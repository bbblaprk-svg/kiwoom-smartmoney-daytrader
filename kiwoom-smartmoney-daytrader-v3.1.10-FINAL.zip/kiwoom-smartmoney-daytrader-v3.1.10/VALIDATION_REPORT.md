# v3.1.10 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.10

## 이번 수정 핵심

- 종목별 프로그램매매 REST TR을 키움 공식 최신 목록 기준 `ka90004`로 교정(`ka90003`은 프로그램순매수상위50).
- 휴장/과거 종가 재구성 시 `ka90013` 종목일별 프로그램매매추이 보강.
- 같은 KRX 종가일을 다시 동기화해도 이미 저장된 마감 스마트머니/프로그램/외국계/기관 수급을 소거하지 않도록 보존.
- 과거 장중 체결 이력이 없던 날짜의 스마트머니는 임의 추정으로 채우지 않음.

## 실행 검증

- `node --check lib/flowCollector.js`: 통과
- `node --check lib/marketSnapshot.js`: 통과
- `node scripts/check.js`: 통과
- `node scripts/integration-check.js`: 통과
- `node scripts/storage-check.js`: 통과
- `node scripts/flow-regression-check.js`: 통과
- `node scripts/load-check.js`: 통과
- 12종목/12,000틱: 21,239 ticks/s, 이벤트루프 p95 27.54ms, RSS 72.4MB, 처리 오류 0, 최종 pending 0

## 실전 확인이 필요한 부분

키움 실서버의 프로그램/투자자 필드 값과 영웅문 표시값은 다음 거래일 장중 및 장마감 후 실제 대조가 필요합니다. 특히 `smartMoney`는 앱이 체결·호가·프로그램·거래원으로 계산하는 파생지표이므로 과거 날짜를 REST 자료만으로 동일하게 복원하지 않습니다.


## v3.1.8 장전 하드닝 검증 항목
- ka90004 기본 TR 확인 및 프로그램 필드 parser strictness
- 프로그램 20초 freshness 일치
- 프로그램/거래원 첫 표본 baseline 처리
- smart-money BUY readiness에 체결/프로그램 최소 표본 적용
- health feedReady 세부 카운터


## v3.1.10 장전 신뢰성 보강 최종 확인

- `RISK → EARLY_SELL → SELL` 3단계를 분리하고, 가격 하락확정(`breakdown`)이 없어도 스마트머니 `DISTRIBUTION` + 공격매도 + 프로그램 매도 가속 + 호가 약화가 겹치면 EARLY_SELL이 가능한 회귀검사를 추가했습니다.
- 확정 SELL은 BUY 전용 VWAP 과열/스프레드 진입금지와 분리하고, 최소 실시간 체결 신선도만 필수로 적용해 매도 경보가 매수 veto 때문에 누락되지 않도록 했습니다.
- SOR는 주문/시세 경로이며 실제 체결시장은 KRX/NXT가 확인된 경우에만 표시하도록 했습니다. `_AL`만 보고 실제체결을 SOR로 표시하지 않습니다.
- 장전 사전점검은 종가/일봉, 프로그램·외국계·기관, 장중 체결·호가·프로그램·거래원, 실제 체결시장, 아이폰 Push를 각각 분리해 누락 종목을 표시합니다.
- VAPID 키는 환경변수가 없으면 영속 볼륨에 최초 1회 생성·저장합니다. 다만 **아이폰 실제 푸시 성공은 홈 화면 PWA에서 구독 후 ‘아이폰 푸시 켜기·테스트’를 눌러 실제 알림 수신까지 확인해야 완료**됩니다. 서버 코드검사만으로 기기 수신 성공을 가장하지 않습니다.
- 휴장 중 체결강도/VWAP/5초 공격대금/호가/프로그램 10초 등 장중 전용 값은 채울 수 없으며 `장중 대기`로 표시합니다. 이는 누락이 아니라 정상 상태입니다.


### Next.js 실제 빌드 확인

- 현재 제작 환경에서 `npm install`을 실행했으나 내부 패키지 프록시가 `autoprefixer` 요청에 404를 반환하여 여기서는 `next build`까지 실행하지 못했습니다.
- 배포용 Dockerfile/업데이트 스크립트는 AWS Lightsail에서 `registry.npmjs.org`를 명시하고 `npm install → npm run check → npm run check:load → npm run build`가 모두 성공해야 새 컨테이너로 교체하도록 구성합니다.
- 따라서 **로컬 소스/회귀/부하 검사는 통과했지만, 실제 Next.js 빌드 성공은 Lightsail 배포 로그에서 최종 확인해야 합니다.**


## v3.1.10 REST 핫픽스 검증

- v3.1.9 `withRestRateLimit()` 스코프 오류 재현 원인 확인
- `scripts/rest-regression-check.js`에서 토큰 발급 후 실제 `kiwoomPost()` 경로 모의 호출 통과
- REST 신규 값이 비어도 마지막 유효 종가를 덮어쓰지 않는 보호 로직 추가
- snapshotStatus는 유효 KRX 종가 개수를 기준으로 ready/partial/error 판정
