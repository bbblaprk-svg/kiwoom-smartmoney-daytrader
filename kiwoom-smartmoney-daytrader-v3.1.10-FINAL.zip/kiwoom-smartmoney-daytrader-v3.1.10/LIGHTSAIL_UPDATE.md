# Lightsail v3.1.10 FINAL 업데이트

GitHub 저장소 최상위에 `Dockerfile`, `kiwoom-smartmoney-daytrader-v3.1.10-FINAL.zip`, `update-lightsail-v3.1.10-FINAL.sh`를 올린 뒤 업데이트 스크립트를 실행합니다. 기존 `.env`와 `kiwoom-data` 볼륨을 그대로 사용합니다.

업데이트는 소스 SHA256, 단위/통합/저장/수급/REST 회귀검사, 12종목 부하검사와 Next build를 통과해야 새 컨테이너로 교체합니다.

업데이트 후 `/api/health`에서 `status=connected`, 종가 동기화 후 `closeSnapshots=5`, 앱의 장전 사전점검에서 SNAPSHOT 5/5와 CLOSING FLOW 5/5를 확인합니다.
