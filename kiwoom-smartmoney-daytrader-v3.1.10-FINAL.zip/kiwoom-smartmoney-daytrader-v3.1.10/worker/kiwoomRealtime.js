const WebSocket = require('ws');
const { getAccessToken } = require('../lib/kiwoomClient');
const { getItem, setItem } = require('../lib/store');
const { mergeWatchlist, splitWatchlist, toKiwoomCode } = require('../lib/stocks');
const { state, processRealtimeEntry, setConnection, setSignalSettings, resetSubscriptions, setPromotion, applyMarketSnapshot } = require('../lib/realtimeStore');
const { notify } = require('../lib/notifications');
const { mergeSettings } = require('../lib/settings');
const { accountRisk } = require('../lib/risk');
const { ensureLoaded: loadPerformance, registerBuySignal, updatePrice: updatePerformancePrice, sweepExpired } = require('../lib/signalPerformance');
const { ensureLoaded: loadSignalLedger, recordSignal, recordShadowSignal, updatePrice: updateLedgerPrice, persistNow: persistSignalLedger } = require('../lib/signalLedger');
const runtimeMetrics = require('../lib/runtimeMetrics');
const { refreshAll: refreshMarketSnapshots, loadLatestSnapshots } = require('../lib/marketSnapshot');

const WS_URL = process.env.KIWOOM_WS_URL || 'wss://api.kiwoom.com:10000/api/dostk/websocket';
const FOCUS_TYPES = ['0B', '0D', '0F', '0w'];
const LIGHT_TYPES = ['0B'];
const GLOBAL_TYPES = ['0s', '1h'];
const SNAPSHOT_INTERVAL_MS = Math.max(5 * 60_000, Number(process.env.MARKET_SNAPSHOT_INTERVAL_MS || 15 * 60_000));
let singleton = globalThis.__KIWOOM_WORKER__ || null;

async function loadWatchlist() { return mergeWatchlist((await getItem('watchlist:user')) || []); }
function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

class KiwoomRealtimeWorker {
  constructor() {
    this.stopped = false;
    this.ws = null;
    this.reconnectAttempt = 0;
    this.watchHash = '';
    this.watchlist = [];
    this.watchPoll = null;
    this.snapshotPoll = null;
    this.marketClockPoll = null;
    this.lastScheduledSnapshotKey = '';
    this.marketStatusRefreshTimers = new Map();
    this.snapshotBusy = false;
    this.notificationBusy = new Set();
    this.positionCache = { loadedAt: 0, positions: [], settings: mergeSettings(null) };
    this.positionAlertAt = new Map();
    this.resubscribeBusy = false;
    this.postPending = new Map();
    this.postRunning = new Set();
    this.postActive = 0;
    this.postMaxConcurrency = Math.max(1, Number(process.env.POST_PROCESS_CONCURRENCY || 4));
    this.positionPersistTimer = null;
    this.positionPersistDirty = false;
  }

  start() {
    this.stopped = false;
    Promise.all([loadPerformance(), loadSignalLedger()]).catch((error) => console.error(`[startup] 성과/기록부 로드 실패: ${error.message}`));
    this.connectLoop().catch((error) => setConnection({ status: 'error', lastError: String(error.message || error) }));
    return this;
  }

  async stop() {
    this.stopped = true;
    if (this.watchPoll) clearInterval(this.watchPoll);
    if (this.snapshotPoll) clearInterval(this.snapshotPoll);
    if (this.marketClockPoll) clearInterval(this.marketClockPoll);
    for (const timer of this.marketStatusRefreshTimers.values()) clearTimeout(timer);
    this.marketStatusRefreshTimers.clear();
    if (this.positionPersistTimer) clearTimeout(this.positionPersistTimer);
    await this.flushPositions().catch((error) => console.error(`[positions] 종료 저장 실패: ${error.message}`));
    await persistSignalLedger().catch((error) => console.error(`[ledger] 종료 저장 실패: ${error.message}`));
    if (this.ws) this.ws.close();
  }

  async connectLoop() {
    while (!this.stopped) {
      try { await this.connectOnce(); this.reconnectAttempt = 0; }
      catch (error) {
        this.reconnectAttempt += 1;
        setConnection({ status: 'reconnecting', lastError: String(error.message || error), reconnects: state.connection.reconnects + 1 });
      }
      if (!this.stopped) await wait(Math.min(30_000, 1000 * (2 ** Math.min(this.reconnectAttempt, 5))));
    }
  }

  async connectOnce() {
    setConnection({ status: 'connecting', lastError: null });
    const token = await getAccessToken();
    const [watchlist, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    this.watchlist = watchlist;
    setSignalSettings(mergeSettings(savedSettings).signal);
    const ws = new WebSocket(WS_URL, { handshakeTimeout: 20_000, perMessageDeflate: false });
    this.ws = ws;
    try {
      await new Promise((resolve, reject) => {
        const cleanup = () => { clearTimeout(timer); ws.off('open', onOpen); ws.off('error', onError); };
        const onOpen = () => { cleanup(); resolve(); };
        const onError = (error) => { cleanup(); reject(error); };
        const timer = setTimeout(() => { cleanup(); reject(new Error('키움 WebSocket 연결 시간초과')); }, 20_000);
        ws.once('open', onOpen); ws.once('error', onError);
      });
      ws.send(JSON.stringify({ trnm: 'LOGIN', token }));
      await this.waitForLogin(ws);
      setConnection({ status: 'connected', connectedAt: new Date().toISOString(), lastError: null });
      ws.on('message', (data) => this.onMessage(data));
      await this.subscribe(this.watchlist, true);
      await this.hydrateSnapshots(this.watchlist);
      this.refreshSnapshots('startup').catch(() => null);
      this.watchPoll = setInterval(() => this.refreshWatchlist().catch(() => null), 30_000);
      this.snapshotPoll = setInterval(() => this.refreshSnapshots('schedule').catch(() => null), SNAPSHOT_INTERVAL_MS);
      this.marketClockPoll = setInterval(() => this.maybeScheduledCloseRefresh().catch(() => null), 60_000);
      this.maybeScheduledCloseRefresh().catch(() => null);
      await new Promise((resolve, reject) => {
        ws.once('close', resolve); ws.once('error', reject);
      });
    } finally {
      if (this.watchPoll) clearInterval(this.watchPoll);
      if (this.snapshotPoll) clearInterval(this.snapshotPoll);
      if (this.marketClockPoll) clearInterval(this.marketClockPoll);
      this.watchPoll = null;
      this.snapshotPoll = null;
      this.marketClockPoll = null;
      for (const timer of this.marketStatusRefreshTimers.values()) clearTimeout(timer);
      this.marketStatusRefreshTimers.clear();
      if (this.ws === ws) this.ws = null;
      try { if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.terminate(); } catch (_) {}
      if (!this.stopped) setConnection({ status: 'disconnected' });
    }
  }

  waitForLogin(ws) {
    return new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); ws.off('message', handler); ws.off('close', onClose); ws.off('error', onError); };
      const finish = (error) => { cleanup(); if (error) reject(error); else resolve(); };
      const onClose = () => finish(new Error('키움 WebSocket이 LOGIN 전에 종료됐습니다.'));
      const onError = (error) => finish(error);
      const handler = (buffer) => {
        let message; try { message = JSON.parse(buffer.toString()); } catch (_) { return; }
        if (message.trnm === 'PING') { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message)); return; }
        if (String(message.trnm || '').toUpperCase() !== 'LOGIN') return;
        if (Number(message.return_code || 0) !== 0) finish(new Error(`키움 LOGIN 실패: ${message.return_msg || message.return_code}`));
        else finish();
      };
      const timer = setTimeout(() => finish(new Error('키움 WebSocket LOGIN 응답 시간초과')), 15_000);
      ws.on('message', handler); ws.once('close', onClose); ws.once('error', onError);
    });
  }


  async hydrateSnapshots(watchlist) {
    const saved = await loadLatestSnapshots(watchlist).catch(() => []);
    for (const item of saved) applyMarketSnapshot(item.meta.code, item.snapshot, {
      name: item.meta.name, marketMode: item.meta.market, tier: item.meta.tier, fixed: item.meta.fixed,
    });
    if (saved.length) setConnection({ snapshotCount: saved.length });
  }

  async refreshSnapshots(reason = 'manual') {
    if (this.snapshotBusy || !this.watchlist.length) return null;
    this.snapshotBusy = true;
    setConnection({ snapshotStatus: 'refreshing', snapshotReason: reason });
    try {
      const savedSettings = await getItem('settings');
      const result = await refreshMarketSnapshots(this.watchlist, {
        settings: savedSettings,
        getLiveStock: (code) => state.stocks.get(code) || null,
      });
      for (const snapshot of result.snapshots) {
        const meta = this.watchlist.find((item) => item.code === snapshot.code) || {};
        applyMarketSnapshot(snapshot.code, snapshot, {
          name: meta.name || snapshot.name, marketMode: meta.market || 'SOR', tier: meta.tier || 'FOCUS', fixed: meta.fixed,
        });
      }
      const invalidSnapshots = result.snapshots
        .filter((snapshot) => !(snapshot && snapshot.krx && Number(snapshot.krx.close || 0) > 0))
        .map((snapshot) => ({ code: snapshot && snapshot.code || '?', error: 'KRX 종가 미수집' }));
      const validSnapshots = result.snapshots.length - invalidSnapshots.length;
      const allErrors = [...result.errors, ...invalidSnapshots];
      const snapshotStatus = validSnapshots === result.requested && allErrors.length === 0
        ? 'ready'
        : validSnapshots > 0 ? 'partial' : 'error';
      setConnection({
        snapshotStatus,
        snapshotCount: validSnapshots,
        snapshotRequested: result.requested,
        snapshotErrors: allErrors,
        lastSnapshotAt: new Date().toISOString(),
      });
      return result;
    } catch (error) {
      setConnection({ snapshotStatus: 'error', snapshotErrors: [{ error: String(error.message || error) }] });
      throw error;
    } finally {
      this.snapshotBusy = false;
    }
  }

  async maybeScheduledCloseRefresh(now = new Date()) {
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const weekday = kst.getUTCDay();
    if (weekday === 0 || weekday === 6) return null;
    const date = kst.toISOString().slice(0, 10);
    const minute = kst.getUTCHours() * 60 + kst.getUTCMinutes();
    let stage = '';
    if (minute >= 15 * 60 + 32 && minute <= 15 * 60 + 37) stage = 'KRX_CLOSE';
    if (minute >= 20 * 60 + 1 && minute <= 20 * 60 + 6) stage = 'NXT_CLOSE';
    if (!stage) return null;
    const key = `${date}:${stage}`;
    if (this.lastScheduledSnapshotKey === key || this.snapshotBusy) return null;
    const result = await this.refreshSnapshots(stage.toLowerCase());
    if (result) this.lastScheduledSnapshotKey = key;
    return result;
  }

  subscriptionGroups(watchlist) {
    const now = Date.now();
    const { focus, light } = splitWatchlist(watchlist);
    const promoted = light.filter((item) => {
      const stock = state.stocks.get(item.code);
      return stock && stock.promotedUntil > now;
    });
    const promotedCodes = new Set(promoted.map((x) => x.code));
    const full = [...focus, ...promoted];
    const lightOnly = light.filter((x) => !promotedCodes.has(x.code));
    return { full, lightOnly, promoted };
  }

  async subscribe(watchlist, replace = false) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const { full, lightOnly, promoted } = this.subscriptionGroups(watchlist);
    const fullCodes = full.map(toKiwoomCode);
    const lightCodes = lightOnly.map(toKiwoomCode);
    const allCodes = [...new Set([...fullCodes, ...lightCodes])];
    const hash = JSON.stringify({ fullCodes, lightCodes });
    this.watchHash = hash;
    this.watchlist = watchlist;
    this.metaByCode = new Map(watchlist.map((item) => [item.code, item]));
    const data = [];
    if (fullCodes.length) data.push({ item: fullCodes, type: FOCUS_TYPES });
    if (lightCodes.length) data.push({ item: lightCodes, type: LIGHT_TYPES });
    data.push({ item: [''], type: GLOBAL_TYPES });
    this.ws.send(JSON.stringify({ trnm: 'REG', grp_no: '1', refresh: replace ? '0' : '1', data }));
    resetSubscriptions({ all: allCodes, focus: fullCodes, light: lightCodes });
    setConnection({ promoted: promoted.map((x) => x.code) });
  }

  async refreshWatchlist() {
    const [list, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    setSignalSettings(mergeSettings(savedSettings).signal);
    const now = Date.now();
    let promotionExpired = false;
    for (const item of list) {
      const stock = state.stocks.get(item.code);
      if (stock && stock.tier === 'LIGHT' && stock.promotedUntil > 0 && stock.promotedUntil <= now) {
        setPromotion(item.code, 0); promotionExpired = true;
      }
    }
    const groups = this.subscriptionGroups(list);
    const hash = JSON.stringify({ fullCodes: groups.full.map(toKiwoomCode), lightCodes: groups.lightOnly.map(toKiwoomCode) });
    const changed = hash !== this.watchHash;
    if (changed || promotionExpired) await this.subscribe(list, true);
    this.watchlist = list;
    if (changed) {
      await this.hydrateSnapshots(list);
      this.refreshSnapshots('watchlist-change').catch(() => null);
    }
    const prices = {};
    for (const [code, stock] of state.stocks.entries()) prices[code] = stock.price;
    await sweepExpired(prices).catch(() => null);
  }

  onMessage(buffer) {
    let message; try { message = JSON.parse(buffer.toString()); } catch (_) { return; }
    if (message.trnm === 'PING') { if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(message)); return; }
    if (message.trnm === 'REG' && Number(message.return_code || 0) !== 0) {
      setConnection({ lastError: `실시간 등록 실패: ${message.return_msg || message.return_code}` });
      if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.close(1011, 'registration failed');
      return;
    }
    if (message.trnm !== 'REAL' || !Array.isArray(message.data)) return;
    setConnection({ lastMessageAt: new Date().toISOString() });
    for (const entry of message.data) {
      const payloadCode = entry.type === '1h' ? entry.values && entry.values['9001'] : entry.item;
      const baseCode = String(payloadCode || '').replace(/_(AL|NX)$/i, '');
      if (entry.type === '1h' && (!this.metaByCode || !this.metaByCode.has(baseCode))) continue;
      const metadata = this.metaByCode ? this.metaByCode.get(baseCode) : null;
      const stock = processRealtimeEntry(entry, metadata || {});
      if (entry.type === '0s') {
        const operation = String(entry.values && entry.values['215'] || '');
        if (['S', 'V', 'W'].includes(operation) && !this.marketStatusRefreshTimers.has(operation)) {
          const timer = setTimeout(() => {
            this.marketStatusRefreshTimers.delete(operation);
            this.refreshSnapshots(`market-status-${operation}`).catch(() => null);
          }, 90_000);
          this.marketStatusRefreshTimers.set(operation, timer);
        }
      }
      if (!baseCode) continue;
      this.schedulePostProcess(baseCode, { trade: entry.type === '0B' });
    }
  }


  schedulePostProcess(code, flags = {}) {
    const existing = this.postPending.get(code);
    if (existing) {
      existing.trade = existing.trade || Boolean(flags.trade);
      runtimeMetrics.incrementPostProcess('coalesced');
    } else {
      this.postPending.set(code, { trade: Boolean(flags.trade) });
    }
    runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
    this.drainPostProcess();
  }

  drainPostProcess() {
    while (this.postActive < this.postMaxConcurrency) {
      const next = [...this.postPending.entries()].find(([code]) => !this.postRunning.has(code));
      if (!next) break;
      const [code, flags] = next;
      this.postPending.delete(code);
      this.postRunning.add(code);
      this.postActive += 1;
      runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
      setImmediate(async () => {
        try {
          const stock = state.stocks.get(code);
          if (flags.trade) {
            await this.maybePromote(code);
            if (stock && stock.price > 0) {
              await Promise.all([
                updatePerformancePrice(code, stock.price),
                updateLedgerPrice(code, stock.price),
              ]);
            }
            await this.maybeRiskNotify(code);
          }
          await this.maybeNotify(code);
          runtimeMetrics.incrementPostProcess('processed');
        } catch (error) {
          runtimeMetrics.incrementPostProcess('errors');
          console.error(`[post-process] ${code} 처리 실패: ${error.message}`);
        } finally {
          this.postRunning.delete(code);
          this.postActive = Math.max(0, this.postActive - 1);
          runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
          this.drainPostProcess();
        }
      });
    }
  }

  schedulePositionsPersist() {
    this.positionPersistDirty = true;
    if (this.positionPersistTimer) return;
    this.positionPersistTimer = setTimeout(() => {
      this.positionPersistTimer = null;
      this.flushPositions().catch((error) => console.error(`[positions] 배치 저장 실패: ${error.message}`));
    }, Math.max(200, Number(process.env.POSITION_BATCH_MS || 750)));
    if (this.positionPersistTimer.unref) this.positionPersistTimer.unref();
  }

  async flushPositions() {
    if (!this.positionPersistDirty || !this.positionCache || !Array.isArray(this.positionCache.positions)) return;
    this.positionPersistDirty = false;
    await setItem('positions', this.positionCache.positions);
    this.positionCache.loadedAt = Date.now();
  }

  async maybePromote(code) {
    const stock = state.stocks.get(code);
    if (!stock || stock.tier !== 'LIGHT' || stock.promotedUntil > Date.now() || stock.promotionScore < 70) return;
    const max = Number(state.settings.maxPromotedLight || 2);
    const current = [...state.stocks.values()].filter((s) => s.tier === 'LIGHT' && s.promotedUntil > Date.now());
    if (current.length >= max) return;
    const seconds = Number(state.settings.promotionSeconds || 600);
    setPromotion(code, Date.now() + seconds * 1000);
    if (this.resubscribeBusy) return;
    this.resubscribeBusy = true;
    try { await this.subscribe(this.watchlist, true); }
    finally { this.resubscribeBusy = false; }
  }

  async loadPositionCache() {
    if (Date.now() - this.positionCache.loadedAt < 30_000) return this.positionCache;
    const [positions, savedSettings] = await Promise.all([getItem('positions'), getItem('settings')]);
    this.positionCache = { loadedAt: Date.now(), positions: Array.isArray(positions) ? positions : [], settings: mergeSettings(savedSettings) };
    return this.positionCache;
  }

  async maybeRiskNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !(stock.price > 0)) return;
    const cache = await this.loadPositionCache();
    const openPositions = cache.positions.filter((position) => position.status !== 'closed' && String(position.code) === code);
    if (!openPositions.length) return;
    let changed = false;
    for (const position of openPositions) {
      const cfg = cache.settings.perStock[code] || { stopPct: -1.5, t1Pct: 1.2, t2Pct: 2, t3Pct: 3, trailPct: 1, trailActivationR: 1 };
      const avg = Number(position.avgPrice || 0); if (!(avg > 0)) continue;
      const initialStop = Number(position.initialStopPrice || avg * (1 + Number(cfg.stopPct || -1.5) / 100));
      const highest = Math.max(Number(position.highestPrice || avg), stock.price);
      const riskPerShare = Math.max(1, avg - initialStop);
      const activationPrice = avg + riskPerShare * Number(cfg.trailActivationR || 1);
      const trailActive = highest >= activationPrice;
      const trailStop = trailActive ? highest * (1 - Number(cfg.trailPct || 1) / 100) : initialStop;
      const currentStop = Math.max(initialStop, trailStop);
      if (highest !== Number(position.highestPrice || avg) || currentStop !== Number(position.currentStopPrice || 0)) {
        position.highestPrice = highest; position.currentStopPrice = Math.round(currentStop); position.trailActive = trailActive;
        position.updatedAt = new Date().toISOString(); changed = true;
      }
      const levels = [
        ['STOP', currentStop, '손절/트레일링 청산'],
        ['T3', avg * (1 + Number(cfg.t3Pct || 3) / 100), '3차 목표 도달'],
        ['T2', avg * (1 + Number(cfg.t2Pct || 2) / 100), '2차 목표 도달'],
        ['T1', avg * (1 + Number(cfg.t1Pct || 1.2) / 100), '1차 목표 도달'],
      ];
      let hit = stock.price <= currentStop ? levels[0] : levels.slice(1).find(([, level]) => stock.price >= level) || null;
      if (!hit) continue;
      const [kind, level, label] = hit;
      const notified = Array.isArray(position.notifiedLevels) ? position.notifiedLevels : [];
      const key = `${position.id}:${kind}`; const last = this.positionAlertAt.get(key) || 0;
      if (kind !== 'STOP' && notified.includes(kind)) continue;
      if (Date.now() - last < 180_000) continue;
      this.positionAlertAt.set(key, Date.now());
      if (kind !== 'STOP') { position.notifiedLevels = [...new Set([...notified, kind])]; changed = true; }
      await notify({
        type: kind === 'STOP' ? 'critical' : 'sell', action: 'SELL', code, name: stock.name, price: stock.price,
        message: `${label} · 현재 ${stock.price.toLocaleString()}원 · 기준 ${Math.round(level).toLocaleString()}원`,
        reasons: [kind === 'STOP' ? '신규매수 차단과 무관하게 청산은 항상 허용' : '분할익절 후 잔량 손절 상향'],
      });
    }
    if (changed) this.schedulePositionsPersist();
  }

  async maybeNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !stock.signal) return;
    const signal = stock.signal;
    const earlyEligible = signal.action === 'EARLY'
      && !signal.blockedByProfitPriority
      && stock.activeTier === 'FOCUS'
      && signal.smartMoneyState === 'TURN'
      && Number(signal.qualityScore || 0) >= Math.max(78, Number(state.settings.earlyWatchScore || 70) + 5);
    const earlySellEligible = signal.action === 'EARLY_SELL'
      && stock.activeTier === 'FOCUS'
      && Boolean(signal.earlySellEligible)
      && Number(signal.sellPressureGroups || 0) >= Number(state.settings.earlySellMinGroups || 3);
    if (!signal.confirmed && !earlyEligible && !earlySellEligible) {
      if (signal.blockedByProfitPriority) {
        await recordShadowSignal({
          code,
          name: stock.name,
          price: stock.price,
          qualityScore: signal.qualityScore,
          profitPriorityScore: signal.profitPriorityScore,
          minProfitPriorityScore: Number(state.settings.minProfitPriorityScore || 78),
          vwapDistancePct: Number(signal.metrics && signal.metrics.vwapDistancePct || 0),
          spreadBps: Number(signal.metrics && signal.metrics.spreadBps || 0),
          reasons: [...signal.reasons, ...signal.warnings],
          at: Date.now(),
        });
      }
      return;
    }
    if (signal.action === 'BUY' || earlyEligible) {
      const cache = await this.loadPositionCache();
      const risk = accountRisk(cache.positions, cache.settings);
      if (risk.halted || risk.openCount >= Number(cache.settings.maxConcurrentPositions || 2)) return;
    }
    const now = Date.now();
    const cooldownMs = Number(state.settings.signalCooldownSeconds || 90) * 1000;
    if (stock.lastNotifiedAction === signal.action && now - stock.lastNotifiedAt < cooldownMs) return;
    const key = `${code}:${signal.action}`;
    if (this.notificationBusy.has(key)) return;
    this.notificationBusy.add(key);
    try {
      stock.lastNotifiedAction = signal.action; stock.lastNotifiedAt = now;
      const notificationAction = earlySellEligible ? 'EARLY_SELL' : (earlyEligible ? 'EARLY' : signal.action);
      const score = notificationAction === 'EARLY_SELL' ? signal.riskScore : notificationAction === 'SELL' ? signal.sellScore : signal.qualityScore;
      const performanceSummary = globalThis.__SIGNAL_PERFORMANCE__;
      const verified = Boolean(performanceSummary && performanceSummary.outcomes && performanceSummary.outcomes.filter((x) => x.result === 'WIN' || x.result === 'LOSS').length >= 200);
      if (notificationAction === 'BUY' && signal.plan) {
        await registerBuySignal({ code, name: stock.name, price: stock.price, qualityScore: signal.qualityScore, stop: signal.plan.stop, target: signal.plan.target1, at: now });
      }
      if (notificationAction !== 'EARLY_SELL') {
        await recordSignal({
          code, name: stock.name, action: notificationAction, price: stock.price,
          qualityScore: signal.qualityScore, profitPriorityScore: signal.profitPriorityScore, sellScore: signal.sellScore,
          reasons: [...signal.reasons, ...signal.warnings], plan: signal.plan, at: now, verified,
        });
      }
      const type = signal.urgency === 'critical' ? 'critical' : ['SELL', 'EARLY_SELL'].includes(notificationAction) ? 'sell' : 'buy';
      const firstReasons = [...signal.reasons, ...signal.warnings].slice(0, 3).join(' · ');
      await notify({
        type, action: notificationAction, code, name: stock.name, score, price: stock.price, reasons: signal.reasons,
        message: `${earlySellEligible ? '급락위험 조기경보·매도확정 아님' : earlyEligible ? '조기관찰·매수확정 아님' : signal.label} · ${['SELL', 'EARLY_SELL'].includes(notificationAction) ? `매도위험 ${score}점` : `품질 ${score}점 · 수익우선 ${signal.profitPriorityScore || 0}점`} · 스마트머니 ${signal.smartMoneyState} · ${stock.price.toLocaleString()}원${verified ? '' : ' · 미검증 신호'}${firstReasons ? ` · ${firstReasons}` : ''}`,
      });
    } finally { this.notificationBusy.delete(key); }
  }
}

function startKiwoomRealtime() {
  if (singleton) return singleton;
  singleton = new KiwoomRealtimeWorker().start();
  globalThis.__KIWOOM_WORKER__ = singleton;
  return singleton;
}

module.exports = { KiwoomRealtimeWorker, startKiwoomRealtime };
