"""Normalize a mounted dotenv file without contacting the broker or printing secrets to logs."""
from __future__ import annotations
import os
import sys
from pathlib import PurePosixPath
from dotenv import dotenv_values


def prepare(path: str) -> dict[str, str]:
    values = {k: v for k, v in dotenv_values(path, interpolate=False).items() if v is not None}
    for key, value in values.items():
        if not key.replace('_', '').isalnum() or '\n' in value or '\r' in value or '\x00' in value:
            raise ValueError(f'invalid single-line environment field: {key}')
    os.environ.update(values)
    os.environ['PULSE_FEED_ENABLED'] = 'false'
    from pulse_edge.config import Settings
    cfg = Settings(_env_file=None).model_copy(update={'feed_enabled': True})
    # Import remains Feed-OFF: no DB open, OAuth or WS activity.
    from pulse_edge.main import effective_pipeline_flags
    flags = effective_pipeline_flags(cfg)
    missing = [key for key, enabled in flags.items() if not enabled]
    if missing:
        raise ValueError('effective pipeline disabled: ' + ','.join(missing))
    if not cfg.ui_enabled:
        raise ValueError('PULSE_UI_ENABLED must be true')
    for key in ('kiwoom_appkey', 'kiwoom_secretkey'):
        if not getattr(cfg, key).strip():
            raise ValueError('missing PULSE_' + key.upper())
    if not 0 < cfg.discovery_interval_sec <= 30:
        raise ValueError('discovery interval must be >0 and <=30 seconds')
    seen = set()
    for name in type(cfg).model_fields:
        if name.endswith('_db_path'):
            value = getattr(cfg, name)
            p = PurePosixPath(value)
            if '..' in p.parts or not p.is_absolute() or not p.is_relative_to('/app/data/pulse_edge'):
                raise ValueError('database path must be inside /app/data/pulse_edge: ' + name)
            if str(p) in seen:
                raise ValueError('different databases share one path: ' + name)
            seen.add(str(p))
    static = len(set(cfg.item_list))
    dynamic = min(cfg.ws_dynamic_max_items, 34 - static)
    if dynamic < 8:
        raise ValueError('fewer than 8 dynamic slots inside the 34-stock cap')
    reserve = max(1, min(cfg.ws_background_reserve_items, 10, dynamic // 3))
    batch = max(1, min(cfg.background_batch_size, 10, reserve))
    values.update(PULSE_WS_DYNAMIC_MAX_ITEMS=str(dynamic),
                  PULSE_WS_BACKGROUND_RESERVE_ITEMS=str(reserve),
                  PULSE_BACKGROUND_BATCH_SIZE=str(batch),
                  PULSE_BACKGROUND_COVERAGE_INTERVAL_SEC='6',
                  PULSE_FEED_ENABLED='true')
    print(f'ENV_PASS effective_pipeline={flags} static={static} dynamic={dynamic} reserve={reserve} batch={batch}', file=sys.stderr)
    return values


if __name__ == '__main__':
    try:
        output = prepare(sys.argv[1])
    except Exception as exc:
        # Do not render ValidationError's input values (may include credentials).
        from pydantic import ValidationError
        detail = ','.join('.'.join(map(str, e['loc'])) + ':' + e['type'] for e in exc.errors()) if isinstance(exc, ValidationError) else str(exc)
        print('ENV_ERROR: ' + detail, file=sys.stderr)
        raise SystemExit(1)
    for key, value in output.items():
        print(f'{key}={value}')
