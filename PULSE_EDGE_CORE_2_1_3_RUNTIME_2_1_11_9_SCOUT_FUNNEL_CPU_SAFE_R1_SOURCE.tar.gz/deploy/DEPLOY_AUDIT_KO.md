# PULSE EDGE 2.1.11.8 CPU ROOT FIX 감사 기록

## 실제 원인 근거
이 수정은 기존 실장 py-spy에서 확인된 608% CPU burst 경로를 기준으로 한다. 당시 스택은 `feed/ws.py:_run_once -> feed/service.py:ingest/ingest_raw -> features/engine.py`가 주 경로였고, Pydantic 생성/FeedState/raw normalize/short-window 계산 및 동기 derived refresh가 함께 CPU를 사용했다.

2.1.11.7을 재분해한 결과 CPU_GUARD가 있었지만 다음 병목이 남아 있었다.
1. WS payload마다 RawEvent와 NormalizedEvent를 Pydantic 정규 생성해 동일 내부 데이터에 검증/복사 비용을 반복했다.
2. SMART FLOW는 10s/30s/2m/5m마다 quote/trade deque를 각각 다시 순회했고 2m large-trade 계산도 별도 순회했다.
3. 5m/30m/이전 5m feature window도 같은 trade deque를 여러 번 다시 순회했다.
4. `RuntimeTruthEngine`은 HIGH/CRITICAL을 표시했지만 dual/history/board/live-audit 계층 상당수가 실제 `_runtime_component_allowed()`를 사용하지 않아 CPU 보호가 관측 중심에 머물렀다.
5. runtime CPU 샘플링 기본 5초는 수초짜리 burst를 막기에는 느렸다.
6. 브라우저는 정상/과부하 상태와 무관하게 slow API 10개를 5초마다 계속 요청했다.

## 2.1.11.8 수정 범위
- `feed/service.py`: WS가 이미 파싱한 trusted dict에 대해 `RawEvent.model_construct` 사용. FeedTruth/Continuity/Session gate는 그대로 유지.
- `feed/normalize.py`: normalizer가 직접 만든 필드에 `NormalizedEvent.model_construct` 사용. decode/truth/continuity 로직 변경 없음.
- `features/engine.py`: 여러 short window를 한 번의 reverse traversal로 생성하고, 5m/30m/previous windows도 한 번의 traversal로 생성. 수학식과 경계조건은 동일.
- `main.py`: FeatureFrame recompute batch를 NORMAL/BUSY/HIGH/CRITICAL에 따라 4/3/2/1로 조정. runtime truth를 1초마다 샘플. 동기 derived refresh를 load 단계에서 분산. historical/audit/display-only observer는 HIGH/CRITICAL에서 잠시 양보하며 마지막 snapshot은 보존.
- `runtime/engine.py`: 실제 suppression 대상 확대. websocket/feed/features/current decision 계층은 보호.
- `web/pulse.js`: 테이블 DOM/행수/열수는 변경하지 않고, HIGH/CRITICAL에서 polling cadence만 자동 완화.
- `/health`: feed hotpath 관측 카운터 추가.

## 변경하지 않은 것
DUAL/PRICE HOLD/PRE-BUY/NXT/SMART MONEY/RS 점수식, threshold, ranking formula, signal eligibility, broker endpoint/type, database schema, table layout/index/css는 변경하지 않았다.

## 실장 안전성
배포는 기존 2.1.11.7 방식의 SHA/archive validation, Docker build, Feed-OFF canary, API validation, two-minute canary soak, exact alias/Feed singleton, data snapshot, Feed-ON warmup, ten-minute live soak, CPU/memory/feed/fresh-tick/recalc queue validation 및 rollback을 유지한다.
