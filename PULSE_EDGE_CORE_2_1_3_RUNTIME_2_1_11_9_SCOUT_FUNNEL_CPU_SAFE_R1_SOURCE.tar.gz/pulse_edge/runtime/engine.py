from __future__ import annotations

from pulse_edge.runtime.models import FeedHealth, LoadStage, RuntimeFrame, RuntimeMetrics, RuntimePolicy


class RuntimeTruthEngine:
    """Pure operational classification. It never changes trading scores."""

    PROTECTED = [
        "websocket",
        "feed_ingest",
        "features",
        "smart_money",
        "ignition",
        "patterns",
        "confluence",
        "prebuy_decision",
        "current_decision_compression",
        "signal_ledger",
    ]

    def __init__(
        self,
        *,
        busy_cpu_pct: float = 65.0,
        high_cpu_pct: float = 80.0,
        critical_cpu_pct: float = 90.0,
        busy_memory_pct: float = 70.0,
        high_memory_pct: float = 82.0,
        critical_memory_pct: float = 92.0,
        busy_disk_pct: float = 78.0,
        high_disk_pct: float = 88.0,
        critical_disk_pct: float = 94.0,
        busy_loop_lag_sec: float = 0.35,
        high_loop_lag_sec: float = 0.8,
        critical_loop_lag_sec: float = 1.5,
        feed_stale_sec: float = 7.0,
    ) -> None:
        self.busy_cpu_pct = busy_cpu_pct
        self.high_cpu_pct = high_cpu_pct
        self.critical_cpu_pct = critical_cpu_pct
        self.busy_memory_pct = busy_memory_pct
        self.high_memory_pct = high_memory_pct
        self.critical_memory_pct = critical_memory_pct
        self.busy_disk_pct = busy_disk_pct
        self.high_disk_pct = high_disk_pct
        self.critical_disk_pct = critical_disk_pct
        self.busy_loop_lag_sec = busy_loop_lag_sec
        self.high_loop_lag_sec = high_loop_lag_sec
        self.critical_loop_lag_sec = critical_loop_lag_sec
        self.feed_stale_sec = feed_stale_sec

    @staticmethod
    def _ge(value: float | None, threshold: float) -> bool:
        return value is not None and value >= threshold

    def _load_stage(self, m: RuntimeMetrics) -> tuple[LoadStage, list[str]]:
        reasons: list[str] = []
        critical = []
        high = []
        busy = []
        for name, value, b, h, c in (
            ("cpu", m.cpu_pct, self.busy_cpu_pct, self.high_cpu_pct, self.critical_cpu_pct),
            ("memory", m.memory_pct, self.busy_memory_pct, self.high_memory_pct, self.critical_memory_pct),
            ("disk", m.disk_pct, self.busy_disk_pct, self.high_disk_pct, self.critical_disk_pct),
            ("event_loop_lag", m.event_loop_lag_sec, self.busy_loop_lag_sec, self.high_loop_lag_sec, self.critical_loop_lag_sec),
        ):
            if self._ge(value, c):
                critical.append(f"{name}_critical")
            elif self._ge(value, h):
                high.append(f"{name}_high")
            elif self._ge(value, b):
                busy.append(f"{name}_busy")
        if critical:
            return LoadStage.CRITICAL, critical
        if high:
            return LoadStage.HIGH, high
        if busy:
            return LoadStage.BUSY, busy
        return LoadStage.NORMAL, reasons

    def _feed_health(self, m: RuntimeMetrics) -> FeedHealth:
        if not m.feed_enabled:
            return FeedHealth.DISABLED
        if not m.ws_connected:
            return FeedHealth.OFFLINE
        if m.last_payload_age_sec is None:
            return FeedHealth.WARMING
        if m.last_payload_age_sec > self.feed_stale_sec:
            return FeedHealth.STALE
        bad = m.truth_invalid_delta + m.truth_stale_delta + m.continuity_reject_delta
        good = m.truth_live_delta
        if bad > 0 and (good == 0 or bad * 4 >= good):
            return FeedHealth.DEGRADED
        return FeedHealth.LIVE

    def _policy(self, stage: LoadStage, feed: FeedHealth, load_reasons: list[str]) -> RuntimePolicy:
        suppressed: list[str] = []
        multipliers: dict[str, float] = {}
        reasons = list(load_reasons)
        if stage == LoadStage.BUSY:
            multipliers = {
                "background_coverage": 1.5,
                "sector_breadth": 1.5,
                "daily_outcomes": 2.0,
                "ignition": 1.5, "sector_spillover": 1.5, "pullback_second_wave": 1.5,
                "market_regime": 1.5, "confluence": 1.5, "pattern_completion": 1.5,
                "krx_nxt_bridge": 1.5, "prebuy_decision": 1.5,
                "current_decision_compression": 1.5, "signal_ledger": 1.5,
            }
        elif stage == LoadStage.HIGH:
            # Protect the live feed and current-decision path first. Historical /
            # audit observers may pause briefly and retain their last snapshot.
            suppressed = ["daily_outcomes", "dual_daily_outcomes", "missed_opportunity", "daily_review"]
            multipliers = {
                "background_coverage": 2.0,
                "sector_breadth": 2.0,
                "market_discovery": 1.5,
                "investor_flow": 2.0,
                "universe_refresh": 2.0,
                "baseline_flush": 2.0,
                "dual_performance": 2.0, "transition_ops": 2.0,
                "nxt_operations_board": 2.0, "krx_operations_board": 2.0,
                "current_enrichment": 2.0, "live_shadow_validation": 2.0, "live_certification": 2.0,
                "ignition": 2.5, "sector_spillover": 2.5, "pullback_second_wave": 2.5,
                "market_regime": 2.5, "confluence": 2.5, "pattern_completion": 2.5,
                "krx_nxt_bridge": 2.5, "prebuy_decision": 2.5,
                "current_decision_compression": 2.5, "signal_ledger": 2.5,
            }
        elif stage == LoadStage.CRITICAL:
            # Do not spend scarce CPU on historical/audit/display stabilizers while
            # the websocket + feature + current-decision path is at risk. The
            # suppressed components preserve their last in-memory/database state.
            suppressed = [
                "daily_outcomes", "dual_daily_outcomes",
                "dual_performance", "transition_ops", "nxt_operations_board",
                "missed_opportunity", "current_enrichment", "krx_operations_board",
                "daily_review", "live_shadow_validation", "live_certification",
            ]
            multipliers = {
                "sector_breadth": 3.0,
                "background_coverage": 2.0,
                "market_discovery": 1.5,
                "investor_flow": 3.0,
                "universe_refresh": 3.0,
                "baseline_flush": 3.0,
                "nxt_native": 2.0,
                "ignition": 4.0, "sector_spillover": 4.0, "pullback_second_wave": 4.0,
                "market_regime": 4.0, "confluence": 4.0, "pattern_completion": 4.0,
                "krx_nxt_bridge": 4.0, "prebuy_decision": 4.0,
                "current_decision_compression": 4.0, "signal_ledger": 4.0,
            }
        lock = feed in {FeedHealth.OFFLINE, FeedHealth.STALE} or stage == LoadStage.CRITICAL
        if feed in {FeedHealth.OFFLINE, FeedHealth.STALE, FeedHealth.DEGRADED}:
            reasons.append(f"feed_{feed.value.lower()}")
        if lock:
            reasons.append("decision_lock_recommended")
        return RuntimePolicy(
            protected_components=list(self.PROTECTED),
            suppressed_components=suppressed,
            interval_multipliers=multipliers,
            decision_lock_recommended=lock,
            reasons=reasons,
        )

    def evaluate(self, metrics: RuntimeMetrics) -> RuntimeFrame:
        stage, reasons = self._load_stage(metrics)
        feed = self._feed_health(metrics)
        policy = self._policy(stage, feed, reasons)
        return RuntimeFrame(
            asof=metrics.asof,
            load_stage=stage,
            feed_health=feed,
            metrics=metrics,
            policy=policy,
            official_signal_enabled=False,
            order_action_enabled=False,
        )
