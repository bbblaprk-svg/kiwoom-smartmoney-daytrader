from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta
from math import isfinite
from time import monotonic
from typing import Any

from pulse_edge.core.models import NormalizedEvent, Venue
from pulse_edge.features.benchmark import BenchmarkMapper, MarketClass
from pulse_edge.features.models import (
    AuctionPoint, FeatureFrame, OpeningFrame, QuoteFlowPoint, TradeFlowPoint, TradePoint
)
from pulse_edge.features.rs import PriceSample, RelativeStrengthEngine
from pulse_edge.session.router import SessionPhase, SessionRouter
from pulse_edge.storage.baseline import SameTimeBaselineStore


def _f(value: Any, *, absolute: bool = False) -> float | None:
    if value is None:
        return None
    try:
        x = float(str(value).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
    if not isfinite(x):
        return None
    return abs(x) if absolute else x


def _window(points: deque[TradePoint], now: datetime, start_min: float, end_min: float = 0.0) -> list[TradePoint]:
    """Return the same chronological window as before, but stop scanning once older rows are reached.

    Exact predicate is preserved: older < ts <= newer.  The deque is time ordered,
    so reverse iteration avoids a full 35-minute scan on every tick.
    """
    newer = now - timedelta(minutes=end_min)
    older = now - timedelta(minutes=start_min)
    out: list[TradePoint] = []
    for point in reversed(points):
        if point.ts > newer:
            continue
        if point.ts <= older:
            break
        out.append(point)
    out.reverse()
    return out


def _seconds_window(points, now: datetime, seconds: float):
    """Exact cutoff-preserving short-window lookup with early stop."""
    cutoff = now - timedelta(seconds=seconds)
    out = []
    for point in reversed(points):
        if point.ts > now:
            continue
        if point.ts <= cutoff:
            break
        out.append(point)
    out.reverse()
    return out




def _seconds_windows(points, now: datetime, seconds_values: tuple[int, ...]):
    """Build several exact short windows in one reverse pass.

    Semantics are identical to repeated _seconds_window calls: cutoff < ts <= now.
    This is a CPU-only optimization for dense realtime quote/trade streams.
    """
    ordered = tuple(sorted(set(int(x) for x in seconds_values)))
    if not ordered:
        return {}
    cutoffs = {sec: now - timedelta(seconds=sec) for sec in ordered}
    oldest = cutoffs[max(ordered)]
    out = {sec: [] for sec in ordered}
    for point in reversed(points):
        if point.ts > now:
            continue
        if point.ts <= oldest:
            break
        for sec in ordered:
            if point.ts > cutoffs[sec]:
                out[sec].append(point)
    for sec in ordered:
        out[sec].reverse()
    return out


def _trade_window_bundle(points: deque[TradePoint], now: datetime):
    """Build 5m/30m and previous 5m windows in one reverse pass.

    Exact predicates are preserved:
      w5  = now-5m  < ts <= now
      w30 = now-30m < ts <= now
      p5  = now-10m < ts <= now-5m
      p10 = now-15m < ts <= now-10m
    """
    c5 = now - timedelta(minutes=5)
    c10 = now - timedelta(minutes=10)
    c15 = now - timedelta(minutes=15)
    c30 = now - timedelta(minutes=30)
    w5, w30, p5, p10 = [], [], [], []
    for point in reversed(points):
        ts = point.ts
        if ts > now:
            continue
        if ts <= c30:
            break
        w30.append(point)
        if ts > c5:
            w5.append(point)
        elif ts > c10:
            p5.append(point)
        elif ts > c15:
            p10.append(point)
    for rows in (w5, w30, p5, p10):
        rows.reverse()
    return w5, w30, p5, p10

def _normalized_ofi(points: list[QuoteFlowPoint]) -> float | None:
    vals = [p.ofi_increment for p in points if p.ofi_increment is not None]
    denom = sum(abs(v) for v in vals)
    if denom <= 0:
        return None
    return max(-1.0, min(1.0, sum(vals) / denom))


def _aggressive_metrics(points: list[TradeFlowPoint]) -> tuple[float | None, float | None]:
    buy = sum(max(0.0, p.buy_exec_volume or 0.0) for p in points)
    sell = sum(max(0.0, p.sell_exec_volume or 0.0) for p in points)
    total = buy + sell
    if total > 0:
        return buy / total * 100.0, (buy - sell) / total
    net = [p.net_buy_exec_volume for p in points if p.net_buy_exec_volume is not None]
    denom = sum(abs(v) for v in net)
    if denom > 0:
        pressure = max(-1.0, min(1.0, sum(net) / denom))
        return 50.0 + pressure * 50.0, pressure
    return None, None


def _large_trade_buy_persistence(points: list[TradeFlowPoint]) -> float | None:
    usable = [p for p in points if p.instant_amount is not None and abs(p.instant_amount) > 0]
    if len(usable) < 4:
        return None
    amounts = sorted(abs(p.instant_amount or 0.0) for p in usable)
    idx = max(0, min(len(amounts) - 1, int((len(amounts) - 1) * 0.75)))
    threshold = amounts[idx]
    large = [p for p in usable if abs(p.instant_amount or 0.0) >= threshold]
    if not large:
        return None
    positive = 0
    known = 0
    for p in large:
        direction = p.net_buy_exec_volume
        if direction is None:
            b = p.buy_exec_single or p.buy_exec_volume
            s = p.sell_exec_single or p.sell_exec_volume
            if b is not None or s is not None:
                direction = (b or 0.0) - (s or 0.0)
        if direction is None or direction == 0:
            continue
        known += 1
        positive += int(direction > 0)
    return None if known == 0 else positive / known * 100.0


def _quote_flow_point(ts: datetime, ask: float, bid: float, data: dict[str, Any], prev: QuoteFlowPoint | None) -> QuoteFlowPoint:
    ask_qty = _f(data.get("ask1_qty"), absolute=True)
    bid_qty = _f(data.get("bid1_qty"), absolute=True)
    total_ask = _f(data.get("total_ask_qty"), absolute=True)
    total_bid = _f(data.get("total_bid_qty"), absolute=True)
    ofi = None
    if prev is not None and ask_qty is not None and bid_qty is not None and prev.ask_qty is not None and prev.bid_qty is not None:
        bid_part = (bid_qty if bid >= prev.bid else 0.0) - (prev.bid_qty if bid <= prev.bid else 0.0)
        ask_part = -(ask_qty if ask <= prev.ask else 0.0) + (prev.ask_qty if ask >= prev.ask else 0.0)
        ofi = bid_part + ask_part
    micro = bias = None
    if ask_qty is not None and bid_qty is not None and ask_qty + bid_qty > 0:
        micro = (ask * bid_qty + bid * ask_qty) / (bid_qty + ask_qty)
        mid = (ask + bid) / 2.0
        if mid > 0:
            bias = (micro / mid - 1.0) * 100.0
    return QuoteFlowPoint(
        ts=ts, ask=ask, bid=bid, ask_qty=ask_qty, bid_qty=bid_qty,
        total_ask_qty=total_ask, total_bid_qty=total_bid,
        ofi_increment=ofi, microprice=micro, microprice_bias_pct=bias,
    )


def _smart_flow_realtime(quote_points, trade_points, now: datetime):
    windows = ((10, "10s"), (30, "30s"), (120, "2m"), (300, "5m"))
    q_windows = _seconds_windows(quote_points, now, (10, 30, 120, 300))
    t_windows = _seconds_windows(trade_points, now, (10, 30, 120, 300))
    ofi = {}; buy_ratio = {}; pressure = {}; confirms = 0
    for seconds, label in windows:
        qw = q_windows[seconds]
        tw = t_windows[seconds]
        ofi[label] = _normalized_ofi(qw)
        buy_ratio[label], pressure[label] = _aggressive_metrics(tw)
        q_ok = ofi[label] is not None and ofi[label] >= 0.10
        t_ok = ((pressure[label] is not None and pressure[label] >= 0.10) or
                (buy_ratio[label] is not None and buy_ratio[label] >= 55.0))
        confirms += int(q_ok and t_ok)

    latest_quote = quote_points[-1] if quote_points else None
    micro = latest_quote.microprice if latest_quote else None
    micro_bias = latest_quote.microprice_bias_pct if latest_quote else None
    quote_age = None if latest_quote is None else max(0.0, (now - latest_quote.ts).total_seconds())
    large = _large_trade_buy_persistence(t_windows[120])

    # Score is intentionally bounded and scale-light; it strengthens the existing
    # flow evidence group but never becomes an independent sixth Confluence vote.
    ofi_vals = [max(0.0, v) for v in ofi.values() if v is not None]
    pressure_vals = [max(0.0, v) for v in pressure.values() if v is not None]
    buy_vals = [max(0.0, min(100.0, v)) for v in buy_ratio.values() if v is not None]
    score = 0.0
    covered = 0
    if ofi_vals:
        score += min(35.0, sum(ofi_vals) / len(ofi_vals) * 35.0); covered += 35
    if pressure_vals or buy_vals:
        p = sum(pressure_vals) / len(pressure_vals) if pressure_vals else 0.0
        b = ((sum(buy_vals) / len(buy_vals)) - 50.0) / 50.0 if buy_vals else 0.0
        score += min(30.0, max(0.0, max(p, b)) * 30.0); covered += 30
    if micro_bias is not None:
        score += min(15.0, max(0.0, micro_bias) / 0.05 * 15.0); covered += 15
    if large is not None:
        score += min(10.0, max(0.0, large - 50.0) / 50.0 * 10.0); covered += 10
    score += confirms / 4.0 * 10.0; covered += 10
    normalized = None if covered == 0 else max(0.0, min(100.0, score * 100.0 / covered))

    if normalized is None:
        state = "DATA_WAIT"
    elif confirms >= 4 and normalized >= 75 and quote_age is not None and quote_age <= 3.5:
        state = "FLOW_LIVE"
    elif confirms >= 3 and normalized >= 65:
        state = "FLOW_EST_HIGH"
    elif confirms >= 2 and normalized >= 52:
        state = "FLOW_EST_MID"
    else:
        state = "FLOW_WARMING"
    return ofi, buy_ratio, pressure, micro, micro_bias, large, normalized, confirms, state, quote_age


def _money(points: list[TradePoint]) -> float:
    return sum(p.price * p.volume for p in points)


def _vwap(points: list[TradePoint]) -> float | None:
    vol = sum(p.volume for p in points)
    if vol <= 0:
        return None
    return sum(p.price * p.volume for p in points) / vol


def _price_at_or_before(points: deque[TradePoint], cutoff: datetime) -> float | None:
    # Exact same result as the forward scan, but normally returns after only a
    # handful of reverse steps instead of walking the entire retained deque.
    for point in reversed(points):
        if point.ts <= cutoff:
            return point.price
    return None


@dataclass
class _SessionAccumulator:
    session_id: str
    pv: float = 0.0
    volume: float = 0.0

    def add(self, price: float, volume: float) -> None:
        if volume > 0:
            self.pv += price * volume
            self.volume += volume

    @property
    def vwap(self) -> float | None:
        if self.volume <= 0:
            return None
        return self.pv / self.volume


class FeatureEngine:
    def __init__(
        self,
        session_router: SessionRouter | None = None,
        baseline_store: SameTimeBaselineStore | None = None,
        benchmark_mapper: BenchmarkMapper | None = None,
    ) -> None:
        self.session_router = session_router or SessionRouter()
        self.baseline_store = baseline_store
        self.benchmark_mapper = benchmark_mapper or BenchmarkMapper()
        self.trades: dict[tuple[Venue, str], deque[TradePoint]] = defaultdict(lambda: deque(maxlen=50000))
        self.trade_flow: dict[tuple[Venue, str], deque[TradeFlowPoint]] = defaultdict(lambda: deque(maxlen=20000))
        self.quote_flow: dict[tuple[Venue, str], deque[QuoteFlowPoint]] = defaultdict(lambda: deque(maxlen=20000))
        self.auctions: dict[str, deque[AuctionPoint]] = defaultdict(lambda: deque(maxlen=1000))
        self.best_quotes: dict[tuple[Venue, str], tuple[float, float, datetime]] = {}
        self.program: dict[tuple[Venue, str], dict[str, float | None]] = {}
        self.frames: dict[tuple[Venue, str], FeatureFrame] = {}
        self.opening_frames: dict[str, OpeningFrame] = {}
        self.benchmarks: dict[tuple[Venue, str], deque[PriceSample]] = defaultdict(lambda: deque(maxlen=20000))
        self.session_accumulators: dict[tuple[Venue, str], _SessionAccumulator] = {}
        self.rs = RelativeStrengthEngine()
        # Runtime-only recalculation coalescing. Raw/normalized events are still
        # applied immediately; only expensive derived-frame recomputation is
        # bounded. This preserves formulas and the latest state while preventing
        # bursty 0B/0C/0D/0w streams from recalculating the same symbol hundreds
        # of times per second.
        self._recalc_min_interval_sec = 0.50
        self._dirty_recalc: dict[tuple[Venue, str], datetime] = {}
        self._dirty_since_wall: dict[tuple[Venue, str], float] = {}
        self._last_recalc_wall: dict[tuple[Venue, str], float] = {}
        self.recalc_requested = 0
        self.recalc_executed = 0
        self.recalc_coalesced = 0

    def register_symbol_market(self, symbol: str, market: MarketClass | str) -> None:
        self.benchmark_mapper.register(symbol, market)

    def _request_recalc(self, key: tuple[Venue, str], ts: datetime) -> None:
        """Schedule derived-frame work without wasting CPU before trade state exists."""
        # A quote/program event can legitimately arrive before the first trade.
        # _recalc() cannot produce a FeatureFrame without trade data, so calling it
        # repeatedly in that state is pure CPU cost. Keep quote/program state as
        # ingested and let the first trade create the initial frame.
        if not self.trades.get(key):
            return
        self.recalc_requested += 1
        now_wall = monotonic()
        if key not in self.frames:
            self._recalc(key, ts)
            if key in self.frames:
                self._last_recalc_wall[key] = now_wall
                self.recalc_executed += 1
            self._dirty_recalc.pop(key, None)
            self._dirty_since_wall.pop(key, None)
            return
        if key in self._dirty_recalc:
            self.recalc_coalesced += 1
        else:
            self._dirty_since_wall[key] = now_wall
        prev = self._dirty_recalc.get(key)
        if prev is None or ts >= prev:
            self._dirty_recalc[key] = ts

    def flush_due(self, *, force: bool = False, max_batch: int = 4) -> int:
        """Recalculate a bounded number of dirty symbols using their latest event time.

        Ordering is oldest-dirty-first for fairness. A force flush is intended for
        tests/shutdown only. No market data is dropped.
        """
        if not self._dirty_recalc:
            return 0
        now_wall = monotonic()
        due = []
        for key, ts in self._dirty_recalc.items():
            last = self._last_recalc_wall.get(key, 0.0)
            if force or now_wall - last >= self._recalc_min_interval_sec:
                due.append((self._dirty_since_wall.get(key, now_wall), key, ts))
        if not due:
            return 0
        due.sort(key=lambda x: x[0])
        done = 0
        for _, key, ts in due[:max(1, int(max_batch))]:
            # Pop before calculating so a future request can never be lost.
            self._dirty_recalc.pop(key, None)
            self._dirty_since_wall.pop(key, None)
            self._recalc(key, ts)
            self._last_recalc_wall[key] = monotonic()
            self.recalc_executed += 1
            done += 1
        return done

    def pending_recalc_count(self) -> int:
        return len(self._dirty_recalc)

    def recalc_runtime_stats(self) -> dict[str, int | float]:
        now_wall = monotonic()
        oldest_pending_ms = 0
        if self._dirty_since_wall:
            oldest_pending_ms = int(max(0.0, now_wall - min(self._dirty_since_wall.values())) * 1000.0)
        return {
            "pending": len(self._dirty_recalc),
            "requested": self.recalc_requested,
            "executed": self.recalc_executed,
            "coalesced": self.recalc_coalesced,
            "min_interval_ms": int(self._recalc_min_interval_sec * 1000),
            "oldest_pending_ms": oldest_pending_ms,
        }

    def ingest(self, event: NormalizedEvent) -> None:
        if not event.real_type:
            return
        ts = event.event_time or event.receive_time

        if event.real_type in {"0J", "0U"}:
            if not event.symbol:
                return
            if event.real_type == "0J":
                price = _f(event.data.get("price"), absolute=True)
                if price is not None and price > 0:
                    key = (Venue.KRX, event.symbol)
                    self.benchmarks[key].append(PriceSample(ts=ts, price=price))
                    self._trim_benchmark(key, ts)
            return

        if not event.symbol:
            return
        key = (event.venue, event.symbol)

        if event.real_type == "0B":
            session_id = self.session_router.session_key(event.venue, ts)
            if session_id is None:
                return
            price = _f(event.data.get("price"), absolute=True)
            if price is None or price <= 0:
                return
            volume = _f(event.data.get("trade_volume"), absolute=True) or 0.0
            point = TradePoint(
                ts=ts,
                price=price,
                volume=volume,
                change_rate=_f(event.data.get("change_rate")),
                cumulative_volume=_f(event.data.get("cumulative_volume"), absolute=True),
                cumulative_amount=_f(event.data.get("cumulative_amount"), absolute=True),
            )
            self.trades[key].append(point)
            self.trade_flow[key].append(TradeFlowPoint(
                ts=ts, price=price,
                buy_exec_volume=_f(event.data.get("buy_exec_volume"), absolute=True),
                sell_exec_volume=_f(event.data.get("sell_exec_volume"), absolute=True),
                net_buy_exec_volume=_f(event.data.get("net_buy_exec_volume")),
                instant_amount=_f(event.data.get("instant_amount"), absolute=True),
                buy_exec_single=_f(event.data.get("buy_exec_single"), absolute=True),
                sell_exec_single=_f(event.data.get("sell_exec_single"), absolute=True),
            ))
            self._trim_trade(key, ts)
            self._trim_flow(key, ts)
            acc = self.session_accumulators.get(key)
            if acc is None or acc.session_id != session_id:
                acc = _SessionAccumulator(session_id=session_id)
                self.session_accumulators[key] = acc
            acc.add(price, volume)
            self._request_recalc(key, ts)
            if event.venue == Venue.NXT:
                self._recalc_opening(event.symbol, ts)
            return

        if event.real_type in {"0C", "0D"}:
            ask = _f(event.data.get("ask1"), absolute=True)
            bid = _f(event.data.get("bid1"), absolute=True)
            if ask and bid and ask > 0 and bid > 0:
                self.best_quotes[key] = (ask, bid, ts)
                if event.real_type == "0D":
                    prev = self.quote_flow[key][-1] if self.quote_flow[key] else None
                    self.quote_flow[key].append(_quote_flow_point(ts, ask, bid, event.data, prev))
                    self._trim_flow(key, ts)
                self._request_recalc(key, ts)
            return

        if event.real_type == "0w":
            self.program[key] = {
                "program_net_buy_qty": _f(event.data.get("program_net_buy_qty")),
                "program_net_buy_qty_delta": _f(event.data.get("program_net_buy_qty_delta")),
                "program_net_buy_amount": _f(event.data.get("program_net_buy_amount")),
                "program_net_buy_amount_delta": _f(event.data.get("program_net_buy_amount_delta")),
            }
            self._request_recalc(key, ts)
            return

        if event.real_type == "0H" and event.venue == Venue.KRX:
            if self.session_router.phase_at(ts) != SessionPhase.OPENING_AUCTION:
                return
            price = _f(event.data.get("price"), absolute=True)
            if price is None or price <= 0:
                return
            ap = AuctionPoint(
                ts=ts,
                expected_price=price,
                expected_change_rate=_f(event.data.get("change_rate")),
                expected_volume=_f(event.data.get("cumulative_volume"), absolute=True)
                or _f(event.data.get("trade_volume"), absolute=True),
            )
            self.auctions[event.symbol].append(ap)
            self._trim_auction(event.symbol, ts)
            self._recalc_opening(event.symbol, ts)

    def _trim_trade(self, key: tuple[Venue, str], now: datetime) -> None:
        q = self.trades[key]
        cutoff = now - timedelta(minutes=35)
        while q and q[0].ts < cutoff:
            q.popleft()

    def _trim_flow(self, key: tuple[Venue, str], now: datetime) -> None:
        cutoff = now - timedelta(minutes=6)
        for store in (self.trade_flow, self.quote_flow):
            q = store[key]
            while q and q[0].ts < cutoff:
                q.popleft()

    def _trim_benchmark(self, key: tuple[Venue, str], now: datetime) -> None:
        q = self.benchmarks[key]
        cutoff = now - timedelta(minutes=35)
        while q and q[0].ts < cutoff:
            q.popleft()

    def _trim_auction(self, symbol: str, now: datetime) -> None:
        q = self.auctions[symbol]
        cutoff = now - timedelta(minutes=15)
        while q and q[0].ts < cutoff:
            q.popleft()

    def _recalc(self, key: tuple[Venue, str], now: datetime) -> None:
        q = self.trades.get(key)
        if not q:
            return
        venue, symbol = key
        cur = q[-1]
        w5, w30, p5, p10 = _trade_window_bundle(q, now)
        money5 = _money(w5)
        money_prev5 = _money(p5)
        money_prev10 = _money(p10)
        v5 = money5 / 300.0 if w5 else None
        vp5 = money_prev5 / 300.0 if p5 else None
        vp10 = money_prev10 / 300.0 if p10 else None
        accel = None if v5 is None or vp5 is None else v5 - vp5
        prev_accel = None if vp5 is None or vp10 is None else vp5 - vp10
        second = None if accel is None or prev_accel is None else accel - prev_accel

        acc = self.session_accumulators.get(key)
        session_vwap = acc.vwap if acc else None
        vwap5 = _vwap(w5)
        vwap30 = _vwap(w30)
        dist = None if session_vwap is None else (cur.price / session_vwap - 1.0) * 100.0

        def ret(minutes: int) -> float | None:
            p0 = _price_at_or_before(q, now - timedelta(minutes=minutes))
            if p0 is None or p0 <= 0:
                return None
            return (cur.price / p0 - 1.0) * 100.0

        spread = None
        quote = self.best_quotes.get(key)
        if quote:
            ask, bid, _ = quote
            mid = (ask + bid) / 2.0
            if mid > 0:
                spread = (ask - bid) / mid * 100.0

        baseline = None
        baseline_days = 0
        if self.baseline_store is not None:
            baseline, baseline_days = self.baseline_store.get_same_time_money(venue.value, symbol, now, 20)
            self.baseline_store.observe(venue.value, symbol, now, money5)
        rvol = None if baseline is None or baseline <= 0 else money5 / baseline

        rs_level = rs_velocity = rs_accel = None
        rs_zero = None
        benchmark_symbol = None
        binding = self.benchmark_mapper.benchmark_for(venue, symbol)
        if binding:
            benchmark_symbol = binding[1]
            bq = self.benchmarks.get(binding)
            if bq:
                # TradePoint and PriceSample share the exact ts/price interface.
                # Avoid copying the complete stock deque on every market event.
                r = self.rs.calculate(q, bq, now)
                rs_level = r["level"]
                rs_velocity = r["velocity"]
                rs_accel = r["acceleration"]
                rs_zero = r["zero_cross"]

        program = self.program.get(key, {})
        qflow = self.quote_flow.get(key, deque())
        tflow = self.trade_flow.get(key, deque())
        (ofi, aggressive_ratio, trade_pressure, microprice, microprice_bias, large_trade_buy,
         realtime_flow_score, realtime_flow_windows, realtime_flow_state, quote_age) = _smart_flow_realtime(qflow, tflow, now)
        coverage = max(0.0, (q[-1].ts - q[0].ts).total_seconds())
        flags: list[str] = []
        if coverage < 300:
            flags.append("WARMUP_LT_5M")
        if coverage < 900:
            flags.append("MONEY_SECOND_DERIVATIVE_WARMUP")
        if baseline is None:
            flags.append("SAME_TIME_BASELINE_MISSING")
        elif baseline_days < 20:
            flags.append(f"SAME_TIME_BASELINE_PARTIAL_{baseline_days}D")
        if binding is None:
            flags.append("BENCHMARK_MARKET_UNKNOWN")
        elif binding not in self.benchmarks or not self.benchmarks[binding]:
            flags.append("BENCHMARK_STREAM_MISSING")
        if not qflow:
            flags.append("SMART_FLOW_QUOTE_DEPTH_MISSING")
        if not tflow:
            flags.append("SMART_FLOW_TRADE_DETAIL_MISSING")
        if large_trade_buy is not None:
            flags.append("LARGE_TRADE_AMOUNT_SCALE_UNVERIFIED_DIRECTION_ONLY")

        self.frames[key] = FeatureFrame(
            venue=venue,
            symbol=symbol,
            asof=now,
            session_id=acc.session_id if acc else None,
            price=cur.price,
            change_rate=cur.change_rate,
            session_vwap=session_vwap,
            vwap_5m=vwap5,
            vwap_30m=vwap30,
            vwap_distance_pct=dist,
            return_1m_pct=ret(1),
            return_5m_pct=ret(5),
            return_10m_pct=ret(10),
            money_5m=money5,
            money_velocity_5m=v5,
            money_velocity_prev5m=vp5,
            money_acceleration=accel,
            money_second_derivative=second,
            spread_pct=spread,
            rvol_same_time=rvol,
            baseline_days=baseline_days,
            benchmark_symbol=benchmark_symbol,
            rs_level=rs_level,
            rs_velocity=rs_velocity,
            rs_acceleration=rs_accel,
            rs_zero_cross=rs_zero,
            program_net_buy_qty=program.get("program_net_buy_qty"),
            program_net_buy_qty_delta=program.get("program_net_buy_qty_delta"),
            program_net_buy_amount=program.get("program_net_buy_amount"),
            program_net_buy_amount_delta=program.get("program_net_buy_amount_delta"),
            ofi_10s=ofi.get("10s"),
            ofi_30s=ofi.get("30s"),
            ofi_2m=ofi.get("2m"),
            ofi_5m=ofi.get("5m"),
            aggressive_buy_ratio_10s=aggressive_ratio.get("10s"),
            aggressive_buy_ratio_30s=aggressive_ratio.get("30s"),
            aggressive_buy_ratio_2m=aggressive_ratio.get("2m"),
            aggressive_buy_ratio_5m=aggressive_ratio.get("5m"),
            trade_pressure_10s=trade_pressure.get("10s"),
            trade_pressure_30s=trade_pressure.get("30s"),
            trade_pressure_2m=trade_pressure.get("2m"),
            trade_pressure_5m=trade_pressure.get("5m"),
            microprice=microprice,
            microprice_bias_pct=microprice_bias,
            large_trade_buy_persistence_2m=large_trade_buy,
            smart_flow_realtime_score_100=realtime_flow_score,
            smart_flow_confirmed_windows=realtime_flow_windows,
            smart_flow_state=realtime_flow_state,
            quote_age_sec=quote_age,
            coverage_sec=coverage,
            flags=flags,
        )

    def _recalc_opening(self, symbol: str, now: datetime) -> None:
        opening_valid = self.session_router.phase_at(now) == SessionPhase.OPENING_AUCTION
        if not opening_valid:
            return
        aq = self.auctions.get(symbol)
        if not aq:
            return
        rows = list(aq)
        latest = rows[-1]
        rates = [p.expected_change_rate for p in rows if p.expected_change_rate is not None]
        min_rate = min(rates) if rates else None
        recovery = None if min_rate is None or latest.expected_change_rate is None else latest.expected_change_rate - min_rate
        velocity = None
        if recovery is not None:
            min_point = min((p for p in rows if p.expected_change_rate is not None), key=lambda p: p.expected_change_rate)
            mins = max((latest.ts - min_point.ts).total_seconds() / 60.0, 1e-9)
            velocity = recovery / mins

        accel = None
        valid = [p for p in rows if p.expected_change_rate is not None]
        if len(valid) >= 3:
            a, b, c = valid[-3:]
            dt1 = max((b.ts - a.ts).total_seconds() / 60.0, 1e-9)
            dt2 = max((c.ts - b.ts).total_seconds() / 60.0, 1e-9)
            s1 = (b.expected_change_rate - a.expected_change_rate) / dt1
            s2 = (c.expected_change_rate - b.expected_change_rate) / dt2
            accel = s2 - s1

        vols = [p.expected_volume for p in rows if p.expected_volume is not None]
        vol_change = None if len(vols) < 2 else vols[-1] - vols[0]

        nxt_q = self.trades.get((Venue.NXT, symbol))
        nxt_rate = nxt_q[-1].change_rate if nxt_q else None
        current_dislocation = None
        if nxt_rate is not None and latest.expected_change_rate is not None:
            current_dislocation = nxt_rate - latest.expected_change_rate
        max_dislocation = None
        if nxt_rate is not None and rates:
            max_dislocation = max(nxt_rate - r for r in rates)

        flags: list[str] = []
        if nxt_rate is None:
            flags.append("NXT_REFERENCE_MISSING")
        if len(rows) < 3:
            flags.append("OPENING_SERIES_WARMUP")

        self.opening_frames[symbol] = OpeningFrame(
            symbol=symbol,
            asof=now,
            opening_window_valid=True,
            nxt_change_rate=nxt_rate,
            krx_expected_change_rate=latest.expected_change_rate,
            current_dislocation_pp=current_dislocation,
            max_dislocation_pp=max_dislocation,
            min_expected_change_rate=min_rate,
            recovery_pp=recovery,
            recovery_velocity_pp_per_min=velocity,
            recovery_acceleration=accel,
            expected_volume_change=vol_change,
            sample_count=len(rows),
            flags=flags,
        )
