# v3.3.0 REALTIME FOUNDATION

## 목적
급등 후 추격이 아니라 급등 전 PRE-IGNITION을 포착한다. 장중 판단은 실제 Kiwoom 국내주식 WebSocket에서 수신된 데이터만 사용한다.

## 데이터 수급 원칙
- 국내주식 WebSocket 연결 1개, LOGIN 1회.
- 공식 예제 형태의 bare 6자리 종목코드 REG만 사용한다.
- 핵심 체결 타입은 0B(주식체결).
- 0D(호가잔량), 0u(종목프로그램매매), 0F(당일거래원), 0m(장시작시간)를 보조 실시간 입력으로 사용한다.
- `_NX`, `stex_tp`, 별도 NXT socket, 숫자/문자 probe, 장시간 기반 거래소 추정은 사용하지 않는다.
- 수신 REAL payload의 FID 9081이 KRX/1 또는 NXT/2로 확인될 때만 해당 거래소 데이터로 인정한다.
- FID 9081 미확인/미지원 값은 UNKNOWN으로 남기며 currentPrice와 신호 입력에 사용하지 않는다.

## 실시간 판단 게이트
REG ACK는 데이터 정상의 증거가 아니다. 정상 순서는 다음과 같다.
1. SOCKET_CONNECTED
2. REG_ACCEPTED
3. FIRST_CONFIRMED_TICK
4. FRESH_CONFIRMED_TICK

활성 세션에서 fresh 0B가 없으면 currentPrice를 비우고 신규 PRE-IGNITION/EARLY/PRE-BUY/BUY를 차단한다. REST/전일종가/캐시는 이를 대신하지 않는다.

## 상태 저장
KRX와 NXT raw venue state를 분리 저장한다. 통합 현재가는 가장 최근의 confirmed+fresh 실제 체결에서만 계산한다. 원본 KRX/NXT 상태는 서로 덮어쓰지 않는다.

## PRE-IGNITION
- Tape: 체결속도/순매수/대형공격매수 가속
- Orderbook: 매수잔량 재충전/매도잔량 소진/imbalance 개선
- Program: 프로그램 순매수 velocity/음→양 전환
- Context: VWAP 근접/상대거래량 증가/과열 아님
최소 3개의 독립축 동시 강화가 필요하며 같은 체결 원천의 파생지표를 독립증거로 중복 계산하지 않는다.

## 복구
특정 거래소 tick 부재만으로 정상 국내 WebSocket을 끊지 않는다. 활성 세션 전체에서 confirmed 0B가 모두 사라졌을 때만 동일 공식 REG 재시도 후 필요 시 socket 재연결한다.
