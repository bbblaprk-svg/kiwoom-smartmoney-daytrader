# v3.3.6 Official Trade 0B Restore

- Kiwoom official domestic realtime map: 0B = 주식체결.
- Reverts the incorrect v3.3.5 0A trade change.
- Keeps official bare six-digit WebSocket REG.
- Keeps REST NXT code suffix `_NX` only for REST queries.
- Keeps FID9081 as KRX/NXT venue truth and fails closed when NXT firstTick/fresh is absent.
- Does not claim NXT success from REG ACK alone.
