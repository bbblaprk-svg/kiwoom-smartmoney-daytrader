# Kiwoom Unified Edge v3.3.3

REALTIME FOUNDATION + close freshness + NXT exchange-map subscription.

Core policy: active-session trading judgments use confirmed WebSocket 0B ticks only. KRX/NXT classification is made from REAL FID 9081 only. REST/close/cache never substitutes for active-session live price.
