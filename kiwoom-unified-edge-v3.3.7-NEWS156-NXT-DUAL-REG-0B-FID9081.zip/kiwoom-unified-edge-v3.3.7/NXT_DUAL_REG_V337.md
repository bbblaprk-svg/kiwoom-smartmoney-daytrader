# v3.3.7 NXT Dual WebSocket Registration

- KRX 0B: bare 6-digit item registration retained.
- NXT 0B: one batched `code_NX` registration group added.
- No `stex_tp` item-map is used in domestic WebSocket REG.
- Actual venue truth remains FID 9081 only; registration labels never override the received venue.
- NXT registration failure is non-fatal so KRX realtime remains available.
- REST `_NX` lookup path is unchanged.
