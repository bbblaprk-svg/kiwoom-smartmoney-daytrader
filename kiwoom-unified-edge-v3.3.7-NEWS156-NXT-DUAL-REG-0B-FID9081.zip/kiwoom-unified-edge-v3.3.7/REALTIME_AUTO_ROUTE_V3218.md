# v3.2.18 REALTIME AUTO-ROUTE
- WebSocket REG uses bare 6-digit stock codes; `_NX/_AL` are reserved for REST exchange-specific queries.
- Core registration subscribes both 0A and 0B. Official menu identifies 0A as stock trades; runtime additionally recognizes a trade-like payload by FIDs (10 + 15/13/228) so a live compatibility discrepancy cannot leave the engine at firstTick=0.
- REAL payload exchange FIDs (9081/337) are authoritative. In NXT-only/KRX-only sessions the session identifies venue. During overlap without an exchange FID the tick is marked SOR rather than falsely classified KRX.
- No REST/close price can become an intraday decision price. No fresh WebSocket trade -> no EARLY/PRE-BUY/BUY.
- Health exposes detectedTradeType, firstTick/fresh per KRX/NXT/SOR, and dataStatus.
