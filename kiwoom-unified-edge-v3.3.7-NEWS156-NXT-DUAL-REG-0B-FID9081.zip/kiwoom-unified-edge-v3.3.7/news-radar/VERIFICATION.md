# ROTATION PICKS v1.5.6 검증

- 기준: SECTOR FORECAST v1.5.3 RESTORED
- 화면: 예상 순환섹터 최대 1~2개만 노출
- 카드: 3일/5일 확률 + 1차 최대 2 + 2차 최대 2 + 핵심근거
- `현재 시장 주도섹터 TOP` 다중 나열 UI 제거, 내부 계산/분산 로직은 유지
- 평탄한 50%대 시장에서는 억지 후보 생성 금지
- v1.5.3 기본 글씨/배치 유지
- 스크롤 시 화면 중앙 상세문단만 1.5배 확대
- `/api/discovery-feed` + `INTERNAL_BRIDGE_TOKEN` 유지
- v3.2.12 뉴스→30종목 자동투입 계약 유지
- 뉴스앱 Kiwoom 직접호출 없음

검사:
- node --check: PASS
- npm run check: PASS
- SOURCE_MANIFEST.sha256: PASS
