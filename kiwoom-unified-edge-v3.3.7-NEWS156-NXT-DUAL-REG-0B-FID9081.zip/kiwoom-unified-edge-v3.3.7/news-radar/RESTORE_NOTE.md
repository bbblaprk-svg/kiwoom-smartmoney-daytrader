# SECTOR FORECAST v1.5.3 RESTORED

이 패키지는 `SECTOR FORECAST v1.5.3` 뉴스앱을 기준으로 복원한 독립 News Radar입니다.

유지되는 핵심 화면/기능:
- NEXT US SESSION
- US MARKET LIVE DESK (프리/정규/애프터)
- GLOBAL PULSE
- SECTOR ROTATION FORECAST 3D/5D
- GLOBAL SECTOR ROTATION
- AUTO200 / ACTIVE20
- 글로벌 6축 뉴스
- 정부정책 / 투자자 인사이트 / YouTube 3선
- D+1/D+2/D+3 자동확률보정

호환성 복원:
- `/api/discovery-feed`
- `INTERNAL_BRIDGE_TOKEN`
- v3.2.12 `lib/newsBridge.js`가 기대하는 feed 필드
- 뉴스→30종목 자동투입 계약

추가 안전수정:
- 느린 미국 공개시세/학습복원이 전체 화면 초기화를 막지 않도록 비동기 FASTBOOT
- 섹터 예측은 실제 우위가 확인된 1~2개만 표시
- 기본 글씨/배치는 v1.5.3 그대로, 스크롤 중 읽는 상세문단만 1.5배 확대

뉴스앱은 Kiwoom API를 직접 호출하지 않습니다.
