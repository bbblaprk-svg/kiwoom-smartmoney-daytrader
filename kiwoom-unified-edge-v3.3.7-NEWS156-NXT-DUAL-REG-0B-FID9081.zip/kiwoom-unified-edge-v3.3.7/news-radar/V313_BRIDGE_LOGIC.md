# V3.1.x Read-Only Bridge · v1.3.8

뉴스앱은 Kiwoom API에 직접 로그인하거나 TR/WebSocket을 추가하지 않습니다. 연결된 스마트머니/단타 앱의 `/api/dashboard`를 읽기 전용으로 사용합니다.

기존 환경변수 `V313_BASE_URL`, `V313_ACCESS_TOKEN`은 호환 유지합니다. 새 이름 `SMARTMONEY_BASE_URL`, `SMARTMONEY_ACCESS_TOKEN`도 지원합니다.

재사용 값: 현재가, 등락률, 외국인 방향, 기관 방향, 프로그램 방향, 전일동시간 거래량비/RVOL, 체결강도, VWAP, KRX 일봉. 공유앱 관심종목을 뉴스앱이 추가/삭제하지 않으므로 원 API 트래픽을 늘리는 쓰기 동작은 없습니다.
