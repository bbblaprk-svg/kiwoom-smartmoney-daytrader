(() => {
  const state = { watchlist: [], macroTopics: [], news: [], themeBriefs: [], semiconductorBriefs: [], affectedStocks: [], foreignLeads: [], earlyEdges: [], secondOrderBriefs: [], secondOrderCandidates: [], marketPulse: null, usMarketDesk: null, nextUsSession: null, nextUsForecastStorage: null, nextUsForecastMirrorAt: 0, activeMonitor: [], activeMarket: null, sectorRotation: [], sectorForecast: null, sectorForecastStorage: null, sectorForecastMirrorAt: 0, investorInsights: null, calibration: null, calibrationStorage: null, calibrationMirrorAt: 0, universe: null, health: null, filter: 'earlyedge', eventSource: null, healthTimer: null, marketTimer: null, accessRefreshTimer: null, accessRefreshRetries: 0 };
  const CALIBRATION_MIRROR_KEY = 'krRadar.calibration.v136';
  const NEXT_US_MIRROR_KEY = 'krRadar.nextUsSession.v140';
  const SECTOR_FORECAST_MIRROR_KEY = 'krRadar.sectorForecast.v153';
  const $ = (id) => document.getElementById(id);
  const SOURCE_LABEL = { official: '공식원문', media: '언론사 직접피드', 'naver-public': '네이버 뉴스' };
  const REGION = { KR: '🇰🇷', US: '🇺🇸', CN: '🇨🇳', JP: '🇯🇵', TW: '🇹🇼', EU: '🇪🇺', GLOBAL: '🌐' };
  const SENTIMENT = {
    positive: { label: '호재 키워드', className: 'positive' }, negative: { label: '악재 키워드', className: 'negative' },
    mixed: { label: '혼재', className: 'mixed' }, neutral: { label: '중립', className: 'neutral' },
  };
  const IMPACT = { high: '영향 상', medium: '영향 중', low: '영향 하' };
  const IMPORTANCE = { critical: '긴급', high: '중요', medium: '관찰', low: '일반' };
  const SMART_LEVEL = { immediate: '즉시반응', high: '민감', watch: '관찰', low: '낮음', none: '비대상' };
  const DIRECTION = { positive: '상방', negative: '하방', mixed: '혼재', neutral: '중립' };
  const MODE_LABEL = { 'weekend-48h-active': '주말 48h 상시수집 · 접속시 즉시보강', 'us-session-fast': '미장 고속', 'kr-premarket-open-fast': '장전·장초 고속', 'kr-market-normal': '한국장 정상', 'aftermarket-low-duty': '저점유 대기' };

  async function api(path, options = {}) {
    const timeoutMs = Math.max(1500, Number(options.timeoutMs || 6500));
    const fetchOptions = { ...options };
    delete fetchOptions.timeoutMs;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(path, {
        credentials: 'same-origin',
        ...fetchOptions,
        signal: controller.signal,
        headers: { ...(fetchOptions.body ? { 'Content-Type': 'application/json' } : {}), ...(fetchOptions.headers || {}) },
      });
      const data = await response.json().catch(() => ({}));
      if (response.status === 401) showLogin();
      if (!response.ok) throw new Error(data.error || `요청 실패 (${response.status})`);
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('응답 지연 · 자동 재시도');
      throw error;
    } finally { clearTimeout(timer); }
  }

  function delayedStatus(id, message) {
    const el = $(id); if (!el) return;
    const value = String(el.textContent || '');
    if (/확인 중|작성 중|학습 중|계산 중|탐색 중|확장 탐색/.test(value) || value === '-' || value === '0/20') el.textContent = message;
  }

  function showLoading() {
    $('loadingView').classList.remove('hidden');
    $('loginView').classList.add('hidden');
    $('appView').classList.add('hidden');
  }

  function showLogin() {
    stopRealtime();
    $('loadingView').classList.add('hidden');
    $('appView').classList.add('hidden');
    $('loginView').classList.remove('hidden');
  }

  function showApp() {
    $('loadingView').classList.add('hidden');
    $('loginView').classList.add('hidden');
    $('appView').classList.remove('hidden');
  }

  function timeAgo(value) {
    if (!value) return '-';
    const time = new Date(value).getTime();
    if (!Number.isFinite(time)) return '-';
    const seconds = Math.max(0, Math.round((Date.now() - time) / 1000));
    if (seconds < 60) return `${seconds}초 전`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}분 전`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}시간 전`;
    return new Date(time).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  function text(tag, value, className) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    element.textContent = value;
    return element;
  }

  function sourceState(source) {
    if (!source || !source.configured) return { label: '미설정', className: 'muted' };
    if (source.running) return { label: '수집 중', className: 'working' };
    if (source.lastError) return { label: '오류 대기', className: 'error' };
    if (source.lastSuccessAt) return { label: '정상', className: 'ok' };
    return { label: '시작 대기', className: 'muted' };
  }

  function renderHealth() {
    const health = state.health;
    $('versionText').textContent = `ROTATION PICKS v${health?.version || '1.5.6'}`;
    $('readyText').textContent = health?.ready ? '정상' : '확인 필요';
    $('readyText').className = health?.ready ? 'ok' : 'error';
    $('watchCount').textContent = `${health?.inventory?.watchlist ?? state.watchlist.length}/${health?.inventory?.watchlistMax ?? 200}`;
    $('universeCount').textContent = `${health?.inventory?.autoUniverse ?? state.universe?.count ?? 200} + EXPAND ${health?.inventory?.expandOnly ?? state.universe?.expandOnlyCount ?? 0}`;
    $('cycleMinutes').textContent = MODE_LABEL[health?.poller?.mode] || health?.poller?.mode || '-';
    $('officialFeedCount').textContent = String(health?.poller?.settings?.newsFeedCount ?? health?.poller?.settings?.officialFeedCount ?? '-');
    $('apiKeyCount').textContent = '0개';
    $('importantCount').textContent = String(health?.news?.smartMoneyItems ?? '-');
    $('criticalCount').textContent = String(health?.news?.semiconductorAiItems ?? '-');

    const rows = $('sourceRows');
    rows.replaceChildren();
    const sources = health?.poller?.sources || {};
    ['official', 'naverPublic'].forEach((name) => {
      const row = document.createElement('div');
      const healthLabel = name === 'official' ? '공식·언론 직접피드' : name === 'naverPublic' ? '네이버 최근뉴스' : (SOURCE_LABEL[name] || name);
      row.append(text('span', healthLabel));
      const status = sourceState(sources[name]);
      row.append(text('b', status.label, status.className));
      rows.append(row);
    });
  }

  function fmtNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.round(n).toLocaleString('ko-KR') : '-';
  }

  function fmtPct(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return '-';
    return `${n > 0 ? '+' : ''}${n.toFixed(2)}%`;
  }

  function pctClass(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n === 0) return 'neutral';
    return n > 0 ? 'up' : 'down';
  }

  function managementClass(value) {
    const textValue = String(value || '');
    if (textValue.includes('금지') || textValue.includes('강등')) return 'managementStop';
    if (textValue.includes('진입') || textValue.includes('적극 추적')) return 'managementGo';
    return 'managementWatch';
  }

  const SECTOR_LABELS = { semicon:'반도체·AI HW', power:'AI전력·데이터센터', defense:'방산·조선·원전', robot:'로봇·자동차', battery:'2차전지·소재', bio:'바이오·헬스', consumer:'소비·뷰티·콘텐츠', finance:'금융·정책', industrial:'건설·산업재', other:'기타' };

  function diversifyNewsRows(rows, limit = 80) {
    const counts = {}; const selected = []; const skipped = [];
    const cap = (id) => id === 'semicon' ? 3 : id === 'other' ? 4 : 4;
    for (const row of rows || []) {
      const id = row.sectorId || 'other';
      if ((counts[id] || 0) < cap(id)) { selected.push(row); counts[id] = (counts[id] || 0) + 1; }
      else skipped.push(row);
      if (selected.length >= Math.min(limit, 30)) break;
    }
    // 첫 화면 30건을 분산하고 이후에는 원래 순서를 유지해 정보 자체를 버리지는 않는다.
    const seen = new Set(selected.map((x) => x.id || x.link));
    for (const row of rows || []) if (!seen.has(row.id || row.link)) selected.push(row);
    return selected.slice(0, limit);
  }

  function sectorReasonList(row) {
    const out = [];
    const add = (x) => { if (x && !out.includes(x)) out.push(x); };
    if (Number(row.relativeStrength || 0) >= 56 || Number(row.deltas?.relativeStrength || 0) >= 2) add('RS↑');
    if (Number(row.volumeMomentum || 0) >= 56 || Number(row.turnoverScore || 0) >= 56 || Number(row.turnoverShare || 0) >= 10) add('거래대금·거래량 유입');
    if (Number(row.flow || 0) >= 56) add('외인·기관/프로그램 수급↑');
    if (Number(row.breadth || 0) >= 56) add('Breadth 확산');
    if (Number(row.vwapBreadth || 0) >= 60) add('VWAP 상회 확산');
    if (Number(row.globalLead || 0) >= 60) {
      const map = {
        power:'미국 데이터센터·전력 CAPEX', robot:'미국·일본 자동화/로봇 선행', semicon:'SOX·미국/대만 반도체 선행',
        defense:'글로벌 방산·조선·원전 선행', battery:'글로벌 EV·배터리 선행', bio:'미국 바이오·헬스 선행',
        consumer:'미국·중국 소비/콘텐츠 선행', finance:'금리·정책·금융주 선행', industrial:'글로벌 인프라·산업재 선행'
      };
      add(map[row.id] || '해외 동종업종 선행');
    }
    if (Number(row.policyNews || 0) >= 64) add('정책·산업 촉매');
    (row.evidence || []).forEach((x) => {
      if (/상대강도/.test(x)) add('RS↑');
      else if (/거래량|거래대금/.test(x)) add('거래대금·거래량 유입');
      else if (/수급/.test(x)) add('외인·기관/프로그램 수급↑');
      else if (/확산/.test(x)) add('Breadth 확산');
      else if (/해외/.test(x)) add('해외 동종업종 선행');
      else if (/정책|뉴스/.test(x)) add('정책·산업 촉매');
    });
    if (!out.length) add('교차섹터 상대우위');
    return out.slice(0, 5);
  }

  function renderForecastStockLine(card, label, rows, order) {
    const line = document.createElement('div'); line.className = `rotationStockLine order-${order}`;
    line.append(text('strong', `${label}:`));
    const body = document.createElement('div'); body.className = 'rotationStockNames';
    const selected = (rows || []).filter((x) => Number(x.order || 1) === order).slice(0, 2);
    if (!selected.length) body.append(text('span', '관련종목 근거 확인 중', 'mutedStock'));
    selected.forEach((st) => {
      const chip = document.createElement('span'); chip.className = `rotationStockName ${st.relationOnly ? 'relationOnly' : ''}`;
      chip.textContent = st.name || '-';
      const tip = [];
      if (Number.isFinite(Number(st.probability))) tip.push(`종목확률 ${Number(st.probability).toFixed(0)}%`);
      if (st.relationOnly) tip.push('섹터 대표연관');
      if (!st.quoteConnected) tip.push('시세확인');
      if (tip.length) chip.title = tip.join(' · ');
      body.append(chip);
    });
    line.append(body); card.append(line);
  }

  function renderSectorForecast() {
    const data = state.sectorForecast;
    const grid = $('sectorForecastGrid');
    if (!grid) return;
    grid.replaceChildren();
    const stateEl = $('sectorForecastState');
    if (!data) {
      if (stateEl) stateEl.textContent = '순환패턴 계산 중';
      grid.append(text('div', 'ACTIVE20 시세·수급과 섹터 신호를 결합하는 중입니다.', 'emptyFeed'));
      return;
    }
    const picks = (data.recommendations || data.sectorsTop || []).slice(0, 2);
    if (stateEl) stateEl.textContent = `${data.learningPhase || '학습중'} · 선별 ${picks.length}/2 · 누적 ${data.historyDays || 0}일`;
    if (!picks.length) {
      const empty = document.createElement('div'); empty.className = 'rotationNoPick';
      empty.append(text('strong', '뚜렷한 예상 순환섹터 없음'));
      empty.append(text('p', '현재는 섹터 간 RS·거래대금·수급·Breadth 차이가 충분하지 않습니다. 50% 부근 섹터를 억지로 순위화하지 않습니다.'));
      grid.append(empty);
    }
    picks.forEach((row, idx) => {
      const card = document.createElement('article'); card.className = `rotationPickCard rank-${idx + 1} phase-${String(row.phase || 'WATCH').toLowerCase()}`;
      const rank = document.createElement('div'); rank.className = 'rotationRankLine';
      rank.append(text('span', `예상 순환 ${idx + 1}순위`));
      if (row.phaseLabel) rank.append(text('b', row.phaseLabel, `phaseBadge phase-${String(row.phase || 'WATCH').toLowerCase()}`));
      card.append(rank);

      const title = document.createElement('div'); title.className = 'rotationPickTitle';
      title.append(text('strong', `${row.icon || ''} ${row.label || row.id}`));
      const probs = document.createElement('div'); probs.className = 'rotationPickProb';
      probs.append(text('span', `3일 ${Number(row.next3Probability || 0).toFixed(0)}%`));
      probs.append(text('i', '/'));
      probs.append(text('span', `5일 ${Number(row.next5Probability || 0).toFixed(0)}%`));
      title.append(probs); card.append(title);

      renderForecastStockLine(card, '1차', row.stocks, 1);
      renderForecastStockLine(card, '2차', row.stocks, 2);

      const reasons = document.createElement('div'); reasons.className = 'rotationReasonLine';
      reasons.append(text('strong', '핵심근거:'));
      reasons.append(text('span', sectorReasonList(row).join(' · ')));
      card.append(reasons);

      const meta = document.createElement('div'); meta.className = 'rotationPickMeta';
      const hist = row.history3?.samples ? `과거유사 ${row.history3.samples}건` : `과거학습 ${data.historyDays || 0}/${data.minHistory || 15}일`;
      meta.append(text('span', `RS ${Number(row.relativeStrength || 0).toFixed(0)}`));
      meta.append(text('span', `Breadth ${Number(row.breadth || 0).toFixed(0)}`));
      meta.append(text('span', `수급 ${Number(row.flow || 0).toFixed(0)}`));
      meta.append(text('span', hist));
      card.append(meta);
      if (row.lowConfidence) card.append(text('small', '저신뢰 관찰: 2순위와 격차가 아직 작아 실제 시세·수급 확인이 필요합니다.', 'forecastWarning'));
      if (Number(row.outflowRisk || 0) >= 58) card.append(text('small', `자금이탈 위험 ${Number(row.outflowRisk).toFixed(0)}%`, 'forecastWarning'));
      grid.append(card);
    });
    if ($('sectorForecastNote')) $('sectorForecastNote').textContent = `${data.note || ''} · 1차/2차 종목은 섹터 연결근거이며 매수 신호가 아닙니다.`;
  }

  function renderSectorRotation() {
    const grid = $('sectorRotationGrid'); if (!grid) return;
    grid.replaceChildren();
    const rows = state.sectorRotation || [];
    const st = $('sectorRotationState');
    if (st) st.textContent = rows.length ? `최근 36h · ${rows.filter(x => x.storyCount > 0).length}개 섹터 경쟁` : '섹터 경쟁 계산 중';
    if (!rows.length) { grid.append(text('div','최근 뉴스에서 섹터 강도를 계산 중입니다.','emptyFeed')); return; }
    rows.forEach((row, idx) => {
      const card = document.createElement('article'); card.className = `sectorRotationCard sector-${row.trend || 'mixed'}`;
      const top = document.createElement('div'); top.className = 'sectorRotationTop';
      top.append(text('span', `${idx + 1}위`), text('b', `${row.icon || ''} ${row.label || SECTOR_LABELS[row.id] || row.id}`));
      top.append(text('strong', row.score ? `${row.score}` : '-', row.trend === 'positive' ? 'up' : row.trend === 'negative' ? 'down' : 'neutral'));
      card.append(top);
      card.append(text('p', `독립재료 ${row.storyCount || 0} · 출처 ${row.sourceCount || 0} · ACTIVE20 기본상한 ${row.softMax || '-'}${row.id === 'semicon' ? ' (강한 주도장 최대 7)' : ''}`));
      grid.append(card);
    });
  }

  function renderInvestorInsights() {
    const data = state.investorInsights; if (!data) return;
    const updated = $('investorInsightUpdated'); if (updated) updated.textContent = `갱신 ${timeAgo(data.updatedAt)}`;
    const pList = $('policyInsightList'); if (pList) {
      pList.replaceChildren();
      const rows = data.policy || [];
      if (!rows.length) pList.append(text('div','최근 정부·자본시장 정책 발표를 수집 중입니다.','emptySmall'));
      rows.slice(0,5).forEach((row) => {
        const a = document.createElement('a'); a.href = safeUrl(row.link); a.target = '_blank'; a.rel = 'noopener noreferrer'; a.className = 'policyInsightRow';
        a.append(text('strong', row.title || '-'), text('span', `${row.sourceLabel || '정부정책'} · ${timeAgo(row.publishedAt)}`), text('small', row.impact || '정책의 수요·세제·규제 효과를 확인하세요.'));
        pList.append(a);
      });
    }
    if ($('knowledgeTitle')) $('knowledgeTitle').textContent = data.knowledge?.title || '-';
    if ($('knowledgeBody')) $('knowledgeBody').textContent = data.knowledge?.body || '';
    if ($('postureTitle')) $('postureTitle').textContent = data.posture?.title || '-';
    if ($('postureBody')) $('postureBody').textContent = data.posture?.body || '';
    const chips = $('principleChips'); if (chips) { chips.replaceChildren(); (data.principles || []).forEach((v) => chips.append(text('span', v))); }
    const yt = data.youtube || {}; const ytGrid = $('youtubeInsightGrid');
    if (ytGrid) {
      ytGrid.replaceChildren();
      (yt.items || []).slice(0,3).forEach((row) => {
        const a = document.createElement('a'); a.href = safeUrl(row.url); a.target = '_blank'; a.rel = 'noopener noreferrer'; a.className = 'youtubeInsightCard';
        const meta = document.createElement('div'); meta.className = 'youtubeMeta'; meta.append(text('span', row.bucketLabel || '투자인사이트'), text('span', row.channel || 'YouTube'));
        a.append(meta, text('h3', row.title || '-'), text('p', row.summary || ''), text('small', `${row.published || '최근 영상'}${row.duration ? ` · ${row.duration}` : ''} · ${row.summaryBasis || '공개정보 기반 요약'}`));
        ytGrid.append(a);
      });
      if (!ytGrid.childNodes.length) ytGrid.append(text('div','유튜브 인사이트를 불러오는 중입니다.','emptyFeed'));
    }
    const ytState = $('youtubeInsightState'); if (ytState) ytState.textContent = yt.error ? '일부 영상 탐색 대체요약' : `3개 분야 · ${timeAgo(yt.updatedAt)}`;
  }

  function renderCalibration() {
    const summary = state.calibration || state.health?.calibration || null;
    const stats = $('calibrationStats');
    if (!stats) return;
    stats.replaceChildren();
    const phase = $('calibrationPhase');
    const total = Number(summary?.totalPredictions || 0);
    if (phase) {
      phase.textContent = summary?.label || '학습 준비';
      phase.className = summary?.phase === 'CALIBRATED' ? 'stockTag' : summary?.phase === 'CALIBRATING' || summary?.phase === 'EARLY_CALIBRATION' ? 'themeTag' : 'source';
    }
    const horizonCard = (h, label) => {
      const row = summary?.horizons?.[h] || summary?.horizons?.[String(h)] || {};
      const div = document.createElement('div'); div.className = 'calibrationStat';
      div.append(text('span', label));
      div.append(text('strong', row.hitRate === null || row.hitRate === undefined ? '-' : `${row.hitRate}%`));
      div.append(text('small', `표본 ${row.samples || 0} · 평균수익 ${row.avgReturnPct === null || row.avgReturnPct === undefined ? '-' : fmtPct(row.avgReturnPct)}`));
      return div;
    };
    stats.append(horizonCard(1, 'D+1 적중률'), horizonCard(2, 'D+2 적중률'), horizonCard(3, 'D+3 적중률'));
    const totalCard = document.createElement('div'); totalCard.className = 'calibrationStat';
    totalCard.append(text('span', '예측 누적'));
    totalCard.append(text('strong', `${total}/${summary?.targetSamples || 300}`));
    totalCard.append(text('small', `최소 보정 ${summary?.minSamples || 30}건`));
    stats.append(totalCard);
    const persistence = $('calibrationPersistence');
    if (persistence) {
      const storage = state.calibrationStorage || state.health?.calibration?.storage || {};
      persistence.textContent = storage.browserMirrorRecommended
        ? '무료 Render 임시저장 보완: 이 기기의 브라우저에 보정 기록 복구본을 자동 보관합니다. 서버 재시작 후 로그인하면 복원 후 공유앱 일봉으로 D+1~D+3를 재대조합니다.'
        : '서버 저장소에 보정 기록을 유지하며 브라우저 복구본도 함께 사용할 수 있습니다.';
    }
    const recent = $('calibrationRecent');
    if (recent) {
      recent.replaceChildren();
      const rows = summary?.recentResults || [];
      if (rows.length) {
        const table = document.createElement('table');
        const thead = document.createElement('thead');
        const hr = document.createElement('tr');
        ['최근 실제결과','진입','D+1','D+2','D+3'].forEach((v) => hr.append(text('th', v))); thead.append(hr); table.append(thead);
        const tbody = document.createElement('tbody');
        rows.slice(0,5).forEach((row) => {
          const tr = document.createElement('tr');
          tr.append(text('td', `${row.name || row.code} · 원모델 ${row.rawProbability}%`));
          tr.append(text('td', fmtNumber(row.entryPrice)));
          [row.d1,row.d2,row.d3].forEach((out) => tr.append(text('td', out ? `${out.returnPct > 0 ? '+' : ''}${Number(out.returnPct).toFixed(2)}%` : '-', out ? (out.hit ? 'hit' : 'miss') : '')));
          tbody.append(tr);
        });
        table.append(tbody); recent.append(table);
      }
    }
  }

  function renderActiveMonitor() {
    const body = $('activeMonitorBody');
    if (!body) return;
    body.replaceChildren();
    const rows = state.activeMonitor || [];
    const max = Number(state.health?.inventory?.activeMonitorMax || 20);
    $('activeCount').textContent = `${rows.length}/${max}`;
    const market = state.activeMarket || {};
    const marketOk = market.status === 'connected' || market.status === 'partial';
    const providerName = String(market.provider || '').startsWith('smartmoney') ? `${market.sourceApp || 'V3.2.16+'} 공유시세` : market.provider === 'legacy-bridge' ? '외부 시세브리지' : '시세';
    const marketLabel = marketOk ? `${providerName} 연결${market.updatedAt ? ` · ${timeAgo(market.updatedAt)}` : ''}` : market.status === 'error' ? `${providerName} 연결 오류` : String(market.provider || '').startsWith('smartmoney') ? '공유앱 연결 대기' : '시세연동 대기';
    $('marketFeedState').textContent = marketLabel;
    $('marketFeedState').className = marketOk ? 'stockTag' : market.status === 'error' ? 'macroTag' : 'source';
    const aggressive = rows.filter((row) => row.status === '적극시세').length;
    const watch = rows.filter((row) => row.status === '적극관찰').length;
    const connected = rows.filter((row) => row.quoteConnected).length;
    const summary = $('activeSummary');
    summary.replaceChildren();
    const probs = rows.map((row) => Number(row.calibratedProbability ?? row.upsideProbability)).filter(Number.isFinite);
    const topProb = probs.length ? Math.max(...probs) : null;
    const avgProb = probs.length ? Math.round(probs.reduce((a,b) => a+b, 0) / probs.length) : null;
    summary.append(text('span', `적극시세 ${aggressive}`), text('span', `적극관찰 ${watch}`), text('span', `${String(market.provider || '').startsWith('smartmoney') ? '공유시세' : '시세수신'} ${connected}/${rows.length || 0}`), text('span', `최고 보정확률 ${topProb === null ? '-' : `${topProb}%`}`), text('span', `평균 ${avgProb === null ? '-' : `${avgProb}%`}`));
    renderCalibration();
    if (!rows.length) {
      const tr = document.createElement('tr');
      const td = text('td', '현재 적극시세·적극관찰 기준을 통과한 AUTO200/EXPAND 후보를 계산 중입니다.', 'tableEmpty');
      td.colSpan = 14; tr.append(td); body.append(tr); return;
    }
    rows.forEach((row) => {
      const tr = document.createElement('tr');
      tr.append(text('td', String(row.rank || '-')));
      tr.append(text('td', row.status || '-', row.status === '적극시세' ? 'statusActive' : 'statusWatch'));
      const stock = document.createElement('td'); stock.className = 'stockCell';
      stock.append(text('strong', row.name || '-'), text('small', row.code || '코드 미등록'));
      if (row.sectorLabel) stock.append(text('span', row.sectorLabel, 'sectorTag'));
      if (row.sectorForecast) stock.append(text('span', `${row.sectorForecast.phaseLabel || '섹터'} · 3D ${Number(row.sectorForecast.next3Probability || 0).toFixed(0)}%`, 'sectorForecastTag'));
      if (row.universeScope === 'EXPAND') stock.append(text('span', 'EXPAND', 'expandTag'));
      tr.append(stock);
      tr.append(text('td', fmtNumber(row.currentPrice)));
      tr.append(text('td', fmtPct(row.changePct), pctClass(row.changePct)));
      tr.append(text('td', row.flowLabel || '수급 미수신'));
      const volumeCell = document.createElement('td');
      volumeCell.append(text('div', fmtPct(row.volumeIncreasePct), pctClass(row.volumeIncreasePct)));
      if (row.volumeBasis) volumeCell.append(text('small', row.volumeBasis, 'source'));
      tr.append(volumeCell);
      tr.append(text('td', row.prepositionScore === null || row.prepositionScore === undefined ? '-' : String(row.prepositionScore)));
      tr.append(text('td', row.pricedInScore === null || row.pricedInScore === undefined ? '-' : String(row.pricedInScore), Number(row.pricedInScore) >= 70 ? 'managementStop' : ''));
      tr.append(text('td', row.rawProbability === null || row.rawProbability === undefined ? (row.upsideProbability === undefined ? '-' : `${row.upsideProbability}%`) : `${row.rawProbability}%`, 'source'));
      const horizon = document.createElement('td'); horizon.className = 'calibrationProb';
      const d1 = row.calibratedByHorizon?.d1?.probability;
      const d2 = row.calibratedByHorizon?.d2?.probability;
      const d3 = row.calibratedByHorizon?.d3?.probability;
      horizon.append(text('strong', `${d1 ?? '-'} / ${d2 ?? '-'} / ${d3 ?? '-'}`));
      horizon.append(text('small', `표본 ${row.calibratedByHorizon?.d1?.samples || 0}/${row.calibratedByHorizon?.d2?.samples || 0}/${row.calibratedByHorizon?.d3?.samples || 0}`));
      tr.append(horizon);
      const prob = document.createElement('td');
      const displayed = row.calibratedProbability ?? row.upsideProbability;
      prob.append(text('strong', displayed === null || displayed === undefined ? '-' : `${displayed}%`, Number(displayed) >= 72 ? 'statusActive' : Number(displayed) >= 64 ? 'managementGo' : Number(displayed) < 48 ? 'managementStop' : ''));
      prob.append(text('small', row.calibrationLabel || row.probabilityLabel || '학습중', 'source'));
      tr.append(prob);
      const conf = document.createElement('td');
      conf.append(text('strong', row.probabilityConfidence === null || row.probabilityConfidence === undefined ? '-' : `${row.probabilityConfidence}`));
      conf.append(text('small', row.confidenceLabel || '-', 'source'));
      tr.append(conf);
      tr.append(text('td', row.management || '-', managementClass(row.management)));
      body.append(tr);
    });
  }

  function renderWatchlist() {
    const list = $('watchlist');
    list.replaceChildren();
    if (!state.watchlist.length) {
      list.append(text('div', '등록 종목이 없습니다.', 'emptySmall'));
      return;
    }
    state.watchlist.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'itemRow';
      const info = document.createElement('div');
      info.append(text('strong', item.name));
      const details = `${item.code || '코드 미등록'}${item.aliases?.length ? ` · ${item.aliases.join(', ')}` : ''}`;
      info.append(text('span', details));
      const button = text('button', '×');
      button.type = 'button';
      button.setAttribute('aria-label', `${item.name} 삭제`);
      button.addEventListener('click', async () => {
        try {
          await api('/api/watchlist', { method: 'DELETE', body: JSON.stringify({ id: item.id }) });
          await refreshAll();
        } catch (error) { $('stockError').textContent = error.message; }
      });
      row.append(info, button);
      list.append(row);
    });
  }

  function renderMacroTopics() {
    const list = $('macroTopics');
    list.replaceChildren();
    state.macroTopics.forEach((topic) => {
      const row = document.createElement('div');
      row.className = 'itemRow';
      const info = document.createElement('div');
      info.append(text('strong', `${REGION[topic.region] || '🌐'} ${topic.label}`));
      info.append(text('span', (topic.keywords || []).join(', ')));
      row.append(info);
      if (!topic.isDefault) {
        const button = text('button', '×');
        button.type = 'button';
        button.setAttribute('aria-label', `${topic.label} 삭제`);
        button.addEventListener('click', async () => {
          try {
            await api('/api/macro', { method: 'DELETE', body: JSON.stringify({ id: topic.id }) });
            await refreshAll();
          } catch (error) { $('macroError').textContent = error.message; }
        });
        row.append(button);
      }
      list.append(row);
    });
  }

  function safeUrl(value) {
    try {
      const url = new URL(value);
      return ['http:', 'https:'].includes(url.protocol) ? url.toString() : '#';
    } catch (_) { return '#'; }
  }

  function isWeekendView() {
    const weekday = Number(state.health?.poller?.koreaClock?.weekday);
    return weekday === 0 || weekday === 6;
  }

  function weekendViewHours() {
    return Math.max(12, Number(state.health?.poller?.settings?.weekendViewHours || 72));
  }

  function active(item, field, fallbackHours) {
    const stamp = new Date(item.publishedAt || item.ingestedAt || 0).getTime();
    if (isWeekendView()) {
      return Number.isFinite(stamp) && stamp >= Date.now() - weekendViewHours() * 3600000;
    }
    const until = new Date(item?.[field]?.activeUntil || 0).getTime();
    if (Number.isFinite(until) && until > 0) return until >= Date.now();
    return Number.isFinite(stamp) && stamp >= Date.now() - fallbackHours * 3600000;
  }

  function renderThemeBriefs() {
    const cards = $('newsCards');
    cards.replaceChildren();
    if (!state.themeBriefs.length) {
      cards.append(text('div', '최근 48시간 테마 뉴스를 수집·분류 중입니다. 새로고침 후 다시 확인하세요.', 'emptyFeed'));
      return;
    }
    const directionLabel = { positive: '상방', negative: '하방', mixed: '혼재' };
    state.themeBriefs.forEach((brief) => {
      const card = document.createElement('section');
      card.className = 'themeBriefCard';
      const top = document.createElement('div');
      top.className = 'themeBriefTop';
      const heading = document.createElement('div');
      heading.className = 'themeBriefHeading';
      heading.append(text('span', brief.icon || '📌', 'themeIcon'), text('h2', brief.label || '-'));
      const score = text('b', `${directionLabel[brief.direction] || '혼재'} ${brief.intensity || 0}`, `themeImpact direction-${brief.direction || 'mixed'}`);
      top.append(heading, score);
      card.append(top);
      card.append(text('p', brief.summary || '', 'themeSummary'));

      const chips = document.createElement('div');
      chips.className = 'themeChips';
      (brief.relatedStocks || []).slice(0, 6).forEach((name) => chips.append(text('span', name, 'stockTag')));
      (brief.sources || []).slice(0, 4).forEach((name) => chips.append(text('span', name, 'source')));
      chips.append(text('span', `${brief.count || 0}건`, 'macroTag'));
      card.append(chips);

      const list = document.createElement('div');
      list.className = 'themeHeadlines';
      (brief.headlines || []).slice(0, 3).forEach((item) => {
        const link = document.createElement('a');
        link.href = safeUrl(item.link);
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        const body = document.createElement('div');
        body.append(text('strong', item.title || '-'));
        body.append(text('span', `${item.sourceLabel || '-'} · ${timeAgo(item.publishedAt)} · 영향 ${item.score || 0}`));
        link.append(body, text('span', '›', 'themeArrow'));
        list.append(link);
      });
      card.append(list);
      cards.append(card);
    });
  }

  function renderSemiconductorBriefs() {
    const cards = $('newsCards');
    cards.replaceChildren();
    if (!state.semiconductorBriefs.length) {
      cards.append(text('div', '최근 48시간 반도체 밸류체인 뉴스를 세분화·분석 중입니다. 새로고침 후 다시 확인하세요.', 'emptyFeed'));
      return;
    }
    const directionLabel = { positive: '상방', negative: '하방', mixed: '혼재' };
    state.semiconductorBriefs.forEach((brief) => {
      const card = document.createElement('section');
      card.className = 'themeBriefCard semiconBriefCard';
      const top = document.createElement('div'); top.className = 'themeBriefTop';
      const heading = document.createElement('div'); heading.className = 'themeBriefHeading';
      heading.append(text('span', brief.icon || '🔬', 'themeIcon'), text('h2', brief.label || '-'));
      top.append(heading, text('b', `${directionLabel[brief.direction] || '혼재'} ${brief.intensity || 0}`, `themeImpact direction-${brief.direction || 'mixed'}`));
      card.append(top, text('p', brief.summary || '', 'themeSummary'));

      const candidates = document.createElement('div'); candidates.className = 'candidateList';
      (brief.candidates || []).filter((row) => row.grade !== 'C').slice(0, 5).forEach((row) => {
        const line = document.createElement('div'); line.className = 'candidateLine';
        line.append(text('b', row.grade, `grade grade-${row.grade}`));
        const body = document.createElement('div');
        body.append(text('strong', `${row.name} ${row.code ? `(${row.code})` : ''}`));
        body.append(text('span', `${row.role || ''} · ${row.action || ''}`));
        line.append(body, text('em', `${row.score || 0}`, `candidateScore direction-${row.direction || 'mixed'}`));
        candidates.append(line);
      });
      if (!candidates.childNodes.length) candidates.append(text('div', 'S/A/B 대응후보 없음', 'emptySmall'));
      card.append(candidates);

      const chips = document.createElement('div'); chips.className = 'themeChips';
      (brief.sources || []).slice(0, 4).forEach((name) => chips.append(text('span', name, 'source')));
      chips.append(text('span', `${brief.count || 0}건`, 'macroTag'));
      card.append(chips);
      const list = document.createElement('div'); list.className = 'themeHeadlines';
      (brief.headlines || []).slice(0, 3).forEach((item) => {
        const link = document.createElement('a'); link.href = safeUrl(item.link); link.target = '_blank'; link.rel = 'noopener noreferrer';
        const body = document.createElement('div'); body.append(text('strong', item.title || '-')); body.append(text('span', `${item.sourceLabel || '-'} · ${timeAgo(item.publishedAt)} · 적합도 ${item.score || 0}`));
        link.append(body, text('span', '›', 'themeArrow')); list.append(link);
      });
      card.append(list, text('p', brief.disclaimer || '', 'semiconDisclaimer'));
      cards.append(card);
    });
  }


  function renderEarlyEdges() {
    const cards = $('newsCards');
    cards.replaceChildren();
    if (!state.earlyEdges.length) {
      cards.append(text('div', '해외 1차정보에서 국내 기사 확산 전 수요·병목·CAPEX 연결고리를 찾고 있습니다. 직접근거가 약하거나 이미 대중화된 재료는 제외합니다.', 'emptyFeed'));
      return;
    }
    state.earlyEdges.forEach((brief) => {
      const card = document.createElement('section'); card.className = 'themeBriefCard foreignLeadCard';
      const top = document.createElement('div'); top.className = 'themeBriefTop';
      const heading = document.createElement('div'); heading.className = 'themeBriefHeading';
      heading.append(text('span', brief.antiChase ? '🛑' : '🎯', 'themeIcon'), text('h2', brief.title || '-'));
      const scorePair = document.createElement('div'); scorePair.className = 'scorePair';
      scorePair.append(text('b', `선취 ${brief.prepositionScore ?? 0}`, 'preScore'));
      scorePair.append(text('b', `선반영 ${brief.pricedInScore ?? 0}`, brief.antiChase ? 'pricedScore hot' : 'pricedScore'));
      top.append(heading, scorePair);
      card.append(top);
      const chips = document.createElement('div'); chips.className = 'themeChips';
      chips.append(text('span', brief.verdict || 'WATCH', brief.antiChase ? 'macroTag' : 'leadBadge'));
      chips.append(text('span', `EDGE ${brief.edgeScore || 0}`, 'stockTag'));
      chips.append(text('span', `격차 ${brief.scoreGap ?? 0}`, (brief.scoreGap ?? 0) >= 35 ? 'leadBadge' : 'macroTag'));
      chips.append(text('span', brief.lifecycle?.label || '-', brief.antiChase ? 'macroTag' : 'stockTag'));
      chips.append(text('span', brief.leadStatus || '국내보도 미확인', 'source'));
      card.append(chips);
      if ((brief.hiddenLinks || []).length) {
        const linkBox = document.createElement('div'); linkBox.className = 'smartReason';
        linkBox.append(text('b', '숨은 연결 '));
        linkBox.append(document.createTextNode((brief.hiddenLinks || []).join('  →  ')));
        card.append(linkBox);
      }
      const candidates = document.createElement('div'); candidates.className = 'candidateList';
      (brief.candidates || []).slice(0,3).forEach((row, idx) => {
        const line = document.createElement('div'); line.className = 'candidateLine';
        line.append(text('b', row.grade || 'B', `grade grade-${row.grade || 'B'}`));
        const body = document.createElement('div');
        body.append(text('strong', `${idx + 1}. ${row.name}${row.code ? ` (${row.code})` : ''}`));
        body.append(text('span', `${row.action || '관찰'} · ${(row.reasons || []).join(' · ')}`));
        const scores = document.createElement('div'); scores.className = 'candidateDual';
        scores.append(text('em', `선취 ${row.prepositionScore ?? row.score ?? 0}`, `candidateScore direction-${brief.direction || 'mixed'}`));
        scores.append(text('small', `반영 ${row.pricedInScore ?? 0}`, (row.pricedInScore ?? 0) >= 70 ? 'pricedHot' : ''));
        line.append(body, scores);
        candidates.append(line);
      });
      card.append(candidates);
      card.append(text('p', `해외교차 ${brief.lifecycle?.foreignConfirmCount || 0} · 국내확산 ${brief.lifecycle?.domesticCount || 0} · ${brief.pricingBasis || '뉴스확산 추정'} · ${brief.note || ''}`, 'semiconDisclaimer'));
      const a = document.createElement('a'); a.className='foreignOriginalLink'; a.href=safeUrl(brief.link); a.target='_blank'; a.rel='noopener noreferrer'; a.textContent='선행 원문/기사 열기 ›';
      card.append(a); cards.append(card);
    });
  }

  function renderForeignLeads() {
    const cards = $('newsCards');
    cards.replaceChildren();
    if (!state.foreignLeads.length) {
      cards.append(text('div', '최근 48시간 해외 원문·국제뉴스에서 한국장 직접 연관 TOP3 후보를 찾고 있습니다. 국내뉴스는 선행시간 확인용으로만 사용합니다.', 'emptyFeed'));
      return;
    }
    const dir = { positive: '상방', negative: '하방', mixed: '혼재', neutral: '중립' };
    state.foreignLeads.forEach((brief) => {
      const card = document.createElement('section'); card.className = 'themeBriefCard foreignLeadCard';
      const top = document.createElement('div'); top.className = 'themeBriefTop';
      const heading = document.createElement('div'); heading.className = 'themeBriefHeading';
      heading.append(text('span', brief.officialDirect ? '⚡' : '🌐', 'themeIcon'), text('h2', brief.title || '-'));
      top.append(heading, text('b', `신선도 ${brief.discoveryScore || 0}`, `themeImpact direction-${brief.direction || 'mixed'}`));
      card.append(top);
      const meta = document.createElement('div'); meta.className = 'themeChips';
      meta.append(text('span', brief.sourceLabel || '해외뉴스', brief.officialDirect ? 'source officialSource' : 'source'));
      meta.append(text('span', brief.leadStatus || '선행시간 확인 중', brief.leadMinutes === null || brief.leadMinutes > 0 ? 'leadBadge' : 'macroTag'));
      (brief.entities || []).slice(0,3).forEach(v => meta.append(text('span', v, 'stockTag')));
      meta.append(text('span', timeAgo(brief.publishedAt), 'macroTag'));
      card.append(meta);
      if (brief.description) card.append(text('p', brief.description, 'themeSummary'));

      const candidates = document.createElement('div'); candidates.className = 'candidateList';
      (brief.candidates || []).slice(0,3).forEach((row, idx) => {
        const line = document.createElement('div'); line.className = 'candidateLine';
        line.append(text('b', row.grade, `grade grade-${row.grade}`));
        const body = document.createElement('div');
        body.append(text('strong', `${idx + 1}. ${row.name}${row.code ? ` (${row.code})` : ''}`));
        body.append(text('span', (row.reasons || []).join(' · ') || (row.roles || []).join(' · ')));
        line.append(body, text('em', `${row.score || 0}`, `candidateScore direction-${brief.direction || 'mixed'}`));
        candidates.append(line);
      });
      card.append(candidates);

      if (brief.domesticSources?.length) {
        card.append(text('p', `국내 확인: ${brief.domesticSources.join(' · ')}${brief.domesticFirstAt ? ` · ${timeAgo(brief.domesticFirstAt)}` : ''}`, 'semiconDisclaimer'));
      } else {
        card.append(text('p', '국내 신뢰매체 재보도 미확인 — 조기발굴 구간', 'semiconDisclaimer'));
      }
      const link = document.createElement('a'); link.className = 'foreignOriginalLink'; link.href = safeUrl(brief.link); link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '해외 원문/기사 열기 ›';
      card.append(link, text('p', brief.rationale || '', 'semiconDisclaimer'));
      cards.append(card);
    });
  }

  function renderMarketPulse() {
    const pulse = state.marketPulse || {};
    const strip = $('globalIndexStrip');
    if (!strip) return;
    strip.replaceChildren();
    const status = pulse.status || 'idle';
    const statusEl = $('marketPulseState');
    if (statusEl) {
      statusEl.textContent = status === 'connected' ? `공개시세 수신 · ${timeAgo(pulse.updatedAt)}` : status === 'partial' ? '일부 지수 수신' : status === 'error' ? '공개시세 수신 지연' : '시장시세 확인 중';
      statusEl.className = status === 'connected' ? 'stockTag' : status === 'partial' ? 'themeTag' : status === 'error' ? 'macroTag' : 'source';
    }
    const order = ['kospi','kosdaq','nasdaq','sp500','dow','sox','vix','us10y','usdkrw','usdjpy','usdcny','wti','nikkei','shanghai','hangseng','twii','stoxx50'];
    const byId = new Map((pulse.items || []).map((row) => [row.id, row]));
    order.forEach((id) => {
      const row = byId.get(id); if (!row) return;
      const card = document.createElement('div'); card.className = 'indexCard';
      card.append(text('span', row.label || id));
      card.append(text('strong', row.price === null || row.price === undefined ? '-' : Number(row.price).toLocaleString('ko-KR', { maximumFractionDigits: 2 })));
      card.append(text('em', row.changePct === null || row.changePct === undefined ? '미수신' : fmtPct(row.changePct), pctClass(row.changePct)));
      strip.append(card);
    });
    if (!strip.childNodes.length) strip.append(text('div', '공개 지수시세를 확인 중입니다. 뉴스 분석은 계속 동작합니다.', 'emptySmall'));
  }

  function usMoveValue(row, sessionId) {
    if (!row) return null;
    if (sessionId === 'pre' && row.prePct !== null && row.prePct !== undefined) return Number(row.prePct);
    if (sessionId === 'after' && row.postPct !== null && row.postPct !== undefined) return Number(row.postPct);
    if (row.regularPct !== null && row.regularPct !== undefined) return Number(row.regularPct);
    return null;
  }

  function renderImpactList(id, rows, depth) {
    const box = $(id); if (!box) return;
    box.replaceChildren();
    (rows || []).forEach((row, idx) => {
      const line = document.createElement('div'); line.className = 'usImpactRow';
      const rank = text('b', String(idx + 1), depth === 1 ? 'firstRank' : 'secondRank');
      const body = document.createElement('div'); body.className = 'usImpactBody';
      const title = document.createElement('div'); title.className = 'usImpactTitle';
      title.append(text('strong', `${row.name}${row.code ? ` · ${row.code}` : ''}`));
      title.append(text('span', row.universeScope === 'EXPAND' ? 'EXPAND' : 'AUTO200', row.universeScope === 'EXPAND' ? 'expandTag' : 'stockTag'));
      body.append(title, text('small', (row.reasons || [row.reason]).filter(Boolean).slice(0,2).join(' · ') || '미국장 영향경로'));
      line.append(rank, body, text('em', String(Math.round(Number(row.score || 0))), `candidateScore direction-${row.direction === 'negative' ? 'negative' : row.direction === 'mixed' ? 'mixed' : 'positive'}`));
      box.append(line);
    });
    if (!box.childNodes.length) box.append(text('div', '현재 세션에서 확신도 높은 국내 영향 후보를 계산 중입니다.', 'emptySmall'));
  }

  function renderNextUsSession() {
    const fc = state.nextUsSession || {};
    const probs = fc.calibratedProbabilities || fc.rawProbabilities || {};
    const target = fc.target || {};
    const dominant = fc.dominantLabel || '-';
    const domKey = fc.dominant || 'NEUTRAL';
    const domProb = Number(probs[domKey]);
    if ($('nextUsHeadline')) $('nextUsHeadline').textContent = fc.updatedAt ? `${target.stageLabel || '다음 세션 전망'} · ${dominant} ${Number.isFinite(domProb) ? domProb.toFixed(1) + '%' : '-'} · 뉴스클러스터 ${(fc.newsClusters || []).length}개 · 국내 1차 ${(fc.firstOrder || []).length} / 2차 ${(fc.secondOrder || []).length}` : '여러 뉴스와 시장 흐름을 종합해 다음 미국 정규장을 추론 중입니다.';
    if ($('nextUsTarget')) $('nextUsTarget').textContent = target.targetDate ? `${target.targetDate} ET` : '목표일 확인 중';
    if ($('nextUsPhase')) $('nextUsPhase').textContent = fc.calibration?.label || fc.history?.label || '학습 준비';
    if ($('nextProbUp')) $('nextProbUp').textContent = Number.isFinite(Number(probs.UP)) ? `${Number(probs.UP).toFixed(1)}%` : '-';
    if ($('nextProbNeutral')) $('nextProbNeutral').textContent = Number.isFinite(Number(probs.NEUTRAL)) ? `${Number(probs.NEUTRAL).toFixed(1)}%` : '-';
    if ($('nextProbDown')) $('nextProbDown').textContent = Number.isFinite(Number(probs.DOWN)) ? `${Number(probs.DOWN).toFixed(1)}%` : '-';
    if ($('nextUsConfidence')) $('nextUsConfidence').textContent = Number.isFinite(Number(fc.confidence)) ? `${Math.round(Number(fc.confidence))}/100` : '-';
    if ($('nextUsStage')) $('nextUsStage').textContent = `${target.stageLabel || '단계 확인 중'}${Number.isFinite(Number(fc.rawScore)) ? ` · 방향점수 ${Number(fc.rawScore).toFixed(1)}` : ''}`;
    if ($('nextUsNarrative')) $('nextUsNarrative').textContent = fc.summary || '익일 미국장 전망을 작성 중입니다.';
    if ($('nextSummaryChars')) $('nextSummaryChars').textContent = fc.summaryChars ? `${Number(fc.summaryChars).toLocaleString('ko-KR')}자` : '-';

    const regionBox = $('nextRegionStrip');
    if (regionBox) {
      regionBox.replaceChildren();
      const regionOrder = ['US','CN','JP','TW','EU','GLOBAL'];
      const rows = new Map((fc.regionalIntelligence || []).map((row) => [row.id, row]));
      regionOrder.forEach((id) => {
        const row = rows.get(id); if (!row) return;
        const card = document.createElement('article'); card.className = `nextRegionCard region-${String(row.direction || 'mixed')}`;
        card.append(text('span', `${row.emoji || '🌐'} ${row.label || id}`));
        card.append(text('strong', `${Number(row.score || 0) > 0 ? '+' : ''}${Number(row.score || 0)}`, row.direction === 'positive' ? 'up' : row.direction === 'negative' ? 'down' : 'neutral'));
        const headline = row.headlines?.[0]?.title || '독립 헤드라인 확인 중';
        card.append(text('small', `${row.sourceCount || 0}개 출처 · ${headline}`));
        regionBox.append(card);
      });
      if (!regionBox.childNodes.length) regionBox.append(text('small', '국제뉴스 지역별 선행판을 계산 중입니다.', 'emptySmall'));
    }

    const factors = $('nextFactorList');
    if (factors) {
      factors.replaceChildren();
      (fc.components || []).forEach((row) => {
        const line = document.createElement('div'); line.className = 'nextFactorRow';
        const left = document.createElement('div'); left.append(text('strong', `${row.label} · ${(Number(row.weight || 0) * 100).toFixed(0)}%`), text('small', row.note || '-'));
        line.append(left, text('b', `${Number(row.score || 0) > 0 ? '+' : ''}${Number(row.score || 0).toFixed(1)}`, Number(row.score || 0) > 10 ? 'up' : Number(row.score || 0) < -10 ? 'down' : 'neutral'));
        factors.append(line);
      });
      if (!factors.childNodes.length) factors.append(text('small', '6축 판단을 계산 중입니다.', 'emptySmall'));
    }
    const fillBullets = (id, rows) => {
      const box = $(id); if (!box) return; box.replaceChildren();
      (rows || []).forEach((v) => box.append(text('div', `• ${v}`)));
      if (!box.childNodes.length) box.append(text('div', '• 확인 중'));
    };
    fillBullets('nextRiskList', fc.risks || []);
    fillBullets('nextCheckList', fc.openChecks || []);
    const sectors = $('nextSectorList');
    if (sectors) {
      sectors.replaceChildren();
      (fc.sectorOutlook || []).forEach((row) => {
        const line = document.createElement('div'); line.className = 'sectorCompactRow';
        line.append(text('span', row.name), text('b', `${Number(row.score || 0) > 0 ? '+' : ''}${Number(row.score || 0).toFixed(1)}`, row.direction === 'positive' ? 'up' : row.direction === 'negative' ? 'down' : 'neutral'));
        line.append(text('small', row.reason || '-'));
        sectors.append(line);
      });
      if (!sectors.childNodes.length) sectors.append(text('small', '섹터 전망 계산 중', 'emptySmall'));
    }
    renderImpactList('nextFirstOrder', fc.firstOrder || [], 1);
    renderImpactList('nextSecondOrder', fc.secondOrder || [], 2);
    const h = fc.history || {};
    if ($('nextUsHistory')) $('nextUsHistory').textContent = `미국장 예측 ${h.totalForecasts || 0}회 · 평가 ${h.evaluated || 0}회 · 방향적중 ${h.hitRate ?? '-'}% · Brier ${h.avgBrier ?? '-'}`;
  }

  function renderUsMarketDesk() {
    const desk = state.usMarketDesk || {};
    const session = desk.session || {};
    if ($('usDeskSession')) $('usDeskSession').textContent = session.label ? `${session.label} · ET ${session.etTime || '-'}` : '세션 확인 중';
    if ($('usDeskState')) {
      $('usDeskState').textContent = desk.status === 'connected' ? `미국 확장시세 수신 · ${timeAgo(desk.updatedAt)}` : desk.status === 'partial' ? '일부 시세 수신' : desk.status === 'error' ? '시세 지연' : '시세 확인 중';
      $('usDeskState').className = desk.status === 'connected' ? 'stockTag' : desk.status === 'partial' ? 'themeTag' : 'source';
    }
    const pulse = state.marketPulse?.analysis || {};
    if ($('usDeskHeadline')) $('usDeskHeadline').textContent = `${session.label || '미국장'} · ${pulse.regime || 'MIXED'}${Number.isFinite(Number(pulse.riskScore)) ? ` ${pulse.riskScore}/100` : ''} · 국내 1차 ${(desk.firstOrder || []).length} · 2차 ${(desk.secondOrder || []).length}`;
    if ($('usDeskNarrative')) $('usDeskNarrative').textContent = desk.summary || '미국 프리·정규·애프터 흐름과 국내 영향경로를 분석 중입니다.';
    if ($('usSummaryChars')) $('usSummaryChars').textContent = desk.summaryChars ? `${Number(desk.summaryChars).toLocaleString('ko-KR')}자` : '-';

    const sessionBox = $('usSessionStrip');
    if (sessionBox) {
      sessionBox.replaceChildren();
      const labels = { pre:'프리마켓', regular:'정규장', after:'애프터마켓' };
      ['pre','regular','after'].forEach((id) => {
        const snap = desk.sessions?.[id] || {};
        const card = document.createElement('div'); card.className = `usSessionCard ${session.id === id ? 'currentSession' : ''}`;
        card.append(text('span', labels[id]));
        card.append(text('strong', snap.averagePct === null || snap.averagePct === undefined ? '확인중' : fmtPct(snap.averagePct), pctClass(snap.averagePct)));
        card.append(text('small', `상승 ${snap.up || 0} · 하락 ${snap.down || 0} · 수신 ${snap.available || 0}`));
        sessionBox.append(card);
      });
    }

    const leaderBox = $('usLeaderMoves');
    if (leaderBox) {
      leaderBox.replaceChildren();
      const sid = session.id || 'regular';
      const rows = (desk.assets || []).filter((row) => ['nvda','amd','avgo','mu','msft','googl','amzn','meta','tsla'].includes(row.id)).map((row) => ({...row, move:usMoveValue(row,sid)})).filter((row)=>Number.isFinite(row.move)).sort((a,b)=>Math.abs(b.move)-Math.abs(a.move)).slice(0,8);
      rows.forEach((row) => { const line=document.createElement('div'); line.className='leaderMove'; line.append(text('span',row.label),text('b',fmtPct(row.move),pctClass(row.move))); leaderBox.append(line); });
      if (!leaderBox.childNodes.length) leaderBox.append(text('small','미국 대형주 확장시세 수신 중','emptySmall'));
    }
    const themeBox = $('usNewsThemes');
    if (themeBox) {
      themeBox.replaceChildren();
      (desk.themes || []).slice(0,5).forEach((row)=>themeBox.append(text('span',`${row.label} · ${row.hits}`,'themeTag')));
      if (!themeBox.childNodes.length) themeBox.append(text('small','해외뉴스 테마 집중도 계산 중','emptySmall'));
    }
    renderImpactList('usFirstOrder', desk.firstOrder || [], 1);
    renderImpactList('usSecondOrder', desk.secondOrder || [], 2);
  }

  function renderSecondOrder(psychologyOnly = false) {
    const cards = $('newsCards');
    cards.replaceChildren();
    let briefs = state.secondOrderBriefs || [];
    if (psychologyOnly) briefs = briefs.filter((brief) => brief?.psychology?.regime !== '중립' || brief?.future?.futureArticle);
    else briefs = briefs.filter((brief) => (brief.candidates || []).some((row) => ['SECOND_ORDER','DIRECT_MEDIA'].includes(row.relationType)));
    if (!briefs.length) {
      cards.append(text('div', psychologyOnly ? '투자심리·미래 성장/우려 기사를 분석 중입니다. 종목명이 없어도 구조적 수요와 위험 신호는 여기에 표시됩니다.' : '주요 매체 직접언급과 2차 수혜 경로를 확장 탐색 중입니다. 직접 종목명이 없어도 병목·장비·소모품·전력·냉각 경로를 추론합니다.', 'emptyFeed'));
      return;
    }
    briefs.slice(0, 30).forEach((brief) => {
      const card = document.createElement('section'); card.className = 'themeBriefCard secondOrderCard';
      const top = document.createElement('div'); top.className = 'themeBriefTop';
      const heading = document.createElement('div'); heading.className = 'themeBriefHeading';
      heading.append(text('span', psychologyOnly ? '🧠' : '↳', 'themeIcon'), text('h2', brief.title || '-'));
      const best = Math.max(0, ...(brief.candidates || []).map((row) => Number(row.score || 0)));
      top.append(heading, text('b', psychologyOnly ? `성장 ${brief.future?.growthScore ?? '-'} / 우려 ${brief.future?.concernScore ?? '-'}` : `연결 ${best}`, best >= 78 ? 'themeImpact direction-positive' : 'themeImpact direction-mixed'));
      card.append(top);
      const meta = document.createElement('div'); meta.className = 'themeChips';
      meta.append(text('span', brief.sourceLabel || '-', 'source'));
      meta.append(text('span', brief.timeReliable === false ? '시각 신뢰 낮음' : timeAgo(brief.publishedAt || brief.ingestedAt), brief.timeReliable === false ? 'macroTag' : 'source'));
      if (brief.pathLabel) meta.append(text('span', brief.pathLabel, 'stockTag'));
      if (brief.psychology?.regime && brief.psychology.regime !== '중립') meta.append(text('span', `심리 ${brief.psychology.regime}`, 'themeTag'));
      if (brief.future?.futureArticle) meta.append(text('span', `미래 성장 ${brief.future.growthScore} · 우려 ${brief.future.concernScore}`, brief.future.concernScore >= 65 ? 'macroTag' : 'leadBadge'));
      card.append(meta);
      card.append(text('p', brief.thesis || '직접 언급보다 한 단계 뒤의 실적 연결경로를 확인합니다.', 'themeSummary'));
      if ((brief.mediaMentions || []).length) card.append(text('p', `주요매체 직접 언급: ${(brief.mediaMentions || []).map((x) => x.name).join(' · ')}`, 'directMentionLine'));
      const candidates = document.createElement('div'); candidates.className = 'candidateList';
      (brief.candidates || []).slice(0,5).forEach((row, idx) => {
        const line = document.createElement('div'); line.className = 'candidateLine';
        line.append(text('b', row.relationType === 'SECOND_ORDER' ? '2차' : '직접', row.relationType === 'SECOND_ORDER' ? 'grade grade-A' : 'grade grade-B'));
        const body = document.createElement('div');
        body.append(text('strong', `${idx + 1}. ${row.name}${row.code ? ` (${row.code})` : ''}`));
        body.append(text('span', `${row.reason || ''}${row.pathLabel ? ` · ${row.pathLabel}` : ''}`));
        line.append(body, text('em', String(row.score || 0), 'candidateScore direction-positive'));
        candidates.append(line);
      });
      if (!candidates.childNodes.length && psychologyOnly) candidates.append(text('div', '이 기사는 종목 직접선정보다 시장심리/장기 가설 판단용입니다.', 'emptySmall'));
      card.append(candidates);
      const link = document.createElement('a'); link.className = 'foreignOriginalLink'; link.href = safeUrl(brief.link); link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '기사 열기 ›';
      card.append(link); cards.append(card);
    });
  }

  function renderAffectedStocks() {
    const cards = $('newsCards');
    cards.replaceChildren();
    if (!state.affectedStocks.length) {
      cards.append(text('div', '최근 48시간 뉴스와 자동 200종목 유니버스를 비교하고 있습니다. 뉴스가 들어오면 영향종목 TOP이 자동 생성됩니다.', 'emptyFeed'));
      return;
    }
    const dir = { positive: '상방', negative: '하방', mixed: '혼재' };
    state.affectedStocks.forEach((row) => {
      const card = document.createElement('section');
      card.className = 'themeBriefCard';
      const top = document.createElement('div'); top.className = 'themeBriefTop';
      const heading = document.createElement('div'); heading.className = 'themeBriefHeading';
      heading.append(text('span', row.grade || 'B', `grade grade-${row.grade || 'B'}`), text('h2', `${row.name}${row.code ? ` · ${row.code}` : ''}`));
      top.append(heading, text('b', `${dir[row.direction] || '혼재'} ${row.score || 0}`, `themeImpact direction-${row.direction || 'mixed'}`));
      card.append(top);
      const freshLabel = row.discoveryState === 'REIGNITED' ? '재점화' : row.discoveryState === 'NEW' ? '신규발굴' : row.discoveryState === 'SECOND_ORDER' ? '2차수혜' : row.discoveryState === 'MEDIA_DIRECT' ? '주요매체 언급' : '지속관찰';
      card.append(text('p', `${freshLabel} · ${row.action || '관찰'} · ${(row.roles || []).join(' · ') || '뉴스 연관종목'} · 교차확인 ${row.sourceCount || 0}개 매체`, 'themeSummary'));
      const chips = document.createElement('div'); chips.className = 'themeChips';
      chips.append(text('span', freshLabel, row.discoveryState === 'PERSISTENT' ? 'source' : row.discoveryState === 'SECOND_ORDER' ? 'themeTag' : 'stockTag'));
      if (Number.isFinite(Number(row.catalystAgeHours))) chips.append(text('span', `재료 최초 ${Number(row.catalystAgeHours).toFixed(1)}h`, 'source'));
      if (Number(row.duplicateSuppressed || 0) > 0) chips.append(text('span', `유사기사 ${row.duplicateSuppressed}건 점수중복 제외`, 'source'));
      (row.reasons || []).forEach((v) => chips.append(text('span', v, 'stockTag')));
      (row.sources || []).forEach((v) => chips.append(text('span', v, 'source')));
      card.append(chips);
      const list = document.createElement('div'); list.className = 'themeHeadlines';
      (row.headlines || []).slice(0,3).forEach((item) => {
        const link = document.createElement('a'); link.href = safeUrl(item.link); link.target = '_blank'; link.rel = 'noopener noreferrer';
        const body = document.createElement('div'); body.append(text('strong', item.title || '-')); body.append(text('span', `${item.sourceLabel || '-'} · ${timeAgo(item.publishedAt)} · 종목연관 ${item.score || 0}`));
        link.append(body, text('span','›','themeArrow')); list.append(link);
      });
      card.append(list); cards.append(card);
    });
  }
  function renderNews() {
    if (state.filter === 'earlyedge') return renderEarlyEdges();
    if (state.filter === 'foreignlead') return renderForeignLeads();
    if (state.filter === 'affected') return renderAffectedStocks();
    if (state.filter === 'secondorder') return renderSecondOrder(false);
    if (state.filter === 'psychology') return renderSecondOrder(true);
    if (state.filter === 'themes') return renderThemeBriefs();
    if (state.filter === 'semiconchain') return renderSemiconductorBriefs();
    const cards = $('newsCards');
    cards.replaceChildren();
    const stamp = (item) => new Date(item.publishedAt || item.ingestedAt || 0).getTime() || 0;
    let visible = state.news.filter((item) => {
      if (state.filter === 'smart') return item.marketImpact?.isSmartMoney && item.quality?.realtimeEligible !== false && stamp(item) >= Date.now() - 6 * 3600000;
      if (state.filter === 'semiai') return item.marketImpact?.isSemiconductorAI && item.quality?.realtimeEligible !== false && stamp(item) >= Date.now() - 6 * 3600000;
      if (state.filter === 'important') return item.importance?.isImportant && item.quality?.realtimeEligible !== false && stamp(item) >= Date.now() - 6 * 3600000;
      if (state.filter === 'stock') return item.matched?.length || item.relatedStocks?.length || item.marketImpact?.koreaImpacts?.length;
      if (state.filter === 'macro') return item.macroMatched?.length;
      if (state.filter === 'policy') return /policy-index$/.test(String(item.sourceId || '')) || /기획재정부|금융위원회|산업통상자원부|중소벤처기업부|국토교통부|정책브리핑/.test(String(item.sourceLabel || ''));
      return true;
    }).sort((a, b) => {
      if (['smart', 'semiai'].includes(state.filter)) {
        const rank = (item) => Number(item.marketImpact?.smartMoneyScore || 0)
          + Number(item.marketImpact?.koreaImpactScore || 0) * 0.25
          + (item.officialDirect ? 8 : 0)
          + Math.max(0, 24 - Math.max(0, Date.now() - stamp(item)) / 1200000);
        return rank(b) - rank(a) || stamp(b) - stamp(a);
      }
      if (state.filter === 'important') {
        const rank = (item) => Number(item.importance?.score || 0) + Math.max(0, 16 - Math.max(0, Date.now() - stamp(item)) / 2400000);
        return rank(b) - rank(a) || stamp(b) - stamp(a);
      }
      return stamp(b) - stamp(a);
    });

    if (['all','important','smart','stock'].includes(state.filter)) visible = diversifyNewsRows(visible, 100);

    if (!visible.length) {
      const message = state.filter === 'smart'
        ? '최근 6시간 안에 스마트머니 기준을 통과한 뉴스를 수집·분석 중입니다.'
        : state.filter === 'semiai'
          ? '최근 6시간 안에 반도체·AI 국내 주도주 영향 뉴스를 수집·분석 중입니다.'
          : state.filter === 'important'
            ? '최근 6시간 안에 중요도 기준을 통과한 핵심뉴스를 수집·분석 중입니다.'
            : '최근 24시간 안에 표시할 뉴스가 없습니다. 수집 상태를 확인하세요.';
      cards.append(text('div', message, 'emptyFeed'));
      return;
    }

    visible.forEach((item) => {
      const card = document.createElement('a');
      card.className = 'card';
      card.href = safeUrl(item.link);
      card.target = '_blank';
      card.rel = 'noopener noreferrer';
      const meta = document.createElement('div');
      meta.className = 'cardMeta';
      meta.append(text('span', item.sourceLabel || SOURCE_LABEL[item.source] || item.source || '-', `source${item.officialDirect ? ' officialSource' : ''}`));
      if (item.sectorId) meta.append(text('span', SECTOR_LABELS[item.sectorId] || item.sectorId, 'sectorTag'));

      const smart = item.marketImpact || {};
      if (smart.relevant) {
        meta.append(text('span', `${SMART_LEVEL[smart.level] || '관찰'} ${smart.smartMoneyScore || 0}점`, `smart smart-${smart.level || 'low'}`));
        meta.append(text('span', `한국장 ${smart.koreaImpactScore || 0}`, `koreaImpact direction-${smart.direction || 'mixed'}`));
        if (smart.officialLead) meta.append(text('span', '원문 조기포착', 'leadBadge'));
      } else {
        const importance = item.importance || { score: 0, level: 'low' };
        meta.append(text('span', `${IMPORTANCE[importance.level] || '일반'} ${importance.score || 0}점`, `importance importance-${importance.level || 'low'}`));
      }
      (item.matched || []).slice(0, 3).forEach((match) => meta.append(text('span', match.name, 'stockTag')));
      if (!(item.matched || []).length) (item.relatedStocks || []).slice(0, 3).forEach((match) => meta.append(text('span', `연관 ${match.name}`, 'stockTag')));
      if (item.quality?.archiveOnly) meta.append(text('span', '6시간+ 보조자료', 'macroTag'));
      (item.macroMatched || []).slice(0, 2).forEach((match) => meta.append(text('span', `${REGION[match.region] || '🌐'} ${match.label}`, 'macroTag')));
      const sentiment = SENTIMENT[item.sentiment?.label] || SENTIMENT.neutral;
      meta.append(text('span', sentiment.label, `sentiment ${sentiment.className}`));
      meta.append(text('time', item.source === 'naver-public' && item.publishedTimeReliable === false ? '게시시각 미확인' : timeAgo(item.publishedAt || item.ingestedAt)));
      card.append(meta, text('h2', item.title || '-'));
      if (item.description) card.append(text('p', item.description));

      if (smart.relevant) {
        const impactBox = document.createElement('div');
        impactBox.className = 'impactBox smartReason';
        impactBox.append(text('b', `스마트머니 ${DIRECTION[smart.direction] || '혼재'} 추정`));
        impactBox.append(document.createTextNode(` — ${(smart.reasons || []).join(' · ')}`));
        card.append(impactBox);
      } else if (item.importance?.reasons?.length) {
        const impactBox = document.createElement('div');
        impactBox.className = 'impactBox';
        impactBox.append(text('b', '자동선별 근거'));
        impactBox.append(document.createTextNode(` — ${item.importance.reasons.join(' · ')}`));
        card.append(impactBox);
      }

      const relatedImpactRows = (item.relatedStocks?.length ? item.relatedStocks : smart.koreaImpacts || []).slice(0, 3);
      if (relatedImpactRows.length) {
        const section = document.createElement('div');
        section.className = 'koreaImpactList';
        section.append(text('div', '국내 연관주 TOP 3', 'impactTitle'));
        relatedImpactRows.forEach((row) => {
          const line = document.createElement('div');
          line.className = 'impactLine';
          const name = text('span', `${row.name} · ${row.role || row.group || '연관주'}`, 'impactName');
          const meter = document.createElement('span');
          meter.className = 'impactMeter';
          const fill = document.createElement('i');
          fill.style.width = `${Math.max(0, Math.min(100, Number(row.intensity || row.score || 0)))}%`;
          fill.className = `fill-${row.direction || 'mixed'}`;
          meter.append(fill);
          const scoreValue = Number(row.intensity || row.score || 0);
          const score = text('b', `${DIRECTION[row.direction] || '혼재'} ${scoreValue}`, `impactScore direction-${row.direction || 'mixed'}`);
          line.append(name, meter, score);
          section.append(line);
        });
        card.append(section);
      }

      if (item.importance?.themes?.length) {
        const themes = document.createElement('div');
        themes.className = 'themeRow';
        item.importance.themes.forEach((theme) => themes.append(text('span', theme)));
        card.append(themes);
      }
      const rank = { high: 0, medium: 1, low: 2 };
      const topMacro = [...(item.macroMatched || [])].sort((a, b) => rank[a.impactLevel] - rank[b.impactLevel])[0];
      if (topMacro) {
        const rationale = document.createElement('div');
        rationale.className = `rationale impact-${topMacro.impactLevel || 'medium'}`;
        rationale.append(text('b', IMPACT[topMacro.impactLevel] || '영향 중'));
        rationale.append(document.createTextNode(` — ${topMacro.rationale || ''}`));
        card.append(rationale);
      }
      cards.append(card);
    });
  }

  function renderAll() {
    renderHealth();
    renderMarketPulse();
    renderUsMarketDesk();
    renderActiveMonitor();
    renderSectorRotation();
    renderSectorForecast();
    renderInvestorInsights();
    renderWatchlist();
    renderMacroTopics();
    renderNews();
  }

  function scheduleAccessRefreshFollowup(accessRefresh) {
    if (state.accessRefreshTimer) clearTimeout(state.accessRefreshTimer);
    state.accessRefreshTimer = null;
    const shouldRetry = Boolean(accessRefresh?.triggered || accessRefresh?.running || accessRefresh?.skipped === 'already_running');
    if (!shouldRetry || state.accessRefreshRetries >= 12) {
      state.accessRefreshRetries = 0;
      return;
    }
    state.accessRefreshRetries += 1;
    state.accessRefreshTimer = setTimeout(() => {
      state.accessRefreshTimer = null;
      refreshAll().catch(() => null);
    }, 4000);
  }

  function localCalibrationMirror() {
    try { return JSON.parse(localStorage.getItem(CALIBRATION_MIRROR_KEY) || 'null'); } catch (_) { return null; }
  }

  async function syncCalibrationMirror(allowRestore = true) {
    try {
      let remote = await api('/api/calibration');
      const local = localCalibrationMirror();
      const remoteCount = Number(remote?.summary?.totalPredictions || 0);
      const localCount = Number(local?.state?.predictions?.length || 0);
      if (allowRestore && localCount > 0) {
        // 서버가 재시작되었거나 다른 기기에서 일부 기록만 남은 경우에도 중복키로 안전 병합합니다.
        await api('/api/calibration', { method: 'POST', body: JSON.stringify({ state: local.state, onlyIfEmpty: false }) });
        remote = await api('/api/calibration');
      }
      state.calibration = remote.summary || state.calibration;
      state.calibrationStorage = remote.storage || state.calibrationStorage;
      state.calibrationMirrorAt = Date.now();
      localStorage.setItem(CALIBRATION_MIRROR_KEY, JSON.stringify({ savedAt: new Date().toISOString(), state: remote.state }));
      renderCalibration();
      return remote;
    } catch (_) { return null; }
  }

  function localNextUsMirror() {
    try { return JSON.parse(localStorage.getItem(NEXT_US_MIRROR_KEY) || 'null'); } catch (_) { return null; }
  }

  async function syncNextUsMirror(allowRestore = true) {
    try {
      let remote = await api('/api/next-us-session-state');
      const local = localNextUsMirror();
      const localCount = Number(local?.state?.forecasts?.length || 0);
      if (allowRestore && localCount > 0) {
        await api('/api/next-us-session-state', { method: 'POST', body: JSON.stringify({ state: local.state, onlyIfEmpty: false }) });
        remote = await api('/api/next-us-session-state');
      }
      state.nextUsForecastStorage = remote.storage || state.nextUsForecastStorage;
      state.nextUsForecastMirrorAt = Date.now();
      localStorage.setItem(NEXT_US_MIRROR_KEY, JSON.stringify({ savedAt: new Date().toISOString(), state: remote.state }));
      return remote;
    } catch (_) { return null; }
  }

  async function refreshNextUsSession(force = false) {
    try {
      const data = await api(`/api/next-us-session${force ? '?force=1' : ''}`);
      state.nextUsSession = data || null;
      renderNextUsSession();
      if (Date.now() - state.nextUsForecastMirrorAt > 300000) syncNextUsMirror(false).catch(() => null);
      return data;
    } catch (_) { return null; }
  }

  function localSectorForecastMirror() {
    try { return JSON.parse(localStorage.getItem(SECTOR_FORECAST_MIRROR_KEY) || 'null'); } catch (_) { return null; }
  }

  async function syncSectorForecastMirror(allowRestore = true) {
    try {
      let remote = await api('/api/sector-forecast-state');
      const local = localSectorForecastMirror();
      const localCount = Number(local?.state?.days?.length || 0);
      if (allowRestore && localCount > 0) {
        await api('/api/sector-forecast-state', { method: 'POST', body: JSON.stringify({ state: local.state, onlyIfEmpty: false }) });
        remote = await api('/api/sector-forecast-state');
      }
      state.sectorForecastStorage = remote.storage || state.sectorForecastStorage;
      state.sectorForecastMirrorAt = Date.now();
      localStorage.setItem(SECTOR_FORECAST_MIRROR_KEY, JSON.stringify({ savedAt: new Date().toISOString(), state: remote.state }));
      return remote;
    } catch (_) { return null; }
  }

  async function refreshActiveMonitor(force = false) {
    try {
      const data = await api(`/api/active-monitor${force ? '?force=1' : ''}`);
      state.activeMonitor = data.items || [];
      state.activeMarket = data.market || null;
      state.calibration = data.calibration || state.calibration;
      state.sectorRotation = data.sectorRotation || state.sectorRotation;
      state.sectorForecast = data.sectorForecast || state.sectorForecast;
      state.universe = data.universe || state.universe;
      renderActiveMonitor();
      renderSectorRotation();
      renderSectorForecast();
      if (Date.now() - state.sectorForecastMirrorAt > 300000) syncSectorForecastMirror(false).catch(() => null);
      if (Date.now() - state.calibrationMirrorAt > 300000) syncCalibrationMirror(false).catch(() => null);
      return data;
    } catch (_) { return null; }
  }

  async function refreshAll() {
    // FASTBOOT RESTORE: 화면을 먼저 살리고 각 데이터는 독립적으로 도착하는 즉시 갱신한다.
    // 느린 공개 미국시세/V3 공유시세/학습상태 복원이 뉴스 화면 전체를 막지 않는다.
    const tasks = [];
    const launch = (promise, apply, onError) => {
      const task = promise.then((data) => { if (data) apply(data); return data; }).catch((error) => { onError?.(error); return null; });
      tasks.push(task); return task;
    };

    launch(api('/api/health', { timeoutMs: 3500 }), (health) => { state.health = health; renderHealth(); });
    launch(api('/api/watchlist', { timeoutMs: 3500 }), (data) => { state.watchlist = data.items || []; renderWatchlist(); });
    launch(api('/api/macro', { timeoutMs: 3500 }), (data) => { state.macroTopics = data.items || []; renderMacroTopics(); });
    launch(api('/api/news?limit=300', { timeoutMs: 4500 }), (news) => {
      state.news = news.items || [];
      state.sectorRotation = news.sectorRotation || state.sectorRotation;
      renderNews(); renderSectorRotation();
      scheduleAccessRefreshFollowup(news.accessRefresh);
    }, () => delayedStatus('sectorRotationState', '뉴스 저장소 지연 · 자동 재시도'));

    launch(api('/api/theme-briefs', { timeoutMs: 4500 }), (data) => { state.themeBriefs = data.items || []; if (state.filter === 'themes') renderNews(); });
    launch(api('/api/semiconductor-briefs', { timeoutMs: 4500 }), (data) => { state.semiconductorBriefs = data.items || []; if (state.filter === 'semiconchain') renderNews(); });
    launch(api('/api/affected-stocks', { timeoutMs: 5000 }), (data) => { state.affectedStocks = data.items || []; state.universe = data.universe || state.universe; if (state.filter === 'affected') renderNews(); });
    launch(api('/api/foreign-leads', { timeoutMs: 5000 }), (data) => { state.foreignLeads = data.items || []; state.universe = data.universe || state.universe; if (state.filter === 'foreignlead') renderNews(); });
    launch(api('/api/early-edge', { timeoutMs: 6000 }), (data) => { state.earlyEdges = data.items || []; state.universe = data.universe || state.universe; if (state.filter === 'earlyedge') renderNews(); });
    launch(api('/api/second-order', { timeoutMs: 5000 }), (data) => { state.secondOrderBriefs = data.items || []; state.secondOrderCandidates = data.candidates || []; if (['secondorder','psychology'].includes(state.filter)) renderNews(); });

    launch(api('/api/market-pulse', { timeoutMs: 7000 }), (data) => { state.marketPulse = data || null; renderMarketPulse(); }, () => delayedStatus('marketPulseState', '공개시세 지연 · 자동 재시도'));
    launch(api('/api/us-market-desk', { timeoutMs: 8500 }), (desk) => { state.usMarketDesk = desk; renderUsMarketDesk(); }, () => {
      delayedStatus('usDeskSession', '세션 확인 지연'); delayedStatus('usDeskState', '시세 지연 · 자동 재시도');
      delayedStatus('usDeskNarrative', '미국 공개시세 응답이 지연되고 있습니다. 국내 뉴스와 30종목 자동투입은 계속 동작하며 미국장 분석만 자동 재시도합니다.');
    });
    launch(api('/api/next-us-session', { timeoutMs: 9000 }), (fc) => { state.nextUsSession = fc; renderNextUsSession(); }, () => {
      delayedStatus('nextUsTarget', '목표일 확인 지연'); delayedStatus('nextUsPhase', '자동 재시도');
      delayedStatus('nextUsNarrative', '미국장 전망 데이터가 지연되고 있습니다. 수신되는 항목부터 순차 반영합니다.');
    });
    launch(api('/api/investor-insights', { timeoutMs: 6500 }), (data) => { state.investorInsights = data; renderInvestorInsights(); }, () => delayedStatus('youtubeInsightState', '자료 갱신 지연 · 자동 재시도'));

    launch(refreshActiveMonitor(false), () => {}, () => {
      delayedStatus('marketFeedState', '공유시세 지연 · 자동 재시도');
      delayedStatus('sectorForecastState', '공유시세 대기 · 뉴스/화면은 정상');
    });

    // 핵심 로컬 데이터만 짧게 기다린 뒤 반환한다. 나머지는 백그라운드에서 계속 갱신된다.
    await Promise.race([Promise.allSettled(tasks.slice(0, 4)), new Promise((resolve) => setTimeout(resolve, 4800))]);
    return true;
  }

  async function refreshMarketPulse(force = false) {
    const suffix = force ? '?force=1' : '';
    const jobs = [
      api(`/api/market-pulse${suffix}`, { timeoutMs: 7000 }).then((data) => { state.marketPulse = data || null; renderMarketPulse(); return data; }).catch(() => { delayedStatus('marketPulseState', '공개시세 지연 · 자동 재시도'); return null; }),
      api(`/api/us-market-desk${suffix}`, { timeoutMs: 8500 }).then((desk) => { state.usMarketDesk = desk || null; renderUsMarketDesk(); return desk; }).catch(() => { delayedStatus('usDeskState', '시세 지연 · 자동 재시도'); return null; }),
      api(`/api/next-us-session${suffix}`, { timeoutMs: 9000 }).then((fc) => { state.nextUsSession = fc || null; renderNextUsSession(); return fc; }).catch(() => { delayedStatus('nextUsPhase', '자동 재시도'); return null; }),
    ];
    const result = await Promise.allSettled(jobs);
    return result[0]?.value || null;
  }

  function startRealtime() {
    stopRealtime();
    const source = new EventSource('/api/events');
    state.eventSource = source;
    source.onopen = () => $('connectionDot').classList.add('connected');
    source.onerror = () => $('connectionDot').classList.remove('connected');
    source.addEventListener('news', (event) => {
      try {
        const item = JSON.parse(event.data);
        state.news = [item, ...state.news.filter((row) => row.id !== item.id)].slice(0, 300);
        refreshActiveMonitor(false);
        if (state.filter === 'earlyedge') {
          api('/api/early-edge').then((data) => { state.earlyEdges = data.items || []; state.universe = data.universe || state.universe; renderNews(); }).catch(() => null);
        } else if (state.filter === 'foreignlead') {
          api('/api/foreign-leads').then((data) => { state.foreignLeads = data.items || []; state.universe = data.universe || state.universe; renderNews(); }).catch(() => null);
        } else if (state.filter === 'affected') {
          api('/api/affected-stocks').then((data) => { state.affectedStocks = data.items || []; state.universe = data.universe || state.universe; renderNews(); }).catch(() => null);
        } else if (['secondorder','psychology'].includes(state.filter)) {
          api('/api/second-order').then((data) => { state.secondOrderBriefs = data.items || []; state.secondOrderCandidates = data.candidates || []; renderNews(); }).catch(() => null);
        } else if (state.filter === 'themes') {
          api('/api/theme-briefs').then((data) => { state.themeBriefs = data.items || []; renderNews(); }).catch(() => null);
        } else if (state.filter === 'semiconchain') {
          api('/api/semiconductor-briefs').then((data) => { state.semiconductorBriefs = data.items || []; renderNews(); }).catch(() => null);
        } else renderNews();
      } catch (_) { /* 잘못된 이벤트 무시 */ }
    });
    state.healthTimer = setInterval(() => api('/api/health').then((health) => { state.health = health; renderHealth(); }).catch(() => null), 30000);
    state.marketTimer = setInterval(() => { refreshActiveMonitor(false); refreshMarketPulse(false); }, 30000);
  }

  function stopRealtime() {
    if (state.eventSource) state.eventSource.close();
    state.eventSource = null;
    if (state.healthTimer) clearInterval(state.healthTimer);
    state.healthTimer = null;
    if (state.marketTimer) clearInterval(state.marketTimer);
    state.marketTimer = null;
    if (state.accessRefreshTimer) clearTimeout(state.accessRefreshTimer);
    state.accessRefreshTimer = null;
    state.accessRefreshRetries = 0;
    $('connectionDot')?.classList.remove('connected');
  }

  $('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('loginError').textContent = '';
    $('loginButton').disabled = true;
    $('loginButton').textContent = '확인 중…';
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ token: $('loginToken').value }) });
      $('loginToken').value = '';
      showApp();
      renderAll();
      startRealtime();
      refreshAll().catch(() => null);
      Promise.allSettled([syncCalibrationMirror(true), syncNextUsMirror(true), syncSectorForecastMirror(true)])
        .then(() => { refreshActiveMonitor(false).catch(() => null); renderCalibration(); })
        .catch(() => null);
    } catch (error) {
      $('loginError').textContent = error.message;
    } finally {
      $('loginButton').disabled = false;
      $('loginButton').textContent = '로그인';
    }
  });

  $('logoutButton').addEventListener('click', async () => {
    await api('/api/auth/logout', { method: 'POST' }).catch(() => null);
    showLogin();
  });

  $('refreshButton').addEventListener('click', () => refreshAll().catch(() => null));

  $('backupButton').addEventListener('click', async () => {
    try {
      const response = await fetch('/api/export', { credentials: 'same-origin' });
      if (!response.ok) throw new Error('백업 다운로드에 실패했습니다.');
      const blob = await response.blob();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `kr-news-radar-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.append(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    } catch (error) { alert(error.message); }
  });

  $('stockForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('stockError').textContent = '';
    try {
      await api('/api/watchlist', {
        method: 'POST',
        body: JSON.stringify({ name: $('stockName').value, code: $('stockCode').value, aliases: $('stockAliases').value }),
      });
      event.target.reset();
      await refreshAll();
    } catch (error) { $('stockError').textContent = error.message; }
  });

  $('macroForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('macroError').textContent = '';
    try {
      await api('/api/macro', {
        method: 'POST',
        body: JSON.stringify({
          label: $('macroLabel').value, region: $('macroRegion').value, impactLevel: $('macroImpact').value,
          keywords: $('macroKeywords').value, enKeywords: $('macroEnKeywords').value, rationale: $('macroRationale').value,
        }),
      });
      event.target.reset();
      $('macroRegion').value = 'KR';
      $('macroImpact').value = 'medium';
      await refreshAll();
    } catch (error) { $('macroError').textContent = error.message; }
  });

  $('tabs').addEventListener('click', (event) => {
    const button = event.target.closest('button[data-filter]');
    if (!button) return;
    state.filter = button.dataset.filter;
    [...$('tabs').querySelectorAll('button')].forEach((item) => item.classList.toggle('active', item === button));
    renderNews();
  });


  // v1.5.6 SCROLL READER: 초기 배치/글씨는 v1.5.3 그대로 유지한다.
  // 아래로 스크롤해 읽을 때 화면 중앙의 세부문단 하나만 1.5배 확대한다.
  let scrollReadActive = null;
  let scrollReadFrame = 0;
  const scrollReadSelector = [
    '.usNarrative', '.insightCard p', '.youtubeInsightCard p', '.sectorForecastCard p', '.rotationReasonLine span', '.sectorForecastNote',
    '.card>p', '.rationale', '.impactBox', '.themeSummary', '.usDeskNote', '.activeMonitorNote', '.insightNote',
    '.policyInsightRow small', '.nextFactorRow small', '.usImpactBody small', '.bulletCompact>*', '.sectorCompactRow small'
  ].join(',');
  function clearScrollReadZoom() {
    if (!scrollReadActive) return;
    scrollReadActive.classList.remove('scrollReadActive');
    scrollReadActive.style.removeProperty('--scroll-read-size');
    scrollReadActive = null;
  }
  function updateScrollReadZoom() {
    scrollReadFrame = 0;
    if (window.scrollY < 48) { clearScrollReadZoom(); return; }
    if (scrollReadActive && document.body.contains(scrollReadActive)) {
      const r = scrollReadActive.getBoundingClientRect();
      if (r.bottom > innerHeight * .18 && r.top < innerHeight * .82) return;
    }
    clearScrollReadZoom();
    const targets = [...document.querySelectorAll(scrollReadSelector)].filter((el) => {
      const r = el.getBoundingClientRect();
      return r.height > 0 && r.bottom > innerHeight * .22 && r.top < innerHeight * .78 && String(el.textContent || '').trim().length >= 24;
    });
    if (!targets.length) return;
    const center = innerHeight * .52;
    targets.sort((a,b) => Math.abs((a.getBoundingClientRect().top+a.getBoundingClientRect().bottom)/2-center) - Math.abs((b.getBoundingClientRect().top+b.getBoundingClientRect().bottom)/2-center));
    const el = targets[0];
    const base = parseFloat(getComputedStyle(el).fontSize) || 12;
    el.style.setProperty('--scroll-read-size', `${(base * 1.5).toFixed(1)}px`);
    el.classList.add('scrollReadActive');
    scrollReadActive = el;
  }
  window.addEventListener('scroll', () => {
    if (!scrollReadFrame) scrollReadFrame = requestAnimationFrame(updateScrollReadZoom);
  }, { passive: true });

  showLoading();
  api('/api/auth/check', { timeoutMs: 5000 })
    .then(async (data) => {
      if (!data.authenticated) return showLogin();
      showApp();
      renderAll();
      startRealtime();
      refreshAll().catch(() => null);
      Promise.allSettled([syncCalibrationMirror(true), syncNextUsMirror(true), syncSectorForecastMirror(true)])
        .then(() => { refreshActiveMonitor(false).catch(() => null); renderCalibration(); })
        .catch(() => null);
    })
    .catch(() => showLogin());
})();
