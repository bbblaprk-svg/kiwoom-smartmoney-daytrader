# v1.5.2 → v1.5.3

기존 기능 삭제 없음.

추가:
- SECTOR ROTATION FORECAST 상단판
- 현재/3일/5일 순환경로
- 잠복/초기점화/확산/주도/자금이탈 판정
- 과거유사패턴 3·5일 확률
- V3.1.x dailyRows bootstrap
- 섹터 예측상태 브라우저 미러링 및 백업 포함
