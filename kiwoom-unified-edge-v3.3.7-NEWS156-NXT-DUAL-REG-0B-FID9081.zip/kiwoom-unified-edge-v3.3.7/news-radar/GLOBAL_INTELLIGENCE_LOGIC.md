# GLOBAL INTELLIGENCE v1.5.1

## 왜 추가했는가
미국 정규장은 아시아와 유럽의 장중 정보 이후에 열린다. 따라서 미국 뉴스만 보면 중국 정책, 엔화 급변, 대만 반도체 공급망, 유럽 ASML/ECB 신호를 뒤늦게 반영할 수 있다. v1.5.1은 이 정보를 별도 선행판으로 분리한다.

## 지역별 뉴스 입력
- 미국: Fed/FOMC, CPI/PCE, 고용, 국채, 미국 기업 실적·가이던스.
- 중국: Reuters China, PBOC 공개 색인, PMI, 위안화, 부동산, 수출, 희토류, 규제.
- 일본: Reuters Japan, BOJ 공개 색인, 엔화/JGB, 임금, 물가.
- 대만: Reuters Taiwan, Focus Taiwan, TSMC, 수출주문, 양안.
- 유럽: Reuters Europe, ECB, ASML, 유럽 PMI, 독일 산업.
- 글로벌: 관세, 수출규제, 제재, 지정학, 원유, 해운.

## 지역별 시장 확인
- 중국: Shanghai, Hang Seng, USD/CNY.
- 일본: Nikkei, USD/JPY.
- 대만: Taiwan Weighted, TSMC ADR.
- 유럽: Euro Stoxx 50, ASML ADR.

## 해석 원칙
뉴스 방향과 가격 방향이 같은 경우 신뢰를 높이고, 서로 반대인 경우 과도한 확신을 억제한다. 대만/TSMC와 SOX가 동조하면 한국 반도체 후공정·검사·테스트의 2차 연결을 강화한다. 중국 경기와 위안화가 동시에 약하면 소재·산업재·소비주의 기대를 낮춘다. 엔화 급변은 엔캐리 청산 리스크로 별도 취급한다.

## UI
NEXT US SESSION 안에 미국·중국·일본·대만·유럽·글로벌 6개 지역 카드를 표시한다. 각 카드에는 지역점수, 독립 출처 수, 대표 헤드라인을 보여준다.
