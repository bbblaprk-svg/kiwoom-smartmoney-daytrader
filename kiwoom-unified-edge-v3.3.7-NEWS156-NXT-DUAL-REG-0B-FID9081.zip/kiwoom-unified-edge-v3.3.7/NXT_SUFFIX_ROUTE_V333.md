# v3.3.3 NXT Suffix Route

- 기존 REALTIME FOUNDATION의 `realtimeStore -> realtimeFeatureEngine -> signalEngine`은 변경하지 않는다.
- 국내 WebSocket은 `/api/dostk/websocket` 하나만 사용한다.
- KRX 0B: bare 6자리 종목코드 문자열을 REG한다.
- NXT 0B: 국내 거래소별 종목코드 표기인 `6자리_NX` 문자열을 종목별 CORE REG한다.
- 미국주식 WebSocket 문서의 `{jmcode, stex_tp}` item-map을 국내 WebSocket REG에 사용하지 않는다.
- 실제 거래소 판정은 REAL 0B payload의 FID 9081만 진실값으로 사용한다.
- NXT 미지원 종목의 REG 실패는 그 종목만 격리하고 다른 NXT CORE를 유지한다.
- NXT 미수신만으로 국내 WebSocket을 terminate/reconnect 하지 않는다. transport 재연결은 socket frame watchdog에만 맡긴다.
- 활성 거래소의 confirmed fresh 0B가 없으면 해당 거래소의 현재가/신규 EARLY/PRE-BUY/BUY는 fail-closed한다.
