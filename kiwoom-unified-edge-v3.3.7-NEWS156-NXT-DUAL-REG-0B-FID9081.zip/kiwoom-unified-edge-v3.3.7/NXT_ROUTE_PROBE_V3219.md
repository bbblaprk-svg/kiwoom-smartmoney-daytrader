# v3.2.19 NXT ROUTE PROBE

목적: NXT firstTick=0을 추측으로 고치지 않고 실제 Kiwoom REAL payload에서 거래소 식별 FID/값을 확인한다.

- 최근 REAL entry 80건을 메모리 ring buffer로만 보관한다.
- LOGIN/PING/REG 응답은 저장하지 않는다. access token은 수집하지 않는다.
- `/api/realtime-debug?limit=50`에서 type, item, FID key, 현재가/체결 주요 FID, NXT/KRX/SOR 문자열 힌트, 현재 라우팅 결과를 확인한다.
- 장중 판단은 기존과 동일하게 Kiwoom WebSocket fresh 체결만 사용한다.
- REST/종가/캐시는 활성장 현재가 또는 신규 EARLY/PRE-BUY/BUY의 대체 입력으로 사용하지 않는다.
- 이 버전의 목적은 NXT route를 관찰 가능한 상태로 만들어 다음 라우팅을 실제 payload 근거로 확정하는 것이다.
