# v3.2.19 FIX1

Build gate correction only.

- Fixed stale `realtime-latency-check.js` assertion that still expected `AUTO_ROUTE_ACK_FIRST_TICK_FRESH_V7`.
- The runtime health policy in v3.2.19 is `NXT_ROUTE_PROBE_ACK_FIRST_TICK_FRESH_V8`.
- Added semantic assertions for ACK→FIRST_TICK→FRESH and WebSocket-only judgment.
- No trading-score, realtime-routing, NXT probe, or pre-ignition logic was loosened.
