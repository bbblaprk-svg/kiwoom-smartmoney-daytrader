# v3.2.21 NXT Adaptive Registration

- KRX primary WebSocket REG: `{jmcode, stex_tp:"KRX"}` + `0B`.
- NXT primary WebSocket REG: `{jmcode, stex_tp:"NXT"}` + `0B`.
- If no NXT first tick after 6 seconds, send an isolated legacy compatibility probe with `stex_tp:"2"`.
- A fallback/probe message never becomes NXT market data unless realtime FID `9081` explicitly confirms NXT.
- FID 337 is no longer used as a venue truth fallback.
- During an active NXT session, absence of confirmed NXT 0B ticks keeps NXT DATA_OFFLINE and blocks live-price-based entry signals.
