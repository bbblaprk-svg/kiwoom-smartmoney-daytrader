# PRE-IGNITION REALTIME CORE v3.2.16

## 목적
급등한 뒤 추격하지 않고, 상승이 본격화되기 전 주문흐름의 동시 변화를 포착한다.

## 실시간 hot path
News/rotation은 후보발굴만 수행한다. 30종목 SCOUT는 0B 체결 + 0D 호가잔량 + 0u 프로그램을 지속 수신하고, FOCUS는 0F 거래원을 추가한다.

0A 이벤트가 들어오는 즉시 메모리에서 5/15/60초 롤링값, VWAP, 체결가속, 대형체결, 체결강도, 상대 거래량을 갱신하고 신호를 평가한다. 이 경로에서 REST·스토리지·뉴스 HTTP를 기다리지 않는다. 알림/학습/저장은 후처리 큐로 분리한다.

## 사전점화 독립축
1. Tape: 5초 순매수와 5→15초 매수 가속
2. Orderbook: 매수잔량 불균형, bid replenishment, ask withdrawal
3. Program: 0u 순매수 velocity/양전환
4. Context: VWAP 근접, 동시간 거래량비 증가, 뉴스/섹터는 후보 우선순위만 보조

PRE-IGNITION은 최소 3개 독립축이 동시에 강화될 때만 허용한다. 같은 체결데이터에서 파생된 지표를 여러 독립축으로 중복 계산하지 않는다.

## Anti-chase
- 당일 +4.5% 이상은 PRE-IGNITION에서 제외
- +6.0% 이상 신규 EARLY/PRE-BUY/BUY 차단
- VWAP 과확장, 1분 급등, VI 직전/발동은 신규진입 차단

## Fail closed
활성 거래소의 fresh 0A가 없거나 age limit을 초과하면 currentPrice=null, 신규 EARLY/PRE-BUY/BUY 금지. 전일 종가/REST 값으로 보정하지 않는다.
