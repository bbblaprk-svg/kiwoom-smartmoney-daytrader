# Official Realtime Route Guard v3.2.16

2026-08-05 현재 Kiwoom 공식 국내주식 WebSocket 가이드 기준으로 hot path를 고정한다.

| 역할 | 공식 타입 | 앱 사용 |
|---|---|---|
| 주식체결 | 0A | current price, tape, 체결강도, VWAP/가속도 파생 |
| 주식우선호가 | 0B | 보조 best quote |
| 주식호가잔량 | 0C | orderbook imbalance/replenishment |
| 주식시간외호가 | 0D | 정규/NXT 장중 orderbook 판단에 사용하지 않음 |
| 주식당일거래원 | 0E | FOCUS 보조 수급 |
| ETF NAV | 0F | 일반주식 매매판단에 사용하지 않음 |
| 장시작시간 | 0m | 세션 전환/REG 복구 |
| ELW 지표 | 0s | 일반주식 매매판단에 사용하지 않음 |
| 종목프로그램매매 | 0u | program flow |
| VI발동/해제 | 0w | VI guard |

활성장 신규 신호는 0A fresh 체결이 없으면 fail-closed 한다. REST/종가/뉴스는 currentPrice를 대체하지 않는다.
