# v3.3.4 Official Domestic WebSocket REG

- Registration layer only changed. realtimeStore, realtimeFeatureEngine, signal scoring, close freshness, news and UI remain unchanged.
- Kiwoom official domestic WebSocket example registers `item:["039490"]` with `type:["0B"]`.
- Kiwoom official REST docs define exchange-specific REST stock codes as KRX `039490`, NXT `039490_NX`, SOR `039490_AL`; this is not documented as a domestic WebSocket REG rule.
- The `{jmcode, stex_tp}` item-map is documented on the US WebSocket page, not as the domestic NXT REG contract.
- Therefore v3.3.4 uses one domestic WebSocket and bare six-digit item strings for 0B/0D/0u/0F only.
- No `_NX`, `_AL`, `stex_tp`, separate NXT socket, numeric/text probe, or suffix ACK gate is used.
- Venue readiness continues to require actual REAL ticks routed by the existing truth layer; REG ACK alone is never treated as data readiness.
