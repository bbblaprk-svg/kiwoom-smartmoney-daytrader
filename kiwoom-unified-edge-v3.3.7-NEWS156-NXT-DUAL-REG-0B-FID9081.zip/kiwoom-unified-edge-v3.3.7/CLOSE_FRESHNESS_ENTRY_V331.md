# v3.3.1 CLOSE FRESHNESS + ENTRY GUIDANCE

- v3.3.0 REALTIME FOUNDATION (single domestic WebSocket, bare 6-digit REG, 0B + FID9081 truth) is unchanged.
- closeSnapshot -> close ranking -> UI now uses expected official-close-date freshness gate.
- stale snapshots remain stored as history but cannot become current price, close ranking, or closeDecision in the public dashboard.
- after 15:32 KST, startup performs one immediate current-day KRX close catch-up; after 20:01 it coalesces KRX+NXT catch-up.
- live signal table intentionally stays empty outside market hours. During active sessions, fresh WebSocket signals populate EARLY/PRE-BUY/BUY.
- EARLY/PRE-BUY displays a calculated waiting range; confirmed BUY displays a fixed entry price plus stop/targets.
- fixed legacy UI bug that required KIWOOM_WEBSOCKET_0A instead of the v3.3.0 public realtime source KIWOOM_WEBSOCKET_TRADE_AUTO.
