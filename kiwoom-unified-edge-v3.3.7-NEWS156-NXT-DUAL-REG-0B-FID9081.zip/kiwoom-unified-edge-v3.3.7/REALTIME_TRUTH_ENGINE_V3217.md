# v3.2.17 REALTIME TRUTH ENGINE

- 정상 기준을 WebSocket 연결/요청건수가 아니라 `REG ACK → FIRST 0A TICK → FRESH 0A`로 변경.
- KRX 핵심 가격 0A를 보조 0C/0u와 분리.
- NXT 핵심 0A는 종목별 REG로 격리하여 한 종목 미지원/오류가 전체 NXT를 막지 않게 함.
- NXT 0C/0u는 별도 소배치 보조루트. 실패해도 가격 0A 유지.
- GLOBAL에서 0m/0w 혼합 제거. 전역 0m만 등록.
- 활성장 fresh 0A 없으면 DATA_OFFLINE/PARTIAL, 신규 EARLY/PRE-BUY/BUY 금지.
- 종가/REST는 활성장 현재가 대체 금지.
- 목적은 급등 후 추격이 아니라 PRE-IGNITION: tape/orderbook/program/VWAP 독립축이 점화되되 과열종목은 차단.
