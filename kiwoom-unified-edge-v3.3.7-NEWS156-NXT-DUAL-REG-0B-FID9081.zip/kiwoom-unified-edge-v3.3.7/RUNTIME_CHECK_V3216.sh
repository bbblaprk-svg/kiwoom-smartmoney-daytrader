#!/usr/bin/env bash
set -euo pipefail
URL=${URL:-http://127.0.0.1:3000}
echo '=== IMAGE ==='
sudo docker inspect kiwoom-app --format='IMAGE={{.Config.Image}} STATUS={{.State.Status}} STARTED={{.State.StartedAt}}'
echo '=== REALTIME ==='
curl -s "$URL/api/health" | python3 -c 'import sys,json; x=json.load(sys.stdin); print("VERSION=",x.get("version")); print("STATUS=",x.get("status")); print("ROUTES=",x.get("realtimeTypeMap")); print("KRX/NXT=",x.get("krxSubscribed"),"/",x.get("nxtSubscribed")); print("FEEDS=",x.get("feedReady")); print("VENUES=",x.get("venueFeeds")); print("FRAME_AGE_MS=",x.get("socketFrameAgeMs")); print("POST=",x.get("postProcess")); print("REST=",(x.get("restMetrics") or {}).get("total"))'
