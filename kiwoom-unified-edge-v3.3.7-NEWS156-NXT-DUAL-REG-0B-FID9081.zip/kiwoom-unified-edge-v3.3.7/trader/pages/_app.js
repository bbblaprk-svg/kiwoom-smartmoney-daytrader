import Head from 'next/head';
import '../styles/globals.css';

export default function App({ Component, pageProps }) {
  return <>
    <Head>
      <title>키움 KRX·NXT 단타 신호</title>
      <meta name="description" content="키움 실시간 체결·호가·수급 기반 KRX·NXT 단타 신호 읽기 전용 검증 앱" />
      <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
      <meta name="theme-color" content="#080b0f" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <meta name="apple-mobile-web-app-title" content="키움단타" />
      <link rel="manifest" href="/manifest.webmanifest" />
      <link rel="apple-touch-icon" href="/icon-192.png" />
      <link rel="icon" href="/icon.svg" />
    </Head>
    <Component {...pageProps} />
  </>;
}
