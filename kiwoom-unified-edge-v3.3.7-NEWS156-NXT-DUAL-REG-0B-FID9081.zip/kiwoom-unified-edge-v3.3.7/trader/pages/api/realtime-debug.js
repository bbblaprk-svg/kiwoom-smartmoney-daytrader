const realtimeDebug = require('../../lib/realtimeDebug');
const { state } = require('../../lib/realtimeStore');

module.exports = function handler(req, res) {
  if (req.method === 'POST') {
    realtimeDebug.reset();
    return res.status(200).json({ ok:true, reset:true, at:new Date().toISOString() });
  }
  const limit = Math.max(1, Math.min(80, Number(req.query && req.query.limit || 50)));
  const debug = realtimeDebug.snapshot(limit);
  res.status(200).json({
    ok:true,
    version:'3.3.1-realtime-foundation-close-freshness-news156',
    dataStatus:state.connection.dataStatus || 'UNKNOWN',
    expectedVenues:state.connection.expectedVenues || [],
    detectedTradeType:state.connection.detectedTradeType || null,
    registrationStats:state.connection.registrationStats || {},
    venueHealth:state.connection.venueHealth || {},
    purpose:'SANITIZED_REAL_FRAME_ROUTE_DISCOVERY',
    note:'REAL frames only; no LOGIN token/auth payloads are stored.',
    ...debug,
  });
};
