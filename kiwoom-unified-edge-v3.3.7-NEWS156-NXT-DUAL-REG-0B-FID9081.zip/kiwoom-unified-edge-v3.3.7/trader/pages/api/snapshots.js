const { requireAuth } = require('../../lib/auth');
const { getItem } = require('../../lib/store');
const { mergeWatchlist } = require('../../lib/stocks');
const { state, applyMarketSnapshot } = require('../../lib/realtimeStore');
const { refreshAll } = require('../../lib/marketSnapshot');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method === 'GET') {
      const snapshots = [...state.stocks.values()].map((stock) => stock.marketSnapshot).filter(Boolean);
      return res.status(200).json({ snapshots, connection: state.connection, fetchedAt: new Date().toISOString() });
    }
    if (req.method !== 'POST') return res.status(405).json({ error: 'GET 또는 POST만 지원합니다.' });

    const worker = globalThis.__KIWOOM_WORKER__;
    if (worker && typeof worker.refreshSnapshots === 'function') {
      const result = await worker.refreshSnapshots('manual');
      if (result) return res.status(200).json({ ...result, connection: state.connection });
      return res.status(409).json({ error: '종가 동기화가 이미 진행 중입니다.', connection: state.connection });
    }

    const [userStocks, settings] = await Promise.all([getItem('watchlist:user'), getItem('settings')]);
    const watchlist = mergeWatchlist(userStocks || []);
    const result = await refreshAll(watchlist, {
      settings,
      getLiveStock: (code) => state.stocks.get(code) || null,
    });
    for (const snapshot of result.snapshots) {
      const meta = watchlist.find((item) => item.code === snapshot.code) || {};
      applyMarketSnapshot(snapshot.code, snapshot, {
        name: meta.name || snapshot.name, marketMode: meta.market || 'SOR', tier: meta.tier || 'FOCUS', fixed: meta.fixed,
      });
    }
    return res.status(200).json({ ...result, connection: state.connection });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error), connection: state.connection });
  }
};
