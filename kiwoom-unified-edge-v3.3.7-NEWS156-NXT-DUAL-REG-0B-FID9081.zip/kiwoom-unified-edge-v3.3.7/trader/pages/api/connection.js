const { requireAuth } = require('../../lib/auth');
const { testConnection } = require('../../lib/kiwoomClient');
const { state } = require('../../lib/realtimeStore');
module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const rest = req.query.test === 'true' ? await testConnection() : null;
    return res.status(200).json({ rest, websocket: state.connection, serverTime: new Date().toISOString() });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error), websocket: state.connection });
  }
};
