const { getItem, getList } = require('../../lib/store');
const { mergeWatchlist, countUserTiers, MAX_FOCUS_USER_STOCKS, MAX_LIGHT_USER_STOCKS } = require('../../lib/stocks');
const { mergeSettings } = require('../../lib/settings');
const { getSnapshot, setSignalSettings } = require('../../lib/realtimeStore');
const { accountRisk } = require('../../lib/risk');
const { getPerformanceSummary } = require('../../lib/signalPerformance');
const { getLedger } = require('../../lib/signalLedger');
const { requireAuth } = require('../../lib/auth');
const { buildPreflight } = require('../../lib/preflight');
const { buildManagedSignalPortfolio } = require('../../lib/signalPortfolio');
const {
  getCachedRecommendations, getAutoApplyStatus,
  getCachedIntradayRecommendations, getIntradayAutoApplyStatus, getLearningSettings, getAdaptiveModel,
} = require('../../lib/recommendationEngine');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const [userStocks, savedSettings, positions, alerts, performance, recommendations, recommendationAutoApply, intradayRecommendations, intradayAutoApply, learningSettings, learningModel] = await Promise.all([
      getItem('watchlist:user'), getItem('settings'), getItem('positions'), getList('alerts', 0, 49), getPerformanceSummary(),
      getCachedRecommendations(), getAutoApplyStatus(), getCachedIntradayRecommendations(), getIntradayAutoApplyStatus(), getLearningSettings(), getAdaptiveModel(),
    ]);
    const watchlist = mergeWatchlist(userStocks || []);
    const settings = mergeSettings(savedSettings);
    setSignalSettings(settings.signal);
    const snapshot = getSnapshot(watchlist);
    const safePositions = Array.isArray(positions) ? positions : [];
    const tradeLedger = await getLedger({ stocks: snapshot.stocks, positions: safePositions, limit: 300 });
    const preflight = await buildPreflight(snapshot.stocks, snapshot.connection);
    const managedSignals = buildManagedSignalPortfolio(snapshot.stocks, tradeLedger.rows, { now: Date.now() });
    return res.status(200).json({
      ...snapshot,
      preflight,
      positions: safePositions,
      risk: accountRisk(safePositions, settings),
      alerts: Array.isArray(alerts) ? alerts : [],
      tradeLedger,
      managedSignals,
      watchlist,
      watchCounts: countUserTiers(userStocks || []),
      watchLimits: { focus: MAX_FOCUS_USER_STOCKS, light: MAX_LIGHT_USER_STOCKS, total: 4 + MAX_FOCUS_USER_STOCKS + MAX_LIGHT_USER_STOCKS },
      performance,
      settings,
      recommendations,
      recommendationAutoApply,
      intradayRecommendations,
      intradayAutoApply,
      learningSettings,
      learningModel,
      readOnly: true,
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
