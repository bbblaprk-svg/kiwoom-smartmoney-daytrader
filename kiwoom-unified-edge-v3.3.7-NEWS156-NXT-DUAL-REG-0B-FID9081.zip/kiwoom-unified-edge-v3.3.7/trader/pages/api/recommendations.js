const { requireAuth } = require('../../lib/auth');
const {
  getCachedRecommendations, generateDailyRecommendations, applyRecommendations,
  getAutoApplyStatus, setAutoApplyEnabled,
  getCachedIntradayRecommendations, generateIntradayRecommendations,
  getIntradayAutoApplyStatus, setIntradayAutoApplyEnabled, autoApplyIntradayIfEnabled,
  getLearningSettings, setLearningEnabled, getAdaptiveModel,
} = require('../../lib/recommendationEngine');
const { mergeWatchlist, countUserTiers } = require('../../lib/stocks');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') {
      const [cached, autoApply, intradayRecommendations, intradayAutoApply, learningSettings, learningModel] = await Promise.all([
        getCachedRecommendations(), getAutoApplyStatus(), getCachedIntradayRecommendations(), getIntradayAutoApplyStatus(), getLearningSettings(), getAdaptiveModel(),
      ]);
      return res.status(200).json({ recommendations: cached, autoApply, intradayRecommendations, intradayAutoApply, learningSettings, learningModel });
    }
    if (req.method === 'POST') {
      const action = String(req.body && req.body.action || 'generate').toLowerCase();
      if (action === 'set_learning_enabled') {
        const enabled = req.body && req.body.enabled === true;
        const learningSettings = await setLearningEnabled(enabled);
        return res.status(200).json({ learningSettings, learningModel: await getAdaptiveModel() });
      }
      if (action === 'generate') {
        const recommendations = await generateDailyRecommendations({ force: true });
        const autoApply = await getAutoApplyStatus();
        return res.status(200).json({ recommendations, autoApply, learningSettings: await getLearningSettings(), learningModel: await getAdaptiveModel() });
      }
      if (action === 'apply') {
        const recommendations = await getCachedRecommendations();
        const applied = await applyRecommendations(recommendations);
        return res.status(200).json({
          applied,
          watchlist: mergeWatchlist(applied.user),
          counts: countUserTiers(applied.user),
          recommendations,
          autoApply: await getAutoApplyStatus(),
        });
      }
      if (action === 'set_auto_apply') {
        const enabled = req.body && req.body.enabled === true;
        const autoApply = await setAutoApplyEnabled(enabled);
        return res.status(200).json({ autoApply });
      }
      if (action === 'generate_intraday') {
        const intradayRecommendations = await generateIntradayRecommendations({ force: true });
        const auto = await autoApplyIntradayIfEnabled(intradayRecommendations);
        const payload = {
          intradayRecommendations,
          intradayAutoApply: auto.status || await getIntradayAutoApplyStatus(),
          autoApplied: auto,
          learningSettings: await getLearningSettings(),
          learningModel: await getAdaptiveModel(),
        };
        if (auto.applied && auto.appliedResult) {
          payload.watchlist = mergeWatchlist(auto.appliedResult.user);
          payload.counts = countUserTiers(auto.appliedResult.user);
        }
        return res.status(200).json(payload);
      }
      if (action === 'apply_intraday') {
        const intradayRecommendations = await getCachedIntradayRecommendations();
        const applied = await applyRecommendations(intradayRecommendations);
        return res.status(200).json({
          applied,
          watchlist: mergeWatchlist(applied.user),
          counts: countUserTiers(applied.user),
          intradayRecommendations,
          intradayAutoApply: await getIntradayAutoApplyStatus(),
        });
      }
      if (action === 'set_intraday_auto_apply') {
        const enabled = req.body && req.body.enabled === true;
        const intradayAutoApply = await setIntradayAutoApplyEnabled(enabled);
        return res.status(200).json({ intradayAutoApply });
      }
      return res.status(400).json({ error: '지원 action: generate, apply, set_auto_apply, generate_intraday, apply_intraday, set_intraday_auto_apply, set_learning_enabled' });
    }
    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
