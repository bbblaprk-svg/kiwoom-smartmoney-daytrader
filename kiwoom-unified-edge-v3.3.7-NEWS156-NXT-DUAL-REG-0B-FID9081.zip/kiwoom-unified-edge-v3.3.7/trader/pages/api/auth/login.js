const { verifyAccessToken, setSessionCookie, authRequired } = require('../../../lib/auth');
module.exports = function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 지원합니다.' });
  if (!authRequired || verifyAccessToken(req.body && req.body.token)) {
    setSessionCookie(res);
    return res.status(200).json({ ok: true });
  }
  return res.status(401).json({ error: '접근 암호가 올바르지 않습니다.' });
};
