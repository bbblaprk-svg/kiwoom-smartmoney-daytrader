const { isAuthenticated, authRequired } = require('../../../lib/auth');
module.exports = function handler(req, res) {
  res.status(200).json({ ok: true, authRequired, authenticated: isAuthenticated(req) });
};
