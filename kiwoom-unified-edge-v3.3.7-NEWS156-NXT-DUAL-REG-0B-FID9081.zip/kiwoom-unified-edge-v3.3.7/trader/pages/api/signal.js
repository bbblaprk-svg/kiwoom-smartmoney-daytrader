const { requireAuth } = require('../../lib/auth');
const { state, ensureStock } = require('../../lib/realtimeStore');
const { normalizeBaseCode } = require('../../lib/stocks');
module.exports = function handler(req, res) {
  if (!requireAuth(req, res)) return;
  const code = normalizeBaseCode(req.query.code);
  if (!/^\d{6}$/.test(code)) return res.status(400).json({ error: '6자리 종목코드가 필요합니다.' });
  const stock = ensureStock(code);
  return res.status(200).json({ code, stock: state.stocks.get(code) || stock, fetchedAt: new Date().toISOString() });
};
