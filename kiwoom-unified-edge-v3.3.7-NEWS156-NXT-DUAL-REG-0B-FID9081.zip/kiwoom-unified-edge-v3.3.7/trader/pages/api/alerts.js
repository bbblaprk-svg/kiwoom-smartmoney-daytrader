const { getList } = require('../../lib/store');
const { recordAlert } = require('../../lib/notifications');
const { requireAuth } = require('../../lib/auth');
module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') return res.status(200).json({ alerts: await getList('alerts', 0, 999) });
    if (req.method === 'POST') return res.status(201).json({ alert: await recordAlert(req.body || {}) });
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
