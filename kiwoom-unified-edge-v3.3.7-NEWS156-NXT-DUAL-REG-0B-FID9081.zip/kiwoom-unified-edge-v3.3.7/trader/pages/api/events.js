const { requireAuth } = require('../../lib/auth');
const { onEvent, getPublicStock, state } = require('../../lib/realtimeStore');

module.exports = function handler(req, res) {
  if (!requireAuth(req, res)) return;
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write(`retry: 1500\n`);
  res.write(`data: ${JSON.stringify({ type: 'hello', connection: state.connection, serverTime: new Date().toISOString() })}\n\n`);

  state.sseClients = Number(state.sseClients || 0) + 1;
  const lastSent = new Map();
  const pending = new Map();
  let closed = false;
  const send = (payload) => {
    if (closed) return;
    try { res.write(`data: ${JSON.stringify(payload)}\n\n`); } catch (_) {}
  };
  const sendStockThrottled = (code) => {
    const now = Date.now();
    const previous = lastSent.get(code) || 0;
    const delay = Math.max(0, 50 - (now - previous));
    if (pending.has(code)) return;
    const timer = setTimeout(() => {
      pending.delete(code);
      const stock = getPublicStock(code);
      if (stock) {
        lastSent.set(code, Date.now());
        send({ type: 'stock', code, stock });
      }
    }, delay);
    pending.set(code, timer);
  };

  const unsubscribe = onEvent((event) => {
    if (event && event.code) sendStockThrottled(event.code);
    else if (event && (event.type === 'connection' || event.type === 'market-status')) {
      send({ type: 'connection', connection: state.connection });
    }
  });
  const heartbeat = setInterval(() => send({ type: 'heartbeat', serverTime: new Date().toISOString() }), 15_000);
  req.on('close', () => {
    closed = true;
    state.sseClients = Math.max(0, Number(state.sseClients || 0) - 1);
    clearInterval(heartbeat);
    for (const timer of pending.values()) clearTimeout(timer);
    pending.clear();
    unsubscribe();
    try { res.end(); } catch (_) {}
  });
};

module.exports.config = { api: { responseLimit: false } };
