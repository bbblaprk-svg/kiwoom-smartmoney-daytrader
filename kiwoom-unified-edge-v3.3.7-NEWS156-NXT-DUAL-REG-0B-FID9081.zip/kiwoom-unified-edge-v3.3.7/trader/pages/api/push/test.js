const { requireAuth } = require('../../../lib/auth');
const { sendWebPush } = require('../../../lib/notifications');
const { setItem } = require('../../../lib/store');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 지원합니다.' });
  try {
    const alert = {
      type: 'info', action: 'TEST', code: 'PUSH', name: '키움단타', price: null,
      message: '아이폰 종료상태 Web Push 테스트입니다. 이 알림이 보이면 푸시 경로가 정상입니다.',
      reasons: ['VAPID', 'Service Worker', 'Push Subscription'], time: new Date().toISOString(),
    };
    const result = await sendWebPush(alert);
    const test = { at: new Date().toISOString(), ...result };
    await setItem('push:last-test:v1', test);
    return res.status(result.sent > 0 ? 200 : 409).json({ ok: result.sent > 0, ...test });
  } catch (error) {
    const test = { at: new Date().toISOString(), sent: 0, error: String(error.message || error) };
    await setItem('push:last-test:v1', test).catch(() => null);
    return res.status(500).json({ ok: false, ...test });
  }
};
