const { requireAuth } = require('../../../lib/auth');
const { getVapidConfig } = require('../../../lib/pushConfig');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const config = await getVapidConfig({ generate: true });
    return res.status(200).json({ publicKey: config && config.publicKey || null, enabled: Boolean(config && config.publicKey && config.privateKey), source: config && config.source || null });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
