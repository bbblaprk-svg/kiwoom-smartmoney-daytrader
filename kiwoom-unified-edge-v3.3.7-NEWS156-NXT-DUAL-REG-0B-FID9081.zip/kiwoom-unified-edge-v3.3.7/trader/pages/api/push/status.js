const { requireAuth } = require('../../../lib/auth');
const { getPushStatus } = require('../../../lib/pushConfig');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const status = await getPushStatus({ generate: true });
    return res.status(200).json({ ok: true, ...status });
  } catch (error) {
    return res.status(500).json({ ok: false, error: String(error.message || error) });
  }
};
