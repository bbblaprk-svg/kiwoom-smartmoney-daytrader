const { getItem, setItem } = require('../../lib/store');
const { mergeSettings } = require('../../lib/settings');
const { requireAuth } = require('../../lib/auth');
const { setSignalSettings } = require('../../lib/realtimeStore');

const KEY = 'settings';
module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') {
      const settings = mergeSettings(await getItem(KEY));
      setSignalSettings(settings.signal);
      return res.status(200).json({ settings });
    }
    if (req.method === 'PUT') {
      const settings = mergeSettings(req.body || {});
      await setItem(KEY, settings);
      setSignalSettings(settings.signal);
      return res.status(200).json({ settings });
    }
    res.setHeader('Allow', ['GET', 'PUT']);
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
