const assert = require('assert');
const { parseProgram } = require('../lib/flowCollector');
const { closingFlowFromLive } = require('../lib/marketSnapshot');
const fs = require('fs');
const path = require('path');

const flowSource = fs.readFileSync(path.join(__dirname, '..', 'lib', 'flowCollector.js'), 'utf8');
assert(flowSource.includes("KIWOOM_PROGRAM_API_ID || 'ka90004'"), '종목별 프로그램 기본 TR은 ka90004여야 합니다.');
assert(!flowSource.includes("KIWOOM_PROGRAM_API_ID || 'ka90003'"), 'ka90003을 종목별 프로그램 기본 TR로 사용하면 안 됩니다.');

const p = parseProgram({ rows: [{ prm_netprps_amt: '+123456', prm_netprps_qty: '+789' }] });
assert.equal(p.netAmount, 123456);
assert.equal(p.netQty, 789);
assert.equal(p.rawAvailable, true);

const unrelated = parseProgram({ crd_alow_stk: [{ stk_cd: '000660', crd_alow_yn: 'Y' }] });
assert.equal(unrelated.rawAvailable, false, '비프로그램 TR 응답을 프로그램 수급으로 오인하면 안 됩니다.');

const previous = {
  smartMoneyState: 'EXPANSION', smartMoneyScore: 81,
  programNetAmount: 500000000, programNetQty: 10000,
  foreignNet: 1000, foreignNetDelta: 200, institutionNet: 300,
  availability: { smartMoney: true, program: true, foreign: true, institution: true },
  feedTimes: { tradeAt: 1, programAt: 2, brokerAt: 3, officialAt: 4 }, lastLiveAt: 1,
};
const merged = closingFlowFromLive(null, null, previous);
assert.equal(merged.smartMoneyState, 'EXPANSION');
assert.equal(merged.programNetAmount, 500000000);
assert.equal(merged.availability.smartMoney, false);
assert.equal(merged.availability.program, false);
assert.equal(merged.source, 'PRESERVED_DISPLAY_ONLY');
console.log('flow-regression-check: OK');
