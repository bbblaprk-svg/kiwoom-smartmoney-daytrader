process.env.STORE_DISABLE_LOCAL_FILE = 'true';
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kiwoom-observation-strength-'));
process.env.STORE_FILE_PATH = path.join(tmp, 'store.json');
process.env.STORE_KEY_DIR = path.join(tmp, 'keys');
process.env.LEDGER_BATCH_MS = '20';
const ledger = require('../lib/signalLedger');

(async () => {
  try {
    const t0 = Date.now();
    const base = { code: '009150', name: '삼성전기', action: 'EARLY', price: 200000, qualityScore: 66, profitPriorityScore: 60, reasons: ['test'], at: t0 };
    await ledger.recordSignal({ ...base, observation: { preSurgeScore: 64, tradeStrength: 112, netBuyAmount5s: 5_000_000, smartMoneyState: 'ABSORPTION', activeGroups: 3, executionScore: 8, rvol1m: 1.4 } });
    await ledger.updateObservationTrajectory({ code: '009150', name: '삼성전기', price: 200500, at: t0 + 16_000, observation: { preSurgeScore: 70, tradeStrength: 120, netBuyAmount5s: 25_000_000, smartMoneyState: 'TURN', activeGroups: 4, executionScore: 13, rvol1m: 1.6 } });
    await ledger.updateObservationTrajectory({ code: '009150', name: '삼성전기', price: 201500, at: t0 + 32_000, observation: { preSurgeScore: 79, tradeStrength: 132, netBuyAmount5s: 70_000_000, smartMoneyState: 'EXPANSION', activeGroups: 5, executionScore: 20, rvol1m: 2.0 } });
    let result = await ledger.getLedger({ stocks: [{ code: '009150', name: '삼성전기', price: 201500 }], positions: [] });
    let row = result.rows.find((x) => x.code === '009150');
    assert(row, '관찰행 누락');
    assert.strictEqual(row.observationStrength.trend, 'STRONG_UP', `강화 판정 오류 ${JSON.stringify(row.observationStrength)}`);
    assert.strictEqual(row.observationStrength.rankingAdjustment, 8, '강화 가산은 +8이어야 함');
    assert(row.observationStrength.improvingAxes >= 3, '독립 개선축 3개 미만');
    assert.strictEqual(row.observationPriorityScore, 87, '관찰우선도 계산 오류');

    // 반복 횟수만 늘고 내용이 좋아지지 않으면 가산하지 않는다.
    await ledger.recordSignal({ code: '012330', name: '현대모비스', action: 'EARLY', price: 250000, qualityScore: 65, profitPriorityScore: 58, reasons: ['flat'], at: t0 + 1000,
      observation: { preSurgeScore: 68, tradeStrength: 118, netBuyAmount5s: 20_000_000, smartMoneyState: 'ABSORPTION', activeGroups: 3, executionScore: 10, rvol1m: 1.5 } });
    await ledger.updateObservationTrajectory({ code: '012330', name: '현대모비스', price: 250100, at: t0 + 17_000, observation: { preSurgeScore: 69, tradeStrength: 119, netBuyAmount5s: 20_500_000, smartMoneyState: 'ABSORPTION', activeGroups: 3, executionScore: 10, rvol1m: 1.5 } });
    await ledger.updateObservationTrajectory({ code: '012330', name: '현대모비스', price: 250050, at: t0 + 34_000, observation: { preSurgeScore: 68, tradeStrength: 118, netBuyAmount5s: 20_000_000, smartMoneyState: 'ABSORPTION', activeGroups: 3, executionScore: 10, rvol1m: 1.5 } });
    result = await ledger.getLedger({ stocks: [{ code: '012330', name: '현대모비스', price: 250050 }], positions: [] });
    row = result.rows.find((x) => x.code === '012330');
    assert.strictEqual(row.observationStrength.trend, 'FLAT', '반복 관찰만으로 강화 판정되면 안 됨');
    assert.strictEqual(row.observationStrength.rankingAdjustment, 0, '반복횟수 자체 가산 금지');

    // BUY 게이트를 건드리지 않는지 소스 레벨 회귀 확인.
    const signalSource = fs.readFileSync('lib/signalEngine.js', 'utf8');
    assert(signalSource.includes('minBuyScore: 85'), '확정 BUY 품질기준 변경됨');
    assert(signalSource.includes('minProfitPriorityScore: 78'), '확정 BUY 수익우선기준 변경됨');
    assert(signalSource.includes('minTradeStrength: 118'), '확정 BUY 체결강도 변경됨');
    assert(!signalSource.includes('observationStrength'), '관찰강화가 확정 BUY 엔진에 직접 연결되면 안 됨');
    console.log('OBSERVATION STRENGTH CHECK OK: 반복횟수 0점, 동시강화 +8, BUY 게이트 불변');
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
})().catch((error) => { console.error(error); process.exit(1); });
