const assert = require('assert');
const {
  classifyMarketCapWon, normalizeTurnoverWon, marketActivityScore,
  allocateMarketPool, selectBalancedFocus,
} = require('../lib/marketDiscovery');

assert.equal(classifyMarketCapWon(80_000_000_000), 'MICRO');
assert.equal(classifyMarketCapWon(200_000_000_000), 'SMALL');
assert.equal(classifyMarketCapWon(1_000_000_000_000), 'MID');
assert.equal(classifyMarketCapWon(5_000_000_000_000), 'LARGE');
assert.equal(normalizeTurnoverWon('120000'), 120_000_000_000);

const large = marketActivityScore({ marketCapBucket:'LARGE', volumeSurgeRate:8, turnoverAccelerationPct:0, turnoverVelocityWonPerMin:200_000_000, turnoverWon:300_000_000_000, volumeRatio20:1.1 });
const small = marketActivityScore({ marketCapBucket:'SMALL', volumeSurgeRate:120, turnoverAccelerationPct:85, turnoverVelocityWonPerMin:1_500_000_000, turnoverWon:12_000_000_000, volumeRatio20:2.4 });
assert(small.score > large.score + 15, '중소형 상대활동 급증이 대형 절대거래대금에 묻힘');

const rows = [];
for (const [bucket, prefix, count] of [['MICRO','A',12],['SMALL','B',20],['MID','C',14],['LARGE','D',18]]) {
  for (let i=0;i<count;i++) rows.push({ code:`${prefix}${String(i).padStart(5,'0')}`, marketCapBucket:bucket, score:100-i });
}
const pool = allocateMarketPool(rows, {MICRO:8,SMALL:14,MID:10,LARGE:8}, 40);
const counts = pool.reduce((a,r)=>(a[r.marketCapBucket]=(a[r.marketCapBucket]||0)+1,a),{});
assert.deepStrictEqual(counts, {MICRO:8,SMALL:14,MID:10,LARGE:8}, '시총별 8/14/10/8 시장풀 배분 실패');
const focus = selectBalancedFocus(pool,8);
const largeCount = focus.filter((x)=>x.marketCapBucket==='LARGE').length;
assert(largeCount <= 2, '집중8이 대형주에 과도하게 잠식됨');
assert(focus.some((x)=>['MICRO','SMALL'].includes(x.marketCapBucket)), '중소형주 집중 후보 부재');
console.log('MARKET DISCOVERY CHECK OK: 시총4구간, 상대거래량/가속 우선, 시장풀 8/14/10/8, 집중8 대형 최대2');
