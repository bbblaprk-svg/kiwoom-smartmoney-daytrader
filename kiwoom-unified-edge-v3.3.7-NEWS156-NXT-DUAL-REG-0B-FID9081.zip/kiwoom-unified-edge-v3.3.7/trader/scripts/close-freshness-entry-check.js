const assert = require('assert');
const fs = require('fs');
const { closeSnapshotFreshness, expectedOfficialCloseDate } = require('../lib/marketSnapshot');

const now = new Date('2026-08-05T13:00:00.000Z'); // 22:00 KST
assert.strictEqual(expectedOfficialCloseDate(now), '20260805');
const stale = closeSnapshotFreshness({
  krx:{date:'20260731',close:100000},
  closeSync:{targetDate:'20260731',krxOfficialConfirmed:true,nxtFinalConfirmed:true}
}, now);
assert.strictEqual(stale.status, 'STALE_CLOSE_SNAPSHOT');
assert.strictEqual(stale.rankEligible, false);
const fresh = closeSnapshotFreshness({
  krx:{date:'20260805',close:101000},
  closeSync:{targetDate:'20260805',krxOfficialConfirmed:true,nxtFinalConfirmed:true}
}, now);
assert.strictEqual(fresh.rankEligible, true);

const ui = fs.readFileSync(require.resolve('../pages/index.js'),'utf8');
assert(ui.includes("KIWOOM_WEBSOCKET_TRADE_AUTO"), 'entryGuidance must use v3.3.0 realtime source');
assert(!ui.includes("realtimePriceSource === 'KIWOOM_WEBSOCKET_0A'"), 'legacy 0A entry guidance route remains');
assert(ui.includes('매수대기구간'), 'EARLY/PRE-BUY waiting range missing');
assert(ui.includes('확정 진입가'), 'BUY confirmed entry missing');
assert(ui.includes('STALE_CLOSE_SNAPSHOT') || ui.includes('종가 freshness 차단'), 'stale close UI guard missing');
const preflight = fs.readFileSync(require.resolve('../lib/preflight.js'),'utf8');
assert(preflight.includes('closeSnapshotFreshness?.rankEligible'), 'preflight stale snapshot gate missing');
const health = fs.readFileSync(require.resolve('../pages/api/health.js'),'utf8');
assert(health.includes('staleCloseSnapshots'), 'health stale snapshot metric missing');
const worker = fs.readFileSync(require.resolve('../worker/kiwoomRealtime.js'),'utf8');
assert(worker.includes('runStartupCloseCatchup'), 'startup close catch-up missing');
assert(worker.includes("const TRADE_TYPE = '0B'"), 'v3.3.0 realtime foundation trade route changed');
assert(!/stex_tp\s*:/.test(worker), 'domestic websocket item-map registration reintroduced');
console.log('CLOSE FRESHNESS + ENTRY GUIDANCE CHECK PASS');
