const assert = require('assert');

process.env.KIWOOM_APP_KEY = 'test-key';
process.env.KIWOOM_APP_SECRET = 'test-secret';
process.env.KIWOOM_REST_MIN_GAP_MS = '200';

const calls = [];
global.fetch = async (url) => {
  calls.push(String(url));
  if (String(url).endsWith('/oauth2/token')) {
    return new Response(JSON.stringify({ token: 'test-token', expires_in: 3600 }), {
      status: 200, headers: { 'content-type': 'application/json' },
    });
  }
  return new Response(JSON.stringify({ return_code: 0, stk_cd: '005930', stk_nm: '삼성전자', cur_prc: '1000' }), {
    status: 200, headers: { 'content-type': 'application/json' },
  });
};

(async () => {
  const { getStockInfo } = require('../lib/kiwoomClient');
  const data = await getStockInfo('005930');
  assert.equal(data.stk_nm, '삼성전자');
  assert.equal(calls.length, 2, '토큰 1회 + REST 1회가 호출되어야 합니다.');
  console.log('rest-regression-check: OK');
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
