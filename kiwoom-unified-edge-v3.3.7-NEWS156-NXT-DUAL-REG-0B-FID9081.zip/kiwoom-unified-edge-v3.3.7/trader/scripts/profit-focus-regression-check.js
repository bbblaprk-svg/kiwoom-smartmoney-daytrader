const fs = require('fs');
const assert = require('assert');
const { evaluateSignal } = require('../lib/signalEngine');

const activeTime = new Date('2026-07-31T05:10:00.000Z'); // KST 14:10

// 1) 스마트머니 보조피드가 아직 덜 준비돼도 체결/호가/가격-거래량 3축이 강하면 EARLY로 먼저 보여야 한다.
const early = evaluateSignal({
  price: 100500, vwap: 100000, vwapDistancePct: 0.5, turnover1m: 180_000_000,
  tradeStrength: 124, buyRatio: 60, rvol1m: 1.8,
  netBuyAmount5s: 55_000_000, netBuyAmount15s: 90_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 50_000_000, largeBuyCount1m: 2, largeSellCount1m: 0,
  spreadBps: 10, orderbookImbalance: 1.45, orderbookImbalanceEwma: 1.4, bidReplenishRatio: 0.14, bidReplenishEwma: 0.12, askWithdrawalRatio: 0.11, askWithdrawalEwma: 0.09, orderbookSupportStreak: 3, orderbookSampleCount: 3,
  programNetAmount: 0, programVelocity10s: 0, foreignNetDelta: 0,
  breakout: true, vwapReclaim: true, momentum1mPct: 0.5, drawdownFromHighPct: -0.1,
  recentHigh: 100600, recentLow: 99700, smartMoneyState: 'ABSORPTION',
  dataCompleteness: 80, activeTier: 'FOCUS', orderbookAgeMs: 0,
  programAgeMs: 999999, brokerAgeMs: 999999, tradeEventCount: 4, programSampleCount: 0,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(early.action, 'EARLY', JSON.stringify(early));
assert.strictEqual(early.earlyDiscoveryEligible, true, JSON.stringify(early));
assert.strictEqual(early.smartMoneyFeedReady, false, JSON.stringify(early));
assert(String(early.label).includes('급등 조짐'), JSON.stringify(early));

// 2) 하락압력이 강한 일반 감시종목은 SELL/RISK 경보가 아니라 신규진입 제외(WAIT)여야 한다.
const weak = evaluateSignal({
  price: 99500, vwap: 100000, vwapDistancePct: -0.5, turnover1m: 450_000_000,
  tradeStrength: 82, buyRatio: 39, rvol1m: 2.1,
  netBuyAmount5s: -45_000_000, netBuyAmount15s: -120_000_000, buyAcceleration: -20_000_000,
  largeNetAmount1m: -150_000_000, largeBuyCount1m: 0, largeSellCount1m: 3,
  spreadBps: 10, orderbookImbalance: 0.68, bidReplenishRatio: -0.08, askWithdrawalRatio: -0.05,
  programNetAmount: -300_000_000, programVelocity10s: -90_000_000, foreignNetDelta: -4000,
  breakdown: false, vwapReclaim: false, momentum1mPct: -0.55, drawdownFromHighPct: -0.8,
  recentHigh: 100300, recentLow: 99300, smartMoneyState: 'DISTRIBUTION',
  dataCompleteness: 100, activeTier: 'FOCUS', orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0,
  tradeEventCount: 8, programSampleCount: 3, viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(weak.action, 'WAIT', JSON.stringify(weak));
assert.strictEqual(weak.negativePressureBlock, true, JSON.stringify(weak));
assert(!['SELL', 'EARLY_SELL', 'RISK'].includes(weak.action));

// 3) UI와 worker가 수익추구 중심 정책을 실제로 반영하는지 정적 회귀검사.
const worker = fs.readFileSync('worker/kiwoomRealtime.js', 'utf8');
const page = fs.readFileSync('pages/index.js', 'utf8');
const store = fs.readFileSync('lib/realtimeStore.js', 'utf8');

assert(worker.includes('보유종목 손절가 도달'), '실제 보유종목 손절 알림 누락');
assert(worker.includes("if (notificationAction === 'EARLY' || stock.entryRestricted) return;"), 'EARLY/진입제한 BUY 푸시 억제 누락');
assert(!worker.includes("const ledgerStageAction = signal.action === 'RISK'"), 'RISK/EARLY_SELL 기록 훅이 남아있음');
assert(!worker.includes("if (risk.halted || risk.openCount >= Number(cache.settings.maxConcurrentPositions || 2)) return;"), '보유한도가 BUY 표시 자체를 막는 구식 return이 남아있음');
assert(worker.includes("notified.includes('STOP')"), '손절 알림 1회 억제 누락');
assert(store.includes("const actionable = raw.action === 'BUY';"), '실시간 확정 BUY 전용 정책 누락');
assert(page.includes('급등 사전포착 · 매수후보'), '상승초입 중심 보드 누락');
assert(page.includes('일반 매도잡신호는 숨김'), '매도잡신호 숨김 안내 누락');
assert(page.includes('확정 BUY와 실제 보유종목의 설정 손절가 도달만 전송'), '푸시 정책 안내 누락');
assert(!page.includes("['all','전체'],['active','발생중'],['buy','매수'],['sell','매도']"), '종합기록부 매도 탭이 남아있음');

console.log('PROFIT FOCUS CHECK OK: 급등초입 EARLY/BUY 중심, 일반종목 매도잡신호 제거, 보유종목 손절 1회 알림');
