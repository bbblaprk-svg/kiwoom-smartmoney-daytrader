const assert = require('assert');
const realtime = require('../lib/realtimeStore');

const originalNow = Date.now;
const base = new Date('2026-07-31T04:30:00.000Z').getTime(); // KST 13:30
let clock = base;
Date.now = () => clock;

function trade(item, quantity = 1200, price = 100000) {
  realtime.processRealtimeEntry({
    type: '0B', item,
    values: {
      '10': String(price), '12': '1.0', '15': String(quantity), '13': '100000', '14': '10000000000',
      '27': String(price + 100), '28': String(price), '228': '145', '851': '220', '1032': '67', '620': '99700', '9081': 'NXT',
    },
  }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
}

try {
  realtime.state.stocks.clear();
  realtime.setSignalSettings({
    minBuyScore: 85, minDataCompleteness: 95, confirmTicks: 3, confirmHoldMs: 800,
    maxSpreadBps: 35, minOneMinuteTurnover: 100_000_000, minTradeStrength: 118,
  });
  const item = '123456_AL';
  realtime.processRealtimeEntry({ type: '0D', item, values: { '9081':'KRX', 
    '41': '100100', '61': '10000', '51': '100000', '71': '30000',
    '42': '100200', '62': '8000', '52': '99900', '72': '24000',
    '121': '30000', '125': '30000',
  } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
  clock += 200;
  realtime.processRealtimeEntry({ type: '0D', item, values: { '9081':'KRX', 
    '41': '100100', '61': '10000', '51': '100000', '71': '30000',
    '42': '100200', '62': '8000', '52': '99900', '72': '24000',
    '121': '18000', '125': '54000',
  } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
  realtime.processRealtimeEntry({ type: '0u', item, values: { '9081':'KRX',  '210': '20000', '212': '500000000', '211': '2000', '213': '50000000' } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
  clock += 300;
  realtime.processRealtimeEntry({ type: '0u', item, values: { '9081':'KRX',  '210': '26000', '212': '700000000', '211': '6000', '213': '200000000' } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
  realtime.processRealtimeEntry({ type: '0F', item, values: { '9081':'KRX',  '267': '20000', '268': '5000', '263': '50000', '261': '30000' } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });
  clock += 300;
  realtime.processRealtimeEntry({ type: '0F', item, values: { '9081':'KRX',  '267': '26000', '268': '6000', '263': '56000', '261': '30000' } }, { name: '통합테스트', market: 'SOR', tier: 'FOCUS' });

  for (let i = 0; i < 8; i += 1) {
    clock += 300;
    trade(item, 1200, 100000 + i * 10);
  }
  const stock = realtime.getSnapshot([{ code: '123456', name: '통합테스트', market: 'SOR', tier: 'FOCUS', fixed: false }]).stocks[0];
  assert.strictEqual(stock.signal.action, 'BUY', JSON.stringify(stock.signal));
  assert.strictEqual(stock.signal.confirmed, true, JSON.stringify(stock.signal));
  assert(stock.signal.qualityScore >= 85);
  assert(stock.signal.dataCompleteness >= 95);
  assert(['TURN', 'EXPANSION'].includes(stock.signal.smartMoneyState));
  assert(stock.signal.confirmCount >= 3);
  assert(stock.signal.confirmationHeldMs >= 800);

  const lightItem = '223456_AL';
  for (let i = 0; i < 8; i += 1) {
    clock += 300;
    realtime.processRealtimeEntry({ type: '0B', item: lightItem, values: { '9081':'KRX', 
      '10': String(20000 + i * 5), '15': '5000', '27': '20010', '28': '20000', '228': '150', '1032': '70', '620': '19900',
    } }, { name: '경량테스트', market: 'SOR', tier: 'LIGHT' });
  }
  const light = realtime.getSnapshot([{ code: '223456', name: '경량테스트', market: 'SOR', tier: 'LIGHT', fixed: false }]).stocks[0];
  assert.strictEqual(light.activeTier, 'LIGHT');
  assert.notStrictEqual(light.signal.action, 'BUY');
  assert(light.promotionScore >= 70, `promotionScore=${light.promotionScore}`);

  console.log('INTEGRATION CHECK OK: 집중 BUY 체결확인·유지시간·완전성, 경량 BUY 차단·승격점수');
} finally {
  Date.now = originalNow;
}
