const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const worker = read('worker/kiwoomRealtime.js');
const market = read('lib/marketSnapshot.js');
const flow = read('lib/flowCollector.js');
const health = read('pages/api/health.js');

assert(worker.includes("market:close-sync:v5:"), 'close sync state version must be v5');
assert(worker.includes('this.marketStatusRefreshTimers = new Map()'), 'disconnect cleanup map must be initialized');
assert(worker.includes('runCombinedCloseSync'), 'post-NXT coalesced close sync missing');
assert(worker.includes("stage: 'NXT_CLOSE', targetDate: clock.compactDate") && worker.includes("snapshotReason: 'combined_close_sync'"), 'combined close sync must use one NXT-final snapshot pass');
assert(worker.includes("if (krx.pendingCodes.length && krx.status !== 'ready')") && worker.includes('return this.runCombinedCloseSync'), 'restart after NXT close must not run KRX and NXT full passes separately');

assert(market.includes("syncStage !== 'KRX_CLOSE'"), 'KRX close sync must skip NXT REST');
assert(market.includes('dailyUsable') && market.includes("syncStage === 'MANUAL' || !dailyUsable"), 'KRX basic-info duplicate call guard missing');
assert(market.includes('canFastNxtFinal') && market.includes('refreshNxtFinalOnly'), 'NXT final fast path missing');
assert(market.includes("nxtSource = 'WEBSOCKET_FINAL'"), 'fresh NXT WebSocket final must be reused before REST');
assert(flow.includes("ka10059-derived") && flow.includes('needForeignDetail'), 'foreign-detail fallback-only policy missing');
assert(health.includes('closeSyncCoalescing: true'));
assert(health.includes("nxtFinalFastPath: 'WEBSOCKET_THEN_REST'"));
assert(health.includes('foreignDetailFallbackOnly: true'));
assert(health.includes('startedAt: rest.startedAt'));

console.log(JSON.stringify({
  ok: true,
  version: require('../package.json').version,
  closeSyncState: 'v5',
  postNxtCatchup: 'COALESCED_SINGLE_PASS',
  krxClose: 'DAILY_PRIMARY_NO_NXT_REST',
  nxtFinal: 'WEBSOCKET_THEN_SINGLE_REST_FALLBACK',
  foreignFlow: 'ka10059_PRIMARY_ka10008_FALLBACK_ONLY',
}, null, 2));
