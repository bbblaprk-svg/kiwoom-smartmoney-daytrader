const fs=require('fs'); const assert=require('assert');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8'); const store=fs.readFileSync('lib/realtimeStore.js','utf8');
assert(worker.includes('KRX_CORE_BARE_0B')); assert(worker.includes('startNxtProbeSocket'));
assert(worker.includes("type:['0B']")); assert(worker.includes("type:['0D','0u']")); assert(worker.includes("type:['0F']"));
assert(store.includes("case '0B':")); assert(store.includes("case '0D': processOrderbook")); assert(store.includes("case '0F': processBroker"));
console.log('REALTIME_ENGINE_V3222_COMPAT_CHECK PASS -> KRX bare lock + isolated NXT probe');
