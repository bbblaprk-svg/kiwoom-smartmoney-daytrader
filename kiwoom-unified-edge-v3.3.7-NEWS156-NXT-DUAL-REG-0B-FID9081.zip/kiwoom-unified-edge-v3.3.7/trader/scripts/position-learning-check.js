const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { normalizeActualPositionOutcome } = require('../lib/positionLearning');

const row = normalizeActualPositionOutcome({
  id:'p1', code:'005930', name:'테스트', avgPrice:10000, initialStopPrice:9400,
  exitPrice:11200, createdAt:'2026-08-01T00:00:00Z', exitTime:'2026-08-04T00:00:00Z',
  learningContextEligible:true, signalActionAtEntry:'BUY',
  learningContext:{ qualityScore:88, smartMoneyBehaviorState:'TURN', preSurgeScore:78, changePct:3.2 },
});
assert(row && row.source === 'ACTUAL_POSITION', 'actual position outcome missing');
assert(row.result === 'WIN' && Math.abs(row.resultR - 2) < 0.001, 'actual R calculation regression');

const positions = fs.readFileSync(path.join(__dirname,'../pages/api/positions.js'),'utf8');
const adaptive = fs.readFileSync(path.join(__dirname,'../lib/adaptiveLearning.js'),'utf8');
assert(positions.includes('positionLearningContext(state.stocks.get(code))'), 'entry context capture missing');
assert(positions.includes('recordActualPositionOutcome'), 'closed actual outcome recording missing');
assert(adaptive.includes("source = 'ACTUAL_POSITION'"), 'actual-position learning priority missing');
assert(adaptive.includes('actualPositions.length >= MIN_TOTAL_SAMPLES'), 'actual-position minimum sample guard missing');
console.log('POSITION LEARNING CHECK OK: 앱 BUY/CLOSE_BUY 문맥의 실제 체결가 성과만 60표본 이후 우선학습');
