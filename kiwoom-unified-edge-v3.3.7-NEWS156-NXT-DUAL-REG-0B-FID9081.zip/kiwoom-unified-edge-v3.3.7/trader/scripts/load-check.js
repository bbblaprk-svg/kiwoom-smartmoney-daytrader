const fs = require('fs');
const os = require('os');
const path = require('path');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kiwoom-v313-load-'));
process.env.STORE_FILE_PATH = path.join(root, 'store.json');
process.env.STORE_KEY_DIR = path.join(root, 'keys');
process.env.STORE_DISABLE_LOCAL_FILE = 'false';
process.env.POST_PROCESS_CONCURRENCY = process.env.POST_PROCESS_CONCURRENCY || '4';
process.env.POSITION_BATCH_MS = '100';
process.env.ALERT_BATCH_MS = '100';

const Module = require('module');
const originalLoad = Module._load;
Module._load = function loadWithWsStub(request, parent, isMain) {
  if (request === 'ws') {
    class WebSocketStub {}
    WebSocketStub.OPEN = 1; WebSocketStub.CONNECTING = 0;
    return WebSocketStub;
  }
  return originalLoad.call(this, request, parent, isMain);
};
const realtime = require('../lib/realtimeStore');
const { KiwoomRealtimeWorker } = require('../worker/kiwoomRealtime');
Module._load = originalLoad;
const runtimeMetrics = require('../lib/runtimeMetrics');

const totalTicks = Math.max(1000, Number(process.env.LOAD_TEST_TICKS || 12000));
const batchSize = Math.max(10, Number(process.env.LOAD_TEST_BATCH || 250));
const symbolCount = Math.max(12, Number(process.env.LOAD_TEST_SYMBOLS || 30));
const codes = Array.from({ length: symbolCount }, (_, i) => String(310000 + i));
const worker = new KiwoomRealtimeWorker();
worker.watchlist = codes.map((code, index) => ({ code, name: `부하${index + 1}`, market: 'SOR', tier: index < 12 ? 'FOCUS' : 'LIGHT', fixed: index < 4 }));
// 18개 경량 중 최대 2개 자동승격 상황을 모사해 full-depth 동시대상은 기존과 같은 14개까지 유지한다.
for (let i = 12; i < Math.min(14, codes.length); i += 1) realtime.setPromotion(codes[i], Date.now() + 600_000);

function inject(index) {
  const code = codes[index % codes.length];
  const price = 10000 + (index % 300);
  const quantity = index % 2 ? 200 : -180;
  realtime.processRealtimeEntry({
    type: '0B', item: `${code}_AL`, values: {
      '10': String(price), '12': '0.5', '15': String(quantity),
      '13': String(100000 + index), '14': String(1_000_000_000 + index * 10000),
      '27': String(price + 5), '28': String(price), '228': '105', '851': '120', '1032': '52', '620': String(price - 5), '9081': 'KRX',
    },
  }, { name: `부하${index % codes.length + 1}`, market: 'SOR', tier: index % codes.length < 12 ? 'FOCUS' : 'LIGHT' });
  if (index % 4 === 0 && index % codes.length < 14) {
    realtime.processRealtimeEntry({ type: '0D', item: `${code}_AL`, values: { '41': String(price + 5), '61': '10000', '51': String(price), '71': '30000', '121': '25000', '125': '35000' } }, { name: `부하${index % codes.length + 1}`, market: 'SOR', tier: 'FOCUS' });
  }
  if (index % 10 === 0 && index % codes.length < 14) {
    realtime.processRealtimeEntry({ type: '0u', item: `${code}_AL`, values: { '210': '20000', '212': '500000000', '211': '3000', '213': '70000000' } }, { name: `부하${index % codes.length + 1}`, market: 'SOR', tier: 'FOCUS' });
    realtime.processRealtimeEntry({ type: '0F', item: `${code}_AL`, values: { '267': '22000', '268': '5000', '263': '54000', '261': '30000' } }, { name: `부하${index % codes.length + 1}`, market: 'SOR', tier: 'FOCUS' });
  }
  worker.schedulePostProcess(code, { trade: true });
}

function waitForDrain(timeoutMs = 30000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const timer = setInterval(() => {
      if (worker.postPending.size === 0 && worker.postActive === 0 && worker.postRunning.size === 0) {
        clearInterval(timer); resolve();
      } else if (Date.now() - started > timeoutMs) {
        clearInterval(timer); reject(new Error(`후처리 큐 배출 시간초과 pending=${worker.postPending.size} active=${worker.postActive}`));
      }
    }, 20);
  });
}

(async () => {
  const started = Date.now();
  let cursor = 0;
  while (cursor < totalTicks) {
    const end = Math.min(totalTicks, cursor + batchSize);
    for (; cursor < end; cursor += 1) inject(cursor);
    await new Promise((resolve) => setImmediate(resolve));
  }
  const injectedMs = Date.now() - started;
  await waitForDrain();
  await new Promise((resolve) => setTimeout(resolve, 200));
  const elapsedMs = Date.now() - started;
  const load = runtimeMetrics.snapshot();
  const report = {
    totalTicks,
    symbols: codes.length,
    injectionMs: injectedMs,
    totalMs: elapsedMs,
    throughputTicksPerSecond: Number((totalTicks / Math.max(1, injectedMs) * 1000).toFixed(0)),
    eventLoopP95Ms: load.eventLoop.p95Ms,
    eventLoopMaxMs: load.eventLoop.maxMs,
    maxPendingCodes: load.postProcess.maxPendingCodes,
    coalesced: load.postProcess.coalesced,
    processed: load.postProcess.processed,
    errors: load.postProcess.errors,
    rssMb: load.memory.rssMb,
    finalPending: worker.postPending.size,
    finalActive: worker.postActive,
  };
  console.log(JSON.stringify(report, null, 2));
  if (report.errors !== 0) throw new Error(`후처리 오류 ${report.errors}건`);
  if (report.finalPending !== 0 || report.finalActive !== 0) throw new Error('후처리 큐가 완전히 비워지지 않음');
  if (Number(report.eventLoopP95Ms || 0) > 100) throw new Error(`이벤트 루프 p95 지연 과다 ${report.eventLoopP95Ms}ms`);
  if (report.rssMb > 512) throw new Error(`메모리 사용 과다 ${report.rssMb}MB`);
  const reportDocument = {
    version: require('../package.json').version,
    executedAtUtc: new Date().toISOString(),
    environment: `Node.js ${process.version}, dependency-free source load test`,
    scenario: `${codes.length} symbols (12 focus + 18 light, up to 2 promoted), ${totalTicks} virtual 0B trade ticks plus periodic 0D/0w/0F focus-feed events, per-symbol latest-state coalescing, max ${worker.postMaxConcurrency} post-process workers`,
    result: report,
    passed: true,
    limits: 'Synthetic in-process test. It does not reproduce Kiwoom network latency, Lightsail disk latency, Docker CPU throttling, Redis latency, or real Web Push delays; production /api/health metrics must still be observed.',
  };
  fs.writeFileSync(path.join(__dirname, '..', 'LOAD_TEST_REPORT.json'), `${JSON.stringify(reportDocument, null, 2)}\n`, 'utf8');
  console.log(`LOAD CHECK OK: ${codes.length}종목 혼합 실시간 이벤트, 종목별 최신상태 병합, 백프레셔·메모리·이벤트루프 확인`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}).finally(async () => {
  await worker.stop().catch(() => null);
  fs.rmSync(root, { recursive: true, force: true });
});
