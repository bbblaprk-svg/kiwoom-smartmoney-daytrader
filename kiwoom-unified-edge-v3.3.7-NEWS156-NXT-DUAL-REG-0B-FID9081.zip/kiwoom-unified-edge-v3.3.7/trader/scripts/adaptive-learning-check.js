const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kiwoom-v318-learning-'));
process.env.STORE_FILE_PATH = path.join(root, 'store.json');
process.env.STORE_KEY_DIR = path.join(root, 'keys');
process.env.ADAPTIVE_LEARNING_MIN_TOTAL_SAMPLES = '20';
process.env.ADAPTIVE_LEARNING_MIN_BUCKET_SAMPLES = '6';
process.env.ADAPTIVE_LEARNING_MAX_ADJUSTMENT = '6';

const store = require('../lib/store');
const learning = require('../lib/adaptiveLearning');
const performance = require('../lib/signalPerformance');

function outcome(i, good = true) {
  return {
    id: `EARLY-${i}`,
    result: good ? 'WIN' : 'LOSS',
    resultR: good ? 1 : -1,
    learningContext: good ? {
      turnoverRank: 5,
      changePct: 5,
      foreignNet: 100,
      institutionNet: 100,
      preSurgeScore: 88,
      smartMoneyState: 'TURN',
      qualityScore: 88,
    } : {
      turnoverRank: 50,
      changePct: 28,
      foreignNet: -100,
      institutionNet: -100,
      preSurgeScore: 60,
      smartMoneyState: 'NEUTRAL',
      qualityScore: 70,
    },
  };
}

(async () => {
  try {
    await performance.registerDiscoverySignal({
      code: '999999', name: '학습검증', price: 100, stop: 95, target: 105, qualityScore: 80, at: 1_000_000,
      learningContext: { turnoverRank: 4, changePct: 5, foreignNet: 10, institutionNet: 10, preSurgeScore: 80, smartMoneyState: 'TURN' },
    });
    await performance.updatePrice('999999', 105, 1_000_100);
    const persisted = await store.getItem('signal:performance:v1');
    assert.strictEqual(persisted.discoveryOutcomes.length, 1, 'EARLY 학습결과 저장 실패');
    assert.strictEqual(persisted.discoveryOutcomes[0].learningContext.turnoverRank, 4, '학습 context 저장 실패');
    const discoveryOutcomes = [];
    for (let i = 0; i < 20; i += 1) discoveryOutcomes.push(outcome(i, true));
    for (let i = 20; i < 32; i += 1) discoveryOutcomes.push(outcome(i, false));
    await store.setItem('signal:performance:v1', { discoveryOutcomes, outcomes: [], discoveryPending: [], pending: [] });
    const model = await learning.getAdaptiveModel();
    assert.strictEqual(model.enabled, true);
    assert.strictEqual(model.active, true, JSON.stringify(model));
    assert.strictEqual(model.source, 'EARLY');
    const good = learning.scoreAdaptiveAdjustment({ turnoverRank: 4, changePct: 6, foreignNet: 10, institutionNet: 20, preSurgeScore: 90, smartMoneyState: 'TURN', qualityScore: 90 }, model);
    const bad = learning.scoreAdaptiveAdjustment({ turnoverRank: 55, changePct: 29, foreignNet: -10, institutionNet: -20, preSurgeScore: 60, smartMoneyState: 'NEUTRAL', qualityScore: 70 }, model);
    assert(good.score > 0, `좋은 패턴 학습가산 없음 ${JSON.stringify(good)}`);
    assert(bad.score < 0, `나쁜 패턴 학습감점 없음 ${JSON.stringify(bad)}`);
    assert(Math.abs(good.score) <= 6 && Math.abs(bad.score) <= 6, '학습보정 상한 초과');
    await learning.setLearningEnabled(false);
    const off = await learning.getAdaptiveModel();
    assert.strictEqual(off.enabled, false);
    assert.strictEqual(learning.scoreAdaptiveAdjustment({ turnoverRank: 4, changePct: 6 }, off).score, 0);
    console.log(`ADAPTIVE LEARNING CHECK OK: good=${good.score}, bad=${bad.score}, 표본=${model.sampleSize}, 최대보정=±${model.maxAdjustment}`);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch((error) => { console.error(error); process.exit(1); });
