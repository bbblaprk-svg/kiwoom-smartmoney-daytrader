const assert = require('assert');
const fs = require('fs'); const os = require('os'); const path = require('path');
const root = fs.mkdtempSync(path.join(os.tmpdir(),'close-learn-')); process.env.DATA_DIR=root; process.env.STORE_FILE_PATH=path.join(root,'store.json'); process.env.STORE_KEY_DIR=path.join(root,'store.json.d'); process.env.UPSTASH_REDIS_REST_URL=''; process.env.UPSTASH_REDIS_REST_TOKEN=''; process.env.KV_REST_API_URL=''; process.env.KV_REST_API_TOKEN='';
process.env.CLOSE_LEARNING_MIN_TOTAL='20'; process.env.CLOSE_LEARNING_MIN_BUCKET='6';
const { registerDecision, updateFromSnapshot, summary } = require('../lib/closeOutcomeLearning');
(async()=>{
  const decision={action:'CLOSE_BUY',engine:'FLOOR_REVERSAL',score:88,rawScore:88,basis:{decisionPriceWon:100000},plan:{stop:95000,target1:106000,target2:110000},eventContext:{smartState:'TURN',trustNet:100,pensionNet:100}};
  const snap={code:'000001',name:'TEST',krx:{date:'20260804',close:100000,high:101000,low:99000},indicators:{volumeRatio20:1.6,drawdown20Pct:-12}};
  await registerDecision(snap,decision); let s=await summary(); assert.strictEqual(s.pending,1);
  await updateFromSnapshot({code:'000001',krx:{date:'20260805',close:108000,high:111000,low:99000}}); s=await summary(); assert.strictEqual(s.pending,0); assert.strictEqual(s.outcomes,1); assert.strictEqual(s.overall.wins,1); console.log('CLOSE LEARNING CHECK OK: KRX 종가 진입가 기록 + 후속 일봉 목표/손절 평가');
})().catch(e=>{console.error(e);process.exit(1)});
