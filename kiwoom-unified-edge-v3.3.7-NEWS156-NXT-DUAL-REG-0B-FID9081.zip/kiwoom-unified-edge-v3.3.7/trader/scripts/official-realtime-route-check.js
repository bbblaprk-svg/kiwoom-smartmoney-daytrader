const fs=require('fs'); const assert=require('assert');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8'); const store=fs.readFileSync('lib/realtimeStore.js','utf8'); const health=fs.readFileSync('pages/api/health.js','utf8');
assert(worker.includes("type:['0B']")); assert(store.includes("case '0B':"));
assert(worker.includes("type:['0D','0u']")); assert(store.includes("case '0D': processOrderbook"));
assert(worker.includes("type:['0F']")); assert(store.includes("case '0F': processBroker"));
assert(health.includes("trade:'0B'") && health.includes("orderbook:'0D'") && health.includes("broker:'0F'"));
console.log('OFFICIAL_REALTIME_ROUTE_CHECK PASS: 0B trade / 0D orderbook / 0F broker / 0u program');
