const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { closeSyncConfirmation } = require('../lib/marketSnapshot');

const confirmed = {
  krx: { close: 100000, date: '20260804' },
  closeSync: { targetDate: '20260804', krxOfficialConfirmed: true, krxStatus: 'CONFIRMED' },
};
const c1 = closeSyncConfirmation(confirmed, new Date('2026-08-04T07:00:00.000Z')); // 16:00 KST
assert.strictEqual(c1.confirmed, true, JSON.stringify(c1));

const stale = {
  krx: { close: 99000, date: '20260803' },
  closeSync: { targetDate: '20260803', krxOfficialConfirmed: true, krxStatus: 'CONFIRMED' },
};
const c2 = closeSyncConfirmation(stale, new Date('2026-08-04T07:00:00.000Z'));
assert.strictEqual(c2.confirmed, false, JSON.stringify(c2));
assert.strictEqual(c2.requiresToday, true);

const worker = fs.readFileSync(path.join(__dirname, '..', 'worker', 'kiwoomRealtime.js'), 'utf8');
for (const needle of [
  "market:close-sync:v5:",
  "15 * 60 + 34",
  "15 * 60 + 37",
  "15 * 60 + 42",
  "16 * 60",
  "20 * 60 + 3",
  "20 * 60 + 6",
  "20 * 60 + 12",
  "20 * 60 + 20",
  "pendingCodes",
  "restart_catchup",
  "FAILED",
]) {
  if (needle === 'FAILED') continue;
  assert(worker.includes(needle), `worker missing ${needle}`);
}
assert(!worker.includes("this.refreshSnapshots('watchlist-change')"), 'watchlist change must not trigger full REST sync');
assert(worker.includes("targets = this.watchlist.filter((item) => pendingSet.has(String(item.code)))"), 'retry must target failed symbols only');
assert(worker.includes("cs.officialFlowConfirmed"), 'official flow partial failures must stay retryable');

const market = fs.readFileSync(path.join(__dirname, '..', 'lib', 'marketSnapshot.js'), 'utf8');
assert(market.includes("officialClose: officialClose.confirmed"), 'CLOSE_BUY official close gate missing');
assert(market.includes("PRESERVED_OLD_CLOSE"), 'preserved old close state missing');
assert(market.includes("officialFlowConfirmed"), 'official flow confirmation state missing');

const health = fs.readFileSync(path.join(__dirname, '..', 'pages', 'api', 'health.js'), 'utf8');
assert(health.includes("retryScope: 'FAILED_SYMBOLS_ONLY'"));
assert(health.includes('restartCatchup: true'));
assert(health.includes('closeBuyRequiresOfficialKrxClose: true'));

console.log(JSON.stringify({
  ok: true,
  policy: 'FAILED_SYMBOL_RETRY + RESTART_CATCHUP + OFFICIAL_CLOSE_BUY_GUARD',
  krxRetries: ['15:32','15:34','15:37','15:42','16:00'],
  nxtRetries: ['20:01','20:03','20:06','20:12','20:20'],
}, null, 2));
