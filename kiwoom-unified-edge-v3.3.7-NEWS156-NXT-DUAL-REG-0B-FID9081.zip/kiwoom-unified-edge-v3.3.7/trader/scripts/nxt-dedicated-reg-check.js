const {execFileSync}=require('child_process'); execFileSync(process.execPath,['scripts/nxt-dual-reg-v337-check.js'],{stdio:'inherit'});
