const assert = require('assert');
const { evaluateSignal } = require('../lib/signalEngine');
const now = new Date('2026-08-05T00:30:00.000Z'); // 09:30 KST
const base = {
  price:100000, vwap:99850, vwapDistancePct:0.15, recentHigh:100700, recentLow:99500,
  spreadBps:8, updatedAt:now.getTime()-200, activeTier:'FOCUS', tier:'FOCUS', dataCompleteness:95,
  tradeEventCount:20, tradeAgeMs:200, orderbookAgeMs:300, orderbookSampleCount:8,
  programAgeMs:500, programSampleCount:4, brokerAgeMs:5000,
  netBuyAmount5s:18000000, netBuyAmount15s:12000000, netBuyAmount60s:25000000,
  buyAcceleration:9000000, turnoverAcceleration:5000000, turnover1m:80000000,
  strength5:116, strength15:110, tradeStrength:116, buyRatio5:59, buyRatio15:55, buyRatio:56,
  rvol1m:1.2, momentum15sPct:0.25, momentum1mPct:0.45, distanceToRecentHighPct:-0.7, intradayChangePct:2.8,
  orderbookImbalance:1.18, orderbookImbalanceEwma:1.18, orderbookImbalanceDelta:0.04,
  bidReplenishEwma:0.05, askWithdrawalEwma:0.04, orderbookSupportStreak:3,
  programVelocity10s:30000000, programNetAmount:10000000, programTurnedPositive:1,
  smartMoneyBehaviorState:'ACCUMULATION', smartMoneyConfidence:66, smartMoneyState:'ABSORPTION',
  largeNetAmount1m:10000000, largeBuyCount1m:1, largeSellCount1m:0,
  vwapReclaim:false, breakout:false, breakdown:false, drawdownFromHighPct:-0.7, viActive:false,
  marketDataReady:true, relativeStrengthPct:0.4, marketBreadthPct:58, marketAboveVwap:62,
};
const early = evaluateSignal(base, {preIgnitionScore:60}, now);
assert.strictEqual(early.action,'EARLY');
assert.strictEqual(early.preIgnitionEligible,true);
assert.strictEqual(early.lateChaseBlock,false);
assert.strictEqual(early.label,'점화전 사전포착');
const movedAlready = evaluateSignal({...base,intradayChangePct:5.0}, {}, now);
assert.strictEqual(movedAlready.preIgnitionEligible,false, '4.5% 이상은 점화전 단계로 분류하면 안 됨');
const entryCeiling = evaluateSignal({...base,intradayChangePct:6.2}, {}, now);
assert.strictEqual(entryCeiling.lateChaseBlock,true, '6% 이상 신규추격 차단 누락');
assert(entryCeiling.vetoes.some(x=>x.includes('이미 급등')));
const chased = evaluateSignal({...base,intradayChangePct:11,vwapDistancePct:2.2,momentum1mPct:2.5,tradeStrength:150,netBuyAmount5s:100000000,turnover1m:500000000}, {}, now);
assert.strictEqual(chased.lateChaseBlock,true);
assert.notStrictEqual(chased.action,'BUY');
assert(chased.vetoes.some(x=>x.includes('이미 급등')));
console.log('PRE_IGNITION_CHECK PASS');
