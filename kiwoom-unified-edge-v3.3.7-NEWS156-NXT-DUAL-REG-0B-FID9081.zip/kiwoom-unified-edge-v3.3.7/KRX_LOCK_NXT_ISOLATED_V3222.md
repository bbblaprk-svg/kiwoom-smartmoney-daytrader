# v3.2.22 KRX LOCK + NXT ISOLATED

- KRX 실증 경로를 bare 6자리 + 0B로 고정한다.
- NXT 등록 실험은 별도 WebSocket 연결에서만 수행한다.
- NXT tick은 FID 9081이 NXT 또는 2를 명시할 때만 신뢰한다.
- NXT probe 실패가 KRX primary WebSocket의 REG/체결 수신을 절대 변경하지 않는다.
- 활성장 장중 판단은 WebSocket fresh 체결만 사용하며 REST/전일종가 fallback은 신규 진입 판단에 사용하지 않는다.
- NXT probe는 NXT 문자열형 stex_tp를 먼저 시도하고 7초 동안 확정 tick이 없으면 숫자형 2를 추가 probe한다.
