# v3.2.21 NXT DEDICATED REG

- KRX/NXT WebSocket registration is isolated by exchange-map item objects (`jmcode`, `stex_tp`).
- KRX uses `stex_tp=1`, NXT uses `stex_tp=2`; SOR is reserved as `3`.
- Trade route is fixed to official `0B`; orderbook `0D`; broker `0F`; program `0u`.
- FID 9081 is the final venue truth gate. A tick tagged KRX never increments NXT firstTick, even when received after an NXT registration request.
- Active-market current price and PRE-IGNITION/EARLY/PRE-BUY/BUY remain WebSocket-only and fail closed when fresh ticks are absent.
