# v3.3.3 VALIDATION REPORT

## Scope
- REALTIME FOUNDATION feature/signal path preserved.
- Domestic WebSocket REG uses string stock codes only.
- KRX trade core: bare 6-digit + 0B.
- NXT trade core: exchange-specific `6-digit_NX` + 0B, one core REG per code so unsupported NXT symbols are isolated.
- REAL venue truth remains FID 9081 only.
- Missing NXT data never causes whole-socket churn; transport reconnect is driven only by stale WebSocket frames.
- Close freshness/startup catch-up from v3.3.1 preserved.

## Local checks
- `npm run check`: PASS
- 30 symbols / 30,000 mixed events: PASS
- errors=0, finalPending=0, finalActive=0
- throughput=112,782 events/sec
- event-loop p95=21.76 ms

## Build note
Local `npm run build` was not reproducible in this tool environment because Next.js dependencies are not installed and the internal npm mirror does not contain the pinned package set. The AWS Dockerfile performs `npm install -> npm run check -> 30k load -> npm run build` before container replacement.

## Live acceptance
During NXT active hours deployment is successful only if `NXT_SUFFIX` has REG ACK and a REAL 0B frame confirms NXT through FID 9081, yielding `NXT firstTick>0`, `fresh>0`, `venueConfirmed=true`. Otherwise rollback is required.
