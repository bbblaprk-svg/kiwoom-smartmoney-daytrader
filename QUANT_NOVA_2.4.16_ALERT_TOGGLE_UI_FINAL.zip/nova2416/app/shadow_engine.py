from __future__ import annotations
from collections import defaultdict
from pathlib import Path
import json, gzip, statistics, math

POLICY='SHADOW_SCORE_V2_DEDUP_GROUP_CAP_ADAPTIVE_LOAD_SHED_OBSERVE_ONLY'
GROUPS={
    'base': ('rest',),
    'flow': ('buy_pressure','smart_money'),
    'volume': ('volume_accel',),
    'momentum': ('impulse','micro_breakout'),
    'position': ('vwap_micro','vwap_session'),
    'confirm': ('dual_venue','sector','orderbook','event','second_wave'),
    'dna': ('rally_dna',),
    'penalty': ('penalty_rate','penalty_impulse','penalty_one_tick'),
}
CAPS={'base':25.0,'flow':20.0,'volume':16.0,'momentum':18.0,'position':7.0,'confirm':18.0,'dna':8.0}

def _num(x,default=0.0):
    try:return float(x)
    except:return float(default)

def _clamp(x,lo=0.0,hi=100.0):return max(lo,min(hi,float(x)))

def _group_value(name, parts):
    raw=sum(_num(parts.get(k)) for k in GROUPS[name])
    if name=='penalty':return raw,raw
    cap=CAPS[name]
    return raw,max(-cap,min(cap,raw))

def _score(parts, omitted_feature=None):
    p=dict(parts)
    if omitted_feature:p[omitted_feature]=0.0
    groups={}
    for g in GROUPS:
        raw,capped=_group_value(g,p);groups[g]={'raw':round(raw,4),'capped':round(capped,4),'cap':CAPS.get(g)}
    score=_clamp(sum(x['capped'] for x in groups.values()))
    return round(score,2),groups

def build_shadow_observation(live_parts:dict, loo_features=None, load_mode='FULL'):
    """Pure function: no Candidate/STATE reference and no live-parameter mutation.

    loo_features=None => all non-penalty features; iterable => selected subset;
    empty iterable => no LOO. The base/group shadow score is identical in all modes.
    """
    parts={k:round(_num(v),6) for k,v in dict(live_parts or {}).items() if k!='live_score'}
    shadow,groups=_score(parts)
    allowed=None if loo_features is None else set(loo_features)
    loo={}
    for feat in parts:
        if feat.startswith('penalty_') or (allowed is not None and feat not in allowed):continue
        s,_=_score(parts,feat);loo[feat]=round(shadow-s,3)  # positive => feature raised shadow score
    mode=str(load_mode or 'FULL').upper()
    return {'policy':POLICY,'auto_apply':False,'load_mode':mode,'loo_feature_count':len(loo),'live_score':round(_num((live_parts or {}).get('live_score')),2),'shadow_score':shadow,'groups':groups,'live_parts':parts,'leave_one_out':loo}

def _read_jsonl(p):
    out=[]
    try:
        op=gzip.open if str(p).endswith('.gz') else open
        with op(p,'rt',encoding='utf-8') as f:
            for line in f:
                try:out.append(json.loads(line))
                except:pass
    except:pass
    return out

def shadow_oos_audit(data_dir:Path, horizon_sec=1800):
    """Chronological replay-only benchmark. Diagnostic only; never changes live parameters."""
    data_dir=Path(data_dir);rows=[]
    for p in data_dir.glob('replay_journal_*.jsonl'):rows+=_read_jsonl(p)
    arch=data_dir/'archive'
    if arch.exists():
        for p in arch.glob('20??????/replay_journal.jsonl.gz'):rows+=_read_jsonl(p)
    rows=[x for x in rows if x.get('shadow_score') is not None and _num(x.get('price'))>0 and _num(x.get('ts'))>0]
    rows.sort(key=lambda x:_num(x.get('ts')))
    by=defaultdict(list)
    for x in rows:by[(str(x.get('day')),str(x.get('code')),str(x.get('venue'))) ].append(x)
    samples=[];last_key={}
    for x in rows:
        key=(str(x.get('day')),str(x.get('code')),str(x.get('venue')));t0=_num(x.get('ts'));p0=_num(x.get('price'))
        # One observation per code/venue per 10 minutes prevents a single runner dominating the audit.
        if t0-_num(last_key.get(key))<600:continue
        fut=[z for z in by[key] if horizon_sec-120 <= _num(z.get('ts'))-t0 <= horizon_sec+120 and _num(z.get('price'))>0]
        if not fut:continue
        z=min(fut,key=lambda q:abs((_num(q.get('ts'))-t0)-horizon_sec));ret=(_num(z.get('price'))/p0-1)*100
        samples.append({'day':x.get('day'),'live':_num(x.get('score')),'shadow':_num(x.get('shadow_score')),'ret':ret});last_key[key]=t0
    n=len(samples);status='INSUFFICIENT_OOS' if n<100 else 'PRELIMINARY' if n<500 else 'EVALUABLE'
    def topq(field):
        if not samples:return {'n':0,'avg_ret30':None,'positive_pct':None}
        xs=sorted(samples,key=lambda r:r[field],reverse=True);k=max(1,math.ceil(len(xs)*.25));q=xs[:k];rets=[r['ret'] for r in q]
        return {'n':len(q),'avg_ret30':round(statistics.mean(rets),4),'median_ret30':round(statistics.median(rets),4),'positive_pct':round(sum(v>0 for v in rets)/len(rets)*100,2)}
    live=topq('live');shadow=topq('shadow')
    return {'version':'SHADOW_OOS_V1','policy':POLICY,'auto_apply':False,'samples':n,'status':status,'min_samples':100,'strong_samples':500,'horizon_sec':horizon_sec,'live_top_quartile':live,'shadow_top_quartile':shadow,'shadow_minus_live_avg_ret30':round((shadow['avg_ret30'] or 0)-(live['avg_ret30'] or 0),4) if n else None,'promotion_gate':'HUMAN_APPROVAL_ONLY_AFTER_EVALUABLE_OOS; NEVER_AUTO_APPLY'}
