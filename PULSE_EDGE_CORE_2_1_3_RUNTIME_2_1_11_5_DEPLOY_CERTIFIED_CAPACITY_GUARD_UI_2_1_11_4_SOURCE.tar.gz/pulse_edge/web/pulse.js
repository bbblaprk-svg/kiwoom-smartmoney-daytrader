const $=s=>document.querySelector(s);
const fmt=(v,d=2)=>v==null||Number.isNaN(Number(v))?'—':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d});
const pct=v=>v==null?'—':`${Number(v)>=0?'+':''}${fmt(v,2)}%`;
const tm=v=>{if(!v)return '—';try{return new Date(v).toLocaleTimeString('ko-KR',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'})}catch{return '—'}};
const text=(el,v)=>{el.textContent=v==null?'—':String(v)};
const stockName=r=>{const n=String(r?.name||'').trim();return n||'종목명 확인중'};
const tone=(el,val)=>{el.classList.remove('positive','negative','warning-text');if(Number(val)>0)el.classList.add('positive');else if(Number(val)<0)el.classList.add('negative')};
const resetTone=el=>el.classList.remove('positive','negative','warning-text','age-fresh','age-warn','age-stale');
const freshness=(el,sec)=>{el.classList.remove('age-fresh','age-warn','age-stale');const n=Number(sec);if(!Number.isFinite(n))return;if(n<=3.5)el.classList.add('age-fresh');else if(n<=7)el.classList.add('age-warn');else el.classList.add('age-stale')};
const setVersion=v=>{const full=String(v||'PULSE');const el=$('#version');const rel=$('#releaseLabel');const num=(full.match(/\d+\.\d+\.\d+/)||['PULSE'])[0];text(el,num);el.title=full;if(rel){const fixed=rel.dataset.uiLabel;if(fixed){text(rel,fixed);rel.title=`CORE ${full} · UI ${fixed}`;return}let label=full.toLowerCase().includes('early-buy-expansion')?'EARLY BUY EXPANSION':full.toLowerCase().includes('async-fresh-rotation')?'ASYNC FRESH ROTATION':full.replace(/^\d+\.\d+\.\d+-?/,'').replace(/-/g,' ').toUpperCase()||'RELEASE';text(rel,label);rel.title=full}};
async function api(path,timeoutMs=2500){const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),timeoutMs);try{const r=await fetch(path,{cache:'no-store',signal:ctl.signal});if(!r.ok)throw new Error(path);return await r.json()}finally{clearTimeout(timer)}}
let safety={state:'FROZEN',items:[]};
const ui={decision:[],preopen:[],prebuy:[],discovery:[],candidateHistory:[],ledger:[],performance:{},nxtEarlyFlow:[],nxtEarlyBuy:[],nxtCloseBet:[],krxDual:[],transition:[],closeClass:[]};
let currentSession={operator_phase:'—',preopen_observation_active:false,action_gate_open:false};
let fastBusy=false,slowBusy=false,fastTimer=null,slowTimer=null;
const candidateHistoryBuffer=[];const candidateHistorySig=new Map();

function make(tag,cls){const el=document.createElement(tag);if(cls)el.className=cls;return el}
function makeCell(){return make('td')}
function initDecisionSlots(){
  const root=$('#decisionCards');
  for(let i=0;i<3;i++){
    const card=make('article','decision-card empty');
    const top=make('div','decision-top');
    const rank=make('span','rank'); const badge=make('span','badge'); top.append(rank,badge);
    const body=make('div'); const symbol=make('div','decision-symbol'); const price=make('div','decision-price');
    const change=make('span'); price.append(document.createTextNode('— '),change);
    const meta=make('div','decision-meta');
    const defs=[['CONFLUENCE','confluence'],['SMART FLOW','flow'],['SPREAD','spread'],['ENTRY REF','entryRef'],['INVALIDATION','invalidation'],['DATA AGE','age']];
    const metrics={};
    defs.forEach(([label,key])=>{const box=make('div','metric');const l=make('label');const b=make('b');text(l,label);box.append(l,b);meta.append(box);metrics[key]=b});
    body.append(symbol,price,meta);
    const foot=make('div','decision-foot');const footLeft=make('span');const footRight=make('span');foot.append(footLeft,footRight);
    card.append(top,body,foot);root.append(card);
    ui.decision.push({card,rank,badge,symbol,price,priceText:price.firstChild,change,metrics,footLeft,footRight});
  }
}
function initRows(tbodyId,count,cols,target){
  const tbody=$(tbodyId);
  for(let r=0;r<count;r++){
    const tr=make('tr','placeholder');const cells=[];
    for(let c=0;c<cols;c++){const td=makeCell();text(td,'—');tr.append(td);cells.push(td)}
    tbody.append(tr);target.push({tr,cells});
  }
}
function initPerformance(){
  const root=$('#performance');
  [['10M','captured_10m','avg_10m_return_pct'],['30M','captured_30m','avg_30m_return_pct'],['CLOSE','captured_close','avg_close_return_pct'],['1D','captured_1d','avg_1d_return_pct'],['3D','captured_3d','avg_3d_return_pct'],['5D','captured_5d','avg_5d_return_pct']].forEach(([label,nk,vk])=>{
    const box=make('div','perf');const l=make('label');const strong=make('strong');const small=make('small');text(l,label);text(strong,'—');text(small,'n=0');box.append(l,strong,small);root.append(box);ui.performance[label]={strong,small,nk,vk};
  });
}
function initFixedDom(){
  initDecisionSlots();
  initRows('#preopenBody',10,11,ui.preopen);
  initRows('#prebuyBody',10,13,ui.prebuy);
  initRows('#discoveryBody',10,10,ui.discovery);
  initRows('#candidateHistoryBody',20,10,ui.candidateHistory);
  initRows('#ledgerBody',10,10,ui.ledger);
  initRows('#nxtEarlyFlowBody',10,12,ui.nxtEarlyFlow);
  initRows('#nxtEarlyBuyBody',10,12,ui.nxtEarlyBuy);
  initRows('#nxtCloseBetBody',10,12,ui.nxtCloseBet);
  initRows('#krxDualBody',10,16,ui.krxDual);
  initRows('#transitionBody',8,8,ui.transition);
  initRows('#closeClassBody',8,8,ui.closeClass);
  initPerformance();
}
function clearRow(row){row.tr.className='placeholder';row.cells.forEach(c=>{text(c,'—');resetTone(c)})}
function fillRow(row,values,tones={}){row.tr.className='';row.cells.forEach(resetTone);values.forEach((v,i)=>text(row.cells[i],v));Object.entries(tones).forEach(([idx,val])=>tone(row.cells[Number(idx)],val))}

function applySafety(s){
  safety=s||safety;const st=safety.state||'FROZEN';const preopen=!!safety.preopen_observation_active;text($('#safetyState'),preopen?'OBSERVE':st);text($('#safetyReason'),(safety.reason_codes||[]).join(' · ')||'NORMAL');
  document.body.classList.remove('safety-frozen','safety-locked');const b=$('#safetyBanner');b.className='safety-banner hidden';text(b,'');
  if(preopen){b.className='safety-banner warning';text(b,`${safety.operator_phase||'PREOPEN'} · 08:00부터 실데이터 관찰 중 · 매수성 표현은 09:00 정규장까지 잠금`)}
  else if(st==='WARNING'){b.className='safety-banner warning';text(b,'DATA WARNING · 후보는 표시되지만 데이터 품질이 저하되었습니다.')}
  else if(st==='FROZEN'){document.body.classList.add('safety-frozen');b.className='safety-banner frozen';text(b,'DATA FROZEN · 신규 행동표시는 잠겼습니다. 새 정상 체결/호가와 재평가를 기다립니다.')}
  else if(st==='LOCKED'){document.body.classList.add('safety-locked');b.className='safety-banner locked';text(b,'DISPLAY LOCKED · Runtime CRITICAL 또는 Feed 비활성. 매수성 표현을 표시하지 않습니다.')}
}
function renderDecisions(s){
  const locked=['FROZEN','LOCKED'].includes(s.state)||s.action_gate_open===false,rows=s.items||[];
  for(let i=0;i<3;i++){
    const slot=ui.decision[i],r=rows[i];
    resetTone(slot.metrics.age);
    if(!r){
      slot.card.className='decision-card empty';text(slot.rank,`#${i+1}`);text(slot.badge,'NO QUALIFIED ROW');text(slot.symbol,'—');slot.priceText.nodeValue='조건 충족 후보 없음 ';text(slot.change,'');resetTone(slot.change);
      Object.values(slot.metrics).forEach(x=>{text(x,'—');resetTone(x)});text(slot.footLeft,'ENTRY/A+ 자격 후보만 표시');text(slot.footRight,'SHADOW');continue;
    }
    slot.card.className='decision-card';text(slot.rank,`#${r.rank||i+1} · ${r.venue||'—'}`);text(slot.badge,locked?s.state:(r.source_stage||'—'));text(slot.symbol,stockName(r));slot.priceText.nodeValue=`${fmt(r.price,0)} `;text(slot.change,pct(r.change_rate));tone(slot.change,r.change_rate);
    text(slot.metrics.confluence,`${fmt(r.confluence_score_100,0)} · ${r.evidence_count||0}/5`);text(slot.metrics.flow,`${fmt(r.smart_flow_score_100,0)} · ${r.smart_flow_confirmed_windows||0}W`);text(slot.metrics.spread,`${fmt(r.spread_pct,2)}%`);
    const holdText=s.state==='LOCKED'?'LOCKED':'DATA HOLD';
    text(slot.metrics.entryRef,locked?holdText:`${fmt(r.entry_reference_low,0)}–${fmt(r.entry_reference_high,0)}`);
    text(slot.metrics.invalidation,locked?holdText:fmt(r.invalidation_price,0));
    if(locked){slot.metrics.entryRef.classList.add('warning-text');slot.metrics.invalidation.classList.add('warning-text')}else{resetTone(slot.metrics.entryRef);resetTone(slot.metrics.invalidation)}
    text(slot.metrics.age,`${fmt(r.source_frame_age_sec,1)}s`);freshness(slot.metrics.age,r.source_frame_age_sec);text(slot.footLeft,locked?'마지막 정상 후보 · 행동표현 잠금':(r.primary_route||'—'));text(slot.footRight,r.sector_name||'—');
  }
  text($('#currentNote'),locked?'마지막 정상 후보를 FROZEN/LOCKED 상태로 보존 중':'조건을 통과한 종목만 최대 3개');
}
function renderPreopen(data){
  const section=$('#preopenVisibleSection');
  const active=!!currentSession.preopen_observation_active;
  section?.classList.toggle('hidden',!active);
  if(!active)return;
  const phase=currentSession.operator_phase||'PREOPEN';
  text($('#preopenPhaseLabel'),phase);
  const rows=(data.items||[]).slice(0,10);
  for(let i=0;i<10;i++){
    const r=rows[i],row=ui.preopen[i];
    if(!r){clearRow(row);continue}
    const stage=String(r.stage||'OBSERVE').replace('PRE_SHADOW','WATCH');
    fillRow(row,[i+1,stockName(r),r.venue||'—',stage,fmt(r.price,0),pct(r.change_rate),fmt(r.raw_score_100,0),fmt(r.foreign_absorption_score,0),fmt(r.rs_level,2),fmt(r.money_acceleration,2),`${fmt(r.evidence_age_sec,1)}s`],{5:r.change_rate});
    freshness(row.cells[10],r.evidence_age_sec);
  }
  rememberCandidateRows(rows,'PREOPEN','상태/점수 변화');
  text($('#preopenStamp'),`${phase} · ${tm(data.last_refresh_at)}`);
}
function renderPrebuy(data){
  const rows=(data.items||[]).slice(0,10),locked=['FROZEN','LOCKED'].includes(safety.state);
  for(let i=0;i<10;i++){const r=rows[i],row=ui.prebuy[i];if(!r){clearRow(row);continue}const action=locked?'DATA HOLD':(r.action||'WATCH');fillRow(row,[i+1,stockName(r),r.venue||'—',action,r.absorption_stage||r.stage||'—',fmt(r.action_signal_price||r.price,0),pct(r.change_rate),`${r.evidence_count??'—'}/5`,compactModel(r.absorption_model),fmt(r.absorption_score_100,0),r.selling_deceleration_confirmed?'DECEL':'—',r.absorption_price_hold_pass?'PASS':'—',`${fmt(r.upstream_asof_age_sec,1)}s`],{6:r.change_rate});freshness(row.cells[12],r.upstream_asof_age_sec)}
  rememberCandidateRows(rows,'PRE-BUY','판정 변화');
  text($('#prebuyStamp'),tm(data.last_refresh_at));
}
function renderDiscovery(data){
  const rows=(data.items||[]).slice(0,10);
  for(let i=0;i<10;i++){const r=rows[i],row=ui.discovery[i];if(!r){clearRow(row);continue}fillRow(row,[i+1,stockName(r),r.venue||'—',fmt(r.price??r.current_price,0),pct(r.change_rate),fmt(r.raw_score_100,0),fmt(r.foreign_absorption_score,0),fmt(r.rs_score,0),fmt(r.money_acceleration,2),`${fmt(r.evidence_age_sec,1)}s`],{4:r.change_rate});freshness(row.cells[9],r.evidence_age_sec)}
  rememberCandidateRows(rows,'DISCOVERY','수급/강도 변화');
  text($('#discoveryStamp'),tm(data.last_refresh_at));
}
function ensureCandidateHistoryRows(count){
  const tbody=$('#candidateHistoryBody');const target=Math.min(500,Math.max(20,count));
  while(ui.candidateHistory.length<target){const tr=make('tr','placeholder');const cells=[];for(let c=0;c<10;c++){const td=makeCell();text(td,'—');tr.append(td);cells.push(td)}tbody.append(tr);ui.candidateHistory.push({tr,cells});}
}
function renderCandidateHistory(data){
  const rows=(data.items||[]).slice(0,500);ensureCandidateHistoryRows(rows.length);
  for(let i=0;i<ui.candidateHistory.length;i++){const r=rows[i],row=ui.candidateHistory[i];if(!r){clearRow(row);continue}fillRow(row,[tm(r.event_at),stockName(r),r.venue||'—',r.stage||'—',r.route||'—',fmt(r.price,0),pct(r.change_rate),fmt(r.score,0),fmt(r.flow,0),r.reason||'—'],{6:r.change_rate});}
}
function rememberCandidateRows(rows,route,reason){
  const now=new Date().toISOString();
  (rows||[]).forEach(r=>{
    const symbol=String(r?.symbol||'').trim();if(!symbol)return;
    const venue=r.venue||'—';const stage=r.action||r.stage||r.absorption_stage||'WATCH';
    const scoreRaw=r.score_100??r.raw_score_100??r.absorption_score_100;const flowRaw=r.foreign_absorption_score??r.absorption_ratio??r.smart_flow_score_100;
    const score=scoreRaw==null?null:Number(scoreRaw);const flow=flowRaw==null?null:Number(flowRaw);
    const sig=[stage,Number.isFinite(score)?Math.round(score):'—',Number.isFinite(flow)?Math.round(flow):'—'].join('|');
    const key=`${route}|${venue}|${symbol}`;if(candidateHistorySig.get(key)===sig)return;candidateHistorySig.set(key,sig);
    candidateHistoryBuffer.unshift({event_at:now,name:stockName(r),symbol,venue,stage,route,price:r.price??r.nxt_price??r.action_signal_price,change_rate:r.change_rate,score:Number.isFinite(score)?score:null,flow:Number.isFinite(flow)?flow:null,reason});
  });
  if(candidateHistoryBuffer.length>500)candidateHistoryBuffer.length=500;
  renderCandidateHistory({items:candidateHistoryBuffer});
}
function renderLedger(data){
  const rows=(data.items||[]).slice(0,10);
  for(let i=0;i<10;i++){const r=rows[i],row=ui.ledger[i];if(!r){clearRow(row);continue}fillRow(row,[tm(r.signal_at),stockName(r),r.venue||'—',r.signal_action||'SIGNAL',r.primary_route||'—',fmt(r.signal_price,0),fmt(r.last_price,0),pct(r.mfe_pct),pct(r.mae_pct),r.status||'—']);}
}
function renderPerformance(p){
  const routes=p.by_primary_route||[];
  Object.values(ui.performance).forEach(({strong,small,nk,vk})=>{let n=0,sum=0;routes.forEach(r=>{const c=Number(r[nk]||0),v=r[vk];if(c&&v!=null){n+=c;sum+=Number(v)*c}});const avg=n?sum/n:null;text(strong,pct(avg));tone(strong,avg);text(small,`n=${n}`)});
}
function compactModel(v){
  const s=String(v||'—');return s.replace('A_FOREIGN_ABSORB','A').replace('B1_FUND_ABSORB','B1').replace('B2_PENSION_ABSORB','B2').replace('B3_FUND_PENSION_ABSORB','B3').replace('DUAL_CONFIRMED','DUAL').replace('CORPORATE_ABSORB','CORP');
}
function cap(v){if(v==null)return '—';const n=Number(v);if(!Number.isFinite(n))return '—';if(n>=1e12)return `${fmt(n/1e12,2)}조`;if(n>=1e8)return `${fmt(n/1e8,0)}억`;return fmt(n,0)}
function renderKrxDual(data){
  const rows=(data.items||[]).slice(0,10),locked=['FROZEN','LOCKED'].includes(safety.state);
  for(let i=0;i<10;i++){
    const r=rows[i],row=ui.krxDual[i];if(!r){clearRow(row);continue}
    const grace=(r.flags||[]).includes('MEMBERSHIP_GRACE');
    const stage=locked?'DATA HOLD':(grace?'GRACE':r.stage);
    const cd=r.current_data||{};
    const same=cd.same_time_avg20_ratio==null?'—':`${fmt(Number(cd.same_time_avg20_ratio)*100,0)}%`;
    const stable=r.membership_committed?'COMMIT':`${fmt(r.membership_age_sec,0)}s`;
    fillRow(row,[r.rank||i+1,stockName(r),compactModel(r.model),stage,fmt(r.price,0),pct(r.change_rate),fmt(r.score_100,0),fmt(r.price_hold_score_25,0),r.absorption_ratio==null?'—':fmt(r.absorption_ratio,2),r.seller_decel_count??'—',pct(r.vwap_distance_pct),fmt(r.market_rs,2),fmt(r.sector_rs,2),same,cap(cd.market_cap_est_krw),stable],{5:r.change_rate,10:r.vwap_distance_pct,11:r.market_rs,12:r.sector_rs});
    if(grace)row.cells[3].classList.add('nxt-grace');if(r.membership_committed)row.cells[15].classList.add('nxt-committed');
  }
  rememberCandidateRows(rows,'DUAL/PH','단계/점수 변화');
  text($('#krxBoardStamp'),tm(data.last_refresh_at));
}
function renderTransitions(data){
  const rows=(data.items||[]).slice(0,8);
  for(let i=0;i<8;i++){const r=rows[i],row=ui.transition[i];if(!r){clearRow(row);continue}const move=(r.from_stage||r.to_stage)?`${r.from_stage||'—'}→${r.to_stage||'—'}`:'—';fillRow(row,[tm(r.alert_at),stockName(r),compactModel(r.model),r.event_type||'—',move,fmt(r.score_100,0),r.absorption_ratio==null?'—':fmt(r.absorption_ratio,2),r.price_hold_pass?'PASS':'—']);}
}
function renderCloseClasses(data){
  const rows=(data.items||[]).slice(0,8);
  for(let i=0;i<8;i++){const r=rows[i],row=ui.closeClass[i];if(!r){clearRow(row);continue}fillRow(row,[r.trading_day||'—',stockName(r),compactModel(r.model),r.classification||'—',r.stage||'—',fmt(r.score_100,0),fmt(r.price_hold_score_25,0),r.absorption_ratio==null?'—':fmt(r.absorption_ratio,2)]);}
}
function renderMissedSummary(data){const s=data.summary||{},st=s.status||{};const parts=[];if(st.CAUGHT_PREEMPTIVE!=null)parts.push(`선행 ${st.CAUGHT_PREEMPTIVE}`);if(st.MISSED!=null)parts.push(`미포착 ${st.MISSED}`);if(st.EXCLUDED_OR_UNVERIFIED!=null)parts.push(`제외 ${st.EXCLUDED_OR_UNVERIFIED}`);text($('#missedSummary'),parts.join(' · ')||'장후 대기')}

function setNxtPhaseStamp(id,state){
  const el=$(id);text(el,state||'WAITING');el.classList.remove('nxt-active','nxt-waiting','nxt-closed');
  if(state==='ACTIVE')el.classList.add('nxt-active');else if(state==='CLOSED')el.classList.add('nxt-closed');else el.classList.add('nxt-waiting');
}
function renderNxtBoard(view,target,stampId){
  const rows=(view?.items||[]).slice(0,10),locked=['FROZEN','LOCKED'].includes(safety.state);
  setNxtPhaseStamp(stampId,view?.phase_state||'WAITING');
  for(let i=0;i<10;i++){
    const r=rows[i],row=target[i];if(!r){clearRow(row);continue}
    const grace=(r.flags||[]).includes('MEMBERSHIP_GRACE');
    const stage=locked?'DATA HOLD':(grace?'GRACE':r.stage);
    const stable=r.membership_committed?'COMMIT':`${fmt(r.membership_age_sec,0)}s`;
    fillRow(row,[r.rank||i+1,stockName(r),stage,fmt(r.nxt_price,0),pct(r.change_rate),fmt(r.score_100,0),r.aggressive_buy_ratio_30s==null?'—':`${fmt(Number(r.aggressive_buy_ratio_30s)*100,1)}%`,fmt(r.ofi_2m,0),pct(r.nxt_premium_pct),r.spread_pct==null?'—':`${fmt(r.spread_pct,2)}%`,pct(r.vwap_distance_pct),stable],{4:r.change_rate,8:r.nxt_premium_pct,10:r.vwap_distance_pct});
    if(grace)row.cells[2].classList.add('nxt-grace');
    if(r.membership_committed)row.cells[11].classList.add('nxt-committed');
  }
}
function renderNxtOperations(data){
  const b=data.boards||{};
  renderNxtBoard(b.NXT_EARLY_FLOW,ui.nxtEarlyFlow,'#nxtEarlyFlowState');
  renderNxtBoard(b.NXT_EARLY_BUY,ui.nxtEarlyBuy,'#nxtEarlyBuyState');
  renderNxtBoard(b.NXT_CLOSE_BET,ui.nxtCloseBet,'#nxtCloseBetState');
}
async function fastPoll(){
  if(fastBusy)return;fastBusy=true;
  try{
    const res=await Promise.allSettled([api('/api/presentation/current-decision',2200),api('/api/runtime-truth',2200),api('/api/session',2200),api('/health',2200)]);
    const [ps,rr,ss,hh]=res;
    if(ps.status==='fulfilled'){applySafety(ps.value);renderDecisions(ps.value)}
    else{applySafety({state:'FROZEN',reason_codes:['presentation_api_unreachable'],items:safety.items||[]});renderDecisions(safety)}
    if(rr.status==='fulfilled'){const r=rr.value;text($('#feedState'),r.feed_health||'—');text($('#feedAge'),`last payload ${fmt(r.metrics?.last_payload_age_sec,1)}s`);freshness($('#feedAge'),r.metrics?.last_payload_age_sec);text($('#runtimeState'),r.load_stage||'—');text($('#runtimeMetric'),`CPU ${fmt(r.metrics?.cpu_pct,1)}% · RSS ${fmt(r.metrics?.memory_pct,1)}% · lag ${fmt(r.metrics?.event_loop_lag_sec,2)}s`)}
    else{text($('#feedState'),'API WAIT');text($('#runtimeState'),'API WAIT')}
    if(ss.status==='fulfilled'){const session=ss.value;currentSession=session;text($('#sessionState'),session.operator_phase||session.phase||'—');text($('#sessionDay'),session.trading_day||'—');const pre=$('#preopenVisibleSection');if(pre)pre.classList.toggle('hidden',!session.preopen_observation_active)}
    if(hh.status==='fulfilled')setVersion(hh.value.version);
    text($('#lastRefresh'),`updated ${new Date().toLocaleTimeString('ko-KR',{hour12:false})}`);
  }finally{fastBusy=false}
}
async function slowPoll(){
  if(slowBusy)return;slowBusy=true;
  try{
    const jobs=[
      [api('/api/smart-money/top?limit=10',5000),renderPreopen],
      [api('/api/operator/krx-prebuy-top?limit=10',5000),renderPrebuy],
      [api('/api/operator/krx-discovery-top?limit=10',5000),renderDiscovery],
      [api('/api/ledger/recent?limit=10',5000),renderLedger],
      [api('/api/performance/summary?limit=500',5000),renderPerformance],
      [api('/api/nxt-operations-board',5000),renderNxtOperations],
      [api('/api/krx-operations-board',5000),renderKrxDual],
      [api('/api/transition-alerts?limit=8',5000),renderTransitions],
      [api('/api/krx-close-classifications?limit=8',5000),renderCloseClasses],
      [api('/api/missed-opportunities/summary',5000),renderMissedSummary],
    ];
    const res=await Promise.allSettled(jobs.map(x=>x[0]));
    res.forEach((r,i)=>{if(r.status==='fulfilled')jobs[i][1](r.value)});
  }finally{slowBusy=false}
}
function fastCadence(){return document.hidden?15000:2000}
function slowCadence(){return document.hidden?30000:5000}
async function fastLoop(){await fastPoll();clearTimeout(fastTimer);fastTimer=setTimeout(fastLoop,fastCadence())}
async function slowLoop(){await slowPoll();clearTimeout(slowTimer);slowTimer=setTimeout(slowLoop,slowCadence())}
function resumeVisible(){if(document.hidden)return;clearTimeout(fastTimer);clearTimeout(slowTimer);fastLoop();slowLoop()}

document.addEventListener('visibilitychange',resumeVisible);
initFixedDom();
setInterval(()=>text($('#clock'),new Date().toLocaleTimeString('ko-KR',{hour12:false})),1000);
fastLoop();slowLoop();
