from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class DataTrust(StrEnum):
    LIVE = "LIVE"
    CURRENT_SESSION = "CURRENT_SESSION"
    HISTORICAL_REFERENCE = "HISTORICAL_REFERENCE"
    UNAVAILABLE = "UNAVAILABLE"


class SectorMoneyMember(BaseModel):
    symbol: str
    money_5m: float | None = None
    money_acceleration: float | None = None
    change_rate: float | None = None


class CurrentEnrichmentFrame(BaseModel):
    venue: Venue = Venue.KRX
    symbol: str
    asof: datetime
    price: float | None = None
    change_rate: float | None = None

    return_1d_pct: float | None = None
    return_3d_pct: float | None = None
    return_5d_pct: float | None = None
    return_reference_trust: DataTrust = DataTrust.UNAVAILABLE

    current_cumulative_volume: float | None = None
    current_cumulative_amount: float | None = None
    avg20_daily_volume: float | None = None
    avg20_daily_traded_value_raw: float | None = None
    intraday_volume_vs_20d_daily: float | None = None
    intraday_value_vs_20d_daily: float | None = None
    daily_baseline_days: int = 0
    daily_baseline_trust: DataTrust = DataTrust.UNAVAILABLE

    money_5m: float | None = None
    previous_observed_same_time_money_5m: float | None = None
    same_time_avg20_money_5m: float | None = None
    previous_same_time_ratio: float | None = None
    same_time_avg20_ratio: float | None = None
    same_time_baseline_days: int = 0
    same_time_reference_trust: DataTrust = DataTrust.UNAVAILABLE

    listed_shares: float | None = None
    market_cap_est_krw: float | None = None
    market_cap_trust: DataTrust = DataTrust.UNAVAILABLE

    sector_code: str | None = None
    sector_name: str | None = None
    sector_money_rank: int | None = None
    sector_money_stage: str = "NO_DATA"
    sector_second_to_leader_ratio: float | None = None
    sector_third_to_leader_ratio: float | None = None
    sector_top3_positive_accel_count: int = 0
    sector_top3: list[SectorMoneyMember] = Field(default_factory=list)
    sector_money_trust: DataTrust = DataTrust.UNAVAILABLE

    historical_reference_feeds_current_ranking: bool = False
    historical_reference_feeds_current_score: bool = False
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
