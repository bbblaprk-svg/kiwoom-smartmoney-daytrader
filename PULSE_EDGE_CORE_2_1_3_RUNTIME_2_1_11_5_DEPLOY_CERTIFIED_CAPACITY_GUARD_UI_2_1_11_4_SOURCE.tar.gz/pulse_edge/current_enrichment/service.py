from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from statistics import fmean
from typing import Iterable

from pulse_edge.context.daily import DailyBar, DailyContextService
from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.features.models import FeatureFrame
from pulse_edge.sector.service import SectorBreadthService
from pulse_edge.storage.baseline import SameTimeBaselineStore
from pulse_edge.universe.service import UniverseService
from pulse_edge.current_enrichment.models import CurrentEnrichmentFrame, DataTrust, SectorMoneyMember


def _ratio(numerator: float | None, denominator: float | None) -> float | None:
    if numerator is None or denominator is None or denominator <= 0:
        return None
    return numerator / denominator


def _pct(current: float | None, reference: float | None) -> float | None:
    if current is None or reference is None or current <= 0 or reference <= 0:
        return None
    return (current / reference - 1.0) * 100.0


def _completed_bars(rows: Iterable[DailyBar], now: datetime) -> list[DailyBar]:
    local_day = now.astimezone(ZoneInfo("Asia/Seoul")).date()
    # DailyContext rows are exchange dates. Excluding any row dated today avoids
    # treating a partial current-day bar as a completed historical reference.
    return sorted([x for x in rows if x.trading_date < local_day], key=lambda x: x.trading_date)


def _daily_stats(rows: list[DailyBar], current_price: float | None) -> dict[str, float | int | None]:
    completed = rows[-20:]
    n = len(completed)
    refs = [x.close for x in completed]
    result: dict[str, float | int | None] = {
        "return_1d_pct": _pct(current_price, refs[-1]) if len(refs) >= 1 else None,
        "return_3d_pct": _pct(current_price, refs[-3]) if len(refs) >= 3 else None,
        "return_5d_pct": _pct(current_price, refs[-5]) if len(refs) >= 5 else None,
        "avg20_daily_volume": fmean([x.volume for x in completed]) if completed else None,
        "avg20_daily_traded_value_raw": None,
        "daily_baseline_days": n,
    }
    values = [x.traded_value_raw for x in completed]
    if completed and all(v is not None for v in values):
        result["avg20_daily_traded_value_raw"] = fmean(float(v) for v in values if v is not None)
    return result


class CurrentEnrichmentService:
    """Phase 6G read-only current-data enrichment.

    Historical references are descriptive fields only. This service has no API
    that supplies values to PULSE selection, ranking, scoring, DUAL, PRE-BUY or
    NXT engines.
    """

    def __init__(
        self,
        *,
        features: FeatureEngine,
        daily_context: DailyContextService,
        universe: UniverseService,
        sectors: SectorBreadthService,
        baseline_store: SameTimeBaselineStore | None,
        max_rows: int = 200,
        daily_requests_per_cycle: int = 12,
    ) -> None:
        self.features = features
        self.daily_context = daily_context
        self.universe = universe
        self.sectors = sectors
        self.baseline_store = baseline_store
        self.max_rows = max(20, int(max_rows))
        self.daily_requests_per_cycle = max(1, int(daily_requests_per_cycle))
        self.frames: dict[str, CurrentEnrichmentFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self.last_daily_hydration_count: int = 0

    async def refresh(self, asof: datetime | None = None) -> list[CurrentEnrichmentFrame]:
        now = asof or datetime.now(timezone.utc)
        source = [
            row for (venue, _), row in self.features.frames.items()
            if venue == Venue.KRX and row.price is not None and row.price > 0
        ]
        source.sort(key=lambda x: (x.money_5m or 0.0, x.change_rate or 0.0), reverse=True)
        source = source[: self.max_rows]

        hydration = 0
        for row in source:
            if hydration >= self.daily_requests_per_cycle:
                break
            cached = self.daily_context.frames.get(row.symbol)
            if cached is None or (now - cached.asof).total_seconds() > self.daily_context.ttl_sec:
                await self.daily_context.ensure(row.symbol)
                hydration += 1
        self.last_daily_hydration_count = hydration

        sector_maps = self._sector_money_maps(source)
        out: list[CurrentEnrichmentFrame] = []
        for row in source:
            frame = self._build(row, now, sector_maps)
            self.frames[row.symbol] = frame
            out.append(frame)
        live_symbols = {r.symbol for r in source}
        for symbol in list(self.frames):
            if symbol not in live_symbols:
                self.frames.pop(symbol, None)
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(out)

    def _build(self, row: FeatureFrame, now: datetime, sector_maps: dict[str, dict]) -> CurrentEnrichmentFrame:
        flags: list[str] = []
        daily = self.daily_context.frames.get(row.symbol)
        daily_stats: dict[str, float | int | None] = {}
        daily_age = (now - daily.asof).total_seconds() if daily is not None else None
        if daily is not None and daily_age is not None and daily_age <= self.daily_context.ttl_sec:
            completed = _completed_bars(daily.bars, now)
            daily_stats = _daily_stats(completed, row.price)
        elif daily is not None:
            flags.append("DAILY_REFERENCE_STALE")
        else:
            flags.append("DAILY_REFERENCE_UNAVAILABLE")

        q = self.features.trades.get((Venue.KRX, row.symbol))
        latest = q[-1] if q else None
        cumulative_volume = latest.cumulative_volume if latest else None
        cumulative_amount = latest.cumulative_amount if latest else None
        avg_volume = daily_stats.get("avg20_daily_volume")
        avg_value = daily_stats.get("avg20_daily_traded_value_raw")
        days = int(daily_stats.get("daily_baseline_days") or 0)
        daily_trust = DataTrust.HISTORICAL_REFERENCE if days > 0 else DataTrust.UNAVAILABLE

        prev_same = avg_same = None
        same_days = 0
        if self.baseline_store is not None and row.money_5m is not None:
            prev_same, _ = self.baseline_store.get_same_time_money(Venue.KRX.value, row.symbol, now, 1)
            avg_same, same_days = self.baseline_store.get_same_time_money(Venue.KRX.value, row.symbol, now, 20)
        same_trust = DataTrust.HISTORICAL_REFERENCE if same_days > 0 else DataTrust.UNAVAILABLE
        if same_days == 0:
            flags.append("SAME_TIME_REFERENCE_UNAVAILABLE")

        stock = self.universe.stocks.get(row.symbol)
        shares = stock.listed_shares if stock else None
        market_cap = row.price * shares if row.price is not None and shares is not None and shares > 0 else None
        market_cap_trust = DataTrust.CURRENT_SESSION if market_cap is not None else DataTrust.UNAVAILABLE
        if market_cap is None:
            flags.append("MARKET_CAP_UNAVAILABLE")

        sector = sector_maps.get(row.symbol, {})
        top3 = sector.get("top3", [])
        sector_trust = DataTrust.CURRENT_SESSION if top3 else DataTrust.UNAVAILABLE
        if not top3:
            flags.append("SECTOR_MONEY_UNAVAILABLE")

        return CurrentEnrichmentFrame(
            symbol=row.symbol,
            asof=now,
            price=row.price,
            change_rate=row.change_rate,
            return_1d_pct=daily_stats.get("return_1d_pct"),
            return_3d_pct=daily_stats.get("return_3d_pct"),
            return_5d_pct=daily_stats.get("return_5d_pct"),
            return_reference_trust=daily_trust,
            current_cumulative_volume=cumulative_volume,
            current_cumulative_amount=cumulative_amount,
            avg20_daily_volume=avg_volume if isinstance(avg_volume, float) else None,
            avg20_daily_traded_value_raw=avg_value if isinstance(avg_value, float) else None,
            intraday_volume_vs_20d_daily=_ratio(cumulative_volume, avg_volume if isinstance(avg_volume, float) else None),
            intraday_value_vs_20d_daily=_ratio(cumulative_amount, avg_value if isinstance(avg_value, float) else None),
            daily_baseline_days=days,
            daily_baseline_trust=daily_trust,
            money_5m=row.money_5m,
            previous_observed_same_time_money_5m=prev_same,
            same_time_avg20_money_5m=avg_same,
            previous_same_time_ratio=_ratio(row.money_5m, prev_same),
            same_time_avg20_ratio=_ratio(row.money_5m, avg_same),
            same_time_baseline_days=same_days,
            same_time_reference_trust=same_trust,
            listed_shares=shares,
            market_cap_est_krw=market_cap,
            market_cap_trust=market_cap_trust,
            sector_code=sector.get("sector_code"),
            sector_name=sector.get("sector_name"),
            sector_money_rank=sector.get("rank"),
            sector_money_stage=sector.get("stage", "NO_DATA"),
            sector_second_to_leader_ratio=sector.get("second_ratio"),
            sector_third_to_leader_ratio=sector.get("third_ratio"),
            sector_top3_positive_accel_count=sector.get("positive_accel_count", 0),
            sector_top3=top3,
            sector_money_trust=sector_trust,
            flags=flags,
        )

    def _sector_money_maps(self, rows: list[FeatureFrame]) -> dict[str, dict]:
        groups: dict[str, list[FeatureFrame]] = defaultdict(list)
        for row in rows:
            code = self.sectors.symbol_sector.get(row.symbol)
            if code:
                groups[code].append(row)
        result: dict[str, dict] = {}
        for code, members in groups.items():
            members.sort(key=lambda x: (x.money_5m or 0.0, x.money_acceleration or 0.0), reverse=True)
            top = [x for x in members if (x.money_5m or 0.0) > 0][:3]
            leader_money = top[0].money_5m if top else None
            second_ratio = _ratio(top[1].money_5m, leader_money) if len(top) >= 2 else None
            third_ratio = _ratio(top[2].money_5m, leader_money) if len(top) >= 3 else None
            positive_accel = sum(1 for x in top if (x.money_acceleration or 0.0) > 0)
            if len(top) >= 3 and (third_ratio or 0.0) >= 0.20:
                stage = "THREE_WAY_PLUS"
            elif len(top) >= 2 and (second_ratio or 0.0) >= 0.25:
                stage = "TWO_WAY"
            elif len(top) >= 1:
                stage = "LEADER_ONLY"
            else:
                stage = "NO_DATA"
            sector_frame = self.sectors.frames.get(code)
            top3 = [
                SectorMoneyMember(
                    symbol=x.symbol,
                    money_5m=x.money_5m,
                    money_acceleration=x.money_acceleration,
                    change_rate=x.change_rate,
                )
                for x in top
            ]
            for idx, member in enumerate(members, start=1):
                result[member.symbol] = {
                    "sector_code": code,
                    "sector_name": sector_frame.sector_name if sector_frame else None,
                    "rank": idx,
                    "stage": stage,
                    "second_ratio": second_ratio,
                    "third_ratio": third_ratio,
                    "positive_accel_count": positive_accel,
                    "top3": top3,
                }
        return result

    def top(self, limit: int = 20) -> list[CurrentEnrichmentFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), self.max_rows))]

    def get(self, symbol: str) -> CurrentEnrichmentFrame | None:
        return self.frames.get(str(symbol)[:6])

    @staticmethod
    def _sorted(rows: list[CurrentEnrichmentFrame]) -> list[CurrentEnrichmentFrame]:
        rows.sort(key=lambda x: (x.money_5m or 0.0, x.change_rate or 0.0), reverse=True)
        return rows
