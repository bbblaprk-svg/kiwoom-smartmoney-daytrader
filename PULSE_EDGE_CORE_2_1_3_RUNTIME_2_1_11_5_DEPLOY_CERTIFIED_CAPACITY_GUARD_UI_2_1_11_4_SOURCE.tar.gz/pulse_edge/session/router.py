from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time
from enum import StrEnum
from zoneinfo import ZoneInfo

from pulse_edge.core.models import NormalizedEvent, Venue

KST = ZoneInfo("Asia/Seoul")


class OperatorPhase(StrEnum):
    CLOSED = "CLOSED"
    PREOPEN_LIVE = "PREOPEN LIVE"
    PREOPEN_SCAN = "PREOPEN SCAN"
    ARMED = "ARMED"
    MARKET_LIVE = "MARKET LIVE"
    KRX_CLOSE_AUCTION = "KRX CLOSE AUCTION"
    POST_GAP = "POST GAP"
    NXT_AFTER = "NXT AFTER"
    NXT_CLOSE_BET = "NXT CLOSE-BET"


class SessionPhase(StrEnum):
    CLOSED = "CLOSED"
    NXT_PRE = "NXT_PRE"
    OPENING_AUCTION = "OPENING_AUCTION"
    MARKET_MAIN = "MARKET_MAIN"
    KRX_CLOSE_AUCTION = "KRX_CLOSE_AUCTION"
    POST_GAP = "POST_GAP"
    NXT_AFTER = "NXT_AFTER"
    NXT_LATE_SESSION = "NXT_LATE_SESSION"


OFFICIAL_OPERATION_CODES = {
    "0": "KRX_PRE",
    "3": "KRX_OPEN",
    "P": "NXT_PRE_OPEN",
    "Q": "NXT_PRE_CLOSE",
    "R": "NXT_MAIN_OPEN",
    "S": "NXT_MAIN_CLOSE",
    "T": "NXT_AFTER_SINGLE_OPEN",
    "U": "NXT_AFTER_OPEN",
    "V": "NXT_CLOSE_TRADE_END",
    "W": "NXT_AFTER_CLOSE",
}


@dataclass(frozen=True)
class SessionFrame:
    asof: datetime
    trading_day: bool
    phase: SessionPhase
    nxt_late_session_active: bool
    official_operation_code: str | None = None
    official_operation_name: str | None = None


class SessionRouter:
    """Pure KST session contract plus optional Kiwoom 0s operation-code evidence."""

    def __init__(self, holidays: set[date] | None = None) -> None:
        self.holidays = holidays or set()
        self.last_operation_code: str | None = None
        self.last_operation_at: datetime | None = None

    def is_trading_day(self, value: date) -> bool:
        return value.weekday() < 5 and value not in self.holidays

    def phase_at(self, when: datetime) -> SessionPhase:
        local = when.astimezone(KST)
        if not self.is_trading_day(local.date()):
            return SessionPhase.CLOSED
        t = local.time().replace(tzinfo=None)
        if time(8, 0) <= t < time(8, 50):
            return SessionPhase.NXT_PRE
        if time(8, 50) <= t < time(9, 0):
            return SessionPhase.OPENING_AUCTION
        if time(9, 0) <= t < time(15, 20):
            return SessionPhase.MARKET_MAIN
        if time(15, 20) <= t < time(15, 30):
            return SessionPhase.KRX_CLOSE_AUCTION
        if time(15, 30) <= t < time(15, 40):
            return SessionPhase.POST_GAP
        if time(15, 40) <= t < time(19, 30):
            return SessionPhase.NXT_AFTER
        if time(19, 30) <= t < time(19, 55):
            return SessionPhase.NXT_LATE_SESSION
        if time(19, 55) <= t < time(20, 0):
            return SessionPhase.NXT_AFTER
        return SessionPhase.CLOSED


    def operator_phase_at(self, when: datetime) -> OperatorPhase:
        """Operator-facing session state.

        This is display/action-gating metadata only. It does not change the
        exchange session phase, event acceptance, ranking, scoring, DUAL,
        PRICE HOLD, PRE-BUY, NXT logic, or any broker subscription.
        """
        local = when.astimezone(KST)
        if not self.is_trading_day(local.date()):
            return OperatorPhase.CLOSED
        t = local.time().replace(tzinfo=None)
        if time(8, 0) <= t < time(8, 30):
            return OperatorPhase.PREOPEN_LIVE
        if time(8, 30) <= t < time(8, 50):
            return OperatorPhase.PREOPEN_SCAN
        if time(8, 50) <= t < time(9, 0):
            return OperatorPhase.ARMED
        if time(9, 0) <= t < time(15, 20):
            return OperatorPhase.MARKET_LIVE
        if time(15, 20) <= t < time(15, 30):
            return OperatorPhase.KRX_CLOSE_AUCTION
        if time(15, 30) <= t < time(15, 40):
            return OperatorPhase.POST_GAP
        if time(15, 40) <= t < time(19, 30):
            return OperatorPhase.NXT_AFTER
        if time(19, 30) <= t < time(19, 55):
            return OperatorPhase.NXT_CLOSE_BET
        if time(19, 55) <= t < time(20, 0):
            return OperatorPhase.NXT_AFTER
        return OperatorPhase.CLOSED

    def operator_action_gate_open(self, when: datetime) -> bool:
        """True only when regular-market action presentation may be shown."""
        return self.operator_phase_at(when) == OperatorPhase.MARKET_LIVE

    def preopen_observation_active(self, when: datetime) -> bool:
        return self.operator_phase_at(when) in {
            OperatorPhase.PREOPEN_LIVE,
            OperatorPhase.PREOPEN_SCAN,
            OperatorPhase.ARMED,
        }

    def frame_at(self, when: datetime) -> SessionFrame:
        local = when.astimezone(KST)
        phase = self.phase_at(local)
        return SessionFrame(
            asof=local,
            trading_day=self.is_trading_day(local.date()),
            phase=phase,
            nxt_late_session_active=phase == SessionPhase.NXT_LATE_SESSION,
            official_operation_code=self.last_operation_code,
            official_operation_name=OFFICIAL_OPERATION_CODES.get(self.last_operation_code or ""),
        )

    def observe_market_time(self, event: NormalizedEvent) -> None:
        if event.real_type != "0s":
            return
        code = str(event.data.get("market_operation") or "").strip()
        if code:
            self.last_operation_code = code
            self.last_operation_at = event.event_time or event.receive_time

    def session_key(self, venue: Venue, when: datetime) -> str | None:
        local = when.astimezone(KST)
        phase = self.phase_at(local)
        day = local.date().isoformat()
        if venue == Venue.NXT:
            if phase == SessionPhase.NXT_PRE:
                return f"{day}:NXT_PRE"
            if phase == SessionPhase.MARKET_MAIN:
                return f"{day}:NXT_MAIN"
            if phase in {SessionPhase.NXT_AFTER, SessionPhase.NXT_LATE_SESSION}:
                return f"{day}:NXT_AFTER"
        if venue == Venue.KRX and phase == SessionPhase.MARKET_MAIN:
            return f"{day}:KRX_MAIN"
        if venue == Venue.SOR and phase == SessionPhase.MARKET_MAIN:
            return f"{day}:SOR_MAIN"
        return None

    def event_allowed(self, event: NormalizedEvent) -> bool:
        if event.real_type == "0s":
            return True
        ts = event.event_time or event.receive_time
        phase = self.phase_at(ts)
        typ = event.real_type or ""

        if typ in {"0J", "0U"}:
            return phase in {SessionPhase.MARKET_MAIN, SessionPhase.KRX_CLOSE_AUCTION}

        if event.venue == Venue.NXT:
            if typ in {"0B", "0C", "0D", "0w"}:
                return phase in {
                    SessionPhase.NXT_PRE,
                    SessionPhase.MARKET_MAIN,
                    SessionPhase.NXT_AFTER,
                    SessionPhase.NXT_LATE_SESSION,
                }
            return False

        if event.venue == Venue.KRX:
            if typ == "0H":
                return phase in {SessionPhase.OPENING_AUCTION, SessionPhase.KRX_CLOSE_AUCTION}
            if typ in {"0B", "0C", "0D", "0w"}:
                return phase == SessionPhase.MARKET_MAIN
            return False

        if event.venue == Venue.SOR:
            return phase == SessionPhase.MARKET_MAIN and typ in {"0B", "0C", "0D", "0w"}

        return False
