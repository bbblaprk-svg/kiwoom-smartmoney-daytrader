from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.patterns.engine import OrbRetestEngine, SqueezeReleaseEngine, VwapReclaimEngine
from pulse_edge.patterns.models import OrbFrame, OrbStage, SqueezeFrame, SqueezeStage, VwapReclaimFrame, VwapReclaimStage

KST = ZoneInfo('Asia/Seoul')


class PatternCompletionService:
    def __init__(self, features: FeatureEngine, max_rows: int = 100) -> None:
        self.features = features
        self.orb_engine = OrbRetestEngine()
        self.squeeze_engine = SqueezeReleaseEngine()
        self.reclaim_engine = VwapReclaimEngine()
        self.max_rows = max(10, int(max_rows))
        self.orb_frames: dict[tuple[Venue,str], OrbFrame] = {}
        self.squeeze_frames: dict[tuple[Venue,str], SqueezeFrame] = {}
        self.reclaim_frames: dict[tuple[Venue,str], VwapReclaimFrame] = {}
        self._opening_ranges: dict[tuple[str,Venue,str], tuple[float,float]] = {}
        self._orb_persist: dict[tuple[Venue,str], int] = {}
        self._squeeze_persist: dict[tuple[Venue,str], int] = {}
        self._reclaim_persist: dict[tuple[Venue,str], int] = {}
        self._session_day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> None:
        now = asof or datetime.now(timezone.utc)
        day = now.astimezone(KST).date().isoformat()
        if self._session_day != day:
            self._session_day = day
            self._opening_ranges.clear()
            self._orb_persist.clear(); self._squeeze_persist.clear(); self._reclaim_persist.clear()
            self.orb_frames.clear(); self.squeeze_frames.clear(); self.reclaim_frames.clear()

        ranked_keys = sorted(self.features.frames, key=lambda k: self.features.frames[k].asof, reverse=True)
        current_keys = ranked_keys[: max(20, min(int(limit), 200))]
        keep: set[tuple[Venue,str]] = set()
        for key in current_keys:
            feature = self.features.frames.get(key)
            if feature is None:
                continue
            points = list(self.features.trades.get(key, []))
            if not points or (now - points[-1].ts).total_seconds() > 7.0:
                continue
            keep.add(key)
            if feature.venue == Venue.KRX:
                self._update_opening_range(day, key, points)
            op = self._opening_ranges.get((day, key[0], key[1]))
            provisional_orb = self.orb_engine.evaluate(
                feature, points,
                opening_high=op[0] if op else None, opening_low=op[1] if op else None,
                persistence_count=self._orb_persist.get(key, 0), asof=now,
            )
            orb_qualifies = provisional_orb.stage in {OrbStage.ORB_RETEST_SHADOW, OrbStage.ORB_RETEST_CONFIRMED_SHADOW}
            self._orb_persist[key] = self._orb_persist.get(key,0) + 1 if orb_qualifies else 0
            orb = self.orb_engine.evaluate(feature, points, opening_high=op[0] if op else None, opening_low=op[1] if op else None,
                                           persistence_count=self._orb_persist[key], asof=now)
            if orb.stage != OrbStage.DATA_WAIT:
                self.orb_frames[key] = orb
            else:
                self.orb_frames.pop(key, None)

            provisional_sq = self.squeeze_engine.evaluate(feature, points, persistence_count=self._squeeze_persist.get(key,0), asof=now)
            sq_qualifies = provisional_sq.stage in {SqueezeStage.RELEASE_WATCH, SqueezeStage.SQUEEZE_RELEASE_SHADOW}
            self._squeeze_persist[key] = self._squeeze_persist.get(key,0) + 1 if sq_qualifies else 0
            sq = self.squeeze_engine.evaluate(feature, points, persistence_count=self._squeeze_persist[key], asof=now)
            if sq.stage != SqueezeStage.DATA_WAIT:
                self.squeeze_frames[key] = sq
            else:
                self.squeeze_frames.pop(key, None)

            provisional_rc = self.reclaim_engine.evaluate(feature, points, persistence_count=self._reclaim_persist.get(key,0), asof=now)
            rc_qualifies = provisional_rc.stage in {VwapReclaimStage.RECLAIM_WATCH, VwapReclaimStage.VWAP_RECLAIM_SHADOW}
            self._reclaim_persist[key] = self._reclaim_persist.get(key,0) + 1 if rc_qualifies else 0
            rc = self.reclaim_engine.evaluate(feature, points, persistence_count=self._reclaim_persist[key], asof=now)
            if rc.stage != VwapReclaimStage.DATA_WAIT:
                self.reclaim_frames[key] = rc
            else:
                self.reclaim_frames.pop(key, None)

        for store, persist in ((self.orb_frames,self._orb_persist),(self.squeeze_frames,self._squeeze_persist),(self.reclaim_frames,self._reclaim_persist)):
            for key in list(store):
                if key not in keep:
                    store.pop(key,None); persist.pop(key,None)
        self.last_refresh_at = now
        self.last_error = None

    def _update_opening_range(self, day: str, key: tuple[Venue,str], points) -> None:
        selected=[]
        for p in points:
            local=p.ts.astimezone(KST)
            if local.date().isoformat()==day and (local.hour==9 and 0 <= local.minute < 10):
                selected.append(p)
        if not selected:
            return
        high=max(p.price for p in selected); low=min(p.price for p in selected)
        cache_key=(day,key[0],key[1])
        prev=self._opening_ranges.get(cache_key)
        if prev:
            high=max(high,prev[0]); low=min(low,prev[1])
        self._opening_ranges[cache_key]=(high,low)

    def top_orb(self, limit:int=10)->list[OrbFrame]:
        return self._sorted_orb(list(self.orb_frames.values()))[:max(1,min(int(limit),100))]
    def top_squeeze(self, limit:int=10)->list[SqueezeFrame]:
        return self._sorted_squeeze(list(self.squeeze_frames.values()))[:max(1,min(int(limit),100))]
    def top_reclaim(self, limit:int=10)->list[VwapReclaimFrame]:
        return self._sorted_reclaim(list(self.reclaim_frames.values()))[:max(1,min(int(limit),100))]

    @staticmethod
    def _sorted_orb(rows):
        order={OrbStage.ORB_RETEST_CONFIRMED_SHADOW:7,OrbStage.ORB_RETEST_SHADOW:6,OrbStage.ORB_BREAKOUT_WATCH:5,OrbStage.OPENING_RANGE_BUILDING:4,OrbStage.NO_PATTERN:3,OrbStage.ORB_FAIL_SHADOW:2,OrbStage.OVERHEAT_RISK_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.orb_score_100),reverse=True)
    @staticmethod
    def _sorted_squeeze(rows):
        order={SqueezeStage.SQUEEZE_RELEASE_SHADOW:6,SqueezeStage.RELEASE_WATCH:5,SqueezeStage.SQUEEZE_WATCH:4,SqueezeStage.NO_PATTERN:3,SqueezeStage.OVEREXTENDED_RISK_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.squeeze_score_100),reverse=True)
    @staticmethod
    def _sorted_reclaim(rows):
        order={VwapReclaimStage.VWAP_RECLAIM_SHADOW:6,VwapReclaimStage.RECLAIM_WATCH:5,VwapReclaimStage.BELOW_VWAP_WATCH:4,VwapReclaimStage.NO_PATTERN:3,VwapReclaimStage.RECLAIM_FAIL_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.reclaim_score_100),reverse=True)
