from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class OrbStage(StrEnum):
    DATA_WAIT = 'DATA_WAIT'
    OPENING_RANGE_BUILDING = 'OPENING_RANGE_BUILDING'
    ORB_BREAKOUT_WATCH = 'ORB_BREAKOUT_WATCH'
    ORB_RETEST_SHADOW = 'ORB_RETEST_SHADOW'
    ORB_RETEST_CONFIRMED_SHADOW = 'ORB_RETEST_CONFIRMED_SHADOW'
    ORB_FAIL_SHADOW = 'ORB_FAIL_SHADOW'
    OVERHEAT_RISK_SHADOW = 'OVERHEAT_RISK_SHADOW'
    NO_PATTERN = 'NO_PATTERN'


class SqueezeStage(StrEnum):
    DATA_WAIT = 'DATA_WAIT'
    SQUEEZE_WATCH = 'SQUEEZE_WATCH'
    RELEASE_WATCH = 'RELEASE_WATCH'
    SQUEEZE_RELEASE_SHADOW = 'SQUEEZE_RELEASE_SHADOW'
    OVEREXTENDED_RISK_SHADOW = 'OVEREXTENDED_RISK_SHADOW'
    NO_PATTERN = 'NO_PATTERN'


class VwapReclaimStage(StrEnum):
    DATA_WAIT = 'DATA_WAIT'
    BELOW_VWAP_WATCH = 'BELOW_VWAP_WATCH'
    RECLAIM_WATCH = 'RECLAIM_WATCH'
    VWAP_RECLAIM_SHADOW = 'VWAP_RECLAIM_SHADOW'
    RECLAIM_FAIL_SHADOW = 'RECLAIM_FAIL_SHADOW'
    NO_PATTERN = 'NO_PATTERN'


class OrbFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    stage: OrbStage
    price: float | None = None
    opening_high: float | None = None
    opening_low: float | None = None
    opening_range_pct: float | None = None
    breakout_pct: float | None = None
    retest_distance_pct: float | None = None
    orb_score_100: float = 0.0
    persistence_count: int = 0
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)


class SqueezeFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    stage: SqueezeStage
    price: float | None = None
    compression_high: float | None = None
    compression_low: float | None = None
    compression_width_pct: float | None = None
    range_contraction_pct: float | None = None
    volume_rate_contraction_pct: float | None = None
    breakout_pct: float | None = None
    squeeze_score_100: float = 0.0
    persistence_count: int = 0
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)


class VwapReclaimFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    stage: VwapReclaimStage
    price: float | None = None
    session_vwap: float | None = None
    min_below_vwap_pct: float | None = None
    current_above_vwap_pct: float | None = None
    reclaim_score_100: float = 0.0
    persistence_count: int = 0
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
