from __future__ import annotations

from datetime import datetime, timezone

from pulse_edge.sector.service import SectorBreadthFrame
from pulse_edge.smart_money.models import SmartMoneyFrame
from pulse_edge.spillover.models import SpilloverFrame, SpilloverStage


def _clip(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


class SectorSpilloverEngine:
    """Phase 3D shadow-only sector lead/lag evaluator.

    It consumes current-session sector breadth plus fresh SMART-MONEY frames only.
    It never changes 3B/3C scores, never reserves incumbent symbols, and never
    creates an official PREBUY/ENTRY action.
    """

    def evaluate(
        self,
        row: SmartMoneyFrame,
        *,
        sector_code: str | None,
        sector: SectorBreadthFrame | None,
        peers: list[SmartMoneyFrame],
        asof: datetime | None = None,
    ) -> SpilloverFrame:
        now = asof or datetime.now(timezone.utc)
        flags: list[str] = []
        active_peers = [p for p in peers if p.change_rate is not None and p.evidence_age_sec is not None and p.evidence_age_sec <= 1200]
        active_peers.sort(key=lambda p: p.change_rate or -999.0, reverse=True)
        leader = active_peers[0] if active_peers else None

        flow_positive = [p for p in active_peers if self._flow_positive(p)]
        money_positive = [p for p in active_peers if (p.money_acceleration or 0) > 0]
        flow_ratio = (len(flow_positive) / len(active_peers) * 100.0) if active_peers else None

        leader_rate = leader.change_rate if leader else None
        lag = None
        if leader_rate is not None and row.change_rate is not None:
            lag = leader_rate - row.change_rate

        sector_strength = self._sector_strength(sector, len(active_peers), flow_ratio, len(money_positive), flags)
        leader_quality = self._leader_quality(leader, flags)
        underreaction = self._underreaction(row, lag, flags)
        rs_turn = self._rs_turn(row, flags)
        flow_turn = self._flow_turn(row, flags)
        price_structure = self._price_structure(row, flags)
        score = _clip(sector_strength + leader_quality + underreaction + rs_turn + flow_turn + price_structure)
        overheat = self._overheat(row)

        if row.price is None or row.change_rate is None or sector is None or sector_code is None or len(active_peers) < 3:
            stage = SpilloverStage.DATA_WAIT
        elif leader is not None and leader.symbol == row.symbol:
            stage = SpilloverStage.LEADER_SHADOW
        elif overheat >= 70:
            stage = SpilloverStage.OVERHEAT_RISK_SHADOW
        elif self._strong_sector(sector, len(active_peers), flow_ratio, len(money_positive)) and score >= 72 and self._early_follower_shape(row, lag):
            stage = SpilloverStage.EARLY_FOLLOWER_SHADOW
        elif score >= 58 and lag is not None and lag >= 1.0 and row.change_rate <= 6.0:
            stage = SpilloverStage.LATE_FOLLOWER_SHADOW
        else:
            stage = SpilloverStage.NO_SPILLOVER

        return SpilloverFrame(
            venue=row.venue,
            symbol=row.symbol,
            asof=now,
            stage=stage,
            sector_code=sector_code,
            sector_name=sector.sector_name if sector else row.sector_name,
            price=row.price,
            change_rate=row.change_rate,
            leader_symbol=leader.symbol if leader else None,
            leader_change_rate=leader_rate,
            lag_to_leader_pp=round(lag, 4) if lag is not None else None,
            evaluated_member_count=len(active_peers),
            flow_positive_ratio=round(flow_ratio, 4) if flow_ratio is not None else None,
            money_accel_positive_count=len(money_positive),
            spillover_score_100=round(score, 4),
            sector_strength_score_25=round(sector_strength, 4),
            leader_quality_score_20=round(leader_quality, 4),
            underreaction_score_20=round(underreaction, 4),
            rs_turn_score_15=round(rs_turn, 4),
            flow_turn_score_15=round(flow_turn, 4),
            price_structure_score_5=round(price_structure, 4),
            overheat_risk=round(overheat, 4),
            official_signal_enabled=False,
            flags=list(dict.fromkeys(flags)),
        )

    @staticmethod
    def _flow_positive(row: SmartMoneyFrame) -> bool:
        return bool(
            (row.foreign_flow_acceleration is not None and row.foreign_flow_acceleration > 0)
            or (row.money_acceleration is not None and row.money_acceleration > 0)
            or (row.program_net_buy_amount_delta is not None and row.program_net_buy_amount_delta > 0)
        )

    @staticmethod
    def _strong_sector(sector: SectorBreadthFrame, member_count: int, flow_ratio: float | None, money_count: int) -> bool:
        return bool(
            member_count >= 3
            and sector.score_15 >= 10.5
            and (sector.member_positive_ratio or sector.breadth_ratio or 0) >= 60.0
            and (flow_ratio or 0) >= 60.0
            and money_count >= 2
        )

    def _sector_strength(self, sector, member_count, flow_ratio, money_count, flags) -> float:
        if sector is None:
            flags.append("SECTOR_FRAME_MISSING")
            return 0.0
        score = min(12.0, max(0.0, sector.score_15 / 15.0 * 12.0))
        breadth = sector.member_positive_ratio if sector.member_positive_ratio is not None else sector.breadth_ratio
        if breadth is not None:
            if breadth >= 70: score += 5
            elif breadth >= 60: score += 3
        if member_count >= 3: score += 3
        else: flags.append("SECTOR_EVALUATED_MEMBERS_LT3")
        if flow_ratio is not None and flow_ratio >= 60: score += 3
        if money_count >= 2: score += 2
        return min(score, 25.0)

    def _leader_quality(self, leader, flags) -> float:
        if leader is None or leader.change_rate is None:
            flags.append("SECTOR_LEADER_MISSING")
            return 0.0
        score = 0.0
        if 3.0 <= leader.change_rate <= 10.0: score += 8
        elif 1.5 <= leader.change_rate < 3.0 or 10.0 < leader.change_rate <= 12.0: score += 4
        if (leader.rs_acceleration or 0) > 0: score += 4
        if self._flow_positive(leader): score += 4
        if (leader.money_acceleration or 0) > 0: score += 2
        if leader.vwap_distance_pct is not None and leader.vwap_distance_pct <= 3.0: score += 2
        return min(score, 20.0)

    @staticmethod
    def _underreaction(row, lag, flags) -> float:
        if lag is None:
            flags.append("LEADER_LAG_MISSING")
            return 0.0
        score = 0.0
        if lag >= 4.0: score += 9
        elif lag >= 2.0: score += 7
        elif lag >= 1.0: score += 3
        if row.change_rate is not None:
            if -0.5 <= row.change_rate <= 2.0: score += 8
            elif 2.0 < row.change_rate <= 4.0: score += 5
            elif 4.0 < row.change_rate <= 6.0: score += 2
        if row.flow_price_divergence_score >= 3.0: score += 3
        return min(score, 20.0)

    @staticmethod
    def _rs_turn(row, flags) -> float:
        score = 0.0
        if (row.rs_acceleration or 0) > 0: score += 7
        else: flags.append("FOLLOWER_RS_ACCEL_NONPOSITIVE")
        if (row.rs_velocity or 0) > 0: score += 5
        if row.rs_zero_cross: score += 3
        return min(score, 15.0)

    def _flow_turn(self, row, flags) -> float:
        score = 0.0
        if (row.money_acceleration or 0) > 0: score += 5
        else: flags.append("FOLLOWER_MONEY_ACCEL_NONPOSITIVE")
        if (row.foreign_flow_acceleration or 0) > 0: score += 4
        if row.foreign_flow_reversal: score += 2
        if (row.program_net_buy_amount_delta or 0) > 0: score += 2
        if row.flow_price_divergence_score >= 2.0: score += 2
        return min(score, 15.0)

    @staticmethod
    def _price_structure(row, flags) -> float:
        gap = row.vwap_distance_pct
        if gap is None:
            flags.append("FOLLOWER_VWAP_MISSING")
            return 0.0
        if -0.5 <= gap <= 1.5: return 5.0
        if 1.5 < gap <= 2.5 or -1.0 <= gap < -0.5: return 2.5
        return 0.0

    @staticmethod
    def _early_follower_shape(row, lag) -> bool:
        return bool(
            lag is not None and lag >= 2.0
            and row.change_rate is not None and -0.5 <= row.change_rate <= 4.0
            and (row.rs_acceleration or 0) > 0
            and (row.money_acceleration or 0) > 0
            and row.vwap_distance_pct is not None and -0.75 <= row.vwap_distance_pct <= 2.0
        )

    @staticmethod
    def _overheat(row) -> float:
        risk = 0.0
        if row.change_rate is not None:
            if row.change_rate >= 12: risk += 45
            elif row.change_rate >= 9: risk += 25
        if row.vwap_distance_pct is not None:
            if row.vwap_distance_pct > 4: risk += 35
            elif row.vwap_distance_pct > 3: risk += 20
        if (row.money_acceleration is not None and row.money_acceleration <= 0): risk += 15
        if (row.rs_acceleration is not None and row.rs_acceleration <= 0): risk += 15
        return _clip(risk)
