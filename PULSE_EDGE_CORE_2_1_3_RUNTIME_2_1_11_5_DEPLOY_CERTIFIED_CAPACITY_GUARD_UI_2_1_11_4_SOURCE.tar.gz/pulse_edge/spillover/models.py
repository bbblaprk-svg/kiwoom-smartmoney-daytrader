from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class SpilloverStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    NO_SPILLOVER = "NO_SPILLOVER"
    LEADER_SHADOW = "LEADER_SHADOW"
    EARLY_FOLLOWER_SHADOW = "EARLY_FOLLOWER_SHADOW"
    LATE_FOLLOWER_SHADOW = "LATE_FOLLOWER_SHADOW"
    OVERHEAT_RISK_SHADOW = "OVERHEAT_RISK_SHADOW"


class SpilloverFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    stage: SpilloverStage
    sector_code: str | None = None
    sector_name: str | None = None
    price: float | None = None
    change_rate: float | None = None
    leader_symbol: str | None = None
    leader_change_rate: float | None = None
    lag_to_leader_pp: float | None = None
    evaluated_member_count: int = 0
    flow_positive_ratio: float | None = None
    money_accel_positive_count: int = 0

    spillover_score_100: float = 0.0
    sector_strength_score_25: float = 0.0
    leader_quality_score_20: float = 0.0
    underreaction_score_20: float = 0.0
    rs_turn_score_15: float = 0.0
    flow_turn_score_15: float = 0.0
    price_structure_score_5: float = 0.0

    overheat_risk: float = 0.0
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
