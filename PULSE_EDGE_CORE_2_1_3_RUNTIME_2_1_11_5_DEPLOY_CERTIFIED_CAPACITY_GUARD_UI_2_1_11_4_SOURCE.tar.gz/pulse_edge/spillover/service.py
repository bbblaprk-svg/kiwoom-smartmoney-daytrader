from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone

from pulse_edge.core.models import Venue
from pulse_edge.sector.service import SectorBreadthService
from pulse_edge.smart_money.models import SmartMoneyFrame
from pulse_edge.smart_money.service import SmartMoneyService
from pulse_edge.spillover.engine import SectorSpilloverEngine
from pulse_edge.spillover.models import SpilloverFrame, SpilloverStage


class SectorSpilloverService:
    def __init__(self, smart_money: SmartMoneyService, sectors: SectorBreadthService, engine: SectorSpilloverEngine, max_rows: int = 100) -> None:
        self.smart_money = smart_money
        self.sectors = sectors
        self.engine = engine
        self.max_rows = max(10, int(max_rows))
        self.frames: dict[tuple[Venue, str], SpilloverFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[SpilloverFrame]:
        now = asof or datetime.now(timezone.utc)
        source = self.smart_money.top(max(20, min(int(limit), 200)), now)
        groups: dict[str, list[SmartMoneyFrame]] = defaultdict(list)
        for row in source:
            code = self.sectors.symbol_sector.get(row.symbol[:6])
            if code:
                groups[code].append(row)

        rows: list[SpilloverFrame] = []
        keep: set[tuple[Venue, str]] = set()
        for row in source:
            code = self.sectors.symbol_sector.get(row.symbol[:6])
            sector = self.sectors.frame_for(row.symbol, now)
            frame = self.engine.evaluate(row, sector_code=code, sector=sector, peers=groups.get(code or "", []), asof=now)
            key = (frame.venue, frame.symbol)
            if frame.stage == SpilloverStage.DATA_WAIT:
                self.frames.pop(key, None)
                continue
            self.frames[key] = frame
            keep.add(key)
            rows.append(frame)

        for key in list(self.frames):
            if key not in keep:
                self.frames.pop(key, None)
        ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
        self.frames = {(r.venue, r.symbol): r for r in ranked}
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def top(self, limit: int = 10) -> list[SpilloverFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]

    @staticmethod
    def _sorted(rows: list[SpilloverFrame]) -> list[SpilloverFrame]:
        order = {
            SpilloverStage.EARLY_FOLLOWER_SHADOW: 5,
            SpilloverStage.LEADER_SHADOW: 4,
            SpilloverStage.LATE_FOLLOWER_SHADOW: 3,
            SpilloverStage.NO_SPILLOVER: 2,
            SpilloverStage.OVERHEAT_RISK_SHADOW: 1,
            SpilloverStage.DATA_WAIT: 0,
        }
        rows.sort(key=lambda x: (order.get(x.stage, 0), x.spillover_score_100, -x.overheat_risk), reverse=True)
        return rows
