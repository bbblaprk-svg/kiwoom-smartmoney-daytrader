from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.compression.models import CurrentDecisionRow


class PresentationState(StrEnum):
    LIVE = "LIVE"
    WARNING = "WARNING"
    FROZEN = "FROZEN"
    LOCKED = "LOCKED"


class PresentationSafetyFrame(BaseModel):
    asof: datetime
    state: PresentationState
    reason_codes: list[str] = Field(default_factory=list)
    data_warning: bool = False
    new_action_presentation_allowed: bool = False
    buy_like_language_allowed: bool = False
    frozen_at: datetime | None = None
    last_trusted_market_event_at: datetime | None = None
    current_decision_refresh_at: datetime | None = None
    recovery_event_seen: bool = False
    recovery_reassessment_seen: bool = False
    rows: list[CurrentDecisionRow] = Field(default_factory=list)
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    historical_restore_used: bool = False
