from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from pulse_edge.compression.service import CurrentDecisionCompressionService
from pulse_edge.runtime.models import FeedHealth, LoadStage
from pulse_edge.runtime.service import RuntimeTruthService
from pulse_edge.presentation.models import PresentationSafetyFrame, PresentationState


class PresentationSafetyService:
    """UI safety envelope over current-only compressed decisions.

    This service never changes a score, stage, gate, ranking or order state.
    It only controls how current decision rows may be presented when data/runtime
    truth is degraded. Frozen rows live in process memory only and are never used
    as an input to any current decision service.
    """

    def __init__(
        self,
        *,
        runtime_truth: RuntimeTruthService,
        feed_service: Any,
        current_decisions: CurrentDecisionCompressionService,
    ) -> None:
        self.runtime_truth = runtime_truth
        self.feed_service = feed_service
        self.current_decisions = current_decisions
        self.frame: PresentationSafetyFrame | None = None
        self._visible_rows = []
        self._hold_started_at: datetime | None = None
        self._hold_event_floor: datetime | None = None

    @staticmethod
    def _target_state(feed: FeedHealth, load: LoadStage) -> tuple[PresentationState, list[str]]:
        reasons: list[str] = []
        if load == LoadStage.CRITICAL:
            return PresentationState.LOCKED, ["runtime_critical"]
        if feed == FeedHealth.DISABLED:
            return PresentationState.LOCKED, ["feed_disabled"]
        if feed in {FeedHealth.OFFLINE, FeedHealth.STALE, FeedHealth.WARMING}:
            return PresentationState.FROZEN, [f"feed_{feed.value.lower()}"]
        if feed == FeedHealth.DEGRADED:
            reasons.append("feed_degraded")
        if load == LoadStage.HIGH:
            reasons.append("runtime_high")
        if reasons:
            return PresentationState.WARNING, reasons
        return PresentationState.LIVE, reasons

    def _trusted_market_event_at(self) -> datetime | None:
        return getattr(self.feed_service, "last_trusted_market_event_at", None)

    def refresh(self, now: datetime | None = None) -> PresentationSafetyFrame:
        now = now or datetime.now(timezone.utc)
        runtime = self.runtime_truth.frame
        if runtime is None:
            state = PresentationState.FROZEN
            reasons = ["runtime_truth_warming"]
            target_state = state
        else:
            target_state, reasons = self._target_state(runtime.feed_health, runtime.load_stage)

        trusted_event_at = self._trusted_market_event_at()
        decision_refresh_at = self.current_decisions.last_refresh_at
        was_holding = self._hold_started_at is not None
        entering_hold = target_state in {PresentationState.FROZEN, PresentationState.LOCKED}

        if entering_hold:
            if not was_holding:
                self._hold_started_at = now
                self._hold_event_floor = trusted_event_at
                # Freeze the last current-only rows. No DB/history lookup occurs.
                self._visible_rows = deepcopy(self.current_decisions.top(3))
            state = target_state
            recovery_event_seen = False
            recovery_reassessment_seen = False
        elif was_holding:
            floor = self._hold_event_floor
            recovery_event_seen = trusted_event_at is not None and (floor is None or trusted_event_at > floor)
            recovery_reassessment_seen = (
                recovery_event_seen
                and decision_refresh_at is not None
                and trusted_event_at is not None
                and decision_refresh_at >= trusted_event_at
                and decision_refresh_at >= self._hold_started_at
            )
            if not recovery_reassessment_seen:
                # Connection/load may look healthy again, but presentation remains
                # frozen until a new trusted 0B/0D event has driven a fresh decision pass.
                state = PresentationState.FROZEN
                reasons = ["recovery_reassessment_pending"]
            else:
                self._hold_started_at = None
                self._hold_event_floor = None
                state = target_state
                self._visible_rows = deepcopy(self.current_decisions.top(3))
        else:
            recovery_event_seen = False
            recovery_reassessment_seen = False
            state = target_state
            self._visible_rows = deepcopy(self.current_decisions.top(3))

        data_warning = state == PresentationState.WARNING
        allow_new_action = state in {PresentationState.LIVE, PresentationState.WARNING}
        allow_buy_like = allow_new_action
        self.frame = PresentationSafetyFrame(
            asof=now,
            state=state,
            reason_codes=reasons,
            data_warning=data_warning,
            new_action_presentation_allowed=allow_new_action,
            buy_like_language_allowed=allow_buy_like,
            frozen_at=self._hold_started_at,
            last_trusted_market_event_at=trusted_event_at,
            current_decision_refresh_at=decision_refresh_at,
            recovery_event_seen=recovery_event_seen,
            recovery_reassessment_seen=recovery_reassessment_seen,
            rows=deepcopy(self._visible_rows),
            official_signal_enabled=False,
            order_action_enabled=False,
            historical_restore_used=False,
        )
        return self.frame
