from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field


class KrxBoardRow(BaseModel):
    rank: int
    symbol: str
    model: str
    stage: str
    price: float | None = None
    change_rate: float | None = None
    score_100: float = 0.0
    price_hold_score_25: float = 0.0
    price_hold_pass: bool = False
    absorption_ratio: float | None = None
    seller_actor: str | None = None
    seller_velocity: float | None = None
    seller_decel_count: int = 0
    vwap_distance_pct: float | None = None
    market_rs: float | None = None
    sector_rs: float | None = None
    sector_breadth_ratio: float | None = None
    price_compression: bool = False
    preemptive_fit: str = "WATCH"
    stage_trust: str = "UNAVAILABLE"
    current_data: dict | None = None
    member_since: datetime
    membership_age_sec: float = 0.0
    membership_committed: bool = False
    source_asof: datetime
    flags: list[str] = Field(default_factory=list)


class KrxBoardView(BaseModel):
    fixed_rows: int = 10
    qualification_dwell_sec: float = 12.0
    membership_commit_sec: float = 30.0
    overtake_min_score_gap: float = 5.0
    items: list[KrxBoardRow] = Field(default_factory=list)
