from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.absorption.service import SupplyAbsorptionService
from pulse_edge.current_enrichment.service import CurrentEnrichmentService
from pulse_edge.krx_board.models import KrxBoardRow, KrxBoardView

KST = ZoneInfo("Asia/Seoul")


@dataclass
class _Member:
    symbol: str
    joined_at: datetime
    last_frame: AbsorptionFrame
    miss_since: datetime | None = None


class KrxDualOperationsBoardService:
    """Display-only stabilizer over current KRX DUAL absorption frames.

    It creates no score, does not call the broker, and never supplies values to
    discovery, DUAL, PRE-BUY, NXT, or compressed current decisions.
    """

    ORDER = {
        AbsorptionStage.ABSORB: 1,
        AbsorptionStage.PRICE_HOLD: 2,
        AbsorptionStage.SUPPLY_TIGHT: 3,
        AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED: 4,
        AbsorptionStage.PRE_IGNITION: 5,
    }
    HARD_EXIT = {
        AbsorptionStage.DATA_WAIT,
        AbsorptionStage.WATCH,
        AbsorptionStage.IGNITION,
    }
    BAD_TRUST = {FactTrust.STALE, FactTrust.DELAYED, FactTrust.UNAVAILABLE}

    def __init__(
        self,
        *,
        source: SupplyAbsorptionService,
        enrichment: CurrentEnrichmentService | None = None,
        fixed_rows: int = 10,
        qualification_dwell_sec: float = 12.0,
        membership_commit_sec: float = 30.0,
        missing_grace_sec: float = 15.0,
        overtake_min_score_gap: float = 5.0,
        overtake_required_checks: int = 2,
        overtake_max_wait_sec: float = 20.0,
    ) -> None:
        self.source = source
        self.enrichment = enrichment
        self.fixed_rows = 10
        self.qualification_dwell_sec = max(0.0, float(qualification_dwell_sec))
        self.membership_commit_sec = max(0.0, float(membership_commit_sec))
        self.missing_grace_sec = max(0.0, float(missing_grace_sec))
        self.overtake_min_score_gap = max(0.0, float(overtake_min_score_gap))
        self.overtake_required_checks = max(1, int(overtake_required_checks))
        self.overtake_max_wait_sec = max(1.0, float(overtake_max_wait_sec))
        self._members: list[_Member] = []
        self._qualification_since: dict[str, datetime] = {}
        self._overtake: dict[tuple[str, str], tuple[int, datetime]] = {}
        self._day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, asof: datetime | None = None) -> KrxBoardView:
        now = asof or datetime.now(timezone.utc)
        day = now.astimezone(KST).date().isoformat()
        if self._day != day:
            self._day = day
            self._members.clear()
            self._qualification_since.clear()
            self._overtake.clear()
        self._update(now)
        self.last_refresh_at = now
        self.last_error = None
        return self.view(now)

    def view(self, asof: datetime | None = None) -> KrxBoardView:
        now = asof or self.last_refresh_at or datetime.now(timezone.utc)
        rows: list[KrxBoardRow] = []
        for rank, member in enumerate(self._members[: self.fixed_rows], start=1):
            frame = self.source.frames.get(member.symbol)
            in_grace = frame is None or not self._eligible(frame)
            use = member.last_frame if in_grace else frame
            if use is None:
                continue
            age = max(0.0, (now - member.joined_at).total_seconds())
            rows.append(self._row(rank, use, member, age, in_grace))
        return KrxBoardView(
            fixed_rows=self.fixed_rows,
            qualification_dwell_sec=self.qualification_dwell_sec,
            membership_commit_sec=self.membership_commit_sec,
            overtake_min_score_gap=self.overtake_min_score_gap,
            items=rows,
        )

    def _eligible(self, frame: AbsorptionFrame) -> bool:
        if frame.stage not in self.ORDER:
            return False
        if frame.model == AbsorptionModel.NONE:
            return False
        if frame.preemptive_fit == "EXCLUDE":
            return False
        if frame.stage_trust in self.BAD_TRUST or frame.price_trust in self.BAD_TRUST:
            return False
        return True

    def _hard_exit(self, frame: AbsorptionFrame | None) -> bool:
        if frame is None:
            return False
        if frame.stage in self.HARD_EXIT or frame.preemptive_fit == "EXCLUDE":
            return True
        if frame.stage_trust in self.BAD_TRUST or frame.price_trust in self.BAD_TRUST:
            return True
        return False

    def _update(self, now: datetime) -> None:
        frames = self.source.frames
        kept: list[_Member] = []
        for member in self._members:
            frame = frames.get(member.symbol)
            if self._hard_exit(frame):
                self._drop(member.symbol)
                continue
            if frame is None or not self._eligible(frame):
                member.miss_since = member.miss_since or now
                if (now - member.miss_since).total_seconds() >= self.missing_grace_sec:
                    self._drop(member.symbol)
                    continue
            else:
                member.miss_since = None
                member.last_frame = frame
            kept.append(member)
        self._members = kept

        member_symbols = {m.symbol for m in self._members}
        eligible = [f for f in frames.values() if self._eligible(f)]
        eligible.sort(key=lambda f: (self.ORDER[f.stage], f.score_100, f.price_defense_score_25), reverse=True)

        for frame in eligible:
            if frame.symbol in member_symbols:
                continue
            first = self._qualification_since.setdefault(frame.symbol, now)
            high_stage = self.ORDER[frame.stage] >= self.ORDER[AbsorptionStage.PRICE_HOLD]
            if not high_stage and (now - first).total_seconds() < self.qualification_dwell_sec:
                continue
            if len(self._members) < self.fixed_rows:
                self._members.append(_Member(frame.symbol, now, frame))
                member_symbols.add(frame.symbol)
                self._qualification_since.pop(frame.symbol, None)
                continue
            weakest = min(self._members, key=lambda m: self._rank_key(frames.get(m.symbol) or m.last_frame))
            weakest_frame = frames.get(weakest.symbol) or weakest.last_frame
            stronger_stage = self.ORDER[frame.stage] > self.ORDER.get(weakest_frame.stage, 0)
            weakest_age = (now - weakest.joined_at).total_seconds()
            score_replace = weakest_age >= self.membership_commit_sec and frame.score_100 >= weakest_frame.score_100 + self.overtake_min_score_gap
            if stronger_stage or score_replace:
                idx = self._members.index(weakest)
                self._drop(weakest.symbol)
                self._members[idx] = _Member(frame.symbol, now, frame)
                member_symbols.discard(weakest.symbol)
                member_symbols.add(frame.symbol)
                self._qualification_since.pop(frame.symbol, None)

        self._stabilize(now)

    def _stabilize(self, now: datetime) -> None:
        frames = self.source.frames
        passes = 0
        changed = True
        while changed and passes < self.fixed_rows:
            changed = False
            passes += 1
            for i in range(1, len(self._members)):
                ahead, behind = self._members[i - 1], self._members[i]
                if ahead.miss_since is not None or behind.miss_since is not None:
                    continue
                fa = frames.get(ahead.symbol) or ahead.last_frame
                fb = frames.get(behind.symbol) or behind.last_frame
                sa, sb = self.ORDER.get(fa.stage, 0), self.ORDER.get(fb.stage, 0)
                if sb > sa:
                    self._members[i - 1], self._members[i] = behind, ahead
                    changed = True
                    continue
                if sb < sa:
                    continue
                gap = fb.score_100 - fa.score_100
                key = (behind.symbol, ahead.symbol)
                if gap < self.overtake_min_score_gap:
                    self._overtake.pop(key, None)
                    continue
                count, since = self._overtake.get(key, (0, now))
                count += 1
                self._overtake[key] = (count, since)
                if count >= self.overtake_required_checks or (now - since).total_seconds() >= self.overtake_max_wait_sec:
                    self._members[i - 1], self._members[i] = behind, ahead
                    self._overtake.pop(key, None)
                    changed = True

    def _row(self, rank: int, frame: AbsorptionFrame, member: _Member, age: float, in_grace: bool) -> KrxBoardRow:
        data = None
        if self.enrichment is not None:
            x = self.enrichment.get(frame.symbol)
            if x is not None:
                data = x.model_dump(mode="json")
        flags: list[str] = []
        if in_grace:
            flags.append("MEMBERSHIP_GRACE")
        if frame.price_compression:
            flags.append("PRICE_COMPRESSION")
        return KrxBoardRow(
            rank=rank,
            symbol=frame.symbol,
            model=frame.model.value,
            stage=frame.stage.value,
            price=frame.price,
            change_rate=frame.change_rate,
            score_100=frame.score_100,
            price_hold_score_25=frame.price_defense_score_25,
            price_hold_pass=frame.price_hold_pass,
            absorption_ratio=frame.absorption_ratio,
            seller_actor=frame.seller_actor,
            seller_velocity=frame.seller_new_sell_velocity_per_min,
            seller_decel_count=frame.seller_sell_deceleration_count,
            vwap_distance_pct=frame.vwap_distance_pct,
            market_rs=frame.rs_level,
            sector_rs=frame.sector_relative_strength_pct,
            sector_breadth_ratio=frame.sector_breadth_ratio,
            price_compression=frame.price_compression,
            preemptive_fit=frame.preemptive_fit,
            stage_trust=frame.stage_trust.value,
            current_data=data,
            member_since=member.joined_at,
            membership_age_sec=round(age, 2),
            membership_committed=age >= self.membership_commit_sec,
            source_asof=frame.asof,
            flags=flags,
        )

    def _rank_key(self, frame: AbsorptionFrame) -> tuple[int, float, float]:
        return (self.ORDER.get(frame.stage, 0), float(frame.score_100), float(frame.price_defense_score_25))

    def _drop(self, symbol: str) -> None:
        self._qualification_since.pop(symbol, None)
        for key in [k for k in self._overtake if symbol in k]:
            self._overtake.pop(key, None)
