from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Any, Iterable

from pulse_edge.core.models import NormalizedEvent, RawEvent, Venue
from pulse_edge.core.venue import split_item
from pulse_edge.feed.fids import decode_values

KST = ZoneInfo("Asia/Seoul")


def _extract_data_rows(payload: dict[str, Any]) -> Iterable[dict[str, Any]]:
    data = payload.get("data")
    if isinstance(data, list):
        for row in data:
            if isinstance(row, dict):
                yield row
    elif isinstance(data, dict):
        yield data


def _parse_event_time(receive_time: datetime, decoded: dict[str, Any]) -> datetime | None:
    raw = decoded.get("trade_time") or decoded.get("quote_time")
    if raw is None:
        return None
    text = "".join(ch for ch in str(raw) if ch.isdigit())
    if len(text) < 6:
        return None
    text = text[-6:]
    try:
        hh, mm, ss = int(text[:2]), int(text[2:4]), int(text[4:6])
        if hh > 23 or mm > 59 or ss > 59:
            return None
    except ValueError:
        return None
    recv_kst = receive_time.astimezone(KST)
    event = recv_kst.replace(hour=hh, minute=mm, second=ss, microsecond=0)
    if event - recv_kst > timedelta(hours=12):
        event -= timedelta(days=1)
    elif recv_kst - event > timedelta(hours=12):
        event += timedelta(days=1)
    return event


def _identity(real_type: str | None, item: object) -> tuple[str | None, Venue]:
    text = str(item).strip() if item is not None else ""
    if real_type in {"0J", "0U"} and text:
        return text, Venue.KRX
    if real_type == "0s":
        return None, Venue.UNKNOWN
    return split_item(text or None)


def normalize(raw: RawEvent) -> list[NormalizedEvent]:
    payload = raw.payload
    trnm = str(payload.get("trnm") or payload.get("type") or "").upper() or None
    if trnm != "REAL":
        return []

    output: list[NormalizedEvent] = []
    for row in _extract_data_rows(payload):
        real_type = str(row.get("type") or "").strip() or None
        item = row.get("item") if "item" in row else row.get("stk_cd") or payload.get("item")
        values = row.get("values") if isinstance(row.get("values"), dict) else {}
        symbol, venue = _identity(real_type, item)
        decoded = decode_values(real_type, values)
        output.append(
            NormalizedEvent(
                receive_time=raw.receive_time,
                event_time=_parse_event_time(raw.receive_time, decoded),
                source=raw.source,
                trnm=trnm,
                real_type=real_type,
                name=str(row.get("name")) if row.get("name") is not None else None,
                item=str(item) if item is not None else None,
                symbol=symbol,
                venue=venue,
                data=decoded,
                values={str(k): v for k, v in values.items()},
                raw=payload,
            )
        )
    return output
