from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque

from pulse_edge.core.models import NormalizedEvent, RawEvent, TruthStatus, Venue


@dataclass
class SymbolFeedState:
    events_by_type: dict[str, NormalizedEvent] = field(default_factory=dict)

    def apply(self, event: NormalizedEvent) -> None:
        if event.real_type:
            self.events_by_type[event.real_type] = event


class FeedState:
    def __init__(self, raw_ring_size: int = 1000) -> None:
        self.krx: dict[str, SymbolFeedState] = {}
        self.nxt: dict[str, SymbolFeedState] = {}
        self.sor: dict[str, SymbolFeedState] = {}
        self.global_events_by_type: dict[str, NormalizedEvent] = {}
        self.raw: Deque[RawEvent] = deque(maxlen=raw_ring_size)

    def add_raw(self, raw: RawEvent) -> None:
        self.raw.append(raw)

    def _book(self, venue: Venue) -> dict[str, SymbolFeedState] | None:
        if venue == Venue.KRX:
            return self.krx
        if venue == Venue.NXT:
            return self.nxt
        if venue == Venue.SOR:
            return self.sor
        return None

    def apply(self, event: NormalizedEvent, status: TruthStatus) -> bool:
        if status != TruthStatus.LIVE:
            return False
        if event.real_type == "0s":
            self.global_events_by_type["0s"] = event
            return True
        if not event.symbol:
            return False
        book = self._book(event.venue)
        if book is None:
            return False
        book.setdefault(event.symbol, SymbolFeedState()).apply(event)
        return True
