from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Awaitable, Callable
from typing import Any
import websockets


OnPayload = Callable[[dict], Awaitable[None]]


def _chunks(items: list[str], size: int = 100) -> list[list[str]]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def build_registrations(
    base_group: str,
    stock_items: list[str],
    stock_types: list[str],
    global_types: list[str],
    index_items: list[str],
    index_types: list[str],
) -> list[dict[str, Any]]:
    try:
        base = int(base_group)
    except ValueError:
        base = 1001
    regs: list[dict[str, Any]] = []
    for offset, chunk in enumerate(_chunks(sorted(set(stock_items)))):
        if chunk and stock_types:
            regs.append({"grp_no": str(base + offset), "item": chunk, "type": stock_types})
    next_group = base + 100
    if global_types:
        regs.append({"grp_no": str(next_group), "item": [], "type": global_types})
    if index_items and index_types:
        regs.append({"grp_no": str(next_group + 1), "item": sorted(set(index_items)), "type": index_types})
    return regs


class KiwoomWebSocket:
    """Single Kiwoom realtime connection with in-memory dynamic stock registrations.

    Dynamically discovered item names exist only in this process. A process restart
    starts with the configured static registration set and receives no prior-session
    names from disk or any archive.
    """

    def __init__(
        self,
        url: str,
        token_getter: Callable[[], Awaitable[str]],
        registrations: list[dict[str, Any]],
        on_payload: OnPayload,
        *,
        dynamic_group_base: int = 2000,
        dynamic_stock_types: list[str] | None = None,
        max_dynamic_items: int = 600,
        background_reserve_items: int = 120,
    ) -> None:
        self.url = url
        self.token_getter = token_getter
        self.registrations = registrations
        self.on_payload = on_payload
        self.dynamic_group_base = int(dynamic_group_base)
        self.dynamic_stock_types = list(dynamic_stock_types or ["0B", "0C", "0D", "0H", "0w"])
        self.max_dynamic_items = int(max_dynamic_items)
        self.background_reserve_items = max(0, int(background_reserve_items))
        self._event_stock_seen: dict[str, float] = {}
        self._background_stock_items: set[str] = set()
        self.event_subscription_ttl_sec = 1200.0
        self._stop = asyncio.Event()
        self._ws: Any | None = None
        self._send_lock = asyncio.Lock()
        self.connected = False
        self.last_error: str | None = None
        self.dynamic_refresh_count = 0
        self.connection_count = 0
        self.reconnect_count = 0
        self.last_connected_at: float | None = None
        self.last_disconnected_at: float | None = None
        self.last_message_at: float | None = None

    @property
    def dynamic_stock_items(self) -> list[str]:
        # Current-event names have priority; background coverage fills the rest.
        now = time.monotonic()
        self._event_stock_seen = {
            item: seen for item, seen in self._event_stock_seen.items()
            if now - seen <= self.event_subscription_ttl_sec
        }
        event = [item for item, _ in sorted(self._event_stock_seen.items(), key=lambda kv: kv[1], reverse=True)]
        if self._background_stock_items:
            reserved_cap = max(1, self.max_dynamic_items // 3)
            reserved = min(self.background_reserve_items, reserved_cap, len(self._background_stock_items))
            event = event[: max(0, self.max_dynamic_items - reserved)]
        else:
            event = event[: self.max_dynamic_items]
        remaining = max(0, self.max_dynamic_items - len(event))
        event_set = set(event)
        background = [x for x in sorted(self._background_stock_items) if x not in event_set][:remaining]
        return (event + background)[: self.max_dynamic_items]

    @property
    def event_stock_items(self) -> list[str]:
        return [item for item in self.dynamic_stock_items if item in self._event_stock_seen]

    @property
    def background_stock_items(self) -> list[str]:
        return sorted(self._background_stock_items)

    async def stop(self) -> None:
        self._stop.set()

    async def add_stock_items(self, items: list[str]) -> None:
        # Preserve caller priority deterministically. Discovery can return more
        # names than the realtime capacity; assigning every item the exact same
        # timestamp made the retained set depend on dict/ticker ordering. The
        # caller now supplies rank-priority order and earlier names receive a
        # tiny monotonic priority lead while still belonging to the same scan.
        clean: list[str] = []
        seen: set[str] = set()
        for raw in items:
            item = str(raw).strip()
            if item and item not in seen:
                seen.add(item)
                clean.append(item)
        if not clean:
            return
        before = set(self.dynamic_stock_items)
        seen_at = time.monotonic()
        for idx, item in enumerate(clean):
            self._event_stock_seen[item] = seen_at - (idx * 1e-6)
        if len(self._event_stock_seen) > self.max_dynamic_items:
            newest = sorted(self._event_stock_seen.items(), key=lambda kv: kv[1], reverse=True)[: self.max_dynamic_items]
            self._event_stock_seen = dict(newest)
        if set(self.dynamic_stock_items) != before and self.connected and self._ws is not None:
            await self._send_dynamic_registrations(self._ws)

    async def set_background_items(self, items: list[str]) -> None:
        before = set(self.dynamic_stock_items)
        self._background_stock_items = {str(x).strip() for x in items if str(x).strip()}
        if set(self.dynamic_stock_items) != before and self.connected and self._ws is not None:
            await self._send_dynamic_registrations(self._ws)

    async def run_forever(self) -> None:
        backoff = 1.0
        while not self._stop.is_set():
            try:
                await self._run_once()
                backoff = 1.0
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.connected = False
                self._ws = None
                self.last_disconnected_at = time.time()
                self.last_error = f"{type(exc).__name__}: {exc}"
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2.0, 30.0)

    async def _send_reg(self, ws: Any, reg: dict[str, Any], *, refresh: str = "1") -> None:
        packet = {
            "trnm": "REG",
            "grp_no": reg["grp_no"],
            "refresh": refresh,
            "data": [{"item": reg["item"], "type": reg["type"]}],
        }
        async with self._send_lock:
            await ws.send(json.dumps(packet, ensure_ascii=False))

    async def _send_dynamic_registrations(self, ws: Any) -> None:
        items = self.dynamic_stock_items
        chunks = _chunks(items, 100)
        # refresh=0 replaces prior item/type membership in each dynamic group.
        # Send every configured slot, including an empty item list, so a rotated
        # background batch cannot leave an older group subscribed by accident.
        slots = max(1, (self.max_dynamic_items + 99) // 100)
        for offset in range(slots):
            chunk = chunks[offset] if offset < len(chunks) else []
            await self._send_reg(
                ws,
                {
                    "grp_no": str(self.dynamic_group_base + offset),
                    "item": chunk,
                    "type": self.dynamic_stock_types,
                },
                refresh="0",
            )
        self.dynamic_refresh_count += 1

    async def _run_once(self) -> None:
        token = await self.token_getter()
        async with websockets.connect(self.url, ping_interval=20, ping_timeout=20, close_timeout=5) as ws:
            self._ws = ws
            self.connected = True
            self.connection_count += 1
            self.reconnect_count = max(0, self.connection_count - 1)
            self.last_connected_at = time.time()
            self.last_error = None
            await ws.send(json.dumps({"trnm": "LOGIN", "token": token}, ensure_ascii=False))
            login_ack = json.loads(await ws.recv())
            if str(login_ack.get("return_code", "0")) != "0":
                raise RuntimeError(f"WS LOGIN failed: {login_ack.get('return_msg', 'unknown')}")

            for reg in self.registrations:
                await self._send_reg(ws, reg)
            await self._send_dynamic_registrations(ws)

            async for message in ws:
                if self._stop.is_set():
                    break
                self.last_message_at = time.time()
                payload = json.loads(message)
                if payload.get("trnm") == "PING":
                    async with self._send_lock:
                        await ws.send(message)
                    continue
                await self.on_payload(payload)
        self.connected = False
        self._ws = None
        self.last_disconnected_at = time.time()
