from __future__ import annotations

from typing import Any

COMMON_PRICE = {
    "20": "trade_time",
    "10": "price",
    "11": "change",
    "12": "change_rate",
    "15": "trade_volume",
    "13": "cumulative_volume",
    "14": "cumulative_amount",
    "25": "change_sign",
}

TRADE_EXTRA = {
    "1030": "sell_exec_volume",
    "1031": "buy_exec_volume",
    "1032": "buy_exec_ratio",
    "1071": "sell_exec_count",
    "1072": "buy_exec_count",
    "1313": "instant_amount",
    "1315": "sell_exec_single",
    "1316": "buy_exec_single",
    "1314": "net_buy_exec_volume",
    "620": "day_average_price",
    "9081": "exchange_code",
}

PROGRAM = {
    **COMMON_PRICE,
    "202": "program_sell_qty",
    "204": "program_sell_amount",
    "206": "program_buy_qty",
    "208": "program_buy_amount",
    "210": "program_net_buy_qty",
    "211": "program_net_buy_qty_delta",
    "212": "program_net_buy_amount",
    "213": "program_net_buy_amount_delta",
    "214": "market_remaining_time",
    "215": "market_operation",
    "216": "investor_ticker",
}

FID_MAPS: dict[str, dict[str, str]] = {
    "0B": {**COMMON_PRICE, **TRADE_EXTRA},
    "0H": COMMON_PRICE,
    "0J": COMMON_PRICE,
    "0C": {"21": "quote_time", "27": "ask1", "28": "bid1"},
    "0D": {
        "21": "quote_time",
        "41": "ask1",
        "51": "bid1",
        "61": "ask1_qty",
        "71": "bid1_qty",
        "121": "total_ask_qty",
        "125": "total_bid_qty",
        "128": "net_bid_qty",
        "129": "bid_ratio",
        "138": "net_ask_qty",
        "139": "ask_ratio",
        "291": "expected_price",
        "292": "expected_volume",
        "295": "expected_change_rate",
    },
    "0s": {"215": "market_operation", "20": "trade_time", "214": "market_remaining_time"},
    "0w": PROGRAM,
    "0U": {
        "20": "trade_time",
        "252": "rising_count",
        "251": "upper_limit_count",
        "253": "flat_count",
        "254": "falling_count",
        "255": "lower_limit_count",
    },
}


def decode_values(real_type: str | None, values: dict[str, Any]) -> dict[str, Any]:
    mapping = FID_MAPS.get(str(real_type or ""), {})
    out: dict[str, Any] = {}
    for fid, value in values.items():
        key = mapping.get(str(fid), f"fid_{fid}")
        out[key] = value
    return out
