from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from pulse_edge.core.models import NormalizedEvent, TruthStatus, Venue

KST = ZoneInfo("Asia/Seoul")


def _int_abs(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return abs(int(float(str(value).replace(",", "").strip())))
    except (TypeError, ValueError):
        return None


@dataclass
class _SeenVolume:
    day: date
    cumulative_volume: int


class ContinuityGuard:
    """Reject timestamp regression and same-session actual-volume regression."""

    def __init__(self, timestamp_regression_tolerance_sec: float = 1.0) -> None:
        self._volume_seen: dict[tuple[Venue, str], _SeenVolume] = {}
        self._time_seen: dict[tuple[Venue, str, str], datetime] = {}
        self.timestamp_regression_tolerance = timedelta(seconds=timestamp_regression_tolerance_sec)
        self.volume_rejects = 0
        self.time_rejects = 0

    @property
    def rejects(self) -> int:
        return self.volume_rejects + self.time_rejects

    def check(self, event: NormalizedEvent, status: TruthStatus) -> tuple[TruthStatus, list[str]]:
        if status != TruthStatus.LIVE:
            return status, []

        reasons: list[str] = []
        if event.event_time is not None:
            time_key = (event.venue, event.symbol or "", event.real_type or "")
            prev_time = self._time_seen.get(time_key)
            if prev_time and event.event_time < prev_time - self.timestamp_regression_tolerance:
                self.time_rejects += 1
                return TruthStatus.INVALID, ["event_timestamp_regressed"]
            if prev_time is None or event.event_time > prev_time:
                self._time_seen[time_key] = event.event_time

        if event.real_type != "0B" or not event.symbol:
            return status, reasons

        cv = _int_abs(event.data.get("cumulative_volume"))
        if cv is None:
            return TruthStatus.PARTIAL, ["missing_cumulative_volume"]
        local_day = (event.event_time or event.receive_time).astimezone(KST).date()
        key = (event.venue, event.symbol)
        prev = self._volume_seen.get(key)
        if prev and prev.day == local_day and cv < prev.cumulative_volume:
            self.volume_rejects += 1
            return TruthStatus.INVALID, ["cumulative_volume_regressed"]
        self._volume_seen[key] = _SeenVolume(day=local_day, cumulative_volume=cv)
        return status, reasons
