from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable

from pulse_edge.core.models import NormalizedEvent, TruthResult, TruthStatus, Venue

PRICE_REQUIRED = {"0B", "0H", "0J", "0w"}
TIME_EXPECTED = {"0B", "0C", "0D", "0H", "0J", "0U", "0s", "0w"}
SYMBOL_EXPECTED = {"0B", "0C", "0D", "0H", "0J", "0U", "0w"}


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip().replace(",", "")
    if not text:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


class FeedTruth:
    def __init__(
        self,
        receive_stale_after_sec: float = 5.0,
        event_stale_after_sec: float = 7.0,
        future_tolerance_sec: float = 2.0,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self.receive_stale_after_sec = receive_stale_after_sec
        self.event_stale_after_sec = event_stale_after_sec
        self.future_tolerance_sec = future_tolerance_sec
        self.now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        self.counters: dict[str, int] = {s.value: 0 for s in TruthStatus}
        self.last_reasons: list[str] = []

    def validate(self, event: NormalizedEvent) -> TruthResult:
        reasons: list[str] = []
        now = self.now_fn()
        receive_age = (now - event.receive_time).total_seconds()
        event_age = None if event.event_time is None else (now - event.event_time).total_seconds()

        if receive_age > self.receive_stale_after_sec:
            reasons.append("receive_age_exceeded")
        if receive_age < -self.future_tolerance_sec:
            reasons.append("receive_time_in_future")
        if event.real_type in TIME_EXPECTED and event.event_time is None:
            reasons.append("missing_event_time")
        if event_age is not None and event_age > self.event_stale_after_sec:
            reasons.append("event_age_exceeded")
        if event_age is not None and event_age < -self.future_tolerance_sec:
            reasons.append("event_time_in_future")

        if event.trnm != "REAL":
            reasons.append("not_real_event")
        if not event.real_type:
            reasons.append("missing_real_type")
        if event.real_type in SYMBOL_EXPECTED and not event.symbol:
            reasons.append("missing_symbol")
        if event.real_type in SYMBOL_EXPECTED and event.venue == Venue.UNKNOWN:
            reasons.append("unknown_venue")
        if not isinstance(event.values, dict):
            reasons.append("values_not_object")
        if event.raw.get("return_code") not in (None, 0, "0"):
            reasons.append("upstream_return_code_nonzero")

        if event.real_type in PRICE_REQUIRED:
            price = _num(event.data.get("price"))
            if price is None:
                reasons.append("missing_or_non_numeric_price")
            elif price == 0:
                reasons.append("zero_price")

        if event.real_type == "0C":
            ask = _num(event.data.get("ask1"))
            bid = _num(event.data.get("bid1"))
            if ask is None or bid is None:
                reasons.append("missing_best_quote")

        fatal = {
            "upstream_return_code_nonzero",
            "not_real_event",
            "missing_real_type",
            "missing_symbol",
            "unknown_venue",
            "missing_or_non_numeric_price",
            "zero_price",
            "receive_time_in_future",
            "event_time_in_future",
        }
        stale = {"receive_age_exceeded", "event_age_exceeded"}
        if any(r in fatal for r in reasons):
            status = TruthStatus.INVALID
        elif any(r in stale for r in reasons):
            status = TruthStatus.STALE
        elif reasons:
            status = TruthStatus.PARTIAL
        else:
            status = TruthStatus.LIVE

        self.counters[status.value] += 1
        self.last_reasons = reasons[-20:]
        return TruthResult(
            status=status,
            reasons=reasons,
            receive_age_sec=receive_age,
            event_age_sec=event_age,
            event=event,
        )
