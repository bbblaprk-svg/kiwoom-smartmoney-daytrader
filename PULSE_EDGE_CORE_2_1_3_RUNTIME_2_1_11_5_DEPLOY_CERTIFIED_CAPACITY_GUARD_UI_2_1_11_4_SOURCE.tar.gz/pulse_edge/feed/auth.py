from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import httpx

KST = ZoneInfo("Asia/Seoul")


class KiwoomAuth:
    def __init__(self, base_url: str, appkey: str, secretkey: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.appkey = appkey
        self.secretkey = secretkey
        self._token: str | None = None
        self._expires_at: datetime | None = None
        self._lock = asyncio.Lock()

    async def token(self) -> str:
        async with self._lock:
            now = datetime.now(timezone.utc)
            if self._token and self._expires_at and now < self._expires_at - timedelta(minutes=2):
                return self._token
            if not self.appkey or not self.secretkey:
                raise RuntimeError("Kiwoom credentials are not configured")
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    f"{self.base_url}/oauth2/token",
                    json={
                        "grant_type": "client_credentials",
                        "appkey": self.appkey,
                        "secretkey": self.secretkey,
                    },
                    headers={"Content-Type": "application/json;charset=UTF-8"},
                )
                response.raise_for_status()
                body = response.json()
            if int(body.get("return_code", 0)) != 0 or not body.get("token"):
                raise RuntimeError(f"Kiwoom token error: {body.get('return_msg', 'unknown')}")
            self._token = str(body["token"])
            raw_exp = str(body.get("expires_dt", ""))
            try:
                parsed = datetime.strptime(raw_exp, "%Y%m%d%H%M%S").replace(tzinfo=KST)
                self._expires_at = parsed.astimezone(timezone.utc)
            except ValueError:
                self._expires_at = now + timedelta(hours=12)
            return self._token
