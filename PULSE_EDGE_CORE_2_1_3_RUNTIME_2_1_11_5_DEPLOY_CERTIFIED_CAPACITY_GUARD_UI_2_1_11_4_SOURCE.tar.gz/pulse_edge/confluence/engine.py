from __future__ import annotations

from datetime import datetime
from typing import Any

from pulse_edge.confluence.models import ConfluenceFrame, ConfluenceGrade, DecisionStage, PrimaryEngine
from pulse_edge.features.models import FeatureFrame
from pulse_edge.ignition.models import IgnitionFrame, IgnitionStage
from pulse_edge.patterns.models import (
    OrbFrame, OrbStage, SqueezeFrame, SqueezeStage, VwapReclaimFrame, VwapReclaimStage,
)
from pulse_edge.pullback.models import PullbackFrame, PullbackStage
from pulse_edge.regime.models import MarketRegimeFrame, MarketRegimeState
from pulse_edge.smart_money.models import SmartMoneyFrame, SmartMoneyStage
from pulse_edge.spillover.models import SpilloverFrame, SpilloverStage


class ConfluenceEngine:
    """Combines exactly five independent evidence groups without duplicate voting.

    Phase 4A.1 integration rules:
    - ORB/SQUEEZE/VWAP/NXT may strengthen only the existing price_structure group.
    - realtime OFI/Microprice/aggressive execution may strengthen only the existing flow group.
    - no sixth vote is introduced and no upstream discovery score is changed.
    """

    WEIGHTS = {
        "price_structure": 20.0,
        "flow": 25.0,
        "activity": 20.0,
        "relative_strength": 15.0,
        "cluster_persistence": 20.0,
    }

    def evaluate(
        self,
        smart: SmartMoneyFrame,
        feature: FeatureFrame | None,
        ignition: IgnitionFrame | None,
        spillover: SpilloverFrame | None,
        pullback: PullbackFrame | None,
        regime: MarketRegimeFrame,
        *,
        orb: OrbFrame | None = None,
        squeeze: SqueezeFrame | None = None,
        reclaim: VwapReclaimFrame | None = None,
        bridge: Any | None = None,
        asof: datetime,
    ) -> ConfluenceFrame:
        if feature is None:
            return ConfluenceFrame(
                venue=smart.venue,
                symbol=smart.symbol,
                asof=asof,
                price=smart.price,
                change_rate=smart.change_rate,
                regime_state=regime.state,
                regime_score_100=regime.regime_score_100,
                decision_stage=DecisionStage.DATA_WAIT,
                flags=["FEATURE_FRAME_MISSING"],
            )

        evidence, details = self._evidence(
            smart, feature, ignition, spillover, pullback, orb, squeeze, reclaim, bridge
        )
        count = sum(1 for value in evidence.values() if value)
        score = sum(self.WEIGHTS[name] for name, value in evidence.items() if value)
        primary = self._primary(smart, ignition, spillover, pullback, orb, squeeze, reclaim, bridge)
        preferred = primary.value in set(regime.preferred_engines)

        return ConfluenceFrame(
            venue=smart.venue,
            symbol=smart.symbol,
            asof=asof,
            price=feature.price,
            change_rate=feature.change_rate,
            primary_engine=primary,
            decision_stage=DecisionStage.WATCH_SHADOW,
            confluence_grade=self._grade(count, False),
            confluence_score_100=score,
            evidence_count=count,
            evidence_groups=evidence,
            evidence_details=details,
            regime_state=regime.state,
            regime_score_100=regime.regime_score_100,
            strategy_preferred_by_regime=preferred,
            official_signal_enabled=False,
            flags=[] if preferred or regime.state != MarketRegimeState.YELLOW else ["REGIME_STRATEGY_NOT_PREFERRED"],
        )

    @staticmethod
    def _primary(smart, ignition, spillover, pullback, orb, squeeze, reclaim, bridge) -> PrimaryEngine:
        # Phase 4C.1 keeps the same structural priority already used by the
        # PRE-BUY decision layer so regime routing and hard-gate fit cannot lag
        # behind a confirmed current pattern.
        if smart.venue.value == "NXT" and bridge is not None and getattr(bridge.stage, "value", str(bridge.stage)) == "NXT_CONFIRM_SHADOW":
            return PrimaryEngine.NXT_BRIDGE
        if pullback is not None and pullback.stage in {PullbackStage.SECOND_WAVE_SHADOW, PullbackStage.REACCEL_WATCH}:
            return PrimaryEngine.SECOND_WAVE
        if reclaim is not None and reclaim.stage == VwapReclaimStage.VWAP_RECLAIM_SHADOW:
            return PrimaryEngine.VWAP_RECLAIM
        if orb is not None and orb.stage == OrbStage.ORB_RETEST_CONFIRMED_SHADOW:
            return PrimaryEngine.ORB_RETEST
        if squeeze is not None and squeeze.stage == SqueezeStage.SQUEEZE_RELEASE_SHADOW:
            return PrimaryEngine.SQUEEZE_RELEASE
        if spillover is not None and spillover.stage == SpilloverStage.EARLY_FOLLOWER_SHADOW:
            return PrimaryEngine.EARLY_FOLLOWER
        if ignition is not None and ignition.stage in {
            IgnitionStage.FLOW_IGNITION_SHADOW,
            IgnitionStage.VERIFIED_CATALYST_IGNITION_SHADOW,
        }:
            return PrimaryEngine.IGNITION
        if smart.stage == SmartMoneyStage.PRE_SHADOW:
            return PrimaryEngine.SMART_PRE
        return PrimaryEngine.OBSERVE

    @staticmethod
    def _price_structure_detail(smart, ignition, pullback, orb, squeeze, reclaim, bridge) -> tuple[bool, str]:
        if smart.venue.value == "NXT" and bridge is not None and getattr(bridge.stage, "value", str(bridge.stage)) == "NXT_CONFIRM_SHADOW":
            return True, "NXT_BRIDGE_CONFIRM"
        if pullback is not None and pullback.stage in {PullbackStage.SECOND_WAVE_SHADOW, PullbackStage.REACCEL_WATCH}:
            return True, pullback.stage.value
        if reclaim is not None and reclaim.stage == VwapReclaimStage.VWAP_RECLAIM_SHADOW:
            return True, "VWAP_RECLAIM_SHADOW"
        if orb is not None and orb.stage == OrbStage.ORB_RETEST_CONFIRMED_SHADOW:
            return True, "ORB_RETEST_CONFIRMED_SHADOW"
        if squeeze is not None and squeeze.stage == SqueezeStage.SQUEEZE_RELEASE_SHADOW:
            return True, "SQUEEZE_RELEASE_SHADOW"
        if ignition is not None and ignition.price_quality_score_15 >= 8 and not ignition.veto:
            return True, "IGNITION_PRICE_QUALITY"
        if smart.compression_score >= 10 and (smart.vwap_distance_pct is None or -1.0 <= smart.vwap_distance_pct <= 2.5):
            return True, "COMPRESSION_UNDERREACTION"
        return False, "none"

    @staticmethod
    def _realtime_flow_confirmed(feature: FeatureFrame) -> bool:
        if feature.quote_age_sec is None or feature.quote_age_sec > 3.5:
            return False
        if feature.smart_flow_confirmed_windows < 2:
            return False
        if feature.smart_flow_realtime_score_100 is None or feature.smart_flow_realtime_score_100 < 52.0:
            return False
        # Require actual trade pressure plus quote/order-book confirmation when available.
        trade_ok = any(
            x is not None and x >= 0.10
            for x in (feature.trade_pressure_10s, feature.trade_pressure_30s, feature.trade_pressure_2m)
        ) or any(
            x is not None and x >= 55.0
            for x in (feature.aggressive_buy_ratio_10s, feature.aggressive_buy_ratio_30s, feature.aggressive_buy_ratio_2m)
        )
        quote_ok = any(
            x is not None and x >= 0.10
            for x in (feature.ofi_10s, feature.ofi_30s, feature.ofi_2m)
        )
        if feature.microprice_bias_pct is not None and feature.microprice_bias_pct > 0:
            quote_ok = True
        return trade_ok and quote_ok

    @classmethod
    def _evidence(cls, smart, feature, ignition, spillover, pullback, orb=None, squeeze=None, reclaim=None, bridge=None):
        price, price_detail = cls._price_structure_detail(
            smart, ignition, pullback, orb, squeeze, reclaim, bridge
        )

        investor_program_flow = (
            (smart.foreign_flow_acceleration is not None and smart.foreign_flow_acceleration > 0)
            or (smart.program_net_buy_amount_delta is not None and smart.program_net_buy_amount_delta > 0)
            or (smart.intraday_foreign_net is not None and smart.intraday_foreign_net > 0)
        )
        realtime_flow = cls._realtime_flow_confirmed(feature)
        flow = investor_program_flow or realtime_flow
        if investor_program_flow and realtime_flow:
            flow_detail = "FLOW_FACTS_PLUS_REALTIME_ORDERFLOW"
        elif realtime_flow:
            flow_detail = f"REALTIME_ORDERFLOW_{feature.smart_flow_state}"
        elif investor_program_flow:
            flow_detail = "INVESTOR_PROGRAM_FLOW_POSITIVE"
        else:
            flow_detail = "FLOW_NOT_CONFIRMED"

        activity = (
            (feature.money_acceleration is not None and feature.money_acceleration > 0)
            and (
                (feature.money_second_derivative is not None and feature.money_second_derivative > 0)
                or (feature.rvol_same_time is not None and feature.rvol_same_time >= 1.3)
            )
        )
        rs = (
            feature.rs_acceleration is not None and feature.rs_acceleration > 0
            and (feature.rs_velocity is None or feature.rs_velocity > 0)
        )
        cluster = (
            smart.sector_score >= 10.5
            or (spillover is not None and spillover.stage in {SpilloverStage.EARLY_FOLLOWER_SHADOW, SpilloverStage.LEADER_SHADOW})
        )
        evidence = {
            "price_structure": price,
            "flow": flow,
            "activity": activity,
            "relative_strength": rs,
            "cluster_persistence": cluster,
        }
        details = {
            "price_structure": price_detail,
            "flow": flow_detail,
            "activity": "MONEY_ACCEL_CONFIRMED" if activity else "ACTIVITY_NOT_CONFIRMED",
            "relative_strength": "RS_ACCEL_CONFIRMED" if rs else "RS_NOT_CONFIRMED",
            "cluster_persistence": "SECTOR_CONFIRMED" if cluster else "SECTOR_NOT_CONFIRMED",
        }
        return evidence, details

    @staticmethod
    def _grade(count: int, hard_gate_pass: bool) -> ConfluenceGrade:
        if count >= 5 and hard_gate_pass:
            return ConfluenceGrade.A_PLUS_SHADOW
        if count >= 4:
            return ConfluenceGrade.HIGH
        if count == 3:
            return ConfluenceGrade.MID
        if count >= 1:
            return ConfluenceGrade.SINGLE
        return ConfluenceGrade.NONE

    @classmethod
    def finalize(cls, frame: ConfluenceFrame, *, base_gate_pass: bool, hard_gate_pass: bool, persistence_count: int,
                 gate_results: dict[str, bool], gate_failures: list[str], tick_age_sec: float | None,
                 discovery_source_count: int, spread_pct: float | None, money_5m: float | None,
                 universe_eligible: bool = False, universe_eligibility_reasons: list[str] | None = None) -> ConfluenceFrame:
        grade = cls._grade(frame.evidence_count, hard_gate_pass)
        if frame.decision_stage == DecisionStage.DATA_WAIT:
            stage = DecisionStage.DATA_WAIT
        elif not base_gate_pass:
            stage = DecisionStage.BLOCKED_SHADOW
        elif frame.evidence_count >= 5 and hard_gate_pass:
            stage = DecisionStage.A_PLUS_ELIGIBLE_SHADOW
        elif frame.evidence_count >= 4 and hard_gate_pass:
            stage = DecisionStage.ENTRY_ELIGIBLE_SHADOW
        elif frame.evidence_count >= 3:
            stage = DecisionStage.READY_SHADOW
        else:
            stage = DecisionStage.WATCH_SHADOW
        flags = list(frame.flags)
        if base_gate_pass and not hard_gate_pass:
            flags.append("PERSISTENCE_WAIT")
        return frame.model_copy(update={
            "decision_stage": stage,
            "confluence_grade": grade,
            "persistence_count": persistence_count,
            "base_hard_gate_pass": base_gate_pass,
            "hard_gate_pass": hard_gate_pass,
            "gate_results": gate_results,
            "gate_failures": gate_failures,
            "tick_age_sec": tick_age_sec,
            "discovery_source_count": discovery_source_count,
            "spread_pct": spread_pct,
            "money_5m": money_5m,
            "universe_eligible": universe_eligible,
            "universe_eligibility_reasons": list(universe_eligibility_reasons or []),
            "official_signal_enabled": False,
            "flags": list(dict.fromkeys(flags)),
        })
