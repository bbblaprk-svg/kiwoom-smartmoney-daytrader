from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue
from pulse_edge.regime.models import MarketRegimeState


class PrimaryEngine(StrEnum):
    OBSERVE = "OBSERVE"
    SMART_PRE = "SMART_PRE"
    IGNITION = "IGNITION"
    EARLY_FOLLOWER = "EARLY_FOLLOWER"
    SECOND_WAVE = "SECOND_WAVE"
    ORB_RETEST = "ORB_RETEST"
    SQUEEZE_RELEASE = "SQUEEZE_RELEASE"
    VWAP_RECLAIM = "VWAP_RECLAIM"
    NXT_BRIDGE = "NXT_BRIDGE"


class ConfluenceGrade(StrEnum):
    NONE = "NONE"
    SINGLE = "SINGLE"
    MID = "CONFLUENCE_MID"
    HIGH = "CONFLUENCE_HIGH"
    A_PLUS_SHADOW = "CONFLUENCE_A_PLUS_SHADOW"


class DecisionStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    BLOCKED_SHADOW = "BLOCKED_SHADOW"
    WATCH_SHADOW = "WATCH_SHADOW"
    READY_SHADOW = "READY_SHADOW"
    ENTRY_ELIGIBLE_SHADOW = "ENTRY_ELIGIBLE_SHADOW"
    A_PLUS_ELIGIBLE_SHADOW = "A_PLUS_ELIGIBLE_SHADOW"


class ConfluenceFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    price: float | None = None
    change_rate: float | None = None
    primary_engine: PrimaryEngine = PrimaryEngine.OBSERVE
    decision_stage: DecisionStage = DecisionStage.DATA_WAIT
    confluence_grade: ConfluenceGrade = ConfluenceGrade.NONE
    confluence_score_100: float = 0.0
    evidence_count: int = 0
    evidence_groups: dict[str, bool] = Field(default_factory=dict)
    evidence_details: dict[str, str] = Field(default_factory=dict)

    regime_state: MarketRegimeState = MarketRegimeState.DATA_WAIT
    regime_score_100: float = 50.0
    strategy_preferred_by_regime: bool = False

    tick_age_sec: float | None = None
    discovery_source_count: int = 0
    spread_pct: float | None = None
    money_5m: float | None = None
    universe_eligible: bool = False
    universe_eligibility_reasons: list[str] = Field(default_factory=list)
    persistence_count: int = 0
    persistence_required: int = 3

    base_hard_gate_pass: bool = False
    hard_gate_pass: bool = False
    gate_results: dict[str, bool] = Field(default_factory=dict)
    gate_failures: list[str] = Field(default_factory=list)

    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
