from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from pulse_edge.confluence.engine import ConfluenceEngine
from pulse_edge.confluence.models import ConfluenceFrame
from pulse_edge.core.models import Venue
from pulse_edge.discovery.market import MarketDiscoveryService
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.ignition.models import IgnitionStage
from pulse_edge.ignition.service import IgnitionService
from pulse_edge.pullback.models import PullbackStage
from pulse_edge.pullback.service import PullbackSecondWaveService
from pulse_edge.regime.models import MarketRegimeState
from pulse_edge.regime.service import MarketRegimeService
from pulse_edge.smart_money.service import SmartMoneyService
from pulse_edge.spillover.models import SpilloverStage
from pulse_edge.spillover.service import SectorSpilloverService
from pulse_edge.universe.service import UniverseService


class ConfluenceService:
    def __init__(
        self,
        *,
        features: FeatureEngine,
        smart_money: SmartMoneyService,
        discovery: MarketDiscoveryService,
        ignition: IgnitionService,
        spillover: SectorSpilloverService,
        pullback: PullbackSecondWaveService,
        regime: MarketRegimeService,
        universe: UniverseService,
        engine: ConfluenceEngine,
        patterns: Any | None = None,
        bridge: Any | None = None,
        tick_max_age_sec: float = 3.5,
        required_discovery_sources: int = 2,
        required_persistence: int = 3,
        krx_spread_max_pct: float = 0.6,
        nxt_spread_max_pct: float = 0.8,
        min_money_5m_krw: float = 100_000_000.0,
        max_rows: int = 100,
    ) -> None:
        self.features = features
        self.smart_money = smart_money
        self.discovery = discovery
        self.ignition = ignition
        self.spillover = spillover
        self.pullback = pullback
        self.regime = regime
        self.universe = universe
        self.engine = engine
        self.patterns = patterns
        self.bridge = bridge
        self.tick_max_age_sec = max(0.5, float(tick_max_age_sec))
        self.required_discovery_sources = max(1, int(required_discovery_sources))
        self.required_persistence = max(1, int(required_persistence))
        self.krx_spread_max_pct = max(0.05, float(krx_spread_max_pct))
        self.nxt_spread_max_pct = max(0.05, float(nxt_spread_max_pct))
        self.min_money_5m_krw = max(0.0, float(min_money_5m_krw))
        self.max_rows = max(10, int(max_rows))
        self.frames: dict[tuple[Venue, str], ConfluenceFrame] = {}
        self._persistence: dict[tuple[Venue, str], int] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[ConfluenceFrame]:
        now = asof or datetime.now(timezone.utc)
        regime = self.regime.refresh(now)
        # The current KRX decision path is KRX-only. NXT has its own native engine
        # and fixed boards, so NXT SMART-MONEY frames must never enter KRX confluence.
        source = [
            row for row in self.smart_money.top(max(40, min(int(limit) * 2, 200)), now)
            if row.venue == Venue.KRX
        ][: max(20, min(int(limit), 200))]
        keep: set[tuple[Venue, str]] = set()
        rows: list[ConfluenceFrame] = []
        for smart in source:
            key = (smart.venue, smart.symbol)
            feature = self.features.frames.get(key)
            orb = self.patterns.orb_frames.get(key) if self.patterns is not None else None
            squeeze = self.patterns.squeeze_frames.get(key) if self.patterns is not None else None
            reclaim = self.patterns.reclaim_frames.get(key) if self.patterns is not None else None
            bridge = None
            if self.bridge is not None and smart.venue == Venue.NXT:
                bridge = self.bridge.frames.get(smart.symbol)
            base = self.engine.evaluate(
                smart,
                feature,
                self.ignition.frames.get(key),
                self.spillover.frames.get(key),
                self.pullback.frames.get(key),
                regime,
                orb=orb, squeeze=squeeze, reclaim=reclaim, bridge=bridge,
                asof=now,
            )
            finalized = self._hard_gate(base, feature, now)
            if finalized.decision_stage.value == "DATA_WAIT":
                self.frames.pop(key, None)
                self._persistence.pop(key, None)
                continue
            self.frames[key] = finalized
            keep.add(key)
            rows.append(finalized)

        for key in list(self.frames):
            if key not in keep:
                self.frames.pop(key, None)
                self._persistence.pop(key, None)
        ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
        self.frames = {(r.venue, r.symbol): r for r in ranked}
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def attach_bridge(self, bridge: Any) -> None:
        self.bridge = bridge

    def top(self, limit: int = 10) -> list[ConfluenceFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]

    def _hard_gate(self, frame: ConfluenceFrame, feature, now: datetime) -> ConfluenceFrame:
        if feature is None:
            return frame
        key = (frame.venue, frame.symbol)
        trades = self.features.trades.get(key) if hasattr(self.features, "trades") else None
        last_trade_at = trades[-1].ts if trades else feature.asof
        tick_age = max(0.0, (now - last_trade_at).total_seconds())
        source_count = self._discovery_source_count(frame.venue, frame.symbol, now)
        exact_venue = frame.venue in {Venue.KRX, Venue.NXT}
        if hasattr(self.universe, "eligibility"):
            eligibility = self.universe.eligibility(frame.symbol, frame.venue)
            universe_eligible = bool(eligibility.eligible)
            universe_reasons = list(eligibility.reasons)
        else:
            universe_eligible = frame.symbol in self.universe.stocks if self.universe.stocks else False
            universe_reasons = [] if universe_eligible else ["NOT_IN_CURRENT_UNIVERSE"]
        liquidity = feature.money_5m is not None and feature.money_5m >= self.min_money_5m_krw
        spread_limit = self.nxt_spread_max_pct if frame.venue == Venue.NXT else self.krx_spread_max_pct
        spread_ok = feature.spread_pct is not None and 0 <= feature.spread_pct <= spread_limit
        market_ok = frame.regime_state not in {MarketRegimeState.RED, MarketRegimeState.DATA_WAIT}
        strategy_ok = frame.strategy_preferred_by_regime
        ignition = self.ignition.frames.get(key)
        spill = self.spillover.frames.get(key)
        pull = self.pullback.frames.get(key)
        veto_ok = ignition is None or (not ignition.veto and ignition.stage != IgnitionStage.FALSE_BREAKOUT_VETO)
        overheat_ok = (
            (feature.vwap_distance_pct is None or feature.vwap_distance_pct <= 3.5)
            and (feature.change_rate is None or feature.change_rate <= 12.0)
            and (spill is None or spill.stage != SpilloverStage.OVERHEAT_RISK_SHADOW)
            and (pull is None or pull.stage != PullbackStage.OVEREXTENDED_RISK_SHADOW)
        )
        gates = {
            "tick_fresh": tick_age <= self.tick_max_age_sec,
            "exact_venue": exact_venue,
            "independent_discovery_sources": source_count >= self.required_discovery_sources,
            "universe_eligible": universe_eligible,
            "liquidity_floor": liquidity,
            "spread": spread_ok,
            "market_regime": market_ok,
            "regime_strategy_fit": strategy_ok,
            "no_active_veto": veto_ok,
            "not_overheated": overheat_ok,
        }
        failures = [name for name, passed in gates.items() if not passed]
        base_pass = all(gates.values())
        if base_pass:
            self._persistence[key] = self._persistence.get(key, 0) + 1
        else:
            self._persistence[key] = 0
        persistence = self._persistence[key]
        hard_pass = base_pass and persistence >= self.required_persistence
        return self.engine.finalize(
            frame,
            base_gate_pass=base_pass,
            hard_gate_pass=hard_pass,
            persistence_count=persistence,
            gate_results=gates,
            gate_failures=failures,
            tick_age_sec=round(tick_age, 3),
            discovery_source_count=source_count,
            spread_pct=feature.spread_pct,
            money_5m=feature.money_5m,
            universe_eligible=universe_eligible,
            universe_eligibility_reasons=universe_reasons,
        )

    def _discovery_source_count(self, venue: Venue, symbol: str, now: datetime) -> int:
        cutoff = now - timedelta(minutes=2)
        sources = {
            row.source
            for row in self.discovery.recent(500)
            if row.venue == venue and row.symbol == symbol and row.observed_at >= cutoff
        }
        return len(sources)

    @staticmethod
    def _sorted(rows: list[ConfluenceFrame]) -> list[ConfluenceFrame]:
        order = {
            "A_PLUS_ELIGIBLE_SHADOW": 6,
            "ENTRY_ELIGIBLE_SHADOW": 5,
            "READY_SHADOW": 4,
            "WATCH_SHADOW": 3,
            "BLOCKED_SHADOW": 2,
            "DATA_WAIT": 1,
        }
        rows.sort(
            key=lambda x: (
                order.get(x.decision_stage.value, 0),
                x.evidence_count,
                x.confluence_score_100,
                x.regime_score_100,
            ),
            reverse=True,
        )
        return rows
