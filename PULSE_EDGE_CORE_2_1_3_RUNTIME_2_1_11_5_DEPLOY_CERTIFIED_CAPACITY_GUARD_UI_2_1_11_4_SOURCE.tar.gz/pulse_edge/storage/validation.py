from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from threading import RLock

from pulse_edge.live_validation.models import LiveCheckStatus, LiveValidationCheck


class LiveValidationStore:
    """One-way operational evidence store. It is never read by trading logic."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS live_validation_check (
                trading_day TEXT NOT NULL,
                check_id TEXT NOT NULL,
                label TEXT NOT NULL,
                scope TEXT NOT NULL,
                blocking INTEGER NOT NULL,
                status TEXT NOT NULL,
                first_observed_at TEXT,
                last_observed_at TEXT,
                details_json TEXT NOT NULL,
                notes_json TEXT NOT NULL,
                PRIMARY KEY (trading_day, check_id)
            )
            """
        )
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS live_validation_run (
                trading_day TEXT PRIMARY KEY,
                started_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                app_version TEXT NOT NULL,
                environment TEXT NOT NULL,
                real_connection_observed INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        self._conn.commit()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def touch_run(
        self,
        trading_day: str,
        *,
        now: datetime,
        app_version: str,
        environment: str,
        real_connection_observed: bool,
    ) -> None:
        iso = now.isoformat()
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO live_validation_run(
                    trading_day, started_at, updated_at, app_version, environment, real_connection_observed
                ) VALUES(?,?,?,?,?,?)
                ON CONFLICT(trading_day) DO UPDATE SET
                    updated_at=excluded.updated_at,
                    app_version=excluded.app_version,
                    environment=excluded.environment,
                    real_connection_observed=MAX(live_validation_run.real_connection_observed, excluded.real_connection_observed)
                """,
                (trading_day, iso, iso, app_version, environment, int(real_connection_observed)),
            )
            self._conn.commit()

    def upsert_check(self, trading_day: str, check: LiveValidationCheck) -> None:
        with self._lock:
            self._conn.execute(
                """
                INSERT INTO live_validation_check(
                    trading_day, check_id, label, scope, blocking, status,
                    first_observed_at, last_observed_at, details_json, notes_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(trading_day, check_id) DO UPDATE SET
                    label=excluded.label,
                    scope=excluded.scope,
                    blocking=excluded.blocking,
                    status=excluded.status,
                    first_observed_at=COALESCE(live_validation_check.first_observed_at, excluded.first_observed_at),
                    last_observed_at=excluded.last_observed_at,
                    details_json=excluded.details_json,
                    notes_json=excluded.notes_json
                """,
                (
                    trading_day,
                    check.check_id,
                    check.label,
                    check.scope.value,
                    int(check.blocking),
                    check.status.value,
                    check.first_observed_at.isoformat() if check.first_observed_at else None,
                    check.last_observed_at.isoformat() if check.last_observed_at else None,
                    json.dumps(check.details, ensure_ascii=False, sort_keys=True, default=str),
                    json.dumps(check.notes, ensure_ascii=False),
                ),
            )
            self._conn.commit()

    def load_day(self, trading_day: str) -> dict[str, dict]:
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT check_id, status, first_observed_at, last_observed_at, details_json, notes_json
                FROM live_validation_check WHERE trading_day=?
                """,
                (trading_day,),
            ).fetchall()
        out: dict[str, dict] = {}
        for row in rows:
            out[str(row[0])] = {
                "status": LiveCheckStatus(str(row[1])),
                "first_observed_at": datetime.fromisoformat(row[2]) if row[2] else None,
                "last_observed_at": datetime.fromisoformat(row[3]) if row[3] else None,
                "details": json.loads(row[4] or "{}"),
                "notes": json.loads(row[5] or "[]"),
            }
        return out

    def recent_days(self, limit: int = 10) -> list[dict]:
        limit = max(1, min(int(limit), 100))
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT trading_day, started_at, updated_at, app_version, environment, real_connection_observed
                FROM live_validation_run ORDER BY trading_day DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            {
                "trading_day": r[0],
                "started_at": r[1],
                "updated_at": r[2],
                "app_version": r[3],
                "environment": r[4],
                "real_connection_observed": bool(r[5]),
            }
            for r in rows
        ]
