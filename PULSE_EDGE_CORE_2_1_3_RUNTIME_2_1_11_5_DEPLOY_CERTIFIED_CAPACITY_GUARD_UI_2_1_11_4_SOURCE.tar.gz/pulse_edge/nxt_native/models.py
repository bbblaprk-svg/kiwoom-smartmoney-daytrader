from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class NxtNativePhase(StrEnum):
    CLOSED = "CLOSED"
    EARLY_FLOW = "EARLY_FLOW"          # 15:40-18:30 KST
    EARLY_BUY = "EARLY_BUY"            # 18:30-19:30 KST
    CLOSE_BET = "CLOSE_BET"            # 19:30-19:55 KST


class NxtNativeStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    NXT_EARLY_FLOW = "NXT_EARLY_FLOW"
    NXT_EARLY_BUY = "NXT_EARLY_BUY"
    NXT_CLOSE_BET = "NXT_CLOSE_BET"
    NXT_OVERHEATED = "NXT_OVERHEATED"
    NXT_WIDE_SPREAD = "NXT_WIDE_SPREAD"
    NXT_LOW_LIQUIDITY = "NXT_LOW_LIQUIDITY"
    NXT_STALE = "NXT_STALE"
    NXT_NO_SIGNAL = "NXT_NO_SIGNAL"


class NxtTrust(StrEnum):
    LIVE = "LIVE"
    ESTIMATED = "ESTIMATED"
    STALE = "STALE"
    UNAVAILABLE = "UNAVAILABLE"


class NxtReferencePrice(BaseModel):
    trading_day: str
    symbol: str
    price: float
    observed_at: datetime
    source: str = "KRX_SAME_DAY_CLOSE_REFERENCE_ONLY"


class NxtNativeFrame(BaseModel):
    symbol: str
    trading_day: str
    asof: datetime
    phase: NxtNativePhase
    stage: NxtNativeStage

    nxt_price: float | None = None
    krx_reference_price: float | None = None
    nxt_premium_pct: float | None = None
    change_rate: float | None = None
    return_1m_pct: float | None = None
    return_5m_pct: float | None = None
    vwap_distance_pct: float | None = None
    spread_pct: float | None = None
    money_5m: float | None = None
    money_acceleration: float | None = None
    rvol_same_time: float | None = None

    ofi_30s: float | None = None
    ofi_2m: float | None = None
    aggressive_buy_ratio_30s: float | None = None
    aggressive_buy_ratio_2m: float | None = None
    trade_pressure_30s: float | None = None
    trade_pressure_2m: float | None = None
    microprice_bias_pct: float | None = None
    large_trade_buy_persistence_2m: float | None = None

    score_100: float = 0.0
    liquidity_score_20: float = 0.0
    aggressive_flow_score_20: float = 0.0
    orderflow_score_15: float = 0.0
    money_acceleration_score_15: float = 0.0
    price_structure_score_15: float = 0.0
    microprice_score_5: float = 0.0
    persistence_score_5: float = 0.0
    reference_premium_score_5: float = 0.0

    persistence_count: int = 0
    strict_close_window: bool = False
    price_trust: NxtTrust = NxtTrust.UNAVAILABLE
    quote_trust: NxtTrust = NxtTrust.UNAVAILABLE
    flow_trust: NxtTrust = NxtTrust.ESTIMATED
    investor_flow_trust: NxtTrust = NxtTrust.UNAVAILABLE
    investor_flow_source: str = "UNAVAILABLE"
    krx_investor_flow_used: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
