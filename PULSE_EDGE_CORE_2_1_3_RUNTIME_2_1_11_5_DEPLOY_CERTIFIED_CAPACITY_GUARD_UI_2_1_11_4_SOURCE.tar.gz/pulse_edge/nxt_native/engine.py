from __future__ import annotations

from datetime import datetime, time
from zoneinfo import ZoneInfo

from pulse_edge.features.models import FeatureFrame
from pulse_edge.nxt_native.models import NxtNativeFrame, NxtNativePhase, NxtNativeStage, NxtReferencePrice, NxtTrust

KST = ZoneInfo("Asia/Seoul")


class NxtNativeEngine:
    """PULSE-native NXT microstructure engine.

    It consumes only NXT FeatureFrame facts plus a same-day KRX closing reference
    price. It deliberately does not accept KRX investor/program flows or any
    bridge score. Flow is an ESTIMATED microstructure proxy based on NXT
    trades/orderbook facts already present in FeatureEngine.
    """

    @staticmethod
    def phase_at(asof: datetime) -> NxtNativePhase:
        local = asof.astimezone(KST)
        t = local.time().replace(tzinfo=None)
        if time(15, 40) <= t < time(18, 30):
            return NxtNativePhase.EARLY_FLOW
        if time(18, 30) <= t < time(19, 30):
            return NxtNativePhase.EARLY_BUY
        if time(19, 30) <= t < time(19, 55):
            return NxtNativePhase.CLOSE_BET
        return NxtNativePhase.CLOSED

    def evaluate(
        self,
        feature: FeatureFrame | None,
        reference: NxtReferencePrice | None,
        *,
        asof: datetime,
        trade_age_sec: float | None,
        quote_age_sec: float | None,
        persistence_count: int,
        min_money_5m_krw: float,
        spread_max_pct: float,
        close_strict_after: time,
    ) -> NxtNativeFrame:
        phase = self.phase_at(asof)
        day = asof.astimezone(KST).date().isoformat()
        symbol = feature.symbol if feature is not None else (reference.symbol if reference is not None else "")
        base = dict(
            symbol=symbol,
            trading_day=day,
            asof=asof,
            phase=phase,
            persistence_count=persistence_count,
            investor_flow_trust=NxtTrust.UNAVAILABLE,
            investor_flow_source="UNAVAILABLE",
            krx_investor_flow_used=False,
            official_signal_enabled=False,
            order_action_enabled=False,
        )
        if phase == NxtNativePhase.CLOSED:
            return NxtNativeFrame(stage=NxtNativeStage.DATA_WAIT, flags=["OUTSIDE_NXT_NATIVE_WINDOW"], **base)
        if feature is None or feature.price is None:
            return NxtNativeFrame(stage=NxtNativeStage.DATA_WAIT, flags=["NXT_PRICE_UNAVAILABLE"], **base)

        price_trust = NxtTrust.LIVE if trade_age_sec is not None and trade_age_sec <= 3.5 else NxtTrust.STALE
        quote_trust = NxtTrust.LIVE if quote_age_sec is not None and quote_age_sec <= 5.0 else NxtTrust.STALE
        strict_close = phase == NxtNativePhase.CLOSE_BET and asof.astimezone(KST).time().replace(tzinfo=None) >= close_strict_after
        premium = None
        if reference is not None and reference.trading_day == day and reference.price > 0:
            premium = (feature.price / reference.price - 1.0) * 100.0

        common = dict(
            nxt_price=feature.price,
            krx_reference_price=reference.price if reference and reference.trading_day == day else None,
            nxt_premium_pct=round(premium, 4) if premium is not None else None,
            change_rate=feature.change_rate,
            return_1m_pct=feature.return_1m_pct,
            return_5m_pct=feature.return_5m_pct,
            vwap_distance_pct=feature.vwap_distance_pct,
            spread_pct=feature.spread_pct,
            money_5m=feature.money_5m,
            money_acceleration=feature.money_acceleration,
            rvol_same_time=feature.rvol_same_time,
            ofi_30s=feature.ofi_30s,
            ofi_2m=feature.ofi_2m,
            aggressive_buy_ratio_30s=feature.aggressive_buy_ratio_30s,
            aggressive_buy_ratio_2m=feature.aggressive_buy_ratio_2m,
            trade_pressure_30s=feature.trade_pressure_30s,
            trade_pressure_2m=feature.trade_pressure_2m,
            microprice_bias_pct=feature.microprice_bias_pct,
            large_trade_buy_persistence_2m=feature.large_trade_buy_persistence_2m,
            strict_close_window=strict_close,
            price_trust=price_trust,
            quote_trust=quote_trust,
            flow_trust=NxtTrust.ESTIMATED,
        )

        if price_trust != NxtTrust.LIVE or quote_trust != NxtTrust.LIVE:
            flags = []
            if price_trust != NxtTrust.LIVE:
                flags.append("NXT_TRADE_STALE")
            if quote_trust != NxtTrust.LIVE:
                flags.append("NXT_QUOTE_STALE")
            return NxtNativeFrame(stage=NxtNativeStage.NXT_STALE, flags=flags, **base, **common)

        spread = feature.spread_pct
        if spread is None or spread < 0 or spread > spread_max_pct:
            return NxtNativeFrame(stage=NxtNativeStage.NXT_WIDE_SPREAD, flags=["NXT_SPREAD_GATE_FAILED"], **base, **common)

        money = feature.money_5m or 0.0
        if money < min_money_5m_krw:
            return NxtNativeFrame(stage=NxtNativeStage.NXT_LOW_LIQUIDITY, flags=["NXT_MONEY_5M_TOO_LOW"], **base, **common)

        vertical = (feature.return_1m_pct or 0.0) >= (1.2 if strict_close else 1.8)
        five_min_hot = (feature.return_5m_pct or 0.0) >= (2.5 if strict_close else 3.5)
        premium_hot = premium is not None and premium > (1.5 if strict_close else 2.5)
        day_hot = (feature.change_rate or 0.0) >= 5.0
        if premium_hot or vertical or five_min_hot or (day_hot and (feature.vwap_distance_pct or 0.0) > 2.5):
            flags = []
            if premium_hot: flags.append("NXT_PREMIUM_EXCESS")
            if vertical: flags.append("NXT_VERTICAL_1M")
            if five_min_hot: flags.append("NXT_VERTICAL_5M")
            if day_hot: flags.append("NXT_DAY_MOVE_OVER_PREEMPTIVE_RANGE")
            return NxtNativeFrame(stage=NxtNativeStage.NXT_OVERHEATED, flags=flags, **base, **common)

        liquidity = 20.0
        aggressive = 0.0
        ratio30 = feature.aggressive_buy_ratio_30s
        ratio2m = feature.aggressive_buy_ratio_2m
        if ratio30 is not None:
            aggressive += 10.0 if ratio30 >= 0.60 else 7.0 if ratio30 >= 0.55 else 3.0 if ratio30 >= 0.50 else 0.0
        if ratio2m is not None:
            aggressive += 10.0 if ratio2m >= 0.60 else 7.0 if ratio2m >= 0.55 else 3.0 if ratio2m >= 0.50 else 0.0

        orderflow = 0.0
        if feature.ofi_30s is not None and feature.ofi_30s > 0: orderflow += 6.0
        if feature.ofi_2m is not None and feature.ofi_2m > 0: orderflow += 5.0
        if feature.trade_pressure_30s is not None and feature.trade_pressure_30s > 0: orderflow += 2.0
        if feature.trade_pressure_2m is not None and feature.trade_pressure_2m > 0: orderflow += 2.0

        money_score = 0.0
        if feature.money_acceleration is not None and feature.money_acceleration > 0:
            money_score += 9.0
        if feature.rvol_same_time is not None:
            money_score += 6.0 if feature.rvol_same_time >= 1.5 else 4.0 if feature.rvol_same_time >= 1.2 else 2.0 if feature.rvol_same_time >= 1.0 else 0.0
        elif money >= min_money_5m_krw * 2:
            money_score += 3.0

        price_structure = 0.0
        if feature.vwap_distance_pct is not None and feature.vwap_distance_pct >= 0:
            price_structure += 6.0
        if feature.return_1m_pct is not None and -0.3 <= feature.return_1m_pct <= 1.2:
            price_structure += 4.0
        if feature.return_5m_pct is not None and -0.5 <= feature.return_5m_pct <= 2.0:
            price_structure += 3.0
        if feature.change_rate is not None and -1.5 <= feature.change_rate <= 3.0:
            price_structure += 2.0

        micro = 5.0 if feature.microprice_bias_pct is not None and feature.microprice_bias_pct > 0 else 0.0
        persist_score = min(5.0, max(0, persistence_count) * 2.0)
        premium_score = 0.0
        if premium is None:
            premium_score = 2.0
        elif -0.5 <= premium <= 1.5:
            premium_score = 5.0
        elif -1.0 <= premium <= 2.0:
            premium_score = 3.0

        total = liquidity + aggressive + orderflow + money_score + price_structure + micro + persist_score + premium_score
        total = round(min(100.0, total), 2)

        positive_flow = (
            (ratio30 is not None and ratio30 >= 0.55)
            and (feature.ofi_30s is not None and feature.ofi_30s > 0)
            and (feature.trade_pressure_30s is not None and feature.trade_pressure_30s > 0)
            and (feature.money_acceleration is not None and feature.money_acceleration > 0)
        )
        vwap_ok = feature.vwap_distance_pct is not None and feature.vwap_distance_pct >= -0.15
        premium_ok = premium is None or (-1.0 <= premium <= (1.5 if strict_close else 2.0))
        close_reference_ok = reference is not None and reference.trading_day == day and premium is not None
        no_vertical = not vertical and not five_min_hot

        stage = NxtNativeStage.NXT_NO_SIGNAL
        flags: list[str] = []
        if phase == NxtNativePhase.EARLY_FLOW:
            if total >= 55 and positive_flow and persistence_count >= 2:
                stage = NxtNativeStage.NXT_EARLY_FLOW
            else:
                flags.append("EARLY_FLOW_CONDITIONS_NOT_COMPLETE")
        elif phase == NxtNativePhase.EARLY_BUY:
            if total >= 70 and positive_flow and vwap_ok and premium_ok and persistence_count >= 2:
                stage = NxtNativeStage.NXT_EARLY_BUY
            else:
                flags.append("EARLY_BUY_CONDITIONS_NOT_COMPLETE")
        elif phase == NxtNativePhase.CLOSE_BET:
            threshold = 90 if strict_close else 82
            close_ratio = 0.62 if strict_close else 0.60
            close_flow = positive_flow and ratio30 is not None and ratio30 >= close_ratio and feature.ofi_2m is not None and feature.ofi_2m > 0
            spread_strict = spread <= (0.6 if strict_close else spread_max_pct)
            if total >= threshold and close_flow and vwap_ok and premium_ok and close_reference_ok and no_vertical and spread_strict and persistence_count >= 3:
                stage = NxtNativeStage.NXT_CLOSE_BET
            else:
                flags.append("CLOSE_BET_CONDITIONS_NOT_COMPLETE")
                if not close_reference_ok:
                    flags.append("KRX_REFERENCE_REQUIRED_FOR_CLOSE_BET")
                if strict_close:
                    flags.append("STRICT_1950_GATE_ACTIVE")

        return NxtNativeFrame(
            stage=stage,
            score_100=total,
            liquidity_score_20=liquidity,
            aggressive_flow_score_20=aggressive,
            orderflow_score_15=orderflow,
            money_acceleration_score_15=money_score,
            price_structure_score_15=price_structure,
            microprice_score_5=micro,
            persistence_score_5=persist_score,
            reference_premium_score_5=premium_score,
            flags=flags,
            **base,
            **common,
        )
