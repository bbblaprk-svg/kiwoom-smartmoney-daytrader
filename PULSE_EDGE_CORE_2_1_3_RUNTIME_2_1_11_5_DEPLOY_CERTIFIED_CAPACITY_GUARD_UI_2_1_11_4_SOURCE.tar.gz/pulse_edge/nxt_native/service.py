from __future__ import annotations

from datetime import datetime, time, timezone
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.nxt_native.engine import NxtNativeEngine
from pulse_edge.nxt_native.models import NxtNativeFrame, NxtNativePhase, NxtNativeStage, NxtReferencePrice
from pulse_edge.universe.service import UniverseService

KST = ZoneInfo("Asia/Seoul")


class NxtNativeService:
    """Current-session NXT-only evaluator.

    KRX is observed only to retain a same-day closing *reference price*. No KRX
    investor/program/SMART-MONEY/confluence/bridge state enters the NXT score.
    All state is process-memory and rolls at the KST trading-day boundary.
    """

    def __init__(
        self,
        *,
        features: FeatureEngine,
        universe: UniverseService,
        engine: NxtNativeEngine,
        spread_max_pct: float = 0.8,
        min_money_5m_krw: float = 20_000_000.0,
        close_strict_hour_kst: int = 19,
        close_strict_minute_kst: int = 50,
        max_rows: int = 600,
    ) -> None:
        self.features = features
        self.universe = universe
        self.engine = engine
        self.spread_max_pct = float(spread_max_pct)
        self.min_money_5m_krw = float(min_money_5m_krw)
        self.close_strict_after = time(int(close_strict_hour_kst), int(close_strict_minute_kst))
        self.max_rows = max(20, int(max_rows))
        self.references: dict[str, NxtReferencePrice] = {}
        self.frames: dict[str, NxtNativeFrame] = {}
        self._persistence: dict[str, int] = {}
        self._day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 200, asof: datetime | None = None) -> list[NxtNativeFrame]:
        now = asof or datetime.now(timezone.utc)
        local = now.astimezone(KST)
        day = local.date().isoformat()
        if self._day != day:
            self._day = day
            self.references.clear()
            self.frames.clear()
            self._persistence.clear()

        self._capture_same_day_krx_reference(now)
        phase = self.engine.phase_at(now)
        if phase == NxtNativePhase.CLOSED:
            self.frames.clear()
            self._persistence.clear()
            self.last_refresh_at = now
            self.last_error = None
            return []

        keys = []
        for (venue, symbol), feature in self.features.frames.items():
            if venue != Venue.NXT:
                continue
            eligibility = self.universe.eligibility(symbol, Venue.NXT)
            if not eligibility.eligible:
                continue
            keys.append((symbol, feature))
        def current_priority(item):
            symbol, feature = item
            trades = self.features.trades.get((Venue.NXT, symbol))
            last_ts = trades[-1].ts.timestamp() if trades else 0.0
            return (last_ts, feature.money_5m or 0.0, feature.smart_flow_realtime_score_100 or 0.0)
        keys.sort(key=current_priority, reverse=True)
        keys = keys[:max(20, min(int(limit), self.max_rows))]

        output: list[NxtNativeFrame] = []
        keep: set[str] = set()
        for symbol, feature in keys:
            trades = self.features.trades.get((Venue.NXT, symbol))
            quote = self.features.best_quotes.get((Venue.NXT, symbol))
            trade_age = (now - trades[-1].ts).total_seconds() if trades else None
            quote_age = (now - quote[2]).total_seconds() if quote else None
            reference = self.references.get(symbol)

            previous_persist = self._persistence.get(symbol, 0)
            provisional = self.engine.evaluate(
                feature,
                reference,
                asof=now,
                trade_age_sec=trade_age,
                quote_age_sec=quote_age,
                persistence_count=previous_persist,
                min_money_5m_krw=self.min_money_5m_krw,
                spread_max_pct=self.spread_max_pct,
                close_strict_after=self.close_strict_after,
            )
            structural = provisional.stage not in {
                NxtNativeStage.DATA_WAIT,
                NxtNativeStage.NXT_STALE,
                NxtNativeStage.NXT_WIDE_SPREAD,
                NxtNativeStage.NXT_LOW_LIQUIDITY,
                NxtNativeStage.NXT_OVERHEATED,
            } and provisional.score_100 >= 50
            self._persistence[symbol] = previous_persist + 1 if structural else 0
            frame = self.engine.evaluate(
                feature,
                reference,
                asof=now,
                trade_age_sec=trade_age,
                quote_age_sec=quote_age,
                persistence_count=self._persistence[symbol],
                min_money_5m_krw=self.min_money_5m_krw,
                spread_max_pct=self.spread_max_pct,
                close_strict_after=self.close_strict_after,
            )
            self.frames[symbol] = frame
            output.append(frame)
            keep.add(symbol)

        for symbol in list(self.frames):
            if symbol not in keep:
                self.frames.pop(symbol, None)
                self._persistence.pop(symbol, None)

        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(output)

    def _capture_same_day_krx_reference(self, now: datetime) -> None:
        day = now.astimezone(KST).date().isoformat()
        for (venue, symbol), feature in self.features.frames.items():
            if venue != Venue.KRX or feature.price is None:
                continue
            trades = self.features.trades.get((Venue.KRX, symbol))
            if not trades:
                continue
            last = trades[-1]
            local = last.ts.astimezone(KST)
            if local.date().isoformat() != day:
                continue
            t = local.time().replace(tzinfo=None)
            # Use only a closing-period observation. Never substitute a previous day.
            if not (time(15, 20) <= t <= time(15, 31)):
                continue
            current = self.references.get(symbol)
            if current is None or last.ts >= current.observed_at:
                self.references[symbol] = NxtReferencePrice(
                    trading_day=day,
                    symbol=symbol,
                    price=last.price,
                    observed_at=last.ts,
                )

    def top(self, limit: int = 10) -> list[NxtNativeFrame]:
        return self._sorted(list(self.frames.values()))[:max(1, min(int(limit), 100))]

    def get(self, symbol: str) -> NxtNativeFrame | None:
        return self.frames.get(str(symbol).strip()[:6])

    @staticmethod
    def _sorted(rows: list[NxtNativeFrame]) -> list[NxtNativeFrame]:
        order = {
            NxtNativeStage.NXT_CLOSE_BET: 9,
            NxtNativeStage.NXT_EARLY_BUY: 8,
            NxtNativeStage.NXT_EARLY_FLOW: 7,
            NxtNativeStage.NXT_NO_SIGNAL: 6,
            NxtNativeStage.NXT_LOW_LIQUIDITY: 5,
            NxtNativeStage.NXT_WIDE_SPREAD: 4,
            NxtNativeStage.NXT_OVERHEATED: 3,
            NxtNativeStage.NXT_STALE: 2,
            NxtNativeStage.DATA_WAIT: 1,
        }
        return sorted(rows, key=lambda row: (order.get(row.stage, 0), row.score_100), reverse=True)
