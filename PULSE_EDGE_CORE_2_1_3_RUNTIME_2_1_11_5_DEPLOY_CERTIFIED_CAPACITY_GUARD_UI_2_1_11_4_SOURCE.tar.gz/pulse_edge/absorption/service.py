from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from pulse_edge.absorption.engine import AbsorptionInputs, DualAbsorptionEngine
from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue
from pulse_edge.discovery.market import MarketDiscoveryService
from pulse_edge.feed.state import FeedState
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.flow.investor import InvestorBreakdown, InvestorFlowService
from pulse_edge.regime.models import MarketRegimeState
from pulse_edge.regime.service import MarketRegimeService
from pulse_edge.sector.service import SectorBreadthService

KST = ZoneInfo("Asia/Seoul")


@dataclass(frozen=True)
class ActorPoint:
    at: datetime
    net: float


@dataclass(frozen=True)
class RatioPoint:
    at: datetime
    ratio: float


@dataclass(frozen=True)
class ProgramPoint:
    at: datetime
    net: float


class SupplyAbsorptionService:
    """KRX DUAL ABSORPTION + PRICE HOLD shadow.

    Existing PULSE ranking/promotion remains untouched. Investor detail is
    hydrated only for current KRX symbols and never reused as NXT-native flow.
    """

    def __init__(self, *, features: FeatureEngine, investor_flow: InvestorFlowService,
                 state: FeedState, discovery: MarketDiscoveryService,
                 sectors: SectorBreadthService | None, regime: MarketRegimeService | None,
                 engine: DualAbsorptionEngine, max_rows: int = 200,
                 investor_max_age_sec: float = 420.0, price_max_age_sec: float = 7.0,
                 program_max_age_sec: float = 15.0, detail_ttl_sec: float = 75.0,
                 detail_requests_per_cycle: int = 8) -> None:
        self.features=features; self.investor_flow=investor_flow; self.state=state
        self.discovery=discovery; self.sectors=sectors; self.regime=regime; self.engine=engine
        self.max_rows=max(20,int(max_rows)); self.investor_max_age_sec=max(60,float(investor_max_age_sec))
        self.price_max_age_sec=max(3.5,float(price_max_age_sec)); self.program_max_age_sec=max(5,float(program_max_age_sec))
        self.detail_ttl_sec=max(30,float(detail_ttl_sec)); self.detail_requests_per_cycle=max(1,int(detail_requests_per_cycle))
        self.frames: dict[str,AbsorptionFrame]={}; self.last_refresh_at: datetime|None=None; self.last_error: str|None=None
        self._actors: dict[tuple[str,str],deque[ActorPoint]]=defaultdict(lambda: deque(maxlen=16))
        self._ratios: dict[tuple[str,str],deque[RatioPoint]]=defaultdict(lambda: deque(maxlen=16))
        self._program: dict[str,deque[ProgramPoint]]=defaultdict(lambda: deque(maxlen=30))
        self._session_day=None; self._detail_cursor=0

    async def hydrate_breakdowns(self, limit: int = 100, asof: datetime | None = None) -> int:
        now=asof or datetime.now(timezone.utc); self._roll_session(now)
        symbols=self._symbols(limit)
        if not symbols: return 0
        n=len(symbols); start=self._detail_cursor % n; ordered=symbols[start:]+symbols[:start]
        loaded=0; scanned=0; target_day=now.astimezone(KST).date()
        for symbol in ordered:
            if loaded >= self.detail_requests_per_cycle: break
            scanned += 1
            cur=self.investor_flow.breakdown.get(symbol)
            if cur is not None and cur.source_date == target_day:
                age=max(0.0,(now-cur.asof).total_seconds())
                if age < self.detail_ttl_sec: continue
            try:
                await self.investor_flow.load_breakdown(symbol,target_day)
                loaded += 1
            except Exception as exc:
                self.last_error=f"INVESTOR_BREAKDOWN:{type(exc).__name__}:{exc}"
        self._detail_cursor=(start+max(1,scanned))%n
        return loaded

    def refresh(self, limit: int = 100, asof: datetime | None = None) -> list[AbsorptionFrame]:
        now=asof or datetime.now(timezone.utc); self._roll_session(now)
        rows=[]
        for symbol in self._symbols(limit):
            feature=self.features.frames.get((Venue.KRX,symbol))
            if feature is None or not self._same_day(feature.asof,now): continue
            row=self._one(symbol,feature,now); self.frames[symbol]=row; rows.append(row)
        keep={r.symbol for r in rows}
        for symbol in list(self.frames):
            if symbol not in keep and max(0.0,(now-self.frames[symbol].asof).total_seconds())>1200:
                self.frames.pop(symbol,None)
        if len(self.frames)>self.max_rows:
            allowed={r.symbol for r in self._sorted(list(self.frames.values()))[:self.max_rows]}
            for symbol in list(self.frames):
                if symbol not in allowed: self.frames.pop(symbol,None)
        self.last_refresh_at=now
        return self._sorted(rows)

    def top(self, limit:int=10)->list[AbsorptionFrame]: return self._sorted(list(self.frames.values()))[:max(1,min(int(limit),100))]
    def get(self,symbol:str)->AbsorptionFrame|None: return self.frames.get(symbol[:6])

    def _one(self,symbol,feature,now):
        prior=self.frames.get(symbol); prior_model=prior.model if prior else AbsorptionModel.NONE; prior_stage=prior.stage if prior else None
        detail=self._detail(symbol,now)
        foreign=institution=fund=pension=insurance=financial=private=corp=None
        flow_unit=None; source_api=None; detail_at=None
        if detail is not None:
            foreign=detail.foreign; institution=detail.institution; fund=detail.fund; pension=detail.pension
            insurance=detail.insurance; financial=detail.financial_investment; private=detail.private_fund; corp=detail.other_corporation
            flow_unit=detail.unit; source_api=detail.source_api_id; detail_at=detail.asof
        else:
            fr=self.investor_flow.intraday.get((symbol,"FOREIGN")); ins=self.investor_flow.intraday.get((symbol,"INSTITUTION"))
            if fr is not None and not self._same_day(fr.asof,now): fr=None
            if ins is not None and not self._same_day(ins.asof,now): ins=None
            foreign=fr.net_value if fr else None; institution=ins.net_value if ins else None
            detail_at=max([x.asof for x in (fr,ins) if x is not None],default=None)
            flow_unit="RANK_NATIVE" if (fr or ins) else None; source_api=(fr.source_api_id if fr else ins.source_api_id if ins else None)

        actor_values={"FOREIGN":foreign,"INSTITUTION":institution,"FUND":fund,"PENSION":pension,"OTHER_CORP":corp}
        at=detail_at
        for actor,val in actor_values.items(): self._append_actor(self._actors[(symbol,actor)],at,val)
        if fund is not None or pension is not None:
            self._append_actor(self._actors[(symbol,"FUND_PENSION")],at,(fund or 0)+(pension or 0))

        current_model=self._raw_model(foreign,institution,fund,pension,corp)
        dynamics_model=current_model if current_model != AbsorptionModel.NONE else prior_model
        seller_key, absorber_key=self._roles(dynamics_model)
        seller_q=self._actors[(symbol,seller_key)] if seller_key else deque()
        absorber_q=self._actors[(symbol,absorber_key)] if absorber_key else deque()
        seller_turn=self._buy_turn(seller_q) if seller_key else None
        sell_cur,sell_prev,sell_ratio,decel=self._sell_velocity(seller_q) if seller_key else (None,None,None,0)
        absorber_vel=self._positive_velocity(absorber_q) if absorber_key else None

        a_ratio=(foreign/abs(institution)) if institution is not None and institution<0 and foreign is not None and foreign>0 else None
        core=(max(0,fund or 0)+max(0,pension or 0))
        b_ratio=(core/abs(foreign)) if foreign is not None and foreign<0 and core>0 else None
        c_ratio=(max(0,corp or 0)/abs(foreign)) if foreign is not None and foreign<0 and (corp or 0)>0 else None
        ratio_key=self._ratio_key(current_model if current_model != AbsorptionModel.NONE else prior_model)
        prior_ratio=self._ratios[(symbol,ratio_key)][-1].ratio if ratio_key and self._ratios[(symbol,ratio_key)] else None
        current_ratio=self._ratio_for_model(current_model,a_ratio,b_ratio,c_ratio)
        if ratio_key and current_ratio is not None and at is not None: self._append_ratio(self._ratios[(symbol,ratio_key)],at,current_ratio)
        ratio_delta,_=self._ratio_motion(self._ratios[(symbol,ratio_key)]) if ratio_key else (None,None)

        program_event=self._event(symbol,"0w"); program_at=(program_event.event_time or program_event.receive_time) if program_event else None
        if program_at is not None and not self._same_day(program_at,now): program_at=None
        program_net=feature.program_net_buy_amount if program_at is not None else None
        if program_at is not None and program_net is not None: self._append_program(self._program[symbol],program_at,program_net)
        program_improving,program_turn=self._program_motion(self._program[symbol])

        rising=self._rising_lows(symbol,now); range_pos=self._range_position(symbol,feature.price,now)
        dd10=self._max_drawdown(symbol,feature.price,now,10); dd30=self._max_drawdown(symbol,feature.price,now,30)
        sector=self.sectors.frame_for(symbol,now) if self.sectors is not None else None
        market_red=bool(self.regime and self.regime.frame and self.regime.frame.state==MarketRegimeState.RED)

        return self.engine.evaluate(AbsorptionInputs(
            symbol=symbol,asof=now,price=feature.price,change_rate=feature.change_rate,
            foreign_net=foreign,institution_net=institution,fund_net=fund,pension_net=pension,insurance_net=insurance,
            financial_investment_net=financial,private_fund_net=private,other_corporation_net=corp,program_net=program_net,
            flow_unit=flow_unit,investor_source_api_id=source_api,prior_model=prior_model,prior_stage=prior_stage,
            model_a_ratio=a_ratio,model_b_ratio=b_ratio,corporate_ratio=c_ratio,prior_absorption_ratio=prior_ratio,
            absorption_ratio_delta=ratio_delta,seller_new_sell_velocity_per_min=sell_cur,
            seller_previous_sell_velocity_per_min=sell_prev,seller_sell_velocity_ratio=sell_ratio,
            seller_sell_deceleration_count=decel,seller_neutral_or_buy_turn=seller_turn,
            absorber_buy_velocity_per_min=absorber_vel,program_improving=program_improving,program_buy_turn=program_turn,
            rising_lows=rising,vwap_distance_pct=feature.vwap_distance_pct,intraday_range_position=range_pos,
            max_drawdown_10m_pct=dd10,max_drawdown_30m_pct=dd30,money_acceleration=feature.money_acceleration,
            rvol_same_time=feature.rvol_same_time,rs_level=feature.rs_level,rs_velocity=feature.rs_velocity,
            rs_acceleration=feature.rs_acceleration,sector_name=sector.sector_name if sector else None,
            sector_relative_strength_pct=((feature.change_rate - sector.member_median_change)
                                          if sector and feature.change_rate is not None and sector.member_median_change is not None
                                          else None),
            sector_breadth_ratio=(sector.member_positive_ratio if sector and sector.member_positive_ratio is not None else sector.breadth_ratio if sector else None),
            sector_breadth_velocity=sector.breadth_velocity_ppm if sector else None,
            price_trust=self._trust(feature.asof,now,self.price_max_age_sec,live=True),
            investor_trust=self._investor_trust(detail,detail_at,now),program_trust=self._trust(program_at,now,self.program_max_age_sec,live=True),
            market_red=market_red,
        ))

    def _detail(self,symbol,now)->InvestorBreakdown|None:
        row=self.investor_flow.breakdown.get(symbol)
        if row is None or row.source_date != now.astimezone(KST).date(): return None
        if max(0.0,(now-row.asof).total_seconds()) > self.investor_max_age_sec*2: return None
        return row

    def _symbols(self,limit):
        out=[]; seen=set()
        for event in reversed(self.discovery.recent(max(limit*4,100))):
            if event.venue!=Venue.KRX: continue
            symbol=event.symbol[:6]
            if symbol in seen: continue
            seen.add(symbol); out.append(symbol)
            if len(out)>=limit:return out
        for venue,symbol in reversed(list(self.features.frames.keys())):
            if venue!=Venue.KRX or symbol in seen:continue
            seen.add(symbol);out.append(symbol)
            if len(out)>=limit:break
        return out

    @staticmethod
    def _raw_model(foreign,institution,fund,pension,corp):
        if institution is not None and institution<0 and (foreign or 0)>0:return AbsorptionModel.A_FOREIGN_ABSORB
        if foreign is not None and foreign<0 and max(0,fund or 0)+max(0,pension or 0)>0:
            if (fund or 0)>0 and (pension or 0)>0:return AbsorptionModel.B3_FUND_PENSION_ABSORB
            if (pension or 0)>0:return AbsorptionModel.B2_PENSION_ABSORB
            return AbsorptionModel.B1_FUND_ABSORB
        if foreign is not None and foreign<0 and (corp or 0)>0:return AbsorptionModel.CORPORATE_ABSORB
        return AbsorptionModel.NONE

    @staticmethod
    def _roles(model):
        if model==AbsorptionModel.A_FOREIGN_ABSORB:return "INSTITUTION","FOREIGN"
        if model in {AbsorptionModel.B1_FUND_ABSORB,AbsorptionModel.B2_PENSION_ABSORB,AbsorptionModel.B3_FUND_PENSION_ABSORB}:return "FOREIGN","FUND_PENSION"
        if model==AbsorptionModel.CORPORATE_ABSORB:return "FOREIGN","OTHER_CORP"
        if model==AbsorptionModel.DUAL_CONFIRMED:return None,None
        return None,None

    @staticmethod
    def _ratio_key(model):
        if model==AbsorptionModel.A_FOREIGN_ABSORB:return "A"
        if model in {AbsorptionModel.B1_FUND_ABSORB,AbsorptionModel.B2_PENSION_ABSORB,AbsorptionModel.B3_FUND_PENSION_ABSORB}:return "B"
        if model==AbsorptionModel.CORPORATE_ABSORB:return "C"
        return None

    @staticmethod
    def _ratio_for_model(model,a,b,c):
        if model==AbsorptionModel.A_FOREIGN_ABSORB:return a
        if model in {AbsorptionModel.B1_FUND_ABSORB,AbsorptionModel.B2_PENSION_ABSORB,AbsorptionModel.B3_FUND_PENSION_ABSORB}:return b
        if model==AbsorptionModel.CORPORATE_ABSORB:return c
        return None

    def _event(self,symbol,real_type):
        book=self.state.krx.get(symbol);return book.events_by_type.get(real_type) if book else None

    def _roll_session(self,now):
        day=now.astimezone(KST).date()
        if self._session_day==day:return
        self._session_day=day;self.frames.clear();self._actors.clear();self._ratios.clear();self._program.clear();self._detail_cursor=0

    @staticmethod
    def _same_day(at,now):return at.astimezone(KST).date()==now.astimezone(KST).date()

    @staticmethod
    def _append_actor(q,at,net):
        if at is None or net is None:return
        if q and at<=q[-1].at:return
        q.append(ActorPoint(at,float(net)))

    @staticmethod
    def _append_ratio(q,at,ratio):
        if at is None or ratio is None:return
        if q and at<=q[-1].at:return
        q.append(RatioPoint(at,float(ratio)))

    @staticmethod
    def _append_program(q,at,net):
        if q and at<=q[-1].at:return
        q.append(ProgramPoint(at,float(net)))

    @staticmethod
    def _buy_turn(q):
        if len(q)<2:return None
        return q[-2].net<0<=q[-1].net

    @staticmethod
    def _positive_velocity(q):
        if len(q)<2:return None
        a,b=q[-2],q[-1];mins=max((b.at-a.at).total_seconds()/60,1e-6)
        return max(0.0,b.net-a.net)/mins

    @staticmethod
    def _sell_velocity(q):
        if len(q)<3:return None,None,None,0
        rows=list(q);v=[]
        for a,b in zip(rows[:-1],rows[1:]):
            mins=max((b.at-a.at).total_seconds()/60,1e-6);v.append(max(0.0,a.net-b.net)/mins)
        cur,prev=v[-1],v[-2];ratio=cur/prev if prev>0 else (0.0 if cur==0 else None);count=0
        for left,right in zip(reversed(v[:-1]),reversed(v[1:])):
            if right<left:count+=1
            else:break
            if count>=3:break
        return cur,prev,ratio,count

    @staticmethod
    def _ratio_motion(q):
        if len(q)<2:return None,None
        a,b=q[-2],q[-1];d=b.ratio-a.ratio;mins=max((b.at-a.at).total_seconds()/60,1e-6);return d,d/mins

    @staticmethod
    def _program_motion(q):
        if len(q)<2:return None,None
        a,b=q[-2],q[-1];return b.net>a.net,a.net<0<=b.net

    def _trade_pts(self,symbol,now,minutes=None):
        q=self.features.trades.get((Venue.KRX,symbol))
        if not q:return []
        cutoff=now-timedelta(minutes=minutes) if minutes else datetime.combine(now.astimezone(KST).date(),datetime.min.time(),tzinfo=KST).astimezone(timezone.utc)
        return [p for p in q if p.ts>=cutoff and self._same_day(p.ts,now)]

    def _rising_lows(self,symbol,now):
        pts=self._trade_pts(symbol,now,10)
        if len(pts)<6:return None
        n=len(pts);chunks=[pts[:n//3],pts[n//3:2*n//3],pts[2*n//3:]]
        if any(not c for c in chunks):return None
        lows=[min(p.price for p in c) for c in chunks]
        return lows[1]>=lows[0] and lows[2]>=lows[1] and lows[2]>lows[0]

    def _range_position(self,symbol,price,now):
        if price is None:return None
        pts=self._trade_pts(symbol,now)
        if not pts:return None
        lo=min(p.price for p in pts);hi=max(p.price for p in pts)
        if hi<=lo:return 0.5
        return max(0.0,min(1.0,(price-lo)/(hi-lo)))

    def _max_drawdown(self,symbol,price,now,minutes):
        if price is None:return None
        pts=self._trade_pts(symbol,now,minutes)
        if not pts:return None
        peak=max(p.price for p in pts)
        return ((price/peak)-1)*100 if peak>0 else None

    def _investor_trust(self,detail,at,now):
        if at is None:return FactTrust.UNAVAILABLE
        age=max(0.0,(now-at).total_seconds())
        if age<=self.investor_max_age_sec:return FactTrust.ESTIMATED
        if age<=self.investor_max_age_sec*2:return FactTrust.DELAYED
        return FactTrust.STALE

    @staticmethod
    def _trust(at,now,max_age,*,live):
        if at is None:return FactTrust.UNAVAILABLE
        age=max(0.0,(now-at).total_seconds())
        if age<=max_age:return FactTrust.LIVE if live else FactTrust.CONFIRMED
        if age<=max_age*2:return FactTrust.DELAYED
        return FactTrust.STALE

    @staticmethod
    def _sorted(rows):
        priority={AbsorptionStage.PRE_IGNITION:7,AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED:6,AbsorptionStage.SUPPLY_TIGHT:5,
                  AbsorptionStage.PRICE_HOLD:4,AbsorptionStage.ABSORB:3,AbsorptionStage.IGNITION:2,AbsorptionStage.WATCH:1,AbsorptionStage.DATA_WAIT:0}
        rows.sort(key=lambda r:(priority[r.stage],r.price_hold_pass,r.score_100,r.coverage_pct),reverse=True);return rows
