from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class AbsorptionStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    WATCH = "WATCH"
    ABSORB = "ABSORB"
    PRICE_HOLD = "PRICE_HOLD"
    SUPPLY_TIGHT = "SUPPLY_TIGHT"
    SUPPLY_EXHAUSTION_ESTIMATED = "SUPPLY_EXHAUSTION_ESTIMATED"
    PRE_IGNITION = "PRE_IGNITION"
    IGNITION = "IGNITION"


class AbsorptionModel(StrEnum):
    NONE = "NONE"
    A_FOREIGN_ABSORB = "A_FOREIGN_ABSORB"
    B1_FUND_ABSORB = "B1_FUND_ABSORB"
    B2_PENSION_ABSORB = "B2_PENSION_ABSORB"
    B3_FUND_PENSION_ABSORB = "B3_FUND_PENSION_ABSORB"
    DUAL_CONFIRMED = "DUAL_CONFIRMED"
    CORPORATE_ABSORB = "CORPORATE_ABSORB"


class FactTrust(StrEnum):
    LIVE = "LIVE"
    CONFIRMED = "CONFIRMED"
    ESTIMATED = "ESTIMATED"
    DELAYED = "DELAYED"
    STALE = "STALE"
    UNAVAILABLE = "UNAVAILABLE"


class AbsorptionFrame(BaseModel):
    venue: Venue = Venue.KRX
    symbol: str
    asof: datetime
    model: AbsorptionModel = AbsorptionModel.NONE
    prior_model: AbsorptionModel = AbsorptionModel.NONE
    stage: AbsorptionStage
    score_100: float = 0.0
    covered_weight: float = 0.0
    coverage_pct: float = 0.0

    price: float | None = None
    change_rate: float | None = None
    preemptive_fit: str = "WATCH"
    price_hold_pass: bool = False
    price_compression: bool = False

    foreign_net: float | None = None
    institution_net: float | None = None
    fund_net: float | None = None
    pension_net: float | None = None
    insurance_net: float | None = None
    financial_investment_net: float | None = None
    private_fund_net: float | None = None
    other_corporation_net: float | None = None
    program_net: float | None = None
    flow_unit: str | None = None
    investor_source_api_id: str | None = None

    seller_actor: str | None = None
    absorber_actor: str | None = None
    absorption_ratio: float | None = None
    prior_absorption_ratio: float | None = None
    absorption_ratio_delta: float | None = None
    seller_new_sell_velocity_per_min: float | None = None
    seller_previous_sell_velocity_per_min: float | None = None
    seller_sell_velocity_ratio: float | None = None
    seller_sell_deceleration_count: int = 0
    seller_sell_deceleration_confirmed: bool = False
    seller_neutral_or_buy_turn: bool | None = None
    absorber_buy_velocity_per_min: float | None = None
    program_improving: bool | None = None
    program_buy_turn: bool | None = None

    rising_lows: bool | None = None
    vwap_distance_pct: float | None = None
    intraday_range_position: float | None = None
    max_drawdown_10m_pct: float | None = None
    max_drawdown_30m_pct: float | None = None
    money_acceleration: float | None = None
    rvol_same_time: float | None = None
    rs_level: float | None = None
    rs_velocity: float | None = None
    rs_acceleration: float | None = None
    sector_name: str | None = None
    sector_relative_strength_pct: float | None = None
    sector_breadth_ratio: float | None = None
    sector_breadth_velocity: float | None = None

    price_defense_score_25: float = 0.0
    counterparty_absorption_score_20: float = 0.0
    selling_deceleration_score_15: float = 0.0
    flow_price_divergence_score_10: float = 0.0
    flow_acceleration_score_10: float = 0.0
    activity_acceleration_score_8: float = 0.0
    relative_strength_score_7: float = 0.0
    sector_expansion_score_5: float = 0.0

    price_trust: FactTrust = FactTrust.UNAVAILABLE
    investor_trust: FactTrust = FactTrust.UNAVAILABLE
    program_trust: FactTrust = FactTrust.UNAVAILABLE
    absorption_trust: FactTrust = FactTrust.UNAVAILABLE
    stage_trust: FactTrust = FactTrust.UNAVAILABLE

    reasons: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    missing: list[str] = Field(default_factory=list)
    interpretation_notes: list[str] = Field(default_factory=list)
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    feeds_existing_ranking: bool = False
