from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from math import isfinite

from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue


def _clip(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _ok(v: float | None) -> bool:
    return v is not None and isfinite(v)


@dataclass(frozen=True)
class AbsorptionInputs:
    symbol: str
    asof: datetime
    price: float | None
    change_rate: float | None
    foreign_net: float | None
    institution_net: float | None
    fund_net: float | None
    pension_net: float | None
    insurance_net: float | None
    financial_investment_net: float | None
    private_fund_net: float | None
    other_corporation_net: float | None
    program_net: float | None
    flow_unit: str | None
    investor_source_api_id: str | None
    prior_model: AbsorptionModel
    prior_stage: AbsorptionStage | None
    model_a_ratio: float | None
    model_b_ratio: float | None
    corporate_ratio: float | None
    prior_absorption_ratio: float | None
    absorption_ratio_delta: float | None
    seller_new_sell_velocity_per_min: float | None
    seller_previous_sell_velocity_per_min: float | None
    seller_sell_velocity_ratio: float | None
    seller_sell_deceleration_count: int
    seller_neutral_or_buy_turn: bool | None
    absorber_buy_velocity_per_min: float | None
    program_improving: bool | None
    program_buy_turn: bool | None
    rising_lows: bool | None
    vwap_distance_pct: float | None
    intraday_range_position: float | None
    max_drawdown_10m_pct: float | None
    max_drawdown_30m_pct: float | None
    money_acceleration: float | None
    rvol_same_time: float | None
    rs_level: float | None
    rs_velocity: float | None
    rs_acceleration: float | None
    sector_name: str | None
    sector_relative_strength_pct: float | None
    sector_breadth_ratio: float | None
    sector_breadth_velocity: float | None
    price_trust: FactTrust
    investor_trust: FactTrust
    program_trust: FactTrust
    market_red: bool = False


class DualAbsorptionEngine:
    """KRX-only DUAL ABSORPTION + PRICE HOLD shadow evaluator.

    PRICE HOLD is a hard gate. Results never feed existing PULSE scoring/ranking.
    """

    FULL_WEIGHT = 100.0

    def evaluate(self, x: AbsorptionInputs) -> AbsorptionFrame:
        reasons: list[str] = []
        risks: list[str] = []
        missing: list[str] = []

        model, seller, absorber, ratio = self._model(x, reasons)
        if ratio is None and x.prior_absorption_ratio is not None and model == AbsorptionModel.DUAL_CONFIRMED:
            ratio = x.prior_absorption_ratio
            reasons.append("PRIOR_ABSORPTION_RATIO_RETAINED_FOR_DUAL_CONFIRMATION")

        p25, wp25, price_hold = self._price_defense(x, reasons, missing)
        a20, wa20 = self._absorption(ratio, x.absorption_ratio_delta, model, reasons, missing)
        d15, wd15 = self._deceleration(x, reasons, missing)
        g10, wg10 = self._divergence(x, seller, price_hold, reasons, missing)
        f10, wf10 = self._flow_accel(x, reasons, missing)
        m8, wm8 = self._activity(x, reasons, missing)
        r7, wr7 = self._rs(x, reasons, missing)
        s5, ws5 = self._sector(x, reasons, missing)
        score = p25 + a20 + d15 + g10 + f10 + m8 + r7 + s5
        covered = wp25 + wa20 + wd15 + wg10 + wf10 + wm8 + wr7 + ws5

        decel = x.seller_sell_deceleration_count >= 2
        exhaustion = self._exhaustion(x, seller, ratio, price_hold)
        stage = self._stage(x, model, ratio, score, price_hold, decel, exhaustion)

        if not price_hold and ratio is not None and ratio >= 0.5:
            risks.append("ABSORPTION_WITHOUT_PRICE_HOLD")
            risks.append("PRICE_HOLD_HARD_GATE_FAILED")
        if x.change_rate is not None and x.change_rate >= 5.0:
            risks.append("ALREADY_UP_5PCT_PREEMPTIVE_EXCLUDED")
        elif x.change_rate is not None and x.change_rate >= 3.0:
            risks.append("PRICE_ALREADY_EXTENDED_PREEMPTIVE_PENALTY")
        if x.market_red:
            risks.append("MARKET_RED")
        if x.price_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            risks.append("PRICE_DATA_NOT_ACTIONABLE")
        if x.investor_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            risks.append("INVESTOR_DATA_NOT_ACTIONABLE")

        compression = bool(
            price_hold and x.change_rate is not None and -2.0 <= x.change_rate <= 2.5
            and ((x.money_acceleration is not None and x.money_acceleration > 0) or (x.rvol_same_time is not None and x.rvol_same_time >= 1.5))
            and ratio is not None and ratio >= 0.5
        )
        if compression:
            reasons.append("PRICE_COMPRESSION_WITH_ACTIVITY_AND_ABSORPTION")

        notes: list[str] = []
        if model == AbsorptionModel.A_FOREIGN_ABSORB:
            notes.append("FOREIGN_BUY_MAY_BE_ABSORBING_INSTITUTION_SELL_PRESSURE_ESTIMATED")
        elif model in {AbsorptionModel.B1_FUND_ABSORB, AbsorptionModel.B2_PENSION_ABSORB, AbsorptionModel.B3_FUND_PENSION_ABSORB}:
            notes.append("FUND_PENSION_BUY_MAY_BE_ABSORBING_FOREIGN_SELL_PRESSURE_ESTIMATED")
        elif model == AbsorptionModel.CORPORATE_ABSORB:
            notes.append("CORPORATE_ABSORB_SEPARATE_FROM_INSTITUTIONAL_MODEL")
        if decel:
            notes.append("SELL_SUPPLY_REDUCTION_POSSIBLE")
        if exhaustion:
            notes.append("SUPPLY_EXHAUSTION_ESTIMATED_NOT_DIRECT_MATCH")
        if price_hold:
            notes.append("PRICE_DEFENSE_CONFIRMED_BY_SHADOW_RULES")

        absorption_trust = FactTrust.ESTIMATED if ratio is not None else FactTrust.UNAVAILABLE
        stage_trust = self._stage_trust(x)
        fit = self._preemptive_fit(x, stage, price_hold, ratio, risks)

        return AbsorptionFrame(
            symbol=x.symbol, venue=Venue.KRX, asof=x.asof, model=model, prior_model=x.prior_model,
            stage=stage, score_100=round(_clip(score, 0, 100), 4), covered_weight=round(covered, 4),
            coverage_pct=round(covered, 4), price=x.price, change_rate=x.change_rate, preemptive_fit=fit,
            price_hold_pass=price_hold, price_compression=compression,
            foreign_net=x.foreign_net, institution_net=x.institution_net, fund_net=x.fund_net,
            pension_net=x.pension_net, insurance_net=x.insurance_net,
            financial_investment_net=x.financial_investment_net, private_fund_net=x.private_fund_net,
            other_corporation_net=x.other_corporation_net, program_net=x.program_net,
            flow_unit=x.flow_unit, investor_source_api_id=x.investor_source_api_id,
            seller_actor=seller, absorber_actor=absorber, absorption_ratio=ratio,
            prior_absorption_ratio=x.prior_absorption_ratio, absorption_ratio_delta=x.absorption_ratio_delta,
            seller_new_sell_velocity_per_min=x.seller_new_sell_velocity_per_min,
            seller_previous_sell_velocity_per_min=x.seller_previous_sell_velocity_per_min,
            seller_sell_velocity_ratio=x.seller_sell_velocity_ratio,
            seller_sell_deceleration_count=x.seller_sell_deceleration_count,
            seller_sell_deceleration_confirmed=decel, seller_neutral_or_buy_turn=x.seller_neutral_or_buy_turn,
            absorber_buy_velocity_per_min=x.absorber_buy_velocity_per_min,
            program_improving=x.program_improving, program_buy_turn=x.program_buy_turn,
            rising_lows=x.rising_lows, vwap_distance_pct=x.vwap_distance_pct,
            intraday_range_position=x.intraday_range_position, max_drawdown_10m_pct=x.max_drawdown_10m_pct,
            max_drawdown_30m_pct=x.max_drawdown_30m_pct, money_acceleration=x.money_acceleration,
            rvol_same_time=x.rvol_same_time, rs_level=x.rs_level, rs_velocity=x.rs_velocity,
            rs_acceleration=x.rs_acceleration, sector_name=x.sector_name,
            sector_relative_strength_pct=x.sector_relative_strength_pct,
            sector_breadth_ratio=x.sector_breadth_ratio, sector_breadth_velocity=x.sector_breadth_velocity,
            price_defense_score_25=round(p25,4), counterparty_absorption_score_20=round(a20,4),
            selling_deceleration_score_15=round(d15,4), flow_price_divergence_score_10=round(g10,4),
            flow_acceleration_score_10=round(f10,4), activity_acceleration_score_8=round(m8,4),
            relative_strength_score_7=round(r7,4), sector_expansion_score_5=round(s5,4),
            price_trust=x.price_trust, investor_trust=x.investor_trust, program_trust=x.program_trust,
            absorption_trust=absorption_trust, stage_trust=stage_trust,
            reasons=reasons, risks=risks, missing=missing, interpretation_notes=notes,
        )

    @staticmethod
    def _model(x: AbsorptionInputs, reasons: list[str]) -> tuple[AbsorptionModel, str | None, str | None, float | None]:
        # DUAL confirmation means the original seller has neutralized/turned while
        # the original absorber remains supportive. It reuses only same-session prior model facts.
        if x.prior_model == AbsorptionModel.A_FOREIGN_ABSORB and x.seller_neutral_or_buy_turn and (x.foreign_net or 0) > 0:
            reasons.append("DUAL_CONFIRMATION_AFTER_INSTITUTION_SELLING_END")
            return AbsorptionModel.DUAL_CONFIRMED, "INSTITUTION", "FOREIGN+INSTITUTION", x.prior_absorption_ratio
        if x.prior_model in {AbsorptionModel.B1_FUND_ABSORB, AbsorptionModel.B2_PENSION_ABSORB, AbsorptionModel.B3_FUND_PENSION_ABSORB} and x.seller_neutral_or_buy_turn and ((x.fund_net or 0) + (x.pension_net or 0)) > 0:
            reasons.append("DUAL_CONFIRMATION_AFTER_FOREIGN_SELLING_END")
            return AbsorptionModel.DUAL_CONFIRMED, "FOREIGN", "FOREIGN+FUND/PENSION", x.prior_absorption_ratio

        if x.institution_net is not None and x.institution_net < 0 and (x.foreign_net or 0) > 0:
            reasons.append("MODEL_A_FOREIGN_ABSORB")
            return AbsorptionModel.A_FOREIGN_ABSORB, "INSTITUTION", "FOREIGN", x.model_a_ratio

        fund = max(0.0, x.fund_net or 0.0)
        pension = max(0.0, x.pension_net or 0.0)
        if x.foreign_net is not None and x.foreign_net < 0 and fund + pension > 0:
            if fund > 0 and pension > 0:
                m = AbsorptionModel.B3_FUND_PENSION_ABSORB
            elif pension > 0:
                m = AbsorptionModel.B2_PENSION_ABSORB
            else:
                m = AbsorptionModel.B1_FUND_ABSORB
            reasons.append(m.value)
            return m, "FOREIGN", "FUND+PENSION" if m == AbsorptionModel.B3_FUND_PENSION_ABSORB else ("PENSION" if m == AbsorptionModel.B2_PENSION_ABSORB else "FUND"), x.model_b_ratio

        if x.foreign_net is not None and x.foreign_net < 0 and (x.other_corporation_net or 0) > 0:
            reasons.append("CORPORATE_ABSORB_NOT_MODEL_B")
            return AbsorptionModel.CORPORATE_ABSORB, "FOREIGN", "OTHER_CORPORATION", x.corporate_ratio
        return AbsorptionModel.NONE, None, None, None

    @staticmethod
    def _price_defense(x: AbsorptionInputs, reasons: list[str], missing: list[str]) -> tuple[float,float,bool]:
        score=0.0; weight=0.0; structural=0
        if x.change_rate is not None:
            weight += 8
            if x.change_rate >= -1.0 or ((x.rs_level or 0) > 0.8 and x.change_rate >= -3.0):
                score += 8; reasons.append("PRICE_HOLDS_DESPITE_SELL_PRESSURE")
            elif x.change_rate >= -2.0 or ((x.rs_level or 0) > 0 and x.change_rate >= -3.0):
                score += 5
        else: missing.append("CHANGE_RATE_UNAVAILABLE")
        if x.rising_lows is not None:
            weight += 5
            if x.rising_lows: score += 5; structural += 1; reasons.append("INTRADAY_LOWS_RISING")
        else: missing.append("RISING_LOWS_WARMING")
        if x.vwap_distance_pct is not None:
            weight += 5
            if x.vwap_distance_pct >= 0: score += 5; structural += 1; reasons.append("VWAP_DEFENDED")
            elif x.vwap_distance_pct >= -0.25: score += 3; structural += 1
        else: missing.append("VWAP_UNAVAILABLE")
        # PRICE HOLD RS component is explicitly split between market-relative
        # and sector-relative defense (2 + 2). Sector-relative strength is the
        # symbol change minus the current sector member median change.
        if x.rs_level is not None:
            weight += 2
            if x.rs_level > 0:
                score += 2; structural += 1; reasons.append("MARKET_RELATIVE_DEFENSE")
        else:
            missing.append("MARKET_RS_UNAVAILABLE_FOR_PRICE_HOLD")
        if x.sector_relative_strength_pct is not None:
            weight += 2
            if x.sector_relative_strength_pct > 0:
                score += 2; structural += 1; reasons.append("SECTOR_RELATIVE_DEFENSE")
        else:
            missing.append("SECTOR_RS_UNAVAILABLE_FOR_PRICE_HOLD")
        if x.intraday_range_position is not None:
            weight += 3
            if x.intraday_range_position >= .75: score += 3
            elif x.intraday_range_position >= .60: score += 2
            elif x.intraday_range_position >= .45: score += 1
        else: missing.append("RANGE_POSITION_UNAVAILABLE")
        collapse = x.change_rate is not None and x.change_rate < -3.0 and (x.rs_level is None or x.rs_level <= 0)
        lower_range = x.intraday_range_position is not None and x.intraday_range_position < .35
        hard = bool(score >= 15.0 and structural >= 1 and not collapse and not lower_range)
        return min(25.0,score), weight, hard

    @staticmethod
    def _absorption(ratio, delta, model, reasons, missing):
        if ratio is None or model == AbsorptionModel.NONE:
            missing.append("COUNTERPARTY_ABSORPTION_RATIO_UNAVAILABLE"); return 0.0,0.0
        if ratio >= 1.0: score=16.0; reasons.append("STRONG_COUNTERPARTY_ABSORPTION_ESTIMATED")
        elif ratio >= .70: score=13.0; reasons.append("MEANINGFUL_COUNTERPARTY_ABSORPTION_ESTIMATED")
        elif ratio >= .50: score=8.0
        else: score=2.0
        if delta is not None:
            if delta >= .20: score += 4
            elif delta >= .10: score += 3
            elif delta > 0: score += 1.5
        return min(20.0,score),20.0

    @staticmethod
    def _deceleration(x, reasons, missing):
        if x.seller_new_sell_velocity_per_min is None or x.seller_previous_sell_velocity_per_min is None:
            missing.append("SELLING_VELOCITY_HISTORY_WARMING"); return 0.0,0.0
        ratio=x.seller_sell_velocity_ratio; score=0.0
        if ratio is not None:
            if ratio <= .25: score += 10
            elif ratio <= .50: score += 8
            elif ratio <= .75: score += 5
            elif ratio < 1: score += 2
        score += min(5.0, x.seller_sell_deceleration_count*2.5)
        if x.seller_sell_deceleration_count >= 2: reasons.append("SELLING_DECELERATION_CONFIRMED")
        if x.seller_neutral_or_buy_turn: score=15.0; reasons.append("ORIGINAL_SELLER_NEUTRAL_OR_BUY_TURN")
        return min(15.0,score),15.0

    @staticmethod
    def _divergence(x, seller, price_hold, reasons, missing):
        if seller is None: return 0.0,0.0
        if price_hold: reasons.append("SELL_PRESSURE_PRICE_DIVERGENCE"); return 10.0,10.0
        return 0.0,10.0

    @staticmethod
    def _flow_accel(x, reasons, missing):
        score=0.0; weight=0.0
        if x.absorber_buy_velocity_per_min is not None:
            weight += 5
            if x.absorber_buy_velocity_per_min > 0: score += 5; reasons.append("ABSORBER_BUY_FLOW_PERSISTING")
        else: missing.append("ABSORBER_VELOCITY_WARMING")
        if x.program_improving is not None:
            weight += 5
            if x.program_improving: score += 3
            if x.program_buy_turn: score += 2; reasons.append("PROGRAM_BUY_TURN")
        else: missing.append("PROGRAM_FLOW_UNAVAILABLE")
        return min(10.0,score),weight

    @staticmethod
    def _activity(x, reasons, missing):
        score=0.0; weight=0.0
        if x.money_acceleration is not None:
            weight += 4
            if x.money_acceleration > 0: score += 4
        else: missing.append("MONEY_ACCELERATION_UNAVAILABLE")
        if x.rvol_same_time is not None:
            weight += 4
            if x.rvol_same_time >= 2: score += 4
            elif x.rvol_same_time >= 1.5: score += 3
            elif x.rvol_same_time >= 1: score += 1
        else: missing.append("SAME_TIME_ACTIVITY_UNAVAILABLE")
        return score,weight

    @staticmethod
    def _rs(x, reasons, missing):
        score=0.0; weight=0.0
        if x.rs_level is not None:
            weight += 2
            if x.rs_level > 0: score += 2
        else: missing.append("MARKET_RS_LEVEL_UNAVAILABLE")
        if x.sector_relative_strength_pct is not None:
            weight += 2
            if x.sector_relative_strength_pct > 0: score += 2
        else: missing.append("SECTOR_RS_UNAVAILABLE")
        if x.rs_velocity is not None:
            weight += 1.5
            if x.rs_velocity > 0: score += 1.5
        if x.rs_acceleration is not None:
            weight += 1.5
            if x.rs_acceleration > 0: score += 1.5
        return score,weight

    @staticmethod
    def _sector(x, reasons, missing):
        score=0.0; weight=0.0
        if x.sector_breadth_ratio is not None:
            weight += 3
            if x.sector_breadth_ratio >= 60: score += 3
        else: missing.append("SECTOR_BREADTH_UNAVAILABLE")
        if x.sector_breadth_velocity is not None:
            weight += 2
            if x.sector_breadth_velocity > 0: score += 2
        return score,weight

    @staticmethod
    def _exhaustion(x, seller, ratio, price_hold):
        return bool(
            seller is not None and ratio is not None and ratio >= .7 and price_hold
            and x.seller_sell_deceleration_count >= 2
            and ((x.seller_sell_velocity_ratio is not None and x.seller_sell_velocity_ratio <= .25)
                 or (x.seller_new_sell_velocity_per_min is not None and x.seller_new_sell_velocity_per_min <= .25)
                 or x.seller_neutral_or_buy_turn)
        )

    @staticmethod
    def _stage(x, model, ratio, score, price_hold, decel, exhaustion):
        if x.price is None or x.investor_trust in {FactTrust.STALE, FactTrust.UNAVAILABLE}:
            return AbsorptionStage.DATA_WAIT
        if x.change_rate is not None and x.change_rate >= 5.0:
            return AbsorptionStage.IGNITION
        if model == AbsorptionModel.NONE or ratio is None or ratio < .50:
            return AbsorptionStage.WATCH
        # Absorption may be real while price defense fails. Keep it visible as
        # ABSORB, but the PRICE HOLD hard gate prevents any further promotion.
        if not price_hold:
            return AbsorptionStage.ABSORB
        if score < 70:
            return AbsorptionStage.WATCH
        if score < 78:
            return AbsorptionStage.ABSORB
        if score < 85 or not decel:
            return AbsorptionStage.PRICE_HOLD
        if score < 90 or not exhaustion:
            return AbsorptionStage.SUPPLY_TIGHT
        if score < 94:
            return AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED
        flow_ok=(x.absorber_buy_velocity_per_min or 0)>0 and ((x.money_acceleration or 0)>0 or (x.rvol_same_time or 0)>=1.5)
        rs_ok=(x.rs_level or 0)>0
        if exhaustion and flow_ok and rs_ok:
            return AbsorptionStage.PRE_IGNITION
        return AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED

    @staticmethod
    def _preemptive_fit(x, stage, price_hold, ratio, risks):
        if "ALREADY_UP_5PCT_PREEMPTIVE_EXCLUDED" in risks or x.market_red or not price_hold:
            return "EXCLUDE"
        if x.investor_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            return "EXCLUDE"
        if stage == AbsorptionStage.PRE_IGNITION and ratio is not None and ratio >= .7:
            if x.change_rate is not None and -1 <= x.change_rate <= 2.5: return "A"
            if x.change_rate is not None and -2 <= x.change_rate <= 3.0: return "B"
        if stage in {AbsorptionStage.SUPPLY_TIGHT, AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED, AbsorptionStage.PRICE_HOLD}:
            return "B"
        return "WATCH"

    @staticmethod
    def _stage_trust(x):
        trusts={x.price_trust,x.investor_trust,x.program_trust}
        if FactTrust.UNAVAILABLE in trusts: return FactTrust.UNAVAILABLE
        if FactTrust.STALE in trusts: return FactTrust.STALE
        if FactTrust.DELAYED in trusts: return FactTrust.DELAYED
        if FactTrust.ESTIMATED in trusts: return FactTrust.ESTIMATED
        if FactTrust.CONFIRMED in trusts: return FactTrust.CONFIRMED
        return FactTrust.LIVE


# Backward import compatibility: implementation is now DUAL/PRICE-HOLD, not the old Model-A-only engine.
SupplyAbsorptionEngine = DualAbsorptionEngine
