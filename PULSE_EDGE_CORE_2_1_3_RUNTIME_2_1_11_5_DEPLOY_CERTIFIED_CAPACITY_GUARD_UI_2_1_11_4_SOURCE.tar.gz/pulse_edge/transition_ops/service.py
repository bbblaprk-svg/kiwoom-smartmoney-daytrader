from __future__ import annotations

from datetime import datetime, time, timezone
from uuid import uuid4
from zoneinfo import ZoneInfo

from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue
from .models import AlertSeverity, AlertType, CloseClass, KrxCloseRecord, TransitionAlert
from .store import TransitionOpsStore

KST = ZoneInfo("Asia/Seoul")
ORDER = {s: i for i, s in enumerate([
    AbsorptionStage.DATA_WAIT,
    AbsorptionStage.WATCH,
    AbsorptionStage.ABSORB,
    AbsorptionStage.PRICE_HOLD,
    AbsorptionStage.SUPPLY_TIGHT,
    AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,
    AbsorptionStage.PRE_IGNITION,
    AbsorptionStage.IGNITION,
])}


class TransitionOpsService:
    """One-way Phase 6D observer. Alerts and close records never feed selection/ranking."""

    def __init__(self, *, store: TransitionOpsStore, absorption, close_time: time = time(15, 30), alert_cooldown_sec: float = 600.0):
        self.store = store
        self.absorption = absorption
        self.close_time = close_time
        self.alert_cooldown_sec = max(0.0, float(alert_cooldown_sec))
        self._last: dict[tuple[Venue, str], AbsorptionFrame] = {}
        self._last_alert_at: dict[tuple, datetime] = {}
        self._day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    @staticmethod
    def _fresh_same_day(frame: AbsorptionFrame, day: str) -> bool:
        if frame.asof.tzinfo is None:
            at = frame.asof.replace(tzinfo=timezone.utc)
        else:
            at = frame.asof
        return at.astimezone(KST).date().isoformat() == day

    @staticmethod
    def _severity(event: AlertType, to_stage: AbsorptionStage | None = None) -> AlertSeverity:
        if event == AlertType.PRICE_HOLD_FAILED:
            return AlertSeverity.CRITICAL
        if event == AlertType.STAGE_DOWNGRADE:
            return AlertSeverity.HIGH
        if event == AlertType.MODEL_CHANGE:
            return AlertSeverity.HIGH
        if event == AlertType.STAGE_PROMOTION and to_stage in {
            AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,
            AbsorptionStage.PRE_IGNITION,
            AbsorptionStage.IGNITION,
        }:
            return AlertSeverity.HIGH
        return AlertSeverity.INFO

    def _alert(self, now: datetime, day: str, f: AbsorptionFrame, event: AlertType, *, prev: AbsorptionFrame, reasons: list[str]) -> TransitionAlert:
        return TransitionAlert(
            alert_id=uuid4().hex,
            trading_day=day,
            symbol=f.symbol,
            model=f.model,
            event_type=event,
            severity=self._severity(event, f.stage),
            alert_at=now,
            from_stage=prev.stage,
            to_stage=f.stage,
            price=float(f.price),
            score_100=f.score_100,
            score_delta=round(f.score_100 - prev.score_100, 4),
            absorption_ratio=f.absorption_ratio,
            absorption_ratio_delta=f.absorption_ratio_delta,
            seller_actor=f.seller_actor,
            seller_velocity=f.seller_new_sell_velocity_per_min,
            seller_decel_count=f.seller_sell_deceleration_count,
            program_buy_turn=f.program_buy_turn,
            vwap_distance_pct=f.vwap_distance_pct,
            rising_lows=f.rising_lows,
            sector_breadth_ratio=f.sector_breadth_ratio,
            price_hold_pass=f.price_hold_pass,
            stage_trust=f.stage_trust,
            reasons=reasons,
        )

    def _material_events(self, prev: AbsorptionFrame, f: AbsorptionFrame) -> list[tuple[AlertType, list[str]]]:
        out: list[tuple[AlertType, list[str]]] = []
        if prev.stage != f.stage:
            kind = AlertType.STAGE_PROMOTION if ORDER[f.stage] > ORDER[prev.stage] else AlertType.STAGE_DOWNGRADE
            out.append((kind, [f"stage:{prev.stage.value}->{f.stage.value}"]))
        if prev.model != f.model and prev.model != AbsorptionModel.NONE and f.model != AbsorptionModel.NONE:
            out.append((AlertType.MODEL_CHANGE, [f"model:{prev.model.value}->{f.model.value}"]))
        pr, cr = prev.absorption_ratio, f.absorption_ratio
        if cr is not None and cr >= 0.70 and (pr is None or pr < 0.70):
            out.append((AlertType.ABSORPTION_RATIO_CROSS_070, [f"absorption_ratio:{pr}->{cr}"]))
        if f.score_100 - prev.score_100 >= 8.0:
            out.append((AlertType.SCORE_JUMP_8, [f"score_delta:{round(f.score_100-prev.score_100,2)}"]))
        if f.program_buy_turn is True and prev.program_buy_turn is not True:
            out.append((AlertType.PROGRAM_BUY_TURN, ["program_buy_turn:new"]))
        if f.vwap_distance_pct is not None and f.vwap_distance_pct > 0 and (prev.vwap_distance_pct is not None and prev.vwap_distance_pct <= 0):
            out.append((AlertType.VWAP_RECLAIM, [f"vwap_distance_pct:{prev.vwap_distance_pct}->{f.vwap_distance_pct}"]))
        if f.rising_lows is True and prev.rising_lows is not True:
            out.append((AlertType.HIGHER_LOW_CONFIRMED, ["rising_lows:new_true"]))
        if f.sector_breadth_ratio is not None and prev.sector_breadth_ratio is not None and f.sector_breadth_ratio - prev.sector_breadth_ratio >= 0.15:
            out.append((AlertType.SECTOR_BREADTH_EXPANSION, [f"breadth_delta:{round(f.sector_breadth_ratio-prev.sector_breadth_ratio,4)}"]))
        if prev.price_hold_pass and not f.price_hold_pass:
            out.append((AlertType.PRICE_HOLD_FAILED, ["price_hold:true->false"]))
        return out

    @staticmethod
    def classify_close(f: AbsorptionFrame) -> tuple[CloseClass, list[str]]:
        if f.price_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            return CloseClass.FAILED, ["PRICE_DATA_NOT_ACTIONABLE"]
        if f.investor_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            return CloseClass.FAILED, ["INVESTOR_DATA_NOT_ACTIONABLE"]
        if not f.price_hold_pass:
            return CloseClass.FAILED, ["PRICE_HOLD_FAILED"]
        if f.preemptive_fit == "EXCLUDE":
            return CloseClass.FAILED, ["PREEMPTIVE_EXCLUDED"]
        if f.stage == AbsorptionStage.PRE_IGNITION:
            return CloseClass.CLOSE_PRE_IGNITION, ["PRE_IGNITION_AT_KRX_CLOSE", "PRICE_HOLD_PASS"]
        if f.stage in {AbsorptionStage.SUPPLY_TIGHT, AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED}:
            return CloseClass.SUPPLY_TIGHT_OVERNIGHT, [f"{f.stage.value}_AT_KRX_CLOSE", "PRICE_HOLD_PASS"]
        if f.stage == AbsorptionStage.PRICE_HOLD:
            return CloseClass.PRICE_HOLD_OVERNIGHT, ["PRICE_HOLD_AT_KRX_CLOSE"]
        if f.stage == AbsorptionStage.IGNITION:
            return CloseClass.FAILED, ["ALREADY_IGNITED_AT_KRX_CLOSE"]
        return CloseClass.FAILED, [f"INSUFFICIENT_CLOSE_STAGE:{f.stage.value}"]

    def refresh(self, asof: datetime | None = None) -> dict[str, int]:
        now = asof or datetime.now(timezone.utc)
        local = now.astimezone(KST)
        day = local.date().isoformat()
        if self._day != day:
            self._last.clear()
            self._last_alert_at.clear()
            self._day = day
        alerts = 0
        closes = 0
        for f in list(self.absorption.frames.values()):
            if f.venue != Venue.KRX or f.price is None or f.price <= 0:
                continue
            if not self._fresh_same_day(f, day):
                continue
            key = (f.venue, f.symbol)
            prev = self._last.get(key)
            if prev is not None:
                for event, reasons in self._material_events(prev, f):
                    # Stage transitions are keyed by the exact transition. Other material
                    # events use a per-symbol/event cooldown to prevent oscillation spam.
                    if event in {AlertType.STAGE_PROMOTION, AlertType.STAGE_DOWNGRADE}:
                        alert_key = (day, f.symbol, event.value, prev.stage.value, f.stage.value)
                    elif event == AlertType.MODEL_CHANGE:
                        alert_key = (day, f.symbol, event.value, prev.model.value, f.model.value)
                    else:
                        alert_key = (day, f.symbol, event.value)
                    prior_alert = self._last_alert_at.get(alert_key)
                    if prior_alert is None:
                        if event in {AlertType.STAGE_PROMOTION, AlertType.STAGE_DOWNGRADE}:
                            prior_alert = self.store.last_alert_at(day, f.symbol, event.value, prev.stage.value, f.stage.value)
                        else:
                            prior_alert = self.store.last_alert_at(day, f.symbol, event.value)
                    if prior_alert is not None and (now - prior_alert).total_seconds() < self.alert_cooldown_sec:
                        continue
                    if self.store.insert_alert(self._alert(now, day, f, event, prev=prev, reasons=reasons)):
                        self._last_alert_at[alert_key] = now
                        alerts += 1
            self._last[key] = f.model_copy(deep=True)

            if local.time() >= self.close_time and f.model != AbsorptionModel.NONE:
                cls, reasons = self.classify_close(f)
                snap = KrxCloseRecord(
                    trading_day=day,
                    symbol=f.symbol,
                    model=f.model,
                    classification=cls,
                    classified_at=now,
                    source_asof=f.asof,
                    stage=f.stage,
                    price=float(f.price),
                    score_100=f.score_100,
                    price_hold_score_25=f.price_defense_score_25,
                    absorption_ratio=f.absorption_ratio,
                    seller_decel_count=f.seller_sell_deceleration_count,
                    price_hold_pass=f.price_hold_pass,
                    preemptive_fit=f.preemptive_fit,
                    vwap_distance_pct=f.vwap_distance_pct,
                    range_position=f.intraday_range_position,
                    market_rs=f.rs_level,
                    sector_rs=f.sector_relative_strength_pct,
                    sector_breadth_ratio=f.sector_breadth_ratio,
                    stage_trust=f.stage_trust,
                    reasons=reasons,
                )
                if self.store.insert_close(snap):
                    closes += 1
        self.last_refresh_at = now
        self.last_error = None
        return {"alerts": alerts, "close_records": closes}
