from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.absorption.models import AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue


class AlertType(StrEnum):
    STAGE_PROMOTION = "STAGE_PROMOTION"
    STAGE_DOWNGRADE = "STAGE_DOWNGRADE"
    MODEL_CHANGE = "MODEL_CHANGE"
    ABSORPTION_RATIO_CROSS_070 = "ABSORPTION_RATIO_CROSS_070"
    SCORE_JUMP_8 = "SCORE_JUMP_8"
    PROGRAM_BUY_TURN = "PROGRAM_BUY_TURN"
    VWAP_RECLAIM = "VWAP_RECLAIM"
    HIGHER_LOW_CONFIRMED = "HIGHER_LOW_CONFIRMED"
    SECTOR_BREADTH_EXPANSION = "SECTOR_BREADTH_EXPANSION"
    PRICE_HOLD_FAILED = "PRICE_HOLD_FAILED"


class AlertSeverity(StrEnum):
    INFO = "INFO"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class CloseClass(StrEnum):
    CLOSE_PRE_IGNITION = "CLOSE_PRE_IGNITION"
    SUPPLY_TIGHT_OVERNIGHT = "SUPPLY_TIGHT_OVERNIGHT"
    PRICE_HOLD_OVERNIGHT = "PRICE_HOLD_OVERNIGHT"
    FAILED = "FAILED"


class TransitionAlert(BaseModel):
    alert_id: str
    trading_day: str
    venue: Venue = Venue.KRX
    symbol: str
    model: AbsorptionModel
    event_type: AlertType
    severity: AlertSeverity
    alert_at: datetime
    from_stage: AbsorptionStage | None = None
    to_stage: AbsorptionStage | None = None
    price: float
    score_100: float
    score_delta: float | None = None
    absorption_ratio: float | None = None
    absorption_ratio_delta: float | None = None
    seller_actor: str | None = None
    seller_velocity: float | None = None
    seller_decel_count: int = 0
    program_buy_turn: bool | None = None
    vwap_distance_pct: float | None = None
    rising_lows: bool | None = None
    sector_breadth_ratio: float | None = None
    price_hold_pass: bool = False
    stage_trust: FactTrust = FactTrust.UNAVAILABLE
    reasons: list[str] = Field(default_factory=list)
    feeds_existing_ranking: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False


class KrxCloseRecord(BaseModel):
    trading_day: str
    venue: Venue = Venue.KRX
    symbol: str
    model: AbsorptionModel
    classification: CloseClass
    classified_at: datetime
    source_asof: datetime
    stage: AbsorptionStage
    price: float
    score_100: float
    price_hold_score_25: float
    absorption_ratio: float | None = None
    seller_decel_count: int = 0
    price_hold_pass: bool = False
    preemptive_fit: str
    vwap_distance_pct: float | None = None
    range_position: float | None = None
    market_rs: float | None = None
    sector_rs: float | None = None
    sector_breadth_ratio: float | None = None
    stage_trust: FactTrust = FactTrust.UNAVAILABLE
    reasons: list[str] = Field(default_factory=list)
    reference_only_next_session: bool = True
    feeds_next_session_current_facts: bool = False
    feeds_existing_ranking: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
