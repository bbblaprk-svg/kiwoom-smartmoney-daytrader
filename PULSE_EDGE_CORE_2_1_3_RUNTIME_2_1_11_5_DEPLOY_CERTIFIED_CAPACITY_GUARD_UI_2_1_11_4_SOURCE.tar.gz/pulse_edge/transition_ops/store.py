from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from .models import KrxCloseRecord, TransitionAlert


def _iso(v: datetime | None) -> str | None:
    if v is None:
        return None
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.astimezone(timezone.utc).isoformat()


class TransitionOpsStore:
    """Phase 6D event/close archive only. It never supplies current scoring inputs."""

    def __init__(self, path: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._schema()

    def _schema(self) -> None:
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS transition_alert(
              alert_id TEXT PRIMARY KEY,
              trading_day TEXT NOT NULL,
              venue TEXT NOT NULL,
              symbol TEXT NOT NULL,
              model TEXT NOT NULL,
              event_type TEXT NOT NULL,
              severity TEXT NOT NULL,
              alert_at TEXT NOT NULL,
              from_stage TEXT,
              to_stage TEXT,
              price REAL NOT NULL,
              score_100 REAL NOT NULL,
              score_delta REAL,
              absorption_ratio REAL,
              absorption_ratio_delta REAL,
              seller_actor TEXT,
              seller_velocity REAL,
              seller_decel_count INTEGER NOT NULL,
              program_buy_turn INTEGER,
              vwap_distance_pct REAL,
              rising_lows INTEGER,
              sector_breadth_ratio REAL,
              price_hold_pass INTEGER NOT NULL,
              stage_trust TEXT NOT NULL,
              reasons_json TEXT NOT NULL,
              feeds_existing_ranking INTEGER NOT NULL DEFAULT 0,
              official_signal_enabled INTEGER NOT NULL DEFAULT 0,
              order_action_enabled INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_transition_alert_time
              ON transition_alert(alert_at DESC);
            CREATE INDEX IF NOT EXISTS idx_transition_alert_symbol
              ON transition_alert(trading_day, symbol, alert_at DESC);

            CREATE TABLE IF NOT EXISTS krx_close_record(
              trading_day TEXT NOT NULL,
              venue TEXT NOT NULL,
              symbol TEXT NOT NULL,
              model TEXT NOT NULL,
              classification TEXT NOT NULL,
              classified_at TEXT NOT NULL,
              source_asof TEXT NOT NULL,
              stage TEXT NOT NULL,
              price REAL NOT NULL,
              score_100 REAL NOT NULL,
              price_hold_score_25 REAL NOT NULL,
              absorption_ratio REAL,
              seller_decel_count INTEGER NOT NULL,
              price_hold_pass INTEGER NOT NULL,
              preemptive_fit TEXT NOT NULL,
              vwap_distance_pct REAL,
              range_position REAL,
              market_rs REAL,
              sector_rs REAL,
              sector_breadth_ratio REAL,
              stage_trust TEXT NOT NULL,
              reasons_json TEXT NOT NULL,
              reference_only_next_session INTEGER NOT NULL DEFAULT 1,
              feeds_next_session_current_facts INTEGER NOT NULL DEFAULT 0,
              feeds_existing_ranking INTEGER NOT NULL DEFAULT 0,
              official_signal_enabled INTEGER NOT NULL DEFAULT 0,
              order_action_enabled INTEGER NOT NULL DEFAULT 0,
              PRIMARY KEY(trading_day, venue, symbol)
            );
            CREATE INDEX IF NOT EXISTS idx_krx_close_class
              ON krx_close_record(trading_day, classification, score_100 DESC);
            """
        )
        self._db.commit()

    def insert_alert(self, x: TransitionAlert) -> bool:
        with self._lock:
            cur = self._db.execute(
                """INSERT OR IGNORE INTO transition_alert(
                alert_id,trading_day,venue,symbol,model,event_type,severity,alert_at,from_stage,to_stage,
                price,score_100,score_delta,absorption_ratio,absorption_ratio_delta,seller_actor,seller_velocity,
                seller_decel_count,program_buy_turn,vwap_distance_pct,rising_lows,sector_breadth_ratio,price_hold_pass,
                stage_trust,reasons_json,feeds_existing_ranking,official_signal_enabled,order_action_enabled)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    x.alert_id,x.trading_day,x.venue.value,x.symbol,x.model.value,x.event_type.value,x.severity.value,_iso(x.alert_at),
                    x.from_stage.value if x.from_stage else None,x.to_stage.value if x.to_stage else None,x.price,x.score_100,x.score_delta,
                    x.absorption_ratio,x.absorption_ratio_delta,x.seller_actor,x.seller_velocity,x.seller_decel_count,
                    None if x.program_buy_turn is None else int(x.program_buy_turn),x.vwap_distance_pct,
                    None if x.rising_lows is None else int(x.rising_lows),x.sector_breadth_ratio,int(x.price_hold_pass),x.stage_trust.value,
                    json.dumps(x.reasons,ensure_ascii=False),int(x.feeds_existing_ranking),int(x.official_signal_enabled),int(x.order_action_enabled),
                ),
            )
            self._db.commit()
            return bool(cur.rowcount)

    def insert_close(self, x: KrxCloseRecord) -> bool:
        with self._lock:
            cur = self._db.execute(
                """INSERT OR IGNORE INTO krx_close_record(
                trading_day,venue,symbol,model,classification,classified_at,source_asof,stage,price,score_100,
                price_hold_score_25,absorption_ratio,seller_decel_count,price_hold_pass,preemptive_fit,vwap_distance_pct,
                range_position,market_rs,sector_rs,sector_breadth_ratio,stage_trust,reasons_json,reference_only_next_session,
                feeds_next_session_current_facts,feeds_existing_ranking,official_signal_enabled,order_action_enabled)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    x.trading_day,x.venue.value,x.symbol,x.model.value,x.classification.value,_iso(x.classified_at),_iso(x.source_asof),
                    x.stage.value,x.price,x.score_100,x.price_hold_score_25,x.absorption_ratio,x.seller_decel_count,int(x.price_hold_pass),
                    x.preemptive_fit,x.vwap_distance_pct,x.range_position,x.market_rs,x.sector_rs,x.sector_breadth_ratio,x.stage_trust.value,
                    json.dumps(x.reasons,ensure_ascii=False),int(x.reference_only_next_session),int(x.feeds_next_session_current_facts),
                    int(x.feeds_existing_ranking),int(x.official_signal_enabled),int(x.order_action_enabled),
                ),
            )
            self._db.commit()
            return bool(cur.rowcount)

    def recent_alerts(self, limit: int = 100):
        return self._db.execute("SELECT * FROM transition_alert ORDER BY alert_at DESC LIMIT ?", (limit,)).fetchall()

    def last_alert_at(self, trading_day: str, symbol: str, event_type: str, from_stage: str | None = None, to_stage: str | None = None):
        q = "SELECT alert_at FROM transition_alert WHERE trading_day=? AND symbol=? AND event_type=?"
        args: list[object] = [trading_day, symbol, event_type]
        if from_stage is not None:
            q += " AND from_stage=?"; args.append(from_stage)
        if to_stage is not None:
            q += " AND to_stage=?"; args.append(to_stage)
        q += " ORDER BY alert_at DESC LIMIT 1"
        r = self._db.execute(q, tuple(args)).fetchone()
        if not r:
            return None
        x = datetime.fromisoformat(r["alert_at"])
        return x if x.tzinfo else x.replace(tzinfo=timezone.utc)

    def close_rows(self, trading_day: str | None = None, limit: int = 100):
        if trading_day:
            return self._db.execute(
                "SELECT * FROM krx_close_record WHERE trading_day=? ORDER BY score_100 DESC, symbol LIMIT ?",
                (trading_day, limit),
            ).fetchall()
        return self._db.execute("SELECT * FROM krx_close_record ORDER BY trading_day DESC, score_100 DESC LIMIT ?", (limit,)).fetchall()

    def close(self) -> None:
        self._db.close()
