from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum


class FreshnessBand(StrEnum):
    FRESH_0_2M = "FRESH_0_2M"
    FRESH_2_5M = "FRESH_2_5M"
    AGING_5_10M = "AGING_5_10M"
    OLD_10_20M = "OLD_10_20M"
    EXPIRED = "EXPIRED"


@dataclass(frozen=True)
class FreshnessFrame:
    evidence_at: datetime
    age_sec: float
    score_100: float
    band: FreshnessBand
    expired: bool


def evaluate_freshness(evidence_at: datetime, now: datetime) -> FreshnessFrame:
    age = max(0.0, (now - evidence_at).total_seconds())
    if age <= 120:
        score, band = 100.0, FreshnessBand.FRESH_0_2M
    elif age <= 300:
        score, band = 85.0, FreshnessBand.FRESH_2_5M
    elif age <= 600:
        score, band = 65.0, FreshnessBand.AGING_5_10M
    elif age <= 1200:
        score, band = 40.0, FreshnessBand.OLD_10_20M
    else:
        score, band = 0.0, FreshnessBand.EXPIRED
    return FreshnessFrame(evidence_at, age, score, band, band == FreshnessBand.EXPIRED)
