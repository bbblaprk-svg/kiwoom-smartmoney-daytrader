from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue
from pulse_edge.smart_money.freshness import FreshnessBand


class PriceRoute(StrEnum):
    SMART_PRE_ZONE = "SMART_PRE_ZONE"
    DEEP_RED_REVIEW = "DEEP_RED_REVIEW"
    ROUTE_IGNITION = "ROUTE_IGNITION"
    PRICE_UNKNOWN = "PRICE_UNKNOWN"


class SmartMoneyStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    SCOUT = "SCOUT"
    WATCH = "WATCH"
    PRE_SHADOW = "PRE_SHADOW"
    ROUTE_IGNITION = "ROUTE_IGNITION"


class SmartMoneyFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    price: float | None = None
    change_rate: float | None = None
    price_route: PriceRoute
    stage: SmartMoneyStage

    foreign_absorption_score: float = 0.0
    compression_score: float = 0.0
    rs_score: float = 0.0
    sector_score: float = 0.0
    money_acceleration_score: float = 0.0
    business_context_score: float = 0.0
    confirmation_score: float = 0.0

    raw_score_100: float = 0.0
    covered_weight: float = 0.0
    coverage_pct: float = 0.0
    observed_score_pct: float = 0.0
    core_score_75: float = 0.0
    core_score_pct: float = 0.0

    foreign_1d: float | None = None
    foreign_3d: float | None = None
    foreign_5d: float | None = None
    institution_5d: float | None = None
    foreign_streak_days: float | None = None
    seller_absorption_ratio: float | None = None
    turnover_absorption_pct: float | None = None
    intraday_foreign_net: float | None = None
    intraday_institution_net: float | None = None

    return_5d_pct: float | None = None
    atr_compression_ratio: float | None = None
    range_compression_ratio: float | None = None
    volume_ratio: float | None = None
    rising_lows: bool | None = None

    rs_level: float | None = None
    rs_velocity: float | None = None
    rs_acceleration: float | None = None
    rs_zero_cross: bool | None = None
    rvol_same_time: float | None = None
    money_acceleration: float | None = None
    money_second_derivative: float | None = None
    vwap_distance_pct: float | None = None

    program_net_buy_amount_delta: float | None = None

    evidence_at: datetime | None = None
    evidence_age_sec: float | None = None
    freshness_score: float = 0.0
    freshness_band: FreshnessBand | None = None
    episode_id: int = 0

    foreign_flow_velocity: float | None = None
    foreign_flow_acceleration: float | None = None
    foreign_flow_reversal: bool | None = None
    flow_price_divergence_score: float = 0.0
    rs_accel_percentile: float | None = None
    money_accel_percentile: float | None = None
    sector_name: str | None = None
    sector_breadth_ratio: float | None = None
    sector_breadth_velocity: float | None = None
    sector_breadth_acceleration: float | None = None
    business_evidence_count: int = 0

    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
