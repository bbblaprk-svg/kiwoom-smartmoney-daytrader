from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterable

from pulse_edge.background.service import BackgroundCoverageService
from pulse_edge.context.business import BusinessContextService
from pulse_edge.context.daily import DailyContextService
from pulse_edge.core.models import Venue
from pulse_edge.discovery.market import DiscoveryEvent, MarketDiscoveryService
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.flow.investor import InvestorFlowService
from pulse_edge.sector.service import SectorBreadthService
from pulse_edge.smart_money.engine import SmartMoneyEngine
from pulse_edge.smart_money.freshness import evaluate_freshness
from pulse_edge.smart_money.models import SmartMoneyFrame


def _percentiles(values: dict[tuple[Venue, str], float | None]) -> dict[tuple[Venue, str], float | None]:
    valid = sorted((value, key) for key, value in values.items() if value is not None)
    if not valid:
        return {key: None for key in values}
    n = len(valid)
    out: dict[tuple[Venue, str], float | None] = {key: None for key in values}
    if n == 1:
        out[valid[0][1]] = 100.0
        return out
    for idx, (_, key) in enumerate(valid):
        out[key] = idx / (n - 1) * 100.0
    return out


class SmartMoneyService:
    """Builds fresh SMART-MONEY shadow frames from current PULSE facts only."""

    def __init__(
        self,
        features: FeatureEngine,
        investor_flow: InvestorFlowService,
        daily_context: DailyContextService,
        discovery: MarketDiscoveryService,
        engine: SmartMoneyEngine,
        *,
        background: BackgroundCoverageService | None = None,
        sectors: SectorBreadthService | None = None,
        business: BusinessContextService | None = None,
        max_rows: int = 200,
    ) -> None:
        self.features = features
        self.investor_flow = investor_flow
        self.daily_context = daily_context
        self.discovery = discovery
        self.engine = engine
        self.background = background
        self.sectors = sectors
        self.business = business
        self.max_rows = max(20, int(max_rows))
        self.frames: dict[tuple[Venue, str], SmartMoneyFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self.expired_pruned = 0
        self._episode_id: dict[tuple[Venue, str], int] = {}
        self._last_evidence_at: dict[tuple[Venue, str], datetime] = {}
        self._feature_signature: dict[tuple[Venue, str], tuple[float | None, ...]] = {}

    async def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[SmartMoneyFrame]:
        now = asof or datetime.now(timezone.utc)
        events = self._latest_unique(self.discovery.recent(max(limit * 4, 100)), limit)
        event_at = {(row.venue, row.symbol): row.observed_at for row in events}
        keys: list[tuple[Venue, str]] = [(row.venue, row.symbol) for row in events]
        background_keys: set[tuple[Venue, str]] = set()
        if self.background is not None:
            background_keys = set(self.background.ready_keys(limit=max(20, limit // 2)))
            for key in background_keys:
                if key not in keys:
                    keys.append(key)
        keys = keys[: max(1, limit)]

        feature_by_key = {key: self.features.frames.get(key) for key in keys}
        feature_by_key = {key: frame for key, frame in feature_by_key.items() if frame is not None}
        rs_pct = _percentiles({key: frame.rs_acceleration for key, frame in feature_by_key.items()})
        money_pct = _percentiles({key: frame.money_acceleration for key, frame in feature_by_key.items()})

        rows: list[SmartMoneyFrame] = []
        for key, feature in feature_by_key.items():
            venue, symbol = key
            evidence_at = self._resolve_evidence_at(
                key, feature, event_at.get(key), key in background_keys
            )
            freshness = evaluate_freshness(evidence_at, now)
            if freshness.expired:
                self._drop(key)
                continue

            daily = await self.daily_context.ensure(symbol)
            recent = {
                period: row
                for period in (1, 3, 5)
                if (row := self.investor_flow.recent.get((symbol, period))) is not None
            }
            intraday = {
                actor: row
                for actor in ("FOREIGN", "INSTITUTION")
                if (row := self.investor_flow.intraday.get((symbol, actor))) is not None
            }
            sector = self.sectors.frame_for(symbol, now) if self.sectors is not None else None
            business = self.business.frame(symbol, now) if self.business is not None else None
            frame = self.engine.evaluate(
                feature,
                daily,
                recent,
                intraday,
                sector=sector,
                business=business,
                rs_accel_percentile=rs_pct.get(key),
                money_accel_percentile=money_pct.get(key),
                asof=now,
            )
            episode_id = self._episode_for(key, evidence_at)
            frame = frame.model_copy(update={
                "evidence_at": evidence_at,
                "evidence_age_sec": round(freshness.age_sec, 3),
                "freshness_score": freshness.score_100,
                "freshness_band": freshness.band,
                "episode_id": episode_id,
            })
            self.frames[key] = frame
            rows.append(frame)

        self._prune(now)
        # Bound only fresh frames; no old name receives a reserved slot.
        if len(self.frames) > self.max_rows:
            ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
            keep = {(row.venue, row.symbol) for row in ranked}
            for key in list(self.frames):
                if key not in keep:
                    self._drop(key)
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def top(self, limit: int = 10, asof: datetime | None = None) -> list[SmartMoneyFrame]:
        now = asof or datetime.now(timezone.utc)
        self._prune(now)
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]


    def _resolve_evidence_at(self, key, feature, event_time: datetime | None, background_active: bool) -> datetime:
        previous = self._last_evidence_at.get(key)
        signature = (
            feature.rs_acceleration, feature.rs_velocity, feature.money_acceleration,
            feature.money_second_derivative, feature.rvol_same_time,
            feature.program_net_buy_amount_delta,
        )
        prior_signature = self._feature_signature.get(key)
        self._feature_signature[key] = signature

        if previous is None:
            return event_time or feature.asof
        if event_time is not None and event_time > previous:
            return event_time
        if background_active:
            # The symbol is in the current fair-rotation observation batch.
            return max(previous, feature.asof)
        if self._meaningful_feature_change(prior_signature, signature):
            return max(previous, feature.asof)
        return previous

    @staticmethod
    def _meaningful_feature_change(previous, current) -> bool:
        if previous is None:
            return False
        prs_a, prs_v, pmoney, pjerk, prvol, pprog = previous
        crs_a, crs_v, cmoney, cjerk, crvol, cprog = current
        if crs_a is not None and ((prs_a is None and crs_a > 0) or (prs_a is not None and crs_a - prs_a >= 0.05)):
            return True
        if crs_v is not None and ((prs_v is None and crs_v > 0) or (prs_v is not None and crs_v - prs_v >= 0.10)):
            return True
        if cmoney is not None and cmoney > 0:
            if pmoney is None or pmoney <= 0:
                return True
            if cmoney >= pmoney * 1.20:
                return True
        if cjerk is not None and cjerk > 0 and (pjerk is None or pjerk <= 0):
            return True
        if crvol is not None and prvol is not None and crvol - prvol >= 0.20:
            return True
        if cprog is not None and cprog > 0 and (pprog is None or pprog <= 0):
            return True
        return False

    def _prune(self, now: datetime) -> None:
        for key, row in list(self.frames.items()):
            evidence_at = row.evidence_at or row.asof
            if evaluate_freshness(evidence_at, now).expired:
                self._drop(key)
                self.expired_pruned += 1

    def _drop(self, key: tuple[Venue, str]) -> None:
        self.frames.pop(key, None)

    def _episode_for(self, key: tuple[Venue, str], evidence_at: datetime) -> int:
        previous = self._last_evidence_at.get(key)
        episode = self._episode_id.get(key, 0)
        if previous is None or (evidence_at - previous).total_seconds() > 1200:
            episode += 1
            self._episode_id[key] = episode
        self._last_evidence_at[key] = evidence_at
        return max(1, episode)

    @staticmethod
    def _sorted(rows: list[SmartMoneyFrame]) -> list[SmartMoneyFrame]:
        rows.sort(
            key=lambda x: (
                x.raw_score_100,
                x.freshness_score,
                x.coverage_pct,
                x.core_score_pct,
                x.observed_score_pct,
            ),
            reverse=True,
        )
        return rows

    @staticmethod
    def _latest_unique(events: Iterable[DiscoveryEvent], limit: int) -> list[DiscoveryEvent]:
        seen: set[tuple[Venue, str]] = set()
        out: list[DiscoveryEvent] = []
        for row in reversed(list(events)):
            key = (row.venue, row.symbol)
            if key in seen:
                continue
            seen.add(key)
            out.append(row)
            if len(out) >= limit:
                break
        return out
