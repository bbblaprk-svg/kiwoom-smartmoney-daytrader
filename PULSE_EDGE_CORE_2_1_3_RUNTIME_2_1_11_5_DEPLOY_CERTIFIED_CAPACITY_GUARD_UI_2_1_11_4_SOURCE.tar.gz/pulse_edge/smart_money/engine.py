from __future__ import annotations

from datetime import datetime, timezone
from math import isfinite

from pulse_edge.context.business import BusinessContextFrame
from pulse_edge.context.daily import DailyContextFrame
from pulse_edge.features.models import FeatureFrame
from pulse_edge.flow.investor import IntradayInvestorFlow, RecentInvestorFlow
from pulse_edge.sector.service import SectorBreadthFrame
from pulse_edge.smart_money.models import PriceRoute, SmartMoneyFrame, SmartMoneyStage


def _clip(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _positive(value: float | None) -> bool:
    return value is not None and isfinite(value) and value > 0


def _price_route(change_rate: float | None) -> PriceRoute:
    if change_rate is None:
        return PriceRoute.PRICE_UNKNOWN
    if change_rate > 4.0:
        return PriceRoute.ROUTE_IGNITION
    if change_rate < -2.0:
        return PriceRoute.DEEP_RED_REVIEW
    return PriceRoute.SMART_PRE_ZONE


class SmartMoneyEngine:
    """SMART-MONEY 100-point shadow evaluator.

    Phase 3B can consume all seven weight groups, but official PREBUY/ENTRY/A+
    remains disabled. Missing evidence reduces covered weight; it is never filled
    by a synthetic neutral or bonus value.
    """

    FULL_WEIGHT = 100.0
    CORE_WEIGHT = 75.0

    def __init__(self, flow_amount_to_daily_value_scale: float = 0.0) -> None:
        self.flow_amount_to_daily_value_scale = max(0.0, float(flow_amount_to_daily_value_scale))

    def evaluate(
        self,
        feature: FeatureFrame,
        daily: DailyContextFrame | None,
        recent: dict[int, RecentInvestorFlow],
        intraday: dict[str, IntradayInvestorFlow],
        *,
        sector: SectorBreadthFrame | None = None,
        business: BusinessContextFrame | None = None,
        rs_accel_percentile: float | None = None,
        money_accel_percentile: float | None = None,
        asof: datetime | None = None,
    ) -> SmartMoneyFrame:
        now = asof or datetime.now(timezone.utc)
        route = _price_route(feature.change_rate)
        flags: list[str] = list(feature.flags)

        flow_score, flow_metrics, flow_weight, flow_flags = self._foreign_score(feature, recent, intraday, daily)
        flags.extend(flow_flags)
        compression_score, compression_weight, compression_flags = self._compression_score(feature, daily)
        flags.extend(compression_flags)
        rs_score, rs_weight, rs_flags = self._rs_score(feature, rs_accel_percentile)
        flags.extend(rs_flags)
        money_score, money_weight, money_flags = self._money_score(feature, money_accel_percentile)
        flags.extend(money_flags)
        confirm_score, confirm_weight, confirm_flags = self._confirmation_score(feature, recent, intraday)
        flags.extend(confirm_flags)

        sector_value = _clip(sector.score_15, 0.0, 15.0) if sector else 0.0
        sector_weight = 15.0 if sector else 0.0
        business_value = _clip(business.score_10, 0.0, 10.0) if business else 0.0
        business_weight = 10.0 if business else 0.0
        if sector is None:
            flags.append("SECTOR_EVIDENCE_MISSING")
        if business is None:
            flags.append("VERIFIED_BUSINESS_CONTEXT_MISSING")

        raw = flow_score + compression_score + rs_score + sector_value + money_score + business_value + confirm_score
        covered = flow_weight + compression_weight + rs_weight + sector_weight + money_weight + business_weight + confirm_weight
        coverage_pct = covered / self.FULL_WEIGHT * 100.0
        observed = raw / covered * 100.0 if covered > 0 else 0.0
        core = flow_score + compression_score + rs_score + money_score + confirm_score
        core_pct = core / self.CORE_WEIGHT * 100.0

        # Phase 3B stage is still shadow-only. Full 100-point evidence increases
        # ranking confidence but cannot emit an official trading action.
        if route == PriceRoute.ROUTE_IGNITION:
            stage = SmartMoneyStage.ROUTE_IGNITION
        elif covered < 50.0 or flow_weight < 12.0 or compression_weight < 10.0 or rs_weight < 5.0:
            stage = SmartMoneyStage.DATA_WAIT
        elif raw >= 78.0 and coverage_pct >= 80.0 and core_pct >= 72.0:
            stage = SmartMoneyStage.PRE_SHADOW
        elif core_pct >= 65.0 or observed >= 68.0:
            stage = SmartMoneyStage.WATCH
        else:
            stage = SmartMoneyStage.SCOUT

        if route == PriceRoute.DEEP_RED_REVIEW and stage == SmartMoneyStage.PRE_SHADOW:
            stage = SmartMoneyStage.WATCH
            flags.append("DEEP_RED_PRE_DOWNGRADED")
        if "TURNOVER_ABSORPTION_UNIT_NOT_VERIFIED" in flags and stage == SmartMoneyStage.PRE_SHADOW:
            stage = SmartMoneyStage.WATCH
            flags.append("PRE_SHADOW_BLOCKED_UNVERIFIED_AMOUNT_SCALE")

        return SmartMoneyFrame(
            venue=feature.venue,
            symbol=feature.symbol,
            asof=now,
            price=feature.price,
            change_rate=feature.change_rate,
            price_route=route,
            stage=stage,
            foreign_absorption_score=round(flow_score, 4),
            compression_score=round(compression_score, 4),
            rs_score=round(rs_score, 4),
            sector_score=round(sector_value, 4),
            money_acceleration_score=round(money_score, 4),
            business_context_score=round(business_value, 4),
            confirmation_score=round(confirm_score, 4),
            raw_score_100=round(raw, 4),
            covered_weight=round(covered, 4),
            coverage_pct=round(coverage_pct, 4),
            observed_score_pct=round(observed, 4),
            core_score_75=round(core, 4),
            core_score_pct=round(core_pct, 4),
            foreign_1d=flow_metrics.get("foreign_1d"),
            foreign_3d=flow_metrics.get("foreign_3d"),
            foreign_5d=flow_metrics.get("foreign_5d"),
            institution_5d=flow_metrics.get("institution_5d"),
            foreign_streak_days=flow_metrics.get("foreign_streak_days"),
            seller_absorption_ratio=flow_metrics.get("seller_absorption_ratio"),
            turnover_absorption_pct=flow_metrics.get("turnover_absorption_pct"),
            intraday_foreign_net=flow_metrics.get("intraday_foreign_net"),
            intraday_institution_net=flow_metrics.get("intraday_institution_net"),
            foreign_flow_velocity=flow_metrics.get("foreign_flow_velocity"),
            foreign_flow_acceleration=flow_metrics.get("foreign_flow_acceleration"),
            foreign_flow_reversal=bool(flow_metrics.get("foreign_flow_reversal")) if flow_metrics.get("foreign_flow_reversal") is not None else None,
            flow_price_divergence_score=float(flow_metrics.get("flow_price_divergence_score") or 0.0),
            return_5d_pct=daily.return_5d_pct if daily else None,
            atr_compression_ratio=daily.atr_compression_ratio if daily else None,
            range_compression_ratio=daily.range_compression_ratio if daily else None,
            volume_ratio=daily.volume_ratio if daily else None,
            rising_lows=daily.rising_lows if daily else None,
            rs_level=feature.rs_level,
            rs_velocity=feature.rs_velocity,
            rs_acceleration=feature.rs_acceleration,
            rs_zero_cross=feature.rs_zero_cross,
            rvol_same_time=feature.rvol_same_time,
            money_acceleration=feature.money_acceleration,
            money_second_derivative=feature.money_second_derivative,
            vwap_distance_pct=feature.vwap_distance_pct,
            program_net_buy_amount_delta=feature.program_net_buy_amount_delta,
            rs_accel_percentile=rs_accel_percentile,
            money_accel_percentile=money_accel_percentile,
            sector_name=sector.sector_name if sector else None,
            sector_breadth_ratio=sector.breadth_ratio if sector else None,
            sector_breadth_velocity=sector.breadth_velocity_ppm if sector else None,
            sector_breadth_acceleration=sector.breadth_acceleration_ppm2 if sector else None,
            business_evidence_count=business.evidence_count if business else 0,
            official_signal_enabled=False,
            flags=sorted(set(flags)),
        )

    def _foreign_score(
        self,
        feature: FeatureFrame,
        recent: dict[int, RecentInvestorFlow],
        intraday: dict[str, IntradayInvestorFlow],
        daily: DailyContextFrame | None,
    ) -> tuple[float, dict[str, float | bool | None], float, list[str]]:
        score = 0.0
        weight = 0.0
        flags: list[str] = []
        r1, r3, r5 = recent.get(1), recent.get(3), recent.get(5)
        f1 = r1.foreign_net_amount if r1 else None
        f3 = r3.foreign_net_amount if r3 else None
        f5 = r5.foreign_net_amount if r5 else None
        i5 = r5.institution_net_amount if r5 else None
        streak = r5.foreign_streak_days if r5 else None
        intraday_foreign = intraday.get("FOREIGN")
        intraday_institution = intraday.get("INSTITUTION")

        turnover_ratio = None
        if (
            self.flow_amount_to_daily_value_scale > 0
            and f5 is not None
            and daily is not None
            and daily.traded_value_5d_raw is not None
            and daily.traded_value_5d_raw > 0
        ):
            turnover_ratio = f5 * self.flow_amount_to_daily_value_scale / daily.traded_value_5d_raw * 100.0
            weight += 7.0
            if turnover_ratio >= 1.2: score += 7.0
            elif turnover_ratio >= 0.7: score += 5.5
            elif turnover_ratio >= 0.3: score += 3.5
            elif turnover_ratio >= 0.1: score += 1.5
        else:
            flags.append("TURNOVER_ABSORPTION_UNIT_NOT_VERIFIED")

        if streak is not None:
            weight += 3.0
            if streak >= 3: score += 3.0
            elif streak >= 2: score += 2.0
            elif streak >= 1: score += 0.75

        flow_velocity = None
        flow_acceleration = None
        flow_reversal = None
        if f1 is not None and f3 is not None and f5 is not None:
            weight += 7.0
            avg1 = f1
            avg3 = f3 / 3.0
            avg5 = f5 / 5.0
            scale = max(abs(avg5), abs(avg3), 1.0)
            flow_velocity = (avg1 - avg3) / scale
            flow_acceleration = ((avg1 - avg3) - (avg3 - avg5)) / scale
            flow_reversal = bool(f5 <= 0 < f3 and f1 > 0)
            if flow_reversal:
                score += 7.0
            elif avg1 > avg3 > avg5 and flow_acceleration > 0:
                score += 6.0
            elif avg1 > avg3 and flow_velocity > 0:
                score += 4.5
            elif avg3 > avg5 and avg3 > 0:
                score += 2.5
            elif avg1 > 0:
                score += 1.0
        else:
            flags.append("FLOW_ACCELERATION_FACTS_INCOMPLETE")

        seller_ratio = None
        if f5 is not None and i5 is not None:
            weight += 3.0
            if i5 < 0 and f5 > 0:
                seller_ratio = f5 / abs(i5) if i5 != 0 else None
                if seller_ratio is not None:
                    if seller_ratio >= 1.0: score += 3.0
                    elif seller_ratio >= 0.5: score += 2.0
                    elif seller_ratio > 0: score += 0.75
            elif f5 > 0 and i5 >= 0:
                score += 1.0

        divergence = 0.0
        accel_positive = flow_acceleration is not None and flow_acceleration > 0
        intraday_positive = intraday_foreign is not None and intraday_foreign.net_value is not None and intraday_foreign.net_value > 0
        program_positive = (feature.program_net_buy_amount_delta or 0) > 0 or (feature.program_net_buy_qty_delta or 0) > 0
        if feature.change_rate is not None and (accel_positive or intraday_positive):
            weight += 5.0
            underreaction = -1.5 <= feature.change_rate <= 2.5
            rs_support = feature.rs_velocity is None or feature.rs_velocity >= 0
            if underreaction and rs_support:
                divergence += 3.0
                if program_positive:
                    divergence += 1.0
                if i5 is not None and i5 < 0 and (f5 or 0) > 0:
                    divergence += 1.0
            elif 2.5 < feature.change_rate <= 4.0 and rs_support:
                divergence += 1.5
            score += min(divergence, 5.0)

        if f1 is None and f3 is None and f5 is None:
            flags.append("FOREIGN_RECENT_FACTS_MISSING")
        if intraday_foreign is None:
            flags.append("INTRADAY_FOREIGN_FACT_MISSING")

        return score, {
            "foreign_1d": f1,
            "foreign_3d": f3,
            "foreign_5d": f5,
            "institution_5d": i5,
            "foreign_streak_days": streak,
            "seller_absorption_ratio": seller_ratio,
            "turnover_absorption_pct": turnover_ratio,
            "intraday_foreign_net": intraday_foreign.net_value if intraday_foreign else None,
            "intraday_institution_net": intraday_institution.net_value if intraday_institution else None,
            "foreign_flow_velocity": flow_velocity,
            "foreign_flow_acceleration": flow_acceleration,
            "foreign_flow_reversal": flow_reversal,
            "flow_price_divergence_score": divergence,
        }, weight, flags

    def _compression_score(self, feature: FeatureFrame, daily: DailyContextFrame | None) -> tuple[float, float, list[str]]:
        if daily is None:
            return 0.0, 0.0, ["DAILY_CONTEXT_MISSING"]
        score = 0.0
        weight = 0.0
        flags: list[str] = list(daily.flags)
        if feature.change_rate is not None:
            weight += 5.0
            if -2.0 <= feature.change_rate <= 4.0: score += 5.0
            elif -4.0 <= feature.change_rate < -2.0: score += 1.0
        if daily.return_5d_pct is not None:
            weight += 5.0
            r = daily.return_5d_pct
            if -5.0 <= r <= 4.0: score += 5.0
            elif 4.0 < r <= 7.0: score += 3.0
            elif 7.0 < r <= 12.0: score += 1.0
            elif -8.0 <= r < -5.0: score += 1.0
        if daily.atr_compression_ratio is not None:
            weight += 4.0
            if daily.atr_compression_ratio <= 0.75: score += 4.0
            elif daily.atr_compression_ratio <= 0.90: score += 3.0
            elif daily.atr_compression_ratio <= 1.00: score += 1.5
        if daily.range_compression_ratio is not None:
            weight += 3.0
            if daily.range_compression_ratio <= 0.75: score += 3.0
            elif daily.range_compression_ratio <= 0.90: score += 2.0
            elif daily.range_compression_ratio <= 1.00: score += 1.0
        if daily.rising_lows is not None:
            weight += 2.0
            if daily.rising_lows: score += 2.0
        if daily.volume_ratio is not None:
            weight += 1.0
            if daily.volume_ratio <= 1.05: score += 1.0
            elif daily.volume_ratio <= 1.20: score += 0.5
        return score, weight, flags

    def _rs_score(self, feature: FeatureFrame, percentile: float | None) -> tuple[float, float, list[str]]:
        score = 0.0
        weight = 0.0
        flags: list[str] = []
        if feature.rs_acceleration is not None:
            weight += 6.0
            if percentile is not None:
                if percentile >= 90: score += 6.0
                elif percentile >= 75: score += 5.0
                elif percentile >= 60: score += 3.5
                elif feature.rs_acceleration > 0: score += 2.0
            elif feature.rs_acceleration >= 0.15: score += 6.0
            elif feature.rs_acceleration > 0: score += 4.0
        else:
            flags.append("RS_ACCELERATION_MISSING")
        if feature.rs_velocity is not None:
            weight += 4.0
            if feature.rs_velocity >= 0.30: score += 4.0
            elif feature.rs_velocity > 0: score += 2.0
        if feature.rs_zero_cross is not None:
            weight += 3.0
            if feature.rs_zero_cross: score += 3.0
        if feature.rs_level is not None:
            weight += 2.0
            if -1.5 <= feature.rs_level <= 3.0 and _positive(feature.rs_velocity): score += 2.0
            elif feature.rs_level > 0: score += 1.0
        return score, weight, flags

    def _money_score(self, feature: FeatureFrame, percentile: float | None) -> tuple[float, float, list[str]]:
        score = 0.0
        weight = 0.0
        flags: list[str] = []
        if feature.money_acceleration is not None:
            weight += 3.0
            if percentile is not None:
                if percentile >= 90: score += 3.0
                elif percentile >= 75: score += 2.5
                elif percentile >= 60: score += 1.5
                elif feature.money_acceleration > 0: score += 0.75
            elif feature.money_acceleration > 0:
                score += 1.5
        if feature.money_second_derivative is not None:
            weight += 3.0
            if feature.money_second_derivative > 0: score += 3.0
        if feature.rvol_same_time is not None:
            weight += 3.0
            if feature.rvol_same_time >= 1.8: score += 3.0
            elif feature.rvol_same_time >= 1.3: score += 2.0
            elif feature.rvol_same_time >= 1.1: score += 1.0
        else:
            flags.append("MONEY_SAME_TIME_BASELINE_MISSING")
        if feature.vwap_distance_pct is not None:
            weight += 1.0
            if 0.0 <= feature.vwap_distance_pct <= 3.0: score += 1.0
        return score, weight, flags

    def _confirmation_score(
        self,
        feature: FeatureFrame,
        recent: dict[int, RecentInvestorFlow],
        intraday: dict[str, IntradayInvestorFlow],
    ) -> tuple[float, float, list[str]]:
        score = 0.0
        weight = 0.0
        flags: list[str] = []
        r5 = recent.get(5)
        if r5 is not None and r5.institution_net_amount is not None:
            weight += 1.5
            if r5.institution_net_amount > 0: score += 1.5
        inst = intraday.get("INSTITUTION")
        if inst is not None and inst.net_value is not None:
            weight += 1.0
            if inst.net_value > 0: score += 1.0
        if feature.program_net_buy_amount_delta is not None:
            weight += 1.5
            if feature.program_net_buy_amount_delta > 0: score += 1.5
        if feature.program_net_buy_qty_delta is not None:
            weight += 1.0
            if feature.program_net_buy_qty_delta > 0: score += 1.0
        if weight == 0:
            flags.append("CONFIRMATION_FACTS_MISSING")
        return score, weight, flags
