from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class PullbackStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    NO_PATTERN = "NO_PATTERN"
    FIRST_WAVE_WATCH = "FIRST_WAVE_WATCH"
    PULLBACK_FORMING_SHADOW = "PULLBACK_FORMING_SHADOW"
    REACCEL_WATCH = "REACCEL_WATCH"
    SECOND_WAVE_SHADOW = "SECOND_WAVE_SHADOW"
    OVEREXTENDED_RISK_SHADOW = "OVEREXTENDED_RISK_SHADOW"


class PullbackFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    stage: PullbackStage
    price: float | None = None
    change_rate: float | None = None

    base_price: float | None = None
    peak_price: float | None = None
    trough_price: float | None = None
    first_wave_pct: float | None = None
    retracement_pct: float | None = None
    pullback_volume_contraction_pct: float | None = None
    recovery_from_trough_pct_of_pullback: float | None = None
    peak_age_sec: float | None = None
    trough_age_sec: float | None = None

    second_wave_score_100: float = 0.0
    wave_quality_score_20: float = 0.0
    retracement_score_20: float = 0.0
    volume_contraction_score_15: float = 0.0
    support_vwap_score_15: float = 0.0
    reacceleration_score_20: float = 0.0
    flow_rs_confirmation_score_10: float = 0.0

    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
