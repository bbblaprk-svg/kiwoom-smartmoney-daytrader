from __future__ import annotations

from datetime import datetime, timezone

from pulse_edge.features.models import FeatureFrame, TradePoint
from pulse_edge.pullback.models import PullbackFrame, PullbackStage
from pulse_edge.smart_money.models import SmartMoneyFrame


def _clip(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


class PullbackSecondWaveEngine:
    """Current-session, shadow-only pullback/reacceleration detector.

    Contract: first wave 3-8%, 25-50% retracement, >=30% pullback volume-rate
    contraction, support/VWAP hold, then renewed price/flow/RS acceleration.
    """

    def evaluate(
        self,
        feature: FeatureFrame,
        smart: SmartMoneyFrame | None,
        points: list[TradePoint],
        asof: datetime | None = None,
    ) -> PullbackFrame:
        now = asof or datetime.now(timezone.utc)
        flags: list[str] = []
        points = sorted([p for p in points if p.price > 0], key=lambda p: p.ts)
        if feature.price is None or len(points) < 8 or feature.coverage_sec < 300:
            return self._empty(feature, now, PullbackStage.DATA_WAIT, ["PULLBACK_HISTORY_WARMUP"])

        shape = self._shape(points)
        if shape is None:
            return self._empty(feature, now, PullbackStage.NO_PATTERN, ["FIRST_WAVE_NOT_FOUND"])
        base_i, peak_i, trough_i, wave_pct = shape
        base, peak, trough = points[base_i], points[peak_i], points[trough_i]
        amplitude = peak.price - base.price
        retrace = ((peak.price - trough.price) / amplitude * 100.0) if amplitude > 0 else None
        pullback_drop = peak.price - trough.price
        recovery = ((feature.price - trough.price) / pullback_drop * 100.0) if pullback_drop > 0 else None
        contraction = self._volume_contraction(points, base_i, peak_i, trough_i)

        wave_score = self._wave_score(wave_pct)
        retrace_score = self._retrace_score(retrace)
        volume_score = self._volume_score(contraction, flags)
        support_score = self._support_score(feature, trough.price, base.price, flags)
        reaccel_score = self._reaccel_score(feature, recovery, peak.price, flags)
        flow_score = self._flow_rs_score(feature, smart, flags)
        score = _clip(wave_score + retrace_score + volume_score + support_score + reaccel_score + flow_score)

        shape_ok = 3.0 <= wave_pct <= 8.0
        retrace_ok = retrace is not None and 25.0 <= retrace <= 50.0
        volume_ok = contraction is not None and contraction >= 30.0
        support_ok = self._support_ok(feature, trough.price, base.price)
        reaccel_ok = self._reaccel_ok(feature, recovery)
        overextended = feature.vwap_distance_pct is not None and feature.vwap_distance_pct > 4.0

        if overextended or (feature.change_rate is not None and feature.change_rate > 12.0):
            stage = PullbackStage.OVEREXTENDED_RISK_SHADOW
        elif shape_ok and retrace_ok and volume_ok and support_ok and reaccel_ok and score >= 74:
            stage = PullbackStage.SECOND_WAVE_SHADOW
        elif shape_ok and retrace_ok and support_ok and reaccel_ok:
            stage = PullbackStage.REACCEL_WATCH
        elif shape_ok and retrace is not None and 15.0 <= retrace <= 60.0:
            stage = PullbackStage.PULLBACK_FORMING_SHADOW
        elif shape_ok:
            stage = PullbackStage.FIRST_WAVE_WATCH
        else:
            stage = PullbackStage.NO_PATTERN

        return PullbackFrame(
            venue=feature.venue,
            symbol=feature.symbol,
            asof=now,
            stage=stage,
            price=feature.price,
            change_rate=feature.change_rate,
            base_price=round(base.price, 6),
            peak_price=round(peak.price, 6),
            trough_price=round(trough.price, 6),
            first_wave_pct=round(wave_pct, 4),
            retracement_pct=round(retrace, 4) if retrace is not None else None,
            pullback_volume_contraction_pct=round(contraction, 4) if contraction is not None else None,
            recovery_from_trough_pct_of_pullback=round(recovery, 4) if recovery is not None else None,
            peak_age_sec=max(0.0, round((now - peak.ts).total_seconds(), 3)),
            trough_age_sec=max(0.0, round((now - trough.ts).total_seconds(), 3)),
            second_wave_score_100=round(score, 4),
            wave_quality_score_20=round(wave_score, 4),
            retracement_score_20=round(retrace_score, 4),
            volume_contraction_score_15=round(volume_score, 4),
            support_vwap_score_15=round(support_score, 4),
            reacceleration_score_20=round(reaccel_score, 4),
            flow_rs_confirmation_score_10=round(flow_score, 4),
            official_signal_enabled=False,
            flags=list(dict.fromkeys(flags)),
        )

    @staticmethod
    def _shape(points: list[TradePoint]) -> tuple[int, int, int, float] | None:
        running_min_i = 0
        best: tuple[int, int, float] | None = None
        for i in range(1, len(points)):
            if points[i - 1].price < points[running_min_i].price:
                running_min_i = i - 1
            base = points[running_min_i].price
            rise = (points[i].price / base - 1.0) * 100.0 if base > 0 else 0.0
            if best is None or rise > best[2]:
                best = (running_min_i, i, rise)
        if best is None or best[2] < 2.0 or best[1] >= len(points) - 2:
            return None
        base_i, peak_i, wave = best
        trough_i = min(range(peak_i + 1, len(points)), key=lambda i: points[i].price)
        if trough_i <= peak_i:
            return None
        return base_i, peak_i, trough_i, wave

    @staticmethod
    def _volume_contraction(points, base_i, peak_i, trough_i) -> float | None:
        impulse = points[base_i: peak_i + 1]
        pullback = points[peak_i + 1: trough_i + 1]
        if len(impulse) < 2 or len(pullback) < 2:
            return None
        imp_sec = max((impulse[-1].ts - impulse[0].ts).total_seconds(), 1.0)
        pb_sec = max((pullback[-1].ts - pullback[0].ts).total_seconds(), 1.0)
        imp_rate = sum(max(0.0, p.volume) for p in impulse) / imp_sec
        pb_rate = sum(max(0.0, p.volume) for p in pullback) / pb_sec
        if imp_rate <= 0:
            return None
        return (1.0 - pb_rate / imp_rate) * 100.0

    @staticmethod
    def _wave_score(wave: float) -> float:
        if 3.0 <= wave <= 8.0: return 20.0
        if 2.0 <= wave < 3.0 or 8.0 < wave <= 10.0: return 10.0
        return 0.0

    @staticmethod
    def _retrace_score(retrace: float | None) -> float:
        if retrace is None: return 0.0
        if 25.0 <= retrace <= 50.0: return 20.0
        if 15.0 <= retrace < 25.0 or 50.0 < retrace <= 60.0: return 10.0
        return 0.0

    @staticmethod
    def _volume_score(contraction: float | None, flags: list[str]) -> float:
        if contraction is None:
            flags.append("PULLBACK_VOLUME_CONTRACTION_MISSING")
            return 0.0
        if contraction >= 45: return 15.0
        if contraction >= 30: return 12.0
        if contraction >= 15: return 5.0
        return 0.0

    @staticmethod
    def _support_ok(feature: FeatureFrame, trough: float, base: float) -> bool:
        if trough < base: return False
        if feature.session_vwap is not None and trough < feature.session_vwap * 0.995: return False
        return True

    def _support_score(self, feature, trough, base, flags) -> float:
        score = 0.0
        if trough >= base: score += 5.0
        else: flags.append("FIRST_WAVE_BASE_BROKEN")
        if feature.session_vwap is None:
            flags.append("SESSION_VWAP_MISSING")
        elif trough >= feature.session_vwap * 0.995:
            score += 7.0
        if feature.vwap_distance_pct is not None and -0.5 <= feature.vwap_distance_pct <= 2.0:
            score += 3.0
        return min(score, 15.0)

    @staticmethod
    def _reaccel_ok(feature: FeatureFrame, recovery: float | None) -> bool:
        return bool(
            recovery is not None and recovery >= 20.0
            and (feature.return_1m_pct or 0) > 0
            and (feature.money_acceleration or 0) > 0
        )

    @staticmethod
    def _reaccel_score(feature, recovery, peak, flags) -> float:
        score = 0.0
        if recovery is not None:
            if recovery >= 50: score += 7
            elif recovery >= 20: score += 5
        if (feature.return_1m_pct or 0) > 0: score += 4
        else: flags.append("REACCEL_1M_RETURN_NONPOSITIVE")
        if (feature.money_acceleration or 0) > 0: score += 5
        else: flags.append("REACCEL_MONEY_NONPOSITIVE")
        if (feature.money_second_derivative or 0) > 0: score += 2
        if feature.price is not None and peak > 0 and feature.price >= peak * 0.985: score += 2
        return min(score, 20.0)

    @staticmethod
    def _flow_rs_score(feature, smart, flags) -> float:
        score = 0.0
        if (feature.rs_acceleration or 0) > 0: score += 4
        else: flags.append("SECOND_WAVE_RS_ACCEL_NONPOSITIVE")
        if smart is not None and (smart.foreign_flow_acceleration or 0) > 0: score += 3
        if feature.program_net_buy_amount_delta is not None and feature.program_net_buy_amount_delta > 0: score += 2
        if smart is not None and smart.sector_score > 0: score += 1
        return min(score, 10.0)

    @staticmethod
    def _empty(feature: FeatureFrame, now: datetime, stage: PullbackStage, flags: list[str]) -> PullbackFrame:
        return PullbackFrame(
            venue=feature.venue, symbol=feature.symbol, asof=now, stage=stage,
            price=feature.price, change_rate=feature.change_rate,
            official_signal_enabled=False, flags=flags,
        )
