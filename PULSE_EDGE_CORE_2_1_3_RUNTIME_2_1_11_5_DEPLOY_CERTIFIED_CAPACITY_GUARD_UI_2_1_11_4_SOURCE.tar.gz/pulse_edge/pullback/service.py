from __future__ import annotations

from datetime import datetime, timedelta, timezone

from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.pullback.engine import PullbackSecondWaveEngine
from pulse_edge.pullback.models import PullbackFrame, PullbackStage
from pulse_edge.smart_money.service import SmartMoneyService


class PullbackSecondWaveService:
    def __init__(self, features: FeatureEngine, smart_money: SmartMoneyService, engine: PullbackSecondWaveEngine, max_rows: int = 100) -> None:
        self.features = features
        self.smart_money = smart_money
        self.engine = engine
        self.max_rows = max(10, int(max_rows))
        self.frames: dict[tuple[Venue, str], PullbackFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[PullbackFrame]:
        now = asof or datetime.now(timezone.utc)
        source = self.smart_money.top(max(20, min(int(limit), 200)), now)
        rows: list[PullbackFrame] = []
        keep: set[tuple[Venue, str]] = set()
        cutoff = now - timedelta(minutes=30)
        for smart in source:
            key = (smart.venue, smart.symbol)
            feature = self.features.frames.get(key)
            if feature is None:
                self.frames.pop(key, None)
                continue
            points = [p for p in self.features.trades.get(key, []) if p.ts >= cutoff]
            frame = self.engine.evaluate(feature, smart, points, now)
            if frame.stage == PullbackStage.DATA_WAIT:
                self.frames.pop(key, None)
                continue
            self.frames[key] = frame
            keep.add(key)
            rows.append(frame)

        for key in list(self.frames):
            if key not in keep:
                self.frames.pop(key, None)
        ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
        self.frames = {(r.venue, r.symbol): r for r in ranked}
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def top(self, limit: int = 10) -> list[PullbackFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]

    @staticmethod
    def _sorted(rows: list[PullbackFrame]) -> list[PullbackFrame]:
        order = {
            PullbackStage.SECOND_WAVE_SHADOW: 6,
            PullbackStage.REACCEL_WATCH: 5,
            PullbackStage.PULLBACK_FORMING_SHADOW: 4,
            PullbackStage.FIRST_WAVE_WATCH: 3,
            PullbackStage.NO_PATTERN: 2,
            PullbackStage.OVEREXTENDED_RISK_SHADOW: 1,
            PullbackStage.DATA_WAIT: 0,
        }
        rows.sort(key=lambda x: (order.get(x.stage, 0), x.second_wave_score_100), reverse=True)
        return rows
