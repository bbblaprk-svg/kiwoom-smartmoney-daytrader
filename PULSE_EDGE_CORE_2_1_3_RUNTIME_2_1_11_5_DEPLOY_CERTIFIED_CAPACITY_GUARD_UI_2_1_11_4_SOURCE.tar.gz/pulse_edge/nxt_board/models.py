from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class NxtBoardKind(StrEnum):
    EARLY_FLOW = "NXT_EARLY_FLOW"
    EARLY_BUY = "NXT_EARLY_BUY"
    CLOSE_BET = "NXT_CLOSE_BET"


class NxtBoardPhaseState(StrEnum):
    WAITING = "WAITING"
    ACTIVE = "ACTIVE"
    CLOSED = "CLOSED"


class NxtBoardRow(BaseModel):
    rank: int
    symbol: str
    stage: str
    score_100: float
    nxt_price: float | None = None
    change_rate: float | None = None
    nxt_premium_pct: float | None = None
    spread_pct: float | None = None
    aggressive_buy_ratio_30s: float | None = None
    ofi_2m: float | None = None
    money_5m: float | None = None
    money_acceleration: float | None = None
    vwap_distance_pct: float | None = None
    persistence_count: int = 0
    strict_close_window: bool = False
    price_trust: str = "UNAVAILABLE"
    quote_trust: str = "UNAVAILABLE"
    flow_trust: str = "ESTIMATED"
    investor_flow_trust: str = "UNAVAILABLE"
    member_since: datetime
    membership_age_sec: float = 0.0
    membership_committed: bool = False
    source_asof: datetime
    flags: list[str] = Field(default_factory=list)


class NxtBoardView(BaseModel):
    kind: NxtBoardKind
    phase_state: NxtBoardPhaseState
    window_kst: str
    fixed_rows: int = 10
    membership_commit_sec: float = 30.0
    qualification_dwell_sec: float = 12.0
    overtake_min_score_gap: float = 5.0
    items: list[NxtBoardRow] = Field(default_factory=list)
