from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from pulse_edge.nxt_native.models import NxtNativeFrame, NxtNativePhase, NxtNativeStage
from pulse_edge.nxt_native.service import NxtNativeService
from pulse_edge.nxt_board.models import NxtBoardKind, NxtBoardPhaseState, NxtBoardRow, NxtBoardView

KST = ZoneInfo("Asia/Seoul")


@dataclass
class _Member:
    symbol: str
    joined_at: datetime
    last_frame: NxtNativeFrame
    miss_since: datetime | None = None


class NxtFixedOperationsBoardService:
    """Display-only NXT operations board with stable membership.

    Reads Phase 6E NXT-native frames only. It does not call a broker, create a
    trading score, or feed any current ranking module. Three fixed 10-row boards
    are exposed for EARLY FLOW, EARLY-BUY and CLOSE-BET. Only the currently
    active phase contains current rows; other boards remain fixed placeholders.
    """

    TARGET = {
        NxtBoardKind.EARLY_FLOW: NxtNativeStage.NXT_EARLY_FLOW,
        NxtBoardKind.EARLY_BUY: NxtNativeStage.NXT_EARLY_BUY,
        NxtBoardKind.CLOSE_BET: NxtNativeStage.NXT_CLOSE_BET,
    }
    PHASE_KIND = {
        NxtNativePhase.EARLY_FLOW: NxtBoardKind.EARLY_FLOW,
        NxtNativePhase.EARLY_BUY: NxtBoardKind.EARLY_BUY,
        NxtNativePhase.CLOSE_BET: NxtBoardKind.CLOSE_BET,
    }
    WINDOW = {
        NxtBoardKind.EARLY_FLOW: "15:40-18:30",
        NxtBoardKind.EARLY_BUY: "18:30-19:30",
        NxtBoardKind.CLOSE_BET: "19:30-19:55",
    }
    ORDER = {
        NxtNativeStage.NXT_EARLY_FLOW: 1,
        NxtNativeStage.NXT_EARLY_BUY: 2,
        NxtNativeStage.NXT_CLOSE_BET: 3,
    }
    HARD_RISK = {
        NxtNativeStage.DATA_WAIT,
        NxtNativeStage.NXT_STALE,
        NxtNativeStage.NXT_WIDE_SPREAD,
        NxtNativeStage.NXT_LOW_LIQUIDITY,
        NxtNativeStage.NXT_OVERHEATED,
    }

    def __init__(
        self,
        *,
        source: NxtNativeService,
        fixed_rows: int = 10,
        qualification_dwell_sec: float = 12.0,
        membership_commit_sec: float = 30.0,
        missing_grace_sec: float = 15.0,
        overtake_min_score_gap: float = 5.0,
        overtake_required_checks: int = 2,
        overtake_max_wait_sec: float = 20.0,
    ) -> None:
        self.source = source
        self.fixed_rows = 10
        self.qualification_dwell_sec = max(0.0, float(qualification_dwell_sec))
        self.membership_commit_sec = max(0.0, float(membership_commit_sec))
        self.missing_grace_sec = max(0.0, float(missing_grace_sec))
        self.overtake_min_score_gap = max(0.0, float(overtake_min_score_gap))
        self.overtake_required_checks = max(1, int(overtake_required_checks))
        self.overtake_max_wait_sec = max(1.0, float(overtake_max_wait_sec))
        self._members: dict[NxtBoardKind, list[_Member]] = {k: [] for k in NxtBoardKind}
        self._qualification_since: dict[tuple[NxtBoardKind, str], datetime] = {}
        self._overtake: dict[tuple[NxtBoardKind, str, str], tuple[int, datetime]] = {}
        self._highest_stage: dict[str, int] = {}
        self._day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, asof: datetime | None = None) -> dict[str, NxtBoardView]:
        now = asof or datetime.now(timezone.utc)
        day = now.astimezone(KST).date().isoformat()
        if self._day != day:
            self._day = day
            self._members = {k: [] for k in NxtBoardKind}
            self._qualification_since.clear()
            self._overtake.clear()
            self._highest_stage.clear()

        phase = self.source.engine.phase_at(now)
        active_kind = self.PHASE_KIND.get(phase)
        for kind in NxtBoardKind:
            if kind != active_kind:
                self._members[kind].clear()
                self._clear_kind_tracking(kind)
        if active_kind is not None:
            self._update_active(active_kind, now)

        self.last_refresh_at = now
        self.last_error = None
        return self.views(now)

    def views(self, asof: datetime | None = None) -> dict[str, NxtBoardView]:
        now = asof or self.last_refresh_at or datetime.now(timezone.utc)
        phase = self.source.engine.phase_at(now)
        active_kind = self.PHASE_KIND.get(phase)
        return {kind.value: self._view(kind, active_kind, now) for kind in NxtBoardKind}

    def _view(self, kind: NxtBoardKind, active_kind: NxtBoardKind | None, now: datetime) -> NxtBoardView:
        state = self._phase_state(kind, active_kind, now)
        rows: list[NxtBoardRow] = []
        if state == NxtBoardPhaseState.ACTIVE:
            for rank, member in enumerate(self._members[kind][: self.fixed_rows], start=1):
                current = self.source.frames.get(member.symbol)
                in_grace = current is None or current.stage != self.TARGET[kind]
                frame = member.last_frame if in_grace else current
                age = max(0.0, (now - member.joined_at).total_seconds())
                rows.append(self._row(rank, frame, member, age, self.membership_commit_sec, in_grace))
        return NxtBoardView(
            kind=kind,
            phase_state=state,
            window_kst=self.WINDOW[kind],
            fixed_rows=self.fixed_rows,
            membership_commit_sec=self.membership_commit_sec,
            qualification_dwell_sec=self.qualification_dwell_sec,
            overtake_min_score_gap=self.overtake_min_score_gap,
            items=rows,
        )

    def _update_active(self, kind: NxtBoardKind, now: datetime) -> None:
        target = self.TARGET[kind]
        current = self.source.frames
        members = self._members[kind]

        # Hard-risk states exit immediately. A simple loss of qualification gets
        # a short grace period so a single calculation does not make rows flicker.
        kept: list[_Member] = []
        for member in members:
            frame = current.get(member.symbol)
            if frame is not None and frame.stage in self.HARD_RISK:
                self._drop_tracking(kind, member.symbol)
                continue
            if frame is None or frame.stage != target:
                member.miss_since = member.miss_since or now
                if (now - member.miss_since).total_seconds() >= self.missing_grace_sec:
                    self._drop_tracking(kind, member.symbol)
                    continue
            else:
                member.miss_since = None
                member.last_frame = frame
            kept.append(member)
        self._members[kind] = members = kept

        members_set = {m.symbol for m in members}
        eligible = [f for f in current.values() if f.stage == target]
        eligible.sort(key=lambda f: (f.score_100, f.persistence_count), reverse=True)

        # Record highest stage seen for same-session immediate stage escalation.
        prior_stage = dict(self._highest_stage)
        for frame in eligible:
            self._highest_stage[frame.symbol] = max(self._highest_stage.get(frame.symbol, 0), self.ORDER[target])

        for frame in eligible:
            if frame.symbol in members_set:
                continue
            key = (kind, frame.symbol)
            first = self._qualification_since.setdefault(key, now)
            stage_escalation = prior_stage.get(frame.symbol, 0) > 0 and self.ORDER[target] > prior_stage.get(frame.symbol, 0)
            dwell = (now - first).total_seconds()
            if not stage_escalation and dwell < self.qualification_dwell_sec:
                continue
            if len(members) < self.fixed_rows:
                members.append(_Member(symbol=frame.symbol, joined_at=now, last_frame=frame))
                members_set.add(frame.symbol)
                self._qualification_since.pop(key, None)
                continue

            replaceable = [m for m in members if m.miss_since is None]
            if not replaceable:
                continue
            weakest = min(replaceable, key=lambda m: self._score(current.get(m.symbol) or m.last_frame))
            weakest_frame = current.get(weakest.symbol) or weakest.last_frame
            weakest_age = (now - weakest.joined_at).total_seconds()
            if (
                weakest_age >= self.membership_commit_sec
                and frame.score_100 >= self._score(weakest_frame) + self.overtake_min_score_gap
            ):
                idx = members.index(weakest)
                self._drop_tracking(kind, weakest.symbol)
                members[idx] = _Member(symbol=frame.symbol, joined_at=now, last_frame=frame)
                members_set.discard(weakest.symbol)
                members_set.add(frame.symbol)
                self._qualification_since.pop(key, None)

        self._stabilize_order(kind, now)

    def _stabilize_order(self, kind: NxtBoardKind, now: datetime) -> None:
        members = self._members[kind]
        frames = self.source.frames
        changed = True
        passes = 0
        while changed and passes < self.fixed_rows:
            changed = False
            passes += 1
            for i in range(1, len(members)):
                ahead, behind = members[i - 1], members[i]
                if ahead.miss_since is not None or behind.miss_since is not None:
                    continue
                fa, fb = frames.get(ahead.symbol), frames.get(behind.symbol)
                if fa is None or fb is None:
                    continue
                gap = fb.score_100 - fa.score_100
                key = (kind, behind.symbol, ahead.symbol)
                if gap < self.overtake_min_score_gap:
                    self._overtake.pop(key, None)
                    continue
                count, since = self._overtake.get(key, (0, now))
                count += 1
                self._overtake[key] = (count, since)
                waited = (now - since).total_seconds()
                if count >= self.overtake_required_checks or waited >= self.overtake_max_wait_sec:
                    members[i - 1], members[i] = behind, ahead
                    self._overtake.pop(key, None)
                    changed = True

    def _phase_state(self, kind: NxtBoardKind, active_kind: NxtBoardKind | None, now: datetime) -> NxtBoardPhaseState:
        if kind == active_kind:
            return NxtBoardPhaseState.ACTIVE
        local_t = now.astimezone(KST).time().replace(tzinfo=None)
        start_hm = {
            NxtBoardKind.EARLY_FLOW: (15, 40),
            NxtBoardKind.EARLY_BUY: (18, 30),
            NxtBoardKind.CLOSE_BET: (19, 30),
        }[kind]
        if (local_t.hour, local_t.minute) < start_hm:
            return NxtBoardPhaseState.WAITING
        return NxtBoardPhaseState.CLOSED

    @staticmethod
    def _score(frame: NxtNativeFrame | None) -> float:
        return float(frame.score_100) if frame is not None else -1.0

    @staticmethod
    def _row(rank: int, frame: NxtNativeFrame, member: _Member, age: float, commit_sec: float, in_grace: bool) -> NxtBoardRow:
        flags = list(frame.flags)
        if in_grace:
            flags.append("MEMBERSHIP_GRACE")
        return NxtBoardRow(
            rank=rank,
            symbol=frame.symbol,
            stage=frame.stage.value,
            score_100=frame.score_100,
            nxt_price=frame.nxt_price,
            change_rate=frame.change_rate,
            nxt_premium_pct=frame.nxt_premium_pct,
            spread_pct=frame.spread_pct,
            aggressive_buy_ratio_30s=frame.aggressive_buy_ratio_30s,
            ofi_2m=frame.ofi_2m,
            money_5m=frame.money_5m,
            money_acceleration=frame.money_acceleration,
            vwap_distance_pct=frame.vwap_distance_pct,
            persistence_count=frame.persistence_count,
            strict_close_window=frame.strict_close_window,
            price_trust=frame.price_trust.value,
            quote_trust=frame.quote_trust.value,
            flow_trust=frame.flow_trust.value,
            investor_flow_trust=frame.investor_flow_trust.value,
            member_since=member.joined_at,
            membership_age_sec=round(age, 2),
            membership_committed=age >= commit_sec,
            source_asof=frame.asof,
            flags=flags,
        )

    def _clear_kind_tracking(self, kind: NxtBoardKind) -> None:
        for key in [k for k in self._qualification_since if k[0] == kind]:
            self._qualification_since.pop(key, None)
        for key in [k for k in self._overtake if k[0] == kind]:
            self._overtake.pop(key, None)

    def _drop_tracking(self, kind: NxtBoardKind, symbol: str) -> None:
        self._qualification_since.pop((kind, symbol), None)
        for key in [k for k in self._overtake if k[0] == kind and symbol in k[1:]]:
            self._overtake.pop(key, None)
