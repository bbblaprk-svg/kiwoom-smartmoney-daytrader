from __future__ import annotations

from copy import deepcopy
from datetime import datetime, time, timezone
from typing import Any
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.live_validation.models import (
    LiveCheckScope,
    LiveCheckStatus,
    LiveValidationCheck,
    LiveValidationFrame,
)
from pulse_edge.storage.validation import LiveValidationStore

KST = ZoneInfo("Asia/Seoul")


CHECKS: tuple[tuple[str, str, LiveCheckScope, bool], ...] = (
    ("NXT_PRE_0800", "08:00 NXT trusted trade/orderbook", LiveCheckScope.SESSION, True),
    ("KRX_AUCTION_0850", "08:50 KRX expected-execution stream", LiveCheckScope.SESSION, True),
    ("KRX_MAIN_0900", "09:00 KRX trusted trade/orderbook", LiveCheckScope.SESSION, True),
    ("VENUE_SEPARATION", "KRX/NXT exact-lane separation", LiveCheckScope.SESSION, True),
    ("INDEX_RS", "001/101 benchmark streams and realtime RS", LiveCheckScope.SESSION, True),
    ("PROGRAM_0W", "0w program fields live unit/sign review", LiveCheckScope.REVIEW, True),
    ("INVESTOR_FLOW", "1/3/5D + intraday foreign/institution review", LiveCheckScope.REVIEW, True),
    ("DISCOVERY_DYNAMIC_WS", "ka10021/22/23 discovery and dynamic WS", LiveCheckScope.SESSION, True),
    ("BASELINE_MULTI_DAY", "same-time baseline from earlier trading date", LiveCheckScope.MULTI_DAY, True),
    ("NXT_AFTER", "15:40-20:00 NXT trusted trade/orderbook", LiveCheckScope.SESSION, True),
    ("RECONNECT_RECOVERY", "actual reconnect followed by trusted recovery", LiveCheckScope.EVENT_DEPENDENT, True),
    ("STALE_REGRESSION_FILTER", "live stale/regressed event rejection observed", LiveCheckScope.EVENT_DEPENDENT, False),
    ("DECISION_PIPELINE", "PRE-BUY and 0-3 compression refresh health", LiveCheckScope.SESSION, True),
    ("PRESENTATION_SAFETY", "presentation safety refresh health", LiveCheckScope.SESSION, True),
    ("SIGNAL_LEDGER", "signal ledger refresh health", LiveCheckScope.SESSION, True),
)


class LiveShadowValidationService:
    """Read-only live-session observer.

    It records evidence from already-running PULSE services and never supplies a
    value to discovery, scoring, gates, PRE-BUY, compression or presentation.
    """

    def __init__(
        self,
        *,
        store: LiveValidationStore,
        app_version: str,
        environment: str,
        session_router: Any,
        state: Any,
        features: Any,
        feed_service: Any,
        ws: Any,
        runtime_truth: Any,
        discovery: Any,
        investor_flow: Any,
        prebuy_decision: Any,
        current_decisions: Any,
        presentation_safety: Any,
        signal_ledger: Any,
    ) -> None:
        self.store = store
        self.app_version = app_version
        self.environment = environment
        self.session_router = session_router
        self.state = state
        self.features = features
        self.feed_service = feed_service
        self.ws = ws
        self.runtime_truth = runtime_truth
        self.discovery = discovery
        self.investor_flow = investor_flow
        self.prebuy_decision = prebuy_decision
        self.current_decisions = current_decisions
        self.presentation_safety = presentation_safety
        self.signal_ledger = signal_ledger
        self.frame: LiveValidationFrame | None = None
        self.last_error: str | None = None
        self._day: str | None = None
        self._persisted: dict[str, dict] = {}
        self._last_run_touch_at: datetime | None = None
        self._run_heartbeat_sec = 60.0

    @staticmethod
    def _local(ts: datetime) -> datetime:
        return ts.astimezone(KST)

    def _load_day(self, day: str) -> None:
        if self._day == day:
            return
        self._day = day
        self._persisted = self.store.load_day(day)
        self._last_run_touch_at = None

    def _check(self, check_id: str) -> LiveValidationCheck:
        meta = next(x for x in CHECKS if x[0] == check_id)
        row = LiveValidationCheck(check_id=meta[0], label=meta[1], scope=meta[2], blocking=meta[3])
        old = self._persisted.get(check_id)
        if old:
            row.status = old["status"]
            row.first_observed_at = old["first_observed_at"]
            row.last_observed_at = old["last_observed_at"]
            row.details = deepcopy(old["details"])
            row.notes = list(old["notes"])
        return row

    @staticmethod
    def _promote(
        check: LiveValidationCheck,
        status: LiveCheckStatus,
        now: datetime,
        *,
        details: dict | None = None,
        notes: list[str] | None = None,
    ) -> LiveValidationCheck:
        rank = {
            LiveCheckStatus.PENDING: 0,
            LiveCheckStatus.REVIEW: 1,
            LiveCheckStatus.PASS: 2,
            LiveCheckStatus.FAIL: 3,
        }
        if rank[status] >= rank[check.status]:
            check.status = status
        if check.first_observed_at is None:
            check.first_observed_at = now
        check.last_observed_at = now
        if details:
            check.details.update(details)
        if notes:
            check.notes = list(dict.fromkeys(check.notes + notes))
        return check

    @staticmethod
    def _event_local(event: Any) -> datetime:
        return (getattr(event, "event_time", None) or getattr(event, "receive_time")).astimezone(KST)

    def _events_in_window(self, venue: Venue, start: time, end: time) -> dict[str, set[str]]:
        book = self.state.krx if venue == Venue.KRX else self.state.nxt
        day = self._day
        out: dict[str, set[str]] = {}
        for symbol, st in book.items():
            for typ, event in st.events_by_type.items():
                local = self._event_local(event)
                if local.date().isoformat() != day:
                    continue
                t = local.time().replace(tzinfo=None)
                if start <= t < end:
                    out.setdefault(symbol, set()).add(str(typ))
        return out

    def _accumulate_types(
        self,
        check: LiveValidationCheck,
        rows: dict[str, set[str]],
        required: set[str],
        now: datetime,
    ) -> LiveValidationCheck:
        seen = set(check.details.get("types_seen", []))
        symbols = set(check.details.get("symbols", []))
        for symbol, types in rows.items():
            seen.update(types & required)
            if types & required:
                symbols.add(symbol)
        check.details["types_seen"] = sorted(seen)
        check.details["symbols"] = sorted(symbols)[:20]
        if required.issubset(seen):
            self._promote(check, LiveCheckStatus.PASS, now)
        elif seen:
            self._promote(check, LiveCheckStatus.PENDING, now)
        return check

    def _evaluate(self, now: datetime) -> list[LiveValidationCheck]:
        checks = {cid: self._check(cid) for cid, _, _, _ in CHECKS}

        nxt_pre = self._events_in_window(Venue.NXT, time(8, 0), time(8, 50))
        self._accumulate_types(checks["NXT_PRE_0800"], nxt_pre, {"0B", "0D"}, now)

        krx_auc = self._events_in_window(Venue.KRX, time(8, 50), time(9, 0))
        auc = checks["KRX_AUCTION_0850"]
        seen_auc = set(auc.details.get("types_seen", []))
        auc_symbols = set(auc.details.get("symbols", []))
        for symbol, types in krx_auc.items():
            if "0H" in types:
                seen_auc.add("0H")
                auc_symbols.add(symbol)
        auc.details["types_seen"] = sorted(seen_auc)
        auc.details["symbols"] = sorted(auc_symbols)[:20]
        auc.details["opening_frame_count"] = len(getattr(self.features, "opening_frames", {}))
        if "0H" in seen_auc and auc.details["opening_frame_count"] > 0:
            self._promote(auc, LiveCheckStatus.PASS, now)
        elif seen_auc:
            self._promote(auc, LiveCheckStatus.PENDING, now)

        krx_main = self._events_in_window(Venue.KRX, time(9, 0), time(15, 20))
        self._accumulate_types(checks["KRX_MAIN_0900"], krx_main, {"0B", "0D"}, now)

        sep = checks["VENUE_SEPARATION"]
        overlap = sorted(set(self.state.krx) & set(self.state.nxt))
        exact = []
        for symbol in overlap:
            k = self.state.krx[symbol].events_by_type
            n = self.state.nxt[symbol].events_by_type
            k_today = [e for t, e in k.items() if t in {"0B", "0D"} and self._event_local(e).date().isoformat() == self._day]
            n_today = [e for t, e in n.items() if t in {"0B", "0D"} and self._event_local(e).date().isoformat() == self._day]
            if k_today and n_today:
                exact.append(symbol)
        if exact:
            self._promote(
                sep,
                LiveCheckStatus.PASS,
                now,
                details={"overlap_symbols": exact[:20], "krx_count": len(self.state.krx), "nxt_count": len(self.state.nxt)},
            )

        idx = checks["INDEX_RS"]
        benchmarks = getattr(self.features, "benchmarks", {})
        def benchmark_today(symbol: str) -> bool:
            rows = benchmarks.get((Venue.KRX, symbol))
            if not rows:
                return False
            ts = getattr(rows[-1], "ts", None)
            return ts is not None and ts.astimezone(KST).date().isoformat() == self._day

        b001 = benchmark_today("001")
        b101 = benchmark_today("101")
        rs_rows = [
            f for f in getattr(self.features, "frames", {}).values()
            if getattr(f, "rs_level", None) is not None
            and getattr(f, "benchmark_symbol", None) in {"001", "101"}
            and getattr(f, "asof", None) is not None
            and f.asof.astimezone(KST).date().isoformat() == self._day
        ]
        if b001 and b101 and rs_rows:
            self._promote(idx, LiveCheckStatus.PASS, now, details={"index_001": True, "index_101": True, "rs_rows": len(rs_rows)})

        program = checks["PROGRAM_0W"]
        program_rows = []
        for frame in getattr(self.features, "frames", {}).values():
            frame_asof = getattr(frame, "asof", None)
            if frame_asof is None or frame_asof.astimezone(KST).date().isoformat() != self._day:
                continue
            vals = {
                "qty": getattr(frame, "program_net_buy_qty", None),
                "qty_delta": getattr(frame, "program_net_buy_qty_delta", None),
                "amount": getattr(frame, "program_net_buy_amount", None),
                "amount_delta": getattr(frame, "program_net_buy_amount_delta", None),
            }
            if any(v is not None for v in vals.values()):
                program_rows.append({"venue": frame.venue.value, "symbol": frame.symbol, **vals})
        if program_rows:
            self._promote(
                program,
                LiveCheckStatus.REVIEW,
                now,
                details={"sample_count": len(program_rows), "samples": program_rows[:5]},
                notes=["Observed live 0w fields; verify Kiwoom unit scale and sign before calibration."],
            )

        inv = checks["INVESTOR_FLOW"]
        recent = getattr(self.investor_flow, "recent", {}) if self.investor_flow is not None else {}
        intraday = getattr(self.investor_flow, "intraday", {}) if self.investor_flow is not None else {}
        recent_today = {k: v for k, v in recent.items() if getattr(v, "asof", None) is not None and v.asof.astimezone(KST).date().isoformat() == self._day}
        intraday_today = {k: v for k, v in intraday.items() if getattr(v, "asof", None) is not None and v.asof.astimezone(KST).date().isoformat() == self._day}
        periods = sorted({int(k[1]) for k in recent_today if len(k) >= 2 and int(k[1]) in {1, 3, 5}})
        actors = sorted({str(k[1]) for k in intraday_today if len(k) >= 2})
        if set(periods) == {1, 3, 5} and {"FOREIGN", "INSTITUTION"}.issubset(set(actors)):
            recent_samples = []
            for row in list(recent_today.values())[:5]:
                recent_samples.append({
                    "symbol": row.symbol,
                    "period_days": row.period_days,
                    "foreign_net_amount": row.foreign_net_amount,
                    "institution_net_amount": row.institution_net_amount,
                })
            intra_samples = []
            for row in list(intraday_today.values())[:5]:
                intra_samples.append({"symbol": row.symbol, "actor": row.actor, "net_value": row.net_value})
            self._promote(
                inv,
                LiveCheckStatus.REVIEW,
                now,
                details={"periods": periods, "actors": actors, "recent_samples": recent_samples, "intraday_samples": intra_samples},
                notes=["Observed 1/3/5D and intraday facts; verify live units/signs before enabling amount-scale calibration."],
            )

        disc = checks["DISCOVERY_DYNAMIC_WS"]
        calls = dict(getattr(self.discovery, "api_call_count", {}) or {}) if self.discovery is not None else {}
        event_items = list(getattr(self.ws, "event_stock_items", []) or []) if self.ws is not None else []
        refresh_count = int(getattr(self.ws, "dynamic_refresh_count", 0) if self.ws else 0)
        scan_at = getattr(self.discovery, "last_scan_at", None) if self.discovery is not None else None
        scan_today = scan_at is not None and scan_at.astimezone(KST).date().isoformat() == self._day
        if scan_today and all(int(calls.get(x, 0)) > 0 for x in ("ka10021", "ka10022", "ka10023")) and event_items and refresh_count > 0:
            self._promote(
                disc,
                LiveCheckStatus.PASS,
                now,
                details={"api_call_count": calls, "event_subscription_count": len(event_items), "dynamic_refresh_count": refresh_count},
            )

        base = checks["BASELINE_MULTI_DAY"]
        base_rows = [
            f for f in getattr(self.features, "frames", {}).values()
            if int(getattr(f, "baseline_days", 0) or 0) >= 1
            and getattr(f, "rvol_same_time", None) is not None
            and getattr(f, "asof", None) is not None
            and f.asof.astimezone(KST).date().isoformat() == self._day
        ]
        if base_rows:
            self._promote(
                base,
                LiveCheckStatus.PASS,
                now,
                details={"rows_with_prior_day_baseline": len(base_rows), "max_baseline_days": max(int(f.baseline_days) for f in base_rows)},
            )

        nxt_after = self._events_in_window(Venue.NXT, time(15, 40), time(20, 0))
        self._accumulate_types(checks["NXT_AFTER"], nxt_after, {"0B", "0D"}, now)

        reconnect = checks["RECONNECT_RECOVERY"]
        reconnect_count = int(getattr(self.ws, "reconnect_count", 0) if self.ws else 0)
        connected_at = getattr(self.ws, "last_connected_at", None) if self.ws else None
        trusted = getattr(self.feed_service, "last_trusted_market_event_at", None)
        trusted_epoch = trusted.timestamp() if trusted is not None else None
        if reconnect_count > 0 and connected_at and trusted_epoch and trusted_epoch >= float(connected_at):
            self._promote(
                reconnect,
                LiveCheckStatus.PASS,
                now,
                details={"reconnect_count": reconnect_count, "last_connected_at_epoch": connected_at, "trusted_event_after_reconnect": True},
            )
        elif reconnect_count > 0:
            self._promote(reconnect, LiveCheckStatus.PENDING, now, details={"reconnect_count": reconnect_count})

        filt = checks["STALE_REGRESSION_FILTER"]
        truth_counts = getattr(getattr(self.runtime_truth, "truth", None), "counters", {}) if self.runtime_truth is not None else {}
        stale = int((truth_counts or {}).get("STALE", 0))
        invalid = int((truth_counts or {}).get("INVALID", 0))
        time_rejects = int(getattr(getattr(self.feed_service, "continuity", None), "time_rejects", 0))
        if stale > 0 or invalid > 0 or time_rejects > 0:
            self._promote(
                filt,
                LiveCheckStatus.PASS,
                now,
                details={"truth_stale": stale, "truth_invalid": invalid, "timestamp_regression_rejects": time_rejects},
            )

        pipe = checks["DECISION_PIPELINE"]
        pre_at = getattr(self.prebuy_decision, "last_refresh_at", None)
        comp_at = getattr(self.current_decisions, "last_refresh_at", None)
        local_now = now.astimezone(KST)
        after_main_open = local_now.time().replace(tzinfo=None) >= time(9, 0)
        same_day_pre = pre_at is not None and pre_at.astimezone(KST).date().isoformat() == self._day
        same_day_comp = comp_at is not None and comp_at.astimezone(KST).date().isoformat() == self._day
        if after_main_open and same_day_pre and same_day_comp and not getattr(self.prebuy_decision, "last_error", None) and not getattr(self.current_decisions, "last_error", None):
            self._promote(
                pipe,
                LiveCheckStatus.PASS,
                now,
                details={
                    "prebuy_rows": len(getattr(self.prebuy_decision, "frames", {})),
                    "compressed_rows": len(getattr(self.current_decisions, "rows", [])),
                    "zero_rows_is_not_failure": True,
                },
            )

        pres = checks["PRESENTATION_SAFETY"]
        pframe = getattr(self.presentation_safety, "frame", None)
        if pframe is not None and pframe.asof.astimezone(KST).date().isoformat() == self._day:
            self._promote(pres, LiveCheckStatus.PASS, now, details={"presentation_state": pframe.state.value})

        ledger = checks["SIGNAL_LEDGER"]
        ledger_at = getattr(self.signal_ledger, "last_refresh_at", None)
        if ledger_at is not None and ledger_at.astimezone(KST).date().isoformat() == self._day and not getattr(self.signal_ledger, "last_error", None):
            self._promote(ledger, LiveCheckStatus.PASS, now, details={"refresh_at": ledger_at.isoformat()})

        return [checks[cid] for cid, _, _, _ in CHECKS]

    @staticmethod
    def _coverage(checks: list[LiveValidationCheck]) -> str:
        if any(c.status == LiveCheckStatus.FAIL for c in checks):
            return "FAIL"
        blocking = [c for c in checks if c.blocking]
        if any(c.status == LiveCheckStatus.PENDING for c in blocking):
            return "PENDING"
        if any(c.status == LiveCheckStatus.REVIEW for c in checks):
            return "REVIEW_REQUIRED"
        return "EVIDENCE_COMPLETE"

    def refresh(self, now: datetime | None = None) -> LiveValidationFrame:
        now = now or datetime.now(timezone.utc)
        local = now.astimezone(KST)
        day = local.date().isoformat()
        self._load_day(day)
        frame = self.session_router.frame_at(now)
        real_connection = bool(self.ws and getattr(self.ws, "connection_count", 0) > 0)

        if not frame.trading_day:
            checks = [self._check(cid) for cid, _, _, _ in CHECKS]
            self.frame = LiveValidationFrame(
                asof=now,
                trading_day=day,
                session_phase=frame.phase.value,
                coverage_state="MARKET_CLOSED",
                real_connection_observed=real_connection,
                pass_count=sum(c.status == LiveCheckStatus.PASS for c in checks),
                review_count=sum(c.status == LiveCheckStatus.REVIEW for c in checks),
                pending_count=sum(c.status == LiveCheckStatus.PENDING for c in checks),
                fail_count=sum(c.status == LiveCheckStatus.FAIL for c in checks),
                checks=checks,
            )
            self.last_error = None
            return self.frame

        checks = self._evaluate(now)
        wrote = False
        for check in checks:
            old = self._persisted.get(check.check_id)
            changed = (
                old is None
                or old["status"] != check.status
                or (old["status"] == LiveCheckStatus.PENDING and old.get("details", {}) != check.details)
                or (old["status"] == LiveCheckStatus.PENDING and old.get("notes", []) != check.notes)
            )
            if changed:
                self.store.upsert_check(day, check)
                wrote = True
        if wrote:
            self._persisted = self.store.load_day(day)
        if self._last_run_touch_at is None or (now - self._last_run_touch_at).total_seconds() >= self._run_heartbeat_sec:
            self.store.touch_run(
                day,
                now=now,
                app_version=self.app_version,
                environment=self.environment,
                real_connection_observed=real_connection,
            )
            self._last_run_touch_at = now
        checks = [self._check(cid) for cid, _, _, _ in CHECKS]
        coverage = self._coverage(checks)
        self.frame = LiveValidationFrame(
            asof=now,
            trading_day=day,
            session_phase=frame.phase.value,
            coverage_state=coverage,
            live_market_validation="PENDING_REVIEW" if coverage in {"REVIEW_REQUIRED", "EVIDENCE_COMPLETE"} else "PENDING",
            real_connection_observed=real_connection,
            pass_count=sum(c.status == LiveCheckStatus.PASS for c in checks),
            review_count=sum(c.status == LiveCheckStatus.REVIEW for c in checks),
            pending_count=sum(c.status == LiveCheckStatus.PENDING for c in checks),
            fail_count=sum(c.status == LiveCheckStatus.FAIL for c in checks),
            checks=checks,
        )
        self.last_error = None
        return self.frame
