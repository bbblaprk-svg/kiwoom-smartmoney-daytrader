from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class LiveCheckStatus(StrEnum):
    PENDING = "PENDING"
    PASS = "PASS"
    REVIEW = "REVIEW"
    FAIL = "FAIL"


class LiveCheckScope(StrEnum):
    SESSION = "SESSION"
    MULTI_DAY = "MULTI_DAY"
    REVIEW = "REVIEW"
    EVENT_DEPENDENT = "EVENT_DEPENDENT"


class LiveValidationCheck(BaseModel):
    check_id: str
    label: str
    scope: LiveCheckScope
    blocking: bool = True
    status: LiveCheckStatus = LiveCheckStatus.PENDING
    first_observed_at: datetime | None = None
    last_observed_at: datetime | None = None
    details: dict[str, Any] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)


class LiveValidationFrame(BaseModel):
    asof: datetime
    trading_day: str
    session_phase: str
    coverage_state: str
    live_market_validation: str = "PENDING"
    real_connection_observed: bool = False
    pass_count: int = 0
    review_count: int = 0
    pending_count: int = 0
    fail_count: int = 0
    checks: list[LiveValidationCheck] = Field(default_factory=list)
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    feeds_current_decisions: bool = False
