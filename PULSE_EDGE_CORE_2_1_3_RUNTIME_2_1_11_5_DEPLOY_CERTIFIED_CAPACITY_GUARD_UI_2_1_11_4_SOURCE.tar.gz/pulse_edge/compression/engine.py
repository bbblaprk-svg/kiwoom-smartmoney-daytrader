from __future__ import annotations

from datetime import datetime

from pulse_edge.decision.models import PreBuyDecisionFrame, PreBuyStage


class CurrentDecisionCompressionEngine:
    """Select current high-eligibility rows without inventing another score.

    Ranking is lexicographic over already-computed current facts. Historical
    outcomes are intentionally absent from this engine.
    """

    ELIGIBLE_STAGES = {
        PreBuyStage.ENTRY_ELIGIBLE_SHADOW,
        PreBuyStage.A_PLUS_ELIGIBLE_SHADOW,
    }

    @classmethod
    def eligible(cls, row: PreBuyDecisionFrame, *, asof: datetime, source_max_age_sec: float) -> bool:
        if row.stage not in cls.ELIGIBLE_STAGES:
            return False
        if not row.base_hard_gate_pass or not row.hard_gate_pass:
            return False
        if not row.universe_eligible:
            return False
        if row.risk_flags or row.gate_failures:
            return False
        age = max(0.0, (asof - row.asof).total_seconds())
        if age > source_max_age_sec:
            return False
        return True

    @staticmethod
    def stage_rank(row: PreBuyDecisionFrame) -> int:
        return 2 if row.stage == PreBuyStage.A_PLUS_ELIGIBLE_SHADOW else 1

    @classmethod
    def sort_key(cls, row: PreBuyDecisionFrame) -> tuple:
        # No probability or synthetic composite score: strongest existing
        # eligibility and independent evidence lead, then current quality/freshness.
        return (
            cls.stage_rank(row),
            int(row.evidence_count),
            float(row.confluence_score_100),
            float(row.route_score_100 or 0.0),
            int(row.smart_flow_confirmed_windows),
            float(row.smart_flow_score_100 or 0.0),
            int(row.discovery_source_count),
            float(row.money_5m or 0.0),
            -float(row.spread_pct if row.spread_pct is not None else 999.0),
            -float(row.tick_age_sec if row.tick_age_sec is not None else 999.0),
            -float(row.upstream_asof_age_sec if row.upstream_asof_age_sec is not None else 999.0),
        )

    @staticmethod
    def selection_reasons(row: PreBuyDecisionFrame) -> list[str]:
        out = [row.stage.value, f"EVIDENCE={row.evidence_count}/5", f"PRIMARY_ROUTE={row.primary_route.value}"]
        if row.hard_gate_pass:
            out.append("PERSISTENT_HARD_GATE_PASS")
        if row.smart_flow_confirmed_windows:
            out.append(f"SMART_FLOW_WINDOWS={row.smart_flow_confirmed_windows}")
        out.append("HISTORICAL_PERFORMANCE_NOT_USED")
        return out
