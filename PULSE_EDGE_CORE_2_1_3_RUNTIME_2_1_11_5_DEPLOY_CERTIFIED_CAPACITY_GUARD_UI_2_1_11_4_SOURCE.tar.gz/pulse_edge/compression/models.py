from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from pulse_edge.confluence.models import ConfluenceGrade
from pulse_edge.core.models import Venue
from pulse_edge.decision.models import DecisionPrimaryRoute, PreBuyStage
from pulse_edge.regime.models import MarketRegimeState


class CurrentDecisionRow(BaseModel):
    rank: int
    venue: Venue
    symbol: str
    asof: datetime
    source_decision_asof: datetime
    price: float | None = None
    change_rate: float | None = None
    source_stage: PreBuyStage
    primary_route: DecisionPrimaryRoute
    supporting_routes: list[str] = Field(default_factory=list)

    confluence_grade: ConfluenceGrade
    confluence_score_100: float
    evidence_count: int
    regime_state: MarketRegimeState
    regime_score_100: float

    sector_name: str | None = None
    sector_code: str | None = None
    smart_flow_state: str = "DATA_WAIT"
    smart_flow_score_100: float | None = None
    smart_flow_confirmed_windows: int = 0
    microprice_bias_pct: float | None = None
    spread_pct: float | None = None
    money_5m: float | None = None
    tick_age_sec: float | None = None
    quote_age_sec: float | None = None
    discovery_source_count: int = 0

    route_score_100: float | None = None
    entry_reference_low: float | None = None
    entry_reference_high: float | None = None
    entry_reference_basis: str | None = None
    invalidation_price: float | None = None
    invalidation_basis: str | None = None

    selection_reasons: list[str] = Field(default_factory=list)
    source_risk_flags: list[str] = Field(default_factory=list)
    source_gate_failures: list[str] = Field(default_factory=list)
    source_frame_age_sec: float = 0.0

    historical_performance_used_for_ranking: bool = False
    new_composite_score_created: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
