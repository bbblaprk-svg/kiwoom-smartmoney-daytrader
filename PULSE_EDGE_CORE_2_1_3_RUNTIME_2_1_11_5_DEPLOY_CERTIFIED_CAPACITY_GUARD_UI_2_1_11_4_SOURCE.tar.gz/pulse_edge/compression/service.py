from __future__ import annotations

from datetime import datetime, timezone

from pulse_edge.compression.engine import CurrentDecisionCompressionEngine
from pulse_edge.compression.models import CurrentDecisionRow
from pulse_edge.core.models import Venue
from pulse_edge.decision.models import PreBuyDecisionFrame
from pulse_edge.decision.service import PreBuyDecisionService


class CurrentDecisionCompressionService:
    def __init__(
        self,
        *,
        decisions: PreBuyDecisionService,
        engine: CurrentDecisionCompressionEngine,
        max_rows: int = 3,
        source_max_age_sec: float = 7.5,
    ) -> None:
        self.decisions = decisions
        self.engine = engine
        self.max_rows = max(1, min(int(max_rows), 3))
        self.source_max_age_sec = max(1.0, float(source_max_age_sec))
        self.rows: list[CurrentDecisionRow] = []
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[CurrentDecisionRow]:
        now = asof or datetime.now(timezone.utc)
        source = self.decisions.top(max(3, min(int(limit), 200)))
        eligible = [
            row for row in source
            if self.engine.eligible(row, asof=now, source_max_age_sec=self.source_max_age_sec)
        ]
        eligible.sort(key=self.engine.sort_key, reverse=True)

        # One current representative per symbol across venues. Venue is never
        # rewritten; the strongest exact-lane row wins by the same ranking key.
        chosen: list[PreBuyDecisionFrame] = []
        seen_symbols: set[str] = set()
        for row in eligible:
            if row.symbol in seen_symbols:
                continue
            seen_symbols.add(row.symbol)
            chosen.append(row)
            if len(chosen) >= self.max_rows:
                break

        out: list[CurrentDecisionRow] = []
        for idx, row in enumerate(chosen, start=1):
            age = max(0.0, (now - row.asof).total_seconds())
            out.append(CurrentDecisionRow(
                rank=idx,
                venue=row.venue,
                symbol=row.symbol,
                asof=now,
                source_decision_asof=row.asof,
                price=row.price,
                change_rate=row.change_rate,
                source_stage=row.stage,
                primary_route=row.primary_route,
                supporting_routes=list(row.supporting_routes),
                confluence_grade=row.confluence_grade,
                confluence_score_100=row.confluence_score_100,
                evidence_count=row.evidence_count,
                regime_state=row.regime_state,
                regime_score_100=row.regime_score_100,
                sector_name=row.sector_name,
                sector_code=row.sector_code,
                smart_flow_state=row.smart_flow_state,
                smart_flow_score_100=row.smart_flow_score_100,
                smart_flow_confirmed_windows=row.smart_flow_confirmed_windows,
                microprice_bias_pct=row.microprice_bias_pct,
                spread_pct=row.spread_pct,
                money_5m=row.money_5m,
                tick_age_sec=row.tick_age_sec,
                quote_age_sec=row.quote_age_sec,
                discovery_source_count=row.discovery_source_count,
                route_score_100=row.route_score_100,
                entry_reference_low=row.entry_reference_low,
                entry_reference_high=row.entry_reference_high,
                entry_reference_basis=row.entry_reference_basis,
                invalidation_price=row.invalidation_price,
                invalidation_basis=row.invalidation_basis,
                selection_reasons=self.engine.selection_reasons(row),
                source_risk_flags=list(row.risk_flags),
                source_gate_failures=list(row.gate_failures),
                source_frame_age_sec=round(age, 3),
                historical_performance_used_for_ranking=False,
                new_composite_score_created=False,
                official_signal_enabled=False,
                order_action_enabled=False,
            ))
        # Current-only replacement: disappeared or downgraded rows are removed.
        self.rows = out
        self.last_refresh_at = now
        self.last_error = None
        return list(self.rows)

    def top(self, limit: int = 3) -> list[CurrentDecisionRow]:
        return list(self.rows[: max(1, min(int(limit), self.max_rows))])

    def get(self, venue: Venue, symbol: str) -> CurrentDecisionRow | None:
        for row in self.rows:
            if row.venue == venue and row.symbol == symbol[:6]:
                return row
        return None
