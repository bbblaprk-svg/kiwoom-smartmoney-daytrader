from __future__ import annotations

from datetime import datetime, timezone
from typing import Awaitable, Callable

from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.session.router import SessionPhase, SessionRouter
from pulse_edge.universe.service import UniverseService, UniverseStock


BackgroundHook = Callable[[list[str]], Awaitable[None]]


class BackgroundCoverageService:
    """Fair process-memory rotation across the current KOSPI/KOSDAQ universe.

    The service gives no incumbent or previous-session priority. A restart resets
    the cursor. Rotation only creates a transient realtime observation pool; it
    does not produce a score or signal by itself.
    """

    def __init__(
        self,
        universe: UniverseService,
        session_router: SessionRouter,
        features: FeatureEngine,
        background_hook: BackgroundHook,
        batch_size: int = 120,
    ) -> None:
        self.universe = universe
        self.session_router = session_router
        self.features = features
        self.background_hook = background_hook
        self.batch_size = max(1, int(batch_size))
        self.cursor = 0
        self.current: list[tuple[Venue, str]] = []
        self.last_rotation_at: datetime | None = None
        self.rotation_count = 0

    async def rotate(self, when: datetime | None = None) -> list[tuple[Venue, str]]:
        now = when or datetime.now(timezone.utc)
        phase = self.session_router.phase_at(now)
        venue, nxt_only = self._venue_for_phase(phase)
        if venue is None:
            self.current = []
            await self.background_hook([])
            self.last_rotation_at = now
            return []

        stocks = self.universe.eligible(nxt_only=nxt_only)
        if not stocks:
            self.current = []
            await self.background_hook([])
            self.last_rotation_at = now
            return []

        if self.cursor >= len(stocks):
            self.cursor = 0
        chosen: list[UniverseStock] = []
        for offset in range(min(self.batch_size, len(stocks))):
            chosen.append(stocks[(self.cursor + offset) % len(stocks)])
        self.cursor = (self.cursor + len(chosen)) % len(stocks)
        self.current = [(venue, x.symbol) for x in chosen]
        wire_items = [f"{x.symbol}_NX" if venue == Venue.NXT else x.symbol for x in chosen]
        await self.background_hook(wire_items)
        self.last_rotation_at = now
        self.rotation_count += 1
        return list(self.current)

    def ready_keys(self, limit: int = 40) -> list[tuple[Venue, str]]:
        scored: list[tuple[float, tuple[Venue, str]]] = []
        for key in self.current:
            frame = self.features.frames.get(key)
            if frame is None:
                continue
            # Feature-only pre-ranking: current acceleration, underreaction and RS.
            score = 0.0
            if frame.change_rate is not None and -2.0 <= frame.change_rate <= 4.0:
                score += 2.0
            if frame.rs_acceleration is not None and frame.rs_acceleration > 0:
                score += 2.0
            if frame.rs_velocity is not None and frame.rs_velocity > 0:
                score += 1.0
            if frame.money_acceleration is not None and frame.money_acceleration > 0:
                score += 2.0
            if frame.money_second_derivative is not None and frame.money_second_derivative > 0:
                score += 1.0
            if frame.rvol_same_time is not None and frame.rvol_same_time >= 1.1:
                score += min(2.0, frame.rvol_same_time - 0.5)
            scored.append((score, key))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [key for _, key in scored[: max(1, int(limit))]]

    @staticmethod
    def _venue_for_phase(phase: SessionPhase) -> tuple[Venue | None, bool]:
        if phase in {SessionPhase.NXT_PRE, SessionPhase.NXT_AFTER, SessionPhase.NXT_LATE_SESSION}:
            return Venue.NXT, True
        if phase == SessionPhase.MARKET_MAIN:
            return Venue.KRX, False
        return None, False
