from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import median
from typing import Any, Protocol

from pulse_edge.feed.rest import RestPage
from pulse_edge.features.benchmark import MarketClass


class RestLike(Protocol):
    async def post(
        self,
        api_id: str,
        path: str,
        body: dict[str, Any],
        cont_yn: str | None = None,
        next_key: str | None = None,
    ) -> RestPage: ...


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").replace("%", "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _symbol(value: Any) -> str:
    raw = str(value or "").strip()
    if raw.endswith("_AL") or raw.endswith("_NX"):
        raw = raw[:-3]
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits[:6] if len(digits) >= 6 else ""


@dataclass(frozen=True)
class SectorBreadthFrame:
    sector_code: str
    sector_name: str | None
    market: MarketClass
    asof: datetime
    change_rate: float | None
    turnover_raw: float | None
    listed_count: int | None
    rising_count: int | None
    falling_count: int | None
    breadth_ratio: float | None
    breadth_velocity_ppm: float | None
    breadth_acceleration_ppm2: float | None
    member_count: int
    member_positive_ratio: float | None
    member_median_change: float | None
    leader_change_rate: float | None
    score_15: float


class SectorBreadthService:
    """Builds sector breadth from Kiwoom sector facts only.

    ka20003 supplies all-sector breadth/count/turnover facts. The strongest
    current sectors are expanded with ka20002 to obtain members. Historical
    breadth velocity/acceleration exists only in process memory.
    """

    CATALOG_API = "ka20003"
    COMPONENT_API = "ka20002"
    PATH = "/api/dostk/sect"
    AGGREGATE_CODES = {"001", "002", "003", "004", "101", "201", "302", "701"}

    def __init__(self, rest: RestLike, component_sector_limit: int = 12) -> None:
        self.rest = rest
        self.component_sector_limit = max(1, int(component_sector_limit))
        self.frames: dict[str, SectorBreadthFrame] = {}
        self.symbol_sector: dict[str, str] = {}
        self._history: dict[str, list[tuple[datetime, float]]] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    async def refresh(self, asof: datetime | None = None) -> list[SectorBreadthFrame]:
        now = asof or datetime.now(timezone.utc)
        catalog_rows: list[tuple[MarketClass, dict[str, Any]]] = []
        try:
            for root, market in (("001", MarketClass.KOSPI), ("101", MarketClass.KOSDAQ)):
                page = await self.rest.post(self.CATALOG_API, self.PATH, {"inds_cd": root})
                for row in page.body.get("all_inds_idex", []) or []:
                    if isinstance(row, dict):
                        catalog_rows.append((market, row))

            base_frames: list[SectorBreadthFrame] = []
            for market, row in catalog_rows:
                frame = self._catalog_frame(market, row, now)
                if frame is not None:
                    base_frames.append(frame)

            # Load members only for sectors with the strongest current breadth evidence.
            ranked = sorted(
                [f for f in base_frames if f.sector_code not in self.AGGREGATE_CODES],
                key=self._sector_priority, reverse=True
            )
            expanded_codes = {f.sector_code for f in ranked[: self.component_sector_limit]}
            out: list[SectorBreadthFrame] = []
            self.symbol_sector = {}
            for frame in base_frames:
                if frame.sector_code in expanded_codes:
                    frame = await self._expand_members(frame)
                out.append(frame)
                self.frames[frame.sector_code] = frame
            self.last_refresh_at = now
            self.last_error = None
            return out
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            raise

    def _catalog_frame(self, market: MarketClass, row: dict[str, Any], now: datetime) -> SectorBreadthFrame | None:
        code_raw = str(row.get("stk_cd") or "").strip()
        code = code_raw.split("_")[0]
        if not code:
            return None
        rising = _num(row.get("rising"))
        falling = _num(row.get("fall"))
        listed = _num(row.get("flo_stk_num"))
        breadth = None
        denom = (rising or 0.0) + (falling or 0.0)
        if denom > 0:
            breadth = (rising or 0.0) / denom * 100.0
        velocity, acceleration = self._kinematics(code, now, breadth)
        score = self._score(
            breadth=breadth,
            velocity=velocity,
            acceleration=acceleration,
            sector_change=_num(row.get("flu_rt")),
            member_positive=None,
        )
        return SectorBreadthFrame(
            sector_code=code,
            sector_name=str(row.get("stk_nm")) if row.get("stk_nm") is not None else None,
            market=market,
            asof=now,
            change_rate=_num(row.get("flu_rt")),
            turnover_raw=_num(row.get("trde_prica")),
            listed_count=int(listed) if listed is not None else None,
            rising_count=int(rising) if rising is not None else None,
            falling_count=int(falling) if falling is not None else None,
            breadth_ratio=breadth,
            breadth_velocity_ppm=velocity,
            breadth_acceleration_ppm2=acceleration,
            member_count=0,
            member_positive_ratio=None,
            member_median_change=None,
            leader_change_rate=None,
            score_15=round(score, 4),
        )

    async def _expand_members(self, base: SectorBreadthFrame) -> SectorBreadthFrame:
        mrkt_tp = "0" if base.market == MarketClass.KOSPI else "1"
        page = await self.rest.post(self.COMPONENT_API, self.PATH, {"mrkt_tp": mrkt_tp, "inds_cd": base.sector_code})
        rows = page.body.get("inds_stkpc", []) or []
        changes: list[float] = []
        positives = 0
        count = 0
        leader: float | None = None
        for row in rows:
            if not isinstance(row, dict):
                continue
            symbol = _symbol(row.get("stk_cd"))
            if not symbol:
                continue
            self.symbol_sector[symbol] = base.sector_code
            count += 1
            change = _num(row.get("flu_rt"))
            if change is not None:
                changes.append(change)
                if change > 0:
                    positives += 1
                leader = change if leader is None else max(leader, change)
        positive_ratio = positives / len(changes) * 100.0 if changes else None
        med = median(changes) if changes else None
        score = self._score(
            breadth=base.breadth_ratio,
            velocity=base.breadth_velocity_ppm,
            acceleration=base.breadth_acceleration_ppm2,
            sector_change=base.change_rate,
            member_positive=positive_ratio,
        )
        return SectorBreadthFrame(
            **{**base.__dict__, "member_count": count, "member_positive_ratio": positive_ratio,
               "member_median_change": med, "leader_change_rate": leader, "score_15": round(score, 4)}
        )

    def _kinematics(self, code: str, now: datetime, breadth: float | None) -> tuple[float | None, float | None]:
        if breadth is None:
            return None, None
        hist = self._history.setdefault(code, [])
        hist.append((now, breadth))
        hist[:] = hist[-3:]
        velocity = None
        acceleration = None
        if len(hist) >= 2:
            dt = max((hist[-1][0] - hist[-2][0]).total_seconds() / 60.0, 1e-6)
            velocity = (hist[-1][1] - hist[-2][1]) / dt
        if len(hist) >= 3:
            dt1 = max((hist[-2][0] - hist[-3][0]).total_seconds() / 60.0, 1e-6)
            dt2 = max((hist[-1][0] - hist[-2][0]).total_seconds() / 60.0, 1e-6)
            v1 = (hist[-2][1] - hist[-3][1]) / dt1
            v2 = (hist[-1][1] - hist[-2][1]) / dt2
            acceleration = (v2 - v1) / max((dt1 + dt2) / 2.0, 1e-6)
        return velocity, acceleration

    @staticmethod
    def _score(*, breadth: float | None, velocity: float | None, acceleration: float | None,
               sector_change: float | None, member_positive: float | None) -> float:
        score = 0.0
        if breadth is not None:
            if breadth >= 70: score += 4.0
            elif breadth >= 60: score += 3.0
            elif breadth >= 52: score += 1.5
        if velocity is not None:
            if velocity >= 2.0: score += 3.0
            elif velocity > 0: score += 1.5
        if acceleration is not None:
            if acceleration >= 0.5: score += 3.0
            elif acceleration > 0: score += 1.5
        if sector_change is not None:
            if 0.2 <= sector_change <= 4.0: score += 2.0
            elif sector_change > 0: score += 1.0
        if member_positive is not None:
            if member_positive >= 65: score += 3.0
            elif member_positive >= 55: score += 1.5
        return min(score, 15.0)

    @staticmethod
    def _sector_priority(frame: SectorBreadthFrame) -> tuple[float, float, float, float]:
        return (
            frame.score_15,
            frame.breadth_acceleration_ppm2 or -999.0,
            frame.breadth_velocity_ppm or -999.0,
            frame.breadth_ratio or -999.0,
        )

    def score_for(self, symbol: str) -> float | None:
        code = self.symbol_sector.get(symbol[:6])
        if code is None:
            return None
        frame = self.frames.get(code)
        return frame.score_15 if frame else None

    def frame_for(self, symbol: str, asof: datetime | None = None, max_age_sec: float = 180.0) -> SectorBreadthFrame | None:
        code = self.symbol_sector.get(symbol[:6])
        frame = self.frames.get(code) if code else None
        if frame is None:
            return None
        if asof is not None and (asof - frame.asof).total_seconds() > max_age_sec:
            return None
        return frame
