from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Protocol
from zoneinfo import ZoneInfo

from pulse_edge.feed.rest import RestPage

KST = ZoneInfo("Asia/Seoul")


def _num(v) -> float | None:
    if v is None or str(v).strip() == "":
        return None
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


class RestLike(Protocol):
    async def post(self, api_id: str, path: str, body: dict, cont_yn: str | None = None, next_key: str | None = None) -> RestPage: ...


@dataclass
class RecentInvestorFlow:
    symbol: str
    name: str | None
    period_days: int
    foreign_net_amount: float | None
    institution_net_amount: float | None
    foreign_streak_days: float | None
    institution_streak_days: float | None
    asof: datetime
    source_api_id: str = "ka10131"
    schema_validated: bool = True


@dataclass
class IntradayInvestorFlow:
    symbol: str
    name: str | None
    actor: str
    net_value: float | None
    buy_value: float | None
    sell_value: float | None
    asof: datetime
    source_api_id: str = "ka10065"
    schema_validated: bool = True
    unit: str = "RANK_NATIVE"


@dataclass
class InvestorBreakdown:
    """Per-symbol investor breakdown from ka10060.

    Values are native ka10060 amount fields (documented as KRW million when
    amt_qty_tp=1). They are treated as ESTIMATED for intraday use until live
    timing/settlement behavior is validated by Phase 6A evidence.
    """

    symbol: str
    source_date: date
    asof: datetime
    foreign: float | None = None
    institution: float | None = None
    financial_investment: float | None = None
    insurance: float | None = None
    fund: float | None = None
    other_financial: float | None = None
    bank: float | None = None
    pension: float | None = None
    private_fund: float | None = None
    nation: float | None = None
    other_corporation: float | None = None
    domestic_foreign: float | None = None
    source_api_id: str = "ka10060"
    schema_validated: bool = True
    unit: str = "KRW_MILLION"


class InvestorSchemaError(RuntimeError):
    pass


class InvestorFlowService:
    """Read-only investor facts with strict schema/provenance checks."""

    RANK_API_ID = "ka10065"
    RANK_PATH = "/api/dostk/rkinfo"
    BREAKDOWN_API_ID = "ka10060"
    BREAKDOWN_PATH = "/api/dostk/chart"

    def __init__(self, rest: RestLike) -> None:
        self.rest = rest
        self.recent: dict[tuple[str, int], RecentInvestorFlow] = {}
        self.intraday: dict[tuple[str, str], IntradayInvestorFlow] = {}
        self.breakdown: dict[str, InvestorBreakdown] = {}
        self.last_schema_error: str | None = None

    def _require_response_api(self, page: RestPage, expected: str) -> None:
        actual = (page.response_api_id or "").strip()
        if actual and actual != expected:
            self.last_schema_error = f"response api-id mismatch: expected {expected}, got {actual}"
            raise InvestorSchemaError(self.last_schema_error)

    async def load_recent(self, period_days: int, market: str, exchange: str = "3") -> list[RecentInvestorFlow]:
        if period_days not in {1, 3, 5, 10, 20, 120}:
            raise ValueError("unsupported period")
        page = await self.rest.post("ka10131", "/api/dostk/frgnistt", {
            "dt": str(period_days), "mrkt_tp": market, "netslmt_tp": "2",
            "stk_inds_tp": "0", "amt_qty_tp": "0", "stex_tp": exchange,
            "strt_dt": "", "end_dt": "",
        })
        self._require_response_api(page, "ka10131")
        rows = page.body.get("orgn_frgnr_cont_trde_prst")
        if not isinstance(rows, list):
            self.last_schema_error = "ka10131 missing orgn_frgnr_cont_trde_prst"
            raise InvestorSchemaError(self.last_schema_error)
        now = datetime.now(timezone.utc)
        out: list[RecentInvestorFlow] = []
        for r in rows:
            if not isinstance(r, dict) or "stk_cd" not in r:
                continue
            row = RecentInvestorFlow(
                symbol=str(r.get("stk_cd") or "")[:6], name=r.get("stk_nm"), period_days=period_days,
                foreign_net_amount=_num(r.get("frgnr_nettrde_amt")),
                institution_net_amount=_num(r.get("orgn_nettrde_amt")),
                foreign_streak_days=_num(r.get("frgnr_cont_netprps_dys")),
                institution_streak_days=_num(r.get("orgn_cont_netprps_dys")),
                asof=now,
            )
            if row.symbol:
                self.recent[(row.symbol, period_days)] = row
                out.append(row)
        self.last_schema_error = None
        return out

    async def load_intraday_rank(self, actor: str, market: str = "000", side: str = "1", amount_or_qty: str = "1") -> list[IntradayInvestorFlow]:
        actor_code = {
            "FOREIGN": "9000", "INSTITUTION": "9999", "FINANCIAL": "1000",
            "FUND": "3000", "INSURANCE": "2000", "PENSION": "6000",
            "OTHER_CORP": "7100",
        }[actor.upper()]
        page = await self.rest.post(self.RANK_API_ID, self.RANK_PATH, {
            "trde_tp": side, "mrkt_tp": market, "orgn_tp": actor_code, "amt_qty_tp": amount_or_qty,
        })
        self._require_response_api(page, self.RANK_API_ID)
        rows = page.body.get("opmr_invsr_trde_upper")
        if not isinstance(rows, list):
            self.last_schema_error = f"{self.RANK_API_ID} missing opmr_invsr_trde_upper"
            raise InvestorSchemaError(self.last_schema_error)
        now = datetime.now(timezone.utc)
        out: list[IntradayInvestorFlow] = []
        for r in rows:
            if not isinstance(r, dict) or "stk_cd" not in r or "netslmt" not in r:
                continue
            row = IntradayInvestorFlow(
                str(r.get("stk_cd") or "")[:6], r.get("stk_nm"), actor.upper(),
                _num(r.get("netslmt")), _num(r.get("buy_qty")), _num(r.get("sel_qty")), now,
                source_api_id=self.RANK_API_ID, schema_validated=True,
            )
            if row.symbol:
                self.intraday[(row.symbol, row.actor)] = row
                out.append(row)
        self.last_schema_error = None
        return out

    async def load_breakdown(self, symbol: str, dt: date | None = None) -> InvestorBreakdown | None:
        """Load KRX per-symbol detailed actor amounts through documented ka10060.

        No NXT suffix is accepted here. This prevents KRX investor facts from
        being presented as NXT-native flow.
        """
        raw_symbol = str(symbol or "").strip()
        if len(raw_symbol) != 6 or not raw_symbol.isdigit():
            raise ValueError("ka10060 investor breakdown is KRX six-digit-symbol only; NXT/alternate venue symbols are forbidden")
        symbol = raw_symbol
        target = dt or datetime.now(timezone.utc).astimezone(KST).date()
        page = await self.rest.post(self.BREAKDOWN_API_ID, self.BREAKDOWN_PATH, {
            "dt": target.strftime("%Y%m%d"), "stk_cd": symbol,
            "amt_qty_tp": "1", "trde_tp": "0", "unit_tp": "1",
        })
        self._require_response_api(page, self.BREAKDOWN_API_ID)
        rows = page.body.get("stk_invsr_orgn_chart")
        if not isinstance(rows, list):
            self.last_schema_error = "ka10060 missing stk_invsr_orgn_chart"
            raise InvestorSchemaError(self.last_schema_error)
        target_str = target.strftime("%Y%m%d")
        src: dict | None = None
        for r in rows:
            if isinstance(r, dict) and str(r.get("dt") or "") == target_str:
                src = r
                break
        if src is None and rows and isinstance(rows[0], dict):
            # Never relabel a different date as current. Keep unavailable.
            self.last_schema_error = None
            return None
        if src is None:
            return None
        now = datetime.now(timezone.utc)
        row = InvestorBreakdown(
            symbol=symbol, source_date=target, asof=now,
            foreign=_num(src.get("frgnr_invsr")), institution=_num(src.get("orgn")),
            financial_investment=_num(src.get("fnnc_invt")), insurance=_num(src.get("insrnc")),
            fund=_num(src.get("invtrt")), other_financial=_num(src.get("etc_fnnc")),
            bank=_num(src.get("bank")), pension=_num(src.get("penfnd_etc")),
            private_fund=_num(src.get("samo_fund")), nation=_num(src.get("natn")),
            other_corporation=_num(src.get("etc_corp")), domestic_foreign=_num(src.get("natfor")),
        )
        self.breakdown[symbol] = row
        self.last_schema_error = None
        return row
