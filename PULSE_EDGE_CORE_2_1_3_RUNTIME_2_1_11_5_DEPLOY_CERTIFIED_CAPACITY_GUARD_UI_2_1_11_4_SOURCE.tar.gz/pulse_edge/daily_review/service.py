from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, time, timezone
from statistics import fmean
from zoneinfo import ZoneInfo

from pulse_edge.absorption.models import AbsorptionStage
from pulse_edge.missed_opportunity.models import OpportunityStatus
from .models import DailyReviewRecord, DailyScoreCard, NextSessionReference, ReviewGrade, ReviewStatus, RuleProposal

KST = ZoneInfo("Asia/Seoul")
TRACKED_STAGES = {
    AbsorptionStage.ABSORB.value,
    AbsorptionStage.PRICE_HOLD.value,
    AbsorptionStage.SUPPLY_TIGHT.value,
    AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED.value,
    AbsorptionStage.PRE_IGNITION.value,
    AbsorptionStage.IGNITION.value,
}


def _avg(values: list[float]) -> float | None:
    return None if not values else round(fmean(values), 4)


def _grade(count: int, avg_return: float | None, win_rate: float | None) -> ReviewGrade:
    if count < 3 or avg_return is None or win_rate is None:
        return ReviewGrade.INSUFFICIENT
    if avg_return > 1.0 and win_rate >= 60.0:
        return ReviewGrade.STRONG
    if avg_return > 0.0 and win_rate >= 50.0:
        return ReviewGrade.ACCEPTABLE
    return ReviewGrade.WEAK


class DailyReviewService:
    """19:00 KST one-way review over Phase 6C/6F/6G evidence.

    The service can propose investigations but cannot mutate any current score,
    rank, gate, model, stage or NXT state.
    """

    def __init__(
        self,
        *,
        store,
        dual_store,
        missed_store,
        transition_store,
        enrichment,
        review_time: time = time(19, 0),
        min_evidence_for_proposal: int = 3,
    ):
        self.store = store
        self.dual_store = dual_store
        self.missed_store = missed_store
        self.transition_store = transition_store
        self.enrichment = enrichment
        self.review_time = review_time
        self.min_evidence_for_proposal = max(1, int(min_evidence_for_proposal))
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self.last_result: DailyReviewRecord | None = None

    def refresh(self, asof: datetime | None = None, *, force: bool = False) -> DailyReviewRecord | None:
        now = asof or datetime.now(timezone.utc)
        local = now.astimezone(KST)
        day = local.date().isoformat()
        if not force and local.time() < self.review_time:
            return None
        result = self.build(day, now)
        if result.status != ReviewStatus.NO_SESSION_EVIDENCE:
            self.store.upsert(result)
        self.last_result = result
        self.last_refresh_at = now
        self.last_error = None
        return result

    def build(self, trading_day: str, now: datetime) -> DailyReviewRecord:
        signals = list(self.dual_store.active_day_signals(trading_day)) if self.dual_store else []
        missed_summary = self.missed_store.summary(trading_day) if self.missed_store else {"count": 0, "status": {}, "primary_reasons": {}}
        close_rows = list(self.transition_store.close_rows(trading_day, 1000)) if self.transition_store else []
        enrichment_rows = list(self.enrichment.frames.values()) if self.enrichment else []

        model_cards, stage_cards, model_stage_cards, evaluated = self._score_cards(signals)
        transition_rates = self._transition_rates(trading_day, signals)

        status_counts = Counter(missed_summary.get("status", {}))
        caught = int(missed_summary.get("status", {}).get(OpportunityStatus.CAUGHT_PREEMPTIVE.value, 0))
        missed = int(missed_summary.get("status", {}).get(OpportunityStatus.MISSED.value, 0))
        excluded = int(missed_summary.get("status", {}).get(OpportunityStatus.EXCLUDED_OR_UNVERIFIED.value, 0))
        denom = caught + missed
        catch_rate = None if denom == 0 else round(caught * 100.0 / denom, 2)
        miss_reasons = Counter({k: int(v) for k, v in missed_summary.get("primary_reasons", {}).items()})
        close_counts = Counter(r["classification"] for r in close_rows)
        coverage, gaps = self._coverage(enrichment_rows)
        strengths, weaknesses = self._observations(model_cards, stage_cards, catch_rate, miss_reasons, coverage)
        proposals = self._proposals(model_cards, stage_cards, miss_reasons, catch_rate, coverage)
        focus = self._focus(trading_day, close_rows)

        opportunity_count = int(missed_summary.get("count", 0))
        has_any = bool(signals or opportunity_count or close_rows or enrichment_rows)
        source_flags = [bool(signals), bool(opportunity_count), bool(enrichment_rows), bool(close_rows)]
        status = ReviewStatus.NO_SESSION_EVIDENCE if not has_any else ReviewStatus.COMPLETE if all(source_flags[:3]) else ReviewStatus.PARTIAL
        return DailyReviewRecord(
            trading_day=trading_day,
            generated_at=now,
            status=status,
            source_dual_performance=bool(signals),
            source_missed_opportunity=bool(opportunity_count),
            source_current_enrichment=bool(enrichment_rows),
            source_close_classification=bool(close_rows),
            dual_signal_count=len(signals),
            evaluated_signal_count=evaluated,
            model_cards=model_cards,
            stage_cards=stage_cards,
            model_stage_cards=model_stage_cards,
            transition_rates=transition_rates,
            surge_total=opportunity_count,
            caught_preemptive=caught,
            missed=missed,
            excluded_or_unverified=excluded,
            catch_rate_pct=catch_rate,
            primary_miss_reasons=dict(miss_reasons.most_common()),
            close_class_counts=dict(close_counts),
            enrichment_rows=len(enrichment_rows),
            enrichment_coverage=coverage,
            data_gaps=gaps,
            strengths=strengths,
            weaknesses=weaknesses,
            rule_proposals=proposals,
            next_session_focus=focus,
        )

    def _score_cards(self, signals):
        buckets = {"MODEL": defaultdict(list), "STAGE": defaultdict(list), "MODEL_STAGE": defaultdict(list)}
        evaluated = 0
        for row in signals:
            outcomes = {o["horizon"]: o for o in self.dual_store.outcome_rows(row["signal_id"]) if o["status"] == "CAPTURED" and o["return_pct"] is not None}
            horizon = next((h for h in ("CLOSE", "30M", "10M") if h in outcomes), None)
            ret = None if horizon is None else float(outcomes[horizon]["return_pct"])
            if ret is not None:
                evaluated += 1
            payload = {
                "ret": ret,
                "horizon": horizon,
                "mfe": float(row["mfe_pct"]),
                "mae": float(row["mae_pct"]),
            }
            buckets["MODEL"][row["model"]].append(payload)
            buckets["STAGE"][row["stage"]].append(payload)
            buckets["MODEL_STAGE"][f"{row['model']}|{row['stage']}"] .append(payload)

        def cards(kind: str):
            result = []
            for key, items in sorted(buckets[kind].items()):
                rets = [x["ret"] for x in items if x["ret"] is not None]
                horizons = Counter(x["horizon"] for x in items if x["horizon"])
                avg_ret = _avg(rets)
                win = None if not rets else round(sum(x > 0 for x in rets) * 100.0 / len(rets), 2)
                result.append(DailyScoreCard(
                    group=f"{kind}:{key}", signal_count=len(items), evaluated_count=len(rets),
                    primary_horizon=horizons.most_common(1)[0][0] if horizons else None,
                    avg_return_pct=avg_ret, win_rate_pct=win,
                    mfe_avg_pct=_avg([x["mfe"] for x in items]), mae_avg_pct=_avg([x["mae"] for x in items]),
                    grade=_grade(len(rets), avg_ret, win),
                ))
            return result
        return cards("MODEL"), cards("STAGE"), cards("MODEL_STAGE"), evaluated

    def _transition_rates(self, trading_day: str, signals):
        if not self.dual_store:
            return []
        transitions = [t for t in self.dual_store.transitions(5000) if t["trading_day"] == trading_day]
        den = Counter((r["model"], r["stage"]) for r in signals)
        num = Counter((t["model"], t["from_stage"], t["to_stage"]) for t in transitions)
        return [{
            "model": m, "from_stage": a, "to_stage": b, "transitions": n,
            "source_signals": den.get((m, a), 0),
            "transition_rate_pct": None if not den.get((m, a)) else round(n * 100.0 / den[(m, a)], 2),
        } for (m, a, b), n in sorted(num.items())]

    @staticmethod
    def _coverage(rows):
        if not rows:
            return {}, ["CURRENT_ENRICHMENT_UNAVAILABLE"]
        fields = [
            "return_1d_pct", "return_3d_pct", "return_5d_pct", "same_time_avg20_money_5m",
            "avg20_daily_volume", "avg20_daily_traded_value_raw", "market_cap_est_krw", "sector_money_stage",
        ]
        coverage = {}
        gaps = []
        n = len(rows)
        for name in fields:
            ok = 0
            for row in rows:
                value = getattr(row, name, None)
                if value is not None and value != "NO_DATA":
                    ok += 1
            pct = round(ok * 100.0 / n, 2)
            coverage[name] = pct
            if pct < 70.0:
                gaps.append(f"LOW_COVERAGE:{name}:{pct}")
        coverage["row_count"] = n
        return coverage, gaps

    @staticmethod
    def _observations(model_cards, stage_cards, catch_rate, reasons, coverage):
        strengths, weaknesses = [], []
        strong = [c for c in [*model_cards, *stage_cards] if c.grade == ReviewGrade.STRONG]
        weak = [c for c in [*model_cards, *stage_cards] if c.grade == ReviewGrade.WEAK]
        if strong:
            strengths.append("STRONG_GROUPS:" + ",".join(c.group for c in strong[:5]))
        if catch_rate is not None and catch_rate >= 70:
            strengths.append(f"PREEMPTIVE_CATCH_RATE:{catch_rate}")
        if weak:
            weaknesses.append("WEAK_GROUPS:" + ",".join(c.group for c in weak[:5]))
        if catch_rate is not None and catch_rate < 50:
            weaknesses.append(f"LOW_PREEMPTIVE_CATCH_RATE:{catch_rate}")
        if reasons:
            weaknesses.append("TOP_MISS_REASON:" + reasons.most_common(1)[0][0])
        low = [k for k, v in coverage.items() if isinstance(v, (int, float)) and k != "row_count" and v < 70]
        if low:
            weaknesses.append("LOW_DATA_COVERAGE:" + ",".join(low[:5]))
        return strengths, weaknesses

    def _proposals(self, model_cards, stage_cards, reasons, catch_rate, coverage):
        out: list[RuleProposal] = []
        threshold = self.min_evidence_for_proposal
        for reason, count in reasons.most_common():
            if count < threshold:
                continue
            mapping = {
                "DATA_COVERAGE_MISS": "Increase current-session coverage and rotation reliability before changing signal thresholds.",
                "DISCOVERY_EVIDENCE_ABSENT": "Audit discovery source coverage; do not loosen PRICE HOLD.",
                "PRICE_HOLD_FAILED": "Review whether defense evidence arrived late; keep PRICE HOLD as a hard gate until larger samples prove otherwise.",
                "ABSORPTION_WEAK": "Review counterparty-flow timing and actor freshness; do not auto-lower the 0.70 meaningful-absorption reference.",
                "SELL_DECEL_INSUFFICIENT": "Inspect sell-velocity sampling cadence and missed deceleration intervals before changing thresholds.",
                "PROGRAM_DATA_UNAVAILABLE": "Improve program-flow availability and freshness rather than inferring missing values as zero.",
                "SECTOR_BREADTH_WEAK": "Check whether isolated stock strength lacked sector confirmation; preserve breadth as corroborating evidence.",
                "SECTOR_BREADTH_UNAVAILABLE": "Improve sector-member coverage before changing breadth thresholds.",
                "PREIGNITION_NOT_REACHED": "Compare PRICE HOLD/SUPPLY TIGHT lead time against ignition timing; review only after sufficient samples.",
                "LATE_DETECTION": "Audit discovery and PRICE HOLD lead-time to reduce post-5% detection.",
            }
            proposal = mapping.get(reason, "Review this repeated miss pattern with a larger sample before changing any rule.")
            out.append(RuleProposal(code=f"REVIEW_{reason}", priority=min(100, 50 + count * 5), reason=reason, evidence_count=count, proposal=proposal))
        for card in [*model_cards, *stage_cards]:
            if card.evaluated_count >= max(5, threshold) and card.grade == ReviewGrade.WEAK:
                out.append(RuleProposal(
                    code="REVIEW_WEAK_GROUP_" + card.group.replace(":", "_").replace("|", "_"),
                    priority=65, reason=card.group, evidence_count=card.evaluated_count,
                    proposal="Review this group's lead-time, MFE/MAE and hard-gate failures. Do not change weights automatically.",
                ))
        if catch_rate is not None and catch_rate < 50:
            denom = sum(reasons.values())
            out.append(RuleProposal(
                code="REVIEW_LOW_CATCH_RATE", priority=90, reason=f"catch_rate={catch_rate}", evidence_count=denom,
                proposal="Prioritize false-negative analysis and coverage gaps before any score optimization.",
            ))
        if coverage and any(isinstance(v, (int, float)) and k != "row_count" and v < 70 for k, v in coverage.items()):
            out.append(RuleProposal(
                code="REVIEW_DATA_COMPLETENESS", priority=80, reason="one_or_more_fields_below_70pct", evidence_count=int(coverage.get("row_count", 0) or 0),
                proposal="Raise data completeness first; unavailable fields must remain unavailable and must not be zero-filled.",
            ))
        out.sort(key=lambda x: (-x.priority, -x.evidence_count, x.code))
        return out[:10]

    @staticmethod
    def _focus(trading_day: str, close_rows):
        priority = {"CLOSE_PRE_IGNITION": 0, "SUPPLY_TIGHT_OVERNIGHT": 1, "PRICE_HOLD_OVERNIGHT": 2}
        eligible = [r for r in close_rows if r["classification"] in priority]
        eligible.sort(key=lambda r: (priority[r["classification"]], -float(r["score_100"]), r["symbol"]))
        return [NextSessionReference(
            symbol=str(r["symbol"]), classification=str(r["classification"]), model=str(r["model"]),
            score_100=float(r["score_100"]), source_day=trading_day,
        ) for r in eligible[:10]]
