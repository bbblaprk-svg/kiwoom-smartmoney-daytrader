from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from .models import DailyReviewRecord, DailyScoreCard, ReviewGrade, ReviewStatus, RuleProposal


def _iso(v: datetime) -> str:
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.astimezone(timezone.utc).isoformat()


def _dt(v: str) -> datetime:
    x = datetime.fromisoformat(v)
    return x if x.tzinfo else x.replace(tzinfo=timezone.utc)


class DailyReviewStore:
    """Phase 7A archive only. Review history never supplies current selection inputs."""

    def __init__(self, path: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._schema()

    def _schema(self) -> None:
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS daily_review(
              trading_day TEXT PRIMARY KEY,
              generated_at TEXT NOT NULL,
              status TEXT NOT NULL,
              payload_json TEXT NOT NULL,
              history_feeds_current_ranking INTEGER NOT NULL DEFAULT 0,
              history_feeds_current_score INTEGER NOT NULL DEFAULT 0,
              proposals_apply_automatically INTEGER NOT NULL DEFAULT 0,
              official_signal_enabled INTEGER NOT NULL DEFAULT 0,
              order_action_enabled INTEGER NOT NULL DEFAULT 0,
              morning_briefing_exists INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_daily_review_time ON daily_review(generated_at DESC);
            """
        )
        self._db.commit()

    def upsert(self, x: DailyReviewRecord) -> None:
        payload = x.model_dump(mode="json")
        with self._lock:
            self._db.execute(
                """INSERT INTO daily_review(
                trading_day,generated_at,status,payload_json,history_feeds_current_ranking,history_feeds_current_score,
                proposals_apply_automatically,official_signal_enabled,order_action_enabled,morning_briefing_exists)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(trading_day) DO UPDATE SET generated_at=excluded.generated_at,status=excluded.status,
                payload_json=excluded.payload_json,history_feeds_current_ranking=0,history_feeds_current_score=0,
                proposals_apply_automatically=0,official_signal_enabled=0,order_action_enabled=0,morning_briefing_exists=0""",
                (
                    x.trading_day,_iso(x.generated_at),x.status.value,json.dumps(payload,ensure_ascii=False),0,0,0,0,0,0,
                ),
            )
            self._db.commit()

    def get(self, trading_day: str) -> DailyReviewRecord | None:
        row = self._db.execute("SELECT payload_json FROM daily_review WHERE trading_day=?", (trading_day,)).fetchone()
        if not row:
            return None
        return DailyReviewRecord.model_validate(json.loads(row["payload_json"]))

    def recent(self, limit: int = 30) -> list[DailyReviewRecord]:
        rows = self._db.execute("SELECT payload_json FROM daily_review ORDER BY trading_day DESC LIMIT ?", (limit,)).fetchall()
        return [DailyReviewRecord.model_validate(json.loads(r["payload_json"])) for r in rows]

    def close(self) -> None:
        self._db.close()
