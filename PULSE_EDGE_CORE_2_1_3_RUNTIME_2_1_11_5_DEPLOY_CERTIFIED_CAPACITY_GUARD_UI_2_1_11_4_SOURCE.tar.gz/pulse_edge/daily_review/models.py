from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class ReviewStatus(StrEnum):
    COMPLETE = "COMPLETE"
    PARTIAL = "PARTIAL"
    NO_SESSION_EVIDENCE = "NO_SESSION_EVIDENCE"


class ReviewGrade(StrEnum):
    STRONG = "STRONG"
    ACCEPTABLE = "ACCEPTABLE"
    WEAK = "WEAK"
    INSUFFICIENT = "INSUFFICIENT"


class DailyScoreCard(BaseModel):
    group: str
    signal_count: int = 0
    evaluated_count: int = 0
    primary_horizon: str | None = None
    avg_return_pct: float | None = None
    win_rate_pct: float | None = None
    mfe_avg_pct: float | None = None
    mae_avg_pct: float | None = None
    grade: ReviewGrade = ReviewGrade.INSUFFICIENT


class RuleProposal(BaseModel):
    code: str
    priority: int
    reason: str
    evidence_count: int = 0
    proposal: str
    apply_automatically: bool = False
    feeds_current_score: bool = False
    feeds_current_ranking: bool = False


class NextSessionReference(BaseModel):
    symbol: str
    classification: str
    model: str
    score_100: float
    source_day: str
    reference_only: bool = True
    feeds_next_session_current_facts: bool = False
    feeds_current_ranking: bool = False
    feeds_current_score: bool = False


class DailyReviewRecord(BaseModel):
    trading_day: str
    generated_at: datetime
    status: ReviewStatus
    source_dual_performance: bool = False
    source_missed_opportunity: bool = False
    source_current_enrichment: bool = False
    source_close_classification: bool = False

    dual_signal_count: int = 0
    evaluated_signal_count: int = 0
    model_cards: list[DailyScoreCard] = Field(default_factory=list)
    stage_cards: list[DailyScoreCard] = Field(default_factory=list)
    model_stage_cards: list[DailyScoreCard] = Field(default_factory=list)
    transition_rates: list[dict] = Field(default_factory=list)

    surge_total: int = 0
    caught_preemptive: int = 0
    missed: int = 0
    excluded_or_unverified: int = 0
    catch_rate_pct: float | None = None
    primary_miss_reasons: dict[str, int] = Field(default_factory=dict)

    close_class_counts: dict[str, int] = Field(default_factory=dict)
    enrichment_rows: int = 0
    enrichment_coverage: dict[str, float | int | None] = Field(default_factory=dict)
    data_gaps: list[str] = Field(default_factory=list)

    strengths: list[str] = Field(default_factory=list)
    weaknesses: list[str] = Field(default_factory=list)
    rule_proposals: list[RuleProposal] = Field(default_factory=list)
    next_session_focus: list[NextSessionReference] = Field(default_factory=list)

    history_feeds_current_ranking: bool = False
    history_feeds_current_score: bool = False
    proposals_apply_automatically: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    morning_briefing_exists: bool = False
