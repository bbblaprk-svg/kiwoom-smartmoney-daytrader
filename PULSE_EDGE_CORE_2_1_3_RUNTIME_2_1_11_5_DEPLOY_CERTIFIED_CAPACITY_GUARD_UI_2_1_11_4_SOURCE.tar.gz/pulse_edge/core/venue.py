from __future__ import annotations

from .models import Venue


def split_item(item: str | None) -> tuple[str | None, Venue]:
    if not item:
        return None, Venue.UNKNOWN
    value = str(item).strip()
    if value.endswith("_NX"):
        return value[:-3], Venue.NXT
    if value.endswith("_AL"):
        return value[:-3], Venue.SOR
    if value.isdigit() and len(value) >= 6:
        return value[:6], Venue.KRX
    return value, Venue.UNKNOWN
