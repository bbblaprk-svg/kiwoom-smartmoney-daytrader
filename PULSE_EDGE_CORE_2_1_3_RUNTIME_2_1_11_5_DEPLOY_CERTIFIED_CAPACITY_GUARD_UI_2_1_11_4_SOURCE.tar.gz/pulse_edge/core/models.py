from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from pydantic import BaseModel, Field


class Venue(StrEnum):
    KRX = "KRX"
    NXT = "NXT"
    SOR = "SOR"
    UNKNOWN = "UNKNOWN"


class TruthStatus(StrEnum):
    LIVE = "LIVE"
    PARTIAL = "PARTIAL"
    STALE = "STALE"
    INVALID = "INVALID"


class RawEvent(BaseModel):
    receive_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source: str = "KIWOOM_WS"
    payload: dict[str, Any]


class NormalizedEvent(BaseModel):
    receive_time: datetime
    event_time: datetime | None = None
    source: str
    trnm: str | None = None
    real_type: str | None = None
    name: str | None = None
    item: str | None = None
    symbol: str | None = None
    venue: Venue = Venue.UNKNOWN
    data: dict[str, Any] = Field(default_factory=dict)
    values: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)


class TruthResult(BaseModel):
    status: TruthStatus
    reasons: list[str] = Field(default_factory=list)
    receive_age_sec: float | None = None
    event_age_sec: float | None = None
    event: NormalizedEvent | None = None
