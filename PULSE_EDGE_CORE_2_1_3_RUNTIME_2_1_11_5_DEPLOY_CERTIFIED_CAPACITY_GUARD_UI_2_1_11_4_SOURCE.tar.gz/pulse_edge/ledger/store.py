from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable

from pulse_edge.core.models import Venue
from pulse_edge.ledger.models import EpisodeStatus, OutcomeHorizon, SignalEpisode, SignalEvent, SignalOutcome


def _iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


def _dt(value: str | None) -> datetime | None:
    if not value:
        return None
    out = datetime.fromisoformat(value)
    return out if out.tzinfo else out.replace(tzinfo=timezone.utc)


class SignalLedgerStore:
    """Historical verification store only.

    This database never supplies current rows, ranks, scores, or current decision rows.
    It is deliberately one-way: current PULSE decision state -> historical ledger.
    """

    def __init__(self, path: str) -> None:
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._db.execute("PRAGMA foreign_keys=ON")
            self._create_schema()

    def _create_schema(self) -> None:
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS signal_episode (
                episode_id TEXT PRIMARY KEY,
                trading_day TEXT NOT NULL,
                venue TEXT NOT NULL,
                symbol TEXT NOT NULL,
                first_seen_at TEXT NOT NULL,
                first_seen_price REAL,
                first_route TEXT,
                signal_at TEXT NOT NULL,
                signal_price REAL NOT NULL,
                primary_route TEXT NOT NULL,
                current_stage TEXT NOT NULL,
                last_stage_at TEXT NOT NULL,
                last_price REAL,
                highest_price REAL,
                lowest_price REAL,
                mfe_pct REAL,
                mae_pct REAL,
                evidence_count INTEGER NOT NULL DEFAULT 0,
                confluence_grade TEXT,
                confluence_score_100 REAL,
                regime_state TEXT,
                smart_flow_state TEXT,
                data_age_sec REAL,
                invalidation_price REAL,
                status TEXT NOT NULL,
                end_at TEXT,
                end_price REAL,
                end_reason TEXT,
                last_update_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_episode_recent ON signal_episode(signal_at DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_symbol ON signal_episode(trading_day, venue, symbol, signal_at DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_status ON signal_episode(status, last_update_at);

            CREATE TABLE IF NOT EXISTS signal_event (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                episode_id TEXT NOT NULL,
                event_at TEXT NOT NULL,
                event_type TEXT NOT NULL,
                stage TEXT,
                price REAL,
                primary_route TEXT,
                evidence_count INTEGER,
                confluence_grade TEXT,
                confluence_score_100 REAL,
                regime_state TEXT,
                smart_flow_state TEXT,
                risk_flags_json TEXT NOT NULL DEFAULT '[]',
                gate_failures_json TEXT NOT NULL DEFAULT '[]',
                details_json TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY(episode_id) REFERENCES signal_episode(episode_id)
            );
            CREATE INDEX IF NOT EXISTS idx_event_episode ON signal_event(episode_id, event_at);

            CREATE TABLE IF NOT EXISTS signal_outcome (
                episode_id TEXT NOT NULL,
                horizon TEXT NOT NULL,
                due_at TEXT,
                captured_at TEXT,
                price REAL,
                return_pct REAL,
                late_by_sec REAL,
                source_trading_day TEXT,
                source_kind TEXT,
                status TEXT NOT NULL DEFAULT 'PENDING',
                PRIMARY KEY(episode_id, horizon),
                FOREIGN KEY(episode_id) REFERENCES signal_episode(episode_id)
            );

            CREATE TABLE IF NOT EXISTS actual_trade (
                trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                episode_id TEXT,
                recorded_at TEXT NOT NULL,
                side TEXT NOT NULL,
                price REAL NOT NULL,
                quantity REAL NOT NULL,
                note TEXT,
                FOREIGN KEY(episode_id) REFERENCES signal_episode(episode_id)
            );
            """
        )
        self._ensure_column("signal_outcome", "source_trading_day", "TEXT")
        self._ensure_column("signal_outcome", "source_kind", "TEXT")
        self._db.commit()

    def _ensure_column(self, table: str, column: str, decl: str) -> None:
        cols = {row[1] for row in self._db.execute(f"PRAGMA table_info({table})").fetchall()}
        if column not in cols:
            self._db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")

    def close(self) -> None:
        with self._lock:
            self._db.commit()
            self._db.close()

    def insert_episode(self, episode: SignalEpisode, outcomes: Iterable[SignalOutcome]) -> None:
        with self._lock:
            self._db.execute(
                """INSERT INTO signal_episode (
                    episode_id,trading_day,venue,symbol,first_seen_at,first_seen_price,first_route,
                    signal_at,signal_price,primary_route,current_stage,last_stage_at,last_price,
                    highest_price,lowest_price,mfe_pct,mae_pct,evidence_count,confluence_grade,
                    confluence_score_100,regime_state,smart_flow_state,data_age_sec,invalidation_price,
                    status,end_at,end_price,end_reason,last_update_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    episode.episode_id, episode.trading_day, episode.venue.value, episode.symbol,
                    _iso(episode.first_seen_at), episode.first_seen_price, episode.first_route,
                    _iso(episode.signal_at), episode.signal_price, episode.primary_route, episode.current_stage,
                    _iso(episode.last_stage_at), episode.last_price, episode.highest_price, episode.lowest_price,
                    episode.mfe_pct, episode.mae_pct, episode.evidence_count, episode.confluence_grade,
                    episode.confluence_score_100, episode.regime_state, episode.smart_flow_state,
                    episode.data_age_sec, episode.invalidation_price, episode.status.value,
                    _iso(episode.end_at), episode.end_price, episode.end_reason, _iso(episode.last_update_at),
                ),
            )
            for outcome in outcomes:
                self._db.execute(
                    "INSERT OR IGNORE INTO signal_outcome (episode_id,horizon,due_at,status) VALUES (?,?,?,?)",
                    (outcome.episode_id, outcome.horizon.value, _iso(outcome.due_at), outcome.status),
                )
            self._db.commit()

    def append_event(self, event: SignalEvent) -> int:
        with self._lock:
            cur = self._db.execute(
                """INSERT INTO signal_event (
                    episode_id,event_at,event_type,stage,price,primary_route,evidence_count,
                    confluence_grade,confluence_score_100,regime_state,smart_flow_state,
                    risk_flags_json,gate_failures_json,details_json
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    event.episode_id, _iso(event.event_at), event.event_type, event.stage, event.price,
                    event.primary_route, event.evidence_count, event.confluence_grade,
                    event.confluence_score_100, event.regime_state, event.smart_flow_state,
                    json.dumps(event.risk_flags, ensure_ascii=False),
                    json.dumps(event.gate_failures, ensure_ascii=False),
                    json.dumps(event.details, ensure_ascii=False),
                ),
            )
            self._db.commit()
            return int(cur.lastrowid)

    def update_episode_sample(
        self,
        episode_id: str,
        *,
        now: datetime,
        price: float | None,
        stage: str | None = None,
        route: str | None = None,
        evidence_count: int | None = None,
        confluence_grade: str | None = None,
        confluence_score_100: float | None = None,
        regime_state: str | None = None,
        smart_flow_state: str | None = None,
        data_age_sec: float | None = None,
        invalidation_price: float | None = None,
    ) -> None:
        with self._lock:
            row = self._db.execute(
                "SELECT signal_price,highest_price,lowest_price,current_stage,primary_route FROM signal_episode WHERE episode_id=?",
                (episode_id,),
            ).fetchone()
            if row is None:
                return
            signal_price = float(row["signal_price"])
            high = row["highest_price"]
            low = row["lowest_price"]
            if price is not None and price > 0:
                high = price if high is None else max(float(high), price)
                low = price if low is None else min(float(low), price)
            mfe = None if high is None or signal_price <= 0 else (float(high) / signal_price - 1.0) * 100.0
            mae = None if low is None or signal_price <= 0 else (float(low) / signal_price - 1.0) * 100.0
            stage_value = stage or row["current_stage"]
            route_value = route or row["primary_route"]
            self._db.execute(
                """UPDATE signal_episode SET
                    current_stage=?, primary_route=?, last_price=?, highest_price=?, lowest_price=?, mfe_pct=?, mae_pct=?,
                    evidence_count=COALESCE(?,evidence_count), confluence_grade=COALESCE(?,confluence_grade),
                    confluence_score_100=COALESCE(?,confluence_score_100), regime_state=COALESCE(?,regime_state),
                    smart_flow_state=COALESCE(?,smart_flow_state), data_age_sec=COALESCE(?,data_age_sec),
                    invalidation_price=COALESCE(?,invalidation_price), last_update_at=?
                    WHERE episode_id=?""",
                (
                    stage_value, route_value, price, high, low, mfe, mae, evidence_count, confluence_grade,
                    confluence_score_100, regime_state, smart_flow_state, data_age_sec, invalidation_price,
                    _iso(now), episode_id,
                ),
            )
            self._db.commit()

    def update_stage_time(self, episode_id: str, now: datetime) -> None:
        with self._lock:
            self._db.execute("UPDATE signal_episode SET last_stage_at=?, last_update_at=? WHERE episode_id=?", (_iso(now), _iso(now), episode_id))
            self._db.commit()

    def end_episode(self, episode_id: str, *, now: datetime, price: float | None, reason: str) -> None:
        with self._lock:
            self._db.execute(
                "UPDATE signal_episode SET status=?,end_at=?,end_price=?,end_reason=?,last_update_at=? WHERE episode_id=? AND status=?",
                (EpisodeStatus.ENDED.value, _iso(now), price, reason, _iso(now), episode_id, EpisodeStatus.ACTIVE.value),
            )
            self._db.commit()

    def find_open_episode(self, trading_day: str, venue: Venue, symbol: str) -> SignalEpisode | None:
        with self._lock:
            row = self._db.execute(
                "SELECT * FROM signal_episode WHERE trading_day=? AND venue=? AND symbol=? AND status=? ORDER BY signal_at DESC LIMIT 1",
                (trading_day, venue.value, symbol, EpisodeStatus.ACTIVE.value),
            ).fetchone()
        return self._episode(row) if row else None

    def get_episode(self, episode_id: str) -> SignalEpisode | None:
        with self._lock:
            row = self._db.execute("SELECT * FROM signal_episode WHERE episode_id=?", (episode_id,)).fetchone()
        return self._episode(row) if row else None

    def recent_episodes(self, limit: int = 100) -> list[SignalEpisode]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM signal_episode ORDER BY signal_at DESC LIMIT ?", (max(1, min(int(limit), 500)),)).fetchall()
        return [self._episode(row) for row in rows]

    def events(self, episode_id: str) -> list[SignalEvent]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM signal_event WHERE episode_id=? ORDER BY event_at,event_id", (episode_id,)).fetchall()
        return [self._event(row) for row in rows]

    def outcomes(self, episode_id: str) -> list[SignalOutcome]:
        with self._lock:
            rows = self._db.execute("SELECT * FROM signal_outcome WHERE episode_id=? ORDER BY CASE horizon WHEN '10M' THEN 1 WHEN '30M' THEN 2 WHEN 'CLOSE' THEN 3 WHEN '1D' THEN 4 WHEN '3D' THEN 5 ELSE 6 END", (episode_id,)).fetchall()
        return [self._outcome(row) for row in rows]

    def due_intraday_outcomes(self, now: datetime) -> list[SignalOutcome]:
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM signal_outcome WHERE status='PENDING' AND horizon IN ('10M','30M') AND due_at IS NOT NULL AND due_at<=?",
                (_iso(now),),
            ).fetchall()
        return [self._outcome(row) for row in rows]

    def episodes_with_pending_daily_outcomes(self, limit: int = 500) -> list[SignalEpisode]:
        with self._lock:
            rows = self._db.execute(
                """SELECT DISTINCT e.* FROM signal_episode e
                   JOIN signal_outcome o ON o.episode_id=e.episode_id
                   WHERE o.horizon IN ('CLOSE','1D','3D','5D') AND o.captured_at IS NULL
                     AND o.status NOT LIKE 'NOT_APPLICABLE%'
                   ORDER BY e.signal_at ASC LIMIT ?""",
                (max(1, min(int(limit), 2000)),),
            ).fetchall()
        return [self._episode(row) for row in rows]

    def mark_outcome_status(self, episode_id: str, horizon: OutcomeHorizon, status: str) -> bool:
        with self._lock:
            cur = self._db.execute(
                "UPDATE signal_outcome SET status=? WHERE episode_id=? AND horizon=? AND captured_at IS NULL AND status NOT LIKE 'NOT_APPLICABLE%'",
                (status, episode_id, horizon.value),
            )
            self._db.commit()
            return cur.rowcount > 0

    def capture_daily_outcome(
        self, episode_id: str, horizon: OutcomeHorizon, *, captured_at: datetime, price: float,
        signal_price: float, source_trading_day, source_kind: str = "KIWOOM_KA10081",
    ) -> bool:
        ret = None if signal_price <= 0 else (price / signal_price - 1.0) * 100.0
        close_local = datetime.combine(source_trading_day, datetime.min.time().replace(hour=15, minute=30), tzinfo=timezone(timedelta(hours=9)))
        due_at = close_local.astimezone(timezone.utc)
        late = max(0.0, (captured_at - due_at).total_seconds())
        with self._lock:
            cur = self._db.execute(
                """UPDATE signal_outcome SET due_at=?,captured_at=?,price=?,return_pct=?,late_by_sec=?,
                   source_trading_day=?,source_kind=?,status='CAPTURED'
                   WHERE episode_id=? AND horizon=? AND captured_at IS NULL AND status NOT LIKE 'NOT_APPLICABLE%'""",
                (_iso(due_at), _iso(captured_at), price, ret, late, source_trading_day.isoformat(), source_kind, episode_id, horizon.value),
            )
            self._db.commit()
            return cur.rowcount > 0

    def capture_outcome(self, episode_id: str, horizon: OutcomeHorizon, *, due_at: datetime, captured_at: datetime, price: float, signal_price: float) -> None:
        ret = None if signal_price <= 0 else (price / signal_price - 1.0) * 100.0
        late = max(0.0, (captured_at - due_at).total_seconds())
        with self._lock:
            self._db.execute(
                "UPDATE signal_outcome SET captured_at=?,price=?,return_pct=?,late_by_sec=?,status='CAPTURED' WHERE episode_id=? AND horizon=? AND status='PENDING'",
                (_iso(captured_at), price, ret, late, episode_id, horizon.value),
            )
            self._db.commit()

    def performance_summary(self, limit: int = 500) -> dict:
        episodes = self.recent_episodes(limit)
        groups: dict[str, dict] = {}
        for ep in episodes:
            g = groups.setdefault(ep.primary_route, {"route": ep.primary_route, "episodes": 0, "mfe": [], "mae": [], "10M": [], "30M": [], "CLOSE": [], "1D": [], "3D": [], "5D": []})
            g["episodes"] += 1
            if ep.mfe_pct is not None:
                g["mfe"].append(ep.mfe_pct)
            if ep.mae_pct is not None:
                g["mae"].append(ep.mae_pct)
            for out in self.outcomes(ep.episode_id):
                if out.status == "CAPTURED" and out.return_pct is not None and out.horizon.value in {"10M", "30M", "CLOSE", "1D", "3D", "5D"}:
                    g[out.horizon.value].append(out.return_pct)
        def avg(vals: list[float]) -> float | None:
            return None if not vals else round(sum(vals) / len(vals), 4)
        rows = []
        for route, g in groups.items():
            rows.append({
                "route": route,
                "episodes": g["episodes"],
                "avg_mfe_pct": avg(g["mfe"]),
                "avg_mae_pct": avg(g["mae"]),
                "captured_10m": len(g["10M"]),
                "avg_10m_return_pct": avg(g["10M"]),
                "captured_30m": len(g["30M"]),
                "avg_30m_return_pct": avg(g["30M"]),
                "captured_close": len(g["CLOSE"]),
                "avg_close_return_pct": avg(g["CLOSE"]),
                "captured_1d": len(g["1D"]),
                "avg_1d_return_pct": avg(g["1D"]),
                "captured_3d": len(g["3D"]),
                "avg_3d_return_pct": avg(g["3D"]),
                "captured_5d": len(g["5D"]),
                "avg_5d_return_pct": avg(g["5D"]),
            })
        rows.sort(key=lambda x: x["episodes"], reverse=True)
        return {"sample_count": len(episodes), "by_primary_route": rows, "probability_calibrated": False}

    @staticmethod
    def _episode(row: sqlite3.Row) -> SignalEpisode:
        return SignalEpisode(
            episode_id=row["episode_id"], trading_day=row["trading_day"], venue=Venue(row["venue"]), symbol=row["symbol"],
            first_seen_at=_dt(row["first_seen_at"]), first_seen_price=row["first_seen_price"], first_route=row["first_route"],
            signal_at=_dt(row["signal_at"]), signal_price=row["signal_price"], primary_route=row["primary_route"],
            current_stage=row["current_stage"], last_stage_at=_dt(row["last_stage_at"]), last_price=row["last_price"],
            highest_price=row["highest_price"], lowest_price=row["lowest_price"], mfe_pct=row["mfe_pct"], mae_pct=row["mae_pct"],
            evidence_count=row["evidence_count"], confluence_grade=row["confluence_grade"], confluence_score_100=row["confluence_score_100"],
            regime_state=row["regime_state"], smart_flow_state=row["smart_flow_state"], data_age_sec=row["data_age_sec"],
            invalidation_price=row["invalidation_price"], status=EpisodeStatus(row["status"]), end_at=_dt(row["end_at"]),
            end_price=row["end_price"], end_reason=row["end_reason"], last_update_at=_dt(row["last_update_at"]),
        )

    @staticmethod
    def _event(row: sqlite3.Row) -> SignalEvent:
        return SignalEvent(
            event_id=row["event_id"], episode_id=row["episode_id"], event_at=_dt(row["event_at"]), event_type=row["event_type"],
            stage=row["stage"], price=row["price"], primary_route=row["primary_route"], evidence_count=row["evidence_count"],
            confluence_grade=row["confluence_grade"], confluence_score_100=row["confluence_score_100"], regime_state=row["regime_state"],
            smart_flow_state=row["smart_flow_state"], risk_flags=json.loads(row["risk_flags_json"] or "[]"),
            gate_failures=json.loads(row["gate_failures_json"] or "[]"), details=json.loads(row["details_json"] or "{}"),
        )

    @staticmethod
    def _outcome(row: sqlite3.Row) -> SignalOutcome:
        return SignalOutcome(
            episode_id=row["episode_id"], horizon=OutcomeHorizon(row["horizon"]), due_at=_dt(row["due_at"]),
            captured_at=_dt(row["captured_at"]), price=row["price"], return_pct=row["return_pct"], late_by_sec=row["late_by_sec"],
            source_trading_day=row["source_trading_day"], source_kind=row["source_kind"], status=row["status"],
        )
