from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from math import isfinite
from typing import Any
from zoneinfo import ZoneInfo

from pulse_edge.context.daily import DailyBar, RestLike
from pulse_edge.ledger.models import OutcomeHorizon, SignalEpisode
from pulse_edge.ledger.store import SignalLedgerStore

KST = ZoneInfo("Asia/Seoul")
KRX_CLOSE_TIME = time(15, 30)
TRUSTED_CLOSE_AVAILABLE_TIME = time(15, 40)


def _number(value: Any, *, absolute: bool = False) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").strip()
    if not text:
        return None
    try:
        result = float(text)
    except ValueError:
        return None
    if not isfinite(result):
        return None
    return abs(result) if absolute else result


class DailyOutcomeBarSource:
    """Outcome-only ka10081 reader with no shared current-scoring memory."""

    def __init__(self, rest: RestLike) -> None:
        self.rest = rest
        self.api_call_count = 0

    async def fetch(self, symbol: str, base_dt: date) -> list[DailyBar]:
        symbol = str(symbol)[:6]
        page = await self.rest.post(
            "ka10081",
            "/api/dostk/chart",
            {"stk_cd": symbol, "base_dt": base_dt.strftime("%Y%m%d"), "upd_stkpc_tp": "1"},
        )
        self.api_call_count += 1
        rows: list[DailyBar] = []
        for raw in page.body.get("stk_dt_pole_chart_qry", []) or []:
            if not isinstance(raw, dict):
                continue
            try:
                trading_date = datetime.strptime(str(raw.get("dt") or "").strip(), "%Y%m%d").date()
            except ValueError:
                continue
            close = _number(raw.get("cur_prc"), absolute=True)
            open_ = _number(raw.get("open_pric"), absolute=True)
            high = _number(raw.get("high_pric"), absolute=True)
            low = _number(raw.get("low_pric"), absolute=True)
            volume = _number(raw.get("trde_qty"), absolute=True)
            if None in {close, open_, high, low, volume} or close <= 0 or high <= 0 or low <= 0:
                continue
            rows.append(
                DailyBar(
                    trading_date=trading_date,
                    close=close,
                    open=open_,
                    high=max(high, low),
                    low=min(high, low),
                    volume=volume,
                    traded_value_raw=_number(raw.get("trde_prica"), absolute=True),
                )
            )
        return sorted(rows, key=lambda x: x.trading_date)


@dataclass(frozen=True)
class DailyOutcomeTarget:
    horizon: OutcomeHorizon
    bar: DailyBar


class DailyOutcomeCompletionService:
    """Completes historical ledger outcomes from trusted Kiwoom daily bars only.

    It reads historical episodes and an outcome-only daily-bar source, then writes outcome rows.
    It never supplies discovery, confluence, hard-gate, or current PRE-BUY rows and owns no
    mutable object used by current scoring.
    """

    def __init__(
        self,
        *,
        store: SignalLedgerStore,
        source: DailyOutcomeBarSource,
        refresh_ttl_sec: float = 300.0,
        max_symbols_per_cycle: int = 20,
    ) -> None:
        self.store = store
        self.source = source
        self.refresh_ttl_sec = max(60.0, float(refresh_ttl_sec))
        self.max_symbols_per_cycle = max(1, min(int(max_symbols_per_cycle), 100))
        self._last_fetch: dict[str, datetime] = {}
        self._bars: dict[str, list[DailyBar]] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self.last_stats: dict[str, int] = {}

    async def refresh(self, asof: datetime | None = None) -> dict[str, int]:
        now = asof or datetime.now(timezone.utc)
        episodes = self.store.episodes_with_pending_daily_outcomes(limit=500)
        by_symbol: dict[str, list[SignalEpisode]] = {}
        for ep in episodes:
            by_symbol.setdefault(ep.symbol, []).append(ep)

        fetched = captured = marked_na = errors = 0
        for symbol in list(by_symbol)[: self.max_symbols_per_cycle]:
            last = self._last_fetch.get(symbol)
            bars = self._bars.get(symbol)
            must_fetch = bars is None or last is None or (now - last).total_seconds() >= self.refresh_ttl_sec
            if must_fetch:
                try:
                    bars = await self.source.fetch(symbol, now.astimezone(KST).date())
                    self._bars[symbol] = bars
                    self._last_fetch[symbol] = now
                    fetched += 1
                except Exception:
                    errors += 1
                    continue
            if bars is None:
                continue
            for ep in by_symbol[symbol]:
                result = self._complete_episode(ep, bars, now)
                captured += result["captured"]
                marked_na += result["not_applicable"]

        stats = {
            "symbols": len(by_symbol),
            "fetched": fetched,
            "captured": captured,
            "not_applicable": marked_na,
            "errors": errors,
        }
        self.last_refresh_at = now
        self.last_error = None if errors == 0 else f"daily outcome fetch errors={errors}"
        self.last_stats = stats
        return stats

    def _complete_episode(self, ep: SignalEpisode, bars: list[DailyBar], now: datetime) -> dict[str, int]:
        signal_day = date.fromisoformat(ep.trading_day)
        signal_local = ep.signal_at.astimezone(KST)
        same_day = next((bar for bar in bars if bar.trading_date == signal_day), None)
        future = [bar for bar in bars if bar.trading_date > signal_day]
        captured = not_applicable = 0

        pending = {row.horizon: row for row in self.store.outcomes(ep.episode_id) if row.captured_at is None}

        close_row = pending.get(OutcomeHorizon.CLOSE)
        if close_row is not None:
            if signal_local.time() > KRX_CLOSE_TIME:
                if self.store.mark_outcome_status(
                    ep.episode_id,
                    OutcomeHorizon.CLOSE,
                    "NOT_APPLICABLE_SIGNAL_AFTER_KRX_CLOSE",
                ):
                    not_applicable += 1
            elif same_day is not None and self._same_day_close_is_trusted(signal_day, now):
                if self.store.capture_daily_outcome(
                    ep.episode_id,
                    OutcomeHorizon.CLOSE,
                    captured_at=now,
                    price=same_day.close,
                    signal_price=ep.signal_price,
                    source_trading_day=same_day.trading_date,
                ):
                    captured += 1

        mapping = {
            OutcomeHorizon.D1: 0,
            OutcomeHorizon.D3: 2,
            OutcomeHorizon.D5: 4,
        }
        for horizon, index in mapping.items():
            row = pending.get(horizon)
            if row is None or len(future) <= index:
                continue
            bar = future[index]
            if self.store.capture_daily_outcome(
                ep.episode_id,
                horizon,
                captured_at=now,
                price=bar.close,
                signal_price=ep.signal_price,
                source_trading_day=bar.trading_date,
            ):
                captured += 1

        return {"captured": captured, "not_applicable": not_applicable}

    @staticmethod
    def _same_day_close_is_trusted(signal_day: date, now: datetime) -> bool:
        local = now.astimezone(KST)
        if local.date() > signal_day:
            return True
        if local.date() < signal_day:
            return False
        return local.time() >= TRUSTED_CLOSE_AVAILABLE_TIME
