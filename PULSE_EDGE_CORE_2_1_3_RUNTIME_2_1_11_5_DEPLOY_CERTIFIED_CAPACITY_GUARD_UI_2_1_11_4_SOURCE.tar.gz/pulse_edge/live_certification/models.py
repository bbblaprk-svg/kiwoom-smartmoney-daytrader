from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class CertificationState(StrEnum):
    NOT_STARTED = "NOT_STARTED"
    COLLECTING = "COLLECTING"
    FIRST_GATE_READY = "FIRST_GATE_READY"
    FINAL_REVIEW_READY = "FINAL_REVIEW_READY"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"


class LiveCertificationFrame(BaseModel):
    asof: datetime
    trading_day: str
    certification_state: CertificationState = CertificationState.NOT_STARTED
    live_market_validation: str = "PENDING"
    profitability_validation: str = "PENDING"
    real_connection_observed: bool = False
    qualifying_days: int = 0
    first_gate_days: int = 3
    final_review_days: int = 5
    evidence_counts: dict[str, int] = Field(default_factory=dict)
    gaps: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    feeds_current_ranking: bool = False
    feeds_current_score: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
    broker_calls_added: int = 0
    strategy_core_mutated: bool = False
    details: dict[str, Any] = Field(default_factory=dict)
