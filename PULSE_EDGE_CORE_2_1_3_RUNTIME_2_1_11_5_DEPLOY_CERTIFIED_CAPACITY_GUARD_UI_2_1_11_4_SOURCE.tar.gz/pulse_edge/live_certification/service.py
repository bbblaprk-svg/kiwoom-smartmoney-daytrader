from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

from pulse_edge.absorption.models import AbsorptionStage
from pulse_edge.core.models import Venue
from pulse_edge.live_certification.models import CertificationState, LiveCertificationFrame

KST = ZoneInfo("Asia/Seoul")


class LiveCertificationService:
    """One-way real-session evidence recorder over frozen PULSE outputs.

    It adds no broker calls and has no reference path back into discovery,
    ranking, score, PRICE HOLD, PRE-BUY, NXT or order actions.
    """

    def __init__(
        self,
        *,
        store: Any,
        state: Any,
        features: Any,
        investor_flow: Any,
        absorption: Any,
        dual_store: Any,
        nxt_native: Any,
        ws: Any,
        feed_service: Any,
        live_shadow_validation: Any,
        max_symbols: int = 30,
        ws_heartbeat_sec: float = 30.0,
        first_gate_days: int = 3,
        final_review_days: int = 5,
    ) -> None:
        self.store = store
        self.state = state
        self.features = features
        self.investor_flow = investor_flow
        self.absorption = absorption
        self.dual_store = dual_store
        self.nxt_native = nxt_native
        self.ws = ws
        self.feed_service = feed_service
        self.live_shadow_validation = live_shadow_validation
        self.max_symbols = max(5, min(int(max_symbols), 100))
        self.ws_heartbeat_sec = max(10.0, float(ws_heartbeat_sec))
        self.first_gate_days = max(1, int(first_gate_days))
        self.final_review_days = max(self.first_gate_days, int(final_review_days))
        self.frame: LiveCertificationFrame | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self._day: str | None = None
        self._last_stage: dict[str, tuple[str, str, bool]] = {}
        self._last_ws_heartbeat_bucket: int | None = None

    @staticmethod
    def _fingerprint(payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _same_day(ts: datetime | None, day: str) -> bool:
        return bool(ts and ts.astimezone(KST).date().isoformat() == day)

    def _record(self, now: datetime, day: str, kind: str, source: str, payload: dict[str, Any], *, venue: str | None = None, symbol: str | None = None) -> bool:
        return self.store.add_event(
            trading_day=day,
            observed_at=now,
            kind=kind,
            venue=venue,
            symbol=symbol,
            source=source,
            fingerprint=self._fingerprint(payload),
            payload=payload,
        )

    def _roll_day(self, day: str) -> None:
        if self._day == day:
            return
        self._day = day
        self._last_stage.clear()
        self._last_ws_heartbeat_bucket = None

    def _capture_ws(self, now: datetime, day: str) -> None:
        bucket = int(now.timestamp() // self.ws_heartbeat_sec)
        if bucket == self._last_ws_heartbeat_bucket:
            return
        self._last_ws_heartbeat_bucket = bucket
        payload = {
            "connected": bool(self.ws and getattr(self.ws, "connected", False)),
            "connection_count": int(getattr(self.ws, "connection_count", 0) if self.ws else 0),
            "reconnect_count": int(getattr(self.ws, "reconnect_count", 0) if self.ws else 0),
            "dynamic_refresh_count": int(getattr(self.ws, "dynamic_refresh_count", 0) if self.ws else 0),
            "last_connected_at_epoch": getattr(self.ws, "last_connected_at", None) if self.ws else None,
            "last_disconnected_at_epoch": getattr(self.ws, "last_disconnected_at", None) if self.ws else None,
            "last_message_at_epoch": getattr(self.ws, "last_message_at", None) if self.ws else None,
            "last_error": getattr(self.ws, "last_error", None) if self.ws else None,
            "feed_total_payloads": int(getattr(self.feed_service, "total_payloads", 0)),
            "feed_total_normalized": int(getattr(self.feed_service, "total_normalized", 0)),
            "continuity_reasons": list(getattr(self.feed_service, "continuity_reasons", [])[-10:]),
            "session_reasons": list(getattr(self.feed_service, "session_reasons", [])[-10:]),
        }
        self._record(now, day, "WS_HEALTH", "KIWOOM_WS_RUNTIME", payload)

    def _capture_krx(self, now: datetime, day: str) -> None:
        frames = list(getattr(self.absorption, "frames", {}).values())
        frames.sort(key=lambda r: (getattr(r, "stage", AbsorptionStage.DATA_WAIT).value, float(getattr(r, "score_100", 0.0))), reverse=True)
        for frame in frames[: self.max_symbols]:
            symbol = str(frame.symbol)[:6]
            payload = {
                "asof": frame.asof,
                "model": frame.model.value,
                "prior_model": frame.prior_model.value,
                "stage": frame.stage.value,
                "score_100": frame.score_100,
                "price": frame.price,
                "change_rate": frame.change_rate,
                "price_hold_pass": frame.price_hold_pass,
                "price_defense_score_25": frame.price_defense_score_25,
                "price_compression": frame.price_compression,
                "foreign_net": frame.foreign_net,
                "institution_net": frame.institution_net,
                "fund_net": frame.fund_net,
                "pension_net": frame.pension_net,
                "other_corporation_net": frame.other_corporation_net,
                "program_net": frame.program_net,
                "flow_unit": frame.flow_unit,
                "investor_source_api_id": frame.investor_source_api_id,
                "seller_actor": frame.seller_actor,
                "absorber_actor": frame.absorber_actor,
                "absorption_ratio": frame.absorption_ratio,
                "seller_new_sell_velocity_per_min": frame.seller_new_sell_velocity_per_min,
                "seller_previous_sell_velocity_per_min": frame.seller_previous_sell_velocity_per_min,
                "seller_sell_deceleration_count": frame.seller_sell_deceleration_count,
                "seller_sell_deceleration_confirmed": frame.seller_sell_deceleration_confirmed,
                "vwap_distance_pct": frame.vwap_distance_pct,
                "rising_lows": frame.rising_lows,
                "intraday_range_position": frame.intraday_range_position,
                "rs_level": frame.rs_level,
                "sector_relative_strength_pct": frame.sector_relative_strength_pct,
                "money_acceleration": frame.money_acceleration,
                "price_trust": frame.price_trust.value,
                "investor_trust": frame.investor_trust.value,
                "program_trust": frame.program_trust.value,
                "stage_trust": frame.stage_trust.value,
                "reasons": list(frame.reasons),
                "risks": list(frame.risks),
                "missing": list(frame.missing),
            }
            self._record(now, day, "DUAL_FRAME", "PULSE_ABSORPTION_OUTPUT", payload, venue="KRX", symbol=symbol)

            prior = self._last_stage.get(symbol)
            current = (frame.model.value, frame.stage.value, bool(frame.price_hold_pass))
            if prior is not None and prior != current:
                self._record(
                    now,
                    day,
                    "STAGE_TRANSITION",
                    "PULSE_ABSORPTION_OUTPUT",
                    {
                        "from_model": prior[0],
                        "from_stage": prior[1],
                        "from_price_hold_pass": prior[2],
                        "to_model": current[0],
                        "to_stage": current[1],
                        "to_price_hold_pass": current[2],
                        "price": frame.price,
                        "score_100": frame.score_100,
                        "asof": frame.asof,
                    },
                    venue="KRX",
                    symbol=symbol,
                )
            self._last_stage[symbol] = current

            st = getattr(self.state, "krx", {}).get(symbol)
            event = getattr(st, "events_by_type", {}).get("0w") if st is not None else None
            event_ts = (getattr(event, "event_time", None) or getattr(event, "receive_time", None)) if event else None
            if event is not None and self._same_day(event_ts, day):
                raw_payload = {
                    "receive_time": getattr(event, "receive_time", None),
                    "event_time": getattr(event, "event_time", None),
                    "real_type": getattr(event, "real_type", None),
                    "data": getattr(event, "data", {}),
                    "values": getattr(event, "values", {}),
                    "raw": getattr(event, "raw", {}),
                }
                self._record(now, day, "PROGRAM_0W_RAW", "KIWOOM_WS_0W", raw_payload, venue="KRX", symbol=symbol)

            detail = getattr(self.investor_flow, "breakdown", {}).get(symbol)
            if detail is not None and str(getattr(detail, "source_date", "")) == day:
                if is_dataclass(detail):
                    detail_payload = asdict(detail)
                else:
                    detail_payload = dict(getattr(detail, "__dict__", {}))
                self._record(now, day, "KA10060_PARSED", "KIWOOM_KA10060_PARSED", detail_payload, venue="KRX", symbol=symbol)

    def _capture_nxt(self, now: datetime, day: str) -> None:
        rows = list(getattr(self.nxt_native, "frames", {}).values())
        rows.sort(key=lambda r: float(getattr(r, "score_100", 0.0)), reverse=True)
        for row in rows[: self.max_symbols]:
            if str(getattr(row, "trading_day", "")) != day:
                continue
            payload = {
                "asof": row.asof,
                "phase": row.phase.value,
                "stage": row.stage.value,
                "nxt_price": row.nxt_price,
                "krx_reference_price": row.krx_reference_price,
                "nxt_premium_pct": row.nxt_premium_pct,
                "change_rate": row.change_rate,
                "vwap_distance_pct": row.vwap_distance_pct,
                "spread_pct": row.spread_pct,
                "money_5m": row.money_5m,
                "money_acceleration": row.money_acceleration,
                "rvol_same_time": row.rvol_same_time,
                "score_100": row.score_100,
                "persistence_count": row.persistence_count,
                "strict_close_window": row.strict_close_window,
                "price_trust": row.price_trust.value,
                "quote_trust": row.quote_trust.value,
                "flow_trust": row.flow_trust.value,
                "investor_flow_source": row.investor_flow_source,
                "krx_investor_flow_used": row.krx_investor_flow_used,
                "flags": list(row.flags),
            }
            self._record(now, day, "NXT_FRAME", "PULSE_NXT_NATIVE_OUTPUT", payload, venue="NXT", symbol=str(row.symbol)[:6])

    def _capture_signal_links(self, now: datetime, day: str) -> None:
        if self.dual_store is None:
            return
        for row in self.dual_store.recent(max(50, self.max_symbols * 5)):
            if str(row["trading_day"]) != day:
                continue
            payload = dict(row)
            self._record(now, day, "SIGNAL_PRICE_LOCK", "PULSE_DUAL_PERFORMANCE", payload, venue=str(row["venue"]), symbol=str(row["symbol"]))
            for outcome in self.dual_store.outcome_rows(row["signal_id"]):
                if outcome["status"] != "CAPTURED":
                    continue
                out = dict(outcome)
                out["signal_price"] = row["signal_price"]
                out["signal_at"] = row["signal_at"]
                out["model"] = row["model"]
                out["stage"] = row["stage"]
                self._record(now, day, "OUTCOME_LINK", "PULSE_DUAL_PERFORMANCE", out, venue=str(row["venue"]), symbol=str(row["symbol"]))

    @staticmethod
    def _day_qualifies(row: dict[str, Any]) -> bool:
        return bool(
            row.get("real_market_observed")
            and row.get("krx_observed")
            and row.get("nxt_observed")
            and row.get("ws_connected_seen")
            and int(row.get("program_evidence_count", 0)) > 0
            and int(row.get("investor_evidence_count", 0)) > 0
            and int(row.get("absorption_evidence_count", 0)) > 0
            and int(row.get("hard_fail_count", 0)) == 0
        )

    def refresh(self, asof: datetime | None = None) -> LiveCertificationFrame:
        now = asof or datetime.now(timezone.utc)
        day = now.astimezone(KST).date().isoformat()
        self._roll_day(day)
        self._capture_ws(now, day)
        self._capture_krx(now, day)
        self._capture_nxt(now, day)
        self._capture_signal_links(now, day)

        counts = self.store.event_counts(day)
        shadow = getattr(getattr(self.live_shadow_validation, "frame", None), "live_market_validation", "PENDING")
        connected = bool(self.ws and getattr(self.ws, "connected", False))
        reconnect = int(getattr(self.ws, "reconnect_count", 0) if self.ws else 0) > 0
        trusted_at = getattr(self.feed_service, "last_trusted_market_event_at", None)
        real_market = self._same_day(trusted_at, day)

        krx_observed = False
        nxt_observed = False
        for symbol, st in getattr(self.state, "krx", {}).items():
            for typ in ("0B", "0D"):
                ev = getattr(st, "events_by_type", {}).get(typ)
                ts = (getattr(ev, "event_time", None) or getattr(ev, "receive_time", None)) if ev else None
                if self._same_day(ts, day):
                    krx_observed = True
                    break
            if krx_observed:
                break
        for symbol, st in getattr(self.state, "nxt", {}).items():
            for typ in ("0B", "0D"):
                ev = getattr(st, "events_by_type", {}).get(typ)
                ts = (getattr(ev, "event_time", None) or getattr(ev, "receive_time", None)) if ev else None
                if self._same_day(ts, day):
                    nxt_observed = True
                    break
            if nxt_observed:
                break

        hard_fail = 0
        shadow_frame = getattr(self.live_shadow_validation, "frame", None)
        if shadow_frame is not None:
            hard_fail = int(getattr(shadow_frame, "fail_count", 0) or 0)

        self.store.upsert_day(
            day,
            now=now,
            values={
                "real_market_observed": real_market,
                "krx_observed": krx_observed,
                "nxt_observed": nxt_observed,
                "ws_connected_seen": connected,
                "reconnect_seen": reconnect,
                "program_evidence_count": counts.get("PROGRAM_0W_RAW", 0),
                "investor_evidence_count": counts.get("KA10060_PARSED", 0),
                "absorption_evidence_count": counts.get("DUAL_FRAME", 0),
                "stage_transition_count": counts.get("STAGE_TRANSITION", 0),
                "signal_evidence_count": counts.get("SIGNAL_PRICE_LOCK", 0),
                "outcome_evidence_count": counts.get("OUTCOME_LINK", 0),
                "hard_fail_count": hard_fail,
                "live_shadow_state": shadow,
                "details": {
                    "reconnect_count": int(getattr(self.ws, "reconnect_count", 0) if self.ws else 0),
                    "last_trusted_market_event_at": trusted_at,
                    "program_semantics_manual_review": "REQUIRED",
                    "ka10060_semantics_manual_review": "REQUIRED",
                    "profitability_minimum_observation_days": "10-20",
                },
            },
        )

        days = self.store.recent_days(100)
        qualifying = sum(1 for row in days if self._day_qualifies(row))
        gaps = []
        current = next((x for x in days if x["trading_day"] == day), None) or {}
        if not current.get("real_market_observed"):
            gaps.append("REAL_TRUSTED_MARKET_EVENT")
        if not current.get("krx_observed"):
            gaps.append("KRX_TRADE_ORDERBOOK")
        if not current.get("nxt_observed"):
            gaps.append("NXT_TRADE_ORDERBOOK")
        if int(current.get("program_evidence_count", 0)) <= 0:
            gaps.append("PROGRAM_0W_EVIDENCE")
        if int(current.get("investor_evidence_count", 0)) <= 0:
            gaps.append("KA10060_EVIDENCE")
        if int(current.get("absorption_evidence_count", 0)) <= 0:
            gaps.append("DUAL_PRICE_HOLD_EVIDENCE")
        if int(current.get("hard_fail_count", 0)) > 0:
            gaps.append("LIVE_SHADOW_HARD_FAIL")

        if not real_market:
            cert_state = CertificationState.NOT_STARTED if qualifying == 0 else CertificationState.COLLECTING
        elif hard_fail > 0:
            cert_state = CertificationState.REVIEW_REQUIRED
        elif qualifying >= self.final_review_days:
            cert_state = CertificationState.FINAL_REVIEW_READY
        elif qualifying >= self.first_gate_days:
            cert_state = CertificationState.FIRST_GATE_READY
        else:
            cert_state = CertificationState.COLLECTING

        frame = LiveCertificationFrame(
            asof=now,
            trading_day=day,
            certification_state=cert_state,
            live_market_validation=shadow,
            profitability_validation="PENDING",
            real_connection_observed=bool(connected or reconnect or getattr(shadow_frame, "real_connection_observed", False)),
            qualifying_days=qualifying,
            first_gate_days=self.first_gate_days,
            final_review_days=self.final_review_days,
            evidence_counts=counts,
            gaps=gaps,
            notes=[
                "PROGRAM_0W and ka10060 sign/unit semantics require real-session review before certification.",
                "FINAL_REVIEW_READY means evidence is ready for manual certification; it is not automatic profitability certification.",
                "Historical evidence cannot feed current ranking, score, PRICE HOLD, PRE-BUY or NXT.",
            ],
            details={
                "days_seen": len(days),
                "reconnect_observed": reconnect,
                "current_day_qualifies_automatic_evidence": self._day_qualifies(current) if current else False,
            },
        )
        self.frame = frame
        self.last_refresh_at = now
        self.last_error = None
        return frame
