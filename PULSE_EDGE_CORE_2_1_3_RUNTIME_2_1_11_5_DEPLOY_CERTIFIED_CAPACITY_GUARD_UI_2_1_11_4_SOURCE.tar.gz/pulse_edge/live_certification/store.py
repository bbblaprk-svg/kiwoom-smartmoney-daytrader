from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Any


class LiveCertificationStore:
    """One-way live evidence store. Nothing in this store is a trading input."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._db = sqlite3.connect(self.path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS live_cert_event (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trading_day TEXT NOT NULL,
                observed_at TEXT NOT NULL,
                kind TEXT NOT NULL,
                venue TEXT,
                symbol TEXT,
                source TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                UNIQUE(trading_day, kind, venue, symbol, fingerprint)
            );
            CREATE INDEX IF NOT EXISTS idx_live_cert_event_time
              ON live_cert_event(trading_day, observed_at DESC);
            CREATE INDEX IF NOT EXISTS idx_live_cert_event_kind
              ON live_cert_event(trading_day, kind, observed_at DESC);

            CREATE TABLE IF NOT EXISTS live_cert_day (
                trading_day TEXT PRIMARY KEY,
                started_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                real_market_observed INTEGER NOT NULL DEFAULT 0,
                krx_observed INTEGER NOT NULL DEFAULT 0,
                nxt_observed INTEGER NOT NULL DEFAULT 0,
                ws_connected_seen INTEGER NOT NULL DEFAULT 0,
                reconnect_seen INTEGER NOT NULL DEFAULT 0,
                program_evidence_count INTEGER NOT NULL DEFAULT 0,
                investor_evidence_count INTEGER NOT NULL DEFAULT 0,
                absorption_evidence_count INTEGER NOT NULL DEFAULT 0,
                stage_transition_count INTEGER NOT NULL DEFAULT 0,
                signal_evidence_count INTEGER NOT NULL DEFAULT 0,
                outcome_evidence_count INTEGER NOT NULL DEFAULT 0,
                hard_fail_count INTEGER NOT NULL DEFAULT 0,
                live_shadow_state TEXT NOT NULL DEFAULT 'PENDING',
                details_json TEXT NOT NULL DEFAULT '{}'
            );
            """
        )
        self._db.commit()

    def close(self) -> None:
        with self._lock:
            self._db.close()

    def add_event(
        self,
        *,
        trading_day: str,
        observed_at: datetime,
        kind: str,
        source: str,
        fingerprint: str,
        payload: dict[str, Any],
        venue: str | None = None,
        symbol: str | None = None,
    ) -> bool:
        with self._lock:
            cur = self._db.execute(
                """
                INSERT OR IGNORE INTO live_cert_event(
                    trading_day, observed_at, kind, venue, symbol, source, fingerprint, payload_json
                ) VALUES(?,?,?,?,?,?,?,?)
                """,
                (
                    trading_day,
                    observed_at.isoformat(),
                    kind,
                    venue,
                    symbol,
                    source,
                    fingerprint,
                    json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str),
                ),
            )
            self._db.commit()
            return bool(cur.rowcount)

    def upsert_day(self, trading_day: str, *, now: datetime, values: dict[str, Any]) -> None:
        with self._lock:
            old = self._db.execute(
                "SELECT * FROM live_cert_day WHERE trading_day=?", (trading_day,)
            ).fetchone()
            started_at = old["started_at"] if old else now.isoformat()
            merged = {
                "real_market_observed": max(int(old["real_market_observed"]) if old else 0, int(bool(values.get("real_market_observed")))),
                "krx_observed": max(int(old["krx_observed"]) if old else 0, int(bool(values.get("krx_observed")))),
                "nxt_observed": max(int(old["nxt_observed"]) if old else 0, int(bool(values.get("nxt_observed")))),
                "ws_connected_seen": max(int(old["ws_connected_seen"]) if old else 0, int(bool(values.get("ws_connected_seen")))),
                "reconnect_seen": max(int(old["reconnect_seen"]) if old else 0, int(bool(values.get("reconnect_seen")))),
                "program_evidence_count": max(int(old["program_evidence_count"]) if old else 0, int(values.get("program_evidence_count", 0))),
                "investor_evidence_count": max(int(old["investor_evidence_count"]) if old else 0, int(values.get("investor_evidence_count", 0))),
                "absorption_evidence_count": max(int(old["absorption_evidence_count"]) if old else 0, int(values.get("absorption_evidence_count", 0))),
                "stage_transition_count": max(int(old["stage_transition_count"]) if old else 0, int(values.get("stage_transition_count", 0))),
                "signal_evidence_count": max(int(old["signal_evidence_count"]) if old else 0, int(values.get("signal_evidence_count", 0))),
                "outcome_evidence_count": max(int(old["outcome_evidence_count"]) if old else 0, int(values.get("outcome_evidence_count", 0))),
                "hard_fail_count": max(int(old["hard_fail_count"]) if old else 0, int(values.get("hard_fail_count", 0))),
            }
            details = {}
            if old:
                try:
                    details.update(json.loads(old["details_json"] or "{}"))
                except Exception:
                    pass
            details.update(values.get("details", {}) or {})
            live_shadow_state = str(values.get("live_shadow_state") or (old["live_shadow_state"] if old else "PENDING"))
            self._db.execute(
                """
                INSERT INTO live_cert_day(
                    trading_day,started_at,updated_at,real_market_observed,krx_observed,nxt_observed,
                    ws_connected_seen,reconnect_seen,program_evidence_count,investor_evidence_count,
                    absorption_evidence_count,stage_transition_count,signal_evidence_count,outcome_evidence_count,
                    hard_fail_count,live_shadow_state,details_json
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(trading_day) DO UPDATE SET
                    updated_at=excluded.updated_at,
                    real_market_observed=excluded.real_market_observed,
                    krx_observed=excluded.krx_observed,
                    nxt_observed=excluded.nxt_observed,
                    ws_connected_seen=excluded.ws_connected_seen,
                    reconnect_seen=excluded.reconnect_seen,
                    program_evidence_count=excluded.program_evidence_count,
                    investor_evidence_count=excluded.investor_evidence_count,
                    absorption_evidence_count=excluded.absorption_evidence_count,
                    stage_transition_count=excluded.stage_transition_count,
                    signal_evidence_count=excluded.signal_evidence_count,
                    outcome_evidence_count=excluded.outcome_evidence_count,
                    hard_fail_count=excluded.hard_fail_count,
                    live_shadow_state=excluded.live_shadow_state,
                    details_json=excluded.details_json
                """,
                (
                    trading_day, started_at, now.isoformat(),
                    merged["real_market_observed"], merged["krx_observed"], merged["nxt_observed"],
                    merged["ws_connected_seen"], merged["reconnect_seen"], merged["program_evidence_count"],
                    merged["investor_evidence_count"], merged["absorption_evidence_count"], merged["stage_transition_count"],
                    merged["signal_evidence_count"], merged["outcome_evidence_count"], merged["hard_fail_count"],
                    live_shadow_state,
                    json.dumps(details, ensure_ascii=False, sort_keys=True, default=str),
                ),
            )
            self._db.commit()

    def recent_days(self, limit: int = 20) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 100))
        with self._lock:
            rows = self._db.execute(
                "SELECT * FROM live_cert_day ORDER BY trading_day DESC LIMIT ?", (limit,)
            ).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            item["real_market_observed"] = bool(item["real_market_observed"])
            item["krx_observed"] = bool(item["krx_observed"])
            item["nxt_observed"] = bool(item["nxt_observed"])
            item["ws_connected_seen"] = bool(item["ws_connected_seen"])
            item["reconnect_seen"] = bool(item["reconnect_seen"])
            try:
                item["details"] = json.loads(item.pop("details_json") or "{}")
            except Exception:
                item["details"] = {}
            out.append(item)
        return out

    def recent_events(self, limit: int = 200, *, trading_day: str | None = None, kind: str | None = None) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 2000))
        where = []
        args: list[Any] = []
        if trading_day:
            where.append("trading_day=?")
            args.append(trading_day)
        if kind:
            where.append("kind=?")
            args.append(kind)
        sql = "SELECT * FROM live_cert_event"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY observed_at DESC, id DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._db.execute(sql, args).fetchall()
        out = []
        for row in rows:
            item = dict(row)
            try:
                item["payload"] = json.loads(item.pop("payload_json") or "{}")
            except Exception:
                item["payload"] = {}
            out.append(item)
        return out

    def event_counts(self, trading_day: str) -> dict[str, int]:
        with self._lock:
            rows = self._db.execute(
                "SELECT kind,COUNT(*) AS n FROM live_cert_event WHERE trading_day=? GROUP BY kind",
                (trading_day,),
            ).fetchall()
        return {str(r["kind"]): int(r["n"]) for r in rows}
