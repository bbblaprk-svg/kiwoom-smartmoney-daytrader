from __future__ import annotations
from datetime import datetime
from pydantic import BaseModel, Field
from pulse_edge.absorption.models import AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue

class DualSignalRecord(BaseModel):
    signal_id: str
    trading_day: str
    venue: Venue = Venue.KRX
    symbol: str
    model: AbsorptionModel
    stage: AbsorptionStage
    signal_at: datetime
    signal_price: float
    score_100: float
    price_hold_score_25: float
    absorption_ratio: float | None = None
    absorption_ratio_delta: float | None = None
    seller_actor: str | None = None
    absorber_actor: str | None = None
    seller_new_sell_velocity_per_min: float | None = None
    seller_sell_deceleration_count: int = 0
    foreign_net: float | None = None
    institution_net: float | None = None
    fund_net: float | None = None
    pension_net: float | None = None
    program_net: float | None = None
    other_corporation_net: float | None = None
    market_rs: float | None = None
    sector_rs: float | None = None
    vwap_distance_pct: float | None = None
    range_position: float | None = None
    money_acceleration: float | None = None
    sector_breadth_ratio: float | None = None
    fact_trust: FactTrust
    preemptive_fit: str
    price_compression: bool = False
    highest_price: float
    lowest_price: float
    mfe_pct: float = 0.0
    mae_pct: float = 0.0
    last_price: float
    last_update_at: datetime

class StageTransition(BaseModel):
    transition_id: int | None = None
    trading_day: str
    venue: Venue = Venue.KRX
    symbol: str
    model: AbsorptionModel
    from_stage: AbsorptionStage
    to_stage: AbsorptionStage
    transition_at: datetime
    price: float
    score_100: float

class DualOutcome(BaseModel):
    signal_id: str
    horizon: str
    due_at: datetime | None = None
    captured_at: datetime | None = None
    price: float | None = None
    return_pct: float | None = None
    source_trading_day: str | None = None
    status: str = "PENDING"

class DualPerformanceSummary(BaseModel):
    group: str
    count: int = 0
    mfe_avg_pct: float | None = None
    mae_avg_pct: float | None = None
    outcomes: dict[str, dict] = Field(default_factory=dict)
