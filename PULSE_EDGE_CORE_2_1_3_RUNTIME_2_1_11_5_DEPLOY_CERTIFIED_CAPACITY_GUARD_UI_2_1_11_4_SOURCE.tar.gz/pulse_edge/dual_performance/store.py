from __future__ import annotations
import sqlite3, threading
from datetime import datetime, timezone
from pathlib import Path
from pulse_edge.absorption.models import AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue
from .models import DualOutcome, DualSignalRecord, StageTransition

def iso(v):
    if v is None:return None
    if v.tzinfo is None:v=v.replace(tzinfo=timezone.utc)
    return v.astimezone(timezone.utc).isoformat()
def dt(v):
    if not v:return None
    x=datetime.fromisoformat(v);return x if x.tzinfo else x.replace(tzinfo=timezone.utc)

class DualPerformanceStore:
    """One-way Phase 6C verifier. No method supplies current ranking/scoring inputs."""
    def __init__(self,path:str):
        self.path=path;Path(path).parent.mkdir(parents=True,exist_ok=True);self._lock=threading.RLock()
        self._db=sqlite3.connect(path,check_same_thread=False);self._db.row_factory=sqlite3.Row
        with self._lock:
            self._db.execute('PRAGMA journal_mode=WAL');self._db.execute('PRAGMA synchronous=NORMAL');self._schema()
    def _schema(self):
        self._db.executescript('''
        CREATE TABLE IF NOT EXISTS dual_signal(
          signal_id TEXT PRIMARY KEY,trading_day TEXT NOT NULL,venue TEXT NOT NULL,symbol TEXT NOT NULL,
          model TEXT NOT NULL,stage TEXT NOT NULL,signal_at TEXT NOT NULL,signal_price REAL NOT NULL,
          score_100 REAL NOT NULL,price_hold_score_25 REAL NOT NULL,absorption_ratio REAL,absorption_ratio_delta REAL,
          seller_actor TEXT,absorber_actor TEXT,seller_velocity REAL,seller_decel_count INTEGER NOT NULL,
          foreign_net REAL,institution_net REAL,fund_net REAL,pension_net REAL,program_net REAL,other_corporation_net REAL,
          market_rs REAL,sector_rs REAL,vwap_distance_pct REAL,range_position REAL,money_acceleration REAL,sector_breadth_ratio REAL,
          fact_trust TEXT NOT NULL,preemptive_fit TEXT NOT NULL,price_compression INTEGER NOT NULL,
          highest_price REAL NOT NULL,lowest_price REAL NOT NULL,mfe_pct REAL NOT NULL,mae_pct REAL NOT NULL,last_price REAL NOT NULL,last_update_at TEXT NOT NULL,
          UNIQUE(trading_day,venue,symbol,model,stage));
        CREATE INDEX IF NOT EXISTS idx_dual_signal_time ON dual_signal(signal_at DESC);
        CREATE INDEX IF NOT EXISTS idx_dual_signal_group ON dual_signal(model,stage,signal_at DESC);
        CREATE TABLE IF NOT EXISTS dual_transition(
          transition_id INTEGER PRIMARY KEY AUTOINCREMENT,trading_day TEXT NOT NULL,venue TEXT NOT NULL,symbol TEXT NOT NULL,
          model TEXT NOT NULL,from_stage TEXT NOT NULL,to_stage TEXT NOT NULL,transition_at TEXT NOT NULL,price REAL NOT NULL,score_100 REAL NOT NULL,
          UNIQUE(trading_day,venue,symbol,model,from_stage,to_stage));
        CREATE TABLE IF NOT EXISTS dual_outcome(
          signal_id TEXT NOT NULL,horizon TEXT NOT NULL,due_at TEXT,captured_at TEXT,price REAL,return_pct REAL,source_trading_day TEXT,status TEXT NOT NULL DEFAULT 'PENDING',
          PRIMARY KEY(signal_id,horizon));
        ''');self._db.commit()
    def insert_signal(self,s:DualSignalRecord)->bool:
        with self._lock:
            cur=self._db.execute('''INSERT OR IGNORE INTO dual_signal (signal_id,trading_day,venue,symbol,model,stage,signal_at,signal_price,score_100,price_hold_score_25,absorption_ratio,absorption_ratio_delta,seller_actor,absorber_actor,seller_velocity,seller_decel_count,foreign_net,institution_net,fund_net,pension_net,program_net,other_corporation_net,market_rs,sector_rs,vwap_distance_pct,range_position,money_acceleration,sector_breadth_ratio,fact_trust,preemptive_fit,price_compression,highest_price,lowest_price,mfe_pct,mae_pct,last_price,last_update_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
              s.signal_id,s.trading_day,s.venue.value,s.symbol,s.model.value,s.stage.value,iso(s.signal_at),s.signal_price,s.score_100,s.price_hold_score_25,
              s.absorption_ratio,s.absorption_ratio_delta,s.seller_actor,s.absorber_actor,s.seller_new_sell_velocity_per_min,s.seller_sell_deceleration_count,
              s.foreign_net,s.institution_net,s.fund_net,s.pension_net,s.program_net,s.other_corporation_net,s.market_rs,s.sector_rs,s.vwap_distance_pct,s.range_position,
              s.money_acceleration,s.sector_breadth_ratio,s.fact_trust.value,s.preemptive_fit,int(s.price_compression),s.highest_price,s.lowest_price,s.mfe_pct,s.mae_pct,s.last_price,iso(s.last_update_at)))
            if cur.rowcount:
                for h,mins in [('10M',10),('30M',30)]:
                    from datetime import timedelta
                    self._db.execute('INSERT INTO dual_outcome(signal_id,horizon,due_at) VALUES(?,?,?)',(s.signal_id,h,iso(s.signal_at+timedelta(minutes=mins))))
                for h in ('CLOSE','1D','3D','5D'):self._db.execute('INSERT INTO dual_outcome(signal_id,horizon) VALUES(?,?)',(s.signal_id,h))
            self._db.commit();return bool(cur.rowcount)
    def insert_transition(self,t:StageTransition)->bool:
        with self._lock:
            cur=self._db.execute('''INSERT OR IGNORE INTO dual_transition(trading_day,venue,symbol,model,from_stage,to_stage,transition_at,price,score_100) VALUES(?,?,?,?,?,?,?,?,?)''',
              (t.trading_day,t.venue.value,t.symbol,t.model.value,t.from_stage.value,t.to_stage.value,iso(t.transition_at),t.price,t.score_100));self._db.commit();return bool(cur.rowcount)
    def update_excursion(self,signal_id:str,price:float,at:datetime):
        with self._lock:
            r=self._db.execute('SELECT signal_price,highest_price,lowest_price FROM dual_signal WHERE signal_id=?',(signal_id,)).fetchone()
            if not r:return
            high=max(float(r['highest_price']),price);low=min(float(r['lowest_price']),price);sp=float(r['signal_price'])
            self._db.execute('UPDATE dual_signal SET highest_price=?,lowest_price=?,mfe_pct=?,mae_pct=?,last_price=?,last_update_at=? WHERE signal_id=?',
              (high,low,(high/sp-1)*100,(low/sp-1)*100,price,iso(at),signal_id));self._db.commit()
    def active_day_signals(self,day:str):return self._db.execute('SELECT * FROM dual_signal WHERE trading_day=?',(day,)).fetchall()
    def due_intraday(self,now:datetime):return self._db.execute("SELECT * FROM dual_outcome WHERE status='PENDING' AND horizon IN ('10M','30M') AND due_at<=?",(iso(now),)).fetchall()
    def capture(self,signal_id,horizon,price,at,source_day=None):
        with self._lock:
            r=self._db.execute('SELECT signal_price FROM dual_signal WHERE signal_id=?',(signal_id,)).fetchone()
            if not r:return False
            sp=float(r['signal_price']);cur=self._db.execute("UPDATE dual_outcome SET captured_at=?,price=?,return_pct=?,source_trading_day=?,status='CAPTURED' WHERE signal_id=? AND horizon=? AND status='PENDING'",
              (iso(at),price,(price/sp-1)*100,source_day,signal_id,horizon));self._db.commit();return bool(cur.rowcount)
    def recent(self,limit=100):return self._db.execute('SELECT * FROM dual_signal ORDER BY signal_at DESC LIMIT ?',(limit,)).fetchall()
    def pending_daily(self,limit=500):return self._db.execute("SELECT DISTINCT s.* FROM dual_signal s JOIN dual_outcome o ON o.signal_id=s.signal_id WHERE o.status='PENDING' AND o.horizon IN ('CLOSE','1D','3D','5D') ORDER BY s.signal_at LIMIT ?",(limit,)).fetchall()
    def outcome_rows(self,signal_id):return self._db.execute('SELECT * FROM dual_outcome WHERE signal_id=?',(signal_id,)).fetchall()
    def transitions(self,limit=1000):return self._db.execute('SELECT * FROM dual_transition ORDER BY transition_at DESC LIMIT ?',(limit,)).fetchall()
    def close(self):self._db.close()
