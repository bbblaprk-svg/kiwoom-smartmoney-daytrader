from __future__ import annotations
from datetime import datetime, timezone
from uuid import uuid4
from zoneinfo import ZoneInfo
from pulse_edge.absorption.models import AbsorptionFrame,AbsorptionModel,AbsorptionStage,FactTrust
from pulse_edge.core.models import Venue
from .models import DualSignalRecord,StageTransition
from .store import DualPerformanceStore
KST=ZoneInfo('Asia/Seoul')
TRACK={AbsorptionStage.ABSORB,AbsorptionStage.PRICE_HOLD,AbsorptionStage.SUPPLY_TIGHT,AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,AbsorptionStage.PRE_IGNITION,AbsorptionStage.IGNITION}
ORDER={s:i for i,s in enumerate([AbsorptionStage.DATA_WAIT,AbsorptionStage.WATCH,AbsorptionStage.ABSORB,AbsorptionStage.PRICE_HOLD,AbsorptionStage.SUPPLY_TIGHT,AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,AbsorptionStage.PRE_IGNITION,AbsorptionStage.IGNITION])}

class DualPerformanceService:
    """Observes absorption output one-way. Never mutates or feeds absorption/current ranks."""
    def __init__(self,*,store:DualPerformanceStore,absorption,features):
        self.store=store;self.absorption=absorption;self.features=features;self._last={};self.last_refresh_at=None;self.last_error=None
    def refresh(self,asof:datetime|None=None):
        now=asof or datetime.now(timezone.utc);day=now.astimezone(KST).date().isoformat();created=transitions=outcomes=0
        frames=list(self.absorption.frames.values())
        for f in frames:
            if f.venue!=Venue.KRX or f.price is None or f.price<=0:continue
            key=(f.venue,f.symbol);prev=self._last.get(key)
            if prev and prev.model==f.model and prev.stage!=f.stage and prev.stage in TRACK and f.stage in TRACK:
                if self.store.insert_transition(StageTransition(trading_day=day,symbol=f.symbol,model=f.model,from_stage=prev.stage,to_stage=f.stage,transition_at=now,price=f.price,score_100=f.score_100)):transitions+=1
            if f.stage in TRACK and f.model!=AbsorptionModel.NONE:
                trust=f.stage_trust
                rec=DualSignalRecord(signal_id=uuid4().hex,trading_day=day,symbol=f.symbol,model=f.model,stage=f.stage,signal_at=now,signal_price=f.price,
                  score_100=f.score_100,price_hold_score_25=f.price_defense_score_25,absorption_ratio=f.absorption_ratio,absorption_ratio_delta=f.absorption_ratio_delta,
                  seller_actor=f.seller_actor,absorber_actor=f.absorber_actor,seller_new_sell_velocity_per_min=f.seller_new_sell_velocity_per_min,seller_sell_deceleration_count=f.seller_sell_deceleration_count,
                  foreign_net=f.foreign_net,institution_net=f.institution_net,fund_net=f.fund_net,pension_net=f.pension_net,program_net=f.program_net,other_corporation_net=f.other_corporation_net,
                  market_rs=f.rs_level,sector_rs=f.sector_relative_strength_pct,vwap_distance_pct=f.vwap_distance_pct,range_position=f.intraday_range_position,money_acceleration=f.money_acceleration,
                  sector_breadth_ratio=f.sector_breadth_ratio,fact_trust=trust,preemptive_fit=f.preemptive_fit,price_compression=f.price_compression,
                  highest_price=f.price,lowest_price=f.price,last_price=f.price,last_update_at=now)
                if self.store.insert_signal(rec):created+=1
            self._last[key]=f.model_copy(deep=True)
        # MFE/MAE and 10/30m use only fresh current-session feature prices.
        for r in self.store.active_day_signals(day):
            feat=self.features.frames.get((Venue(r['venue']),r['symbol']))
            if feat is None or feat.price is None or feat.price<=0:continue
            age=max(0,(now-feat.asof).total_seconds())
            if age>7:continue
            self.store.update_excursion(r['signal_id'],float(feat.price),now)
        for o in self.store.due_intraday(now):
            r=next((x for x in self.store.active_day_signals(day) if x['signal_id']==o['signal_id']),None)
            if r is None:continue
            feat=self.features.frames.get((Venue(r['venue']),r['symbol']))
            if feat is None or feat.price is None or feat.price<=0 or max(0,(now-feat.asof).total_seconds())>7:continue
            if self.store.capture(r['signal_id'],o['horizon'],float(feat.price),now):outcomes+=1
        self.last_refresh_at=now;self.last_error=None;return {'created':created,'transitions':transitions,'outcomes':outcomes}
    def summary(self,limit=1000):
        rows=self.store.recent(limit);groups={}
        for r in rows:
            for key in (f"MODEL:{r['model']}",f"STAGE:{r['stage']}",f"MODEL_STAGE:{r['model']}|{r['stage']}"):
                g=groups.setdefault(key,{'count':0,'mfe':[],'mae':[],'outcomes':{h:[] for h in ('10M','30M','CLOSE','1D','3D','5D')}});g['count']+=1;g['mfe'].append(r['mfe_pct']);g['mae'].append(r['mae_pct'])
                for o in self.store.outcome_rows(r['signal_id']):
                    if o['status']=='CAPTURED' and o['return_pct'] is not None:g['outcomes'][o['horizon']].append(o['return_pct'])
        def avg(a):return None if not a else round(sum(a)/len(a),4)
        out=[]
        for k,g in groups.items():out.append({'group':k,'count':g['count'],'mfe_avg_pct':avg(g['mfe']),'mae_avg_pct':avg(g['mae']),'outcomes':{h:{'count':len(v),'avg_return_pct':avg(v),'win_rate_pct':None if not v else round(sum(x>0 for x in v)*100/len(v),2)} for h,v in g['outcomes'].items()}})
        return sorted(out,key=lambda x:(x['group']))
    def transition_rates(self,limit=5000):
        sig=self.store.recent(limit);trans=self.store.transitions(limit);den={};num={}
        for r in sig:den[(r['model'],r['stage'])]=den.get((r['model'],r['stage']),0)+1
        for t in trans:num[(t['model'],t['from_stage'],t['to_stage'])]=num.get((t['model'],t['from_stage'],t['to_stage']),0)+1
        return [{'model':m,'from_stage':a,'to_stage':b,'transitions':n,'source_signals':den.get((m,a),0),'transition_rate_pct':None if not den.get((m,a)) else round(n*100/den[(m,a)],2)} for (m,a,b),n in sorted(num.items())]

class DualDailyOutcomeService:
    """Outcome-only CLOSE/1D/3D/5D completion; never feeds current selection."""
    def __init__(self,*,store,source,max_symbols_per_cycle=20):
        self.store=store;self.source=source;self.max_symbols_per_cycle=max(1,int(max_symbols_per_cycle));self.last_refresh_at=None;self.last_error=None
    async def refresh(self,asof=None):
        from datetime import date,time
        now=asof or datetime.now(timezone.utc);rows=self.store.pending_daily(500);by={}
        for r in rows:by.setdefault(r['symbol'],[]).append(r)
        fetched=captured=0
        for symbol,signals in list(by.items())[:self.max_symbols_per_cycle]:
            bars=await self.source.fetch(symbol,now.astimezone(KST).date());fetched+=1
            for r in signals:
                sd=date.fromisoformat(r['trading_day']);same=next((b for b in bars if b.trading_date==sd),None);future=[b for b in bars if b.trading_date>sd]
                pending={o['horizon']:o for o in self.store.outcome_rows(r['signal_id']) if o['status']=='PENDING'}
                local=datetime.fromisoformat(r['signal_at']).astimezone(KST)
                if 'CLOSE' in pending and local.time()<=time(15,30) and same is not None and (now.astimezone(KST).date()>sd or now.astimezone(KST).time()>=time(15,40)):
                    captured+=int(self.store.capture(r['signal_id'],'CLOSE',same.close,now,same.trading_date.isoformat()))
                for h,idx in [('1D',0),('3D',2),('5D',4)]:
                    if h in pending and len(future)>idx:
                        b=future[idx];captured+=int(self.store.capture(r['signal_id'],h,b.close,now,b.trading_date.isoformat()))
        self.last_refresh_at=now;self.last_error=None;return {'symbols':len(by),'fetched':fetched,'captured':captured}
