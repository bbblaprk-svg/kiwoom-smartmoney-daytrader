from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

from pulse_edge.absorption.models import AbsorptionModel, AbsorptionStage, FactTrust
from .models import IntradayEvidence, OpportunityRecord


def _iso(v: datetime | None) -> str | None:
    if v is None:
        return None
    if v.tzinfo is None:
        v = v.replace(tzinfo=timezone.utc)
    return v.astimezone(timezone.utc).isoformat()


def _dt(v: str | None) -> datetime | None:
    if not v:
        return None
    x = datetime.fromisoformat(v)
    return x if x.tzinfo else x.replace(tzinfo=timezone.utc)


class MissedOpportunityStore:
    """One-way Phase 6F audit archive. No method supplies current selection inputs."""

    def __init__(self, path: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._schema()

    def _schema(self) -> None:
        self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS missed_evidence(
              trading_day TEXT NOT NULL,
              symbol TEXT NOT NULL,
              first_discovery_at TEXT,
              last_discovery_at TEXT,
              discovery_sources_json TEXT NOT NULL,
              last_frame_at TEXT,
              last_model TEXT NOT NULL,
              best_stage TEXT NOT NULL,
              best_stage_order INTEGER NOT NULL,
              best_score_100 REAL NOT NULL,
              max_absorption_ratio REAL,
              price_hold_ever INTEGER NOT NULL,
              first_price_hold_at TEXT,
              max_sell_decel_count INTEGER NOT NULL,
              program_buy_turn_ever INTEGER NOT NULL,
              vwap_positive_ever INTEGER NOT NULL,
              max_sector_breadth_ratio REAL,
              last_change_rate REAL,
              price_trust TEXT NOT NULL,
              investor_trust TEXT NOT NULL,
              program_trust TEXT NOT NULL,
              PRIMARY KEY(trading_day,symbol)
            );
            CREATE INDEX IF NOT EXISTS idx_missed_evidence_day
              ON missed_evidence(trading_day,symbol);

            CREATE TABLE IF NOT EXISTS missed_opportunity(
              trading_day TEXT NOT NULL,
              symbol TEXT NOT NULL,
              market TEXT NOT NULL,
              name TEXT,
              scanned_at TEXT NOT NULL,
              status TEXT NOT NULL,
              close_price REAL NOT NULL,
              change_pct REAL NOT NULL,
              reference_close_estimate REAL,
              volume REAL,
              execution_strength REAL,
              source_rank INTEGER NOT NULL,
              source_api_id TEXT NOT NULL,
              source_api_verified INTEGER NOT NULL,
              universe_eligible INTEGER,
              universe_reasons_json TEXT NOT NULL,
              caught_by TEXT,
              caught_stage TEXT,
              caught_model TEXT,
              first_signal_at TEXT,
              first_signal_price REAL,
              first_signal_change_pct REAL,
              primary_reason TEXT,
              reasons_json TEXT NOT NULL,
              diagnostic_confidence TEXT NOT NULL,
              discovery_sources_json TEXT NOT NULL,
              best_stage TEXT,
              best_score_100 REAL,
              max_absorption_ratio REAL,
              price_hold_ever INTEGER,
              max_sell_decel_count INTEGER,
              program_buy_turn_ever INTEGER,
              max_sector_breadth_ratio REAL,
              last_model TEXT,
              price_trust TEXT,
              investor_trust TEXT,
              program_trust TEXT,
              feeds_current_ranking INTEGER NOT NULL DEFAULT 0,
              feeds_current_score INTEGER NOT NULL DEFAULT 0,
              official_signal_enabled INTEGER NOT NULL DEFAULT 0,
              order_action_enabled INTEGER NOT NULL DEFAULT 0,
              PRIMARY KEY(trading_day,symbol)
            );
            CREATE INDEX IF NOT EXISTS idx_missed_status
              ON missed_opportunity(trading_day,status,change_pct DESC);

            CREATE TABLE IF NOT EXISTS missed_scan_run(
              trading_day TEXT PRIMARY KEY,
              scanned_at TEXT NOT NULL,
              surge_threshold_pct REAL NOT NULL,
              markets_scanned INTEGER NOT NULL,
              pages_requested INTEGER NOT NULL,
              raw_rows INTEGER NOT NULL,
              surge_rows INTEGER NOT NULL,
              caught_rows INTEGER NOT NULL,
              missed_rows INTEGER NOT NULL,
              excluded_rows INTEGER NOT NULL,
              api_id_verified INTEGER NOT NULL,
              feeds_current_ranking INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        self._db.commit()

    @staticmethod
    def _stage_order(stage: AbsorptionStage) -> int:
        order = [
            AbsorptionStage.DATA_WAIT,
            AbsorptionStage.WATCH,
            AbsorptionStage.ABSORB,
            AbsorptionStage.PRICE_HOLD,
            AbsorptionStage.SUPPLY_TIGHT,
            AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,
            AbsorptionStage.PRE_IGNITION,
            AbsorptionStage.IGNITION,
        ]
        return order.index(stage)

    def merge_discovery(self, trading_day: str, symbol: str, at: datetime, source: str) -> None:
        with self._lock:
            row = self._db.execute(
                "SELECT * FROM missed_evidence WHERE trading_day=? AND symbol=?", (trading_day, symbol)
            ).fetchone()
            if row is None:
                self._db.execute(
                    """INSERT INTO missed_evidence(
                    trading_day,symbol,first_discovery_at,last_discovery_at,discovery_sources_json,last_model,best_stage,
                    best_stage_order,best_score_100,price_hold_ever,max_sell_decel_count,program_buy_turn_ever,vwap_positive_ever,
                    price_trust,investor_trust,program_trust)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        trading_day, symbol, _iso(at), _iso(at), json.dumps([source]), AbsorptionModel.NONE.value,
                        AbsorptionStage.DATA_WAIT.value, 0, 0.0, 0, 0, 0, 0, FactTrust.UNAVAILABLE.value, FactTrust.UNAVAILABLE.value, FactTrust.UNAVAILABLE.value,
                    ),
                )
            else:
                sources = list(dict.fromkeys([*json.loads(row["discovery_sources_json"] or "[]"), source]))
                first_at = _dt(row["first_discovery_at"])
                last_at = _dt(row["last_discovery_at"])
                first_at = at if first_at is None or at < first_at else first_at
                last_at = at if last_at is None or at > last_at else last_at
                self._db.execute(
                    "UPDATE missed_evidence SET first_discovery_at=?,last_discovery_at=?,discovery_sources_json=? WHERE trading_day=? AND symbol=?",
                    (_iso(first_at), _iso(last_at), json.dumps(sources), trading_day, symbol),
                )
            self._db.commit()

    def merge_frame(self, e: IntradayEvidence) -> None:
        with self._lock:
            row = self._db.execute(
                "SELECT * FROM missed_evidence WHERE trading_day=? AND symbol=?", (e.trading_day, e.symbol)
            ).fetchone()
            stage_order = self._stage_order(e.best_stage)
            if row is None:
                self._db.execute(
                    """INSERT INTO missed_evidence(
                    trading_day,symbol,first_discovery_at,last_discovery_at,discovery_sources_json,last_frame_at,last_model,best_stage,
                    best_stage_order,best_score_100,max_absorption_ratio,price_hold_ever,first_price_hold_at,max_sell_decel_count,
                    program_buy_turn_ever,vwap_positive_ever,max_sector_breadth_ratio,last_change_rate,price_trust,investor_trust,program_trust)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        e.trading_day,e.symbol,_iso(e.first_discovery_at),_iso(e.last_discovery_at),json.dumps(e.discovery_sources),
                        _iso(e.last_frame_at),e.last_model.value,e.best_stage.value,stage_order,e.best_score_100,e.max_absorption_ratio,
                        int(e.price_hold_ever),_iso(e.first_price_hold_at),e.max_sell_decel_count,int(e.program_buy_turn_ever),
                        int(e.vwap_positive_ever),e.max_sector_breadth_ratio,e.last_change_rate,e.price_trust.value,e.investor_trust.value,e.program_trust.value,
                    ),
                )
            else:
                old_order = int(row["best_stage_order"])
                best_stage = e.best_stage.value if stage_order >= old_order else row["best_stage"]
                best_order = max(stage_order, old_order)
                best_score = max(float(row["best_score_100"] or 0.0), e.best_score_100)
                old_ratio = row["max_absorption_ratio"]
                max_ratio = e.max_absorption_ratio if old_ratio is None else old_ratio if e.max_absorption_ratio is None else max(float(old_ratio), e.max_absorption_ratio)
                old_breadth = row["max_sector_breadth_ratio"]
                max_breadth = e.max_sector_breadth_ratio if old_breadth is None else old_breadth if e.max_sector_breadth_ratio is None else max(float(old_breadth), e.max_sector_breadth_ratio)
                first_ph = _dt(row["first_price_hold_at"])
                if first_ph is None and e.first_price_hold_at is not None:
                    first_ph = e.first_price_hold_at
                self._db.execute(
                    """UPDATE missed_evidence SET last_frame_at=?,last_model=?,best_stage=?,best_stage_order=?,best_score_100=?,
                    max_absorption_ratio=?,price_hold_ever=?,first_price_hold_at=?,max_sell_decel_count=?,program_buy_turn_ever=?,
                    vwap_positive_ever=?,max_sector_breadth_ratio=?,last_change_rate=?,price_trust=?,investor_trust=?,program_trust=?
                    WHERE trading_day=? AND symbol=?""",
                    (
                        _iso(e.last_frame_at),e.last_model.value,best_stage,best_order,best_score,max_ratio,
                        int(bool(row["price_hold_ever"]) or e.price_hold_ever),_iso(first_ph),
                        max(int(row["max_sell_decel_count"] or 0), e.max_sell_decel_count),
                        int(bool(row["program_buy_turn_ever"]) or e.program_buy_turn_ever),
                        int(bool(row["vwap_positive_ever"]) or e.vwap_positive_ever),max_breadth,e.last_change_rate,
                        e.price_trust.value,e.investor_trust.value,e.program_trust.value,e.trading_day,e.symbol,
                    ),
                )
            self._db.commit()

    def evidence(self, trading_day: str, symbol: str) -> IntradayEvidence | None:
        row = self._db.execute(
            "SELECT * FROM missed_evidence WHERE trading_day=? AND symbol=?", (trading_day, symbol)
        ).fetchone()
        if row is None:
            return None
        return IntradayEvidence(
            trading_day=row["trading_day"], symbol=row["symbol"], first_discovery_at=_dt(row["first_discovery_at"]),
            last_discovery_at=_dt(row["last_discovery_at"]), discovery_sources=json.loads(row["discovery_sources_json"] or "[]"),
            last_frame_at=_dt(row["last_frame_at"]), last_model=AbsorptionModel(row["last_model"]), best_stage=AbsorptionStage(row["best_stage"]),
            best_score_100=float(row["best_score_100"] or 0.0), max_absorption_ratio=row["max_absorption_ratio"],
            price_hold_ever=bool(row["price_hold_ever"]), first_price_hold_at=_dt(row["first_price_hold_at"]),
            max_sell_decel_count=int(row["max_sell_decel_count"] or 0), program_buy_turn_ever=bool(row["program_buy_turn_ever"]),
            vwap_positive_ever=bool(row["vwap_positive_ever"]), max_sector_breadth_ratio=row["max_sector_breadth_ratio"],
            last_change_rate=row["last_change_rate"], price_trust=FactTrust(row["price_trust"]), investor_trust=FactTrust(row["investor_trust"]),
            program_trust=FactTrust(row["program_trust"]),
        )

    def insert_opportunity(self, x: OpportunityRecord) -> bool:
        with self._lock:
            cur = self._db.execute(
                """INSERT OR REPLACE INTO missed_opportunity(
                trading_day,symbol,market,name,scanned_at,status,close_price,change_pct,reference_close_estimate,volume,execution_strength,
                source_rank,source_api_id,source_api_verified,universe_eligible,universe_reasons_json,caught_by,caught_stage,caught_model,
                first_signal_at,first_signal_price,first_signal_change_pct,primary_reason,reasons_json,diagnostic_confidence,
                discovery_sources_json,best_stage,best_score_100,max_absorption_ratio,price_hold_ever,max_sell_decel_count,
                program_buy_turn_ever,max_sector_breadth_ratio,last_model,price_trust,investor_trust,program_trust,feeds_current_ranking,feeds_current_score,
                official_signal_enabled,order_action_enabled)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    x.trading_day,x.symbol,x.market.value,x.name,_iso(x.scanned_at),x.status.value,x.close_price,x.change_pct,
                    x.reference_close_estimate,x.volume,x.execution_strength,x.source_rank,x.source_api_id,int(x.source_api_verified),
                    None if x.universe_eligible is None else int(x.universe_eligible),json.dumps(x.universe_reasons,ensure_ascii=False),
                    x.caught_by,x.caught_stage,x.caught_model,_iso(x.first_signal_at),x.first_signal_price,x.first_signal_change_pct,
                    x.primary_reason.value if x.primary_reason else None,json.dumps([r.value for r in x.reasons],ensure_ascii=False),
                    x.diagnostic_confidence.value,json.dumps(x.discovery_sources,ensure_ascii=False),x.best_stage.value if x.best_stage else None,
                    x.best_score_100,x.max_absorption_ratio,None if x.price_hold_ever is None else int(x.price_hold_ever),x.max_sell_decel_count,
                    None if x.program_buy_turn_ever is None else int(x.program_buy_turn_ever),x.max_sector_breadth_ratio,
                    x.last_model.value if x.last_model else None,x.price_trust.value if x.price_trust else None,
                    x.investor_trust.value if x.investor_trust else None,x.program_trust.value if x.program_trust else None,
                    int(x.feeds_current_ranking),int(x.feeds_current_score),
                    int(x.official_signal_enabled),int(x.order_action_enabled),
                ),
            )
            self._db.commit()
            return bool(cur.rowcount)

    def upsert_scan_run(self, *, trading_day: str, scanned_at: datetime, threshold: float, markets: int, pages: int,
                        raw_rows: int, surge_rows: int, caught: int, missed: int, excluded: int, api_verified: bool) -> None:
        with self._lock:
            self._db.execute(
                """INSERT OR REPLACE INTO missed_scan_run(
                trading_day,scanned_at,surge_threshold_pct,markets_scanned,pages_requested,raw_rows,surge_rows,caught_rows,
                missed_rows,excluded_rows,api_id_verified,feeds_current_ranking)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,0)""",
                (trading_day,_iso(scanned_at),threshold,markets,pages,raw_rows,surge_rows,caught,missed,excluded,int(api_verified)),
            )
            self._db.commit()

    def has_scan(self, trading_day: str) -> bool:
        return self._db.execute("SELECT 1 FROM missed_scan_run WHERE trading_day=?", (trading_day,)).fetchone() is not None

    def recent(self, limit: int = 100, *, status: str | None = None):
        if status:
            return self._db.execute(
                "SELECT * FROM missed_opportunity WHERE status=? ORDER BY trading_day DESC,change_pct DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        return self._db.execute(
            "SELECT * FROM missed_opportunity ORDER BY trading_day DESC,change_pct DESC LIMIT ?", (limit,)
        ).fetchall()

    def summary(self, trading_day: str | None = None) -> dict:
        where = ""
        args: tuple[object, ...] = ()
        if trading_day:
            where = " WHERE trading_day=?"
            args = (trading_day,)
        rows = self._db.execute(f"SELECT * FROM missed_opportunity{where}", args).fetchall()
        reasons: dict[str, int] = {}
        status: dict[str, int] = {}
        for row in rows:
            status[row["status"]] = status.get(row["status"], 0) + 1
            if row["primary_reason"]:
                reasons[row["primary_reason"]] = reasons.get(row["primary_reason"], 0) + 1
        return {
            "count": len(rows),
            "status": dict(sorted(status.items())),
            "primary_reasons": dict(sorted(reasons.items(), key=lambda kv: (-kv[1], kv[0]))),
        }

    def scan_runs(self, limit: int = 30):
        return self._db.execute(
            "SELECT * FROM missed_scan_run ORDER BY trading_day DESC LIMIT ?", (limit,)
        ).fetchall()

    def close(self) -> None:
        self._db.close()
