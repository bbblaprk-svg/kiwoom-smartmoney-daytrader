from __future__ import annotations

from datetime import datetime, time, timezone
from typing import Any, Protocol
from zoneinfo import ZoneInfo

from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.core.models import Venue
from pulse_edge.features.benchmark import MarketClass
from pulse_edge.feed.rest import RestPage
from .models import (
    DiagnosticConfidence,
    IntradayEvidence,
    MissReason,
    OpportunityRecord,
    OpportunityStatus,
    SurgeFact,
)
from .store import MissedOpportunityStore

KST = ZoneInfo("Asia/Seoul")
STAGE_ORDER = {s: i for i, s in enumerate([
    AbsorptionStage.DATA_WAIT,
    AbsorptionStage.WATCH,
    AbsorptionStage.ABSORB,
    AbsorptionStage.PRICE_HOLD,
    AbsorptionStage.SUPPLY_TIGHT,
    AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED,
    AbsorptionStage.PRE_IGNITION,
    AbsorptionStage.IGNITION,
])}
PREEMPTIVE_STAGES = {
    AbsorptionStage.PRICE_HOLD.value,
    AbsorptionStage.SUPPLY_TIGHT.value,
    AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED.value,
    AbsorptionStage.PRE_IGNITION.value,
}


class RestLike(Protocol):
    async def post(self, api_id: str, path: str, body: dict[str, Any], cont_yn: str | None = None,
                   next_key: str | None = None) -> RestPage: ...


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").replace("%", "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _symbol(value: Any) -> str:
    raw = str(value or "").strip()
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits[:6] if len(digits) >= 6 else ""


class MissedOpportunityService:
    """Phase 6F one-way audit observer.

    It preserves compact intraday evidence, scans KRX post-close gainers with ka10027,
    and explains missed pre-ignition opportunities. Audit history never feeds scores,
    membership, discovery supply, or ordering.
    """

    API_ID = "ka10027"
    PATH = "/api/dostk/rkinfo"
    RESPONSE_KEY = "pred_pre_flu_rt_upper"

    def __init__(self, *, store: MissedOpportunityStore, rest: RestLike, universe, discovery, absorption, session_router,
                 dual_store=None, signal_store=None, surge_threshold_pct: float = 5.0,
                 post_close_time: time = time(15, 40), max_pages_per_market: int = 5,
                 trade_value_condition: str = "10"):
        self.store = store
        self.rest = rest
        self.universe = universe
        self.discovery = discovery
        self.absorption = absorption
        self.session_router = session_router
        self.dual_store = dual_store
        self.signal_store = signal_store
        self.surge_threshold_pct = max(0.1, float(surge_threshold_pct))
        self.post_close_time = post_close_time
        self.max_pages_per_market = max(1, int(max_pages_per_market))
        self.trade_value_condition = str(trade_value_condition)
        self.last_refresh_at: datetime | None = None
        self.last_scan_at: datetime | None = None
        self.last_error: str | None = None
        self.last_scan_stats: dict[str, int | float | bool] = {}
        self._seen_discovery_keys: set[tuple[str, str, str, str]] = set()

    @staticmethod
    def _day(now: datetime) -> str:
        return now.astimezone(KST).date().isoformat()

    def capture_evidence(self, now: datetime) -> int:
        day = self._day(now)
        count = 0
        for event in self.discovery.recent(2000) if self.discovery is not None else []:
            if event.venue != Venue.KRX:
                continue
            event_day = event.observed_at.astimezone(KST).date().isoformat()
            if event_day != day:
                continue
            key = (day, event.symbol, event.source.value, event.observed_at.isoformat())
            if key in self._seen_discovery_keys:
                continue
            self._seen_discovery_keys.add(key)
            self.store.merge_discovery(day, event.symbol, event.observed_at, event.source.value)
            count += 1

        for frame in list(self.absorption.frames.values()) if self.absorption is not None else []:
            if frame.venue != Venue.KRX:
                continue
            frame_day = frame.asof.astimezone(KST).date().isoformat()
            if frame_day != day:
                continue
            self.store.merge_frame(self._frame_evidence(day, frame))
            count += 1
        return count

    @staticmethod
    def _frame_evidence(day: str, f: AbsorptionFrame) -> IntradayEvidence:
        return IntradayEvidence(
            trading_day=day,
            symbol=f.symbol,
            last_frame_at=f.asof,
            last_model=f.model,
            best_stage=f.stage,
            best_score_100=f.score_100,
            max_absorption_ratio=f.absorption_ratio,
            price_hold_ever=f.price_hold_pass,
            first_price_hold_at=f.asof if f.price_hold_pass else None,
            max_sell_decel_count=f.seller_sell_deceleration_count,
            program_buy_turn_ever=f.program_buy_turn is True,
            vwap_positive_ever=f.vwap_distance_pct is not None and f.vwap_distance_pct > 0,
            max_sector_breadth_ratio=f.sector_breadth_ratio,
            last_change_rate=f.change_rate,
            price_trust=f.price_trust,
            investor_trust=f.investor_trust,
            program_trust=f.program_trust,
        )

    async def refresh(self, asof: datetime | None = None) -> dict[str, Any]:
        now = asof or datetime.now(timezone.utc)
        local = now.astimezone(KST)
        if not self.session_router.is_trading_day(local.date()):
            self.last_refresh_at = now
            self.last_error = None
            return {"evidence_updates": 0, "post_close_scanned": False, "trading_day": False}
        captured = self.capture_evidence(now)
        scanned = False
        if local.time() >= self.post_close_time and not self.store.has_scan(local.date().isoformat()):
            await self.scan_post_close(now)
            scanned = True
        self.last_refresh_at = now
        self.last_error = None
        return {"evidence_updates": captured, "post_close_scanned": scanned, "trading_day": True, **self.last_scan_stats}

    async def _rank_market(self, market_code: str, market: MarketClass, trading_day: str) -> tuple[list[SurgeFact], int, int, bool]:
        body = {
            "mrkt_tp": market_code,
            "sort_tp": "1",
            "trde_qty_cnd": "0000",
            "stk_cnd": "0",
            "crd_cnd": "0",
            "updown_incls": "1",
            "pric_cnd": "0",
            "trde_prica_cnd": self.trade_value_condition,
            "stex_tp": "1",
        }
        cont_yn: str | None = None
        next_key: str | None = None
        out: list[SurgeFact] = []
        raw_rows = 0
        pages = 0
        all_verified = True
        for page_index in range(self.max_pages_per_market):
            page = await self.rest.post(self.API_ID, self.PATH, body, cont_yn, next_key)
            pages += 1
            if page.response_api_id != self.API_ID:
                if page.response_api_id is None:
                    raise RuntimeError(f"rank api provenance missing: requested={self.API_ID}")
                raise RuntimeError(f"rank api provenance mismatch: requested={self.API_ID} response={page.response_api_id}")
            if self.RESPONSE_KEY not in page.body:
                raise RuntimeError("ka10027 response schema mismatch: pred_pre_flu_rt_upper missing")
            rows = page.body.get(self.RESPONSE_KEY)
            if not isinstance(rows, list):
                raise RuntimeError("ka10027 response schema mismatch: pred_pre_flu_rt_upper is not a list")
            below_threshold_seen = False
            for idx, row in enumerate(rows, start=1):
                if not isinstance(row, dict):
                    continue
                raw_rows += 1
                change = _num(row.get("flu_rt"))
                if change is None:
                    continue
                if change < self.surge_threshold_pct:
                    below_threshold_seen = True
                    continue
                symbol = _symbol(row.get("stk_cd"))
                price = abs(_num(row.get("cur_prc")) or 0.0)
                if not symbol or price <= 0:
                    continue
                reference = price / (1.0 + change / 100.0) if change > -99.9 else None
                out.append(SurgeFact(
                    trading_day=trading_day,
                    market=market,
                    symbol=symbol,
                    name=str(row.get("stk_nm")) if row.get("stk_nm") is not None else None,
                    source_rank=page_index * max(1, len(rows)) + idx,
                    close_price=price,
                    change_pct=change,
                    reference_close_estimate=reference,
                    volume=abs(_num(row.get("now_trde_qty")) or 0.0) or None,
                    execution_strength=_num(row.get("cntr_str")),
                    source_api_verified=page.response_api_id == self.API_ID,
                ))
            cont_yn, next_key = page.cont_yn, page.next_key
            if below_threshold_seen or cont_yn != "Y" or not next_key:
                break
        return out, pages, raw_rows, all_verified

    @staticmethod
    def _signal_change_pct(signal_price: float | None, reference_close: float | None) -> float | None:
        if signal_price is None or reference_close is None or signal_price <= 0 or reference_close <= 0:
            return None
        return (signal_price / reference_close - 1.0) * 100.0

    def _caught_signal(self, fact: SurgeFact) -> dict[str, Any] | None:
        rows: list[dict[str, Any]] = []
        if self.dual_store is not None:
            for row in self.dual_store.active_day_signals(fact.trading_day):
                if row["venue"] != Venue.KRX.value or row["symbol"] != fact.symbol:
                    continue
                chg = self._signal_change_pct(float(row["signal_price"]), fact.reference_close_estimate)
                rows.append({
                    "caught_by": "DUAL_SIGNAL_LEDGER",
                    "stage": row["stage"],
                    "model": row["model"],
                    "at": datetime.fromisoformat(row["signal_at"]),
                    "price": float(row["signal_price"]),
                    "change": chg,
                    "preemptive_fit": row["preemptive_fit"],
                })
        if self.signal_store is not None:
            for ep in self.signal_store.recent_episodes(500):
                if ep.trading_day != fact.trading_day or ep.venue != Venue.KRX or ep.symbol != fact.symbol:
                    continue
                chg = self._signal_change_pct(ep.signal_price, fact.reference_close_estimate)
                rows.append({
                    "caught_by": "PHASE4_SIGNAL_LEDGER",
                    "stage": ep.current_stage,
                    "model": None,
                    "at": ep.signal_at,
                    "price": ep.signal_price,
                    "change": chg,
                    "preemptive_fit": "ALLOW",
                })
        rows.sort(key=lambda x: x["at"])
        for row in rows:
            stage_ok = row["caught_by"] == "PHASE4_SIGNAL_LEDGER" or row["stage"] in PREEMPTIVE_STAGES
            change_ok = row["change"] is not None and row["change"] < self.surge_threshold_pct
            if stage_ok and change_ok and row["preemptive_fit"] != "EXCLUDE":
                return row
        # No valid preemptive catch. Prefer the first actionable-but-late event over
        # an earlier WATCH/ABSORB observation so late detection is not hidden.
        for row in rows:
            if (row["caught_by"] == "PHASE4_SIGNAL_LEDGER" or row["stage"] in PREEMPTIVE_STAGES
                    or row["stage"] == AbsorptionStage.IGNITION.value or row["preemptive_fit"] == "EXCLUDE"):
                return row
        return rows[0] if rows else None

    def _diagnose(self, fact: SurgeFact, e: IntradayEvidence | None, detected: dict[str, Any] | None) -> tuple[OpportunityStatus, list[MissReason], DiagnosticConfidence]:
        if detected is not None:
            change = detected.get("change")
            stage = detected.get("stage")
            if (change is not None and change < self.surge_threshold_pct) and (
                detected.get("caught_by") == "PHASE4_SIGNAL_LEDGER" or stage in PREEMPTIVE_STAGES
            ) and detected.get("preemptive_fit") != "EXCLUDE":
                return OpportunityStatus.CAUGHT_PREEMPTIVE, [], DiagnosticConfidence.HIGH

        reasons: list[MissReason] = []
        if detected is not None:
            change = detected.get("change")
            if (change is not None and change >= self.surge_threshold_pct) or detected.get("stage") == AbsorptionStage.IGNITION.value or detected.get("preemptive_fit") == "EXCLUDE":
                reasons.append(MissReason.LATE_DETECTION)
        if e is None:
            reasons.append(MissReason.DATA_COVERAGE_MISS)
            return OpportunityStatus.MISSED, reasons, DiagnosticConfidence.LOW
        if not e.discovery_sources:
            reasons.append(MissReason.DISCOVERY_EVIDENCE_ABSENT)
        if STAGE_ORDER[e.best_stage] < STAGE_ORDER[AbsorptionStage.ABSORB]:
            reasons.append(MissReason.ABSORPTION_NOT_FORMED)
        if not e.price_hold_ever:
            reasons.append(MissReason.PRICE_HOLD_FAILED)
        if e.max_absorption_ratio is None or e.max_absorption_ratio < 0.70:
            reasons.append(MissReason.ABSORPTION_WEAK)
        if e.max_sell_decel_count < 2:
            reasons.append(MissReason.SELL_DECEL_INSUFFICIENT)
        if e.program_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE}:
            reasons.append(MissReason.PROGRAM_DATA_UNAVAILABLE)
        elif not e.program_buy_turn_ever:
            reasons.append(MissReason.PROGRAM_TURN_NOT_SEEN)
        if e.max_sector_breadth_ratio is None:
            reasons.append(MissReason.SECTOR_BREADTH_UNAVAILABLE)
        elif e.max_sector_breadth_ratio < 0.60:
            reasons.append(MissReason.SECTOR_BREADTH_WEAK)
        if STAGE_ORDER[e.best_stage] < STAGE_ORDER[AbsorptionStage.PRE_IGNITION]:
            reasons.append(MissReason.PREIGNITION_NOT_REACHED)
        trust_bad = e.price_trust in {FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE} or e.investor_trust in {
            FactTrust.DELAYED, FactTrust.STALE, FactTrust.UNAVAILABLE
        }
        confidence = DiagnosticConfidence.HIGH if e.discovery_sources and not trust_bad else DiagnosticConfidence.MEDIUM if e.last_frame_at else DiagnosticConfidence.LOW
        return OpportunityStatus.MISSED, list(dict.fromkeys(reasons)), confidence

    @staticmethod
    def _primary(reasons: list[MissReason]) -> MissReason | None:
        priority = [
            MissReason.LATE_DETECTION,
            MissReason.DATA_COVERAGE_MISS,
            MissReason.DISCOVERY_EVIDENCE_ABSENT,
            MissReason.PRICE_HOLD_FAILED,
            MissReason.ABSORPTION_NOT_FORMED,
            MissReason.ABSORPTION_WEAK,
            MissReason.SELL_DECEL_INSUFFICIENT,
            MissReason.SECTOR_BREADTH_WEAK,
            MissReason.SECTOR_BREADTH_UNAVAILABLE,
            MissReason.PROGRAM_DATA_UNAVAILABLE,
            MissReason.PROGRAM_TURN_NOT_SEEN,
            MissReason.PREIGNITION_NOT_REACHED,
        ]
        return next((x for x in priority if x in reasons), reasons[0] if reasons else None)

    async def scan_post_close(self, asof: datetime | None = None) -> dict[str, Any]:
        now = asof or datetime.now(timezone.utc)
        day = self._day(now)
        # Capture the last current-session evidence before comparing against winners.
        self.capture_evidence(now)
        all_rows: list[SurgeFact] = []
        pages = raw_rows = 0
        verified = True
        for market_code, market in (("001", MarketClass.KOSPI), ("101", MarketClass.KOSDAQ)):
            rows, p, raw, v = await self._rank_market(market_code, market, day)
            all_rows.extend(rows); pages += p; raw_rows += raw; verified = verified and v
        by_symbol: dict[str, SurgeFact] = {}
        for row in all_rows:
            old = by_symbol.get(row.symbol)
            if old is None or row.change_pct > old.change_pct:
                by_symbol[row.symbol] = row
        all_rows = sorted(by_symbol.values(), key=lambda x: (-x.change_pct, x.symbol))

        caught = missed = excluded = 0
        for fact in all_rows:
            eligibility = self.universe.eligibility(fact.symbol, Venue.KRX) if self.universe is not None else None
            if eligibility is None or (self.universe is not None and fact.symbol not in self.universe.stocks):
                status = OpportunityStatus.EXCLUDED_OR_UNVERIFIED
                reasons = [MissReason.UNIVERSE_METADATA_UNAVAILABLE]
                confidence = DiagnosticConfidence.LOW
                universe_eligible = None
                universe_reasons = ["UNIVERSE_METADATA_UNAVAILABLE"]
                detected = None
            elif not eligibility.eligible:
                status = OpportunityStatus.EXCLUDED_OR_UNVERIFIED
                reasons = [MissReason.UNIVERSE_INELIGIBLE]
                confidence = DiagnosticConfidence.HIGH
                universe_eligible = False
                universe_reasons = list(eligibility.reasons)
                detected = None
            else:
                universe_eligible = True
                universe_reasons = []
                evidence = self.store.evidence(day, fact.symbol)
                detected = self._caught_signal(fact)
                status, reasons, confidence = self._diagnose(fact, evidence, detected)
            evidence = self.store.evidence(day, fact.symbol)
            if status == OpportunityStatus.CAUGHT_PREEMPTIVE:
                caught += 1
            elif status == OpportunityStatus.MISSED:
                missed += 1
            else:
                excluded += 1
            rec = OpportunityRecord(
                trading_day=day,symbol=fact.symbol,market=fact.market,name=fact.name,scanned_at=now,status=status,
                close_price=fact.close_price,change_pct=fact.change_pct,reference_close_estimate=fact.reference_close_estimate,
                volume=fact.volume,execution_strength=fact.execution_strength,source_rank=fact.source_rank,source_api_id=fact.source_api_id,
                source_api_verified=fact.source_api_verified,universe_eligible=universe_eligible,universe_reasons=universe_reasons,
                caught_by=detected.get("caught_by") if detected else None,caught_stage=detected.get("stage") if detected else None,
                caught_model=detected.get("model") if detected else None,first_signal_at=detected.get("at") if detected else None,
                first_signal_price=detected.get("price") if detected else None,first_signal_change_pct=detected.get("change") if detected else None,
                primary_reason=self._primary(reasons),reasons=reasons,diagnostic_confidence=confidence,
                discovery_sources=evidence.discovery_sources if evidence else [],best_stage=evidence.best_stage if evidence else None,
                best_score_100=evidence.best_score_100 if evidence else None,max_absorption_ratio=evidence.max_absorption_ratio if evidence else None,
                price_hold_ever=evidence.price_hold_ever if evidence else None,max_sell_decel_count=evidence.max_sell_decel_count if evidence else None,
                program_buy_turn_ever=evidence.program_buy_turn_ever if evidence else None,
                max_sector_breadth_ratio=evidence.max_sector_breadth_ratio if evidence else None,last_model=evidence.last_model if evidence else None,
                price_trust=evidence.price_trust if evidence else None,investor_trust=evidence.investor_trust if evidence else None,
                program_trust=evidence.program_trust if evidence else None,
            )
            self.store.insert_opportunity(rec)
        self.store.upsert_scan_run(
            trading_day=day,scanned_at=now,threshold=self.surge_threshold_pct,markets=2,pages=pages,raw_rows=raw_rows,
            surge_rows=len(all_rows),caught=caught,missed=missed,excluded=excluded,api_verified=verified,
        )
        self.last_scan_at = now
        self.last_scan_stats = {
            "surge_rows": len(all_rows), "caught_preemptive": caught, "missed": missed, "excluded_or_unverified": excluded,
            "pages_requested": pages, "raw_rows": raw_rows, "api_id_verified": verified,
        }
        return dict(self.last_scan_stats)
