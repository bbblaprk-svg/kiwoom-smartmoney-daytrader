from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.absorption.models import AbsorptionModel, AbsorptionStage, FactTrust
from pulse_edge.features.benchmark import MarketClass


class OpportunityStatus(StrEnum):
    CAUGHT_PREEMPTIVE = "CAUGHT_PREEMPTIVE"
    MISSED = "MISSED"
    EXCLUDED_OR_UNVERIFIED = "EXCLUDED_OR_UNVERIFIED"


class MissReason(StrEnum):
    LATE_DETECTION = "LATE_DETECTION"
    DATA_COVERAGE_MISS = "DATA_COVERAGE_MISS"
    DISCOVERY_EVIDENCE_ABSENT = "DISCOVERY_EVIDENCE_ABSENT"
    ABSORPTION_NOT_FORMED = "ABSORPTION_NOT_FORMED"
    PRICE_HOLD_FAILED = "PRICE_HOLD_FAILED"
    ABSORPTION_WEAK = "ABSORPTION_WEAK"
    SELL_DECEL_INSUFFICIENT = "SELL_DECEL_INSUFFICIENT"
    PROGRAM_TURN_NOT_SEEN = "PROGRAM_TURN_NOT_SEEN"
    PROGRAM_DATA_UNAVAILABLE = "PROGRAM_DATA_UNAVAILABLE"
    SECTOR_BREADTH_WEAK = "SECTOR_BREADTH_WEAK"
    SECTOR_BREADTH_UNAVAILABLE = "SECTOR_BREADTH_UNAVAILABLE"
    PREIGNITION_NOT_REACHED = "PREIGNITION_NOT_REACHED"
    UNIVERSE_METADATA_UNAVAILABLE = "UNIVERSE_METADATA_UNAVAILABLE"
    UNIVERSE_INELIGIBLE = "UNIVERSE_INELIGIBLE"


class DiagnosticConfidence(StrEnum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class SurgeFact(BaseModel):
    trading_day: str
    market: MarketClass
    symbol: str
    name: str | None = None
    source_rank: int
    close_price: float
    change_pct: float
    reference_close_estimate: float | None = None
    volume: float | None = None
    execution_strength: float | None = None
    source_api_id: str = "ka10027"
    source_api_verified: bool = False


class IntradayEvidence(BaseModel):
    trading_day: str
    symbol: str
    first_discovery_at: datetime | None = None
    last_discovery_at: datetime | None = None
    discovery_sources: list[str] = Field(default_factory=list)
    last_frame_at: datetime | None = None
    last_model: AbsorptionModel = AbsorptionModel.NONE
    best_stage: AbsorptionStage = AbsorptionStage.DATA_WAIT
    best_score_100: float = 0.0
    max_absorption_ratio: float | None = None
    price_hold_ever: bool = False
    first_price_hold_at: datetime | None = None
    max_sell_decel_count: int = 0
    program_buy_turn_ever: bool = False
    vwap_positive_ever: bool = False
    max_sector_breadth_ratio: float | None = None
    last_change_rate: float | None = None
    price_trust: FactTrust = FactTrust.UNAVAILABLE
    investor_trust: FactTrust = FactTrust.UNAVAILABLE
    program_trust: FactTrust = FactTrust.UNAVAILABLE


class OpportunityRecord(BaseModel):
    trading_day: str
    symbol: str
    market: MarketClass
    name: str | None = None
    scanned_at: datetime
    status: OpportunityStatus
    close_price: float
    change_pct: float
    reference_close_estimate: float | None = None
    volume: float | None = None
    execution_strength: float | None = None
    source_rank: int
    source_api_id: str = "ka10027"
    source_api_verified: bool = False

    universe_eligible: bool | None = None
    universe_reasons: list[str] = Field(default_factory=list)

    caught_by: str | None = None
    caught_stage: str | None = None
    caught_model: str | None = None
    first_signal_at: datetime | None = None
    first_signal_price: float | None = None
    first_signal_change_pct: float | None = None

    primary_reason: MissReason | None = None
    reasons: list[MissReason] = Field(default_factory=list)
    diagnostic_confidence: DiagnosticConfidence = DiagnosticConfidence.LOW

    discovery_sources: list[str] = Field(default_factory=list)
    best_stage: AbsorptionStage | None = None
    best_score_100: float | None = None
    max_absorption_ratio: float | None = None
    price_hold_ever: bool | None = None
    max_sell_decel_count: int | None = None
    program_buy_turn_ever: bool | None = None
    max_sector_breadth_ratio: float | None = None
    last_model: AbsorptionModel | None = None
    price_trust: FactTrust | None = None
    investor_trust: FactTrust | None = None
    program_trust: FactTrust | None = None

    feeds_current_ranking: bool = False
    feeds_current_score: bool = False
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
