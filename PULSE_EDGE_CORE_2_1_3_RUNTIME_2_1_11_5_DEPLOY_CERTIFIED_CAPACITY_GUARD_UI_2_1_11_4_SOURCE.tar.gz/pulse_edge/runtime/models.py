from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class FeedHealth(StrEnum):
    DISABLED = "DISABLED"
    WARMING = "WARMING"
    LIVE = "LIVE"
    DEGRADED = "DEGRADED"
    STALE = "STALE"
    OFFLINE = "OFFLINE"


class LoadStage(StrEnum):
    NORMAL = "NORMAL"
    BUSY = "BUSY"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RuntimeMetrics(BaseModel):
    asof: datetime
    cpu_pct: float | None = None
    memory_pct: float | None = None
    process_rss_mb: float | None = None
    disk_pct: float | None = None
    disk_free_gb: float | None = None
    event_loop_lag_sec: float = 0.0

    feed_enabled: bool = False
    ws_connected: bool = False
    ws_last_error: str | None = None
    ws_connection_count: int = 0
    ws_reconnect_count: int = 0
    last_payload_age_sec: float | None = None

    truth_live_delta: int = 0
    truth_partial_delta: int = 0
    truth_stale_delta: int = 0
    truth_invalid_delta: int = 0
    continuity_reject_delta: int = 0
    session_reject_delta: int = 0
    total_payloads: int = 0

    dynamic_subscription_count: int = 0
    event_subscription_count: int = 0
    background_subscription_count: int = 0
    dynamic_refresh_count: int = 0
    krx_symbol_count: int = 0
    nxt_symbol_count: int = 0


class RuntimePolicy(BaseModel):
    protected_components: list[str] = Field(default_factory=list)
    suppressed_components: list[str] = Field(default_factory=list)
    interval_multipliers: dict[str, float] = Field(default_factory=dict)
    decision_lock_recommended: bool = False
    reasons: list[str] = Field(default_factory=list)


class RuntimeFrame(BaseModel):
    asof: datetime
    load_stage: LoadStage
    feed_health: FeedHealth
    metrics: RuntimeMetrics
    policy: RuntimePolicy
    official_signal_enabled: bool = False
    order_action_enabled: bool = False
