from __future__ import annotations

from enum import StrEnum

from pulse_edge.core.models import Venue


class MarketClass(StrEnum):
    KOSPI = "KOSPI"
    KOSDAQ = "KOSDAQ"
    UNKNOWN = "UNKNOWN"


class BenchmarkMapper:
    """Maps stock market membership to a benchmark index without per-symbol manual binding."""

    DEFAULTS = {
        MarketClass.KOSPI: (Venue.KRX, "001"),
        MarketClass.KOSDAQ: (Venue.KRX, "101"),
    }

    def __init__(self) -> None:
        self._market_by_symbol: dict[str, MarketClass] = {}

    def register(self, symbol: str, market: MarketClass | str) -> None:
        try:
            value = market if isinstance(market, MarketClass) else MarketClass(str(market).upper())
        except ValueError:
            value = MarketClass.UNKNOWN
        if symbol and value != MarketClass.UNKNOWN:
            self._market_by_symbol[str(symbol)] = value

    def market_for(self, symbol: str) -> MarketClass:
        return self._market_by_symbol.get(str(symbol), MarketClass.UNKNOWN)

    def benchmark_for(self, venue: Venue, symbol: str) -> tuple[Venue, str] | None:
        market = self.market_for(symbol)
        return self.DEFAULTS.get(market)

    def registered_count(self) -> int:
        return len(self._market_by_symbol)
