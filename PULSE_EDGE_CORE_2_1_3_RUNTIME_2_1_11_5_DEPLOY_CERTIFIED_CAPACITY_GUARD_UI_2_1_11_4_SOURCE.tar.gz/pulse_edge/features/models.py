from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class TradePoint(BaseModel):
    ts: datetime
    price: float
    volume: float
    change_rate: float | None = None
    cumulative_volume: float | None = None
    cumulative_amount: float | None = None


class TradeFlowPoint(BaseModel):
    ts: datetime
    price: float
    buy_exec_volume: float | None = None
    sell_exec_volume: float | None = None
    net_buy_exec_volume: float | None = None
    instant_amount: float | None = None
    buy_exec_single: float | None = None
    sell_exec_single: float | None = None


class QuoteFlowPoint(BaseModel):
    ts: datetime
    ask: float
    bid: float
    ask_qty: float | None = None
    bid_qty: float | None = None
    total_ask_qty: float | None = None
    total_bid_qty: float | None = None
    ofi_increment: float | None = None
    microprice: float | None = None
    microprice_bias_pct: float | None = None


class AuctionPoint(BaseModel):
    ts: datetime
    expected_price: float
    expected_change_rate: float | None = None
    expected_volume: float | None = None


class FeatureFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    session_id: str | None = None
    price: float | None = None
    change_rate: float | None = None
    session_vwap: float | None = None
    vwap_5m: float | None = None
    vwap_30m: float | None = None
    vwap_distance_pct: float | None = None
    return_1m_pct: float | None = None
    return_5m_pct: float | None = None
    return_10m_pct: float | None = None
    money_5m: float | None = None
    money_velocity_5m: float | None = None
    money_velocity_prev5m: float | None = None
    money_acceleration: float | None = None
    money_second_derivative: float | None = None
    spread_pct: float | None = None
    rvol_same_time: float | None = None
    baseline_days: int = 0
    benchmark_symbol: str | None = None
    rs_level: float | None = None
    rs_velocity: float | None = None
    rs_acceleration: float | None = None
    rs_zero_cross: bool | None = None
    program_net_buy_qty: float | None = None
    program_net_buy_qty_delta: float | None = None
    program_net_buy_amount: float | None = None
    program_net_buy_amount_delta: float | None = None

    # Phase 4A.1 SMART FLOW 2.0 shadow facts. These are scale-light
    # estimates derived only from already-subscribed 0B/0D realtime fields.
    ofi_10s: float | None = None
    ofi_30s: float | None = None
    ofi_2m: float | None = None
    ofi_5m: float | None = None
    aggressive_buy_ratio_10s: float | None = None
    aggressive_buy_ratio_30s: float | None = None
    aggressive_buy_ratio_2m: float | None = None
    aggressive_buy_ratio_5m: float | None = None
    trade_pressure_10s: float | None = None
    trade_pressure_30s: float | None = None
    trade_pressure_2m: float | None = None
    trade_pressure_5m: float | None = None
    microprice: float | None = None
    microprice_bias_pct: float | None = None
    large_trade_buy_persistence_2m: float | None = None
    smart_flow_realtime_score_100: float | None = None
    smart_flow_confirmed_windows: int = 0
    smart_flow_state: str = "DATA_WAIT"
    quote_age_sec: float | None = None

    coverage_sec: float = 0.0
    flags: list[str] = Field(default_factory=list)


class OpeningFrame(BaseModel):
    symbol: str
    asof: datetime
    opening_window_valid: bool = False
    nxt_change_rate: float | None = None
    krx_expected_change_rate: float | None = None
    current_dislocation_pp: float | None = None
    max_dislocation_pp: float | None = None
    min_expected_change_rate: float | None = None
    recovery_pp: float | None = None
    recovery_velocity_pp_per_min: float | None = None
    recovery_acceleration: float | None = None
    expected_volume_change: float | None = None
    sample_count: int = 0
    flags: list[str] = Field(default_factory=list)
