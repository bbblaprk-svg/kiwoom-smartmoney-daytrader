from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class PriceSample:
    ts: datetime
    price: float


def _pct(a: float, b: float) -> float | None:
    if a <= 0 or b <= 0:
        return None
    return (a / b - 1.0) * 100.0


def _at_or_before(samples: deque[PriceSample], cutoff: datetime) -> PriceSample | None:
    # Samples are chronological. Reverse lookup is semantically identical to
    # the former full forward scan and dramatically cheaper on dense ticks.
    for point in reversed(samples):
        if point.ts <= cutoff:
            return point
    return None


class RelativeStrengthEngine:
    """Pure RS calculator. Live benchmark mapping is deliberately separate."""

    def calculate(self, stock: deque[PriceSample], benchmark: deque[PriceSample], now: datetime) -> dict[str, float | bool | None]:
        if not stock or not benchmark:
            return {"level": None, "velocity": None, "acceleration": None, "zero_cross": None}

        def rs_at(minutes: int) -> float | None:
            cutoff = now - timedelta(minutes=minutes)
            s0 = _at_or_before(stock, cutoff)
            b0 = _at_or_before(benchmark, cutoff)
            if s0 is None or b0 is None:
                return None
            sr = _pct(stock[-1].price, s0.price)
            br = _pct(benchmark[-1].price, b0.price)
            if sr is None or br is None:
                return None
            return sr - br

        level = rs_at(10)
        rs5 = rs_at(5)
        rs10 = level
        rs15 = rs_at(15)
        velocity = None if rs5 is None or rs10 is None else rs5 - rs10
        prev_velocity = None if rs10 is None or rs15 is None else rs10 - rs15
        acceleration = None if velocity is None or prev_velocity is None else velocity - prev_velocity
        zero_cross = None
        if rs5 is not None and rs10 is not None:
            zero_cross = rs10 < 0 <= rs5
        return {"level": level, "velocity": velocity, "acceleration": acceleration, "zero_cross": zero_cross}
