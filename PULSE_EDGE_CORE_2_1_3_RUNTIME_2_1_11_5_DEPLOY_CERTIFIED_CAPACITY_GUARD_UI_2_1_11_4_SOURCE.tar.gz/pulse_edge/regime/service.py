from __future__ import annotations

from datetime import datetime, timezone
from statistics import median

from pulse_edge.features.engine import FeatureEngine
from pulse_edge.regime.engine import MarketRegimeEngine
from pulse_edge.regime.models import MarketRegimeFrame
from pulse_edge.sector.service import SectorBreadthService


class MarketRegimeService:
    def __init__(
        self,
        sectors: SectorBreadthService,
        features: FeatureEngine,
        engine: MarketRegimeEngine,
        *,
        sector_max_age_sec: float = 180.0,
        feature_max_age_sec: float = 30.0,
    ) -> None:
        self.sectors = sectors
        self.features = features
        self.engine = engine
        self.sector_max_age_sec = max(30.0, float(sector_max_age_sec))
        self.feature_max_age_sec = max(3.5, float(feature_max_age_sec))
        self.frame: MarketRegimeFrame | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, asof: datetime | None = None) -> MarketRegimeFrame:
        now = asof or datetime.now(timezone.utc)
        fresh = []
        ages = []
        for frame in self.sectors.frames.values():
            age = max(0.0, (now - frame.asof).total_seconds())
            if age <= self.sector_max_age_sec:
                fresh.append(frame)
                ages.append(age)
        aggregates = [f for f in fresh if f.sector_code in {"001", "101"}]

        spreads: list[float] = []
        for feature in self.features.frames.values():
            age = max(0.0, (now - feature.asof).total_seconds())
            if age <= self.feature_max_age_sec and feature.spread_pct is not None and feature.spread_pct >= 0:
                spreads.append(feature.spread_pct)
        med_spread = median(spreads) if spreads else None
        source_age = max((max(0.0, (now - f.asof).total_seconds()) for f in aggregates), default=None)

        self.frame = self.engine.evaluate(
            aggregates,
            fresh,
            median_spread_pct=med_spread,
            source_age_sec=source_age,
            asof=now,
        )
        self.last_refresh_at = now
        self.last_error = None
        return self.frame
