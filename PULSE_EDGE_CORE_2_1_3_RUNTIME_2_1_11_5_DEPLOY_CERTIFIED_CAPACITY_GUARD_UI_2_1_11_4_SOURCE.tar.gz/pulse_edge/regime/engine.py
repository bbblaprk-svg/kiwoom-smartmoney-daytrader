from __future__ import annotations

from datetime import datetime
from statistics import mean

from pulse_edge.regime.models import MarketRegimeFrame, MarketRegimeState
from pulse_edge.sector.service import SectorBreadthFrame


def _clip(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _avg(values):
    vals = [float(v) for v in values if v is not None]
    return mean(vals) if vals else None


class MarketRegimeEngine:
    """Derived market-state router using only current PULSE EDGE facts.

    No broker route is called here. The engine consumes already-loaded aggregate
    sector breadth plus fresh in-memory spread observations. It is intentionally
    conservative: missing or stale aggregate evidence becomes DATA_WAIT rather
    than being inferred from a previous session.
    """

    def evaluate(
        self,
        aggregate_frames: list[SectorBreadthFrame],
        sector_frames: list[SectorBreadthFrame],
        *,
        median_spread_pct: float | None,
        source_age_sec: float | None,
        asof: datetime,
    ) -> MarketRegimeFrame:
        flags: list[str] = []
        by_code = {f.sector_code: f for f in aggregate_frames}
        kospi = by_code.get("001")
        kosdaq = by_code.get("101")

        if not aggregate_frames or source_age_sec is None:
            return self._data_wait(asof, "MARKET_AGGREGATE_MISSING")

        changes = [f.change_rate for f in aggregate_frames]
        breadths = [f.breadth_ratio for f in aggregate_frames]
        velocities = [f.breadth_velocity_ppm for f in aggregate_frames]
        accelerations = [f.breadth_acceleration_ppm2 for f in aggregate_frames]
        avg_change = _avg(changes)
        avg_breadth = _avg(breadths)
        avg_velocity = _avg(velocities)
        avg_acceleration = _avg(accelerations)

        nonagg = [f for f in sector_frames if f.sector_code not in {"001", "002", "003", "004", "101", "201", "302", "701"}]
        strong = [f for f in nonagg if f.score_15 >= 10.5 and (f.breadth_ratio or 0) >= 60]
        strong_ratio = (len(strong) / len(nonagg) * 100.0) if nonagg else None

        if avg_change is None or avg_breadth is None:
            return self._data_wait(asof, "MARKET_DIRECTION_OR_BREADTH_MISSING")

        score = 50.0
        score += _clip(avg_change * 8.0, -20.0, 20.0)
        score += _clip((avg_breadth - 50.0) * 0.65, -20.0, 20.0)
        if avg_velocity is not None:
            score += _clip(avg_velocity * 1.5, -8.0, 8.0)
        if avg_acceleration is not None:
            score += _clip(avg_acceleration * 3.0, -7.0, 7.0)
        if strong_ratio is not None:
            if strong_ratio >= 35:
                score += 5.0
            elif strong_ratio <= 10:
                score -= 5.0
        if median_spread_pct is not None:
            if median_spread_pct > 1.0:
                score -= 10.0
                flags.append("MARKET_SPREAD_STRESS")
            elif median_spread_pct > 0.6:
                score -= 5.0
            elif median_spread_pct <= 0.35:
                score += 3.0
        score = _clip(score, 0.0, 100.0)

        if abs(avg_change) >= 3.5:
            flags.append("MARKET_VOLATILITY_ELEVATED")
        if avg_breadth < 40:
            flags.append("MARKET_BREADTH_WEAK")
        if avg_velocity is not None and avg_velocity < 0:
            flags.append("MARKET_BREADTH_DECELERATING")

        if score < 38 or avg_breadth < 40 or avg_change <= -2.5:
            state = MarketRegimeState.RED
            preferred: list[str] = []
            blocked = True
        elif score >= 62 and avg_breadth >= 55 and avg_change > -0.5:
            state = MarketRegimeState.GREEN
            preferred = [
                "SMART_PRE", "IGNITION", "EARLY_FOLLOWER", "SECOND_WAVE",
                "ORB_RETEST", "SQUEEZE_RELEASE", "VWAP_RECLAIM", "NXT_BRIDGE",
            ]
            blocked = False
        else:
            state = MarketRegimeState.YELLOW
            preferred = [
                "SECOND_WAVE", "VWAP_RECLAIM", "SMART_PRE",
                "SQUEEZE_RELEASE", "NXT_BRIDGE",
            ]
            blocked = False

        return MarketRegimeFrame(
            asof=asof,
            state=state,
            regime_score_100=round(score, 4),
            kospi_change_rate=kospi.change_rate if kospi else None,
            kosdaq_change_rate=kosdaq.change_rate if kosdaq else None,
            average_change_rate=round(avg_change, 4),
            average_breadth_ratio=round(avg_breadth, 4),
            average_breadth_velocity=None if avg_velocity is None else round(avg_velocity, 4),
            average_breadth_acceleration=None if avg_acceleration is None else round(avg_acceleration, 4),
            strong_sector_ratio=None if strong_ratio is None else round(strong_ratio, 4),
            median_fresh_spread_pct=None if median_spread_pct is None else round(median_spread_pct, 4),
            source_age_sec=round(source_age_sec, 3),
            preferred_engines=preferred,
            blocked_new_entry=blocked,
            official_signal_enabled=False,
            flags=list(dict.fromkeys(flags)),
        )

    @staticmethod
    def _data_wait(asof: datetime, flag: str) -> MarketRegimeFrame:
        return MarketRegimeFrame(
            asof=asof,
            state=MarketRegimeState.DATA_WAIT,
            regime_score_100=50.0,
            blocked_new_entry=True,
            official_signal_enabled=False,
            flags=[flag],
        )
