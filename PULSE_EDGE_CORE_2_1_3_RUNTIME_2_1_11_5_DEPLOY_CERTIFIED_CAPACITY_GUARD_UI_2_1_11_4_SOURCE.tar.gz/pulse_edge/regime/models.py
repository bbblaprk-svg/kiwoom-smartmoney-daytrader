from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class MarketRegimeState(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    GREEN = "GREEN"
    YELLOW = "YELLOW"
    RED = "RED"


class MarketRegimeFrame(BaseModel):
    asof: datetime
    state: MarketRegimeState
    regime_score_100: float = 50.0
    kospi_change_rate: float | None = None
    kosdaq_change_rate: float | None = None
    average_change_rate: float | None = None
    average_breadth_ratio: float | None = None
    average_breadth_velocity: float | None = None
    average_breadth_acceleration: float | None = None
    strong_sector_ratio: float | None = None
    median_fresh_spread_pct: float | None = None
    source_age_sec: float | None = None
    preferred_engines: list[str] = Field(default_factory=list)
    blocked_new_entry: bool = True
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
