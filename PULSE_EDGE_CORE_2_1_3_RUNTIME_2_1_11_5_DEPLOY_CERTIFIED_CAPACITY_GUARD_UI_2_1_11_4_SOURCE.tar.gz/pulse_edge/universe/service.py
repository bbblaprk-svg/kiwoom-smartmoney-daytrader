from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol

from pulse_edge.core.models import Venue
from pulse_edge.features.benchmark import BenchmarkMapper, MarketClass
from pulse_edge.feed.rest import RestPage


class RestLike(Protocol):
    async def post(
        self,
        api_id: str,
        path: str,
        body: dict[str, Any],
        cont_yn: str | None = None,
        next_key: str | None = None,
    ) -> RestPage: ...


@dataclass(frozen=True)
class UniverseStock:
    symbol: str
    name: str | None
    market: MarketClass
    listed_shares: float | None
    state: str | None
    sector_name: str | None
    size_name: str | None
    order_warning: str | None
    company_class: str | None
    nxt_enabled: bool


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _symbol(value: Any) -> str:
    raw = str(value or "").strip()
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits[:6] if len(digits) >= 6 else ""


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().upper()
    return text in {"1", "Y", "YES", "TRUE", "T"}




@dataclass(frozen=True)
class UniverseEligibility:
    symbol: str
    eligible: bool
    reasons: tuple[str, ...]
    source_kind: str = "KIWOOM_KA10099"


def _norm(value: Any) -> str:
    return str(value or "").strip().upper().replace(" ", "")


def _explicit_non_common_stock(row: UniverseStock) -> list[str]:
    reasons: list[str] = []
    name = _norm(row.name)
    company_class = _norm(row.company_class)
    state = _norm(row.state)
    warning = _norm(row.order_warning)

    blocked_class_tokens = ("ETF", "ETN", "REIT", "리츠", "SPAC", "스팩", "우선")
    if any(token in company_class for token in blocked_class_tokens):
        reasons.append("NON_COMMON_COMPANY_CLASS")

    if any(token in name for token in ("ETF", "ETN", "REIT", "리츠", "SPAC", "스팩")):
        reasons.append("NON_COMMON_NAME_TYPE")
    # Korean preferred-share display names commonly end in 우 / 우B / 우C / n우B.
    if name.endswith("우") or name.endswith("우B") or name.endswith("우C"):
        reasons.append("PREFERRED_SHARE_NAME")

    if any(token in state for token in ("관리", "거래정지", "정지", "상장폐지", "정리매매", "투자위험")):
        reasons.append("RESTRICTED_LISTING_STATE")
    if warning in {"1", "Y", "YES", "TRUE", "T"} or any(token in warning for token in ("경고", "위험", "주의")):
        reasons.append("ORDER_WARNING_ACTIVE")
    return list(dict.fromkeys(reasons))


class UniverseService:
    """PULSE-owned current domestic-stock universe.

    It is rebuilt from Kiwoom ka10099 and is never restored from a prior PULSE
    selection table. KOSPI and KOSDAQ are requested separately. ETF/ETN/REIT
    market types are not requested by this service.
    """

    API_ID = "ka10099"
    PATH = "/api/dostk/stkinfo"

    def __init__(self, rest: RestLike, benchmark_mapper: BenchmarkMapper, max_pages: int = 30) -> None:
        self.rest = rest
        self.benchmark_mapper = benchmark_mapper
        self.max_pages = max(1, int(max_pages))
        self.stocks: dict[str, UniverseStock] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        self.page_count = 0

    async def refresh(self) -> list[UniverseStock]:
        output: dict[str, UniverseStock] = {}
        try:
            for market_code, market in (("0", MarketClass.KOSPI), ("10", MarketClass.KOSDAQ)):
                rows = await self._load_market(market_code, market)
                for row in rows:
                    output[row.symbol] = row
                    self.benchmark_mapper.register(row.symbol, row.market)
            self.stocks = output
            self.last_refresh_at = datetime.now(timezone.utc)
            self.last_error = None
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            raise
        return list(self.stocks.values())

    async def _load_market(self, market_code: str, market: MarketClass) -> list[UniverseStock]:
        cont_yn: str | None = None
        next_key: str | None = None
        out: list[UniverseStock] = []
        for _ in range(self.max_pages):
            page = await self.rest.post(self.API_ID, self.PATH, {"mrkt_tp": market_code}, cont_yn, next_key)
            self.page_count += 1
            rows = page.body.get("list", []) or []
            if isinstance(rows, list):
                for raw in rows:
                    if not isinstance(raw, dict):
                        continue
                    symbol = _symbol(raw.get("code"))
                    if not symbol:
                        continue
                    out.append(
                        UniverseStock(
                            symbol=symbol,
                            name=str(raw.get("name")) if raw.get("name") is not None else None,
                            market=market,
                            listed_shares=_num(raw.get("listCount")),
                            state=str(raw.get("state")) if raw.get("state") is not None else None,
                            sector_name=str(raw.get("upName")) if raw.get("upName") is not None else None,
                            size_name=str(raw.get("upSizeName")) if raw.get("upSizeName") is not None else None,
                            order_warning=str(raw.get("orderWarning")) if raw.get("orderWarning") is not None else None,
                            company_class=str(raw.get("companyClassName")) if raw.get("companyClassName") is not None else None,
                            nxt_enabled=_truthy(raw.get("nxtEnable")),
                        )
                    )
            cont_yn = page.cont_yn
            next_key = page.next_key
            if cont_yn != "Y" or not next_key:
                break
        return out

    def eligibility(self, symbol: str, venue: Venue | None = None) -> UniverseEligibility:
        row = self.stocks.get(symbol)
        if row is None:
            return UniverseEligibility(symbol=symbol, eligible=False, reasons=("NOT_IN_CURRENT_UNIVERSE",))
        reasons = _explicit_non_common_stock(row)
        if venue == Venue.NXT and not row.nxt_enabled:
            reasons.append("NXT_NOT_ENABLED")
        return UniverseEligibility(
            symbol=symbol,
            eligible=not reasons,
            reasons=tuple(dict.fromkeys(reasons)),
        )

    def eligible(self, *, nxt_only: bool = False) -> list[UniverseStock]:
        venue = Venue.NXT if nxt_only else Venue.KRX
        rows = [
            row for row in self.stocks.values()
            if self.eligibility(row.symbol, venue).eligible
        ]
        rows.sort(key=lambda x: (x.market.value, x.symbol))
        return rows
