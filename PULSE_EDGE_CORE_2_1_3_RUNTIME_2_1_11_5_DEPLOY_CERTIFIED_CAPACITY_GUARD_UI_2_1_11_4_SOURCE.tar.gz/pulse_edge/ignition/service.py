from __future__ import annotations

from datetime import datetime, timezone

from pulse_edge.core.models import Venue
from pulse_edge.ignition.engine import IgnitionEngine
from pulse_edge.ignition.models import IgnitionFrame, IgnitionStage
from pulse_edge.smart_money.service import SmartMoneyService


class IgnitionService:
    """Process-memory Phase-3C shadow layer derived only from fresh 3B frames."""

    def __init__(self, smart_money: SmartMoneyService, engine: IgnitionEngine, max_rows: int = 100) -> None:
        self.smart_money = smart_money
        self.engine = engine
        self.max_rows = max(10, int(max_rows))
        self.frames: dict[tuple[Venue, str], IgnitionFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[IgnitionFrame]:
        now = asof or datetime.now(timezone.utc)
        source = self.smart_money.top(max(20, min(int(limit), 200)), now)
        rows: list[IgnitionFrame] = []
        keep: set[tuple[Venue, str]] = set()
        for src in source:
            frame = self.engine.evaluate(src, now)
            key = (frame.venue, frame.symbol)
            if frame.stage == IgnitionStage.DATA_WAIT:
                self.frames.pop(key, None)
                continue
            self.frames[key] = frame
            keep.add(key)
            rows.append(frame)

        # No incumbent reservation: anything no longer present in fresh 3B input
        # disappears from the current ignition set.
        for key in list(self.frames):
            if key not in keep:
                self.frames.pop(key, None)

        ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
        self.frames = {(row.venue, row.symbol): row for row in ranked}
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def top(self, limit: int = 10) -> list[IgnitionFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]

    @staticmethod
    def _sorted(rows: list[IgnitionFrame]) -> list[IgnitionFrame]:
        rows.sort(
            key=lambda x: (
                0 if x.veto else 1,
                x.ignition_score_100,
                -x.false_breakout_risk,
                -x.sell_the_news_risk,
            ),
            reverse=True,
        )
        return rows
