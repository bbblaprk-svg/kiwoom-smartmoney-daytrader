from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class IgnitionStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    IGNITION_WATCH = "IGNITION_WATCH"
    FLOW_IGNITION_SHADOW = "FLOW_IGNITION_SHADOW"
    VERIFIED_CATALYST_IGNITION_SHADOW = "VERIFIED_CATALYST_IGNITION_SHADOW"
    FALSE_BREAKOUT_VETO = "FALSE_BREAKOUT_VETO"
    SELL_THE_NEWS_RISK_SHADOW = "SELL_THE_NEWS_RISK_SHADOW"


class IgnitionFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    price: float | None = None
    change_rate: float | None = None
    stage: IgnitionStage

    ignition_score_100: float = 0.0
    momentum_score_25: float = 0.0
    flow_score_25: float = 0.0
    rs_score_15: float = 0.0
    sector_score_10: float = 0.0
    freshness_score_10: float = 0.0
    price_quality_score_15: float = 0.0

    smart_money_score_100: float = 0.0
    smart_money_coverage_pct: float = 0.0
    freshness_age_sec: float | None = None
    business_context_score: float = 0.0
    business_evidence_count: int = 0

    false_breakout_risk: float = 0.0
    sell_the_news_risk: float = 0.0
    veto: bool = False
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
