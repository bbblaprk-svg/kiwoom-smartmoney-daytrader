from __future__ import annotations

from datetime import datetime, timezone
from math import isfinite

from pulse_edge.ignition.models import IgnitionFrame, IgnitionStage
from pulse_edge.smart_money.models import SmartMoneyFrame


def _clip(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, value))


def _finite(value: float | None) -> bool:
    return value is not None and isfinite(value)


class IgnitionEngine:
    """Phase 3C shadow-only ignition evaluator.

    This layer consumes Phase-3B SmartMoneyFrame objects. It never changes the
    Phase-3B score, upstream row supply, broker subscription set, or official action
    state. The purpose is to separate healthy early ignition from false-breakout
    and catalyst-exhaustion risk before PREBUY/ENTRY is ever enabled.
    """

    def evaluate(self, row: SmartMoneyFrame, asof: datetime | None = None) -> IgnitionFrame:
        now = asof or datetime.now(timezone.utc)
        flags: list[str] = []

        momentum = self._momentum(row, flags)
        flow = self._flow(row, flags)
        rs = self._rs(row, flags)
        sector = self._sector(row, flags)
        freshness = self._freshness(row, flags)
        price_quality = self._price_quality(row, flags)
        score = _clip(momentum + flow + rs + sector + freshness + price_quality)

        false_breakout = self._false_breakout_risk(row)
        sell_news = self._sell_news_risk(row, flags)
        business_verified = row.business_evidence_count > 0 and row.business_context_score > 0

        data_wait = (
            row.price is None
            or row.change_rate is None
            or row.evidence_age_sec is None
            or row.evidence_age_sec > 1200
        )

        veto = False
        if data_wait:
            stage = IgnitionStage.DATA_WAIT
        elif false_breakout >= 70:
            stage = IgnitionStage.FALSE_BREAKOUT_VETO
            veto = True
        elif sell_news >= 75:
            # Without timestamped verified catalyst ingestion this remains a
            # shadow risk state, not a hard official action veto.
            stage = IgnitionStage.SELL_THE_NEWS_RISK_SHADOW
        elif score >= 74 and row.change_rate >= 2.0:
            if business_verified:
                stage = IgnitionStage.VERIFIED_CATALYST_IGNITION_SHADOW
            else:
                stage = IgnitionStage.FLOW_IGNITION_SHADOW
                flags.append("VERIFIED_CATALYST_CONTEXT_MISSING")
        else:
            stage = IgnitionStage.IGNITION_WATCH

        if row.change_rate is not None and row.change_rate > 12:
            flags.append("PRICE_EXTENSION_HIGH")
        if row.vwap_distance_pct is not None and row.vwap_distance_pct > 3.5:
            flags.append("VWAP_EXTENSION_HIGH")
        if row.money_acceleration is not None and row.money_acceleration <= 0:
            flags.append("MONEY_ACCELERATION_NONPOSITIVE")
        if row.rs_acceleration is not None and row.rs_acceleration <= 0:
            flags.append("RS_ACCELERATION_NONPOSITIVE")
        if row.program_net_buy_amount_delta is not None and row.program_net_buy_amount_delta < 0:
            flags.append("PROGRAM_FLOW_NEGATIVE")

        return IgnitionFrame(
            venue=row.venue,
            symbol=row.symbol,
            asof=now,
            price=row.price,
            change_rate=row.change_rate,
            stage=stage,
            ignition_score_100=round(score, 4),
            momentum_score_25=round(momentum, 4),
            flow_score_25=round(flow, 4),
            rs_score_15=round(rs, 4),
            sector_score_10=round(sector, 4),
            freshness_score_10=round(freshness, 4),
            price_quality_score_15=round(price_quality, 4),
            smart_money_score_100=row.raw_score_100,
            smart_money_coverage_pct=row.coverage_pct,
            freshness_age_sec=row.evidence_age_sec,
            business_context_score=row.business_context_score,
            business_evidence_count=row.business_evidence_count,
            false_breakout_risk=round(false_breakout, 4),
            sell_the_news_risk=round(sell_news, 4),
            veto=veto,
            official_signal_enabled=False,
            flags=list(dict.fromkeys(flags)),
        )

    @staticmethod
    def _momentum(row: SmartMoneyFrame, flags: list[str]) -> float:
        score = 0.0
        rate = row.change_rate
        if rate is None:
            flags.append("CHANGE_RATE_MISSING")
        elif 2.0 <= rate <= 8.0:
            score += 6.0
        elif 0.5 <= rate < 2.0 or 8.0 < rate <= 10.0:
            score += 3.0
        elif rate > 10.0:
            score += 1.0

        if row.money_acceleration is not None:
            if row.money_acceleration > 0:
                score += 8.0
        else:
            flags.append("MONEY_ACCELERATION_MISSING")

        if row.money_second_derivative is not None:
            if row.money_second_derivative > 0:
                score += 4.0
        else:
            flags.append("MONEY_SECOND_DERIVATIVE_MISSING")

        if row.rvol_same_time is not None:
            if row.rvol_same_time >= 2.0:
                score += 4.0
            elif row.rvol_same_time >= 1.5:
                score += 3.0
            elif row.rvol_same_time >= 1.1:
                score += 1.5
        else:
            flags.append("RVOL_SAME_TIME_MISSING")

        if row.vwap_distance_pct is not None and -0.5 <= row.vwap_distance_pct <= 2.0:
            score += 3.0
        return min(score, 25.0)

    @staticmethod
    def _flow(row: SmartMoneyFrame, flags: list[str]) -> float:
        score = 0.0
        if row.foreign_flow_acceleration is not None:
            if row.foreign_flow_acceleration > 0:
                score += 8.0
        else:
            flags.append("FOREIGN_FLOW_ACCELERATION_MISSING")
        if row.foreign_flow_velocity is not None and row.foreign_flow_velocity > 0:
            score += 4.0
        if row.foreign_flow_reversal:
            score += 4.0
        score += min(5.0, max(0.0, row.flow_price_divergence_score))
        if row.program_net_buy_amount_delta is not None:
            if row.program_net_buy_amount_delta > 0:
                score += 4.0
        elif row.intraday_foreign_net is not None and row.intraday_foreign_net > 0:
            score += 2.0
        return min(score, 25.0)

    @staticmethod
    def _rs(row: SmartMoneyFrame, flags: list[str]) -> float:
        score = 0.0
        if row.rs_acceleration is None:
            flags.append("RS_ACCELERATION_MISSING")
        elif row.rs_acceleration > 0:
            score += 7.0
        if row.rs_velocity is not None and row.rs_velocity > 0:
            score += 5.0
        if row.rs_zero_cross:
            score += 3.0
        return min(score, 15.0)

    @staticmethod
    def _sector(row: SmartMoneyFrame, flags: list[str]) -> float:
        if row.sector_score <= 0:
            flags.append("SECTOR_CONFIRMATION_MISSING_OR_ZERO")
            return 0.0
        return min(10.0, row.sector_score / 15.0 * 10.0)

    @staticmethod
    def _freshness(row: SmartMoneyFrame, flags: list[str]) -> float:
        if row.evidence_age_sec is None:
            flags.append("EVIDENCE_AGE_MISSING")
            return 0.0
        if row.evidence_age_sec > 1200:
            flags.append("EVIDENCE_EXPIRED")
            return 0.0
        return min(10.0, max(0.0, row.freshness_score / 10.0))

    @staticmethod
    def _price_quality(row: SmartMoneyFrame, flags: list[str]) -> float:
        score = 0.0
        rate = row.change_rate
        gap = row.vwap_distance_pct
        if rate is not None:
            if 2.0 <= rate <= 6.0:
                score += 7.0
            elif 0.5 <= rate < 2.0 or 6.0 < rate <= 9.0:
                score += 4.0
            elif 9.0 < rate <= 12.0:
                score += 1.5
        if gap is not None:
            if -0.5 <= gap <= 1.5:
                score += 8.0
            elif 1.5 < gap <= 3.0:
                score += 4.0
            elif -1.5 <= gap < -0.5:
                score += 2.0
        else:
            flags.append("VWAP_DISTANCE_MISSING")
        return min(score, 15.0)

    @staticmethod
    def _false_breakout_risk(row: SmartMoneyFrame) -> float:
        risk = 0.0
        if row.money_acceleration is not None and row.money_acceleration <= 0:
            risk += 25.0
        if row.money_second_derivative is not None and row.money_second_derivative <= 0:
            risk += 15.0
        if row.rs_acceleration is not None and row.rs_acceleration <= 0:
            risk += 20.0
        if row.program_net_buy_amount_delta is not None and row.program_net_buy_amount_delta < 0:
            risk += 15.0
        if row.vwap_distance_pct is not None:
            if row.vwap_distance_pct < -0.5:
                risk += 20.0
            elif row.vwap_distance_pct > 3.5:
                risk += 12.0
        if row.sector_score < 4.0:
            risk += 10.0
        return _clip(risk)

    @staticmethod
    def _sell_news_risk(row: SmartMoneyFrame, flags: list[str]) -> float:
        if row.business_evidence_count <= 0 or row.business_context_score <= 0:
            flags.append("SELL_NEWS_EVENT_NOT_VERIFIED")
            return 0.0
        risk = 0.0
        if row.change_rate is not None:
            if row.change_rate >= 15.0:
                risk += 35.0
            elif row.change_rate >= 10.0:
                risk += 25.0
            elif row.change_rate >= 7.0:
                risk += 10.0
        if row.vwap_distance_pct is not None and row.vwap_distance_pct > 3.0:
            risk += 20.0
        if row.money_acceleration is not None and row.money_acceleration <= 0:
            risk += 20.0
        if row.rs_acceleration is not None and row.rs_acceleration <= 0:
            risk += 15.0
        if row.program_net_buy_amount_delta is not None and row.program_net_buy_amount_delta < 0:
            risk += 10.0
        # Current business context does not expose the exact publication-time
        # event needed to call this a confirmed sell-the-news event.
        flags.append("SELL_NEWS_EVENT_TIME_NOT_CONNECTED")
        return _clip(risk)
