from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from math import isfinite
from typing import Any, Protocol

from pulse_edge.feed.rest import RestPage


class RestLike(Protocol):
    async def post(
        self,
        api_id: str,
        path: str,
        body: dict,
        cont_yn: str | None = None,
        next_key: str | None = None,
    ) -> RestPage: ...


def _num(value: Any, *, absolute: bool = False) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").strip()
    if not text:
        return None
    try:
        result = float(text)
    except ValueError:
        return None
    if not isfinite(result):
        return None
    return abs(result) if absolute else result


def _mean(values: list[float]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


@dataclass(frozen=True)
class DailyBar:
    trading_date: date
    close: float
    open: float
    high: float
    low: float
    volume: float
    traded_value_raw: float | None

    @property
    def range_pct(self) -> float:
        if self.close <= 0:
            return 0.0
        return (self.high - self.low) / self.close * 100.0


@dataclass(frozen=True)
class DailyContextFrame:
    symbol: str
    asof: datetime
    bars: tuple[DailyBar, ...]
    return_5d_pct: float | None
    atr_recent3_pct: float | None
    atr_reference5_pct: float | None
    atr_compression_ratio: float | None
    range_recent3_pct: float | None
    range_reference5_pct: float | None
    range_compression_ratio: float | None
    volume_recent3: float | None
    volume_reference5: float | None
    volume_ratio: float | None
    rising_lows: bool | None
    traded_value_5d_raw: float | None
    flags: tuple[str, ...]


def _true_range_pct(rows: list[DailyBar]) -> list[float]:
    values: list[float] = []
    previous_close: float | None = None
    for row in rows:
        if row.close <= 0:
            previous_close = row.close
            continue
        parts = [row.high - row.low]
        if previous_close is not None and previous_close > 0:
            parts.append(abs(row.high - previous_close))
            parts.append(abs(row.low - previous_close))
        values.append(max(parts) / row.close * 100.0)
        previous_close = row.close
    return values


def build_daily_context(symbol: str, bars: list[DailyBar], asof: datetime | None = None) -> DailyContextFrame:
    now = asof or datetime.now(timezone.utc)
    rows = sorted(bars, key=lambda x: x.trading_date)
    flags: list[str] = []
    if len(rows) < 6:
        flags.append("DAILY_LT_6_BARS")

    return5 = None
    if len(rows) >= 6 and rows[-6].close > 0:
        return5 = (rows[-1].close / rows[-6].close - 1.0) * 100.0

    recent3 = rows[-3:] if len(rows) >= 3 else rows[:]
    reference5 = rows[-8:-3] if len(rows) >= 8 else rows[:-3]
    if len(reference5) < 3:
        flags.append("DAILY_REFERENCE_WINDOW_SHORT")

    tr_recent = _true_range_pct(recent3)
    tr_ref = _true_range_pct(reference5)
    atr3 = _mean(tr_recent)
    atr5 = _mean(tr_ref)
    atr_ratio = None if atr3 is None or atr5 is None or atr5 <= 0 else atr3 / atr5

    ranges3 = [x.range_pct for x in recent3]
    ranges5 = [x.range_pct for x in reference5]
    range3 = _mean(ranges3)
    range5 = _mean(ranges5)
    range_ratio = None if range3 is None or range5 is None or range5 <= 0 else range3 / range5

    vol3 = _mean([x.volume for x in recent3])
    vol5 = _mean([x.volume for x in reference5])
    volume_ratio = None if vol3 is None or vol5 is None or vol5 <= 0 else vol3 / vol5

    rising_lows = None
    if len(recent3) == 3:
        rising_lows = recent3[0].low <= recent3[1].low <= recent3[2].low

    traded = [x.traded_value_raw for x in rows[-5:] if x.traded_value_raw is not None]
    traded5 = sum(traded) if len(traded) == min(5, len(rows)) and traded else None
    if traded5 is None:
        flags.append("DAILY_TRADED_VALUE_INCOMPLETE")

    return DailyContextFrame(
        symbol=symbol,
        asof=now,
        bars=tuple(rows),
        return_5d_pct=return5,
        atr_recent3_pct=atr3,
        atr_reference5_pct=atr5,
        atr_compression_ratio=atr_ratio,
        range_recent3_pct=range3,
        range_reference5_pct=range5,
        range_compression_ratio=range_ratio,
        volume_recent3=vol3,
        volume_reference5=vol5,
        volume_ratio=volume_ratio,
        rising_lows=rising_lows,
        traded_value_5d_raw=traded5,
        flags=tuple(flags),
    )


class DailyContextService:
    """PULSE-owned in-memory daily context built from Kiwoom ka10081.

    The service does not persist names or selection state. It exists only to provide
    compression and recent-price facts to the SMART-MONEY evaluator.
    """

    def __init__(self, rest: RestLike, ttl_sec: float = 1800.0) -> None:
        self.rest = rest
        self.ttl_sec = max(60.0, float(ttl_sec))
        self.frames: dict[str, DailyContextFrame] = {}
        self.last_error: str | None = None
        self.api_call_count = 0

    async def ensure(self, symbol: str, base_dt: date | None = None) -> DailyContextFrame | None:
        symbol = str(symbol)[:6]
        now = datetime.now(timezone.utc)
        current = self.frames.get(symbol)
        if current is not None and (now - current.asof).total_seconds() <= self.ttl_sec:
            return current
        try:
            frame = await self.load(symbol, base_dt)
            self.last_error = None
            return frame
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            return None

    async def load(self, symbol: str, base_dt: date | None = None) -> DailyContextFrame:
        symbol = str(symbol)[:6]
        day = base_dt or datetime.now(timezone(timedelta(hours=9))).date()
        page = await self.rest.post(
            "ka10081",
            "/api/dostk/chart",
            {"stk_cd": symbol, "base_dt": day.strftime("%Y%m%d"), "upd_stkpc_tp": "1"},
        )
        self.api_call_count += 1
        rows: list[DailyBar] = []
        for raw in page.body.get("stk_dt_pole_chart_qry", []) or []:
            if not isinstance(raw, dict):
                continue
            text_date = str(raw.get("dt") or "").strip()
            try:
                trading_date = datetime.strptime(text_date, "%Y%m%d").date()
            except ValueError:
                continue
            close = _num(raw.get("cur_prc"), absolute=True)
            open_ = _num(raw.get("open_pric"), absolute=True)
            high = _num(raw.get("high_pric"), absolute=True)
            low = _num(raw.get("low_pric"), absolute=True)
            volume = _num(raw.get("trde_qty"), absolute=True)
            if None in {close, open_, high, low, volume}:
                continue
            if close <= 0 or high <= 0 or low <= 0:
                continue
            rows.append(
                DailyBar(
                    trading_date=trading_date,
                    close=close,
                    open=open_,
                    high=max(high, low),
                    low=min(high, low),
                    volume=volume,
                    traded_value_raw=_num(raw.get("trde_prica"), absolute=True),
                )
            )
        frame = build_daily_context(symbol, rows[-20:], datetime.now(timezone.utc))
        self.frames[symbol] = frame
        return frame
