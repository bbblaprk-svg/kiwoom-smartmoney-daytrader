from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import StrEnum


class BusinessEvidenceType(StrEnum):
    EARNINGS = "EARNINGS"
    ORDER = "ORDER"
    CAPEX = "CAPEX"
    SUPPLY_CONTRACT = "SUPPLY_CONTRACT"
    CUSTOMER_CAPEX = "CUSTOMER_CAPEX"
    PRODUCTION_EXPANSION = "PRODUCTION_EXPANSION"
    POLICY_DIRECT = "POLICY_DIRECT"


@dataclass(frozen=True)
class BusinessEvidence:
    symbol: str
    evidence_type: BusinessEvidenceType
    observed_at: datetime
    verified: bool
    direct_revenue_link: bool
    reliability: float
    impact: float
    source_ref: str | None = None


@dataclass(frozen=True)
class BusinessContextFrame:
    symbol: str
    asof: datetime
    score_10: float
    evidence_count: int
    direct_count: int
    verified_count: int


class BusinessContextService:
    """Verified fact scorer; it does not scrape or invent business facts.

    Automatic DART/news ingestion is intentionally outside this class. Only facts
    explicitly supplied by a verified connector may receive points.
    """

    def __init__(self, ttl_days: int = 45) -> None:
        self.ttl = timedelta(days=max(1, int(ttl_days)))
        self._facts: dict[str, list[BusinessEvidence]] = {}

    def upsert(self, evidence: BusinessEvidence) -> None:
        symbol = evidence.symbol[:6]
        rows = self._facts.setdefault(symbol, [])
        key = (evidence.evidence_type, evidence.observed_at, evidence.source_ref)
        rows[:] = [x for x in rows if (x.evidence_type, x.observed_at, x.source_ref) != key]
        rows.append(evidence)

    def frame(self, symbol: str, asof: datetime | None = None) -> BusinessContextFrame | None:
        now = asof or datetime.now(timezone.utc)
        rows = [x for x in self._facts.get(symbol[:6], []) if now - x.observed_at <= self.ttl]
        verified = [x for x in rows if x.verified]
        if not verified:
            return None
        direct = [x for x in verified if x.direct_revenue_link]
        best = 0.0
        for row in verified:
            base = 6.0 if row.direct_revenue_link else 2.0
            age_days = max(0.0, (now - row.observed_at).total_seconds() / 86400.0)
            freshness = 1.0 if age_days <= 7 else 0.75 if age_days <= 21 else 0.5
            value = base * max(0.0, min(1.0, row.reliability)) * max(0.0, min(1.0, row.impact)) * freshness
            best = max(best, value)
        # Multiple independent direct facts can add up, but total weight is capped at 10.
        score = min(10.0, best + max(0, len(direct) - 1) * 1.5)
        return BusinessContextFrame(
            symbol=symbol[:6],
            asof=now,
            score_10=round(score, 4),
            evidence_count=len(rows),
            direct_count=len(direct),
            verified_count=len(verified),
        )
