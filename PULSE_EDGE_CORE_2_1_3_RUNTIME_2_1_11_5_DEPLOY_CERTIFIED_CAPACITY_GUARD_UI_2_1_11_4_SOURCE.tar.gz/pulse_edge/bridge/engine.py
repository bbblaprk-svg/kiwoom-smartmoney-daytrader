from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

from pulse_edge.bridge.models import BridgeFrame, BridgeStage, SameDayKrxCloseFrame
from pulse_edge.features.models import FeatureFrame
from pulse_edge.session.router import SessionPhase


KST = ZoneInfo('Asia/Seoul')


class KrxNxtBridgeEngine:
    def evaluate(self, close_frame: SameDayKrxCloseFrame | None, nxt: FeatureFrame | None, *, phase: SessionPhase,
                 persistence_count: int, asof: datetime) -> BridgeFrame:
        day = asof.astimezone(KST).date().isoformat()
        if close_frame is None:
            return BridgeFrame(symbol=nxt.symbol if nxt else '', asof=asof, trading_day=day, stage=BridgeStage.DATA_WAIT)
        day = close_frame.trading_day
        if nxt is None or nxt.price is None:
            return BridgeFrame(symbol=close_frame.symbol, asof=asof, trading_day=day, stage=BridgeStage.KRX_CLOSE_FRAME_READY,
                               krx_close_price=close_frame.price)
        premium = (nxt.price / close_frame.price - 1.0) * 100.0 if close_frame.price > 0 else 0.0
        late_session = phase == SessionPhase.NXT_LATE_SESSION
        krx_above_vwap = close_frame.session_vwap is not None and close_frame.price >= close_frame.session_vwap
        krx_evidence = close_frame.confluence_evidence_count >= 3 or (close_frame.smart_money_score_100 or 0) >= 74
        krx_not_overheated = close_frame.change_rate is None or close_frame.change_rate <= 10.0
        krx_quality = (15.0 if krx_above_vwap else 0.0) + (15.0 if krx_evidence else 0.0) + (10.0 if krx_not_overheated else 0.0)
        spread_ok = nxt.spread_pct is not None and 0 <= nxt.spread_pct <= 0.8
        flow_ok = nxt.money_acceleration is not None and nxt.money_acceleration > 0
        short_strength = nxt.return_1m_pct is not None and nxt.return_1m_pct >= 0
        nxt_vwap_ok = nxt.session_vwap is None or nxt.price >= nxt.session_vwap * 0.995
        nxt_score = (15.0 if spread_ok else 0.0) + (15.0 if flow_ok else 0.0) + (5.0 if short_strength else 0.0) + (5.0 if nxt_vwap_ok else 0.0)
        premium_ok = -0.5 <= premium <= 2.0
        premium_score = 20.0 if premium_ok else (10.0 if -1.0 <= premium <= 2.5 else 0.0)
        total = krx_quality + nxt_score + premium_score
        premium_risk = premium > 2.5 or premium < -1.5
        low_liq = nxt.spread_pct is None or nxt.spread_pct > 0.8 or nxt.money_5m is None or nxt.money_5m <= 0
        structural = krx_quality >= 30 and spread_ok and flow_ok and short_strength and nxt_vwap_ok and premium_ok
        if premium_risk:
            stage = BridgeStage.PREMIUM_RISK_SHADOW
        elif low_liq:
            stage = BridgeStage.LOW_LIQUIDITY_SHADOW
        elif structural:
            stage = BridgeStage.NXT_CONFIRM_SHADOW if persistence_count >= 2 else BridgeStage.NXT_BRIDGE_WATCH
        else:
            stage = BridgeStage.NO_BRIDGE
        return BridgeFrame(
            symbol=close_frame.symbol, asof=asof, trading_day=day, stage=stage, krx_close_price=close_frame.price,
            nxt_price=nxt.price, nxt_premium_pct=round(premium,4), nxt_spread_pct=nxt.spread_pct,
            krx_quality_score_40=krx_quality, nxt_flow_liquidity_score_40=nxt_score,
            price_premium_score_20=premium_score, bridge_score_100=total, persistence_count=persistence_count,
            late_session_window=late_session, official_signal_enabled=False,
        )
