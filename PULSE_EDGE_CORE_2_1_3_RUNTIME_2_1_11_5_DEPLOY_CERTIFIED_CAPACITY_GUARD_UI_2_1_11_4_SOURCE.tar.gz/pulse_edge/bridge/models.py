from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field


class BridgeStage(StrEnum):
    DATA_WAIT='DATA_WAIT'
    KRX_CLOSE_FRAME_READY='KRX_CLOSE_FRAME_READY'
    NXT_BRIDGE_WATCH='NXT_BRIDGE_WATCH'
    NXT_CONFIRM_SHADOW='NXT_CONFIRM_SHADOW'
    PREMIUM_RISK_SHADOW='PREMIUM_RISK_SHADOW'
    LOW_LIQUIDITY_SHADOW='LOW_LIQUIDITY_SHADOW'
    NO_BRIDGE='NO_BRIDGE'


class SameDayKrxCloseFrame(BaseModel):
    trading_day: str
    symbol: str
    captured_at: datetime
    price: float
    change_rate: float | None = None
    session_vwap: float | None = None
    smart_money_score_100: float | None = None
    confluence_evidence_count: int = 0
    confluence_stage: str | None = None
    sector_score_15: float | None = None
    money_acceleration: float | None = None
    rs_acceleration: float | None = None


class BridgeFrame(BaseModel):
    symbol: str
    asof: datetime
    trading_day: str
    stage: BridgeStage
    krx_close_price: float | None = None
    nxt_price: float | None = None
    nxt_premium_pct: float | None = None
    nxt_spread_pct: float | None = None
    krx_quality_score_40: float = 0.0
    nxt_flow_liquidity_score_40: float = 0.0
    price_premium_score_20: float = 0.0
    bridge_score_100: float = 0.0
    persistence_count: int = 0
    late_session_window: bool = False
    official_signal_enabled: bool = False
    flags: list[str] = Field(default_factory=list)
