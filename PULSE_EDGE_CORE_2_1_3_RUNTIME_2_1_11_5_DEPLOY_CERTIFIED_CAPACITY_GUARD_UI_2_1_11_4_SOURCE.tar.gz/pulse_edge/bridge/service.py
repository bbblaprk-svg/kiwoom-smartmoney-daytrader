from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from pulse_edge.bridge.engine import KrxNxtBridgeEngine
from pulse_edge.bridge.models import BridgeFrame, BridgeStage, SameDayKrxCloseFrame
from pulse_edge.confluence.service import ConfluenceService
from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.session.router import SessionPhase, SessionRouter
from pulse_edge.smart_money.service import SmartMoneyService
from pulse_edge.sector.service import SectorBreadthService

KST = ZoneInfo('Asia/Seoul')


class KrxNxtBridgeService:
    def __init__(self, features: FeatureEngine, session_router: SessionRouter, smart_money: SmartMoneyService,
                 confluence: ConfluenceService, sectors: SectorBreadthService, engine: KrxNxtBridgeEngine, max_rows:int=100) -> None:
        self.features=features; self.session_router=session_router; self.smart_money=smart_money; self.confluence=confluence; self.sectors=sectors; self.engine=engine
        self.max_rows=max(10,int(max_rows)); self.close_frames:dict[str,SameDayKrxCloseFrame]={}; self.frames:dict[str,BridgeFrame]={}; self._persist:dict[str,int]={}
        self._day:str|None=None; self.last_refresh_at:datetime|None=None; self.last_error:str|None=None

    def refresh(self, limit:int=80, asof:datetime|None=None)->list[BridgeFrame]:
        now=asof or datetime.now(timezone.utc); local=now.astimezone(KST); day=local.date().isoformat()
        if self._day != day:
            self._day=day; self.close_frames.clear(); self.frames.clear(); self._persist.clear()
        self._capture_krx(day, now)
        phase=self.session_router.phase_at(now)
        if phase not in {SessionPhase.NXT_AFTER,SessionPhase.NXT_LATE_SESSION}:
            self.frames.clear(); self._persist.clear(); self.last_refresh_at=now; return []
        rows=[]; keep=set()
        for symbol,close_frame in list(self.close_frames.items())[:max(20,min(int(limit),200))]:
            nxt=self.features.frames.get((Venue.NXT,symbol))
            nxt_trades=self.features.trades.get((Venue.NXT,symbol),[])
            if not nxt_trades or (now-nxt_trades[-1].ts).total_seconds() > 7.0:
                nxt=None
            provisional=self.engine.evaluate(close_frame,nxt,phase=phase,persistence_count=self._persist.get(symbol,0),asof=now)
            qualifies=provisional.stage in {BridgeStage.NXT_BRIDGE_WATCH, BridgeStage.NXT_CONFIRM_SHADOW}
            self._persist[symbol]=self._persist.get(symbol,0)+1 if qualifies else 0
            row=self.engine.evaluate(close_frame,nxt,phase=phase,persistence_count=self._persist[symbol],asof=now)
            if row.stage != BridgeStage.DATA_WAIT:
                self.frames[symbol]=row; rows.append(row); keep.add(symbol)
        for symbol in list(self.frames):
            if symbol not in keep: self.frames.pop(symbol,None); self._persist.pop(symbol,None)
        self.last_refresh_at=now; self.last_error=None
        return self._sorted(rows)

    def _capture_krx(self, day:str, now:datetime)->None:
        local=now.astimezone(KST); minute=local.hour*60+local.minute
        if not (15*60 <= minute < 15*60+20):
            return
        for (venue,symbol),feature in self.features.frames.items():
            if venue != Venue.KRX or feature.price is None: continue
            trades=self.features.trades.get((venue,symbol),[])
            if not trades or (now-trades[-1].ts).total_seconds() > 7.0: continue
            smart=self.smart_money.frames.get((Venue.KRX,symbol))
            confl=self.confluence.frames.get((Venue.KRX,symbol))
            sector=self.sectors.frame_for(symbol,now)
            self.close_frames[symbol]=SameDayKrxCloseFrame(
                trading_day=day,symbol=symbol,captured_at=now,price=feature.price,change_rate=feature.change_rate,
                session_vwap=feature.session_vwap,smart_money_score_100=smart.raw_score_100 if smart else None,
                confluence_evidence_count=confl.evidence_count if confl else 0,
                confluence_stage=confl.decision_stage.value if confl else None,
                sector_score_15=sector.score_15 if sector else None,money_acceleration=feature.money_acceleration,
                rs_acceleration=feature.rs_acceleration,
            )

    def top(self,limit:int=10)->list[BridgeFrame]:
        return self._sorted(list(self.frames.values()))[:max(1,min(int(limit),100))]
    @staticmethod
    def _sorted(rows):
        order={BridgeStage.NXT_CONFIRM_SHADOW:6,BridgeStage.NXT_BRIDGE_WATCH:5,BridgeStage.KRX_CLOSE_FRAME_READY:4,BridgeStage.NO_BRIDGE:3,BridgeStage.LOW_LIQUIDITY_SHADOW:2,BridgeStage.PREMIUM_RISK_SHADOW:1,BridgeStage.DATA_WAIT:0}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.bridge_score_100),reverse=True)
