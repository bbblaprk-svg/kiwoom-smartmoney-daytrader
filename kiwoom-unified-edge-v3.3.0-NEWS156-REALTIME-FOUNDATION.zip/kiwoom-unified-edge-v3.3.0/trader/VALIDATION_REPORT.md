# Trader v3.3.0 REALTIME FOUNDATION validation

- `npm run check`: PASS
- `npm run check:load` (30 symbols / 12,000 events): errors 0, finalPending 0, finalActive 0, throughput ~80,537 events/sec, event-loop p95 22.12 ms
- smart-money-venue-check updated to the v3.3.0 official bare-code 0B + FID9081 truth policy: PASS
- realtime-foundation / realtime-truth / realtime-latency / pre-ignition: PASS
- all JavaScript syntax via `node --check`: PASS
- runtime Docker build additionally runs `npm install`, full check, 30,000-event load check and `next build` before image replacement.
