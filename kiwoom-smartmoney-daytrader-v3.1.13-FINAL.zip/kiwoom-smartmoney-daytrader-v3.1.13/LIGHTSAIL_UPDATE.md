# Lightsail v3.1.13 FINAL 업데이트

GitHub 저장소 최상위에 `Dockerfile`, `kiwoom-smartmoney-daytrader-v3.1.13-FINAL.zip`, `update-lightsail-v3.1.13-FINAL.sh`를 올린 뒤 업데이트 스크립트를 실행합니다. 기존 `.env`와 `kiwoom-data` 볼륨을 그대로 사용합니다.

업데이트는 감시 상한 `사용자 집중 8 + 사용자 경량 8`과 `DAILY_RECOMMENDATIONS_ENABLED=true`를 보장합니다. 기존 키움 키/시크릿, 접근보호 토큰, REST/WebSocket 설정은 보존합니다.

업데이트 스크립트는 소스 SHA256, 단위/통합/저장/수급/REST/자동추천 회귀검사, **20종목 혼합 부하검사**, Next build가 모두 성공해야 새 컨테이너로 교체합니다. 실패하면 기존 컨테이너를 유지/복구합니다.

배포 후 `/api/health`에서 `status=connected`를 확인합니다. `subscribed`는 20이라는 고정값이 아니라 **현재 실제 등록된 감시종목 수**입니다. 자동추천을 적용해 20개 슬롯을 모두 채운 뒤 최대 20으로 증가합니다.

자동추천은 평일 20:15 KST 이후 하루 한 번 리스트만 작성합니다. 자동 BUY가 아니며, 수동종목은 자동적용에서 보호됩니다.
