const { requireAuth } = require('../../lib/auth');
const {
  getCachedRecommendations, generateDailyRecommendations, applyRecommendations,
  getAutoApplyStatus, setAutoApplyEnabled,
} = require('../../lib/recommendationEngine');
const { mergeWatchlist, countUserTiers } = require('../../lib/stocks');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') {
      const [cached, autoApply] = await Promise.all([getCachedRecommendations(), getAutoApplyStatus()]);
      return res.status(200).json({ recommendations: cached, autoApply });
    }
    if (req.method === 'POST') {
      const action = String(req.body && req.body.action || 'generate').toLowerCase();
      if (action === 'generate') {
        const recommendations = await generateDailyRecommendations({ force: true });
        const autoApply = await getAutoApplyStatus();
        return res.status(200).json({ recommendations, autoApply });
      }
      if (action === 'apply') {
        const recommendations = await getCachedRecommendations();
        const applied = await applyRecommendations(recommendations);
        return res.status(200).json({
          applied,
          watchlist: mergeWatchlist(applied.user),
          counts: countUserTiers(applied.user),
          recommendations,
          autoApply: await getAutoApplyStatus(),
        });
      }
      if (action === 'set_auto_apply') {
        const enabled = req.body && req.body.enabled === true;
        const autoApply = await setAutoApplyEnabled(enabled);
        return res.status(200).json({ autoApply });
      }
      return res.status(400).json({ error: 'action은 generate, apply, set_auto_apply를 지원합니다.' });
    }
    res.setHeader('Allow', ['GET', 'POST']);
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
