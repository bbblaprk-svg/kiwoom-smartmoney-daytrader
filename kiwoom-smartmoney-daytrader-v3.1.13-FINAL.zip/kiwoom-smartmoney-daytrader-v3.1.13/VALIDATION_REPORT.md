# v3.1.13 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.13

## 목적

- 급등/급락이 가격에 완전히 반영되기 전에 EARLY/RISK를 포착하면서 확정 BUY/SELL의 기존 신뢰성 게이트를 유지합니다.
- 종합 발생기록부에서 **지금 대응해야 하는 신호를 먼저** 보여주고, 한 종목의 EARLY→BUY→RISK→EARLY_SELL→SELL 진행을 시간순으로 보존합니다.
- 매일 집중 8 + 경량 8 감시 후보를 자동추천하되, **수동입력과 자동추천을 겸용**하고 추천 자체를 BUY로 오인하지 않도록 분리합니다.

## v3.1.11 판정기준 보존

- 미정배열 고정 -10 폐지, 초기 회복/5일선 회복을 합리적으로 평가하는 종가배점 유지.
- 강한 고가잠김·품절형 강세에서 단순 20일 거래량 부족 -7을 면제하는 규칙 유지.
- +10% 초과 상승 자체의 자동 -4 폐지, 고가이탈/수급유지에 따른 추격위험 분리 유지.
- `preSurgeScore`로 확정 BUY 이전의 스마트머니 전환·공격매수 가속·프로그램/외국계 변화·호가흡수·RVOL/VWAP를 조합.
- **확정 BUY의 품질 85, 수익우선 78, 체결강도 118, 기대손익비 1.5R 등은 변경하지 않음.**

## 종합 발생기록부 개선

- 기본정렬: `중요도순`. 대응 우선순위는 확정 SELL → SELL/청산 → EARLY_SELL → RISK → 확정 BUY → 강한 PRE-SURGE EARLY → BUY 확인중 → 일반 EARLY → 종료기록.
- 버튼으로 `최신발생순` 전환 가능.
- SIGNAL row에 최대 20개의 타임라인 이벤트를 저장. 연속 동일단계는 중복 이벤트를 계속 만들지 않고 마지막 이벤트를 갱신.
- 실제 포지션 기록도 BUY/SELL 타임라인을 보존.
- `worker/kiwoomRealtime.js`의 변경은 이미 계산된 RISK/EARLY_SELL 단계가 바뀔 때 기록부에 저장하는 **판정 후 기록 훅**에 한정. WebSocket REG 구독 종류, TR/FID 해석, 실시간 수치 계산 로직은 변경하지 않음.

## 일일 집중8/경량8 자동추천 + 수동겸용

- 평일 **20:15 KST 이후 하루 한 번** NXT 종료 후 추천 리스트 생성. 장중 실시간 경로와 분리.
- 키움 순위 REST 사용:
  - `ka10032` 거래대금상위요청: KOSPI 1회 + KOSDAQ 1회, `mang_stk_incls=0`, `stex_tp=3`.
  - `ka90009` 외국인기관매매상위요청: 전체시장/금액/순매수/통합 1회.
- 총 3 REST 호출/일. Dashboard polling은 추천 REST를 호출하지 않고 캐시만 읽음.
- 거래대금 순위, 외국인·기관 순매수, 과열 전 모멘텀, 이미 저장된 종가판정(존재할 때만)을 합산해 focus 8/light 8 추천.
- 고정 4종목은 추천 후보에서 제외. ETF/ETN/SPAC/리츠 형태의 이름은 후보에서 제외.
- 추천은 `watchlist:daily-recommendations:v1`에 영속 저장.
- 수동종목은 `source=MANUAL`로 보호. 자동 전체적용은 수동종목을 삭제하지 않고 남는 focus/light 슬롯만 `source=AUTO`로 채움. 기존 과거 watchlist의 source가 없으면 MANUAL로 취급해 안전하게 보호.
- 추천 개별 종목을 수동등록하는 기능도 제공.
- 자동추천은 **감시 후보선정용이고 BUY 신호가 아님**.

## 데이터수집/실시간 경로 영향 범위

- v3.1.12에서 `lib/kiwoomClient.js`, `lib/flowCollector.js`, `lib/realtimeStore.js`는 v3.1.11에서 변경하지 않음.
- 기존 WebSocket worker의 watchlist 30초 polling/재구독 방식을 그대로 사용하므로 자동추천 적용 후 최대 30초 안에 새 감시목록을 반영.
- 추천 리스트 자동생성은 20:15 이후 REST 3호출만 추가하며 장중 체결/호가/프로그램/거래원 실시간 수신을 점유하지 않음.

## 회귀검증

실행 및 통과:

- `node --check` 주요 수정 JS
- `node scripts/check.js`
- `node scripts/integration-check.js`
- `node scripts/storage-check.js` — BUY→RISK→EARLY_SELL→SELL 타임라인 검증
- `node scripts/flow-regression-check.js`
- `node scripts/rest-regression-check.js`
- `node scripts/recommendation-check.js` — focus8/light8, 점수정렬, MANUAL 보호, 남는 슬롯 AUTO 채움, 공식 TR ID/입력값 회귀검증

## 20종목 합성 부하검증

최종 실행값 (`LOAD_TEST_REPORT.json`):

- 20종목, 100,000 가상 0B 틱 + 집중대상 주기적 0D/0F/0w
- 처리율: **62,657 ticks/s**
- 이벤트루프 p95: **25.41ms**
- 이벤트루프 max: **29.28ms**
- 최대 pending code: 20
- coalesced: 98,380 / processed: 1,620
- 오류: **0**
- RSS: **114.0MB**
- 종료 pending: **0**, active: **0**

판정: 계층형 20종목 구조는 합성부하에서 충분한 처리여유가 확인됐습니다. 다만 실제 Kiwoom 네트워크 지연, Lightsail CPU throttling/디스크, Web Push 지연은 합성검사에 포함되지 않으므로 실장중 `/api/health`의 event-loop p95, pending/active, RSS를 계속 확인해야 합니다.

## Next.js 실제 빌드 확인

제작환경 기본 npm 프록시는 `autoprefixer@10.5.4`에 404를 반환했고, public registry를 명시한 재시도는 제한시간 안에 완료되지 않아 여기서는 전체 `npm install`/`next build` 성공을 확인하지 못했습니다. 따라서 배포용 업데이트 스크립트는 public npm registry를 명시하고 **npm install → npm run check → 20종목 load check → next build**가 모두 성공한 경우에만 기존 컨테이너를 교체하도록 구성합니다. 실패하면 기존 컨테이너를 유지/복구합니다.


## v3.1.13 AUTO-APPLY FINAL
- 종목관리 > 매일 자동추천 영역에 `자동적용 ON/OFF`를 추가했습니다.
- 기본값은 OFF이며 영속 저장됩니다.
- ON이면 평일 20:15 KST 신규 추천 생성 성공 직후 기존 수동종목을 보호하고 남는 집중/경량 슬롯만 AUTO 종목으로 채웁니다.
- 추천 원천 수집이 실패해 stale 추천만 남은 경우에는 자동적용하지 않습니다.
- OFF이면 기존처럼 추천목록만 자동 생성하고 `추천 전체적용 · 수동종목 보호` 버튼으로 수동 적용합니다.
- 실시간 WebSocket/TR/FID 수신 계산 로직은 변경하지 않았습니다.
## v3.1.13 정식 버전 분리 검증

- `package.json` 버전: `3.1.13`
- 화면 헤더 버전: `v3.1.13`
- 부하검사 리포트 버전: `3.1.13`
- 자동적용 회귀검사: 기본 OFF, ON 영속화, 수동종목 보호, focus/light 빈 슬롯 채움, stale 추천 자동적용 차단을 모두 통과.
- `npm run check` 전체 통과.
- 20종목/100,000틱 합성 부하: **62,657 ticks/s**, event-loop p95 **25.41ms**, max **29.28ms**, 오류 0, RSS **114.0MB**, 종료 pending/active 0.
- v3.1.12 AUTO-APPLY 패치의 동작을 변경하지 않고 정식 버전 번호와 배포검증 식별자만 `3.1.13`으로 통일했습니다.

