# QUANT NOVA 3.3.4 — MARKET-WIDE ROTATION VERIFY deployment invariants

1. **One immutable source tree**: app, static UI, HTTP guard, tests and audits are built into one image. No live-container patch, `docker cp`, bind-mounted source replacement, or `docker commit` is allowed.
2. **Frozen official truth**: the main `<main>`, ENTRY_V18 policy and HTTP Guard hashes must match the accepted baseline.
3. **Protected core priority**: PINNED/FOLLOWUP/HOT registrations precede exploration. Rotation may use only remaining TRADE headroom and cannot displace protected symbols.
4. **No raised broker ceiling**: added REST calls=0, added subscription types=0, code-ceiling increase=0. Exploration PROGRAM/ORDERBOOK items=0.
5. **Immediate load shedding**: exploration targets are NORMAL 8, BUSY 4, HIGH_LOAD 2, CRITICAL 0 and are re-applied during each WebSocket registry refresh.
6. **Fail-closed promotion**: exploration data cannot enter official ENTRY_V18. Promotion discards its window and requires fresh local live warming.
7. **No stale browser path**: static responses are `no-store`; asset URLs and PWA cache are versioned; activation removes only older NOVA shell versions.
8. **One-container cutover**: only `quant-nova` is replaced. Guard and Caddy are never stopped, renamed, rebuilt, or replaced. The exact pre-cutover app container is retained until all gates pass.
9. **Runtime gate**: image label, liveness/readiness, both UI WebSockets, lab contracts, rotation acceptance, swap=0, registered-code budget, exploration target, invariant hashes, and active-session accepted-trade progress must pass. Any failure restores the retained container.
10. **Honest coverage**: the release must not claim simultaneous full-market streaming. It rotates only the existing ranking-result pool under the unchanged 1,200-candidate and broker-capacity bounds.

UI authentication remains exclusively `NOVA_UI_ACCESS_TOKEN`; legacy `APP_ACCESS_TOKEN` is ignored by the UI/API auth layer. Empty broker REG groups remain forbidden. The transport window remains 07:59:55–20:05 on trading days, including matching gaps, while official scoring follows venue session truth.
