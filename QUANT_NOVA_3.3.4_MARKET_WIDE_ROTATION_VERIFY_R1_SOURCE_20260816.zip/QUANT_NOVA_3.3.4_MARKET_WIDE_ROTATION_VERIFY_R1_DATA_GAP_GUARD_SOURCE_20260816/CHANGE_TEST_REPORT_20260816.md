# QUANT NOVA 3.3.4 MARKET-WIDE ROTATION VERIFY — change and test report

## R1 data-gap guard (2026-08-16)

- Internal package version is now aligned to `3.3.4-market-wide-rotation-verify`; runtime `SETTINGS.version` is unchanged.
- The separate VERIFY TOP10 now ranks `QUALIFIED > DATA_WAIT > CONDITION_MISS`. Official ENTRY_V18/BUY thresholds are unchanged.
- Exactly one unavailable non-price observation can be retained as `DATA_WAIT` only when every available frozen condition already passes. Freshness, price, resync and continuity remain hard fail-closed gates.
- Narrow near misses (maximum two issues inside explicit soft bands) may fill unused VERIFY slots as `CONDITION_MISS`; exact missing/failing reasons are shown.
- DATA_WAIT/CONDITION_MISS rows do not create new VERIFY samples/events, do not alert, and are not official-BUY eligible.
- The UI renders ten visible slots during LIVE; if the fresh candidate pool is genuinely smaller, remaining slots explicitly state that no additional realtime/continuity-valid candidate exists. No stock is fabricated.
- MAX PROFIT LAB asset cache-bust advanced to `3341`; the frozen main dashboard DOM and main PWA shell remain unchanged.


## Frozen baseline

- Current production ZIP SHA-256: `4ebb9f4ce1dd42e7c2269f1b04601076ec0075bf713c762f860c6d0f213b724a` (`364,520 bytes`); exact ZIP retained under `rollback/`.
- Main `<main>` SHA-256 before/after: `3f3341522fa0854d212579da30b2139d010bb774cde3f1bf20d9fb8dc297c397` / same.
- ENTRY_V18 policy SHA-256 before/after: `18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a` / same.
- HTTP Guard SHA-256 before/after: `c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b` / same.

## 3.3.4 expansion

- Reuses the existing seven KOSPI/KOSDAQ ranking requests; new broker REST calls: 0.
- Adds a VERIFY-only TRADE rotation lane: NORMAL 8, BUSY 4, HIGH_LOAD 2, CRITICAL 0.
- Normal synthetic registration: 50 protected/core + 8 exploration = 58; existing working target 60 and hard code budget 90 remain unchanged.
- Rotation interval 24 seconds, minimum dwell 72 seconds, batch 2, promising maximum hold 300 seconds, cooldown 180 seconds.
- WebSocket target construction also applies load mode, so overload shedding does not wait for the slower discovery loop.
- Exploration adds no PROGRAM/ORDERBOOK item and cannot reserve tracking capacity, write official WAL, pin a symbol or invoke ENTRY_V18.
- On promotion to an official lane, exploration history is discarded and at least 30 seconds of fresh TRADE flow must be rebuilt.
- The separate lab still shows at most 10 rows; alerts remain global/stage/symbol selectable and default OFF.

This release does not stream every listed stock at once. It rotates the symbols returned by existing ranking responses within the 1,200-candidate cap.

## Verification completed in this workspace

- Python unit/regression suite: `133/133 PASS` including four new data-gap/near-miss regression tests.
- Rotation acceptance: 1,200 candidates, 320 cycles, observed 8/4/2/0, p95 selection time `1.732 ms`, 58 TRADE codes, 0 exploration PROGRAM, 0 exploration ORDERBOOK.
- Accelerated-day validation: 80 symbols × 2 venues × 8 ticks/sec × 330 sec = `422,400` accepted synthetic events; `3,584 events/sec` in this workspace.
- Protected dispatcher stress: 120,000 submissions; 72,444 admitted/processed; protected-drop invariant PASS. Nonprotected overload drops are intentional bounded backpressure.
- Durable journal: 500 formal + 500 important records; critical write p95 `0.74 ms`.
- Master source audit, simulated image-content audit, Python compile, JavaScript syntax and all deployment-shell syntax: PASS.
- Independent VERIFY SQLite sample/event/horizon persistence: PASS.
- Main DOM, ENTRY_V18 and Guard freeze: PASS.

## Cutover and remaining live gate

`NOVA_3.3.4_SAFE_CUTOVER_AUTO_ROLLBACK.sh` retains the exact current `quant-nova` container. Any failed image label, health/readiness, API, both WebSocket paths, rotation contract, swap=0, code budget, invariant hash, or active-session accepted-trade-progress gate restores it. Guard and Caddy are not stopped or replaced.

This workspace has no Docker engine and no live Kiwoom session. Source tests use a non-network `httpx` import shim; the Dockerfile installs the real pinned dependencies and reruns the suite during image build. Lightsail 1GB RSS/CPU and actual broker registration churn therefore remain deployment-time gates, not claimed local results.
