# QUANT NOVA 3.3.4 MARKET-WIDE ROTATION VERIFY

Source of truth: `spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt`.

Official path: Broker TRADE WS -> lightweight receiver -> bounded protected queue -> venue-isolated state/window -> critical-event latch -> signal worker -> durable WAL ACK -> ENTRY_V18/live tracker -> TOP10 delta -> `/ws/live`.

VERIFY path: the existing seven ranking specifications for KOSPI/KOSDAQ produce the discovery pool. `MarketRotation` selects only spare TRADE slots from that already-fetched pool. The read-only MaxProfitLab observes those live trades, writes independent `max_profit_verify.sqlite3`, and publishes a pre-serialized snapshot through `/ws/max-profit-lab` to the separate `/max-profit-lab` page.

## Bounded coverage model

- Existing core lane remains first priority: PINNED -> FOLLOWUP -> HOT.
- Rotation lane is VERIFY only: NORMAL 8, BUSY 4, HIGH_LOAD 2, CRITICAL 0.
- Typical normal registration is 50 core + 8 rotation = 58 codes, below the existing 60-code working target.
- The historical hard provider safety budget remains 90 codes / 180 dual-venue items. Version 3.3.4 does not raise either ceiling.
- Rotation adds no broker REST request, no WebSocket subscription type, and no PROGRAM or ORDERBOOK feed.
- Load mode is applied again in the WebSocket target builder, so exploration registration sheds on the next one-second registry refresh even when the discovery loop is sleeping.
- Two non-promising rows may rotate after a minimum 72-second dwell. Promising rows can remain for at most 300 seconds; exited rows cool down for 180 seconds.

This is wider market coverage, not simultaneous streaming of every listed stock. Coverage is limited to symbols returned by the existing market ranking responses and the 1,200-candidate memory cap.

## Official-signal isolation

An exploration symbol may calculate FAST metrics only for VERIFY. It cannot mutate official score/stage, ENTRY state, BUY, WAL, pinning, tracking reservations, or the main boards. The exploration marker survives removal so a queued tick cannot cross into ENTRY_V18. If the symbol is promoted to HOT/FOLLOWUP/protected tracking, all exploration windows are discarded and at least 30 seconds of fresh local TRADE flow must be re-earned before official scoring becomes eligible. No REST snapshot is fabricated for that promotion.

P0 transport remains unchanged in principle: disk restore and broker preflight/login start concurrently; REG waits for restore completion; restored official lanes re-warm; the socket stays authenticated across scheduled matching gaps while official scoring remains session-gated.

The main `<main>` byte contract remains `3f3341522fa0854d212579da30b2139d010bb774cde3f1bf20d9fb8dc297c397`. Core boards remain fixed at 10 rows. The lab is a separate route and is not inserted into the main DOM.

Hard invariants: wrong venue=0; signal price mismatch=0; official signal without WAL ACK=0; stale official signal=0; exploration-origin official BUY=0; protected signal tick drop=0 inside the supported load envelope.
