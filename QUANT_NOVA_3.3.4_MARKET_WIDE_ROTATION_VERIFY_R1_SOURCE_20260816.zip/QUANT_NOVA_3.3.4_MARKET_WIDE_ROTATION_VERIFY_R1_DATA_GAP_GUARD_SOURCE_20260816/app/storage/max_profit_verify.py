from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from app.addons.max_profit_model import PROBABILITY_MIN_SAMPLES, PROBABILITY_MIN_SUCCESSES, _f, wilson_interval
from app.config import SETTINGS
from app.domain import Venue
from app.runtime.clock import advance_trading_day, now_kst
from app.runtime.state import RuntimeState

KST = ZoneInfo('Asia/Seoul')

class MaxProfitStore:
    """Independent VERIFY-only SQLite ledger; never joins or mutates official BUY tables."""

    def __init__(self, data_dir: Path | None = None):
        self.data_dir = data_dir or SETTINGS.data_dir
        self.path = self.data_dir / 'max_profit_verify.sqlite3'

    def _open(self) -> sqlite3.Connection:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('PRAGMA synchronous=NORMAL')
        con.execute('PRAGMA busy_timeout=3000')
        con.execute('PRAGMA foreign_keys=ON')
        con.execute('''CREATE TABLE IF NOT EXISTS lab_samples(
            sample_id TEXT PRIMARY KEY, sample_day TEXT NOT NULL, code TEXT NOT NULL, name TEXT NOT NULL,
            venue TEXT NOT NULL, entry_stage TEXT NOT NULL, entry_time REAL NOT NULL,
            entry_price REAL NOT NULL, entry_rate REAL NOT NULL, entry_score REAL NOT NULL,
            last_price REAL, last_rate REAL, high_price REAL, low_price REAL, high_rate REAL, low_rate REAL,
            mfe REAL, mae REAL, hit_10 INTEGER NOT NULL DEFAULT 0, hit_20 INTEGER NOT NULL DEFAULT 0,
            limit_touch INTEGER NOT NULL DEFAULT 0, limit_stable INTEGER NOT NULL DEFAULT 0,
            unlock_count INTEGER NOT NULL DEFAULT 0, relock_count INTEGER NOT NULL DEFAULT 0,
            collapse INTEGER NOT NULL DEFAULT 0, protector_take_profit INTEGER NOT NULL DEFAULT 0,
            protector_exit INTEGER NOT NULL DEFAULT 0, last_stage TEXT, protection_line REAL,
            updated_at REAL NOT NULL, payload TEXT NOT NULL,
            UNIQUE(sample_day,code,venue,entry_stage))''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_lab_samples_stage_time ON lab_samples(entry_stage,entry_time)')
        con.execute('''CREATE TABLE IF NOT EXISTS lab_events(
            event_id TEXT PRIMARY KEY, sample_id TEXT NOT NULL, event_time REAL NOT NULL,
            stage TEXT NOT NULL, price REAL, change_rate REAL, payload TEXT NOT NULL,
            FOREIGN KEY(sample_id) REFERENCES lab_samples(sample_id) ON DELETE CASCADE)''')
        con.execute('''CREATE TABLE IF NOT EXISTS lab_horizon_outcomes(
            sample_id TEXT NOT NULL, horizon INTEGER NOT NULL, target_day TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING', close_price REAL, return_pct REAL,
            last_verified_tick_at REAL, finalized_at REAL, source TEXT,
            PRIMARY KEY(sample_id,horizon),
            FOREIGN KEY(sample_id) REFERENCES lab_samples(sample_id) ON DELETE CASCADE)''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_lab_horizon_target ON lab_horizon_outcomes(target_day,status)')
        return con

    def ensure(self) -> None:
        self._open().close()

    def upsert_batch(self, samples: list[dict[str, Any]], events: list[dict[str, Any]]) -> None:
        if not samples and not events:
            return
        con = self._open()
        try:
            con.execute('BEGIN IMMEDIATE')
            for r in samples:
                payload = json.dumps(r.get('payload') or {}, ensure_ascii=False, separators=(',', ':'))
                cur = con.execute('''INSERT OR IGNORE INTO lab_samples(
                    sample_id,sample_day,code,name,venue,entry_stage,entry_time,entry_price,entry_rate,entry_score,
                    last_price,last_rate,high_price,low_price,high_rate,low_rate,mfe,mae,hit_10,hit_20,
                    limit_touch,limit_stable,unlock_count,relock_count,collapse,protector_take_profit,
                    protector_exit,last_stage,protection_line,updated_at,payload)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
                    r['sample_id'], r['sample_day'], r['code'], r['name'], r['venue'], r['entry_stage'],
                    r['entry_time'], r['entry_price'], r['entry_rate'], r['entry_score'], r['last_price'],
                    r['last_rate'], r['high_price'], r['low_price'], r['high_rate'], r['low_rate'], r['mfe'],
                    r['mae'], int(r['hit_10']), int(r['hit_20']), int(r['limit_touch']), int(r['limit_stable']),
                    r['unlock_count'], r['relock_count'], int(r['collapse']), int(r['protector_take_profit']),
                    int(r['protector_exit']), r['last_stage'], r['protection_line'], r['updated_at'], payload))
                if cur.rowcount == 1:
                    for horizon in (1, 3, 5):
                        con.execute('INSERT OR IGNORE INTO lab_horizon_outcomes(sample_id,horizon,target_day,status) VALUES(?,?,?,?)',
                                    (r['sample_id'], horizon, advance_trading_day(r['sample_day'], horizon), 'PENDING'))
                con.execute('''UPDATE lab_samples SET last_price=?,last_rate=?,high_price=?,low_price=?,high_rate=?,low_rate=?,
                    mfe=?,mae=?,hit_10=?,hit_20=?,limit_touch=?,limit_stable=?,unlock_count=?,relock_count=?,collapse=?,
                    protector_take_profit=?,protector_exit=?,last_stage=?,protection_line=?,updated_at=?,payload=? WHERE sample_id=?''',
                    (r['last_price'], r['last_rate'], r['high_price'], r['low_price'], r['high_rate'], r['low_rate'],
                     r['mfe'], r['mae'], int(r['hit_10']), int(r['hit_20']), int(r['limit_touch']),
                     int(r['limit_stable']), r['unlock_count'], r['relock_count'], int(r['collapse']),
                     int(r['protector_take_profit']), int(r['protector_exit']), r['last_stage'],
                     r['protection_line'], r['updated_at'], payload, r['sample_id']))
            for e in events:
                con.execute('INSERT OR IGNORE INTO lab_events(event_id,sample_id,event_time,stage,price,change_rate,payload) VALUES(?,?,?,?,?,?,?)',
                            (e['event_id'], e['sample_id'], e['event_time'], e['stage'], e['price'],
                             e['change_rate'], json.dumps(e.get('payload') or {}, ensure_ascii=False, separators=(',', ':'))))
            extra = con.execute('SELECT sample_id FROM lab_samples ORDER BY entry_time DESC LIMIT -1 OFFSET ?',
                                (SETTINGS.max_profit_sample_cap,)).fetchall()
            if extra:
                con.executemany('DELETE FROM lab_samples WHERE sample_id=?', extra)
            con.execute('COMMIT')
        except Exception:
            con.execute('ROLLBACK')
            raise
        finally:
            con.close()

    @staticmethod
    def _tick_day(ts: float) -> str:
        try:
            return datetime.fromtimestamp(float(ts), KST).strftime('%Y%m%d')
        except Exception:
            return ''

    @staticmethod
    def _venue_closed(venue: str, now: datetime) -> bool:
        sec = now.hour * 3600 + now.minute * 60 + now.second
        return sec >= (15 * 3600 + 30 * 60 if venue == 'KRX' else 20 * 3600)

    def sync_horizons(self, state: RuntimeState) -> int:
        if not self.path.exists():
            return 0
        con = self._open()
        finalized = 0
        try:
            today = now_kst().strftime('%Y%m%d')
            now = now_kst()
            rows = con.execute('''SELECT h.sample_id,h.horizon,h.target_day,s.code,s.venue,s.entry_price
                                  FROM lab_horizon_outcomes h JOIN lab_samples s ON s.sample_id=h.sample_id
                                  WHERE h.status!='FINAL' AND h.target_day<=? ORDER BY s.entry_time DESC LIMIT 1000''',
                               (today,)).fetchall()
            for sample_id, horizon, target, code, venue, entry_price in rows:
                if target != today:
                    continue
                candidate = state.candidates.get(str(code))
                if not candidate:
                    continue
                try:
                    lane = candidate.venue_state[Venue(str(venue))]
                except Exception:
                    continue
                if lane.last_price <= 0 or self._tick_day(lane.last_tick_at) != target:
                    continue
                if not self._venue_closed(str(venue), now):
                    continue
                ret = (float(lane.last_price) / float(entry_price) - 1) * 100
                con.execute("UPDATE lab_horizon_outcomes SET status='FINAL',close_price=?,return_pct=?,last_verified_tick_at=?,finalized_at=?,source=? WHERE sample_id=? AND horizon=?",
                            (lane.last_price, round(ret, 4), lane.last_tick_at, time.time(), 'EXISTING_LIVE_' + str(venue), sample_id, horizon))
                finalized += 1
            return finalized
        finally:
            con.close()

    def statistics(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        con = sqlite3.connect(f'file:{self.path}?mode=ro', uri=True, timeout=3)
        try:
            rows = con.execute('''SELECT entry_stage,COUNT(*),SUM(hit_10),SUM(hit_20),SUM(limit_touch),
                                         SUM(limit_stable),SUM(CASE WHEN relock_count>0 THEN 1 ELSE 0 END),
                                         AVG(mfe),AVG(mae)
                                  FROM lab_samples GROUP BY entry_stage ORDER BY MIN(entry_time)''').fetchall()
            out = []
            for stage, total, hit10, hit20, limit_touch, stable, relock, avg_mfe, avg_mae in rows:
                successes = int(stable or 0) if stage == 'LIMIT_GUARD' else int(relock or 0) if stage == 'UNLOCK_WATCH' else int(limit_touch or 0)
                eligible = int(total) >= PROBABILITY_MIN_SAMPLES and successes >= PROBABILITY_MIN_SUCCESSES
                low, high = wilson_interval(successes, int(total)) if eligible else (0.0, 0.0)
                out.append({
                    'stage': stage,
                    'samples': int(total),
                    'hit_10': int(hit10 or 0),
                    'hit_20': int(hit20 or 0),
                    'limit_touch': int(limit_touch or 0),
                    'limit_stable': int(stable or 0),
                    'relock': int(relock or 0),
                    'success_definition': 'LIMIT_STABLE' if stage == 'LIMIT_GUARD' else 'RELOCK' if stage == 'UNLOCK_WATCH' else 'LIMIT_TOUCH',
                    'probability_pct': round(successes / int(total) * 100, 2) if eligible else None,
                    'ci95_low_pct': round(low * 100, 2) if eligible else None,
                    'ci95_high_pct': round(high * 100, 2) if eligible else None,
                    'sample_status': 'VERIFIED' if eligible else '표본부족',
                    'avg_mfe': round(_f(avg_mfe), 3) if avg_mfe is not None else None,
                    'avg_mae': round(_f(avg_mae), 3) if avg_mae is not None else None,
                })
            return out
        finally:
            con.close()

    def recent_events(self, limit: int = 30) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        con = sqlite3.connect(f'file:{self.path}?mode=ro', uri=True, timeout=3)
        try:
            rows = con.execute('''SELECT e.event_time,s.code,s.name,s.venue,e.stage,e.price,e.change_rate,e.payload
                                  FROM lab_events e JOIN lab_samples s ON s.sample_id=e.sample_id
                                  ORDER BY e.event_time DESC LIMIT ?''', (max(1, min(100, limit)),)).fetchall()
            return [{'at': r[0], 'code': r[1], 'name': r[2], 'venue': r[3], 'stage': r[4],
                     'price': r[5], 'change_rate': r[6], 'payload': json.loads(r[7] or '{}')} for r in rows]
        finally:
            con.close()

