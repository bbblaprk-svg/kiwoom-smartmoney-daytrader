from __future__ import annotations
import asyncio,time,hashlib
from app.domain import SignalEvent,SignalTrack,Venue
from app.runtime.state import RuntimeState
from app.runtime.clock import sessions,trade_day
from app.signal.metrics import MetricEngine
from app.signal.policy import EntryPolicy
from app.storage.wal import DurableJournal
from app.lifecycle.opening import OpeningBridge
from app.config import SETTINGS,effective_ws_code_budget

FORMAL_STAGES={'PRESSURE','IGNITION'}
STAGE_RANK={'SEED':0,'WATCH':1,'PRESSURE':2,'IGNITION':3}

class SignalCoordinator:
    def __init__(self,state:RuntimeState,journal:DurableJournal):
        self.state=state;self.journal=journal;self.metrics=MetricEngine(state);self.entry=EntryPolicy(state,journal);self.opening=OpeningBridge();self.running=True

    @staticmethod
    def _evidence_signature(m:dict)->str:
        keys=(
            ('accel',float(m.get('volume_accel') or 1)>=1.7),('bp',float(m.get('buy_pressure') or 0)>=60),
            ('smart',bool(m.get('smart_money_realtime_proxy_surge'))),('flip',bool(m.get('sell_to_buy_flip'))),
            ('breakout',float(m.get('micro_breakout') or 0)>=.3),('orb',float(m.get('orb_breakout_pct') or 0)>=.15),
            ('dual',bool(m.get('dual_venue'))),('program',bool(m.get('program_fresh')) and float(m.get('program_delta') or 0)>0),
            ('orderbook',float(m.get('orderbook_presignal') or 0)>=1.0),('vwap',float(m.get('micro_vwap_gap') or 0)>=.2),
        )
        raw='|'.join(k for k,v in keys if v) or 'BASE'
        return hashlib.blake2s(raw.encode(),digest_size=6).hexdigest()

    def _reserve_tracking_capacity(self,c,venue:Venue)->tuple[bool,bool]:
        # Formal signals/BUYs are forbidden unless a unique real-time tracking slot is atomically
        # reserved. This closes the 24-way score batch race where several symbols could all observe
        # one remaining slot before their WAL commits completed.
        return self.state.reserve_tracking_slot(c.code,venue,effective_ws_code_budget())

    def _stage_record(self,c,venue,stage,src,decision,valid_repeat:bool,evidence:str)->dict:
        day=trade_day();sid=f'{day}:{venue.value}:{c.code}:{stage}:{src.recv_seq}';m=decision.metrics;next_valid=c.valid_repeat_count+(1 if valid_repeat else 0)
        return {'event':'SIGNAL_CONFIRMED','runtime':SETTINGS.version,'signal_id':sid,'day':day,'trade_day':day,'code':c.code,'symbol':c.code,'name':c.name,'venue':venue.value,'stage':stage,'route':'SCORE_STAGE','signal_time':src.server_receive_time,'signal_price':src.price,'current_price_at_signal':src.price,'signal_change_rate':src.rate,'recv_seq':src.recv_seq,'exchange_time':src.exchange_time,'server_receive_time':src.server_receive_time,'reasons':decision.reasons,'metrics':m,'volume_state':m.get('cum_volume'),'turnover_state':m.get('cum_turnover'),'vwap_state':m.get('session_vwap'),'rvol_state':m.get('rvol_intraday'),'execution_strength_state':m.get('execution_strength'),'smart_money_state':{'score':m.get('smart_money_realtime_proxy_score'),'surge':m.get('smart_money_realtime_proxy_surge'),'label':m.get('smart_money_proxy_label')},'valid_repeat':valid_repeat,'evidence_signature':evidence,'valid_repeat_count':next_valid,'origin':c.origin.value}

    def _apply_stage_committed(self,c,venue,record,decision,src,valid_repeat,evidence):
        v=c.venue_state[venue];lane=v.entry;lane.formal_raw_count+=1;lane.last_formal_at=record['signal_time'];lane.last_formal_stage=record['stage'];v.stage=record['stage']
        if not valid_repeat:
            c.raw_repeat_count+=1;c.append_history('SIGNAL_REPEAT_RAW',record['stage'],src.price,'기계적 중복 · 유효반복 가산 없음',venue,record['signal_time']);c.refresh_aggregate();return
        lane.valid_repeat_count+=1;lane.last_evidence_signature=evidence;repeat=lane.valid_repeat_count
        sig=SignalEvent(record['signal_id'],record['day'],c.code,c.name,venue,record['stage'],'SCORE_STAGE',record['signal_time'],src.price,src.rate,src.recv_seq,src.exchange_time,src.server_receive_time,decision.reasons,decision.metrics,repeat,c.origin)
        c.live_track_pin=True;c.signal_high=src.price;c.signal_low=src.price
        if c.first_signal is None:c.first_signal=sig
        c.last_signal=sig;c.signal_tracks.append(SignalTrack(sig.signal_id,venue,src.price,record['signal_time'],src.price,src.price,src.price,record['signal_time']))
        c.append_history('SIGNAL',record['stage'],src.price,' · '.join(decision.reasons[:3]),venue,record['signal_time']);self.state.pinned_codes.add(c.code);c.refresh_aggregate()

    async def score_one(self,code:str,venue:Venue,signal_queue_age_ms:float=0.0,trigger_recv_seq:int=0):
        c=self.state.candidates.get(code)
        if not c:return
        exploration_only=self.state.is_exploration_only(code);sess=sessions();session_active=bool(self.state.restore_done and (sess['krx'] if venue==Venue.KRX else sess['nxt']));lk=self.state.code_lock(code)
        with lk:
            v=c.venue_state[venue]
            if trigger_recv_seq and v.last_recv_seq!=trigger_recv_seq:self.state.telemetry['critical_event_late_eval_count']+=1
            old_stage=v.stage;decision=self.metrics.score(c,venue,session_active)
            if exploration_only:
                # Rotation expands observation only.  It may calculate the same
                # FAST metrics for MAX PROFIT VERIFY, but cannot mutate score,
                # stage, ENTRY lane, WAL, pinned tracking or the main BUY boards.
                v.metrics.update(decision.metrics);v.metrics['exploration_verify_only']=True
                v.metrics['exploration_candidate_score']=decision.score;v.metrics['exploration_candidate_stage']=decision.stage
                c.metrics['exploration_verify_only']=True;c.metrics['exploration_last_score_at']=time.time()
                self.state.telemetry['exploration_official_block_count']+=1
            else:
                src=self.entry.source(c,venue)
                v.score=decision.score;v.confidence=decision.confidence;v.reasons=decision.reasons;v.metrics.update(decision.metrics)
                evidence=self._evidence_signature(v.metrics);lane=v.entry
                formal_due=decision.stage in FORMAL_STAGES and (old_stage not in FORMAL_STAGES or STAGE_RANK.get(decision.stage,0)>STAGE_RANK.get(old_stage,0) or not lane.last_formal_at or time.time()-lane.last_formal_at>30)
                valid_repeat=formal_due and (old_stage not in FORMAL_STAGES or STAGE_RANK.get(decision.stage,0)>STAGE_RANK.get(old_stage,0) or evidence!=lane.last_evidence_signature)
                if not formal_due:v.stage=decision.stage
                intent=self.entry.advance(c,venue,session_active,src)
                c.refresh_aggregate();self.opening.update(c);c.refresh_aggregate()
        self.state.observe_latency('signal_queue_ms',signal_queue_age_ms)
        if exploration_only:return
        reserved=False
        if formal_due or intent:
            ok_slot,reserved=self._reserve_tracking_capacity(c,venue)
            if not ok_slot:
                with lk:
                    self.state.telemetry['tracking_capacity_block_count']+=1
                    v.metrics['formal_signal_blocked']='WS_TRACKING_CAPACITY'
                    v.metrics['entry_reason']='실시간 추적 슬롯 포화 · 신규 정식신호 fail-closed'
                    if formal_due:v.stage='WATCH'
                    c.refresh_aggregate()
                return
        try:
            if formal_due:
                if not src.server_receive_time or src.recv_seq<=0 or src.venue not in (Venue.KRX,Venue.NXT):
                    self.state.telemetry['signal_without_live_snapshot_count']+=1;return
                if time.time()-src.server_receive_time>3.5 or not bool(decision.metrics.get('fresh')):
                    self.state.telemetry['stale_signal_count']+=1;return
                rec=self._stage_record(c,venue,decision.stage,src,decision,valid_repeat,evidence);v.metrics['signal_publish_state']='PERSIST_PENDING';ok=await asyncio.to_thread(self.journal.commit,rec,.75)
                with lk:
                    if ok:
                        if not ok.inserted:self.state.telemetry['wal_duplicate_commit_count']+=1
                        else:
                            if rec['signal_price']!=rec['current_price_at_signal']:self.state.telemetry['signal_price_mismatch_count']+=1
                            self._apply_stage_committed(c,venue,rec,decision,src,valid_repeat,evidence);v.metrics['signal_publish_state']='OFFICIAL_SIGNAL'
                            self.state.observe_latency('tick_to_signal_ms',max(0,(time.time()-src.server_receive_time)*1000))
                    else:
                        self.state.telemetry['journal_fail_closed_count']+=1;v.stage='WATCH';v.metrics['signal_publish_state']='PERSIST_FAILED';v.metrics['formal_signal_blocked']='WAL_UNAVAILABLE';c.refresh_aggregate()
            if intent:
                if intent.source.venue!=venue:self.state.telemetry['wrong_venue_price_count']+=1;return
                rec=self.entry.wal_record(c,intent);v.metrics['signal_publish_state']='PERSIST_PENDING';ok=await asyncio.to_thread(self.journal.commit,rec,.75)
                with lk:
                    if ok:
                        if not ok.inserted:self.state.telemetry['wal_duplicate_commit_count']+=1;return
                        if rec['signal_price']!=rec['current_price_at_signal'] or rec['signal_price']!=intent.source.price:self.state.telemetry['signal_price_mismatch_count']+=1;return
                        self.entry.apply_committed(c,intent,rec);v.metrics['signal_publish_state']='OFFICIAL_SIGNAL';self.opening.update(c);c.refresh_aggregate();self.state.observe_latency('tick_to_signal_ms',max(0,(time.time()-intent.source.server_receive_time)*1000))
                    else:self.state.telemetry['journal_fail_closed_count']+=1;v.metrics['signal_publish_state']='PERSIST_FAILED';v.metrics['entry_reason']='BUY WAL FAIL-CLOSED'
        finally:
            if reserved:self.state.release_tracking_slot(c.code,venue)

    async def run(self):
        # Dirty keys are already coalesced per (symbol, venue). Process a bounded batch concurrently
        # so one fsync cannot serialize unrelated symbols; DurableJournal group-commits the records.
        while self.running:
            started=time.perf_counter();items=self.state.pop_dirty(24)
            if not items:
                await asyncio.sleep(.02);continue
            results=await asyncio.gather(*(self.score_one(code,venue,qage,trigger_seq) for code,venue,qage,trigger_seq in items),return_exceptions=True)
            errors=sum(1 for x in results if isinstance(x,Exception))
            if errors:self.state.telemetry['score_worker_error_count']+=errors
            self.state.last_score_at=time.time();self.state.telemetry['score_batch_ms']=(time.perf_counter()-started)*1000
