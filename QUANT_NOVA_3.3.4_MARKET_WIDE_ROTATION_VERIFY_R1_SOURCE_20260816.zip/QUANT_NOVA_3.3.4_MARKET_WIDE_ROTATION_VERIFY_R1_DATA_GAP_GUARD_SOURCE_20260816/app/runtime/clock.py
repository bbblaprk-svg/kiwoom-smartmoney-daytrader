from __future__ import annotations
from datetime import datetime,date,timedelta
from zoneinfo import ZoneInfo
import json
from pathlib import Path
from app.config import SETTINGS
KST=ZoneInfo('Asia/Seoul')
_HOLIDAY_FILE=Path(__file__).resolve().parents[2]/'config'/'krx_holidays.json'
_OVERRIDE_FILE=SETTINGS.data_dir/'krx_calendar_override.json'


def _norm_dates(v):
    if isinstance(v,dict):
        return {str(x).replace('-','') for rows in v.values() for x in (rows or [])}
    if isinstance(v,list):
        return {str(x).replace('-','') for x in v}
    return set()

try:
    _RAW=json.loads(_HOLIDAY_FILE.read_text(encoding='utf-8'))
except Exception:
    _RAW={}
_HOLIDAYS=_norm_dates((_RAW or {}).get('holidays') if isinstance(_RAW,dict) else _RAW)
_OPEN_DAYS=_norm_dates((_RAW or {}).get('open_days')) if isinstance(_RAW,dict) else set()
_COVERAGE=(_RAW or {}).get('coverage',{}) if isinstance(_RAW,dict) else {}
_CAL_FROM=str(_COVERAGE.get('from') or '')
_CAL_TO=str(_COVERAGE.get('to') or '')
CALENDAR_VERSION=str((_RAW or {}).get('version') or 'KRX_CALENDAR_LEGACY') if isinstance(_RAW,dict) else 'KRX_CALENDAR_LEGACY'
_CLOSURE_REASONS=(_RAW or {}).get('closure_reasons',{}) if isinstance(_RAW,dict) else {}


def _load_override():
    try:
        raw=json.loads(_OVERRIDE_FILE.read_text(encoding='utf-8'))
        if not isinstance(raw,dict):return set(),set(),{}
        return _norm_dates(raw.get('force_closed')), _norm_dates(raw.get('force_open')), dict(raw.get('special_sessions') or {})
    except Exception:return set(),set(),{}

_FORCE_CLOSED,_FORCE_OPEN,_SPECIAL_SESSIONS=_load_override()


def now_kst() -> datetime:return datetime.now(KST)

def _covered(key:str)->bool:return bool(_OPEN_DAYS and _CAL_FROM and _CAL_TO and _CAL_FROM<=key<=_CAL_TO)

def calendar_info(d:date|None=None)->dict:
    d=d or now_kst().date();key=d.strftime('%Y%m%d');reasons=[]
    yr=_CLOSURE_REASONS.get(str(d.year),{}) if isinstance(_CLOSURE_REASONS,dict) else {}
    if isinstance(yr,dict):reasons=list(yr.get(key) or [])
    override='FORCE_OPEN' if key in _FORCE_OPEN else 'FORCE_CLOSED' if key in _FORCE_CLOSED else ''
    return {'version':CALENDAR_VERSION,'date':key,'covered':_covered(key),'is_trading_date':is_trading_date(d),'override':override,'closure_reasons':reasons,'special_session':_SPECIAL_SESSIONS.get(key)}

def trading_day_for(d:date)->date:
    while not is_trading_date(d):d-=timedelta(days=1)
    return d


def trade_day() -> str:
    # Trading-day identity changes at the 07:30 KST handoff, not at midnight.
    # This preserves the prior session's close/display truth throughout 21:30~07:30
    # and prevents an overnight restart from creating a new empty day before handoff.
    n=now_kst();d=n.date()
    if n.hour*3600+n.minute*60+n.second < 7*3600+30*60:d-=timedelta(days=1)
    return trading_day_for(d).strftime('%Y%m%d')

def sec_of_day() -> int:
    n=now_kst();return n.hour*3600+n.minute*60+n.second


def is_trading_date(d:date)->bool:
    key=d.strftime('%Y%m%d')
    # Operator override is the final authority for future KRX temporary closures/openings.
    if key in _FORCE_OPEN:return True
    if key in _FORCE_CLOSED:return False
    if _covered(key):return key in _OPEN_DAYS
    return d.weekday()<5 and key not in _HOLIDAYS

def is_trading_day() -> bool:return is_trading_date(now_kst().date())
def next_trading_day(day:str)->str:
    d=datetime.strptime(day,'%Y%m%d').date()+timedelta(days=1)
    while not is_trading_date(d):d+=timedelta(days=1)
    return d.strftime('%Y%m%d')


def advance_trading_day(day:str,steps:int)->str:
    out=str(day)
    for _ in range(max(0,int(steps))):out=next_trading_day(out)
    return out


def sessions_at(d:date,s:int) -> dict:
    """Continuous-trade session truth for KRX/NXT.

    NXT's 08:00~20:00 operating day contains auction/rest gaps. Realtime trade
    liveness must follow the actual continuous matching windows, otherwise a healthy
    socket is falsely treated as stale during 08:50~09:00:30 or 15:20~15:40.
    """
    wd=is_trading_date(d)
    krx=wd and 9*3600 <= s < 15*3600+30*60
    nxt_pre=wd and 8*3600 <= s < 8*3600+50*60
    nxt_main=wd and 9*3600+30 <= s < 15*3600+20*60
    nxt_after=wd and 15*3600+40*60 <= s < 20*3600
    nxt=nxt_pre or nxt_main or nxt_after
    nxt_phase='PRE' if nxt_pre else 'MAIN' if nxt_main else 'AFTER' if nxt_after else 'CLOSED'
    return {'krx':krx,'nxt':nxt,'active':krx or nxt,'phase':('DUAL' if krx and nxt else 'KRX' if krx else 'NXT' if nxt else 'CLOSED'),'nxt_phase':nxt_phase}


def sessions() -> dict:
    n=now_kst();return sessions_at(n.date(),n.hour*3600+n.minute*60+n.second)


def connection_window_at(d:date,s:int)->dict:
    """Broker transport window, deliberately wider than matching sessions.

    The socket stays authenticated across the NXT/KRX matching gaps.  Official
    scoring still follows ``sessions_at`` and therefore remains fail-closed
    whenever neither venue is continuously matching.
    """
    trading=is_trading_date(d);opened=trading and 7*3600+59*60+55<=s<20*3600+5*60
    if not opened:state='FROZEN'
    elif s<8*3600:state='PREFLIGHT'
    elif not sessions_at(d,s)['active']:state='CLOSING' if s>=20*3600 else 'SESSION_GAP'
    else:state='ACTIVE'
    return {'open':opened,'state':state,'date':d.strftime('%Y%m%d')}


def connection_window()->dict:
    n=now_kst();return connection_window_at(n.date(),n.hour*3600+n.minute*60+n.second)


def opening_windows(s:int|None=None)->dict:
    s=sec_of_day() if s is None else int(s)
    return {'shakeout':9*3600 <= s < 9*3600+30*60,'reversal':9*3600+10*60 <= s < 10*3600}


def lifecycle_phase() -> str:
    s=sec_of_day()
    if 19*3600+30*60 <= s < 20*3600:return 'CLOSE_TRACK'
    if s >= 20*3600 or s < 7*3600+30*60:return 'PRIOR_CLOSE_FROZEN'
    if 7*3600+30*60 <= s < 8*3600:return 'PREMARKET_PREP'
    if 8*3600 <= s < 8*3600+50*60:return 'PREMARKET_RECHECK'
    if 8*3600+50*60 <= s < 9*3600:return 'OPENING_HANDOFF'
    w=opening_windows(s)
    if w['reversal']:return 'REVERSAL_WINDOW'
    if w['shakeout']:return 'SHAKEOUT_WATCH'
    return 'NORMAL_INTRADAY'
