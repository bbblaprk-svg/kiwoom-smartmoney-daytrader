from __future__ import annotations
import hashlib, json, os, time
from pathlib import Path
from typing import Any
from app.storage.snapshot import PRIOR_CLOSE_SNAPSHOT


def fnum(v: Any, default: float = 0.0) -> float:
    try:return float(v if v is not None else default)
    except Exception:return default


class ShadowStore:
    SCHEMA = 1
    MAX_TRANSITIONS = 500

    def __init__(self, path: Path):
        self.path = Path(path)
        self.last_persist_hash = ''
        self.last_persist_at = 0.0
        self.data = self.load()
        self.bootstrap_r41_prior_if_needed()

    @classmethod
    def blank(cls) -> dict[str, Any]:
        return {'schema':cls.SCHEMA,'mode':'SHADOW','updated_at':0.0,'source_day':'','effective_day':'','phase':'','candidates':{},'transitions':[],'bootstrap':{}}

    def load(self) -> dict[str, Any]:
        try:
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(raw,dict) and int(raw.get('schema') or 0)==self.SCHEMA:
                raw.setdefault('candidates',{});raw.setdefault('transitions',[]);raw.setdefault('bootstrap',{});return raw
        except Exception:pass
        return self.blank()

    def persist(self, force: bool=False) -> None:
        body=json.dumps(self.data,ensure_ascii=False,sort_keys=True,separators=(',',':'));h=hashlib.sha256(body.encode()).hexdigest();now=time.time()
        if not force and h==self.last_persist_hash:return
        if not force and now-self.last_persist_at<5:return
        self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix(self.path.suffix+'.tmp');tmp.write_text(body,encoding='utf-8');os.replace(tmp,self.path)
        self.last_persist_hash=h;self.last_persist_at=now

    def transition(self, rec:dict[str,Any], new_state:str, reason:str, now:float) -> None:
        old=str(rec.get('shadow_state') or '')
        if old==new_state:return
        rec['shadow_state']=new_state;rec['state_changed_at']=now
        arr=self.data.setdefault('transitions',[]);arr.append({'at':now,'candidate_id':rec.get('candidate_id'),'code':rec.get('code'),'from':old,'to':new_state,'reason':reason[:180]})
        if len(arr)>self.MAX_TRANSITIONS:del arr[:-self.MAX_TRANSITIONS]

    def bootstrap_r41_prior_if_needed(self) -> None:
        if self.data.get('candidates'):return
        try:raw=json.loads(Path(PRIOR_CLOSE_SNAPSHOT).read_text(encoding='utf-8'))
        except Exception:return
        source_day=str(raw.get('source_day') or '');effective_day=str(raw.get('effective_day') or '')
        if not source_day or not effective_day:return
        by=self.data.setdefault('candidates',{});now=time.time()
        for i,r in enumerate(raw.get('rows') or [],1):
            code=str(r.get('code') or '')
            if not code:continue
            cid=f'{source_day}:UNKNOWN:{code}:LEGACY_CLOSE_UNSPECIFIED'
            by[cid]={
                'candidate_id':cid,'source_day':source_day,'effective_day':effective_day,'code':code,'name':str(r.get('name') or code),'origin':'PRIOR_CLOSE',
                'source':'LEGACY_CLOSE_UNSPECIFIED','venue':'UNKNOWN','captured_at':float(raw.get('generated_at') or now),'reference_price':fnum(r.get('close_signal_price') or r.get('price')),
                'reference_change_rate':0.0,'close_score':fnum(r.get('close_score') or r.get('score')),'close_rank':int(r.get('close_rank') or r.get('rank') or i),'repeat_total':int(r.get('valid_repeat_count') or 0),
                'entry_state_at_close':'UNKNOWN','stage_at_close':'UNKNOWN','shadow_state':'PRIOR_CLOSE_FROZEN','premarket_state':'HOLD','opening_price':0.0,'opening_high':0.0,'opening_low':0.0,
                'shakeout_seen':False,'reversal_seen':False,'last_eval_at':0.0,'migration_note':'R4.1 compact snapshot lacked venue/source; not inferred',
            }
        if by:
            self.data.update({'source_day':source_day,'effective_day':effective_day,'phase':'PRIOR_CLOSE_FROZEN','updated_at':now})
            try:self.persist(force=True)
            except Exception:pass
