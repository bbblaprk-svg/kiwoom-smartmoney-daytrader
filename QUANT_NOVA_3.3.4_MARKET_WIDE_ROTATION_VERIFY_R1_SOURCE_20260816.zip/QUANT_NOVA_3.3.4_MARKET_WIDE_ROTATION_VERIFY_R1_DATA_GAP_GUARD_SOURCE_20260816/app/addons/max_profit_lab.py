from __future__ import annotations

import asyncio
import json
import math
import threading
import time
from pathlib import Path
from typing import Any

from app.addons.max_profit_model import (
    LabTrack,
    PROBABILITY_MIN_SAMPLES,
    PROBABILITY_MIN_SUCCESSES,
    STAGE_RANK,
    SampleProgress,
    _clamp,
    _f,
    instrument_category,
    protection_line,
    wilson_interval,
    selection_assessment,
)
from app.config import SETTINGS
from app.domain import Candidate, Venue
from app.runtime.clock import sessions, trade_day
from app.runtime.state import RuntimeState
from app.storage.max_profit_verify import MaxProfitStore

SELECTION_STATUS_RANK = {'QUALIFIED': 3, 'DATA_WAIT': 2, 'CONDITION_MISS': 1}

class MaxProfitLab:
    """Read-only shadow observer over existing realtime candidate state."""

    def __init__(self, state: RuntimeState, data_dir: Path | None = None):
        self.state = state
        self.store = MaxProfitStore(data_dir)
        self.lock = threading.RLock()
        self.tracks: dict[tuple[str, Venue], LabTrack] = {}
        self.pending_samples: dict[str, dict[str, Any]] = {}
        self.pending_events: dict[str, dict[str, Any]] = {}
        self.current_day = trade_day()
        self.generation = 0
        self.stats: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.last_rows: list[dict[str, Any]] = []
        self.snapshot = self._empty_snapshot('STARTING')
        self.snapshot_json = json.dumps(self.snapshot, ensure_ascii=False, separators=(',', ':'))

    def _empty_snapshot(self, state: str) -> dict[str, Any]:
        return {
            'ok': True,
            'version': SETTINGS.version,
            'mode': 'VERIFY_ONLY',
            'generated_at': time.time(),
            'generation': self.generation,
            'state': state,
            'rows': [],
            'groups': {'COMMON': [], 'PREFERRED': [], 'SPAC': [], 'MANAGED': []},
            'statistics': [],
            'events': [],
            'contracts': {
                'official_buy_logic_changed': False,
                'new_broker_rest_calls': 0,
                'new_ws_subscription_types': 0,
                'ws_registered_code_ceiling_increase': 0,
                'bounded_trade_rotation': True,
                'exploration_official_buy_blocked': True,
                'exploration_program_orderbook_added': False,
                'automatic_orders': False,
                'probability_min_samples': PROBABILITY_MIN_SAMPLES,
                'probability_min_successes': PROBABILITY_MIN_SUCCESSES,
                'orderbook_dependency': False,
                'qualified_first_ranking': True,
                'single_missing_metric_rescue': True,
                'data_wait_official_buy_blocked': True,
                'condition_miss_official_buy_blocked': True,
            },
        }

    def get(self) -> dict[str, Any]:
        with self.lock:
            return self.snapshot

    def wire(self) -> str:
        with self.lock:
            return self.snapshot_json

    def _track(self, candidate: Candidate, venue: Venue) -> LabTrack:
        key = (candidate.code, venue)
        track = self.tracks.get(key)
        if track is None or track.day != self.current_day:
            track = LabTrack(self.current_day, candidate.code, candidate.name or candidate.code, venue)
            self.tracks[key] = track
        elif candidate.name and track.name == track.code:
            track.name = candidate.name
        return track

    @staticmethod
    def _base_stage(rate: float, metrics: dict[str, Any]) -> str:
        accel = _f(metrics.get('volume_accel'), 1.0)
        accel_ready = bool(metrics.get('volume_accel_ready'))
        bp = _f(metrics.get('buy_pressure'), 50.0)
        strength = _f(metrics.get('execution_strength'), 100.0)
        turn = _f(metrics.get('turnover_60s'))
        sgap = _f(metrics.get('session_vwap_gap'))
        impulse = _f(metrics.get('impulse_60s'))
        if rate >= 29.5:
            return 'LIMIT_GUARD'
        if rate >= 20.0:
            return 'NO_ADD'
        if rate >= 15.0:
            return 'CHASE_BLOCK'
        if 10.0 <= rate < 15.0 and accel_ready and accel >= 1.7 and bp >= 60 and strength >= 120 and turn >= 300_000_000:
            return 'BUY_3'
        if 7.0 <= rate < 10.0 and accel_ready and accel >= 1.7 and bp >= 60 and strength >= 120 and turn >= 200_000_000 and impulse >= .35:
            return 'IGNITION'
        if 3.0 <= rate < 7.0 and accel_ready and accel >= 1.5 and bp >= 58 and strength >= 115 and turn >= 100_000_000 and sgap >= 0:
            return 'PRE_IGNITION'
        if 0.0 <= rate < 3.0 and accel_ready and accel >= 1.3 and bp >= 55 and strength >= 108 and turn >= 50_000_000 and sgap >= 0:
            return 'MICRO_FLOW'
        return ''

    @staticmethod
    def _lab_score(rate: float, metrics: dict[str, Any], collapse_count: int) -> float:
        accel = _f(metrics.get('volume_accel'), 1.0)
        bp = _f(metrics.get('buy_pressure'), 50.0)
        strength = _f(metrics.get('execution_strength'), 100.0)
        turn = _f(metrics.get('turnover_60s'))
        sgap = _f(metrics.get('session_vwap_gap'))
        impulse = _f(metrics.get('impulse_60s'))
        breakout = _f(metrics.get('micro_breakout'))
        smart = _f(metrics.get('smart_money_realtime_proxy_score'))
        score = 25
        score += _clamp((accel - 1) * 14, 0, 20)
        score += _clamp((bp - 50) * .65, 0, 16)
        score += _clamp((strength - 100) * .10, 0, 12)
        score += _clamp(math.log10(max(turn, 1) / 50_000_000 + 1) * 12, 0, 18)
        score += _clamp(sgap * 4, 0, 6) + _clamp(impulse * 3, 0, 8) + _clamp(breakout * 5, 0, 7)
        score += _clamp(smart, 0, 6)
        if rate > 15:
            score -= min(18, (rate - 15) * 1.2)
        score -= collapse_count * 12
        return round(_clamp(score), 1)

    def _sample(self, track: LabTrack, stage: str, now: float, price: float, rate: float, score: float) -> SampleProgress:
        sample = track.samples.get(stage)
        if sample is None:
            sid = f'{track.day}:{track.venue.value}:{track.code}:{stage}'
            sample = SampleProgress(sid, stage, now, price, rate, score, price, price, rate, rate)
            track.samples[stage] = sample
        return sample

    def _evaluate(self, candidate: Candidate, venue: Venue, active: bool, now: float) -> dict[str, Any] | None:
        lane = candidate.venue_state[venue]
        metrics = dict(lane.metrics)
        fresh = bool(active and self.state.restore_done and metrics.get('fresh') and not lane.resync_required and
                     not lane.continuity_reason and lane.last_tick_at and now - lane.last_tick_at <= SETTINGS.display_fresh_ms / 1000)
        if not fresh or lane.last_price <= 0:
            return None
        track = self._track(candidate, venue)
        new_tick = bool(lane.last_recv_seq and lane.last_recv_seq != track.last_seq)
        prev_rate = track.last_rate
        prev_price = track.last_price
        prev_observed_at = track.last_observed_at
        price = _f(lane.last_price)
        rate = _f(lane.last_rate)
        if new_tick:
            if prev_price > 0 and price < prev_price:
                track.lower_streak += 1
            else:
                track.lower_streak = 0
            track.last_seq = lane.last_recv_seq
            track.last_observed_at = now
        if price > track.high_price:
            track.high_price = price
            track.high_at = now
        track.low_price = min(track.low_price or price, price)
        if rate > track.high_rate:
            track.high_rate = rate
            track.high_at = now
        track.peak_buy_pressure = max(track.peak_buy_pressure, _f(metrics.get('buy_pressure'), 50.0))
        track.peak_accel = max(track.peak_accel, _f(metrics.get('volume_accel'), 1.0))
        track.protection_line = protection_line(track.protection_line, track.high_rate)

        if rate >= 29.5:
            if not track.limit_touch_at:
                track.limit_touch_at = now
            if track.unlock_started_at:
                if now - track.unlock_started_at <= 10:
                    track.relock_count += 1
                track.unlock_started_at = 0.0
                track.limit_touch_at = now
            if now - track.limit_touch_at >= 3:
                track.limit_stable = True
        elif new_tick and prev_rate >= 29.5 and track.limit_touch_at:
            track.unlock_count += 1
            track.unlock_started_at = now
            track.limit_stable = False

        drawdown = max(0.0, track.high_rate - rate)
        bp = _f(metrics.get('buy_pressure'), 50.0)
        strength = _f(metrics.get('execution_strength'), 100.0)
        accel = _f(metrics.get('volume_accel'), 1.0)
        sgap = _f(metrics.get('session_vwap_gap'))
        collapse_reasons: list[str] = []
        if drawdown >= 2.0:
            collapse_reasons.append('고점대비 2%p 이상 하락')
        if metrics.get('buy_pressure') is not None and (bp < 50 or (track.peak_buy_pressure - bp >= 15 and bp < 55)):
            collapse_reasons.append('매수압력 급락')
        if metrics.get('execution_strength') is not None and strength < 100:
            collapse_reasons.append('체결강도 100 하회')
        if bool(metrics.get('volume_accel_ready')) and metrics.get('volume_accel') is not None and (accel < .8 or (track.peak_accel >= 1.5 and accel <= track.peak_accel * .5)):
            collapse_reasons.append('거래량 가속도 붕괴')
        if metrics.get('session_vwap_gap') is not None and sgap < 0:
            collapse_reasons.append('세션 VWAP 이탈')
        if track.high_rate >= 3 and now - track.high_at >= 60 and drawdown >= 1:
            collapse_reasons.append('60초 고점회복 실패')
        if track.lower_streak >= 3:
            collapse_reasons.append('연속 저점 하락')
        if track.unlock_count >= 3:
            collapse_reasons.append('상한가 이탈 3회 이상')
        emergency_pressure = metrics.get('buy_pressure') is not None and bp < 55
        emergency_vwap = metrics.get('session_vwap_gap') is not None and sgap < 0
        emergency = bool(new_tick and prev_observed_at and now - prev_observed_at <= 10 and prev_rate - rate >= 1.5 and (emergency_pressure or emergency_vwap))
        if emergency:
            collapse_reasons.append('10초 급락·수급약화')

        if track.protection_line > 0 and rate < track.protection_line:
            if not track.below_started_at:
                track.below_started_at = now
            if new_tick:
                track.below_count += 1
        else:
            track.below_started_at = 0.0
            track.below_count = 0
        action = ''
        if track.protection_line > 0 and rate <= track.protection_line + .5:
            action = 'READY'
        if track.below_started_at and (track.below_count >= 3 or now - track.below_started_at >= 3):
            action = 'TAKE_PROFIT_50'
        if track.below_started_at and (rate <= track.protection_line - .7 or now - track.below_started_at >= 10):
            action = 'EXIT'
        if len(collapse_reasons) >= 2:
            action = 'EXIT'

        stage = self._base_stage(rate, metrics)
        selection_status = 'QUALIFIED' if stage else 'EXCLUDED'
        target_stage = stage
        selection_reasons: list[str] = []
        missing_metrics: list[str] = []
        failed_conditions: list[str] = []
        if track.unlock_started_at and rate < 29.5:
            stage = 'UNLOCK_WATCH'
            target_stage = stage
            selection_status = 'QUALIFIED'
        elif rate >= 29.5 and track.relock_count and prev_rate < 29.5:
            stage = 'RELOCK'
            target_stage = stage
            selection_status = 'QUALIFIED'
        elif track.limit_stable and rate >= 29.5:
            stage = 'LIMIT_STABLE'
            target_stage = stage
            selection_status = 'QUALIFIED'
        if len(collapse_reasons) >= 2:
            stage = 'COLLAPSE_RISK'
            target_stage = stage
            selection_status = 'QUALIFIED'
        if action == 'TAKE_PROFIT_50':
            stage = 'TAKE_PROFIT'
            target_stage = stage
            selection_status = 'QUALIFIED'
        elif action == 'EXIT':
            stage = 'EXIT' if emergency or track.below_started_at else 'COLLAPSE_RISK'
            target_stage = stage
            selection_status = 'QUALIFIED'
        if not stage:
            assessment = selection_assessment(rate, metrics)
            selection_status = assessment['status']
            target_stage = assessment['target_stage']
            selection_reasons = assessment['reasons']
            missing_metrics = assessment['missing']
            failed_conditions = assessment['failed']
            if selection_status == 'EXCLUDED' or not target_stage:
                track.last_price = price
                track.last_rate = rate
                return None
            # Keep stage as the closest frozen target for ranking/context, but do
            # not promote the track, create alerts or create VERIFY samples.
            stage = target_stage
        elif not selection_reasons:
            selection_reasons = ['단계 조건 충족']

        score = self._lab_score(rate, metrics, len(collapse_reasons))
        if selection_status == 'QUALIFIED' and stage != track.stage:
            track.stage = stage
            track.stage_since = now
            track.alert_seq += 1
            sample = self._sample(track, stage, now, price, rate, score)
            event_id = f'{sample.sample_id}:{track.alert_seq}:{stage}'
            self.pending_events[event_id] = {
                'event_id': event_id,
                'sample_id': sample.sample_id,
                'event_time': now,
                'stage': stage,
                'price': price,
                'change_rate': rate,
                'payload': {'action': action, 'collapse_reasons': collapse_reasons},
            }
        row = {
            'code': candidate.code,
            'name': candidate.name or candidate.code,
            'venue': venue.value,
            'category': instrument_category(candidate.name, candidate.metrics),
            'coverage_lane': 'ROTATION_VERIFY' if candidate.code in self.state.exploration_codes else 'CORE',
            'official_buy_eligible': candidate.code not in self.state.exploration_codes and selection_status == 'QUALIFIED',
            'selection_status': selection_status,
            'selection_reasons': selection_reasons,
            'missing_metrics': missing_metrics,
            'failed_conditions': failed_conditions,
            'target_stage': target_stage,
            'price': price,
            'change_rate': round(rate, 3),
            'stage': stage,
            'stage_since': track.stage_since if selection_status == 'QUALIFIED' else 0.0,
            'alert_seq': track.alert_seq,
            'lab_score': score,
            'volume_accel': round(_f(metrics.get('volume_accel'), 1.0), 3),
            'volume_accel_ready': bool(metrics.get('volume_accel_ready')),
            'buy_pressure': round(bp, 2),
            'execution_strength': round(strength, 1),
            'turnover_60s': round(_f(metrics.get('turnover_60s'))),
            'impulse_60s': round(_f(metrics.get('impulse_60s')), 3),
            'session_vwap_gap': round(sgap, 3),
            'high_rate': round(track.high_rate, 3),
            'drawdown_from_high': round(drawdown, 3),
            'protection_line': track.protection_line or None,
            'action': action or ('WAIT_DATA' if selection_status == 'DATA_WAIT' else 'WATCH' if selection_status == 'CONDITION_MISS' else ''),
            'collapse_reasons': collapse_reasons,
            'limit_touch': bool(track.limit_touch_at),
            'limit_stable': track.limit_stable,
            'unlock_count': track.unlock_count,
            'relock_count': track.relock_count,
            'last_tick_at': lane.last_tick_at,
            'updated_at': now,
            'probability_pct': None,
            'probability_status': '표본부족',
        }
        for sample in track.samples.values():
            sample.observe(price, rate, stage, action, track.limit_stable)
            record = sample.public(track, row)
            self.pending_samples[record['sample_id']] = record
        track.last_price = price
        track.last_rate = rate
        return row

    async def _flush(self) -> None:
        samples = list(self.pending_samples.values())
        events = list(self.pending_events.values())
        self.pending_samples.clear()
        self.pending_events.clear()
        if not samples and not events:
            return
        try:
            await asyncio.to_thread(self.store.upsert_batch, samples, events)
        except Exception as exc:
            for row in samples:
                self.pending_samples[row['sample_id']] = row
            for row in events:
                self.pending_events[row['event_id']] = row
            self.state.telemetry['max_profit_store_error_count'] += 1
            self.state.ws_status['max_profit_store_error'] = str(exc)[:160]

    async def flush_pending(self) -> None:
        await self._flush()

    async def run(self) -> None:
        await asyncio.to_thread(self.store.ensure)
        last_flush = 0.0
        last_stats = 0.0
        while True:
            now = time.time()
            day = trade_day()
            if day != self.current_day:
                await self._flush()
                self.current_day = day
                self.tracks.clear()
            sess = sessions()
            active = bool(sess.get('active'))
            with self.state.lock:
                codes = sorted(set(self.state.hot_codes) | set(self.state.pinned_codes) | set(self.state.followup_codes) | set(self.state.exploration_codes))
                candidates = [self.state.candidates[c] for c in codes if c in self.state.candidates]
            rows: list[dict[str, Any]] = []
            if active and self.state.restore_done:
                for candidate in candidates:
                    choices = []
                    for venue, venue_active in ((Venue.KRX, bool(sess.get('krx'))), (Venue.NXT, bool(sess.get('nxt')))):
                        if venue_active:
                            row = self._evaluate(candidate, venue, True, now)
                            if row:
                                choices.append(row)
                    if choices:
                        rows.append(max(choices, key=lambda x: (
                            SELECTION_STATUS_RANK.get(x.get('selection_status'), 0),
                            STAGE_RANK.get(x['stage'], 0), x['lab_score'], x['last_tick_at'],
                        )))
                rows.sort(key=lambda x: (
                    SELECTION_STATUS_RANK.get(x.get('selection_status'), 0),
                    STAGE_RANK.get(x['stage'], 0), x['lab_score'], x['change_rate'], x['last_tick_at'],
                ), reverse=True)
                self.last_rows = rows[:10]
            elif self.last_rows:
                rows = [{**row, 'frozen': True} for row in self.last_rows]

            if now - last_flush >= 2:
                await self._flush()
                last_flush = now
            if now - last_stats >= 30:
                try:
                    await asyncio.to_thread(self.store.sync_horizons, self.state)
                    self.stats, self.events = await asyncio.gather(
                        asyncio.to_thread(self.store.statistics),
                        asyncio.to_thread(self.store.recent_events, 30),
                    )
                except Exception as exc:
                    self.state.telemetry['max_profit_stats_error_count'] += 1
                    self.state.ws_status['max_profit_stats_error'] = str(exc)[:160]
                last_stats = now
            stat_map = {x['stage']: x for x in self.stats}
            for row in rows:
                if row.get('selection_status') == 'QUALIFIED':
                    stat = stat_map.get(row['stage']) or {}
                    row['probability_pct'] = stat.get('probability_pct')
                    row['probability_status'] = stat.get('sample_status') or '표본부족'
                else:
                    row['probability_pct'] = None
                    row['probability_status'] = '판정대기' if row.get('selection_status') == 'DATA_WAIT' else '조건미달'
            groups = {key: [] for key in ('COMMON', 'PREFERRED', 'SPAC', 'MANAGED')}
            for row in rows:
                groups.setdefault(row['category'], []).append(row)
            for key in groups:
                groups[key] = groups[key][:10]
            self.generation += 1
            snap = self._empty_snapshot('LIVE' if active and self.state.restore_done else 'FROZEN')
            snap.update({
                'generated_at': now,
                'generation': self.generation,
                'feed_state': self.state.feed_state.value,
                'connection_state': self.state.ws_status.get('connection_state') or 'FROZEN',
                'rows': rows[:10],
                'groups': groups,
                'statistics': self.stats,
                'events': self.events,
            })
            encoded = json.dumps(snap, ensure_ascii=False, separators=(',', ':'))
            with self.lock:
                self.snapshot = snap
                self.snapshot_json = encoded
            await asyncio.sleep(SETTINGS.max_profit_scan_ms / 1000)
