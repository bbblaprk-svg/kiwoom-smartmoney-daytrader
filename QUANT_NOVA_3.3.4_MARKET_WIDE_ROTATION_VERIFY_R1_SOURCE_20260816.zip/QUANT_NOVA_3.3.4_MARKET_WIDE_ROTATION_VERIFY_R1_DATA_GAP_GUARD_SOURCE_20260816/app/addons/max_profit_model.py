from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from app.domain import Venue

PROBABILITY_MIN_SAMPLES = 300
PROBABILITY_MIN_SUCCESSES = 30
PROTECTION_STEPS = (
    (3.0, 0.5, 2.0),
    (5.0, 2.0, 2.5),
    (8.0, 4.0, 3.0),
    (10.0, 7.0, 3.0),
    (15.0, 11.0, 4.0),
    (20.0, 16.0, 4.0),
    (25.0, 20.0, 5.0),
    (30.0, 25.0, 5.0),
    (35.0, 29.0, 6.0),
)
STAGE_RANK = {
    'MICRO_FLOW': 10,
    'PRE_IGNITION': 20,
    'IGNITION': 30,
    'BUY_3': 40,
    'CHASE_BLOCK': 45,
    'NO_ADD': 50,
    'LIMIT_GUARD': 60,
    'LIMIT_STABLE': 70,
    'UNLOCK_WATCH': 75,
    'RELOCK': 80,
    'COLLAPSE_RISK': 90,
    'TAKE_PROFIT': 95,
    'EXIT': 100,
}


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def instrument_category(name: str, metrics: dict[str, Any] | None = None) -> str:
    """Separate non-common instruments without creating another broker request."""
    metrics = metrics or {}
    if bool(metrics.get('managed_stock')):
        return 'MANAGED'
    upper = str(name or '').upper().replace(' ', '')
    if '스팩' in upper or 'SPAC' in upper:
        return 'SPAC'
    if upper.endswith(('우', '우B', '우C', '1우', '2우B', '3우C')):
        return 'PREFERRED'
    return 'COMMON'


def protection_line(previous: float, high_rate: float) -> float:
    """Intraday ratchet: once raised, the protection line never moves down."""
    line = max(0.0, _f(previous))
    selected = None
    for trigger, floor, giveback in PROTECTION_STEPS:
        if high_rate >= trigger:
            selected = (floor, giveback)
    if selected:
        floor, giveback = selected
        line = max(line, floor, high_rate - giveback)
    return round(line, 3)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total <= 0:
        return 0.0, 0.0
    p = successes / total
    den = 1 + z * z / total
    centre = (p + z * z / (2 * total)) / den
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / den
    return max(0.0, centre - half), min(1.0, centre + half)


def selection_assessment(rate: float, metrics: dict[str, Any]) -> dict[str, Any]:
    """VERIFY-only near-candidate classification without threshold relaxation.

    DATA_WAIT is allowed only for one unavailable required observation while all
    available conditions already pass. CONDITION_MISS must remain inside a
    narrow soft band and have no more than two issues. Official BUY logic never
    calls this helper.
    """
    if not 0.0 <= rate < 15.0:
        return {'status': 'EXCLUDED', 'target_stage': '', 'reasons': [], 'missing': [], 'failed': []}

    if rate >= 10.0:
        target = 'BUY_3'; accel_min = 1.7; bp_min = 60.0; strength_min = 120.0; turn_min = 300_000_000.0; impulse_min = None
    elif rate >= 7.0:
        target = 'IGNITION'; accel_min = 1.7; bp_min = 60.0; strength_min = 120.0; turn_min = 200_000_000.0; impulse_min = .35
    elif rate >= 3.0:
        target = 'PRE_IGNITION'; accel_min = 1.5; bp_min = 58.0; strength_min = 115.0; turn_min = 100_000_000.0; impulse_min = None
    else:
        target = 'MICRO_FLOW'; accel_min = 1.3; bp_min = 55.0; strength_min = 108.0; turn_min = 50_000_000.0; impulse_min = None

    missing: list[str] = []
    failed: list[str] = []
    hard_miss = False

    if not bool(metrics.get('volume_accel_ready')):
        missing.append('거래량 기준선 축적 중')
    elif metrics.get('volume_accel') is None:
        missing.append('거래가속 데이터 대기')
    else:
        value = _f(metrics.get('volume_accel'))
        if value < accel_min:
            failed.append(f'거래가속 {value:.2f}x < {accel_min:.2f}x')
            hard_miss = hard_miss or value < max(1.0, accel_min - .25)

    checks = (
        ('buy_pressure', '매수압력', bp_min, bp_min - 4.0, lambda v: f'{v:.0f}% < {bp_min:.0f}%'),
        ('execution_strength', '체결강도', strength_min, strength_min - 10.0, lambda v: f'{v:.0f} < {strength_min:.0f}'),
        ('turnover_60s', '60초 거래대금', turn_min, turn_min * .60, lambda v: f'{v/100_000_000:.1f}억 < {turn_min/100_000_000:.1f}억'),
        ('session_vwap_gap', '세션 VWAP', 0.0, -.30, lambda v: f'{v:.2f}% < 0.00%'),
    )
    for key, label, threshold, soft_floor, formatter in checks:
        raw = metrics.get(key)
        if raw is None:
            missing.append(f'{label} 데이터 대기')
            continue
        value = _f(raw)
        if value < threshold:
            failed.append(f'{label} {formatter(value)}')
            hard_miss = hard_miss or value < soft_floor

    if impulse_min is not None:
        raw = metrics.get('impulse_60s')
        if raw is None:
            missing.append('60초 가격선행 데이터 대기')
        else:
            value = _f(raw)
            if value < impulse_min:
                failed.append(f'60초 가격선행 {value:.2f}% < {impulse_min:.2f}%')
                hard_miss = hard_miss or value < impulse_min - .20

    issues = len(missing) + len(failed)
    if not missing and not failed:
        status = 'QUALIFIED'
    elif len(missing) == 1 and not failed:
        status = 'DATA_WAIT'
    elif issues <= 2 and not hard_miss:
        status = 'CONDITION_MISS'
    else:
        status = 'EXCLUDED'
    return {
        'status': status,
        'target_stage': target,
        'reasons': (missing + failed)[:4],
        'missing': missing[:4],
        'failed': failed[:4],
    }


@dataclass(slots=True)
class SampleProgress:
    sample_id: str
    entry_stage: str
    entry_time: float
    entry_price: float
    entry_rate: float
    entry_score: float
    high_price: float
    low_price: float
    high_rate: float
    low_rate: float
    hit_10: bool = False
    hit_20: bool = False
    limit_touch: bool = False
    limit_stable: bool = False
    collapse: bool = False
    protector_take_profit: bool = False
    protector_exit: bool = False

    def observe(self, price: float, rate: float, stage: str, action: str, stable: bool) -> None:
        if price > 0:
            self.high_price = max(self.high_price, price)
            self.low_price = min(self.low_price or price, price)
        self.high_rate = max(self.high_rate, rate)
        self.low_rate = min(self.low_rate, rate)
        self.hit_10 = self.hit_10 or self.high_rate >= 10.0
        self.hit_20 = self.hit_20 or self.high_rate >= 20.0
        self.limit_touch = self.limit_touch or self.high_rate >= 29.5
        self.limit_stable = self.limit_stable or stable or stage == 'LIMIT_STABLE'
        self.collapse = self.collapse or stage == 'COLLAPSE_RISK'
        self.protector_take_profit = self.protector_take_profit or action == 'TAKE_PROFIT_50'
        self.protector_exit = self.protector_exit or action == 'EXIT'

    def public(self, track: 'LabTrack', row: dict[str, Any]) -> dict[str, Any]:
        mfe = (self.high_price / self.entry_price - 1) * 100 if self.entry_price > 0 else None
        mae = (self.low_price / self.entry_price - 1) * 100 if self.entry_price > 0 else None
        return {
            'sample_id': self.sample_id,
            'sample_day': track.day,
            'code': track.code,
            'name': track.name,
            'venue': track.venue.value,
            'entry_stage': self.entry_stage,
            'entry_time': self.entry_time,
            'entry_price': self.entry_price,
            'entry_rate': self.entry_rate,
            'entry_score': self.entry_score,
            'last_price': row['price'],
            'last_rate': row['change_rate'],
            'high_price': self.high_price,
            'low_price': self.low_price,
            'high_rate': self.high_rate,
            'low_rate': self.low_rate,
            'mfe': round(mfe, 4) if mfe is not None else None,
            'mae': round(mae, 4) if mae is not None else None,
            'hit_10': self.hit_10,
            'hit_20': self.hit_20,
            'limit_touch': self.limit_touch,
            'limit_stable': self.limit_stable,
            'unlock_count': track.unlock_count,
            'relock_count': track.relock_count,
            'collapse': self.collapse,
            'protector_take_profit': self.protector_take_profit,
            'protector_exit': self.protector_exit,
            'last_stage': row['stage'],
            'protection_line': row['protection_line'],
            'updated_at': row['updated_at'],
            'payload': {
                'lab_score': row['lab_score'],
                'collapse_reasons': row['collapse_reasons'],
                'action': row['action'],
                'volume_accel': row['volume_accel'],
                'buy_pressure': row['buy_pressure'],
                'execution_strength': row['execution_strength'],
            },
        }


@dataclass(slots=True)
class LabTrack:
    day: str
    code: str
    name: str
    venue: Venue
    stage: str = ''
    stage_since: float = 0.0
    alert_seq: int = 0
    last_seq: int = 0
    last_price: float = 0.0
    last_rate: float = 0.0
    last_observed_at: float = 0.0
    high_price: float = 0.0
    low_price: float = 0.0
    high_rate: float = -100.0
    high_at: float = 0.0
    peak_buy_pressure: float = 0.0
    peak_accel: float = 0.0
    protection_line: float = 0.0
    below_started_at: float = 0.0
    below_count: int = 0
    limit_touch_at: float = 0.0
    limit_stable: bool = False
    unlock_started_at: float = 0.0
    unlock_count: int = 0
    relock_count: int = 0
    lower_streak: int = 0
    samples: dict[str, SampleProgress] = field(default_factory=dict)

