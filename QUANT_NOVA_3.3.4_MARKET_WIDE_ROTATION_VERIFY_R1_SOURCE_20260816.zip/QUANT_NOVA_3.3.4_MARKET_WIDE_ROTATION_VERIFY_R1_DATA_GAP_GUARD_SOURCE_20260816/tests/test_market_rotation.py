from __future__ import annotations

import asyncio
import hashlib
import time
import unittest
from pathlib import Path
from unittest.mock import Mock

from app.broker.discovery import RANK_SPECS
from app.broker.market_rotation import MarketRotation
from app.broker.websocket import KiwoomWebSocket
from app.domain import Venue
from app.runtime.state import RuntimeState
from app.signal.coordinator import SignalCoordinator
from app.signal.metrics import ScoreDecision


ROOT = Path(__file__).resolve().parents[1]


class _NoJournal:
    def __init__(self):
        self.commits = 0

    def commit(self, *_args, **_kwargs):
        self.commits += 1
        raise AssertionError('exploration must never reach official WAL')


class MarketRotationTests(unittest.TestCase):
    @staticmethod
    def _rows(count: int = 40, at: float = 999.0):
        state = RuntimeState()
        rows = []
        for index in range(count):
            candidate = state.candidate(f'{index:06d}', f'종목{index}', trade_day='20260816')
            candidate.source_hits['volume_surge'] = at
            candidate.rest_base = index
            rows.append(candidate)
        return state, rows

    def test_rotation_is_bounded_and_load_sheds_before_core(self):
        _state, rows = self._rows()
        rotation = MarketRotation()
        first = rotation.select(rows, set(), set(), rotation.target_for_mode('NORMAL'), '20260816', 1000)
        second = rotation.select(rows, first.selected, set(), rotation.target_for_mode('NORMAL'), '20260816', 1100)
        high = rotation.select(rows, second.selected, set(), rotation.target_for_mode('HIGH_LOAD'), '20260816', 1101)
        critical = rotation.select(rows, high.selected, set(), rotation.target_for_mode('CRITICAL'), '20260816', 1102)
        self.assertEqual([rotation.target_for_mode(x) for x in ('NORMAL', 'BUSY', 'HIGH_LOAD', 'CRITICAL')], [8, 4, 2, 0])
        self.assertEqual(len(first.selected), 8)
        self.assertEqual(second.rotated, 2)
        self.assertEqual(len(second.selected), 8)
        self.assertEqual(len(high.selected), 2)
        self.assertFalse(critical.selected)

    def test_ws_ceiling_is_unchanged_and_exploration_gets_trade_only(self):
        state = RuntimeState()
        state.hot_codes = {f'{index:06d}' for index in range(50)}
        state.exploration_codes = {f'{index:06d}' for index in range(100, 108)}
        ws = KiwoomWebSocket(state, None, None)
        _sessions, trade, program, orderbook = ws._targets()
        self.assertEqual(len(trade), 58)
        self.assertLessEqual(len(trade), 60)
        self.assertTrue(state.exploration_codes.issubset(set(trade)))
        self.assertFalse(state.exploration_codes.intersection(program))
        self.assertFalse(state.exploration_codes.intersection(orderbook))
        state.load_mode = 'CRITICAL'
        _sessions, shed_trade, shed_program, shed_orderbook = ws._targets()
        self.assertEqual(len(shed_trade), 50)
        self.assertFalse(state.exploration_codes.intersection(shed_trade))
        self.assertEqual(program, shed_program)
        self.assertEqual(orderbook, shed_orderbook)

    def test_exploration_metrics_cannot_mutate_official_buy_or_wal(self):
        state = RuntimeState()
        candidate = state.candidate('123456', '순환검증', trade_day='20260816')
        state.exploration_codes.add(candidate.code)
        state.restore_done = True
        lane = candidate.venue_state[Venue.KRX]
        lane.score = 11.0
        lane.stage = 'SEED'
        before = (lane.score, lane.stage, lane.entry.state, candidate.valid_repeat_count)
        journal = _NoJournal()
        coordinator = SignalCoordinator(state, journal)
        coordinator.metrics.score = Mock(return_value=ScoreDecision(99.0, 100.0, 'IGNITION', ['검증'], {
            'fresh': True, 'volume_accel': 3.0, 'volume_accel_ready': True,
            'buy_pressure': 80.0, 'execution_strength': 180.0, 'turnover_60s': 500_000_000,
            'session_vwap_gap': 2.0,
        }))
        asyncio.run(coordinator.score_one(candidate.code, Venue.KRX))
        after = (lane.score, lane.stage, lane.entry.state, candidate.valid_repeat_count)
        self.assertEqual(before, after)
        self.assertEqual(journal.commits, 0)
        self.assertNotIn(candidate.code, state.pinned_codes)
        self.assertTrue(lane.metrics['exploration_verify_only'])
        self.assertEqual(lane.metrics['exploration_candidate_stage'], 'IGNITION')

    def test_promotion_requires_local_live_warming_without_rest_flag(self):
        state, rows = self._rows(1, time.time())
        candidate = rows[0]
        state.exploration_codes.add(candidate.code)
        state.prepare_exploration({candidate.code})
        state.exploration_codes.clear()
        state.hot_codes.add(candidate.code)
        state.promote_exploration({candidate.code})
        for lane in candidate.venue_state.values():
            self.assertEqual(lane.continuity_reason, 'EXPLORATION_PROMOTION_WARMING')
            self.assertFalse(lane.resync_required)
            self.assertEqual(lane.metrics['resync_snapshot_source'], 'ROTATION_LOCAL_WARMING')
            self.assertFalse(lane.metrics['fresh'])

    def test_rotation_marker_blocks_queued_official_score_after_removal(self):
        state, rows = self._rows(1, time.time())
        candidate = rows[0]
        state.exploration_codes.add(candidate.code)
        state.prepare_exploration({candidate.code})
        state.exploration_codes.clear()
        self.assertTrue(state.is_exploration_only(candidate.code))
        state.promote_exploration({candidate.code})
        self.assertFalse(state.is_exploration_only(candidate.code))

    def test_expansion_reuses_existing_rank_calls_and_freezes_critical_files(self):
        self.assertEqual(len(RANK_SPECS), 7)
        rotation_source = (ROOT / 'app/broker/market_rotation.py').read_text(encoding='utf-8')
        discovery_source = (ROOT / 'app/broker/discovery.py').read_text(encoding='utf-8')
        lab_source = (ROOT / 'app/addons/max_profit_lab.py').read_text(encoding='utf-8')
        self.assertNotIn('REST.post', rotation_source)
        self.assertIn('official_protected', discovery_source)
        self.assertIn('self.state.exploration_codes', lab_source)
        self.assertEqual(hashlib.sha256((ROOT / 'app/signal/policy.py').read_bytes()).hexdigest(), '18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a')
        self.assertEqual(hashlib.sha256((ROOT / 'ops/http_guard_v2.py').read_bytes()).hexdigest(), 'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b')


if __name__ == '__main__':
    unittest.main()
