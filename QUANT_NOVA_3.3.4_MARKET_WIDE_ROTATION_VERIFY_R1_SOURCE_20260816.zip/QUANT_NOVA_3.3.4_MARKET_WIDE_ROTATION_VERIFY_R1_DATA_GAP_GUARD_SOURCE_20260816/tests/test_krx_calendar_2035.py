from __future__ import annotations
import json, unittest
from datetime import date
from pathlib import Path
from app.runtime.clock import CALENDAR_VERSION, calendar_info, is_trading_date, next_trading_day

class KRXCalendar2035Test(unittest.TestCase):
    def test_explicit_coverage_and_counts(self):
        root=Path(__file__).resolve().parents[1]
        j=json.loads((root/'config/krx_holidays.json').read_text(encoding='utf-8'))
        self.assertEqual(j['coverage']['from'],'20260101')
        self.assertEqual(j['coverage']['to'],'20351231')
        self.assertEqual(set(j['open_days']),{str(y) for y in range(2026,2036)})
        for y,rows in j['open_days'].items():
            self.assertGreaterEqual(len(rows),240,(y,len(rows)))
            self.assertEqual(len(rows),len(set(rows)),y)
        self.assertIn('2035',CALENDAR_VERSION)

    def test_known_and_rule_derived_closures(self):
        closed=[
            date(2026,8,17), # 광복절 대체공휴일
            date(2027,5,3),  # 노동절 대체공휴일 (2026 law)
            date(2028,4,12), # current-law regular National Assembly election
            date(2030,3,27), # current-law regular presidential election
            date(2030,6,12), # local election shifted because 6/6 is adjacent to initial 6/5 date
            date(2032,4,14),
            date(2034,5,31),
            date(2035,3,28),
            date(2035,12,31),
        ]
        for d in closed:
            with self.subTest(d=d):self.assertFalse(is_trading_date(d))
        self.assertTrue(is_trading_date(date(2027,5,4)))
        self.assertEqual(next_trading_day('20260814'),'20260818')

    def test_calendar_info_marks_coverage(self):
        info=calendar_info(date(2035,6,4))
        self.assertTrue(info['covered'])
        self.assertTrue(info['is_trading_date'])

if __name__=='__main__':unittest.main()
