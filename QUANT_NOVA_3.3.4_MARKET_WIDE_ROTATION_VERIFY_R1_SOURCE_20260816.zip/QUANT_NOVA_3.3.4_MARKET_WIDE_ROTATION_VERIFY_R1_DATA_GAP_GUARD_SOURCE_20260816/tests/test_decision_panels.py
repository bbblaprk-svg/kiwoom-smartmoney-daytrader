import time, unittest
from unittest.mock import patch
from app.domain import Venue, Origin
from app.runtime.state import RuntimeState
from app.addons.decision_panels import DecisionPanelEngine, _entry_plan, _accel_label, _largecap_row, _pre_row, _signal_windows


def seeded_state(ref=None):
    st=RuntimeState();c=st.candidate('005930','삼성전자',Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
    now=ref or time.time();v.last_price=100000;v.last_rate=2.0;v.last_tick_at=now-1
    v.score=85;v.confidence=72
    v.metrics.update({'fresh':True,'buy_pressure':62,'volume_accel':1.6,'volume_accel_ready':True,'session_vwap':99500,'session_vwap_gap':.5,'micro_vwap_gap':.3,'smart_money_realtime_proxy_score':4,'smart_money_realtime_proxy_surge':True})
    c.current_venue=Venue.NXT;c.refresh_aggregate()
    return st,c,v


class DecisionPanelsTest(unittest.TestCase):
    def test_entry_plan_order(self):
        p=_entry_plan(100000,{'session_vwap':99500,'session_vwap_gap':.50})
        self.assertLessEqual(p['entry_low'],p['entry_high']);self.assertLess(p['stop'],p['entry_low']);self.assertGreater(p['t1'],p['entry_high']);self.assertGreater(p['t2'],p['t1'])

    def test_accel_labels(self):
        self.assertEqual(_accel_label(2,3),'↑↑');self.assertEqual(_accel_label(1,1),'↑');self.assertEqual(_accel_label(0,2),'↓');self.assertEqual(_accel_label(0,0),'→')

    def test_build_is_read_only(self):
        st,c,v=seeded_state();before=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));j=DecisionPanelEngine(st,0).build();after=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));self.assertEqual(before,after);self.assertTrue(j['contracts']['official_buy_logic_changed'] is False);self.assertEqual(j['contracts']['new_broker_rest_calls'],0);self.assertEqual(j['contracts']['new_ws_subscriptions'],0)

    def test_close_window_counts_are_relative_to_close_reference(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-2400)
        n10,n30,last=_signal_windows(c,ref)
        self.assertEqual((n10,n30),(1,2));self.assertEqual(last,ref-120)

    def test_closed_rows_keep_actionable_close_decision(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref);v.last_tick_at=ref-20;v.metrics['fresh']=False
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        lr=_largecap_row(c,ref+600,False,{'005930':'삼성전자'},reference_at=ref)
        pr=_pre_row(c,ref+600,False,reference_at=ref)
        self.assertIn(lr['decision'],('NOW','WAIT','AVOID'));self.assertNotEqual(lr['decision'],'CLOSED');self.assertEqual(lr['decision_mode'],'CLOSE');self.assertGreater(lr['score'],39)
        if lr['decision'] in ('NOW','WAIT'):
            self.assertIsNotNone(lr['entry_low']);self.assertIsNotNone(lr['chase_limit']);self.assertIsNotNone(lr['stop'])
        self.assertIn(pr['state'],('CONFIRM','PRE','WATCH'));self.assertNotEqual(pr['state'],'CLOSED');self.assertEqual(pr['window_mode'],'CLOSE');self.assertEqual((pr['signal_10m'],pr['signal_30m']),(1,2))

    def test_engine_freezes_last_live_snapshot_on_session_close(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        eng=DecisionPanelEngine(st,0)
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref):
            live=eng.build()
        with patch('app.addons.decision_panels.sessions',return_value={'active':False}), patch('app.addons.decision_panels.time.time',return_value=ref+10):
            closed=eng.build()
        self.assertEqual(closed['freeze_source'],'LAST_LIVE');self.assertFalse(closed['market_active'])
        self.assertEqual(closed['largecap'][0]['score'],live['largecap'][0]['score']);self.assertEqual(closed['largecap'][0]['decision_mode'],'CLOSE')
        self.assertEqual(closed['preignition'][0]['signal_10m'],live['preignition'][0]['signal_10m']);self.assertEqual(closed['preignition'][0]['signal_30m'],live['preignition'][0]['signal_30m']);self.assertEqual(closed['preignition'][0]['window_mode'],'CLOSE')

    def test_mobile_panel_headers_allocate_layout_height(self):
        from pathlib import Path
        root=Path(__file__).resolve().parents[1]
        css=(root/'static/decision-panels.css').read_text(encoding='utf-8')
        bridge=(root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
        self.assertIn('.decision-panel h2{height:auto;min-height:34px',css)
        self.assertIn('#opening_bridge_panel h2{height:auto;min-height:34px',bridge)

if __name__=='__main__':unittest.main()
