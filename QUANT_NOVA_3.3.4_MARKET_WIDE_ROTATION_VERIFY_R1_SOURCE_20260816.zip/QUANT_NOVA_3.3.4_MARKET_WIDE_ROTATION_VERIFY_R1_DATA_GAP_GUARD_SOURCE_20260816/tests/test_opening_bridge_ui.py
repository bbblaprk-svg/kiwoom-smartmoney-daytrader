from pathlib import Path
import unittest


class OpeningBridgeUiTest(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]

    def test_ui_version_is_r421(self):
        idx=(self.root/'static/index.html').read_text(encoding='utf-8')
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        self.assertIn('R4.2.1 SHADOW', idx)
        self.assertIn('R4.2.1 SHADOW · BUY HANDOFF OFF', js)
        self.assertNotIn('R4.2 SHADOW · BUY HANDOFF OFF', js)

    def test_mobile_badge_is_compact_and_full_state_is_retained(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        css=(self.root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
        for state,label in [('PRIOR_CLOSE_FROZEN','FROZEN'),('PREMARKET_RECHECK','RECHECK'),('OPENING_HANDOFF','HANDOFF'),('SHAKEOUT_WATCH','SHAKEOUT'),('REVERSAL_EARLY','REVERSAL'),('BUY_READY_SHADOW','BUY READY')]:
            self.assertIn(f"{state}:'{label}'", js)
        self.assertIn('title=\"${fullState}\"', js)
        self.assertIn('.ob-origin{display:none}', css)
        self.assertIn('78px', css)

    def test_asset_cache_bust_changed(self):
        idx=(self.root/'static/index.html').read_text(encoding='utf-8')
        self.assertIn('opening-bridge-shadow.css?v=332-r421u1', idx)
        self.assertIn('opening-bridge-shadow.js?v=332-r421u1', idx)

if __name__=='__main__':
    unittest.main()
