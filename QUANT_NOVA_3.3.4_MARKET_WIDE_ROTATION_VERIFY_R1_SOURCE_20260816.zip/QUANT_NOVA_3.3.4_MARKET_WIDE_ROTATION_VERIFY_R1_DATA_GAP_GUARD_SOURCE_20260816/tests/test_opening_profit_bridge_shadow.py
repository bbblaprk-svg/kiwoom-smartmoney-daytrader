from __future__ import annotations

import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from app.addons.opening_profit_bridge_shadow import OpeningProfitBridgeShadow
from app.domain import Origin, Venue
from app.runtime.clock import KST
from app.runtime.state import RuntimeState


class OpeningProfitBridgeShadowTest(unittest.TestCase):
    def setUp(self):
        self.state = RuntimeState()
        self.engine = OpeningProfitBridgeShadow(self.state)
        self.tmp = tempfile.TemporaryDirectory()
        self.engine.path = Path(self.tmp.name) / 'bridge.json'
        self.engine.store = self.engine._blank()
        self.engine._store.last_persist_hash = ''
        self.engine._store.last_persist_at = 0

    def tearDown(self):
        self.tmp.cleanup()

    def dt(self, y, m, d, h, mi, s=0):
        return datetime(y, m, d, h, mi, s, tzinfo=KST)

    def make_candidate(self, code='005930', venue=Venue.NXT, price=100000, rate=2.0, score=70, repeat=4, fresh_at=None):
        c = self.state.candidate(code, 'TEST', Origin.TODAY_NEW, '20260814')
        c.score = score
        c.priority_score = score
        c.valid_repeat_count = repeat
        c.live_track_pin = True
        c.lifecycle_state = 'TODAY_NEW'
        c.current_venue = venue
        v = c.venue_state[venue]
        v.last_price = price
        v.last_rate = rate
        v.last_tick_at = fresh_at or self.dt(2026,8,14,19,45).timestamp()
        v.metrics.update({'fresh': True, 'buy_pressure': 65, 'micro_vwap_gap': .2, 'session_vwap_gap': .2, 'volume_accel': 1.6, 'smart_money_realtime_proxy_score': 3})
        return c

    def test_phase_boundaries(self):
        cases = [
            ((2026,8,14,15,29,29),'NORMAL_INTRADAY'),
            ((2026,8,14,15,29,30),'KRX_CLOSE_CAPTURE'),
            ((2026,8,14,19,29,59),'NORMAL_INTRADAY'),
            ((2026,8,14,19,30,0),'CLOSE_TRACK'),
            ((2026,8,14,19,59,59),'CLOSE_TRACK'),
            ((2026,8,14,20,0,0),'PRIOR_CLOSE_FROZEN'),
            ((2026,8,15,12,0,0),'PRIOR_CLOSE_FROZEN'),
            ((2026,8,17,12,0,0),'PRIOR_CLOSE_FROZEN'),
            ((2026,8,18,7,59,59),'PRIOR_CLOSE_FROZEN'),
            ((2026,8,18,8,0,0),'PREMARKET_RECHECK'),
            ((2026,8,18,8,50,0),'OPENING_HANDOFF'),
            ((2026,8,18,9,0,0),'SHAKEOUT_WATCH'),
            ((2026,8,18,9,29,59),'SHAKEOUT_WATCH'),
            ((2026,8,18,9,30,0),'REVERSAL_EARLY'),
            ((2026,8,18,10,0,0),'NORMAL_INTRADAY'),
        ]
        for args, expected in cases:
            with self.subTest(args=args):
                self.assertEqual(self.engine.phase_at(self.dt(*args)), expected)

    def test_close_to_frozen_persists_candidate(self):
        self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp())
        a = self.engine.build(self.dt(2026,8,14,19,45))
        self.assertTrue(a['ok'])
        self.assertTrue(a['rows'])
        cid = a['rows'][0]['candidate_id']
        b = self.engine.build(self.dt(2026,8,14,20,5))
        self.assertTrue(b['rows'])
        self.assertEqual(b['rows'][0]['candidate_id'], cid)
        self.assertEqual(b['rows'][0]['shadow_state'], 'PRIOR_CLOSE_FROZEN')
        self.assertTrue(self.engine.path.exists())

    def test_premarket_never_substitutes_krx_for_nxt(self):
        c = self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp())
        self.engine.build(self.dt(2026,8,14,19,45))
        # Only KRX is fresh on the next morning; NXT stays stale. PRE state must HOLD.
        kv = c.venue_state[Venue.KRX]
        kv.last_price = 101000
        kv.last_tick_at = self.dt(2026,8,18,8,10).timestamp()
        kv.metrics['fresh'] = True
        out = self.engine.build(self.dt(2026,8,18,8,10))
        self.assertTrue(out['rows'])
        self.assertEqual(out['rows'][0]['premarket_state'], 'HOLD')
        self.assertNotEqual(out['rows'][0]['venue'], 'KRX')

    def test_premarket_nxt_survive(self):
        c = self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp())
        self.engine.build(self.dt(2026,8,14,19,45))
        nv = c.venue_state[Venue.NXT]
        nv.last_price = 101000
        nv.last_tick_at = self.dt(2026,8,18,8,10).timestamp()
        nv.metrics.update({'fresh': True, 'buy_pressure': 60, 'volume_accel': 1.3})
        out = self.engine.build(self.dt(2026,8,18,8,10))
        self.assertEqual(out['rows'][0]['premarket_state'], 'SURVIVE')
        self.assertEqual(out['rows'][0]['venue'], 'NXT')

    def test_shadow_never_mutates_official_candidate_lifecycle_or_entry(self):
        c = self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp())
        before_life = c.lifecycle_state
        before_origin = c.origin
        before_entry = c.entry_state
        self.engine.build(self.dt(2026,8,14,19,45))
        nv = c.venue_state[Venue.NXT]
        nv.last_tick_at = self.dt(2026,8,18,8,10).timestamp()
        self.engine.build(self.dt(2026,8,18,8,10))
        self.assertEqual(c.lifecycle_state, before_life)
        self.assertEqual(c.origin, before_origin)
        self.assertEqual(c.entry_state, before_entry)
        self.assertFalse(self.engine.buy_handoff_enabled)

    def test_restart_restore_keeps_candidate(self):
        self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp())
        first = self.engine.build(self.dt(2026,8,14,19,45))
        self.engine._persist(force=True)
        e2 = OpeningProfitBridgeShadow(self.state)
        e2.path = self.engine.path
        e2.store = e2._load()
        second = e2.build(self.dt(2026,8,14,20,5))
        self.assertEqual(first['rows'][0]['candidate_id'], second['rows'][0]['candidate_id'])
        self.assertEqual(second['rows'][0]['shadow_state'], 'PRIOR_CLOSE_FROZEN')

    def test_prior_and_today_compete_without_origin_priority(self):
        prior = self.make_candidate('005930', fresh_at=self.dt(2026,8,14,19,45).timestamp(), score=65)
        self.engine.build(self.dt(2026,8,14,19,45))
        # Monday open: prior is live but TODAY candidate is stronger.
        prior.venue_state[Venue.KRX].last_price = 100500
        prior.venue_state[Venue.KRX].last_rate = 0.5
        prior.venue_state[Venue.KRX].last_tick_at = self.dt(2026,8,18,9,5).timestamp()
        prior.venue_state[Venue.KRX].metrics.update({'fresh':True,'buy_pressure':55,'micro_vwap_gap':0,'volume_accel':1.1})
        today = self.state.candidate('000660','TODAY',Origin.TODAY_NEW,'20260818')
        today.score = 90; today.priority_score = 90; today.current_venue = Venue.KRX; today.live_track_pin = True
        tv = today.venue_state[Venue.KRX]; tv.last_price=200000; tv.last_rate=1.0; tv.last_tick_at=self.dt(2026,8,18,9,5).timestamp(); tv.metrics['fresh']=True
        out = self.engine.build(self.dt(2026,8,18,9,5))
        self.assertEqual(out['rows'][0]['code'], '000660')
        self.assertEqual(out['rows'][0]['badge'], 'TODAY')

    def test_stale_tick_cannot_create_buy_ready_shadow(self):
        c = self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp(), score=80)
        self.engine.build(self.dt(2026,8,14,19,45))
        # Stale by hours on Monday; even DIRECT_ARM must not promote through shadow.
        c.venue_state[Venue.KRX].entry.state = 'DIRECT_ARM'
        out = self.engine.build(self.dt(2026,8,18,9,20))
        self.assertTrue(out['rows'])
        self.assertNotEqual(out['rows'][0]['shadow_state'], 'BUY_READY_SHADOW')

    def test_nxt_main_not_used_before_090030(self):
        c = self.make_candidate(fresh_at=self.dt(2026,8,14,19,45).timestamp(), score=80)
        self.engine.build(self.dt(2026,8,14,19,45))
        nv = c.venue_state[Venue.NXT]
        nv.last_price = 99000
        nv.last_tick_at = self.dt(2026,8,18,9,0,15).timestamp()
        nv.metrics.update({'fresh':True,'buy_pressure':30,'micro_vwap_gap':-1,'volume_accel':1.0})
        out = self.engine.build(self.dt(2026,8,18,9,0,15))
        self.assertTrue(out['rows'])
        self.assertFalse(out['rows'][0]['shakeout_seen'])

    def test_krx_and_nxt_close_sources_are_preserved_in_store(self):
        c = self.state.candidate('005930','TEST',Origin.TODAY_NEW,'20260814')
        c.score=75;c.priority_score=75;c.valid_repeat_count=5;c.live_track_pin=True
        kv=c.venue_state[Venue.KRX];kv.last_price=100000;kv.last_rate=1;kv.last_tick_at=self.dt(2026,8,14,15,30).timestamp();kv.metrics['fresh']=True
        nv=c.venue_state[Venue.NXT];nv.last_price=101000;nv.last_rate=2;nv.last_tick_at=self.dt(2026,8,14,19,45).timestamp();nv.metrics['fresh']=True
        c.current_venue=Venue.NXT
        self.engine.build(self.dt(2026,8,14,15,30))
        self.engine.build(self.dt(2026,8,14,19,45))
        sources={r['source'] for r in self.engine.store['candidates'].values() if r.get('code')=='005930'}
        self.assertIn('KRX_CLOSE_CANDIDATE',sources)
        self.assertIn('NXT_AFTER_CLOSE_CANDIDATE',sources)

    def test_post_close_first_boot_reconstructs_once_without_official_mutation(self):
        c=self.make_candidate(fresh_at=self.dt(2026,8,14,19,58).timestamp(),score=66,repeat=6)
        before=(c.origin,c.lifecycle_state,c.entry_state,c.score,c.priority_score)
        out=self.engine.build(self.dt(2026,8,14,22,15))
        self.assertTrue(out['rows'])
        self.assertEqual(out['rows'][0]['source'],'BOOTSTRAP_CLOSE_RECONSTRUCTED')
        self.assertEqual(out['rows'][0]['effective_day'],'20260818')
        self.assertGreater(out['bootstrap_count'],0)
        self.assertFalse(out['buy_handoff_enabled'])
        ids1=set(self.engine.store['candidates'])
        out2=self.engine.build(self.dt(2026,8,14,22,16))
        ids2=set(self.engine.store['candidates'])
        self.assertEqual(ids1,ids2)
        self.assertEqual(before,(c.origin,c.lifecycle_state,c.entry_state,c.score,c.priority_score))

    def test_bootstrap_rejects_prior_day_retained_tick(self):
        self.make_candidate(fresh_at=self.dt(2026,8,13,19,58).timestamp(),score=80,repeat=9)
        out=self.engine.build(self.dt(2026,8,14,22,15))
        self.assertEqual(out['rows'],[])
        self.assertEqual(out['bootstrap_count'],0)

    def test_calendar_drives_effective_day_over_substitute_holiday(self):
        c=self.make_candidate(fresh_at=self.dt(2026,8,14,19,58).timestamp(),score=70,repeat=4)
        out=self.engine.build(self.dt(2026,8,14,22,15))
        self.assertEqual(out['rows'][0]['effective_day'],'20260818')
        self.assertTrue(out['calendar']['covered'])
        self.assertIn('2035',out['calendar']['version'])


if __name__ == '__main__':
    unittest.main()
