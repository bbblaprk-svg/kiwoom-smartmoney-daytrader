# MARKET-WIDE ROTATION VERIFY invariants

1. The pool comes only from the existing seven ranking specifications across KOSPI/KOSDAQ. Rotation itself performs no network call.
2. PINNED, FOLLOWUP and HOT are ordered before exploration and can consume all capacity.
3. Exploration slots are NORMAL 8, BUSY 4, HIGH_LOAD 2 and CRITICAL 0. The WebSocket target builder reapplies this limit every second.
4. Typical normal capacity is 50 core + 8 exploration = 58 TRADE codes. The existing working target 60, hard budget 90 codes and 180 dual-venue items are not increased.
5. Exploration uses only the already-supported TRADE (`0B`) subscription. PROGRAM (`0u`) and ORDERBOOK (`0D`) remain core-only.
6. Two rows rotate only after 72 seconds of dwell; promising rows may remain up to 300 seconds; exited rows cool down for 180 seconds.
7. Exploration metrics are VERIFY-only. Tracking reservation, official score/stage, ENTRY_V18, BUY, formal WAL, pinning and main boards are unreachable from this branch.
8. The exploration marker survives removal. Promotion explicitly clears the window and requires at least 30 seconds of new local TRADE flow before official eligibility.
9. Candidate memory remains capped at 1,200; lab rows at 10; stored research samples at 1,000 by default.
10. Coverage means ranked-pool rotation, not simultaneous full-market streaming. The UI and documentation must preserve that distinction.
11. Telemetry exposes target, selected, registered, pool, headroom, rotations, additions, removals and blocked official evaluations.
12. A failed rotation acceptance, code-budget, swap, liveness, or active-session trade-progress gate triggers exact-container rollback.
