#!/usr/bin/env bash
set -Eeuo pipefail

APP="quant-nova"
R421_IMAGE="quant-nova:3.3.2-r421-shadow"
R41_IMAGE="quant-nova:3.3.2-r41-standby"
SRC_DIR="${1:-$(pwd)}"
R41_ZIP="$SRC_DIR/rollback/QUANT_NOVA_3.3.2_LARGECAP_PREIGNITION_R4.1_BASELINE_SOURCE_20260814.zip"
R41_SHA="25aa65878d4f497564bace3ce17a16b774454cb7a2fe9948a8a5796a4c5e4895"
BACKUP="quant-nova-pre-r421-$(date +%Y%m%d-%H%M%S)"
TMP="/tmp/nova-r421-cutover-$$"
mkdir -p "$TMP"

say(){ echo; echo "===== $* ====="; }
inspect_json(){ docker exec "$1" python - "$2" <<'PY'
import json,sys,urllib.request
p=sys.argv[1]
try:
  with urllib.request.urlopen('http://127.0.0.1:8000'+p,timeout=5) as r: print(r.read().decode())
except Exception as e: print(json.dumps({'ok':False,'error':repr(e)}));sys.exit(2)
PY
}
wait_named_health(){
  local name="$1" i h
  for i in $(seq 1 36); do
    h="$(docker inspect "$name" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' 2>/dev/null || true)"
    [ "$h" = "healthy" ] && return 0
    sleep 5
  done
  return 1
}

say "0. PRECHECK CURRENT NOVA"
test -f "$SRC_DIR/Dockerfile"; test -f "$R41_ZIP"
test "$(sha256sum "$R41_ZIP"|awk '{print $1}')" = "$R41_SHA"
docker inspect "$APP" >/dev/null
inspect_json "$APP" /api/live-dashboard > "$TMP/baseline-dashboard.json" || true
inspect_json "$APP" /api/livez > "$TMP/baseline-livez.json" || true

docker inspect "$APP" --format '{{range .Config.Env}}{{println .}}{{end}}' > "$TMP/env"
NETWORK="$(docker inspect "$APP" --format '{{.HostConfig.NetworkMode}}')"
RESTART="$(docker inspect "$APP" --format '{{.HostConfig.RestartPolicy.Name}}')"; [ -n "$RESTART" ] || RESTART="unless-stopped"
MOUNT_ARGS=()
while IFS='|' read -r TYPE SOURCE DEST RW NAME; do
  TYPE="$(echo "$TYPE"|xargs)"; SOURCE="$(echo "$SOURCE"|xargs)"; DEST="$(echo "$DEST"|xargs)"; RW="$(echo "$RW"|xargs)"; NAME="$(echo "$NAME"|xargs)"
  [ -z "$TYPE" ] && continue; MODE=""; [ "$RW" = "true" ] || MODE=":ro"
  if [ "$TYPE" = "bind" ]; then MOUNT_ARGS+=( -v "${SOURCE}:${DEST}${MODE}" ); elif [ "$TYPE" = "volume" ]; then MOUNT_ARGS+=( -v "${NAME}:${DEST}${MODE}" ); fi
done < <(docker inspect "$APP" --format '{{range .Mounts}}{{println .Type "|" .Source "|" .Destination "|" .RW "|" .Name}}{{end}}')

say "1. BUILD R4.1 STANDBY"
rm -rf "$TMP/r41"; mkdir -p "$TMP/r41"; python3 -m zipfile -e "$R41_ZIP" "$TMP/r41"
R41_SRC="$(find "$TMP/r41" -mindepth 1 -maxdepth 1 -type d | head -1)"; test -f "$R41_SRC/Dockerfile"
docker build --no-cache -t "$R41_IMAGE" "$R41_SRC"

say "2. BUILD R4.2.1 SHADOW"
docker build --no-cache -t "$R421_IMAGE" "$SRC_DIR"

run_like_baseline(){
  local image="$1"
  docker run -d --name "$APP" --restart "$RESTART" --network "$NETWORK" --env-file "$TMP/env" "${MOUNT_ARGS[@]}" "$image"
}
restore_original(){
  docker rm -f "$APP" >/dev/null 2>&1 || true
  docker rename "$BACKUP" "$APP" >/dev/null 2>&1 || return 1
  docker start "$APP" >/dev/null
  wait_named_health "$APP"
}
rollback(){
  trap - ERR
  say "ROLLBACK LEVEL 1 -> EXACT PRE-CUTOVER NOVA"
  if restore_original; then
    echo "ROLLBACK_TARGET=PRE_CUTOVER_ORIGINAL HEALTH=healthy"
    exit 42
  fi
  say "ROLLBACK LEVEL 2 -> R4.1 STANDBY"
  docker rm -f "$APP" >/dev/null 2>&1 || true
  if run_like_baseline "$R41_IMAGE" && wait_named_health "$APP"; then
    echo "ROLLBACK_TARGET=R4.1_STANDBY HEALTH=healthy"
    exit 43
  fi
  echo "ROLLBACK_FATAL=MANUAL_INTERVENTION_REQUIRED"; exit 44
}
trap rollback ERR

say "3. CUTOVER QUANT-NOVA ONLY"
docker stop "$APP"; docker rename "$APP" "$BACKUP"; run_like_baseline "$R421_IMAGE"; wait_named_health "$APP"

say "4. R4.2.1 INTERNAL ACCEPTANCE"
docker exec "$APP" python /app/scripts/r421_shadow_acceptance.py | tee "$TMP/r421-acceptance.json"

say "5. BASELINE REGRESSION GUARDS"
python3 - "$TMP/baseline-dashboard.json" "$TMP/r421-acceptance.json" <<'PY'
import json,sys
try:b=json.load(open(sys.argv[1]))
except Exception:b={}
line=open(sys.argv[2]).read().strip().splitlines()[-1];a=json.loads(line)
assert a.get('ok') is True,a
bc=int(b.get('candidate_count') or 0);ac=int(a.get('candidate_count') or 0)
if bc>=20: assert ac>=max(5,int(bc*.40)),('candidate_collapse',bc,ac)
buy0=len((b.get('boards') or {}).get('live_buy') or []);buy1=int(a.get('live_buy_count') or 0)
if buy0>0: assert buy1>0,('official_buy_board_disappeared',buy0,buy1)
assert a.get('buy_handoff_enabled') is False,a
assert '2035' in str(a.get('calendar_version') or ''),a
print('REGRESSION_GUARDS=PASS baseline_candidates=%d after=%d baseline_live_buy=%d after=%d'%(bc,ac,buy0,buy1))
PY

say "6. GUARD READ-ONLY CHECK"
docker exec nova-http-guard python - <<'PY'
import urllib.request
for p in ['/api/livez','/api/readyz','/api/opening-bridge-shadow','/api/decision-panels']:
  with urllib.request.urlopen('http://quant-nova:8000'+p,timeout=5) as r:
    b=r.read();print(p,r.status,len(b));assert r.status==200 and b
PY

say "7. FINAL"
trap - ERR
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'
echo "R421_SHADOW_SUCCESS"
echo "IMAGE=$R421_IMAGE"
echo "PRE_CUTOVER_BACKUP=$BACKUP"
echo "R41_STANDBY_IMAGE=$R41_IMAGE"
echo "GUARD=NOT_TOUCHED"
echo "CADDY=NOT_TOUCHED"
echo "BUY_HANDOFF=OFF"
