#!/usr/bin/env bash
set -Eeuo pipefail
APP="${NOVA_APP_CONTAINER:-quant-nova}"
EXPECTED="NOVA-3.3.4-MARKET-WIDE-ROTATION-VERIFY"
if docker info >/dev/null 2>&1; then DOCKER=(docker)
elif sudo -n docker info >/dev/null 2>&1; then DOCKER=(sudo docker)
else echo "FINAL_AUDIT=FAIL reason=docker_permission"; exit 2
fi
dc(){ "${DOCKER[@]}" "$@"; }
dc inspect "$APP" >/dev/null
ACCEPTANCE="$(mktemp /tmp/nova334-acceptance.XXXXXX)"
ROTATION="$(mktemp /tmp/nova334-rotation.XXXXXX)"
SMOKE="$(mktemp /tmp/nova334-smoke.XXXXXX)"
trap 'rm -f -- "$ACCEPTANCE" "$ROTATION" "$SMOKE"' EXIT
dc exec "$APP" python /app/scripts/max_profit_acceptance.py >"$ACCEPTANCE"
dc exec "$APP" python /app/scripts/market_rotation_acceptance.py >"$ROTATION"
dc exec "$APP" python /app/scripts/runtime_smoke.py --clients 2 --ready-timeout 30 >"$SMOKE"
dc exec "$APP" python - "$EXPECTED" <<'PY'
import json,os,sys,urllib.request
expected=sys.argv[1];token=os.getenv('NOVA_UI_ACCESS_TOKEN','').strip();h={'X-App-Token':token} if token else {}
def get(p):
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8000'+p,headers=h),timeout=8) as r:return json.load(r)
live=get('/api/livez');ready=get('/api/readyz');health=get('/api/realtime-health');lab=get('/api/max-profit-lab')
assert live.get('ok') and live.get('version')==expected
assert ready.get('ok')
assert lab.get('mode')=='VERIFY_ONLY' and len(lab.get('rows') or [])<=10
contract=lab.get('contracts') or {}
assert contract.get('new_broker_rest_calls')==0 and contract.get('new_ws_subscription_types')==0
assert contract.get('ws_registered_code_ceiling_increase')==0 and contract.get('bounded_trade_rotation') is True
assert contract.get('exploration_official_buy_blocked') is True and contract.get('exploration_program_orderbook_added') is False
assert float((health.get('memory') or {}).get('swap_mb') or 0)==0
telemetry=health.get('telemetry') or {};target=int(telemetry.get('exploration_target_slots') or 0);registered=int(telemetry.get('exploration_registered_codes') or 0)
assert target in (0,2,4,8) and registered<=target,(target,registered)
sess=health.get('sessions') or {};ws=health.get('ws') or {}
gate='DEFERRED_NONMATCHING_SESSION'
if sess.get('active'):
 assert ws.get('connected') and ws.get('logged_in') and int(ws.get('registered') or 0)>0,(sess,ws)
 assert ws.get('connection_state') in ('REGISTERING','WARMING','LIVE'),ws
 gate='PASS'
print('FINAL_AUDIT=PASS version=%s main_layout=FROZEN lab=VERIFY_ONLY rows=%d rotation=%d/%d swap=0 trading_day_gate=%s'%(expected,len(lab.get('rows') or []),registered,target,gate))
PY
for name in nova-http-guard caddy nova-caddy; do
  if dc inspect "$name" >/dev/null 2>&1; then echo "PROTECTED_CONTAINER=$name status=PRESENT"; fi
done
