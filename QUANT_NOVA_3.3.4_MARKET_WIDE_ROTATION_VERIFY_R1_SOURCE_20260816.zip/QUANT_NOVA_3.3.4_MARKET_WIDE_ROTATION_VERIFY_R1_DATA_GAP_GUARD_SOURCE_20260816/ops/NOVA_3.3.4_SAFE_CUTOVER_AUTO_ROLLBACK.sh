#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

APP="${NOVA_APP_CONTAINER:-quant-nova}"
EXPECTED_VERSION="NOVA-3.3.4-MARKET-WIDE-ROTATION-VERIFY"
NEW_IMAGE="${1:-${NOVA_NEW_IMAGE:-ghcr.io/bbblaprk-svg/kiwoom-smartmoney-daytrader:latest}}"
BACKUP="${APP}-pre-334-$(date +%Y%m%d-%H%M%S)"
FAILED="${APP}-failed-334-$(date +%Y%m%d-%H%M%S)"
WORK="$(mktemp -d /tmp/nova334-cutover.XXXXXX)"
ENVFILE="$WORK/current.env"
LOG="/tmp/nova334-cutover-$(date +%Y%m%d-%H%M%S).log"
NEW_STARTED=0
OLD_RENAMED=0
OLD_STOPPED=0

if docker info >/dev/null 2>&1; then DOCKER=(docker)
elif sudo -n docker info >/dev/null 2>&1; then DOCKER=(sudo docker)
else echo "FAIL: Docker 권한을 확인할 수 없습니다."; exit 2
fi
dc(){ "${DOCKER[@]}" "$@"; }
say(){ printf '\n===== %s =====\n' "$*" | tee -a "$LOG"; }
cleanup(){ if [ -d "$WORK" ] && [[ "$WORK" == /tmp/nova334-cutover.* ]]; then find "$WORK" -type f -exec chmod 600 {} \; 2>/dev/null || true; rm -rf -- "$WORK"; fi; }
protected_snapshot(){
  for name in nova-http-guard caddy nova-caddy; do
    if dc inspect "$name" >/dev/null 2>&1; then printf '%s=%s\n' "$name" "$(dc inspect "$name" --format '{{.Id}}')"; fi
  done | sort
}
wait_health(){
  local name="$1" i status
  for i in $(seq 1 48); do
    status="$(dc inspect "$name" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
    [ "$status" = "healthy" ] && return 0
    sleep 5
  done
  return 1
}
internal_gate(){
  dc exec "$APP" python - "$EXPECTED_VERSION" <<'PY'
import asyncio,json,os,sys,time,urllib.parse,urllib.request
import websockets
from app.config import effective_ws_code_budget
expected=sys.argv[1]
token=os.getenv('NOVA_UI_ACCESS_TOKEN','').strip()
headers={'X-App-Token':token,'Authorization':'Bearer '+token} if token else {}
def get(path):
    req=urllib.request.Request('http://127.0.0.1:8000'+path,headers=headers)
    with urllib.request.urlopen(req,timeout=8) as r:return json.load(r)
live=get('/api/livez');ready=get('/api/readyz');dash=get('/api/live-dashboard');lab=get('/api/max-profit-lab');health=get('/api/realtime-health')
assert live.get('ok') and live.get('version')==expected,live
assert ready.get('ok') is True,ready
assert int(dash.get('board_slots') or 0)==10,dash.get('board_slots')
assert set((dash.get('boards') or {}).keys())=={'prebuy','opening','live_buy','nxt_early','nxt_management','position_manager'}
assert lab.get('mode')=='VERIFY_ONLY',lab
contract=lab.get('contracts') or {}
assert contract.get('official_buy_logic_changed') is False,contract
assert contract.get('new_broker_rest_calls')==0 and contract.get('new_ws_subscription_types')==0,contract
assert contract.get('ws_registered_code_ceiling_increase')==0,contract
assert contract.get('bounded_trade_rotation') is True and contract.get('exploration_official_buy_blocked') is True,contract
assert contract.get('exploration_program_orderbook_added') is False and contract.get('automatic_orders') is False,contract
assert len(lab.get('rows') or [])<=10
assert float((health.get('memory') or {}).get('swap_mb') or 0)==0,health.get('memory')
assert int((health.get('telemetry') or {}).get('signal_price_mismatch_count') or 0)==0
assert int((health.get('telemetry') or {}).get('wrong_venue_price_count') or 0)==0
telemetry=health.get('telemetry') or {}
target=int(telemetry.get('exploration_target_slots') or 0);registered_exploration=int(telemetry.get('exploration_registered_codes') or 0)
assert target in (0,2,4,8) and registered_exploration<=target,(target,registered_exploration)
assert int((health.get('ws') or {}).get('registered') or 0)<=effective_ws_code_budget(),health.get('ws')
async def ws_gate():
    suffix=('?token='+urllib.parse.quote(token,safe='')) if token else ''
    async with websockets.connect('ws://127.0.0.1:8000/ws/live'+suffix,open_timeout=5,close_timeout=2) as ws:
        msg=json.loads(await asyncio.wait_for(ws.recv(),5));assert msg.get('type') in ('snapshot','delta'),msg
    async with websockets.connect('ws://127.0.0.1:8000/ws/max-profit-lab'+suffix,open_timeout=5,close_timeout=2) as ws:
        msg=json.loads(await asyncio.wait_for(ws.recv(),5));assert msg.get('mode')=='VERIFY_ONLY',msg
asyncio.run(ws_gate())
sess=health.get('sessions') or {};ws=health.get('ws') or {}
if sess.get('active'):
    deadline=time.time()+150
    while time.time()<deadline:
        health=get('/api/realtime-health');ws=health.get('ws') or {}
        if health.get('feed_state')=='LIVE' and ws.get('connected') and ws.get('logged_in') and int(ws.get('registered') or 0)>0 and time.time()-float(ws.get('last_message_at') or 0)<8:break
        time.sleep(3)
    assert health.get('feed_state')=='LIVE',(health.get('feed_state'),ws)
    assert ws.get('connected') and ws.get('logged_in') and int(ws.get('registered') or 0)>0,(sess,ws)
    before=int(health.get('trade_processed') or 0);advanced=False
    for _ in range(10):
        time.sleep(3);later=get('/api/realtime-health')
        if int(later.get('trade_processed') or 0)>before:advanced=True;break
    assert advanced,('NO_ACCEPTED_TRADE_PROGRESS',before)
    trading_gate='PASS'
else:
    assert ws.get('connection_state') in ('FROZEN','PREFLIGHT','CONNECTING','LOGGED_IN','SESSION_GAP','CLOSING','WARMING','LIVE','RECONNECTING'),ws
    trading_gate='DEFERRED_NONMATCHING_SESSION'
print(json.dumps({'ok':True,'version':expected,'main_boards':'FROZEN','max_profit':'VERIFY_ONLY','rotation_target':target,'rotation_registered':registered_exploration,'ws_paths':2,'swap_mb':0,'trading_day_gate':trading_gate},ensure_ascii=False))
PY
}
verify_protected(){
  local before after
  before="$(cat "$WORK/protected.before")";after="$(protected_snapshot)"
  [ "$before" = "$after" ] || { echo "FAIL: Guard/Caddy 컨테이너 식별자가 변경됐습니다." | tee -a "$LOG"; return 1; }
}
rollback(){
  local rc=$?
  trap - ERR INT TERM
  say "AUTO ROLLBACK -> EXACT PRE-CUTOVER CONTAINER"
  if [ "$NEW_STARTED" -eq 1 ] && dc inspect "$APP" >/dev/null 2>&1; then
    dc logs --tail 300 "$APP" >>"$LOG" 2>&1 || true
    dc stop "$APP" >/dev/null 2>&1 || true
    dc rename "$APP" "$FAILED" >/dev/null 2>&1 || true
  fi
  if [ "$OLD_RENAMED" -eq 1 ] && dc inspect "$BACKUP" >/dev/null 2>&1; then
    dc rename "$BACKUP" "$APP"
    dc start "$APP" >/dev/null
    wait_health "$APP" || true
  elif [ "$OLD_STOPPED" -eq 1 ] && dc inspect "$APP" >/dev/null 2>&1; then
    dc start "$APP" >/dev/null 2>&1 || true
    wait_health "$APP" || true
  fi
  verify_protected || true
  cleanup
  echo "RESULT=ROLLED_BACK CURRENT=$APP FAILED=$FAILED LOG=$LOG" | tee -a "$LOG"
  exit "${rc:-1}"
}
trap rollback ERR INT TERM

say "1. PRECHECK AND FREEZE CURRENT CONTAINER"
dc inspect "$APP" >/dev/null
dc inspect "$APP" --format '{{range .Config.Env}}{{println .}}{{end}}' >"$ENVFILE"
chmod 600 "$ENVFILE"
protected_snapshot >"$WORK/protected.before"
mapfile -t NETWORKS < <(dc inspect "$APP" --format '{{range $name, $_ := .NetworkSettings.Networks}}{{println $name}}{{end}}')
[ "${#NETWORKS[@]}" -gt 0 ]
RESTART="$(dc inspect "$APP" --format '{{.HostConfig.RestartPolicy.Name}}')";[ -n "$RESTART" ]||RESTART=unless-stopped
MOUNT_ARGS=()
while IFS='|' read -r TYPE SOURCE DEST RW NAME; do
  TYPE="$(xargs <<<"$TYPE")";SOURCE="$(xargs <<<"$SOURCE")";DEST="$(xargs <<<"$DEST")";RW="$(xargs <<<"$RW")";NAME="$(xargs <<<"$NAME")"
  [ -z "$TYPE" ] && continue;MODE="";[ "$RW" = "true" ]||MODE=":ro"
  if [[ "$DEST" == /app/* && "$DEST" != /app/data && "$DEST" != /app/data/* ]]; then echo "FAIL: 소스 덮어쓰기 마운트 감지 $DEST"; exit 1; fi
  if [ "$TYPE" = bind ]; then MOUNT_ARGS+=( -v "${SOURCE}:${DEST}${MODE}" )
  elif [ "$TYPE" = volume ]; then MOUNT_ARGS+=( -v "${NAME}:${DEST}${MODE}" ); fi
done < <(dc inspect "$APP" --format '{{range .Mounts}}{{println .Type "|" .Source "|" .Destination "|" .RW "|" .Name}}{{end}}')
PORT_ARGS=()
while IFS='|' read -r HOSTIP HOSTPORT CONTAINERPORT; do
  HOSTIP="$(xargs <<<"$HOSTIP")";HOSTPORT="$(xargs <<<"$HOSTPORT")";CONTAINERPORT="$(xargs <<<"$CONTAINERPORT")"
  [ -z "$HOSTPORT" ] && continue
  if [ -n "$HOSTIP" ] && [ "$HOSTIP" != "0.0.0.0" ]; then PORT_ARGS+=( -p "${HOSTIP}:${HOSTPORT}:${CONTAINERPORT}" )
  else PORT_ARGS+=( -p "${HOSTPORT}:${CONTAINERPORT}" ); fi
done < <(dc inspect "$APP" --format '{{range $port, $bindings := .NetworkSettings.Ports}}{{range $bindings}}{{println .HostIp "|" .HostPort "|" $port}}{{end}}{{end}}')

say "2. PULL AND VERIFY IMMUTABLE IMAGE"
dc pull "$NEW_IMAGE" | tee -a "$LOG"
LABEL_VERSION="$(dc image inspect "$NEW_IMAGE" --format '{{index .Config.Labels "org.opencontainers.image.version"}}')"
[ "$LABEL_VERSION" = "$EXPECTED_VERSION" ]

say "3. CUTOVER QUANT-NOVA ONLY"
dc stop "$APP" >/dev/null
OLD_STOPPED=1
dc rename "$APP" "$BACKUP"
OLD_RENAMED=1
dc run -d --name "$APP" --restart "$RESTART" --network "${NETWORKS[0]}" --env-file "$ENVFILE" "${MOUNT_ARGS[@]}" "${PORT_ARGS[@]}" "$NEW_IMAGE" >/dev/null
NEW_STARTED=1
for net in "${NETWORKS[@]:1}"; do dc network connect "$net" "$APP" >/dev/null; done
wait_health "$APP"

say "4. INTERNAL ACCEPTANCE AND LIVE BRIDGE GATES"
dc exec "$APP" python /app/scripts/max_profit_acceptance.py | tee -a "$LOG"
dc exec "$APP" python /app/scripts/market_rotation_acceptance.py | tee -a "$LOG"
dc exec "$APP" python /app/scripts/runtime_smoke.py --clients 2 --ready-timeout 30 | tee -a "$LOG"
internal_gate | tee -a "$LOG"
verify_protected

say "5. SUCCESS"
trap - ERR INT TERM
cleanup
echo "RESULT=SUCCESS VERSION=$EXPECTED_VERSION CURRENT=$APP ROLLBACK_CONTAINER=$BACKUP" | tee -a "$LOG"
echo "GUARD=NOT_TOUCHED CADDY=NOT_TOUCHED BUY=ENTRY_V18_FROZEN" | tee -a "$LOG"
echo "ROTATION=NORMAL8_BUSY4_HIGH2_CRITICAL0 REST_ADDED=0 AUX_FEEDS_ADDED=0" | tee -a "$LOG"
echo "LOG=$LOG"
