#!/usr/bin/env bash
set -Eeuo pipefail

APP="${NOVA_APP_CONTAINER:-quant-nova}"
BACKUP="${1:-}"
if [ -z "$BACKUP" ]; then
  echo "사용법: $0 <SAFE_CUTOVER가 출력한 ROLLBACK_CONTAINER>"
  exit 2
fi
[[ "$BACKUP" == "${APP}-pre-334-"* ]] || { echo "FAIL: 허용되지 않은 백업 이름"; exit 2; }
if docker info >/dev/null 2>&1; then DOCKER=(docker)
elif sudo -n docker info >/dev/null 2>&1; then DOCKER=(sudo docker)
else echo "FAIL: Docker 권한 없음"; exit 2
fi
dc(){ "${DOCKER[@]}" "$@"; }
dc inspect "$APP" >/dev/null
dc inspect "$BACKUP" >/dev/null
FAILED="${APP}-manual-failed-$(date +%Y%m%d-%H%M%S)"
dc stop "$APP" >/dev/null
dc rename "$APP" "$FAILED"
if ! dc rename "$BACKUP" "$APP"; then
  dc rename "$FAILED" "$APP" >/dev/null 2>&1 || true
  dc start "$APP" >/dev/null 2>&1 || true
  echo "RESULT=ROLLBACK_FAILED RESTORED_NEW=$APP"
  exit 1
fi
if ! dc start "$APP" >/dev/null; then
  dc rename "$APP" "$BACKUP" >/dev/null 2>&1 || true
  dc rename "$FAILED" "$APP" >/dev/null 2>&1 || true
  dc start "$APP" >/dev/null 2>&1 || true
  echo "RESULT=ROLLBACK_FAILED RESTORED_NEW=$APP"
  exit 1
fi
for _ in $(seq 1 36); do
  STATUS="$(dc inspect "$APP" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' 2>/dev/null || true)"
  [ "$STATUS" = healthy ] && { echo "RESULT=ROLLBACK_SUCCESS CURRENT=$APP FAILED_NEW=$FAILED GUARD=NOT_TOUCHED CADDY=NOT_TOUCHED"; exit 0; }
  sleep 5
done
echo "RESULT=ROLLBACK_STARTED_BUT_NOT_HEALTHY CURRENT=$APP FAILED_NEW=$FAILED"
exit 1
