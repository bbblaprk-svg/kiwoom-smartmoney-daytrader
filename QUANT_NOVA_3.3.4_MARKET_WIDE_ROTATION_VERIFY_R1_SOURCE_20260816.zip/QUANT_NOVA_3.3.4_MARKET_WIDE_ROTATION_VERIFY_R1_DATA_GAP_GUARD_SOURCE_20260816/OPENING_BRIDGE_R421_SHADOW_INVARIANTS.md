# NOVA R4.2.1 SHADOW invariants

R4.2.1 = R4.2 SHADOW + first-boot close reconstruction + mobile header layout fix + explicit KRX trading calendar through 2035.

## Hard safety contracts
- `BUY_HANDOFF` remains hard-locked OFF in Python.
- No new Kiwoom REST request and no new WebSocket subscription.
- No mutation of official `Candidate.origin`, official lifecycle, ENTRY_V18, formal BUY or signal journal.
- Guard and Caddy are outside this release.
- Opening Bridge errors fail open to the pre-existing Opening board.

## First-boot close reconstruction
- Runs only in `PRIOR_CLOSE_FROZEN` when the shadow store has no candidate for the next effective trading day.
- Uses only already-resident same-trading-day retained ticks between 15:20 and 20:05 KST.
- Source is permanently labelled `BOOTSTRAP_CLOSE_RECONSTRUCTED`.
- It is idempotent and writes only `opening_profit_bridge_shadow.json`.
- No broker call is permitted.

## KRX calendar
- Packaged explicit `open_days` and closures cover 2026-01-01 through 2035-12-31.
- Rules are based on KRX holiday policy and Korean public-holiday law as of 2026-08-14.
- 2027-2035 extraordinary KRX closures, temporary holidays, and future election changes remain inherently announcement-dependent.
- Persistent override path: `<NOVA_DATA_DIR>/krx_calendar_override.json`.
- Override precedence: `force_open > force_closed > packaged explicit calendar`.

## Rollback
`NOVA_R421_SHADOW_SAFE_CUTOVER.sh` rolls back first to the exact pre-cutover running NOVA container. If that fails, it starts the embedded exact R4.1 standby image.
