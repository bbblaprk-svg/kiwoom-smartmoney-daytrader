from __future__ import annotations

import json
import statistics
import time

from app.broker.discovery import RANK_SPECS
from app.broker.market_rotation import MarketRotation
from app.broker.websocket import KiwoomWebSocket
from app.runtime.state import RuntimeState


def main() -> None:
    state = RuntimeState()
    base = time.time()
    rows = []
    for index in range(1200):
        candidate = state.candidate(f'{index:06d}', f'ROTATION{index}', trade_day='20260816')
        candidate.source_hits['volume_surge'] = base
        candidate.rest_base = float(index % 100)
        rows.append(candidate)

    rotation = MarketRotation()
    selected: set[str] = set()
    latencies = []
    sizes = {}
    modes = ('NORMAL', 'NORMAL', 'BUSY', 'NORMAL', 'HIGH_LOAD', 'NORMAL', 'CRITICAL', 'NORMAL')
    now = base
    for cycle in range(320):
        mode = modes[cycle % len(modes)]
        desired = rotation.target_for_mode(mode)
        for candidate in rows:
            candidate.source_hits['volume_surge'] = now
        started = time.perf_counter()
        result = rotation.select(rows, selected, set(), desired, '20260816', now)
        latencies.append((time.perf_counter() - started) * 1000)
        selected = result.selected
        sizes.setdefault(mode, set()).add(len(selected))
        assert len(selected) <= desired
        now += 24

    # Restore the normal target and verify that total TRADE registration remains
    # below the already-configured sixty-code working ceiling.
    for candidate in rows:
        candidate.source_hits['volume_surge'] = now
    normal = rotation.select(rows, selected, set(), rotation.target_for_mode('NORMAL'), '20260816', now)
    state.hot_codes = {f'{index:06d}' for index in range(2000, 2050)}
    state.exploration_codes = set(normal.selected)
    ws = KiwoomWebSocket(state, None, None)
    _sessions, trade, program, orderbook = ws._targets()
    assert len(trade) <= 60
    assert not state.exploration_codes.intersection(program)
    assert not state.exploration_codes.intersection(orderbook)
    state.load_mode = 'CRITICAL'
    _sessions, critical_trade, critical_program, critical_orderbook = ws._targets()
    assert len(critical_trade) == 50
    assert not state.exploration_codes.intersection(critical_trade)
    assert critical_program == program and critical_orderbook == orderbook
    assert len(RANK_SPECS) == 7
    p95 = sorted(latencies)[int(.95 * (len(latencies) - 1))]
    assert p95 < 25.0, p95
    print(json.dumps({
        'ok': True,
        'mode_slots': {mode: rotation.target_for_mode(mode) for mode in ('NORMAL', 'BUSY', 'HIGH_LOAD', 'CRITICAL')},
        'observed_sizes': {mode: sorted(values) for mode, values in sizes.items()},
        'candidate_pool': len(rows),
        'cycles': len(latencies),
        'rotation_p95_ms': round(p95, 3),
        'trade_registered': len(trade),
        'critical_trade_registered': len(critical_trade),
        'critical_exploration_registered': 0,
        'program_exploration': 0,
        'orderbook_exploration': 0,
        'broker_rank_specs_unchanged': len(RANK_SPECS),
        'broker_rest_calls_added': 0,
        'ws_code_ceiling_increase': 0,
        'official_buy_for_exploration': False,
    }, ensure_ascii=False, sort_keys=True))
    print('MARKET_ROTATION_ACCEPTANCE=PASS')


if __name__ == '__main__':
    main()
