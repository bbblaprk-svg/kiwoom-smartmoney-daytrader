from __future__ import annotations
import json, sys, urllib.request
from pathlib import Path

BASE='http://127.0.0.1:8000'

def get(path):
    with urllib.request.urlopen(BASE+path,timeout=5) as r:
        body=r.read();assert r.status==200,(path,r.status);return json.loads(body)

def main():
    live=get('/api/livez');ready=get('/api/readyz');dash=get('/api/live-dashboard');dec=get('/api/decision-panels');bridge=get('/api/opening-bridge-shadow')
    assert live.get('ok') is True,live
    assert ready.get('ok') is True,ready
    assert isinstance(dash.get('boards'),dict),dash.keys()
    assert dec.get('ok') is True,dec
    assert bridge.get('mode')=='SHADOW',bridge
    assert bridge.get('buy_handoff_enabled') is False,bridge
    cal=bridge.get('calendar') or {}
    assert cal.get('covered') in (True,False),cal
    assert '2035' in str(cal.get('version') or ''),cal
    ids=[str(r.get('candidate_id') or '') for r in bridge.get('rows') or [] if r.get('candidate_id')]
    assert len(ids)==len(set(ids)),('duplicate_bridge_ids',ids)
    for r in bridge.get('rows') or []:
        if r.get('badge')=='PRIOR':
            assert r.get('source_day') and r.get('effective_day'),('trade_day_missing',r)
            assert str(r.get('source_day'))<=str(r.get('effective_day')),('trade_day_reverse',r)
        if r.get('shadow_state')=='BUY_READY_SHADOW':
            assert r.get('fresh') is True,('stale_shadow_promotion',r)
        if r.get('source')=='BOOTSTRAP_CLOSE_RECONSTRUCTED':
            assert bridge.get('buy_handoff_enabled') is False,('bootstrap_handoff_violation',r)
    boot=str(bridge.get('bootstrap_source') or '')
    assert boot in ('','BOOTSTRAP_CLOSE_RECONSTRUCTED'),boot
    root=Path('/app')
    css=(root/'static/decision-panels.css').read_text(encoding='utf-8')
    obcss=(root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
    assert '.decision-panel h2{height:auto;min-height:34px' in css
    assert '#opening_bridge_panel h2{height:auto;min-height:34px' in obcss
    print(json.dumps({'ok':True,'version':live.get('version'),'feed_state':live.get('feed_state'),'candidate_count':dash.get('candidate_count',0),'live_buy_count':len((dash.get('boards') or {}).get('live_buy') or []),'bridge_rows':len(bridge.get('rows') or []),'bridge_phase':bridge.get('phase'),'bootstrap_count':int(bridge.get('bootstrap_count') or 0),'calendar_version':cal.get('version'),'buy_handoff_enabled':False},ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps({'ok':False,'error':f'{type(e).__name__}: {e}'},ensure_ascii=False));sys.exit(2)
