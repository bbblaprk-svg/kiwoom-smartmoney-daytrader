from __future__ import annotations
import ast,json,re,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.runtime.state import RuntimeState
from app.signal import policy as p
from app.config import SETTINGS,effective_ws_code_budget,exploration_slots_for_mode

REQUIRED_TELEMETRY={
'dropped_signal_tick_count','dropped_critical_tick_count','dropped_candidate_tick_count','signal_price_mismatch_count','wrong_venue_price_count',
'stale_signal_count','signal_without_live_snapshot_count','duplicate_tick_reject_count','out_of_order_tick_count','stale_tick_reject_count',
'cumulative_rollback_count','journal_fail_closed_count','unrecovered_data_gap_count','ws_messages_per_sec','ws_receive_latency_ms',
'receiver_queue_depth','receiver_queue_oldest_age_ms','signal_queue_depth','signal_queue_oldest_age_ms','ui_clients',
'dispatch_handler_error_count','tracking_capacity_block_count','pinned_ws_overflow','discovery_bootstrap_count','resync_pending_key_count','resync_missing_baseline_key_count','signal_ready_key_count'
}

def frozen_policy_contract():
    j=json.loads((ROOT/'SIGNAL_POLICY_FROZEN.json').read_text())
    got={'pressure_score':p.ENTRY_PRESSURE_SCORE,'hold_sec':p.ENTRY_HOLD_SEC,'pullback_min_pct':p.ENTRY_PULLBACK_MIN,'pullback_max_pct':p.ENTRY_PULLBACK_MAX,'reaccel_sec':p.ENTRY_REACCEL_SEC,'cooldown_sec':p.ENTRY_COOLDOWN_SEC,'max_daily_buy':p.ENTRY_MAX_DAILY,'max_vwap_gap_pct':p.ENTRY_MAX_VWAP_GAP,'max_impulse_60s_pct':p.ENTRY_MAX_IMPULSE,'min_buy_pressure':p.ENTRY_MIN_BUY_PRESSURE,'min_algo_persistence':p.ENTRY_MIN_ALGO_PERSIST}
    for k,v in got.items():assert j[k]==v,(k,j[k],v)
    d=j['direct'];assert (d['score'],d['hold_sec'],d['confirm_sec'],d['buy_pressure'],d['algo_persistence'],d['volume_accel'],d['breakout_pct'],d['impulse_min_pct'],d['impulse_max_pct'],d['vwap_gap_max_pct'])==(p.DIRECT_SCORE,p.DIRECT_HOLD_SEC,p.DIRECT_CONFIRM_SEC,p.DIRECT_MIN_BUY_PRESSURE,p.DIRECT_MIN_ALGO_PERSIST,p.DIRECT_MIN_ACCEL,p.DIRECT_MIN_BREAKOUT,p.DIRECT_MIN_IMPULSE,p.DIRECT_MAX_IMPULSE,p.DIRECT_MAX_VWAP_GAP)
    assert hashlib.sha256((ROOT/'SIGNAL_POLICY_FROZEN.json').read_bytes()).hexdigest()=='7f1688843b83213332c054fc1c6ffba3d69ab48ed8c5518b3d37a8b19c0c8543'
    print('MASTER_ENTRY_V18_FROZEN=PASS')

def telemetry_contract():
    keys=set(RuntimeState().telemetry.keys());missing=REQUIRED_TELEMETRY-keys;assert not missing,missing
    health=(ROOT/'app/runtime/health.py').read_text()
    for needle in ('tick_to_signal_ms','tick_to_ui_ms','signal_queue_ms','receiver_to_state_ms','ui_push_ms','event_loop_lag_p95_ms','memory_growth_mb_sec','receiver_queue_oldest_age_ms'):assert needle in health,needle
    print(f'MASTER_TELEMETRY_CONTRACT=PASS base_keys={len(keys)}')

def architecture_contract():
    required=['app/runtime/window.py','app/runtime/dispatcher.py','app/runtime/integrity.py','app/storage/wal.py','app/storage/performance.py','app/runtime/watchdog.py','app/runtime/display.py','app/runtime/projection.py','ops/http_guard_v2.py','app/signal/coordinator.py','app/signal/policy.py','app/signal/smart_money.py','app/lifecycle/opening.py','app/tracking/top10.py','app/broker/recovery.py']
    for x in required:assert (ROOT/x).exists(),x
    wal=(ROOT/'app/storage/wal.py').read_text();assert 'ONE_WRITER_SQLITE_FULL_PRIORITY' in wal and 'important_history' in wal and '_stall_monitor' in wal and 'synchronous=FULL' in wal
    disp=(ROOT/'app/runtime/dispatcher.py').read_text();assert 'ProtectedTradeQueue' in disp and 'CoalescingLane' in disp and 'critical:bool=False' in disp and 'TRADE_QUEUE_EVICTED_FOR_PROTECTED' in disp
    state=(ROOT/'app/runtime/state.py').read_text();assert 'critical_signal_queue_max' in state and 'dropped_critical_tick_count' in state and 'urgent_dirty' in state
    coord=(ROOT/'app/signal/coordinator.py').read_text();assert 'asyncio.gather' in coord and 'journal.commit' in coord and 'PERSIST_PENDING' in coord and 'OFFICIAL_SIGNAL' in coord and 'WS_TRACKING_CAPACITY' in coord
    recovery=(ROOT/'app/broker/recovery.py').read_text();cfg=(ROOT/'app/config.py').read_text();ingest=(ROOT/'app/runtime/ingest.py').read_text();assert 'REST_BASELINE_ONLY' in recovery and 'resync_required=True' in recovery and 'formal signal' in recovery and '_quote_reference' in recovery and "'sel_fpr_bid'" in recovery and "'buy_fpr_bid'" in recovery;assert "'/api/dostk/mrkcond'" in cfg and "'ka10004'" in cfg;assert 'slow_confirmation_update_count' in ingest and "self.state.mark_dirty(code,venue)" not in ingest.split('def aux',1)[1].split('def dropped',1)[0]
    metrics=(ROOT/'app/signal/metrics.py').read_text();assert 'rvol_intraday' in metrics and "'rvol_ready':False" in metrics and 'resync_required' in metrics and "ov.metrics.get('fresh',False)" in metrics
    clock=(ROOT/'app/runtime/clock.py').read_text();opening=(ROOT/'app/lifecycle/opening.py').read_text();assert "9*3600+30" in clock and "'shakeout':9*3600 <= s < 9*3600+30*60" in clock and "'reversal':9*3600+10*60 <= s < 10*3600" in clock and 'PREMARKET_PREP' in clock;assert 'opening_windows' in opening
    service=(ROOT/'app/service.py').read_text();assert 'resync_missing' in service and 'FeedState.RESYNC' in service and 'FeedState.DEGRADED_TRACK' in service and 'RestRecoveryEngine' in service
    assert 'metric_bundle(now)' in metrics and 'discovery_paused_for_recovery_count' in service and 'discovery_bootstrap_count' in service and "return 'BOOTSTRAP' if not targets else 'PAUSE'" in service
    wal=(ROOT/'app/storage/wal.py').read_text();assert 'self.work_evt.set()' in wal and 'event_log_max_mb' in wal and '_retention_cleanup' in wal
    display=(ROOT/'app/runtime/display.py').read_text();assert 'public_compact' in (ROOT/'app/domain.py').read_text() and 'wire_for' in display and 'ui_wire_delta_bytes' in display
    print('MASTER_RUNTIME_ARCHITECTURE=PASS')

def broker_contract():
    ws=(ROOT/'app/broker/websocket.py').read_text();kw=(ROOT/'app/broker/kiwoom.py').read_text()
    for needle in ("'trnm':'REMOVE'","await self._remove_group(ws,grp)","'refresh':'1'",'critical=abs(p*q)>=50_000_000',"if trade and sess['krx']","if trade and sess['nxt']",'active_subscription_error'):
        assert needle in ws,needle
    for needle in ('expires_dt','_token_expiry_epoch','async def invalidate','r.status_code in (401,403)','await TOKENS.invalidate(token)'):assert needle in kw,needle
    assert SETTINGS.rest_pace_sec>=0.2
    assert SETTINGS.ws_session_item_cap<=200
    assert effective_ws_code_budget()*2<=SETTINGS.ws_session_item_cap
    print(f'MASTER_BROKER_CAPACITY=PASS code_budget={effective_ws_code_budget()} item_cap={SETTINGS.ws_session_item_cap}')

def top10_ui_contract():
    js=(ROOT/'static/nova.js').read_text();css=(ROOT/'static/nova.css').read_text();html=(ROOT/'static/index.html').read_text();api=(ROOT/'app/api/app.py').read_text();display=(ROOT/'app/runtime/display.py').read_text();top10=(ROOT/'app/tracking/top10.py').read_text();guard=(ROOT/'ops/http_guard_v2.py').read_text();sw=(ROOT/'static/sw.js').read_text()
    assert SETTINGS.board_slots==10
    assert js.count('new WebSocket(')==1 and 'NOVA_LIVE_BRIDGE_V2_TOP10' in js and 'applyDelta' in js and 'recoverSnapshot' in js and 'startPoll' not in js
    assert 'setInterval(async()=>{const now=Date.now()' in js # watchdog only, not normal REST polling
    assert 'wire_for(last_gen)' in api and 'send_text(payload)' in api and '/ws/live' in api
    assert 'Top10Registry' in display and "'bridge':'LIVE_BRIDGE_V2_TOP10_DELTA'" in display and 'board_slots' in display
    assert 'TOP10_REENTER' in top10 and 'top10_stats_by_board' in top10
    assert 'tabular-nums' in css and 'v=3320' in html
    assert 'registration.unregister' not in sw and "const CACHE='nova-shell-3340'" in sw and 'respondWith' in sw
    assert 'def websocket_proxy(self):' in guard and 'no-store' in guard
    for forbidden in ('TOP5','top5_','NOVA_LIVE_BRIDGE_V1'):
        assert forbidden not in js,forbidden
    print('MASTER_UI_DELTA_TOP10=PASS')

def no_async_storage_io():
    bad=[]
    for path in (ROOT/'app').rglob('*.py'):
        src=path.read_text();tree=ast.parse(src);lines=src.splitlines()
        for fn in [n for n in ast.walk(tree) if isinstance(n,ast.AsyncFunctionDef)]:
            for n in ast.walk(fn):
                if not isinstance(n,ast.Call):continue
                name=''
                if isinstance(n.func,ast.Name):name=n.func.id
                elif isinstance(n.func,ast.Attribute):
                    a=[];x=n.func
                    while isinstance(x,ast.Attribute):a.append(x.attr);x=x.value
                    if isinstance(x,ast.Name):a.append(x.id)
                    name='.'.join(reversed(a))
                if name.split('.')[-1] in {'open','read_text','write_text','fsync','connect'}:
                    line=lines[n.lineno-1] if n.lineno<=len(lines) else ''
                    if 'to_thread' in line or (path.name=='health.py' and '/proc/' in src) or name.endswith('websockets.connect'):continue
                    bad.append((str(path.relative_to(ROOT)),fn.name,n.lineno,name,line.strip()))
    assert not bad,bad
    print('MASTER_ASYNC_STORAGE_BLOCKING_ZERO=PASS')

def build_contract():
    df=(ROOT/'Dockerfile').read_text();assert df.startswith('FROM python:3.12-slim-bookworm')
    for x in ('COPY Dockerfile /app/Dockerfile','COPY SOURCE_MANIFEST.sha256 /app/SOURCE_MANIFEST.sha256','COPY SIGNAL_POLICY_FROZEN.json','MARKET_WIDE_ROTATION_INVARIANTS.md','COPY app','COPY spec','COPY ops /app/ops','image_contract.py /app','master_audit.py','market_rotation_acceptance.py','validate.py --quick','HEALTHCHECK','io.quantnova.deploy_model="GHCR_PULL_ONLY"','org.opencontainers.image.version="NOVA-3.3.4-MARKET-WIDE-ROTATION-VERIFY"'):assert x in df,x
    assert 'FROM quant-nova' not in df and 'docker commit' not in df
    spec=ROOT/'spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt';assert spec.exists()
    assert not list((ROOT/'spec').glob('*SMART_MONEY_50M개정*'))
    print('MASTER_CLEAN_BUILD_CONTRACT=PASS')

def source_truth_contract():
    cfg=(ROOT/'app/config.py').read_text();policy=(ROOT/'app/signal/policy.py').read_text();coord=(ROOT/'app/signal/coordinator.py').read_text();spec=(ROOT/'spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt').read_text()
    assert SETTINGS.version=='NOVA-3.3.4-MARKET-WIDE-ROTATION-VERIFY'
    assert (ROOT/'app/__init__.py').read_text(encoding='utf-8').strip()=="__version__ = '3.3.4-market-wide-rotation-verify'"
    assert 'ENTRY_V18_TRUTH_GUARD_MAX_PROFIT' in policy and 'SETTINGS.version' in policy and 'SETTINGS.version' in coord
    for needle in ('Top 10','Critical Event Tick','PERSIST_PENDING','MarketPhaseResolver','DEGRADED_TRACK','Hard Invariant'):
        assert needle in spec,needle
    # Runtime/source documents must not retain old TOP5 implementation vocabulary.
    for path in list((ROOT/'app').rglob('*.py'))+list((ROOT/'static').rglob('*'))+[ROOT/'ARCHITECTURE.md',ROOT/'SPEC_TRACEABILITY.md']:
        if not path.is_file():continue
        t=path.read_text(errors='ignore');assert 'TOP5' not in t and 'top5_' not in t,(path,'legacy TOP5')
    print('MASTER_SINGLE_SOURCE_TRUTH=PASS')

def max_profit_shadow_contract():
    import hashlib,re
    policy=ROOT/'app/signal/policy.py';guard=ROOT/'ops/http_guard_v2.py'
    assert hashlib.sha256(policy.read_bytes()).hexdigest()=='18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a'
    assert hashlib.sha256(guard.read_bytes()).hexdigest()=='c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b'
    html=(ROOT/'static/index.html').read_text();main=re.search(r'<main>.*?</main>',html,re.S);assert main
    assert hashlib.sha256(main.group(0).encode()).hexdigest()=='3f3341522fa0854d212579da30b2139d010bb774cde3f1bf20d9fb8dc297c397'
    lab=(ROOT/'app/addons/max_profit_lab.py').read_text();model=(ROOT/'app/addons/max_profit_model.py').read_text();store=(ROOT/'app/storage/max_profit_verify.py').read_text();api=(ROOT/'app/api/app.py').read_text()
    for needle in ('official_buy_logic_changed','new_broker_rest_calls','new_ws_subscription_types','ws_registered_code_ceiling_increase','bounded_trade_rotation','exploration_official_buy_blocked','orderbook_dependency','qualified_first_ranking','single_missing_metric_rescue','data_wait_official_buy_blocked','condition_miss_official_buy_blocked'):
        assert needle in lab,needle
    assert 'PROBABILITY_MIN_SAMPLES = 300' in model and 'PROBABILITY_MIN_SUCCESSES = 30' in model
    assert 'max_profit_verify.sqlite3' in store and '/ws/max-profit-lab' in api and '/max-profit-lab' in api
    assert 'connection_window' in (ROOT/'app/broker/websocket.py').read_text() and 'SESSION_GAP' in (ROOT/'app/broker/websocket.py').read_text()
    assert '_ws_after_restore' not in (ROOT/'app/service.py').read_text()
    print('MAX_PROFIT_VERIFY_SHADOW=PASS')

def market_rotation_contract():
    rotation=(ROOT/'app/broker/market_rotation.py').read_text();discovery=(ROOT/'app/broker/discovery.py').read_text();ws=(ROOT/'app/broker/websocket.py').read_text();coord=(ROOT/'app/signal/coordinator.py').read_text();recovery=(ROOT/'app/broker/recovery.py').read_text();lab=(ROOT/'app/addons/max_profit_lab.py').read_text()
    assert 'REST.post' not in rotation and 'MarketRotation' in discovery
    assert 'exploration_codes' in ws and 'exploration_slots_for_mode' in ws and 'program=core_ordered' in ws and 'orderbook=core_ordered' in ws
    assert 'exploration_only:return' in coord and 'exploration_official_block_count' in coord
    assert 'exploration_codes' not in recovery # rotating rows must never create extra REST resync calls
    assert 'self.state.exploration_codes' in lab
    assert [exploration_slots_for_mode(mode) for mode in ('NORMAL','BUSY','HIGH_LOAD','CRITICAL')]==[8,4,2,0]
    assert SETTINGS.ws_trade_per_venue==60 and effective_ws_code_budget()==90
    assert "candidate.metrics.get('exploration_verify_only')" in (ROOT/'app/runtime/state.py').read_text()
    print('MARKET_WIDE_ROTATION_VERIFY=PASS slots=8/4/2/0 normal_working=60 hard_budget=90 rest_added=0 official_buy=BLOCKED')

def main():
    frozen_policy_contract();telemetry_contract();architecture_contract();broker_contract();top10_ui_contract();no_async_storage_io();build_contract();source_truth_contract();max_profit_shadow_contract();market_rotation_contract();print('MASTER_SPEC_AUDIT=PASS')
if __name__=='__main__':main()
