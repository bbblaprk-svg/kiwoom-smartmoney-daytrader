# KRX trading calendar 2026-2035

`krx_holidays.json` contains explicit trading days (`open_days`) and weekday closures for every year from 2026 through 2035.

The base rule follows KRX: weekday trading except public holidays, Labor Day, Saturday, year-end closure, and exchange-designated closures. Public-holiday/substitute-holiday rules reflect Korean law effective in 2026; lunar holiday dates are precomputed. Current-law regular election dates are included, but future election changes or extraordinary KRX closures cannot be known years in advance.

To patch an official future announcement without rebuilding the image, create:

`<NOVA_DATA_DIR>/krx_calendar_override.json`

using the schema in `krx_calendar_override.example.json`, then restart NOVA.
