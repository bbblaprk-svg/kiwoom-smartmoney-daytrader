# v3.2.18 FINAL Validation Report

## Purpose
급등 후 추격이 아니라 **급등 전 PRE-IGNITION** 포착을 목적으로 한다. 활성장 동적 판단은 실제 Kiwoom WebSocket 수신 데이터만 사용하며, 전일 종가·REST·캐시 값을 장중 현재가 대체값으로 사용하지 않는다.

## Realtime truth rules
1. 정상 단계는 `REQUESTED -> REG ACK -> FIRST REAL TICK -> FRESH TICK` 순서로 확인한다.
2. `connected` 또는 `subscribed=30`만으로 실시간 정상으로 판정하지 않는다.
3. CORE는 0A/0B를 함께 등록하고 실제 payload의 FID 조합으로 trade-like 타입을 런타임 판별한다.
4. 현재가(10)와 체결/누적/체결강도 계열 FID가 함께 확인된 REAL payload만 실시간 가격·체결 판단에 사용한다.
5. NXT WebSocket REG는 bare 6자리 코드를 사용하고, 실제 REAL payload의 venue 식별값을 우선한다.
6. 활성장에 `lastTradeAt == null` 또는 fresh=0이면 현재가를 전일 종가로 채우지 않고 `DATA_OFFLINE/PARTIAL`로 처리한다.
7. EARLY/PRE-BUY/BUY 및 PRE-IGNITION은 fresh WebSocket 데이터가 확보된 종목만 신규 승격 가능하다.
8. REST는 종가/일봉/복구/후보발굴 보조로만 사용하고 활성장 hot path의 현재가 대체에는 사용하지 않는다.

## PRE-IGNITION objective
- tape acceleration
- orderbook absorption/replenishment
- program flow turn
- VWAP/relative-volume structure

위 독립 축 중 복수 증거가 동시에 강화될 때만 조기 신호를 허용하며 이미 급등한 종목은 추격 방지 게이트로 차단한다.

## Verification performed in this package
- `bash -n` deployment script: PASS
- Bundle SHA256 manifest: PASS
- Trader SOURCE_MANIFEST: PASS
- News SOURCE_MANIFEST: PASS
- `REALTIME_ENGINE_V3218_CHECK`: PASS
- `OFFICIAL_REALTIME_ROUTE_CHECK`: PASS

## Production-only gate
실제 Kiwoom 네트워크 수신은 AWS에서만 최종 확인 가능하다. 활성장 배포 성공 조건은 다음을 포함한다.
- REG ACK
- detectedTradeType 확인
- firstTick > 0
- fresh > 0
- lastTradeAt != null
- dashboard realtime-only price lineage

실패하면 신규 버전을 정상으로 간주하지 않고 롤백하도록 배포 스크립트가 검사한다.
