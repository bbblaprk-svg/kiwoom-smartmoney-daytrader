from __future__ import annotations
import json,sys,urllib.request

RELEASE='3.8.17_NOW_REPAIR'

def get_json(base:str,path:str):
    with urllib.request.urlopen(base.rstrip('/')+path,timeout=6) as r:
        return json.load(r)

def verify(base:str):
    h=get_json(base,'/health'); assert h.get('runtime_safety_release')==RELEASE,(h.get('runtime_safety_release'),RELEASE)
    q=get_json(base,'/api/hidden-gem/top?limit=3'); assert q.get('release')==RELEASE
    coiled=get_json(base,'/api/coiled-spring/top?limit=5'); assert coiled.get('release')==RELEASE and isinstance(coiled.get('rows'),list)
    hist=get_json(base,'/api/signal-history?limit=3'); assert isinstance(hist.get('rows'),list)
    push=get_json(base,'/api/push/public-key'); assert 'enabled' in push and 'public_key' in push
    truth=get_json(base,'/api/feed-truth'); assert truth.get('data_truth_policy')=='NO_DELAYED_OR_CROSS_VENUE_DATA_FOR_BUY_DECISION'
    sess=get_json(base,'/api/session'); assert sess.get('release')==RELEASE and sess.get('automatic_orders') is False
    get_json(base,'/api/runtime-truth')
    rd=get_json(base,'/api/readiness'); assert rd.get('release')==RELEASE and rd.get('ready') is True
    return True

def main(argv=None):
    argv=sys.argv if argv is None else argv
    if len(argv)!=2: raise SystemExit('usage: python -m deploy.verify BASE_URL')
    verify(argv[1]); print('HTTP_CONTRACT_PASS release='+RELEASE)

if __name__=='__main__': main()
