PULSE EDGE 3.8.17_NOW_REPAIR
EARLY 관찰 / PRE 실시간 검증 분리, ETF 차단, 일봉 후보 수명 보호.
4개 테이블 신호가·현재가·등락률, DETAIL ON/OFF, 간격 축소.
신호가: 해당 기록 당시 가격. 현재가: 활성 시장의 최신 체결 확인 가격.
등락률: 현재가의 전일 종가 대비 등락률. 신호 후 수익률과 다름.
미수신·장마감은 과거 가격을 현재가로 대체하지 않음.
점화점수는 확률이 아님. EARLY는 매수 확인 전 관찰 단계.
PRE 가격·호가·수급·PRICE HOLD·압력흡수·방출 검증 유지.
테스트: python -m deploy.offline_tests / python -m pytest -q
운영 서버 실데이터·Docker·공개 HTTPS·실서버 부하 검증은 별도 필요.
