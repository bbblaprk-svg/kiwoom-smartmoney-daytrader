from __future__ import annotations
import asyncio,tempfile,time
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.models import SymbolState,Trade,Quote,InvestorSnapshot
from pulse_edge.engine.scorer import Scorer
from pulse_edge.feed.kiwoom import FID
from pulse_edge.runtime import Runtime

class DummyBaseline:
    def rvol(self,*args): return (2.0,20)

def fixture(spread=0.001,cross_div=0.0,target_change=1.5):
    s=Settings(_env_file=None,feed_enabled=False); sc=Scorer(s,DummyBaseline()); now=time.time(); sc.market_change['KOSDAQ']=0.; sc.market_ts['KOSDAQ']=now
    states={}
    for sym,chg,off in [('000001',target_change,0),('000002',1.0,50),('000003',1.2,80),('000004',3.8,120)]:
        st=SymbolState(sym,'S'+sym,'KOSDAQ','반도체',False,100_000_000,venue='KRX',price=10020+off,change_rate=chg,last_event_ts=now,last_receive_ts=now,last_trade_event_ts=now,last_trade_receive_ts=now,last_quote_event_ts=now,last_quote_receive_ts=now,last_program_event_ts=now,last_program_receive_ts=now,program_net=500_000_000,first_seen_ts=now-2000)
        st.rest_price=st.price*(1+cross_div); st.rest_price_ts=now; st.rest_venue='KRX'; st.prev_close=st.price/(1+chg/100)
        for i in range(200):
            age=(200-i)*6
            if age>900: low,span=9700+off,200
            elif age>600: low,span=9800+off,150
            elif age>300: low,span=9900+off,100
            else: low,span=9970+off,18
            p=low+span*(0.25+0.75*((i%10)/9))
            if 510<age<=570: p=10000+off
            if 450<age<=510: p=9900+off+(510-age)/60*20
            if age<=30: p=10020+off
            vol=40000 if age<=300 else (6000 if age<=600 else 4000); signed=vol if i%6 else -vol*0.15
            st.trades.append(Trade(now-age,p,abs(signed),buy_exec=max(signed,0),sell_exec=max(-signed,0),strength=190))
        ask=st.price*(1+spread/2); bid=st.price*(1-spread/2)
        for i in range(100): st.quotes.append(Quote(now-(100-i)*2,ask,bid,max(30,2500-i*23),1400+i*18,3000,14000))
        st.investor_hist.extend([InvestorSnapshot(now-900,0,0,0,'CONFIRMED'),InvestorSnapshot(now-600,100e6,-600e6,0,'CONFIRMED'),InvestorSnapshot(now-300,400e6,-1_000e6,0,'CONFIRMED'),InvestorSnapshot(now,1_200e6,-1_100e6,0,'CONFIRMED')])
        md=datetime.fromtimestamp(now,ZoneInfo('Asia/Seoul')).replace(second=0,microsecond=0)
        for j in range(1,11):
            x=md-timedelta(minutes=j); st.minute_amount[x.hour*100+x.minute]=100_000_000
        states[sym+':KRX']=st; sc.daily_changes[sym]=(1.,3.,5.)
    return s,sc,states

def run():
    s,sc,states=fixture(); c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.stage=='PRE-IGNITION' and c.suitability=='A' and c.price_hold=='PASS' and c.total_score>=88
    print('PREIGNITION_HARDGATE_PASS',c.total_score,c.ignition_probability)
    _,sc2,states2=fixture(spread=0.01); c2=sc2.score(states2['000001:KRX'],states2,sc2.sector_stats(states2))[1]
    assert c2.suitability!='A' and c2.stage not in {'PRE-IGNITION','IGNITION IMMINENT'}
    print('SPREAD_ABSOLUTE_GATE_PASS')
    _,sc3,states3=fixture(cross_div=0.002); c3=sc3.score(states3['000001:KRX'],states3,sc3.sector_stats(states3))[1]
    assert c3.data_status=='ESTIMATED' and c3.suitability=='WATCH'
    _,sc4,states4=fixture(cross_div=0.004); c4=sc4.score(states4['000001:KRX'],states4,sc4.sector_stats(states4))[1]
    assert c4.data_status=='CONFLICT' and c4.suitability=='WATCH'
    print('DATA_TRUTH_RECHECK_CONFLICT_PASS')
    _,sc5,states5=fixture(target_change=3.5); c5=sc5.score(states5['000001:KRX'],states5,sc5.sector_stats(states5))[1]
    assert c5.total_score<88 and c5.stage not in {'PRE-IGNITION','IGNITION IMMINENT'}
    print('HEAT_PENALTY_ORDER_PASS')
    assert FID['0B']['228']=='trade_strength'
    # Fresh quote/program updates must never hide a stale trade stream.
    stale=states['000002:KRX']; stale.last_trade_receive_ts=time.time()-180; stale.last_trade_event_ts=time.time()-180; stale.last_quote_receive_ts=time.time(); stale.last_program_receive_ts=time.time()
    assert sc.data_status(stale)=='STALE'
    print('CHANNEL_FRESHNESS_ISOLATION_PASS')
    with tempfile.TemporaryDirectory() as td:
        rs=Settings(_env_file=None,feed_enabled=False,data_dir=td,baseline_db=str(Path(td)/'b.sqlite3'),history_db=str(Path(td)/'h.sqlite3'))
        rt=Runtime(rs); now=time.time()
        asyncio.run(rt.on_event({'type':'0J','symbol':'001','venue':'KRX','data':{'change_rate':'-0.4','trade_time':'101010'},'receive_ts':now}))
        assert rt.scorer.market_change['KOSPI']==-0.4
        asyncio.run(rt.on_event({'type':'0B','symbol':'123456','venue':'KRX','data':{'price':'10000','change_rate':'1','trade_volume':'+100','trade_strength':'135','trade_time':'101011'},'receive_ts':now}))
        t=rt.state('123456','KRX').trades[-1]; assert t.buy_exec==100 and t.sell_exec==0 and t.strength==135
    print('INDEX_AND_SIGNED_TRADE_PASS')
    # Feed-OFF readiness is deterministic and does not fake live market verification.
    assert rt.readiness()['ready'] is True
    print('READINESS_CONTRACT_PASS')
    verify=Path(__file__).with_name('verify.py').read_text()
    assert s.release in verify
    print('RELEASE_VERIFY_CONSISTENCY_PASS')
    print('OFFLINE_TESTS_PASS')

if __name__=='__main__': run()

# 3.8.25 common NOW pipeline static guards
from pathlib import Path as _P3825
_r3825=(_P3825(__file__).resolve().parents[1]/'pulse_edge/runtime.py').read_text(encoding='utf-8')
_p3825=(_P3825(__file__).resolve().parents[1]/'pulse_edge/presentation.py').read_text(encoding='utf-8')
_s3825=(_P3825(__file__).resolve().parents[1]/'pulse_edge/engine/scorer.py').read_text(encoding='utf-8')
assert 'st.venue==active_venue' in _r3825
assert 'quote_rotation_sec' in _r3825
assert "getattr(c,'energy_stage',None)=='BUILDING'" in _p3825
assert "or c.sensor_only: continue" in _s3825
print('COMMON_NOW_PIPELINE_3825_PASS')
