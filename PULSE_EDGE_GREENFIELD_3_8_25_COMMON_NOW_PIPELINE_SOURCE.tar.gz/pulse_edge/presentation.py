"""Bounded presentation enrichment; never modifies stored signal snapshots."""
import time
from collections import Counter
from pulse_edge.feed.kiwoom import excluded_security

NOW_STAGES={'ABSORB','EARLY HIDDEN GEM','SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}
PRECURSORS={'EARLY PRESSURE ABSORBED','PRESSURE ABSORBED','ENERGY LOADED','RELEASE WINDOW','RELEASE READY'}

def eligible_now(c):
    # NOW is a discovery board, not an action-only board.  Keep strict PRE/A-B gates
    # untouched, but do not hide a valid latent-energy BUILDING candidate merely
    # because it has not reached ABSORB/PRE yet.  This fixes the common KRX/NXT
    # failure mode where the engine ranked live candidates but the presentation
    # filter rendered an empty table.
    building=(
        getattr(c,'energy_stage',None)=='BUILDING'
        and (getattr(c,'energy_stored',None) or 0)>=55
        and (getattr(c,'remaining_energy',None) or 0)>=35
        and not bool(getattr(c,'too_late',False))
    )
    return (not excluded_security(c.name) and not c.sensor_only
            and c.data_status in {'LIVE','CONFIRMED'}
            and (c.stage in NOW_STAGES or c.precursor_stage in PRECURSORS or building))

def enrich(runtime, rows, history=False, horizon='NOW'):
    n=time.time(); venue=runtime.active_venue(); out=[]
    signals={} if history else {(r.get('symbol'),r.get('venue','KRX')):r for r in reversed(runtime.signal_store.recent(200,horizon))}
    for row in rows:
        d=dict(row); sym=d.get('symbol'); source=d.get('venue','KRX')
        sig=d if history else signals.get((sym,source),{})
        d['signal_price']=sig.get('signal_price',sig.get('current_price'))
        d['signal_ts']=sig.get('history_ts')
        st=runtime.states.get(f'{sym}:{venue}') if venue else None
        fresh=bool(st and st.price and runtime.scorer.data_status(st,n) in {'LIVE','CONFIRMED'})
        d['live_price']=st.price if fresh else None
        d['live_change_rate']=st.change_rate if fresh else None
        d['price_status']='LIVE' if fresh else ('WAIT' if venue else 'CLOSED')
        d['price_venue']=venue
        d['price_timestamp']=st.last_trade_event_ts if fresh else None
        d['signal_return_pct']=round((st.price/d['signal_price']-1)*100,2) if fresh and d.get('signal_price') else None
        out.append(d)
    return out

def diagnostics(runtime):
    stages=Counter(c.stage for c in runtime.raw_results)
    gates=Counter()
    for c in runtime.raw_results:
        for reason in c.reasons:
            if reason in {'TRADE_DATA_NOT_FRESH','PRICE_OR_CHANGE_RECHECK_REQUIRED'} or reason in {
                'COMMON_HARD=False','CROSS_SOURCE=False','MODEL_A_READY=False','MODEL_B_READY=False',
                'SPREAD_OK=False','EARLY_ENERGY_EVIDENCE=False','EARLY_ABSORPTION_EVIDENCE=False','MARKET_INDEX_FRESH=False'}:
                gates[reason]+=1
    return {'states':len(runtime.states),'ranked':len(runtime.raw_results),'stages':dict(stages),'blockers':dict(gates),
            'scope':'ranked_top20','note':'잔존에너지 우선 · ENERGY LOADED/RELEASE WINDOW는 관찰 · PRE만 엄격 하드게이트'}

_original_diagnostics=diagnostics
def diagnostics(runtime):
    d=_original_diagnostics(runtime); now=time.time(); venue=runtime.active_venue()
    wires=runtime.ws.items(); details=[]
    evaluated={(c.symbol,c.venue):c for c in getattr(runtime.scorer,'last_evaluated',[])}
    for wire in wires:
        st=runtime._wire_state(wire)
        if st is None:
            details.append({'symbol':wire,'status':'NO_STATE','stage':'NOT_EVALUATED'});continue
        c=evaluated.get((st.symbol,st.venue))
        skipped=getattr(runtime.scorer,'last_skipped',{}).get((st.symbol,st.venue))
        details.append({'symbol':st.symbol,'venue':st.venue,'status':runtime.scorer.data_status(st,now),
            'trade_age_sec':round(now-st.last_trade_event_ts,2) if st.last_trade_event_ts else None,
            'stage':c.stage if c else ('NOT_QUALIFIED' if skipped else 'AWAITING_EVALUATION'),
            'evaluation':dict(skipped) if skipped else {'evaluated_at':getattr(runtime.scorer,'last_rank_ts',None) if c else None},
            'blockers':[x for x in c.reasons if x.endswith('=False') or 'REQUIRED' in x or 'NOT_FRESH' in x] if c else ([skipped['reason']] if skipped else ['AWAITING_EVALUATION']),
            'protected':wire in runtime.priority_leases})
    active_keys={(st.symbol,st.venue) for wire in wires if (st:=runtime._wire_state(wire)) is not None}
    # Only current subscribed symbols belong in the live data-quality diagnosis.
    # Daily/coiled/history state objects intentionally have no live trade/change fields and
    # previously polluted this counter, making a healthy feed look broken.
    d['no_score_reasons']=dict(Counter(v['reason'] for key,v in getattr(runtime.scorer,'last_skipped',{}).items() if key in active_keys and key[1]==venue))
    d['state_pool_total']=len(runtime.states)
    d['active_subscription_states']=len(active_keys)
    d['discovery_pool_count']=len(getattr(runtime,'discovery_pool',[]))
    d['fresh_discovery_count']=len(runtime._fresh_discovery_wires(now)) if hasattr(runtime,'_fresh_discovery_wires') else 0
    d['nxt_verified_count']=len(getattr(runtime,'nxt_verified_symbols',set()))
    d['transport_venue']=getattr(runtime,'transport_venue',None)
    d['evaluated_at']=getattr(runtime.scorer,'last_rank_ts',None)
    d['subscribed']=len(wires);d['subscription_status']=dict(Counter(x['status'] for x in details))
    d['subscription_stages']=dict(Counter(x['stage'] for x in details));d['subscription_details']=details
    d['all_evaluated_stages']=dict(Counter(c.stage for c in evaluated.values() if c.venue==venue))
    active_eval=[c for c in evaluated.values() if c.venue==venue]
    d['energy_states']=dict(Counter(getattr(c,'energy_stage','OBSERVE') for c in active_eval))
    d['too_late_count']=sum(bool(getattr(c,'too_late',False)) for c in active_eval)
    d['live_ranked_count']=sum(c.data_status in {'LIVE','CONFIRMED'} and not c.sensor_only for c in active_eval)
    d['display_eligible_count']=sum(eligible_now(c) for c in active_eval)
    d['sensor_only_count']=sum(bool(c.sensor_only) for c in active_eval)
    seeds=[runtime.states.get(f'{sym}:KRX') for sym in runtime.coiled_seed_symbols]
    d['daily_pipeline']={'seeds':len(seeds),'state_ready':sum(st is not None for st in seeds),
       'bars_ready':sum(bool(st and len(st.daily_bars)>=8) for st in seeds),
       'flows_ready':sum(bool(st and len(st.daily_flows)>=3) for st in seeds),'qualified_top':len(runtime.coiled_results)}
    return d
