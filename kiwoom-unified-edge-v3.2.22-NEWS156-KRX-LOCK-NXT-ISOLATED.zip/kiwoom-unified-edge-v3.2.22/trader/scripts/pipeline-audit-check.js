const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

const worker = read('worker/kiwoomRealtime.js');
const realtime = read('lib/realtimeStore.js');
const behavior = read('lib/smartMoneyBehavior.js');
const market = read('lib/marketSnapshot.js');
const adaptive = read('lib/adaptiveLearning.js');
const closeLearning = read('lib/closeOutcomeLearning.js');
const portfolio = read('lib/signalPortfolio.js');
const health = read('pages/api/health.js');
const ui = read('pages/index.js');
const recommendation = read('lib/recommendationEngine.js');

// Realtime route guard: official v3.2.21 mapping and venue-map isolated registration.
assert(worker.includes("type:['0B']"), '0B core realtime registration missing');
assert(worker.includes('KRX_BARE_LOCK_NXT_ISOLATED_PROBE_FID9081_V3'), 'adaptive venue registration mode missing');
assert(realtime.includes("case '0B':") && realtime.includes('tradeLike'), '0B realtime processor missing');
for (const mapping of ["case '0D': processOrderbook","case '0F': processBroker","case '0u': processProgram","case '0m':","case '0w': processVi"]) assert(realtime.includes(mapping), `realtime processor missing ${mapping}`);

// LOW TRAFFIC must not regress into periodic or market-status full snapshots.
assert(!worker.includes("setInterval(() => this.refreshSnapshots('schedule')"), 'periodic full REST snapshot regression');
assert(!worker.includes("refreshSnapshots('market-status"), 'market-status full REST snapshot regression');
assert(worker.includes("KIWOOM_INTRADAY_REST_DIAGNOSTIC || 'false'"), 'intraday REST diagnostic-off guard missing');
assert(worker.includes("KRX_CLOSE: { start: 15 * 60 + 32"), 'KRX close-only sync missing');
assert(worker.includes("NXT_CLOSE: { start: 20 * 60 + 1"), 'NXT close-only sync missing');

// Event loop / signal scoring pressure guard.
assert(realtime.includes('REALTIME_TRADE_EVAL_MIN_MS || 40'), 'trade evaluation throttle missing');
assert(realtime.includes('REALTIME_AUX_EVAL_MIN_MS || 80'), 'aux evaluation throttle missing');
assert(realtime.includes('quickPromotionMetrics'), 'lightweight promotion path missing');
const signalEngine = read('lib/signalEngine.js');
assert(signalEngine.includes('const brokerFeedFresh') && !signalEngine.includes('&& brokerAgeSeconds <= cfg.maxSmartBrokerAgeSeconds\n    && tradeEvents'), 'low-frequency broker feed must not hard-block BUY readiness');
assert(signalEngine.includes('orderbookImbalanceEwma') && signalEngine.includes('orderbookSupportStreak'), 'base/orderbook scoring must use smoothed persistent evidence');
assert(signalEngine.includes('const evidenceClusters = {') && signalEngine.includes('tape: Math.max(groups.execution / capacities.execution, groups.largeTrades / capacities.largeTrades)'), 'execution/large-trade correlated evidence must count as one independent tape axis');
assert(signalEngine.includes('const programFresh = finite(s.programAgeMs') && signalEngine.includes('const brokerFresh = finite(s.brokerAgeMs'), 'stale flow must not inflate score');
assert(health.includes('realtimeTypeMap'), 'health realtime type telemetry missing');
assert(health.includes('payload.load') && health.includes('realtime'), 'authenticated load telemetry missing');
assert(health.includes('주식당일거래원(0F)') && !health.includes('&& stock.broker && stock.broker.updatedAt && now - stock.broker.updatedAt <= 120000).length;'), 'health smartMoneyReady must match core BUY readiness');

// Smart-money decisions must require fresh, independent, persistent evidence.
for (const marker of [
  'tradeFresh', 'orderbookFresh', 'programFresh', 'supportStreak >= 2',
  'executionTurn', 'recoveryConfirmations >= 2', 'markupConfirmations >= 3',
  'distributionAxes >= 3', "add('tape', '15초 매도우위→5초 공격매수 전환')", 'EVIDENCE_CONFIDENCE_NOT_PROBABILITY', 'persistBehavior',
]) assert(behavior.includes(marker), `smart-money guard missing ${marker}`);

// Official close decision must not accept stale live flow as final institutional/program confirmation.
assert(market.includes('OFFICIAL_REST_PRIMARY'), 'official REST primary close flow missing');
assert(market.includes('FRESH_REALTIME_FALLBACK'), 'fresh realtime fallback marker missing');
assert(market.includes('PRESERVED_DISPLAY_ONLY'), 'preserved-data display-only marker missing');
assert(market.includes('Boolean(flowAvailability.institution && flowAvailability.program)'), 'official close flow must require investor AND program');

// Learning must be conservative and unable to bypass hard gates.
assert(adaptive.includes('ADAPTIVE_LEARNING_MIN_TOTAL_SAMPLES || 60'), 'adaptive minimum total samples regression');
assert(adaptive.includes('ADAPTIVE_LEARNING_MIN_BUCKET_SAMPLES || 12'), 'adaptive minimum bucket samples regression');
assert(adaptive.includes('ADAPTIVE_LEARNING_MAX_ADJUSTMENT || 6'), 'adaptive max adjustment regression');
assert(closeLearning.includes('CLOSE_LEARNING_MIN_TOTAL || 60'), 'close-learning sample guard regression');
assert(closeLearning.includes('CLOSE_LEARNING_MIN_BUCKET || 12'), 'close-learning bucket guard regression');
assert(closeLearning.includes('barsSeen>=7'), 'close-learning trading-bar timeout missing');
assert(closeLearning.includes('mfeR') && closeLearning.includes('maeR'), 'MFE/MAE outcome tracking missing');
const positionLearning = read('lib/positionLearning.js');
assert(positionLearning.includes("source: 'ACTUAL_POSITION'") && adaptive.includes('actualPositions.length >= MIN_TOTAL_SAMPLES'), 'actual fill outcome learning path missing');

// Intraday recommendation enrichment cannot issue a serial REST storm.
assert(recommendation.includes('cacheOnly: includeLive && intradayMarketActive()'), 'intraday profile cache-only guard missing');
assert(recommendation.includes('if (autoCount === 0) await applyRecommendations(rec);'), 'automatic empty-watchlist bootstrap missing');

// Management: do not lower BUY threshold just to fill 4-6; keep bought names pinned; show data quality and R/R.
assert(portfolio.includes("code: 'BUY_MANAGE'"), 'BUY-active management pinning missing');
assert(portfolio.includes('qualityFloor') && portfolio.includes('n(signal.qualityScore) >= qualityFloor'), 'absolute reserve quality floor missing');
assert(portfolio.includes('tradeStrength'), 'reserve trade-strength floor missing');
assert(ui.includes('<th>데이터</th>') && ui.includes('<th>R/R</th>'), 'management table data-quality/RR columns missing');
assert(ui.includes("BUY_MANAGE: 0") && ui.includes("!existing.boughtActive"), 'client table must keep BUY-active rows pinned');
assert(ui.includes('증거신뢰'), 'smart-money confidence must be labeled as evidence confidence');

// Dynamic throttle check: a burst must not recalculate the entire scoring engine on every tick.
process.env.REALTIME_TRADE_EVAL_MIN_MS = '50';
process.env.REALTIME_AUX_EVAL_MIN_MS = '100';
const store = require('../lib/realtimeStore');
const runtimeMetrics = require('../lib/runtimeMetrics');
const before = { ...runtimeMetrics.state.realtime };
const code = '999001';
for (let i = 0; i < 500; i += 1) {
  store.processRealtimeEntry({
    type: '0B', item: code, values: {
      '10': String(10000 + (i % 5)), '12': '0.5', '15': i % 2 ? '100' : '-90',
      '13': String(100000 + i), '14': String(1_000_000_000 + i * 1_000_000),
      '27': '10010', '28': '10000', '228': '122', '851': '150', '1032': '54', '620': '9990',
    },
  }, { name: 'PIPELINE_TEST', market: 'SOR', tier: 'FOCUS' });
}
const after = runtimeMetrics.state.realtime;
const evals = Number(after.signalEvaluations || 0) - Number(before.signalEvaluations || 0);
const skips = Number(after.signalEvaluationSkips || 0) - Number(before.signalEvaluationSkips || 0);
assert(evals >= 1, 'burst must perform at least one signal evaluation');
assert(skips > evals * 10, `burst throttle ineffective evals=${evals} skips=${skips}`);
const testStock = store.state.stocks.get(code);
assert(testStock && testStock.tradeEventCount === 500, 'throttling must not drop trade ticks');

console.log(JSON.stringify({
  ok: true,
  version: require('../package.json').version,
  officialRealtimeTypes: { trade: '0B', orderbook: '0D', broker: '0F', program: '0u', marketStatus: '0m', vi: '0w' },
  burst: { ticks: 500, signalEvaluations: evals, evaluationSkips: skips, droppedTrades: 500 - Number(testStock.tradeEventCount || 0) },
  all30ScoutRealtime: ['0B','0D','0u'],
  smartMoneyIndependentEvidence: true,
  officialCloseFlowGuard: true,
  learningAntiOverfit: { minTotal: 60, minBucket: 12, defaultMaxAdjustment: 6 },
  managementTable: { dataQuality: true, rewardRisk: true, buyPinned: true },
}, null, 2));
