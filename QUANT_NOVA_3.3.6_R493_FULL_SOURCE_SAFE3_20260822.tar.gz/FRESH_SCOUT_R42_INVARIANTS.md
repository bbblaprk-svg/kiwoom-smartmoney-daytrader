# QUANT NOVA 3.3.4 R4.2 — FRESH SCOUT + DISPLAY HYSTERESIS INVARIANTS

## Root objective
- Find names immediately before a sharp move; never optimize for chasing names that already rallied.
- Internal discovery/ranking remains realtime. Display hysteresis may stabilize row position only.
- Current price, change, BP, smart-money, turnover/volume acceleration, VWAP, EARLY EDGE score and state must continue updating while a row position is held.

## Discovery membership
- Discovery boards use ANCHOR 6 + FRESH 4 when the candidate pool permits.
- FRESH window is 180 seconds from discovery_first_seen_at.
- FAST SCOUT privilege is bounded to 90 seconds.
- First capture may enter FAST SCOUT even with rank_velocity=0 when either:
  - two or more rank sources newly join, or
  - first observed best rank is <= 20.
- After FAST SCOUT expires, a name may remain in the FRESH scout lane only if fresh broker TRADE data confirms flow/turnover evidence.
- No new broker REST request and no new WS subscription type may be added.
- Total WS code budget/ceiling must not increase.

## Display hysteresis
- Default display hold: 20 seconds.
- A normal re-sort waits until the hold expires.
- A new candidate may enter during the hold when it exceeds the current weakest row by >= 5 EARLY EDGE points.
- A strong FAST SCOUT at PRE_BREAKOUT/EARLY_IGNITION may enter immediately without the +5 gap.
- Missing/stale candidates disappear immediately because the stabilizer resolves rows only from the current ranked pool.
- Hysteresis state is independent per board/category.

## EARLY EDGE freshness
- Freshness allocation is 15/100, not 5/100.
- 0-45s: 15; <=90s: 13; <=180s: 8; <=360s: 3; older: 0.
- Existing R4 chase control remains in force: penalty begins >+3%; >=+7% blocks EARLY promotion; >=+10% score cap 45; >=+15% cap 25.

## Protected truth
- Official ENTRY_V18 BUY logic byte hash is unchanged.
- Kiwoom REST/WebSocket transport byte hashes are unchanged.
- HTTP Guard/Caddy are untouched.
- BUY/performance, Opening Bridge, NXT signal management, Position Manager, SIGNAL HISTORY and WAL are truth/state boards and are not discovery-re-ranked.
