# R45 LARGE-CAP CLOSE LAST-LIVE-ONLY INVARIANTS

- OPENING PROFIT BRIDGE remains hidden after 10:00 KST; backend records are retained.
- During an active session, LARGE-CAP displays only fresh live operator-universe rows.
- After market close, LARGE-CAP may display only the latest non-empty LIVE snapshot captured in this runtime.
- After a post-close restart with no LIVE snapshot, LARGE-CAP is empty and explicitly reports no LIVE-confirmed rows.
- CLOSE_RECONSTRUCTED / DATA_WAIT / MARKET_BACKFILL rows must never repopulate LARGE-CAP.
- PRE-IGNITION close reconstruction behavior is unchanged.
- Official BUY/ENTRY policy, Kiwoom REST, WebSocket subscriptions, Guard/Caddy are unchanged.
