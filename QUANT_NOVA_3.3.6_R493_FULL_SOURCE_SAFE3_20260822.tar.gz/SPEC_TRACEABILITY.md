# MASTER TOP10 traceability

- Venue isolation: `app/domain.py`, `app/runtime/state.py`, `app/runtime/projection.py`.
- Protected queues and critical latch: `app/runtime/dispatcher.py`, `app/runtime/ingest.py`.
- RESYNC/WARMING and REST baseline: `app/broker/recovery.py`, `app/signal/metrics.py`.
- WAL-before-signal and frozen ENTRY_V18: `app/signal/coordinator.py`, `app/signal/policy.py`, `app/storage/wal.py`.
- TOP10 and delta UI: `app/tracking/top10.py`, `app/runtime/display.py`, `app/api/app.py`, `static/nova.js`.
- Downstream load control: `app/runtime/load_control.py`, `app/runtime/health.py`.
- Existing ranking pool: `app/broker/discovery.py` (`RANK_SPECS`, unchanged seven specifications across two markets).
- Bounded rotation: `app/broker/market_rotation.py`, `app/config.py`, `app/broker/websocket.py`.
- Exploration/official isolation and promotion warming: `app/runtime/state.py`, `app/signal/coordinator.py`, `app/broker/discovery.py`.
- Read-only max-profit research: `app/addons/max_profit_lab.py`, `app/addons/max_profit_model.py`, `app/storage/max_profit_verify.py`.
- Separate research UI: `static/max-profit-lab.html`, `static/max-profit-lab.css`, `static/max-profit-lab.js`, `/ws/max-profit-lab`.

- `MARKET_ROTATION_ZERO_REST`: rotation contains no broker client call and reuses Discovery results.
- `MARKET_ROTATION_BOUNDED_WS`: 8/4/2/0 slots, existing TRADE type only, unchanged provider ceilings, no auxiliary feed.
- `MARKET_ROTATION_SHED_FAST`: WebSocket target construction applies load mode every registry refresh.
- `EXPLORATION_BUY_BLOCK`: exploration evaluation returns before tracking reservation, WAL or ENTRY_V18.
- `EXPLORATION_PROMOTION_WARM`: marker survives queued work; explicit promotion clears the window and re-earns 30 seconds of live trades.
- `P3_PROBABILITY_GUARD`: probability stays hidden until 300 samples and 30 successes; displayed estimates include a 95% Wilson interval.
- `SAFE_CUTOVER`: `ops/NOVA_3.3.4_SAFE_CUTOVER_AUTO_ROLLBACK.sh` changes only `quant-nova` and restores the exact retained container on any failed gate.

## R49.1 PRE-SIGNAL LIVE-EVIDENCE
- Formal cadence isolation + current live evidence qualification: `app/addons/signal_acceleration.py`.
- 10-minute continuous live-only episode cap / 60-second rearm gap / 30-second rank commit: `app/addons/decision_panels.py`.
- UI lane/evidence telemetry: `static/decision-panels.js`.
- Regression and protected-hash tests: `tests/test_r49_signal_acceleration.py`.
