# R46 SESSION CLOSE HARD FREEZE INVARIANTS

- When KRX and NXT continuous sessions are both closed, the main dashboard is read-only.
- The exact latest committed LIVE board order/membership is reused; closed-session display builds do not re-rank TOP10 boards.
- TOP10 ENTER / EXIT / REENTER writers are disabled while the market is closed.
- Signal History is frozen from the latest LIVE snapshot; closed-session display refreshes cannot append TOP10_REENTER events.
- Frozen rows explicitly expose `display_session_state=FROZEN`; the UI badge must not continue to show NORMAL_INTRADAY after close.
- Repeated closed-session reads may refresh transport metadata/generation only; board membership, ranking, repeat/reentry counters, and Signal History remain unchanged.
- R45 LARGE-CAP policy remains LAST-LIVE ONLY: no CLOSE_RECONSTRUCTED, DATA_WAIT, or MARKET_BACKFILL repopulation.
- PRE-IGNITION close behavior is unchanged when no last-LIVE dashboard snapshot is available.
- Official BUY/ENTRY policy, Kiwoom REST, WebSocket subscriptions, Guard and Caddy are unchanged.
