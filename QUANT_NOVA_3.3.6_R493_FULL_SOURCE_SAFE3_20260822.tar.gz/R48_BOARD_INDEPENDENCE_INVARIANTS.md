# R48 BOARD INDEPENDENCE

Purpose: restore distinct contracts for the three live discovery boards after R47 close-freeze work.

- PRE-IGNITION remains the early-edge / pre-breakout observation layer.
- PREBUY (`실시간 유망종목 자동발굴 · BUY 직전 TOP10`) is ENTRY_V18 proximity only. EARLY EDGE alone cannot fill it.
- NXT EARLY (`NXT 조기유입 · 스마트머니 Proxy TOP10`) requires at least two NXT flow confirmations among Smart-Money surge/score/acceleration, sell-to-buy flip, program delta, or buy-pressure acceleration.
- No board is force-filled to 10. Fewer qualified rows is valid.
- Official BUY/ENTRY_V18 numeric policy is byte-frozen.
- Kiwoom REST and WebSocket source files are byte-frozen.
- R47 session-close hard-freeze and late-score queue drop are retained.
