# R4.3.1 Opening 10:00 Expire Invariants

- PREMARKET_RECHECK 08:00~08:50: live NXT PRE rows visible; DATA WAIT compacted.
- OPENING_HANDOFF 08:50~09:00: PRIOR retained for handoff only.
- SHAKEOUT/REVERSAL 09:00~10:00: PRIOR + TODAY_NEW compete on one score rank.
- NORMAL_INTRADAY from 10:00: Opening Bridge rows are empty and UI is one compact status line.
- Historical shadow records remain stored for VERIFY only and cannot occupy the main screen after 10:00.
- Official ENTRY_V18/BUY, Kiwoom REST/WS, Guard, Caddy unchanged.
- PRIOR carry remains next-trading-day only; another-day renewal requires same-day formal evidence.
