# R493 MARKET RELATIVE SAFE invariants

1. R491 official BUY/ENTRY_V18 policy is unchanged.
2. R492 CORE/FRESH, ENERGY and PATH remain intact.
3. KOSPI/KOSDAQ context comes from Kiwoom domestic-sector current price `ka20001` (`/api/dostk/sect`) only during the KRX regular session.
4. Market index collection is a separate low-priority task: NORMAL 60s, BUSY 120s, HIGH_LOAD/CRITICAL paused. No new WebSocket subscription type is added.
5. At most two additional broker REST calls occur per market-index refresh (KOSPI 001 + KOSDAQ 101). If the context is stale or fails, all market adjustments fail open to zero.
6. Discovery stores KOSPI/KOSDAQ membership from the already-existing ranking request market parameter. This adds no ranking request.
7. PRE base score, formal signal cadence and entry-candidate eligibility are unchanged. Only the display PRE `rank_score` receives a bounded market overlay (default +/-3).
8. ENERGY/PATH component scores and stages remain unchanged. Only their ranking score receives bounded overlays (ENERGY +/-5, PATH +/-3).
9. Market relative rate is stock day change minus its KOSPI/KOSDAQ day change. No unverified beta estimate is used.
10. RISK_OFF/PANIC resilience may add a bounded bonus when the stock materially outperforms the falling market.
11. Market context is informational outside KRX regular hours and is not used for fresh ranking adjustment when stale.
12. Load priority remains PRE/BUY/NXT > ENERGY > PATH > market-index refresh.

13. KOSPI/KOSDAQ breadth uses the official ka20001 `upl/rising/stdns/fall/lst` buckets; no undocumented listed-count field is required.
