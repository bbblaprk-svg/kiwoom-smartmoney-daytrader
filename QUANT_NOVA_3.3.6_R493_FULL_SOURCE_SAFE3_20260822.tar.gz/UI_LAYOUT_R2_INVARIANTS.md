# QUANT NOVA 3.3.4 R2 UI / TOP10 invariants

- Official BUY/signal policy is unchanged.
- Broker REST calls, websocket subscription types and code ceilings are unchanged.
- LARGE-CAP panel display target is 10 rows when the existing candidate pool has at least 10 usable rows.
- Fill order is operator large-cap rows first, then large-cap DATA WAIT, then market-wide DISPLAY ONLY backfill.
- MARKET_BACKFILL rows never expose entry/stop/T1/T2 and never mutate official BUY state.
- iPad/tablet 700-1199 CSS px uses one full-width column, fixed row heights and explicit six-column board grids.
- Existing bottom VERIFY panel remains bottom-only and fixed 10 rows.
- Guard/Caddy and SIGNAL_POLICY_FROZEN remain unchanged.
