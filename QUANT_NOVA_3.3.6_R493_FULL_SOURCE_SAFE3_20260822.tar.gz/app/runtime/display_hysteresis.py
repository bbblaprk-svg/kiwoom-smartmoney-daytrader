from __future__ import annotations
from collections.abc import Callable
from typing import Any

from app.config import SETTINGS

Row = dict[str, Any]


def compose_anchor_fresh_rows(rows: list[Row], score: Callable[[Row], float], headroom: Callable[[Row], float] | None = None) -> list[Row]:
    """Select ANCHOR6+FRESH4 membership; final order still follows live rank score."""
    slots = SETTINGS.board_slots
    anchor_n = min(SETTINGS.discovery_anchor_slots, slots)
    fresh_n = min(SETTINGS.discovery_fresh_slots, max(0, slots-anchor_n))
    headroom = headroom or (lambda _: 0.0)
    anchors = [r for r in rows if not r.get('fresh_window')]
    fresh = [r for r in rows if r.get('fresh_window')]
    fresh.sort(key=lambda r: (1 if r.get('fast_scout') else 0, score(r), headroom(r), -(float(r.get('fresh_age_sec')) if r.get('fresh_age_sec') is not None else 1e9)), reverse=True)
    chosen: list[Row] = []; used: set[str] = set()
    for r in anchors[:anchor_n]: chosen.append(r); used.add(str(r['code']))
    for r in fresh[:fresh_n]:
        if str(r['code']) not in used: chosen.append(r); used.add(str(r['code']))
    for r in rows:
        if str(r['code']) in used: continue
        chosen.append(r); used.add(str(r['code']))
        if len(chosen) >= slots: break
    return sorted(chosen[:slots], key=lambda r: (score(r), headroom(r), float(r.get('last_tick_at') or 0.0)), reverse=True)


def stabilize_row_board(board: str, ranked: list[Row], now: float, stable: dict[str, list[str]], last_rank_at: dict[str, float], score: Callable[[Row], float], compose: Callable[[list[Row]], list[Row]], urgent: Callable[[Row], bool]) -> list[Row]:
    """Hold positions only; all returned rows are current live row dictionaries."""
    slots = SETTINGS.board_slots; desired = compose(ranked); by = {str(r['code']): r for r in ranked}
    old = stable.get(board, []); last = float(last_rank_at.get(board, 0.0))
    if not old:
        out = desired[:slots]; stable[board] = [str(r['code']) for r in out]; last_rank_at[board] = now; return out
    existing = [by[c] for c in old if c in by]; seen = {str(r['code']) for r in existing}
    for r in desired:
        if str(r['code']) not in seen and len(existing) < slots: existing.append(r); seen.add(str(r['code']))
    if now-last < SETTINGS.discovery_display_hold_sec and existing:
        wi = min(range(len(existing)), key=lambda i: score(existing[i])); weak = score(existing[wi])
        for r in desired:
            code = str(r['code'])
            if code in seen: continue
            if score(r) >= weak + SETTINGS.discovery_display_immediate_gap or urgent(r):
                seen.discard(str(existing[wi]['code'])); existing[wi] = r; seen.add(code)
                wi = min(range(len(existing)), key=lambda i: score(existing[i])); weak = score(existing[wi])
        out = existing[:slots]
    else:
        out = desired[:slots]; last_rank_at[board] = now
    stable[board] = [str(r['code']) for r in out]
    return out
