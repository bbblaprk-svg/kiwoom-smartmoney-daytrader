from __future__ import annotations
import asyncio,time,threading,json,copy
from app.domain import Candidate,Venue,Origin
from app.runtime.state import RuntimeState
from app.runtime.projection import LiveDisplayProjection
from app.runtime.clock import lifecycle_phase,sec_of_day,sessions
from app.tracking.top10 import Top10Registry
from app.tracking.live import LiveTracker
from app.config import SETTINGS
from app.signal.early_edge import discovery_freshness, early_edge

class DisplayState:
    """Single-writer display snapshot with self-healing read-through freshness.

    The trading engine is authoritative.  The browser must never depend on one
    background display task staying alive forever, so API/WS readers can rebuild
    a stale snapshot from current in-memory engine state without mutating signal
    policy or candidate state.
    """
    def __init__(self,state:RuntimeState,tracker:LiveTracker):
        self.state=state;self.tracker=tracker;self.lock=threading.Lock();self.build_lock=threading.Lock()
        self.snapshot={'type':'snapshot','version':SETTINGS.version,'generation':0,'generated_at':time.time(),'feed_state':'STARTING','phase':'PRIOR_CLOSE_FROZEN','feed':{},'load_mode':'NORMAL','telemetry':{},'boards':{'prebuy':[],'opening':[],'live_buy':[],'nxt_early':[],'nxt_management':[],'position_manager':[]},'signal_history':[],'candidate_count':0,'hot_count':0,'pinned_count':0,'board_slots':SETTINGS.board_slots,'delivery':{'bridge':'LIVE_BRIDGE_V2_TOP10_DELTA','source':'INITIAL'}}
        self.fallback={};self.generation=0;self.top10=Top10Registry();self.wire_lock=threading.Lock();self.wire_generation=0;self.wire_snapshot_json='';self.wire_delta_json='';self.last_build_error='';self.last_build_error_at=0.0;self.last_build_ok_at=0.0
        self.stable_codes:dict[str,list[str]]={};self.last_rank_at:dict[str,float]={};self.last_emitted_tick:dict[tuple[str,Venue],float]={};self.projection=LiveDisplayProjection(SETTINGS.display_fresh_ms)
    def get(self):
        with self.lock:return self.snapshot
    def get_fresh(self,max_age_sec:float|None=None):
        max_age=max_age_sec if max_age_sec is not None else max(1.0,SETTINGS.ui_delta_ms/1000*6)
        with self.lock:
            snap=self.snapshot;age=max(0.0,time.time()-float(snap.get('generated_at') or 0))
        if age>max_age:
            self.build(source='READ_THROUGH',blocking=False)
            with self.lock:snap=self.snapshot
        return snap
    def set_fallback(self,snap:dict):
        with self.lock:self.fallback=snap if isinstance(snap,dict) else {}
    def history(self,code:str):
        c=self.state.candidates.get(code)
        if not c:return []
        with self.state.code_lock(code):
            events=[{'at':x.at,'kind':x.kind,'state':x.state,'price':x.price,'reason':x.reason,'venue':x.venue.value} for x in list(c.history)]
            tracks=[{'at':t.signal_time,'kind':'OUTCOME','state':'SIGNAL_TRACK','price':t.signal_price,'reason':str(t.public()),'venue':t.venue.value} for t in list(c.signal_tracks)]
        return sorted(events+tracks,key=lambda x:x['at'])
    @staticmethod
    def _sort(rows:list[Candidate],key):return sorted(rows,key=key,reverse=True)
    @staticmethod
    def _row_quality(row:dict)->int:
        if not isinstance(row,dict):return 0
        q=0
        if row.get('price') not in (None,0,'') or row.get('reference_price') not in (None,0,''):q+=4
        if row.get('change_rate') is not None:q+=2
        if float(row.get('score') or 0)>0:q+=2
        if float(row.get('priority_score') or 0)>0:q+=1
        if int(row.get('valid_repeat_count') or 0)>0:q+=1
        return q
    @classmethod
    def _merge_frozen_board(cls,current:list[dict],fallback:list[dict])->list[dict]:
        cur=[dict(x) for x in (current or []) if isinstance(x,dict)];fb=[dict(x) for x in (fallback or []) if isinstance(x,dict)]
        by_cur={str(x.get('code') or ''):x for x in cur if x.get('code')};used=set();out=[]
        # Preserve the last committed board order whenever it contains usable truth, but never
        # prefer a degraded/blank fallback row over a richer runtime-restored row.
        for old in fb[:SETTINGS.board_slots]:
            code=str(old.get('code') or '');now=by_cur.get(code)
            pick=old if cls._row_quality(old)>=cls._row_quality(now or {}) else now
            if pick is not None:out.append(dict(pick));used.add(code)
        for row in cur:
            code=str(row.get('code') or '')
            if code and code in used:continue
            out.append(dict(row));used.add(code)
            if len(out)>=SETTINGS.board_slots:break
        return out[:SETTINGS.board_slots]
    @classmethod
    def snapshot_has_truth(cls,snap:dict)->bool:
        boards=(snap.get('boards') or {}) if isinstance(snap,dict) else {}
        return any(cls._row_quality(r)>=4 for rows in boards.values() for r in (rows or []) if isinstance(r,dict))
    @staticmethod
    def delta(prev:dict,cur:dict)->dict:
        patch={};keys=('feed_state','phase','feed','load_mode','telemetry','candidate_count','hot_count','pinned_count','signal_history','delivery')
        for k in keys:
            if prev.get(k)!=cur.get(k):patch[k]=cur.get(k)
        bp={};pb=prev.get('boards') or {};cb=cur.get('boards') or {}
        for k,v in cb.items():
            if pb.get(k)!=v:bp[k]=v
        if bp:patch['boards']=bp
        return {'type':'delta','version':cur.get('version'),'base_generation':prev.get('generation',0),'generation':cur.get('generation',0),'generated_at':cur.get('generated_at'),'patch':patch}
    def wire_for(self,last_generation:int)->tuple[int,str]:
        """Return a pre-serialized snapshot/delta. Delta is built once per generation, not per client."""
        with self.wire_lock:
            gen=self.wire_generation
            if not self.wire_snapshot_json:
                snap=self.get_fresh();return int(snap.get('generation') or 0),json.dumps(snap,ensure_ascii=False,separators=(',',':'))
            if last_generation==gen-1 and self.wire_delta_json:return gen,self.wire_delta_json
            if last_generation==gen:return gen,''
            return gen,self.wire_snapshot_json

    def _refresh_wire(self,prev:dict,cur:dict):
        delta=self.delta(prev,cur) if prev else cur
        with self.wire_lock:
            self.wire_generation=int(cur.get('generation') or 0)
            self.wire_snapshot_json=json.dumps(cur,ensure_ascii=False,separators=(',',':'))
            self.wire_delta_json=json.dumps(delta,ensure_ascii=False,separators=(',',':')) if prev else self.wire_snapshot_json
        self.state.telemetry['ui_wire_snapshot_bytes']=len(self.wire_snapshot_json.encode('utf-8'))
        self.state.telemetry['ui_wire_delta_bytes']=len(self.wire_delta_json.encode('utf-8'))

    def _stabilize(self,board:str,ranked:list[Candidate],now:float,immediate_codes:set[str]|None=None,rank_score=None)->list[Candidate]:
        immediate_codes=immediate_codes or set();rank_score=rank_score or (lambda c:c.priority_score);old=self.stable_codes.get(board,[]);by={c.code:c for c in ranked};raw=[c.code for c in ranked]
        force=bool(immediate_codes-set(old))
        if old and now-self.last_rank_at.get(board,0)<1.0 and not force:
            out=[by[x] for x in old if x in by]
            seen={x.code for x in out}
            for c in ranked:
                if c.code not in seen:out.append(c);seen.add(c.code)
                if len(out)>=SETTINGS.board_slots:break
            return out[:SETTINGS.board_slots]
        desired=ranked[:SETTINGS.board_slots]
        if old and not force:
            desired_codes=[c.code for c in desired]
            for code in old:
                if code in desired_codes or code not in by or code not in raw:continue
                idx=raw.index(code)
                if idx<=SETTINGS.board_slots and desired:
                    weakest=min(desired,key=rank_score)
                    if rank_score(by[code])+1.5>=rank_score(weakest):
                        desired=[c for c in desired if c.code!=weakest.code]+[by[code]];desired=self._sort(desired,lambda c:(rank_score(c),c.score,c.current().last_tick_at))[:SETTINGS.board_slots];desired_codes=[c.code for c in desired]
        self.stable_codes[board]=[c.code for c in desired];self.last_rank_at[board]=now;return desired

    @staticmethod
    def _rank_value(c:Candidate,score_fn):
        try:return float(score_fn(c) or 0.0)
        except Exception:return 0.0

    def _compose_anchor_fresh(self,ranked:list[Candidate],now:float,rank_score)->list[Candidate]:
        """Select discovery-board membership as ANCHOR 6 + FRESH 4.

        This changes membership selection only. Candidate objects remain live, so price,
        BP, SM, acceleration and state continue updating while row positions are held.
        """
        slots=SETTINGS.board_slots
        anchor_n=min(SETTINGS.discovery_anchor_slots,slots)
        fresh_n=min(SETTINGS.discovery_fresh_slots,max(0,slots-anchor_n))
        fresh=[];anchors=[]
        for c in ranked:
            meta=discovery_freshness(c,now)
            (fresh if meta['fresh_window'] else anchors).append(c)
        fresh.sort(key=lambda c:(
            1 if discovery_freshness(c,now)['fast_track'] else 0,
            self._rank_value(c,rank_score),
            float(c.metrics.get('discovery_scout_score') or 0.0),
            -(discovery_freshness(c,now)['age_sec'] if discovery_freshness(c,now)['age_sec'] is not None else 1e9),
        ),reverse=True)
        chosen=[];used=set()
        for c in anchors[:anchor_n]:chosen.append(c);used.add(c.code)
        for c in fresh[:fresh_n]:
            if c.code not in used:chosen.append(c);used.add(c.code)
        for c in ranked:
            if c.code in used:continue
            chosen.append(c);used.add(c.code)
            if len(chosen)>=slots:break
        chosen=chosen[:slots]
        return sorted(chosen,key=lambda c:(self._rank_value(c,rank_score),c.score,c.current().last_tick_at),reverse=True)

    def _stabilize_discovery(self,board:str,desired:list[Candidate],ranked:list[Candidate],now:float,rank_score,urgent_codes:set[str]|None=None)->list[Candidate]:
        """Hold row order for 20s while all live fields continue to update.

        A new symbol can break the hold only when it beats the current weakest row by
        >=5 EARLY-EDGE points, or when it is a strong FAST SCOUT (PRE_BREAKOUT+).
        Stale/removed symbols leave immediately.
        """
        urgent_codes=urgent_codes or set();slots=SETTINGS.board_slots
        by={c.code:c for c in ranked};old=self.stable_codes.get(board,[])
        if not old:
            out=desired[:slots];self.stable_codes[board]=[c.code for c in out];self.last_rank_at[board]=now;return out
        existing=[by[code] for code in old if code in by]
        seen={c.code for c in existing}
        # Disappearance/staleness is never hidden by display hysteresis.
        for c in desired:
            if c.code not in seen and len(existing)<slots:existing.append(c);seen.add(c.code)
        held=now-self.last_rank_at.get(board,0.0)<SETTINGS.discovery_display_hold_sec
        if held and existing:
            weakest_i=min(range(len(existing)),key=lambda i:self._rank_value(existing[i],rank_score))
            weakest_score=self._rank_value(existing[weakest_i],rank_score)
            for c in desired:
                if c.code in seen:continue
                score=self._rank_value(c,rank_score)
                if score>=weakest_score+SETTINGS.discovery_display_immediate_gap or c.code in urgent_codes:
                    displaced=existing[weakest_i].code
                    existing[weakest_i]=c;seen.discard(displaced);seen.add(c.code)
                    weakest_i=min(range(len(existing)),key=lambda i:self._rank_value(existing[i],rank_score))
                    weakest_score=self._rank_value(existing[weakest_i],rank_score)
            out=existing[:slots];self.stable_codes[board]=[c.code for c in out];return out
        out=desired[:slots]
        self.stable_codes[board]=[c.code for c in out];self.last_rank_at[board]=now;return out

    @staticmethod
    def _decorate_discovery_meta(row:dict,c:Candidate,edge:dict,now:float)->dict:
        meta=discovery_freshness(c,now);row=dict(row)
        row['fresh_age_sec']=meta['age_sec'];row['fresh_label']=meta['label'];row['fast_scout']=bool(meta['fast_track'])
        row['rank_trend']=meta['rank_trend'];row['rank_velocity']=meta['rank_velocity'];row['discovery_new_sources_60s']=meta['new_sources_60s']
        row['display_hysteresis_sec']=SETTINGS.discovery_display_hold_sec
        row['rank_lane']='FRESH' if meta['fresh_window'] else 'ANCHOR'
        return row

    def _observe_ui_latency(self,rows:list[Candidate],venue_override:Venue|None=None):
        now=time.time()
        for c in rows:
            v=c.venue_state[venue_override] if venue_override in (Venue.KRX,Venue.NXT) else c.current();k=(c.code,v.venue)
            if v.last_tick_at and v.last_tick_at>self.last_emitted_tick.get(k,0):
                self.state.observe_latency('tick_to_ui_ms',max(0,(now-v.last_tick_at)*1000));self.last_emitted_tick[k]=v.last_tick_at
    def build(self,source:str='BACKGROUND',blocking:bool=True):
        acquired=self.build_lock.acquire(blocking=blocking)
        if not acquired:return False
        try:
            now=time.time();phase=lifecycle_phase();sess=sessions();active=bool(sess['active'])
            # R46 SESSION-CLOSE HARD FREEZE: once all continuous venues are closed,
            # the dashboard is read-only.  Reuse the exact last committed LIVE snapshot
            # instead of re-ranking boards or running TOP10 membership/event writers.
            if not active:
                with self.lock:
                    frozen_source=self.fallback if self.snapshot_has_truth(self.fallback) else None
                if frozen_source:
                    boards=copy.deepcopy(frozen_source.get('boards') or {})
                    for rows in boards.values():
                        for row in rows or []:
                            if isinstance(row,dict):
                                row['display_session_state']='FROZEN'
                                row['display_price_source']='SESSION_CLOSE_FROZEN'
                                row['display_stale']=True
                    with self.state.lock:
                        candidate_count=len(self.state.candidates);hot_count=len(self.state.hot_codes);pinned_count=len(self.state.pinned_codes)
                    delivery=dict(frozen_source.get('delivery') or {})
                    delivery.update({'source':source,'market_active':False,'display_mode':'SESSION_CLOSE_FROZEN','close_hard_freeze':True,'ranking_writers':'STOPPED','event_writers':'STOPPED','last_build_error':self.last_build_error,'last_build_error_at':self.last_build_error_at})
                    snap={'type':'snapshot','version':SETTINGS.version,'generated_at':now,'feed_state':self.state.feed_state.value,'generation':self.generation+1,'phase':phase,'feed':dict(self.state.ws_status),'load_mode':self.state.load_mode,'telemetry':dict(self.state.telemetry),'boards':boards,'signal_history':copy.deepcopy(frozen_source.get('signal_history') or []),'candidate_count':candidate_count,'hot_count':hot_count,'pinned_count':pinned_count,'board_slots':SETTINGS.board_slots,'delivery':delivery}
                    with self.lock:
                        prev_snap=self.snapshot;self.generation+=1;self.snapshot=snap
                    self._refresh_wire(prev_snap,snap);self.last_build_ok_at=now;self.last_build_error='';return True
            with self.state.lock:cands=list(self.state.candidates.values());hot_count=len(self.state.hot_codes);pinned_count=len(self.state.pinned_codes)
            fresh=[c for c in cands if self.projection.has_live(c,now)]
            edge_cache={}
            def edge_for(c,venue=None):
                key=(c.code,venue.value if venue in (Venue.KRX,Venue.NXT) else 'CUR')
                if key not in edge_cache:edge_cache[key]=early_edge(c,venue,now)
                return edge_cache[key]
            # R48 BOARD INDEPENDENCE: PREBUY is an entry-proximity board, not another
            # copy of the PRE-IGNITION/EARLY-EDGE discovery board.  It may therefore
            # legitimately contain fewer than 10 names.  Official ENTRY_V18 remains
            # authoritative and unchanged; this is display/ranking only.
            pre_source=fresh if active else [c for c in cands if c.current().last_price>0 or c.live_track_pin or c.last_signal]
            entry_rank={'BUY':6,'DIRECT_ARM':5,'REACCEL':4,'PULLBACK':3,'PRESSURE_BUILD':2,'DISCOVERY':0}
            def entry_proximity(c):
                v=c.current();m=v.metrics or {};state=c.entry_state
                bp=float(m.get('buy_pressure') or 0);algo=float(m.get('algo_persistence') or 0)
                acc=float(m.get('volume_accel') or 1);vgap=abs(float(m.get('micro_vwap_gap') or 0));imp=abs(float(m.get('impulse_60s') or 0))
                base={ 'BUY':100,'DIRECT_ARM':92,'REACCEL':86,'PULLBACK':78,'PRESSURE_BUILD':70}.get(state,0)
                near=max(0,min(18,(float(v.score or 0)-55)*.6))+max(0,min(8,(bp-54)*.45))+max(0,min(6,(algo-48)*.25))
                near+=max(0,min(4,(acc-1)*2.0)) if bool(m.get('volume_accel_ready')) else 0
                near+=3 if vgap<=1.2 else 0;near+=2 if imp<=2.5 else 0
                return round(base+near,2)
            def prebuy_eligible(c):
                v=c.current();m=v.metrics or {};state=c.entry_state
                if state in ('BUY','DIRECT_ARM','REACCEL','PULLBACK','PRESSURE_BUILD'):return True
                # DISCOVERY is admitted only when it is objectively close to ENTRY_V18,
                # never merely because it ranks high on EARLY EDGE.
                return bool(float(v.score or 0)>=58 and float(m.get('buy_pressure') or 0)>=56 and float(m.get('algo_persistence') or 0)>=50 and abs(float(m.get('micro_vwap_gap') or 0))<=1.5 and abs(float(m.get('impulse_60s') or 0))<=2.5)
            pre_rank_all=self._sort([c for c in pre_source if prebuy_eligible(c)],lambda c:(
                entry_rank.get(c.entry_state,0),entry_proximity(c),c.current().score,
                float((c.current().metrics or {}).get('buy_pressure') or 0),
                float((c.current().metrics or {}).get('algo_persistence') or 0),
                c.current().last_tick_at,
            ))
            pre_desired=pre_rank_all[:SETTINGS.board_slots]
            if phase in ('PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK'):
                opening_pool=[c for c in cands if c.origin==Origin.PRIOR_CLOSE or c.lifecycle_state in ('CLOSE_TRACK','PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK')]
            elif phase in ('OPENING_HANDOFF','SHAKEOUT_WATCH','REVERSAL_WINDOW'):
                opening_pool=[c for c in cands if c.lifecycle_state in ('OPENING_HANDOFF','OPENING_ACTIVE','SHAKEOUT_WATCH','REVERSAL_EARLY','BUY_READY','BUY')]
            elif phase=='CLOSE_TRACK':opening_pool=[c for c in cands if c.lifecycle_state=='CLOSE_TRACK']
            else:opening_pool=[c for c in cands if c.lifecycle_state in ('REVERSAL_EARLY','BUY_READY','BUY') and c.origin==Origin.PRIOR_CLOSE]
            opening_rank=self._sort(opening_pool,lambda c:(1 if c.lifecycle_state in ('BUY','BUY_READY') else 0,1 if c.lifecycle_state=='REVERSAL_EARLY' else 0,c.priority_score or c.close_score,c.valid_repeat_count))[:10]
            live_rank=self._sort([c for c in cands if c.entry_state=='BUY' or c.lifecycle_state in ('BUY_READY','REVERSAL_EARLY')],lambda c:(1 if c.entry_state=='BUY' else 0,c.last_buy_at,c.priority_score,c.valid_repeat_count))[:10]
            # R48 NXT SMART-FLOW BOARD: require NXT-specific money-flow evidence.
            # This board must not be a venue-labelled clone of PREBUY/EARLY EDGE.
            nxt_pool=[c for c in cands if (c.venue_state[Venue.NXT].last_tick_at and now-c.venue_state[Venue.NXT].last_tick_at<=SETTINGS.display_fresh_ms/1000+1)] if active else [c for c in cands if c.venue_state[Venue.NXT].last_price>0 or (c.last_signal and c.last_signal.venue==Venue.NXT)]
            def nxt_flow_score(c):
                v=c.venue_state[Venue.NXT];m=v.metrics or {}
                sm=float(m.get('smart_money_realtime_proxy_score') or 0);acc=float(m.get('smart_money_acceleration') or 1)
                bp=float(m.get('buy_pressure') or 0);bp_d=float(m.get('buy_pressure_delta_30s') or 0);prog=float(m.get('program_delta') or 0) if bool(m.get('program_fresh')) else 0
                turn=float(m.get('turnover_accel_30s') or 1) if bool(m.get('turnover_accel_ready')) else 1
                score=max(0,sm)*12+max(0,acc-1)*10+max(0,bp-50)*.8+max(0,bp_d)*.7+max(0,turn-1)*7
                if bool(m.get('sell_to_buy_flip')):score+=18
                if bool(m.get('smart_money_realtime_proxy_surge')):score+=22
                if prog>0:score+=8
                # Small headroom credit only; EARLY EDGE is not the primary rank here.
                score+=edge_for(c,Venue.NXT)['headroom_score']*.15
                return round(score,2)
            def nxt_flow_eligible(c):
                m=c.venue_state[Venue.NXT].metrics or {}
                evidence=0
                evidence+=1 if bool(m.get('smart_money_realtime_proxy_surge')) else 0
                evidence+=1 if bool(m.get('sell_to_buy_flip')) else 0
                evidence+=1 if float(m.get('smart_money_realtime_proxy_score') or 0)>=1.2 else 0
                evidence+=1 if float(m.get('smart_money_acceleration') or 1)>=1.25 else 0
                evidence+=1 if bool(m.get('program_fresh')) and float(m.get('program_delta') or 0)>0 else 0
                evidence+=1 if float(m.get('buy_pressure') or 0)>=58 and float(m.get('buy_pressure_delta_30s') or 0)>=3 else 0
                return evidence>=2
            nxt_rank_all=self._sort([c for c in nxt_pool if nxt_flow_eligible(c)],lambda c:(
                nxt_flow_score(c),1 if (c.venue_state[Venue.NXT].metrics or {}).get('smart_money_realtime_proxy_surge') else 0,
                float((c.venue_state[Venue.NXT].metrics or {}).get('smart_money_realtime_proxy_score') or 0),
                float((c.venue_state[Venue.NXT].metrics or {}).get('smart_money_acceleration') or 1),
                c.venue_state[Venue.NXT].last_tick_at,
            ))
            nxt_desired=nxt_rank_all[:SETTINGS.board_slots]
            # NXT signal management is a live-strength board, not a lifetime-repeat leaderboard.
            # EARLY EDGE / headroom / current NXT flow lead; cumulative repeats are tie-break only.
            nxt_mgmt_rank=self._sort([c for c in cands if c.live_track_pin and c.last_signal and c.last_signal.venue==Venue.NXT],lambda c:(
                edge_for(c,Venue.NXT)['score'],edge_for(c,Venue.NXT)['headroom_score'],
                1 if c.venue_state[Venue.NXT].metrics.get('sell_to_buy_flip') else 0,
                float(c.venue_state[Venue.NXT].metrics.get('smart_money_acceleration') or 0),
                float(c.venue_state[Venue.NXT].metrics.get('smart_money_realtime_proxy_score') or 0),
                c.last_signal.signal_time if c.last_signal else 0,c.priority_score,c.valid_repeat_count,
            ))[:10]
            pre_urgent={c.code for c in pre_desired if c.entry_state in ('BUY','DIRECT_ARM','REACCEL')}
            nxt_urgent={c.code for c in nxt_desired if bool((c.venue_state[Venue.NXT].metrics or {}).get('smart_money_realtime_proxy_surge')) or bool((c.venue_state[Venue.NXT].metrics or {}).get('sell_to_buy_flip'))}
            pre=self._stabilize('prebuy',pre_desired,now,pre_urgent,rank_score=entry_proximity);opening=self._stabilize('opening',opening_rank,now,{c.code for c in opening_rank if c.lifecycle_state in ('BUY_READY','BUY')});live_buy=self._stabilize('live_buy',live_rank,now,{c.code for c in live_rank if c.entry_state=='BUY'});nxt=self._stabilize('nxt_early',nxt_desired,now,nxt_urgent,rank_score=nxt_flow_score);nxt_mgmt=self._stabilize('nxt_management',nxt_mgmt_rank,now)
            buys=[c for c in cands if c.last_buy_price and c.last_buy_venue in (Venue.KRX,Venue.NXT)];by={c.code:c for c in buys};old_pos=self.stable_codes.get('position_manager',[]);pos=[by[x] for x in old_pos if x in by]
            pos_codes={x.code for x in pos}
            for c in sorted(buys,key=lambda x:x.last_buy_at):
                if c.code not in pos_codes:pos.append(c);pos_codes.add(c.code)
            pos=pos[:SETTINGS.board_slots];self.stable_codes['position_manager']=[c.code for c in pos]
            # TOP10 membership is a live-session writer.  Never create ENTER/EXIT/REENTER
            # history or increment reentry counters after the market is closed.
            if active:
                for name,rows in {'prebuy':pre,'opening':opening,'live_buy':live_buy,'nxt_early':nxt,'nxt_management':nxt_mgmt}.items():self.top10.apply(name,rows,self.state.candidates)
            boards={'prebuy':[self.top10.decorate('prebuy',self.projection.row(c,now,allow_frozen=not active,compact=True),c) for c in pre],'opening':[self.top10.decorate('opening',self.projection.row(c,now,Venue.NXT if c.origin==Origin.PRIOR_CLOSE else Venue.UNKNOWN,False,not active,True),c) for c in opening],'live_buy':[self.top10.decorate('live_buy',self.projection.row(c,now,c.last_buy_venue if c.last_buy_venue in (Venue.KRX,Venue.NXT) else Venue.UNKNOWN,False,not active,True),c) for c in live_buy],'nxt_early':[self.top10.decorate('nxt_early',self.projection.row(c,now,Venue.NXT,True,not active,True),c) for c in nxt],'nxt_management':[self.top10.decorate('nxt_management',self.projection.row(c,now,Venue.NXT,True,not active,True),c) for c in nxt_mgmt],'position_manager':[self.projection.row(c,now,c.last_buy_venue,True,not active,True) for c in pos]}
            for i,(row,c) in enumerate(zip(boards['prebuy'],pre)):
                e=edge_for(c);row.update(self._decorate_discovery_meta(row,c,e,now));row['rank_score']=entry_proximity(c);row['rank_basis']='ENTRY_PROXIMITY';row['early_edge_stage']=e['stage'];row['headroom_score']=e['headroom_score'];row['chase_penalty']=e['penalty'];row['board_contract']='BUY_PRE_ENTRY_ONLY';boards['prebuy'][i]=row
            for i,(row,c) in enumerate(zip(boards['nxt_early'],nxt)):
                e=edge_for(c,Venue.NXT);row.update(self._decorate_discovery_meta(row,c,e,now));row['rank_score']=nxt_flow_score(c);row['rank_basis']='NXT_SMART_FLOW';row['early_edge_stage']=e['stage'];row['headroom_score']=e['headroom_score'];row['chase_penalty']=e['penalty'];row['board_contract']='NXT_FLOW_EVIDENCE_2PLUS';boards['nxt_early'][i]=row
            projection_rows=[row for rows in boards.values() for row in rows];self.state.telemetry['display_projection_fallback_rows']=sum(1 for row in projection_rows if row.get('display_venue_fallback'));self.state.telemetry['display_projection_stale_rows']=sum(1 for row in projection_rows if row.get('display_stale'))
            for row,c in zip(boards['opening'],opening):
                if not row.get('price') and c.close_signal_price:row['reference_price']=c.close_signal_price;row['reference_price_type']='PRIOR_CLOSE'
            # Outside all continuous venues the dashboard becomes a frozen session-close view.
            # Merge the last committed board with runtime-restored candidate truth, choosing the
            # richer row per symbol.  Frozen values are explicitly labelled and never qualify signals.
            if not active:
                with self.lock:fb=dict(self.fallback)
                fb_boards=(fb.get('boards') or {}) if isinstance(fb,dict) else {}
                for k in boards:boards[k]=self._merge_frozen_board(boards[k],fb_boards.get(k) or [])
            self._observe_ui_latency(pre);self._observe_ui_latency(live_buy);self._observe_ui_latency(nxt,Venue.NXT)
            history=[]
            for c in cands:
                for e in list(c.history)[-4:]:history.append({'code':c.code,'name':c.name or c.code,'at':e.at,'state':e.state,'kind':e.kind,'price':e.price,'venue':e.venue.value,'reason':e.reason})
            history.sort(key=lambda x:x['at'],reverse=True)
            delivery={'bridge':'LIVE_BRIDGE_V2_TOP10_DELTA','source':source,'display_task_alive':True,'market_active':active,'display_mode':'LIVE' if active else 'SESSION_CLOSE_FROZEN','last_build_error':self.last_build_error,'last_build_error_at':self.last_build_error_at}
            snap={'type':'snapshot','version':SETTINGS.version,'generated_at':now,'feed_state':self.state.feed_state.value,'generation':self.generation+1,'phase':phase,'feed':dict(self.state.ws_status),'load_mode':self.state.load_mode,'telemetry':dict(self.state.telemetry),'boards':boards,'signal_history':history[:30],'candidate_count':len(cands),'hot_count':hot_count,'pinned_count':pinned_count,'board_slots':SETTINGS.board_slots,'delivery':delivery}
            with self.lock:
                prev_snap=self.snapshot;self.generation+=1;self.snapshot=snap
                # Keep the exact latest live board in memory so the 20:00 close transition freezes
                # the immediately preceding display rather than the fallback loaded at process start.
                if active:self.fallback=snap
            self._refresh_wire(prev_snap,snap);self.last_build_ok_at=now;self.last_build_error='';return True
        except Exception as e:
            self.last_build_error=f'{type(e).__name__}: {e}'[:240];self.last_build_error_at=time.time();self.state.telemetry['display_build_error_count']=int(self.state.telemetry.get('display_build_error_count') or 0)+1;self.state.ws_status['display_error']=self.last_build_error;return False
        finally:self.build_lock.release()
    async def run(self):
        while True:
            self.build(source='BACKGROUND',blocking=False)
            await asyncio.sleep(max(.1,SETTINGS.ui_delta_ms/1000))
