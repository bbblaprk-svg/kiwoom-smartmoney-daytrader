from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


def _i(name: str, default: int) -> int:
    try: return int(os.getenv(name, str(default)))
    except Exception: return default

def _f(name: str, default: float) -> float:
    try: return float(os.getenv(name, str(default)))
    except Exception: return default

def _b(name:str, default:bool=False)->bool:
    raw=os.getenv(name, '1' if default else '0').strip().lower()
    return raw in ('1','true','yes','y','on')

@dataclass(frozen=True, slots=True)
class Settings:
    version: str = 'NOVA-3.3.6-R493-MARKET-RELATIVE-SAFE'
    api_base: str = 'https://api.kiwoom.com'
    ws_url: str = 'wss://api.kiwoom.com:10000/api/dostk/websocket'
    app_key: str = os.getenv('KIWOOM_APP_KEY','').strip()
    secret: str = (os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
    # UI authentication uses a dedicated optional token and is disabled by default.
    ui_access_token: str = os.getenv('NOVA_UI_ACCESS_TOKEN','').strip()
    data_dir: Path = Path(os.getenv('NOVA_DATA_DIR', str(BASE/'data'/'nova30')))
    legacy_data_dir: Path = Path(os.getenv('NOVA_LEGACY_DATA_DIR', str(BASE/'data')))
    hot_target: int = _i('NOVA_HOT_TARGET', 50)
    hot_min: int = min(40,max(10,_i('NOVA_HOT_MIN', 20)))
    hot_max: int = min(90,max(20,_i('NOVA_HOT_MAX', 60)))
    max_candidates: int = min(1200,max(200,_i('NOVA_MAX_CANDIDATES', 1200)))
    fresh_ms: int = _i('NOVA_FRESH_MS', 3500)
    display_fresh_ms: int = _i('NOVA_DISPLAY_FRESH_MS', 8000)
    trade_queue_per_shard: int = min(1024,max(128,_i('NOVA_TRADE_QUEUE_PER_SHARD', 1024)))
    trade_shards: int = min(8,max(1,_i('NOVA_TRADE_SHARDS', 4)))
    score_interval_ms: int = _i('NOVA_SCORE_INTERVAL_MS', 100)
    critical_signal_queue_max: int = min(16384,max(512,_i('NOVA_CRITICAL_SIGNAL_QUEUE_MAX', 4096)))
    ui_delta_ms: int = _i('NOVA_UI_DELTA_MS', 250)
    board_slots: int = min(10,max(5,_i('NOVA_BOARD_SLOTS', 10)))
    # R4.2 discovery-board display hysteresis: data keeps updating continuously;
    # only row membership/order is held briefly to prevent visual thrash.
    discovery_display_hold_sec: float = max(10.0,min(45.0,_f('NOVA_DISCOVERY_DISPLAY_HOLD_SEC', 20.0)))
    discovery_display_immediate_gap: float = max(2.0,min(12.0,_f('NOVA_DISCOVERY_DISPLAY_IMMEDIATE_GAP', 5.0)))
    discovery_anchor_slots: int = min(8,max(4,_i('NOVA_DISCOVERY_ANCHOR_SLOTS', 6)))
    discovery_fresh_slots: int = min(6,max(2,_i('NOVA_DISCOVERY_FRESH_SLOTS', 4)))
    # R49 PRE-IGNITION signal-acceleration board: live data continues updating,
    # while membership/order commits only every 30s with a 60s minimum dwell.
    signal_accel_slots: int = min(20,max(10,_i('NOVA_SIGNAL_ACCEL_SLOTS', 20)))
    signal_accel_rank_sec: float = max(20.0,min(60.0,_f('NOVA_SIGNAL_ACCEL_RANK_SEC', 30.0)))
    signal_accel_min_dwell_sec: float = max(30.0,min(180.0,_f('NOVA_SIGNAL_ACCEL_MIN_DWELL_SEC', 60.0)))
    signal_accel_entry_gap: float = max(1.0,min(10.0,_f('NOVA_SIGNAL_ACCEL_ENTRY_GAP', 3.0)))
    signal_accel_signal_ttl_sec: float = max(300.0,min(1800.0,_f('NOVA_SIGNAL_ACCEL_SIGNAL_TTL_SEC', 900.0)))
    signal_accel_entry_fresh_sec: float = max(60.0,min(300.0,_f('NOVA_SIGNAL_ACCEL_ENTRY_FRESH_SEC', 180.0)))
    # R49.1 pre-formal LIVE-EVIDENCE lane. A continuously strong episode may stay on
    # the display board for at most 10 minutes; a 60s evidence gap rearms a new episode.
    signal_accel_live_episode_sec: float = max(180.0,min(900.0,_f('NOVA_SIGNAL_ACCEL_LIVE_EPISODE_SEC', 600.0)))
    signal_accel_live_reset_sec: float = max(30.0,min(180.0,_f('NOVA_SIGNAL_ACCEL_LIVE_RESET_SEC', 60.0)))
    # R492 SAFE EXTENSION. Display/verification only; never mutates ENTRY_V18 or broker subscriptions.
    r492_extension_enabled: bool = _b('NOVA_R492_EXTENSION_ENABLED', True)
    r492_fresh_slots: int = min(6,max(2,_i('NOVA_R492_FRESH_SLOTS', 4)))
    r492_fresh_lane_sec: int = min(1800,max(300,_i('NOVA_R492_FRESH_LANE_SEC', 1200)))
    r492_shared_pool_cap: int = min(60,max(20,_i('NOVA_R492_SHARED_POOL_CAP', 40)))
    r492_energy_candidate_cap: int = min(40,max(10,_i('NOVA_R492_ENERGY_CANDIDATE_CAP', 25)))
    r492_path_candidate_cap: int = min(50,max(10,_i('NOVA_R492_PATH_CANDIDATE_CAP', 30)))
    r492_energy_rank_sec: float = max(20.0,min(90.0,_f('NOVA_R492_ENERGY_RANK_SEC', 30.0)))
    r492_energy_min_dwell_sec: float = max(30.0,min(180.0,_f('NOVA_R492_ENERGY_MIN_DWELL_SEC', 90.0)))
    r492_energy_entry_gap: float = max(2.0,min(12.0,_f('NOVA_R492_ENERGY_ENTRY_GAP', 5.0)))
    r492_path_rank_sec: float = max(120.0,min(900.0,_f('NOVA_R492_PATH_RANK_SEC', 300.0)))
    r492_path_min_dwell_sec: float = max(300.0,min(1800.0,_f('NOVA_R492_PATH_MIN_DWELL_SEC', 900.0)))
    r492_path_entry_gap: float = max(2.0,min(12.0,_f('NOVA_R492_PATH_ENTRY_GAP', 4.0)))
    # R493 MARKET RELATIVE SAFE. Low-frequency KOSPI/KOSDAQ context only; no new WS type.
    r493_market_index_enabled: bool = _b('NOVA_R493_MARKET_INDEX_ENABLED', True)
    r493_market_index_sec: float = max(45.0,min(180.0,_f('NOVA_R493_MARKET_INDEX_SEC', 60.0)))
    r493_market_index_busy_sec: float = max(90.0,min(300.0,_f('NOVA_R493_MARKET_INDEX_BUSY_SEC', 120.0)))
    r493_market_context_ttl_sec: float = max(90.0,min(300.0,_f('NOVA_R493_MARKET_CONTEXT_TTL_SEC', 150.0)))
    r493_pre_market_adj_cap: float = max(0.0,min(4.0,_f('NOVA_R493_PRE_MARKET_ADJ_CAP', 3.0)))
    r493_energy_market_adj_cap: float = max(0.0,min(6.0,_f('NOVA_R493_ENERGY_MARKET_ADJ_CAP', 5.0)))
    r493_path_market_adj_cap: float = max(0.0,min(4.0,_f('NOVA_R493_PATH_MARKET_ADJ_CAP', 3.0)))
    fresh_scout_fast_sec: int = min(120,max(60,_i('NOVA_FRESH_SCOUT_FAST_SEC', 90)))
    fresh_scout_window_sec: int = min(300,max(120,_i('NOVA_FRESH_SCOUT_WINDOW_SEC', 180)))
    journal_noncritical_max: int = min(4096,max(256,_i('NOVA_JOURNAL_NONCRITICAL_MAX', 4096)))
    journal_important_max: int = min(1024,max(128,_i('NOVA_JOURNAL_IMPORTANT_MAX', 1024)))
    journal_critical_max: int = min(512,max(64,_i('NOVA_JOURNAL_CRITICAL_MAX', 256)))
    hard_stall_sec: float = _f('NOVA_HARD_STALL_SEC', 15.0)
    hard_stall_grace_sec: float = _f('NOVA_HARD_STALL_GRACE_SEC', 30.0)
    wal_hard_stall_sec: float = _f('NOVA_WAL_HARD_STALL_SEC', 8.0)
    event_wal_hard_stall_sec: float = _f('NOVA_EVENT_WAL_HARD_STALL_SEC', 8.0)
    rest_pace_sec: float = max(0.205,_f('NOVA_REST_PACE_SEC', 0.225))
    rest_max_inflight: int = min(4,max(1,_i('NOVA_REST_MAX_INFLIGHT', 4)))
    discovery_sec: int = _i('NOVA_DISCOVERY_SEC', 8)
    discovery_source_ttl_sec: int = _i('NOVA_DISCOVERY_SOURCE_TTL_SEC', 180)
    ws_reg_budget: int = _i('NOVA_WS_REG_BUDGET', 120)
    # Keep a safety margin below Kiwoom's 200-stock realtime session ceiling.
    # A code can be registered on both KRX and NXT during the dual venue window.
    ws_session_item_cap: int = min(180,max(2,_i('NOVA_WS_SESSION_ITEM_CAP', 180)))
    ws_trade_per_venue: int = _i('NOVA_WS_TRADE_PER_VENUE', 60)
    ws_program_cap: int = _i('NOVA_WS_PROGRAM_CAP', 15)
    ws_orderbook_cap: int = _i('NOVA_WS_ORDERBOOK_CAP', 10)
    rss_soft_mb: int = min(340,max(160,_i('NOVA_RSS_SOFT_MB', 320)))
    rss_hard_mb: int = min(400,max(220,_i('NOVA_RSS_HARD_MB', 400)))
    offline: bool = _b('NOVA_OFFLINE', False)
    candidate_mode: bool = _b('NOVA_CANDIDATE_MODE', False)
    warm_sec: int = _i('NOVA_WARM_SEC', 60)
    warm_signal_min_sec: float = max(5.0,_f('NOVA_WARM_SIGNAL_MIN_SEC', 30.0))
    resync_enabled: bool = _b('NOVA_RESYNC_ENABLED', True)
    resync_api_path: str = os.getenv('NOVA_RESYNC_API_PATH','/api/dostk/mrkcond').strip() or '/api/dostk/mrkcond'
    resync_api_id: str = os.getenv('NOVA_RESYNC_API_ID','ka10004').strip() or 'ka10004'
    resync_batch_cap: int = min(30,max(1,_i('NOVA_RESYNC_BATCH_CAP', 12)))
    resync_interval_sec: float = max(1.0,_f('NOVA_RESYNC_INTERVAL_SEC', 2.0))
    candidate_ttl_sec: int = _i('NOVA_CANDIDATE_TTL_SEC', 900)
    fast_window_idle_sec: int = min(300,max(60,_i('NOVA_FAST_WINDOW_IDLE_SEC', 180)))
    event_log_max_mb: int = min(512,max(8,_i('NOVA_EVENT_LOG_MAX_MB', 64)))
    event_log_keep: int = min(10,max(1,_i('NOVA_EVENT_LOG_KEEP', 4)))
    formal_retention_days: int = min(730,max(30,_i('NOVA_FORMAL_RETENTION_DAYS', 180)))
    history_retention_days: int = min(180,max(7,_i('NOVA_HISTORY_RETENTION_DAYS', 30)))
    disk_min_free_mb: int = min(4096,max(128,_i('NOVA_DISK_MIN_FREE_MB', 512)))
    performance_watch_cap: int = _i('NOVA_PERFORMANCE_WATCH_CAP', 40)
    max_profit_scan_ms: int = min(2000,max(250,_i('NOVA_MAX_PROFIT_SCAN_MS', 500)))
    max_profit_sample_cap: int = min(5000,max(300,_i('NOVA_MAX_PROFIT_SAMPLE_CAP', 1000)))
    # Bounded exploration reuses ranking results already fetched by DiscoveryEngine.
    # It may consume only spare TRADE slots and never receives extra program/orderbook feeds.
    exploration_enabled: bool = _b('NOVA_EXPLORATION_ENABLED', True)
    exploration_slots_normal: int = min(12,max(0,_i('NOVA_EXPLORATION_SLOTS_NORMAL', 8)))
    exploration_slots_busy: int = min(8,max(0,_i('NOVA_EXPLORATION_SLOTS_BUSY', 4)))
    exploration_slots_high: int = min(4,max(0,_i('NOVA_EXPLORATION_SLOTS_HIGH', 2)))
    exploration_rotate_sec: int = min(120,max(16,_i('NOVA_EXPLORATION_ROTATE_SEC', 24)))
    exploration_min_dwell_sec: int = min(300,max(45,_i('NOVA_EXPLORATION_MIN_DWELL_SEC', 72)))
    exploration_max_hold_sec: int = min(900,max(120,_i('NOVA_EXPLORATION_MAX_HOLD_SEC', 300)))
    exploration_cooldown_sec: int = min(900,max(60,_i('NOVA_EXPLORATION_COOLDOWN_SEC', 180)))
    exploration_rotation_batch: int = min(4,max(1,_i('NOVA_EXPLORATION_ROTATION_BATCH', 2)))

SETTINGS = Settings()


def exploration_slots_for_mode(mode:str)->int:
    if not SETTINGS.exploration_enabled:
        return 0
    return {
        'NORMAL':SETTINGS.exploration_slots_normal,
        'BUSY':SETTINGS.exploration_slots_busy,
        'HIGH_LOAD':SETTINGS.exploration_slots_high,
        'CRITICAL':0,
    }.get(str(mode or 'NORMAL'),0)


def effective_ws_code_budget()->int:
    # Reserve against the worst-case dual-venue window so a later session transition cannot
    # strand more pinned signals than the socket can legally keep subscribed.
    return max(1,min(SETTINGS.ws_reg_budget,SETTINGS.ws_session_item_cap//2))
