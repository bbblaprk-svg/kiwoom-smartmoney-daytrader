from __future__ import annotations

import copy
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.domain import Candidate, Venue
from app.runtime.clock import KST, sessions, trade_day
from app.config import SETTINGS
from app.signal.early_edge import discovery_freshness, early_edge
from app.addons.energy_path import EnergyPathEngine
from app.addons.market_relative import market_overlay
from app.addons.signal_acceleration import (
    signal_windows_legacy as _signal_windows, legacy_accel_metrics as _accel_metrics,
    legacy_accel_label as _accel_label, pre_row as _pre_row,
)

# Operator-defined liquid large-cap swing universe.  This is intentionally metadata only:
# it does not call a broker, change subscriptions, or claim to calculate live market cap.
_DEFAULT_LARGECAP = {
    '005930':'삼성전자','000660':'SK하이닉스','373220':'LG에너지솔루션','207940':'삼성바이오로직스',
    '005380':'현대차','000270':'기아','068270':'셀트리온','005490':'POSCO홀딩스','035420':'NAVER','035720':'카카오',
    '012450':'한화에어로스페이스','105560':'KB금융','055550':'신한지주','086790':'하나금융지주','316140':'우리금융지주',
    '028260':'삼성물산','032830':'삼성생명','012330':'현대모비스','009150':'삼성전기','066570':'LG전자','051910':'LG화학',
    '006400':'삼성SDI','003670':'포스코퓨처엠','010130':'고려아연','096770':'SK이노베이션','034020':'두산에너빌리티',
    '042660':'한화오션','329180':'HD현대중공업','267260':'HD현대일렉트릭','047810':'한국항공우주','034730':'SK','003550':'LG',
    '015760':'한국전력','017670':'SK텔레콤','030200':'KT','259960':'크래프톤','352820':'하이브','018260':'삼성에스디에스',
    '010950':'S-Oil','011200':'HMM','090430':'아모레퍼시픽','161390':'한국타이어앤테크놀로지','011070':'LG이노텍',
    '000810':'삼성화재','024110':'기업은행','138040':'메리츠금융지주','323410':'카카오뱅크','247540':'에코프로비엠',
    '086520':'에코프로','196170':'알테오젠','005940':'NH투자증권','006800':'미래에셋증권','000720':'현대건설',
}


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v if v is not None else default)
    except Exception:
        return default


def _round_price(x: float) -> float:
    # Display-only approximation of Korean equity tick sizing.  It is deliberately conservative;
    # the broker/exchange remains the execution source of truth.
    if x <= 0:
        return 0.0
    if x < 2_000: tick = 1
    elif x < 5_000: tick = 5
    elif x < 20_000: tick = 10
    elif x < 50_000: tick = 50
    elif x < 200_000: tick = 100
    elif x < 500_000: tick = 500
    else: tick = 1_000
    return round(x / tick) * tick


def _universe() -> dict[str, str]:
    out = dict(_DEFAULT_LARGECAP)
    raw = os.getenv('NOVA_LARGECAP_CODES', '').strip()
    if raw:
        for part in raw.split(','):
            code = part.strip().split(':', 1)[0].strip()
            if len(code) == 6 and code.isdigit():
                out.setdefault(code, code)
    return out


def _fresh_row(c: Candidate, now: float, max_age: float = 9.0) -> tuple[Venue, Any, dict[str, Any], bool]:
    v = c.current()
    m = v.metrics or {}
    age = now - _f(v.last_tick_at) if v.last_tick_at else 10**9
    fresh = bool(v.last_price > 0 and age <= max_age and not v.continuity_reason and not v.resync_required and m.get('fresh', True))
    return v.venue, v, m, fresh


def _session_close_reference(venue: Venue, day: str | None = None) -> float:
    d = datetime.strptime(day or trade_day(), '%Y%m%d').replace(tzinfo=KST)
    if venue == Venue.KRX:
        d = d.replace(hour=15, minute=30, second=0, microsecond=0)
    else:
        d = d.replace(hour=20, minute=0, second=0, microsecond=0)
    return d.timestamp()


def _reference_fresh(v: Any, ref_at: float, max_age: float = 600.0) -> bool:
    if not v.last_tick_at or v.last_price <= 0:
        return False
    age = ref_at - _f(v.last_tick_at)
    # Historical close reconstruction must not reuse the *current* freshness flag, which is
    # expected to be false after the session. Validate the frozen tick against the venue close.
    return bool(-60.0 <= age <= max_age and not v.continuity_reason and not v.resync_required)



def _entry_plan(price: float, m: dict[str, Any]) -> dict[str, float | None]:
    if price <= 0:
        return {'entry_low':None,'entry_high':None,'chase_limit':None,'stop':None,'t1':None,'t2':None}
    svwap = _f(m.get('session_vwap'))
    vgap = _f(m.get('session_vwap_gap'))
    if svwap <= 0 and abs(vgap) < 20:
        svwap = price / (1 + vgap / 100) if (1 + vgap / 100) > 0 else 0
    anchor = svwap if svwap > 0 and abs(price / svwap - 1) <= .035 else price
    low = max(price * .985, anchor * .995)
    high = min(price * 1.002, anchor * 1.006)
    if low > high:
        low, high = price * .994, price * 1.002
    mid = (low + high) / 2
    return {
        'entry_low':_round_price(low),'entry_high':_round_price(high),'chase_limit':_round_price(max(high * 1.012, price * 1.008)),
        'stop':_round_price(mid * .96),'t1':_round_price(mid * 1.06),'t2':_round_price(mid * 1.10),
    }


def _largecap_score(c: Candidate, m: dict[str, Any], fresh: bool) -> tuple[float, list[str], dict[str, Any]]:
    edge=early_edge(c,now=time.time())
    base=_f(c.score);conf=_f(c.confidence);rate=_f(c.current().last_rate)
    # R4 LARGE-CAP is no longer a cumulative-strength rank.  EARLY EDGE dominates,
    # while frozen official score/confidence remain secondary confirmation only.
    score=edge['score']*.68+base*.18+conf*.06+_clamp(c.rest_base*.08,0,6)+min(2.0,c.valid_repeat_count*.12)
    if edge['chase_block']:score=min(score,49.0)
    if rate>5.5:score-=min(16,(rate-5.5)*3.0)
    if not fresh:score=min(score,39)
    reasons=list(edge.get('reasons') or [])
    if edge['headroom_score']>=18:reasons.append(f"상승여력 {edge['headroom_score']:.0f}/25")
    if c.valid_repeat_count:reasons.append(f'반복 {c.valid_repeat_count} (보조)')
    return round(_clamp(score),1),reasons[:4],edge

def _largecap_row(c: Candidate, now: float, active: bool, names: dict[str, str], reference_at: float | None = None, *, allow_data_wait: bool = False) -> dict[str, Any] | None:
    venue, v, m, live_fresh = _fresh_row(c, now)
    ref_at = now if active else (reference_at or _session_close_reference(venue))
    if v.last_price <= 0 and not allow_data_wait:
        return None
    fresh = (live_fresh if active else _reference_fresh(v, ref_at)) if v.last_price > 0 else False
    score, reasons, edge = _largecap_score(c, m, fresh)
    bp = _f(m.get('buy_pressure'), 50); acc = _f(m.get('volume_accel'), 1); vgap = _f(m.get('session_vwap_gap'))
    rate = _f(v.last_rate)
    if v.last_price <= 0 or not fresh:
        decision = 'DATA_WAIT'
    elif edge['chase_block'] or rate > 5.5:
        decision = 'AVOID'
    elif score >= 72 and -1.5 <= rate <= 4.5 and edge['headroom_score'] >= 14 and bp >= 52 and vgap >= -.70:
        decision = 'NOW'
    elif score >= 56 and rate <= 5.0:
        decision = 'WAIT'
    else:
        decision = 'AVOID'
    plan = _entry_plan(_f(v.last_price), m) if decision in ('NOW','WAIT') else {'entry_low':None,'entry_high':None,'chase_limit':None,'stop':None,'t1':None,'t2':None}
    if decision == 'DATA_WAIT':
        reasons = (['현재가/연속성 DATA WAIT'] + reasons)[:4]
    return {
        'code':c.code,'name':c.name or names.get(c.code) or c.code,'venue':venue.value,'price':v.last_price or None,'change_rate':v.last_rate if v.last_price > 0 else None,
        'score':score,'decision':decision,'coverage_status':'CORE','decision_mode':'LIVE' if active else 'CLOSE','frozen':not active,'reference_at':ref_at,
        'fresh':fresh,'last_tick_at':v.last_tick_at,'valid_repeat_count':c.valid_repeat_count,
        'entry_state':c.entry_state,'lifecycle_state':c.lifecycle_state,'buy_pressure':round(bp,1),'volume_accel':round(acc,2),
        'vwap_gap':round(vgap,2),'smart_money_score':round(_f(m.get('smart_money_realtime_proxy_score')),1),'reasons':reasons,
        'early_edge_score':edge['score'],'early_edge_stage':edge['stage'],'headroom_score':edge['headroom_score'],'chase_penalty':edge['penalty'],
        'fresh_age_sec':edge.get('fresh_age_sec'),'fresh_label':edge.get('fresh_label',''),'fast_scout':bool(edge.get('fast_scout')),
        'rank_trend':edge.get('rank_trend','FLAT'),'rank_velocity':edge.get('rank_velocity',0.0),'fresh_window':bool(edge.get('fresh_window')),
        'rank_lane':'FRESH' if edge.get('fresh_window') else 'ANCHOR',
        **plan,
    }


def _market_backfill_row(c: Candidate, now: float, active: bool, names: dict[str, str]) -> dict[str, Any] | None:
    """Display-only fill row used only when the operator large-cap pool has fewer than 10 live candidates.

    It never promotes the official BUY state, never changes broker subscriptions, and intentionally
    suppresses entry/stop/target values so a market-wide fallback cannot be mistaken for a large-cap BUY.
    """
    row = _largecap_row(c, now, active, names)
    if not row:
        return None
    row = dict(row)
    row['coverage_status'] = 'MARKET_BACKFILL'
    row['decision'] = 'REFERENCE'
    row['entry_low'] = row['entry_high'] = row['chase_limit'] = None
    row['stop'] = row['t1'] = row['t2'] = None
    row['reasons'] = (['시장보완 · 공식 BUY 미반영'] + list(row.get('reasons') or []))[:4]
    return row



@dataclass(slots=True)
class DecisionPanelEngine:
    state: Any
    cache_ttl: float = 0.75
    _cache_at: float = 0.0
    _cache: dict[str, Any] | None = None
    _last_live_largecap: list[dict[str, Any]] = field(default_factory=list)
    _last_live_pre: list[dict[str, Any]] = field(default_factory=list)
    _last_live_at: float = 0.0
    _stable_large_codes: list[str] = field(default_factory=list)
    _stable_pre_codes: list[str] = field(default_factory=list)
    _last_large_rank_at: float = 0.0
    _last_pre_rank_at: float = 0.0
    _pre_entered_at: dict[str, float] = field(default_factory=dict)
    _live_evidence_started_at: dict[str, float] = field(default_factory=dict)
    _live_evidence_last_ok_at: dict[str, float] = field(default_factory=dict)
    _energy_path: Any = field(init=False)

    def __post_init__(self):
        self._energy_path=EnergyPathEngine(self.state)

    @staticmethod
    def _freeze_rows(rows: list[dict[str, Any]], mode_key: str, mode_value: str, ref_at: float) -> list[dict[str, Any]]:
        out=copy.deepcopy(rows)
        for r in out:
            r['frozen']=True;r['reference_at']=ref_at;r[mode_key]=mode_value
        return out

    @staticmethod
    def _score_value(row: dict[str, Any]) -> float:
        return _f(row.get('early_edge_score'), _f(row.get('score')))

    @staticmethod
    def _compose_anchor_fresh_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        slots=10;anchor_n=min(SETTINGS.discovery_anchor_slots,slots);fresh_n=min(SETTINGS.discovery_fresh_slots,max(0,slots-anchor_n))
        anchors=[r for r in rows if not r.get('fresh_window')]
        fresh=[r for r in rows if r.get('fresh_window')]
        fresh.sort(key=lambda r:(1 if r.get('fast_scout') else 0,DecisionPanelEngine._score_value(r),_f(r.get('challenge_score')),-(_f(r.get('fresh_age_sec'),1e9))),reverse=True)
        chosen=[];used=set()
        for r in anchors[:anchor_n]:chosen.append(r);used.add(r['code'])
        for r in fresh[:fresh_n]:
            if r['code'] not in used:chosen.append(r);used.add(r['code'])
        for r in rows:
            if r['code'] in used:continue
            chosen.append(r);used.add(r['code'])
            if len(chosen)>=slots:break
        return sorted(chosen[:slots],key=lambda r:(DecisionPanelEngine._score_value(r),_f(r.get('score')),_f(r.get('last_tick_at'))),reverse=True)

    def _stabilize_rows(self,board:str,desired:list[dict[str,Any]],ranked:list[dict[str,Any]],now:float)->list[dict[str,Any]]:
        if board=='large':old=self._stable_large_codes;last=self._last_large_rank_at
        else:old=self._stable_pre_codes;last=self._last_pre_rank_at
        by={r['code']:r for r in ranked};slots=10
        if not old:
            out=desired[:slots]
            if board=='large':self._stable_large_codes=[r['code'] for r in out];self._last_large_rank_at=now
            else:self._stable_pre_codes=[r['code'] for r in out];self._last_pre_rank_at=now
            return out
        existing=[by[c] for c in old if c in by];seen={r['code'] for r in existing}
        for r in desired:
            if r['code'] not in seen and len(existing)<slots:existing.append(r);seen.add(r['code'])
        held=now-last<SETTINGS.discovery_display_hold_sec
        if held and existing:
            weakest_i=min(range(len(existing)),key=lambda i:self._score_value(existing[i]));weak=self._score_value(existing[weakest_i])
            for r in desired:
                if r['code'] in seen:continue
                urgent=bool(r.get('fast_scout') and r.get('early_edge_stage') in ('PRE_BREAKOUT','EARLY_IGNITION'))
                if self._score_value(r)>=weak+SETTINGS.discovery_display_immediate_gap or urgent:
                    seen.discard(existing[weakest_i]['code']);existing[weakest_i]=r;seen.add(r['code'])
                    weakest_i=min(range(len(existing)),key=lambda i:self._score_value(existing[i]));weak=self._score_value(existing[weakest_i])
            out=existing[:slots]
        else:
            out=desired[:slots]
            if board=='large':self._last_large_rank_at=now
            else:self._last_pre_rank_at=now
        if board=='large':self._stable_large_codes=[r['code'] for r in out]
        else:self._stable_pre_codes=[r['code'] for r in out]
        return out

    def _compose_r492_pre_fresh(self, ranked:list[dict[str,Any]], now:float)->list[dict[str,Any]]:
        """Reserve a bounded fresh lane without changing PRE eligibility or official BUY.

        NORMAL keeps 4 of 20 positions available for recently discovered eligible names.
        BUSY uses 3, HIGH_LOAD 2, CRITICAL/R491_SAFE 0. Remaining positions are CORE.
        """
        if not SETTINGS.r492_extension_enabled or str(getattr(self.state,'load_mode','NORMAL'))=='CRITICAL':
            return ranked
        lm=str(getattr(self.state,'load_mode','NORMAL'))
        fresh_slots=SETTINGS.r492_fresh_slots if lm=='NORMAL' else min(3,SETTINGS.r492_fresh_slots) if lm=='BUSY' else min(2,SETTINGS.r492_fresh_slots)
        slots=SETTINGS.signal_accel_slots;fresh=[];core=[]
        for r in ranked:
            age=r.get('discovery_age_sec')
            is_fresh=bool((age is not None and age<=SETTINGS.r492_fresh_lane_sec) or r.get('fast_scout') or r.get('live_evidence_lane'))
            r['r492_lane']='FRESH' if is_fresh else 'CORE'
            (fresh if is_fresh else core).append(r)
        chosen=[];used=set();core_n=max(0,slots-fresh_slots)
        for r in core[:core_n]:chosen.append(r);used.add(r['code'])
        for r in fresh[:fresh_slots]:
            if r['code'] not in used:chosen.append(r);used.add(r['code'])
        for r in ranked:
            if len(chosen)>=slots:break
            if r['code'] not in used:chosen.append(r);used.add(r['code'])
        remaining=[r for r in ranked if r['code'] not in used]
        return chosen+remaining

    def _stabilize_signal_accel(self,ranked:list[dict[str,Any]],now:float)->list[dict[str,Any]]:
        """R49: live metrics refresh continuously; membership/order commits every 30s.

        A row is held at least 60s. After that, a new symbol must beat the weakest
        replaceable row by >=3 points. Stale/ineligible symbols leave immediately,
        so old formal-signal pins cannot occupy the board forever.
        """
        slots=SETTINGS.signal_accel_slots;by={r['code']:r for r in ranked};old=list(self._stable_pre_codes)
        if not old:
            out=ranked[:slots];self._stable_pre_codes=[r['code'] for r in out];self._last_pre_rank_at=now
            self._pre_entered_at={r['code']:now for r in out};return out
        existing=[by[c] for c in old if c in by];seen={r['code'] for r in existing}
        # Stale/ineligible disappearance is immediate; fill vacant capacity with the strongest fresh rows.
        for r in ranked:
            if r['code'] in seen:continue
            if len(existing)>=slots:break
            existing.append(r);seen.add(r['code']);self._pre_entered_at.setdefault(r['code'],now)
        held=now-self._last_pre_rank_at<SETTINGS.signal_accel_rank_sec
        if held:
            self._stable_pre_codes=[r['code'] for r in existing[:slots]]
            self._pre_entered_at={c:t for c,t in self._pre_entered_at.items() if c in self._stable_pre_codes}
            return existing[:slots]
        old_set=set(old)
        # At the 30s boundary, challenge only with materially stronger newcomers.
        for newcomer in ranked:
            code=newcomer['code']
            if code in seen:continue
            replaceable=[(i,r) for i,r in enumerate(existing) if now-self._pre_entered_at.get(r['code'],now)>=SETTINGS.signal_accel_min_dwell_sec]
            if not replaceable:
                break
            wi,weak=min(replaceable,key=lambda x:_f(x[1].get('rank_score'),_f(x[1].get('score'))))
            new_score=_f(newcomer.get('rank_score'),_f(newcomer.get('score')));weak_score=_f(weak.get('rank_score'),_f(weak.get('score')))
            if new_score < weak_score+SETTINGS.signal_accel_entry_gap:
                continue
            seen.discard(weak['code']);self._pre_entered_at.pop(weak['code'],None)
            existing[wi]=newcomer;seen.add(code);self._pre_entered_at[code]=now
        existing.sort(key=lambda r:(_f(r.get('rank_score'),_f(r.get('score'))),1 if r.get('state')=='진입대상' else 0,_f(r.get('accel_5m')),_f(r.get('last_signal_at'))),reverse=True)
        out=existing[:slots];self._stable_pre_codes=[r['code'] for r in out];self._last_pre_rank_at=now
        self._pre_entered_at={c:t for c,t in self._pre_entered_at.items() if c in self._stable_pre_codes}
        for r in out:self._pre_entered_at.setdefault(r['code'],now)
        return out

    def _apply_live_evidence_episode(self, rows:list[dict[str,Any]], now:float)->tuple[list[dict[str,Any]],dict[str,int]]:
        """R49.1 cap for continuous pre-formal LIVE-EVIDENCE qualification.

        Strong current evidence can surface a symbol before the first formal SIGNAL, but
        it may not become a new kind of sticky pin. A continuous episode expires after
        10 minutes. If live evidence is absent for 60s, a later re-acceleration starts a
        new episode. Recent formal SIGNAL or bounded FAST SCOUT uses its own lane.
        """
        out=[];expired=0;active_live=0;seen_live=set()
        for r in rows:
            code=str(r.get('code') or '')
            live_lane=bool(r.get('live_evidence_lane'))
            if live_lane:
                seen_live.add(code);active_live+=1
                last=self._live_evidence_last_ok_at.get(code)
                if last is None or now-last>SETTINGS.signal_accel_live_reset_sec:
                    self._live_evidence_started_at[code]=now
                self._live_evidence_last_ok_at[code]=now
                started=self._live_evidence_started_at.setdefault(code,now)
                age=max(0.0,now-started)
                r['live_evidence_episode_age_sec']=round(age,1)
                r['live_evidence_episode_remaining_sec']=round(max(0.0,SETTINGS.signal_accel_live_episode_sec-age),1)
                if age>SETTINGS.signal_accel_live_episode_sec:
                    expired+=1
                    continue
            else:
                # Formal/fresh-scout qualification supersedes the bounded live-only episode.
                self._live_evidence_started_at.pop(code,None);self._live_evidence_last_ok_at.pop(code,None)
                r['live_evidence_episode_age_sec']=None;r['live_evidence_episode_remaining_sec']=None
            out.append(r)
        # A dropped evidence lane rearms only after a real gap, not on a one-frame wobble.
        for code,last in list(self._live_evidence_last_ok_at.items()):
            if code in seen_live:continue
            if now-last>SETTINGS.signal_accel_live_reset_sec:
                self._live_evidence_last_ok_at.pop(code,None);self._live_evidence_started_at.pop(code,None)
        return out,{'live_evidence_active':active_live,'live_evidence_expired_10m':expired}

    def build(self) -> dict[str, Any]:
        now=time.time()
        if self._cache is not None and now-self._cache_at <= self.cache_ttl:
            return self._cache
        sess=sessions();active=bool(sess.get('active'))
        with self.state.lock:
            cands=list(self.state.candidates.values())
        names=_universe()
        large_core=[]
        large_market_fill=[]
        pre=[]
        for c in cands:
            if c.code in names:
                # R44: during an active session LARGE-CAP is live-data-only.
                # No-price/stale rows are excluded instead of occupying a DATA WAIT slot.
                r=_largecap_row(c,now,active,names,allow_data_wait=False)
                if r and (not active or (r.get('fresh') and r.get('price') is not None and r.get('decision')!='DATA_WAIT')):
                    large_core.append(r)
            elif not active:
                # Market backfill is retained only for closed-session reconstruction.
                # It must never occupy a live large-cap slot.
                r=_market_backfill_row(c,now,active,names)
                if r:large_market_fill.append(r)
            p=_pre_row(c,now,active)
            if p and (p['fresh'] or not active):
                if active:
                    mo=market_overlay(self.state,c,now,SETTINGS.r493_pre_market_adj_cap)
                    p.update(mo)
                    p['rank_score_raw']=p.get('rank_score',p.get('score',0))
                    p['rank_score']=round(_f(p['rank_score_raw'])+_f(mo.get('market_adjustment')),1)
                    p['market_rank_overlay']='R493_KOSPI_KOSDAQ_DISPLAY_ONLY'
                pre.append(p)
        decision_rank={'NOW':4,'WAIT':3,'DATA_WAIT':2,'AVOID':1}
        large_core.sort(key=lambda r:(decision_rank.get(r['decision'],0),r.get('early_edge_score',0),r.get('headroom_score',0),r['score'],r['last_tick_at'] or 0),reverse=True)
        large_market_fill.sort(key=lambda r:(r.get('early_edge_score',0),r.get('headroom_score',0),r['score'],r['last_tick_at'] or 0),reverse=True)
        large_ranked=list(large_core)
        # R44: live session never backfills with DATA WAIT or non-large-cap reference rows.
        # Fewer than ten valid live large-caps is an honest result, not a reason to fill slots.
        if not active and len(large_ranked)<10:
            large_ranked.extend(large_market_fill[:10-len(large_ranked)])
        large_desired=self._compose_anchor_fresh_rows(large_ranked)
        large=self._stabilize_rows('large',large_desired,large_ranked,now) if active else large_desired[:10]

        # R49.1 PRE-IGNITION SIGNAL ACCELERATION TOP20. Formal cadence remains clean, while
        # qualified current LIVE-EVIDENCE can surface a pre-formal name for a bounded 10m episode.
        live_episode_stats={'live_evidence_active':0,'live_evidence_expired_10m':0}
        if active:
            pre,live_episode_stats=self._apply_live_evidence_episode(pre,now)
        pre.sort(key=lambda r:(r.get('rank_score',0),1 if r.get('state')=='진입대상' else 0,r.get('live_evidence_accel',0),r.get('accel_5m',0),r.get('signal_5m',0),r.get('signal_type_count',0),r.get('last_signal_at',0)),reverse=True)
        if active:
            pre=self._compose_r492_pre_fresh(pre,now)
            pre=self._stabilize_signal_accel(pre,now)
        else:
            pre=pre[:SETTINGS.signal_accel_slots]
        freeze_source='NONE'
        largecap_freeze_source='LIVE' if active else 'NO_LIVE_SNAPSHOT'
        pre_freeze_source='LIVE' if active else 'CLOSE_RECONSTRUCTED'
        if active:
            # R45: retain the latest *non-empty* verified LIVE large-cap board.
            # A transient data gap must not erase the close snapshot.
            if large:
                self._last_live_largecap=copy.deepcopy(large[:10])
                self._last_live_at=now
            if pre:
                self._last_live_pre=copy.deepcopy(pre[:SETTINGS.signal_accel_slots])
                if not self._last_live_at:
                    self._last_live_at=now
        else:
            # R45 LARGE-CAP close policy: LAST-LIVE ONLY.
            # Never reconstruct DATA_WAIT / market-backfill rows after close or after a restart.
            if self._last_live_largecap:
                large=self._freeze_rows(self._last_live_largecap,'decision_mode','CLOSE',self._last_live_at)
                largecap_freeze_source='LAST_LIVE'
            else:
                large=[]
                largecap_freeze_source='NO_LIVE_SNAPSHOT'
            # PRE-IGNITION keeps its legacy close reconstruction independently.
            if self._last_live_pre:
                pre=self._freeze_rows(self._last_live_pre,'window_mode','CLOSE',self._last_live_at)
                pre_freeze_source='LAST_LIVE'
            else:
                pre_freeze_source='CLOSE_RECONSTRUCTED'
            freeze_source='LAST_LIVE' if (largecap_freeze_source=='LAST_LIVE' and pre_freeze_source=='LAST_LIVE') else pre_freeze_source
        pinned=[c for c in cands if c.live_track_pin]
        stale_pins=sum(1 for c in pinned if not c.last_signal or now-_f(c.last_signal.signal_time)>SETTINGS.signal_accel_signal_ttl_sec)
        next_rank=max(0.0,SETTINGS.signal_accel_rank_sec-(now-self._last_pre_rank_at)) if active and self._last_pre_rank_at else 0.0
        ep=self._energy_path.build(cands,now,active,{r.get('code') for r in pre})
        out={
            'ok':True,'generated_at':now,'market_active':active,'feed_state':self.state.feed_state.value,
            'freeze_source':freeze_source,'largecap_freeze_source':largecap_freeze_source,'pre_freeze_source':pre_freeze_source,
            'frozen_at':self._last_live_at if (largecap_freeze_source=='LAST_LIVE' or pre_freeze_source=='LAST_LIVE') else None,
            'next_pre_rank_in_sec':round(next_rank,1),'circulation':{'candidate_total':len(cands),'pinned_total':len(pinned),'pinned_signal_stale_15m':stale_pins,'signal_accel_eligible':len(pre),**live_episode_stats},
            'largecap':large[:10],'preignition':pre[:SETTINGS.signal_accel_slots],'energy':ep.get('energy',[]),'path':ep.get('path',[]),'r492':{k:v for k,v in ep.items() if k not in ('energy','path')},
            'contracts':{
                'official_buy_logic_changed':False,'new_broker_rest_calls':2,'new_ws_subscriptions':0,
                'largecap_universe':'OPERATOR_STATIC_UNIVERSE + NOVA_LARGECAP_CODES override','decision_only':True,
                'largecap_fill_policy':'ACTIVE: FRESH LIVE CORE ONLY, NO DATA_WAIT, NO MARKET_BACKFILL; CLOSED: LAST_LIVE ONLY, NO RECONSTRUCTION',
                'largecap_close_policy':'LAST_LIVE_ONLY_NO_RECONSTRUCTION_NO_DATA_WAIT',
                'largecap_backfill_official_buy':False,'largecap_target_rows':10,'largecap_live_only':True,'largecap_allow_partial_rows':True,
                'repeat_ranking':'R49.1 SIGNAL ACCELERATION: 5/15/30m formal cadence + current LIVE-EVIDENCE acceleration; lifetime repeat is context only',
                'pre_acceleration_policy':'TOP20; live metrics continuous; rank/membership 30s commit; 60s minimum dwell; newcomer +3pt; stale pin needs current evidence; pre-formal LIVE-EVIDENCE continuous episode max 10m / reset after 60s gap; official BUY untouched',
                'entry_candidate_policy':'DISPLAY ONLY: 4-of-5 acceleration evidence / flow / price position / activity / live freshness; strong LIVE-EVIDENCE may qualify before formal SIGNAL; never writes ENTRY_V18 or BUY',
                'live_evidence_episode_sec':SETTINGS.signal_accel_live_episode_sec,'live_evidence_reset_sec':SETTINGS.signal_accel_live_reset_sec,
                'early_edge_policy':'PRE-BREAKOUT headroom remains one component; chase/cooling blocks entry-candidate label',
                'pre_signal_slots':SETTINGS.signal_accel_slots,'pre_rank_commit_sec':SETTINGS.signal_accel_rank_sec,'pre_min_dwell_sec':SETTINGS.signal_accel_min_dwell_sec,'pre_newcomer_gap':SETTINGS.signal_accel_entry_gap,'pre_official_buy_changed':False,
                'r41_close_freeze':'PRE may reconstruct after restart; LARGE-CAP is LAST-LIVE ONLY and never reconstructs DATA_WAIT rows',
                'r492_extension':'DISPLAY_VERIFY_ONLY; PRE CORE/FRESH presentation + ENERGY/PATH; no ENTRY_V18 mutation',
                'r493_market_relative':'KOSPI/KOSDAQ ka20001 low-priority overlay; PRE rank display only; ENERGY/PATH rank overlay; base scores and ENTRY_V18 unchanged',
                'r492_fresh_lane':'CORE16+FRESH4 NORMAL; BUSY3; HIGH2; CRITICAL0; eligibility unchanged',
                'r492_shared_cache':'MAX40 NORMAL; ENERGY25; PATH30; stock data remains existing in-memory Kiwoom data',
                'r492_load_shed':'PRE/BUY/NXT > ENERGY > PATH; HIGH pauses PATH; CRITICAL returns R491_SAFE',
                'r492_new_broker_rest_calls':0,'r492_new_ws_subscription_types':0,
                'r493_market_index_rest_calls_per_refresh':2,'r493_market_index_refresh_sec':SETTINGS.r493_market_index_sec,'r493_new_ws_subscription_types':0,
                'r493_market_overlay_caps':{'pre':SETTINGS.r493_pre_market_adj_cap,'energy':SETTINGS.r493_energy_market_adj_cap,'path':SETTINGS.r493_path_market_adj_cap},
            },
        }
        self._cache_at=now;self._cache=out
        return out

