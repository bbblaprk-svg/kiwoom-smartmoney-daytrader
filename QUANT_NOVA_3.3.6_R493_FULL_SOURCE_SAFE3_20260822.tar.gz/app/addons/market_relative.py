from __future__ import annotations

import time
from typing import Any

from app.config import SETTINGS


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v if v is not None else default)
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def market_name_for_candidate(candidate: Any) -> str:
    code = str(candidate.metrics.get('market_code') or '')
    return 'KOSPI' if code == '001' else 'KOSDAQ' if code == '101' else ''


def market_overlay(state: Any, candidate: Any, now: float | None = None, cap: float = 5.0) -> dict[str, Any]:
    """Return a bounded market-relative overlay without touching base component scores.

    The overlay is valid only with a recent official Kiwoom index snapshot.  It uses
    stock change-rate minus its KOSPI/KOSDAQ change-rate plus a small resilience bonus
    in RISK_OFF/PANIC conditions.  No beta is assumed and no future information is used.
    """
    now = time.time() if now is None else float(now)
    name = market_name_for_candidate(candidate)
    if not name:
        return {'market_available': False, 'market_adjustment': 0.0, 'market_name': '', 'market_relative_rate': 0.0, 'market_resilient': False, 'market_regime': 'UNKNOWN'}
    ctx = dict((getattr(state, 'market_context', {}) or {}).get(name) or {})
    updated = _f(ctx.get('updated_at'))
    age = now - updated if updated else 10**9
    if not ctx.get('ok') or age > SETTINGS.r493_market_context_ttl_sec:
        return {'market_available': False, 'market_adjustment': 0.0, 'market_name': name, 'market_relative_rate': 0.0, 'market_resilient': False, 'market_regime': 'STALE', 'market_context_age_sec': round(age, 1) if age < 10**8 else None}
    stock_rate = _f(candidate.current().last_rate)
    index_rate = _f(ctx.get('change_rate'))
    relative = stock_rate - index_rate
    regime = str(ctx.get('regime') or 'NEUTRAL')
    resilient = bool(regime in ('RISK_OFF', 'PANIC') and relative >= 1.0 and stock_rate >= index_rate)
    adjustment = _clamp(relative * 1.2, -cap, cap)
    if resilient:
        adjustment = _clamp(adjustment + min(1.0, max(0.0, relative - 1.0) * 0.4 + 0.4), -cap, cap)
    return {
        'market_available': True,
        'market_name': name,
        'market_index_rate': round(index_rate, 3),
        'market_breadth': round(_f(ctx.get('breadth')), 2),
        'market_regime': regime,
        'market_relative_rate': round(relative, 3),
        'market_adjustment': round(adjustment, 2),
        'market_resilient': resilient,
        'market_context_age_sec': round(max(0.0, age), 1),
        'market_source': str(ctx.get('source') or ''),
    }
