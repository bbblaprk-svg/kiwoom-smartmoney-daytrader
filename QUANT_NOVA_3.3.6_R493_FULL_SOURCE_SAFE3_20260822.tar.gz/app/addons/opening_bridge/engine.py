from __future__ import annotations
import asyncio, os, threading, time
from datetime import datetime
from pathlib import Path
from typing import Any
from app.config import SETTINGS
from app.domain import Candidate, Origin, Venue
from app.runtime.clock import KST, calendar_info, now_kst, sessions_at, trade_day
from app.runtime.state import RuntimeState
from .phase import display_title, effective_day, phase_at, source_day, visible_effective_day
from .store import ShadowStore, fnum


class OpeningProfitBridgeShadow:
    MODE='SHADOW'
    def __init__(self,state:RuntimeState):
        self.state=state
        self.enabled=os.getenv('OPENING_BRIDGE_ENABLED','1').strip().lower() not in {'0','false','off','no'}
        self.ui_enabled=os.getenv('OPENING_BRIDGE_UI_ENABLED','1').strip().lower() not in {'0','false','off','no'}
        self.buy_handoff_enabled=False
        self.path=Path(SETTINGS.data_dir)/'opening_profit_bridge_shadow.json'
        self.lock=threading.RLock();self._task:asyncio.Task|None=None;self._stop=asyncio.Event();self._last_error='';self._last_ok_at=0.0;self._last_phase=''
        self._store=ShadowStore(self.path)


    @property
    def path(self):
        return self._store.path if hasattr(self,'_store') else self._path
    @path.setter
    def path(self,value):
        self._path=Path(value)
        if hasattr(self,'_store'):self._store.path=self._path

    @property
    def store(self):return self._store.data
    @store.setter
    def store(self,value):self._store.data=value
    @staticmethod
    def phase_at(dt:datetime)->str:return phase_at(dt)
    def _blank(self):return ShadowStore.blank()
    def _load(self):return self._store.load()
    def _persist(self,force:bool=False):self._store.persist(force)
    def _transition(self,rec,new_state,reason,now):self._store.transition(rec,new_state,reason,now)

    @staticmethod
    def _fresh(v:Any,now:float,max_age:float=9.0)->bool:
        m=v.metrics or {}
        return bool(v.last_price>0 and v.last_tick_at and 0<=now-fnum(v.last_tick_at)<=max_age and not v.continuity_reason and not v.resync_required and m.get('fresh',True))
    @staticmethod
    def _rank_base(c:Candidate)->float:return max(float(c.priority_score or 0),float(c.score or 0),float(c.close_score or 0))
    @classmethod
    def _meaningful(cls,c:Candidate,v:Any)->bool:return bool(v.last_price>0 and (c.live_track_pin or c.last_signal or c.valid_repeat_count>0 or cls._rank_base(c)>=30))

    @staticmethod
    def _stamp_is_day(ts:float,day:str)->bool:
        if not ts:return False
        try:return datetime.fromtimestamp(float(ts),KST).strftime('%Y%m%d')==str(day)
        except Exception:return False

    @classmethod
    def _prior_requalified_today(cls,c:Candidate,day:str)->bool:
        if c.origin!=Origin.PRIOR_CLOSE:return True
        evidence=[]
        if c.last_signal:evidence.append(float(c.last_signal.signal_time or 0))
        evidence.append(float(c.last_buy_at or 0))
        for venue in (Venue.KRX,Venue.NXT):
            lane=c.venue_state[venue].entry
            evidence.extend((float(lane.last_formal_at or 0),float(lane.last_buy_at or 0)))
        return any(cls._stamp_is_day(ts,day) for ts in evidence)

    def _close_record(self,c:Candidate,venue:Venue,source:str,source_day_s:str,now:float):
        v=c.venue_state[venue]
        if not self._meaningful(c,v):return None
        # A carried PRIOR is not allowed to manufacture a new close candidate merely
        # because its old pin/score still exists. It must have fresh same-day signal evidence.
        if c.origin==Origin.PRIOR_CLOSE and (not self._prior_requalified_today(c,source_day_s) or self._rank_base(c)<64):return None
        m=v.metrics or {};cid=f'{source_day_s}:{venue.value}:{c.code}:{source}'
        return {'candidate_id':cid,'source_day':source_day_s,'effective_day':effective_day(source_day_s),'qualification_day':source_day_s,'requalified_from_prior':bool(c.origin==Origin.PRIOR_CLOSE),'code':c.code,'name':c.name or c.code,'origin':'PRIOR_CLOSE','source':source,'venue':venue.value,
                'captured_at':now,'reference_price':fnum(v.last_price),'reference_change_rate':fnum(v.last_rate),'close_score':round(self._rank_base(c),2),'repeat_total':int(c.valid_repeat_count or 0),
                'entry_state_at_close':str(c.entry_state),'stage_at_close':str(c.stage),'buy_pressure_at_close':fnum(m.get('buy_pressure'),50),'vwap_gap_at_close':fnum(m.get('session_vwap_gap')),
                'volume_accel_at_close':fnum(m.get('volume_accel'),1),'smart_money_at_close':fnum(m.get('smart_money_realtime_proxy_score')),'shadow_state':source,'premarket_state':'HOLD',
                'opening_price':0.0,'opening_high':0.0,'opening_low':0.0,'shakeout_seen':False,'reversal_seen':False,'last_eval_at':now}

    def _bootstrap_close_reconstructed(self,candidates:list[Candidate],phase:str,dt:datetime,now:float)->None:
        """One-shot post-close reconstruction for a first deployment after CLOSE_TRACK.

        SHADOW only. Reads already-resident NOVA candidate/tick state and writes only the
        opening-profit-bridge shadow store. It never calls the broker and never mutates
        official Candidate lifecycle/entry state.
        """
        if phase!='PRIOR_CLOSE_FROZEN' or self.buy_handoff_enabled:return
        src_day=source_day(dt);eff=effective_day(src_day);by=self.store.setdefault('candidates',{})
        if any(str(r.get('effective_day') or '')==eff for r in by.values()):return
        boot=self.store.setdefault('bootstrap',{})
        if str(boot.get('completed_source_day') or '')==src_day:return
        rows=[]
        for c in candidates:
            if c.trade_day and str(c.trade_day)!=src_day:continue
            eligible=[]
            for venue in (Venue.KRX,Venue.NXT):
                v=c.venue_state[venue]
                if v.last_price<=0 or not v.last_tick_at:continue
                tick_dt=datetime.fromtimestamp(float(v.last_tick_at),KST)
                if tick_dt.strftime('%Y%m%d')!=src_day:continue
                sec=tick_dt.hour*3600+tick_dt.minute*60+tick_dt.second
                # Close reconstruction must be based on an actual same-day closing/after-hours tick.
                if sec < 15*3600+20*60 or sec > 20*3600+5*60:continue
                eligible.append((float(v.last_tick_at),1 if venue==Venue.NXT else 0,venue))
            if not eligible:continue
            eligible.sort(reverse=True);venue=eligible[0][2];v=c.venue_state[venue];m=v.metrics or {}
            rec=self._close_record(c,venue,'BOOTSTRAP_CLOSE_RECONSTRUCTED',src_day,now)
            if not rec:continue
            base=self._rank_base(c);bp=fnum(m.get('buy_pressure'),50);acc=fnum(m.get('volume_accel'),1);sm=fnum(m.get('smart_money_realtime_proxy_score'))
            evidence=min(6.0,int(c.valid_repeat_count or 0)*.5)+max(0.0,min(6.0,(bp-50)*.25))+max(0.0,min(4.0,(acc-1)*4))+max(0.0,min(4.0,sm))
            rec['bootstrap_base_score']=round(base,2);rec['close_score']=round(min(100.0,base+evidence),2);rec['captured_at']=float(v.last_tick_at);rec['bootstrap_at']=now
            rec['shadow_state']='PRIOR_CLOSE_FROZEN';rec['bootstrap_note']='same-day retained close tick; SHADOW READ ONLY; no broker request'
            rows.append((fnum(rec.get('close_score')),int(c.valid_repeat_count or 0),float(v.last_tick_at),rec))
        if not rows:return
        rows.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True)
        for rank,(_,_,_,rec) in enumerate(rows[:40],1):
            rec['close_rank']=rank;by[rec['candidate_id']]=rec
        boot.update({'completed_source_day':src_day,'effective_day':eff,'completed_at':now,'source':'BOOTSTRAP_CLOSE_RECONSTRUCTED','count':min(40,len(rows))})
        self.store.update({'source_day':src_day,'effective_day':eff,'phase':'PRIOR_CLOSE_FROZEN','updated_at':now})
        self._persist(force=True)

    def _capture_close(self,candidates:list[Candidate],phase:str,dt:datetime,now:float)->None:
        if phase=='KRX_CLOSE_CAPTURE':venue,source=Venue.KRX,'KRX_CLOSE_CANDIDATE'
        elif phase=='CLOSE_TRACK':venue,source=Venue.NXT,'NXT_AFTER_CLOSE_CANDIDATE'
        else:return
        src_day=source_day(dt);rows=[]
        for c in candidates:
            rec=self._close_record(c,venue,source,src_day,now)
            if rec:rows.append((self._rank_base(c),c.valid_repeat_count,fnum(c.venue_state[venue].last_rate),rec))
        rows.sort(key=lambda x:(x[0],x[1],x[2]),reverse=True);by=self.store.setdefault('candidates',{})
        for rank,(_,_,_,rec) in enumerate(rows[:40],1):
            rec['close_rank']=rank;old=by.get(rec['candidate_id'])
            if old:
                life={k:old.get(k) for k in ('shadow_state','state_changed_at','premarket_state','premarket_price','premarket_change','opening_price','opening_high','opening_low','shakeout_seen','reversal_seen') if k in old};old.update(rec);old.update(life)
            else:by[rec['candidate_id']]=rec
        self.store['source_day']=src_day;self.store['effective_day']=effective_day(src_day)

    def _select_prior(self,eff:str)->list[dict[str,Any]]:
        rows=[r for r in self.store.get('candidates',{}).values() if str(r.get('effective_day') or '')==eff];best={}
        for r in rows:
            code=str(r.get('code') or '');old=best.get(code);key=(fnum(r.get('close_score')),int(r.get('repeat_total') or 0),1 if r.get('source')=='NXT_AFTER_CLOSE_CANDIDATE' else 0)
            old_key=(fnum(old.get('close_score')),int(old.get('repeat_total') or 0),1 if old and old.get('source')=='NXT_AFTER_CLOSE_CANDIDATE' else 0) if old else (-1,-1,-1)
            if key>old_key:best[code]=r
        return list(best.values())
    @staticmethod
    def _continuity_bonus(rec:dict)->float:
        bonus=min(5.0,int(rec.get('repeat_total') or 0)*.4);ps=str(rec.get('premarket_state') or '')
        if ps=='SURVIVE':bonus+=3
        elif ps=='WEAKENED':bonus-=2
        elif ps=='GAP_RISK':bonus-=3
        if rec.get('shakeout_seen'):bonus+=1.5
        if rec.get('reversal_seen'):bonus+=5
        return bonus

    def _premarket(self,rec:dict,c:Candidate|None,dt:datetime,now:float)->None:
        if c is None:self._transition(rec,'PREMARKET_RECHECK','candidate not resident; frozen evidence retained',now);rec['premarket_state']='HOLD';return
        sess=sessions_at(dt.date(),dt.hour*3600+dt.minute*60+dt.second);v=c.venue_state[Venue.NXT]
        if not (sess.get('nxt_phase')=='PRE' and self._fresh(v,now)):
            self._transition(rec,'PREMARKET_RECHECK','no fresh NXT PRE tick; KRX substitution forbidden',now);rec['premarket_state']='HOLD';return
        ref=fnum(rec.get('reference_price'));px=fnum(v.last_price);gap=((px/ref-1)*100) if ref>0 else fnum(v.last_rate);m=v.metrics or {};bp=fnum(m.get('buy_pressure'),50);acc=fnum(m.get('volume_accel'),1)
        state='GAP_RISK' if gap>=6 else 'WEAKENED' if gap<=-4 and bp<45 else 'SURVIVE' if gap>=-2.5 and (bp>=50 or acc>=1.1) else 'HOLD'
        rec.update({'premarket_price':px,'premarket_change':round(gap,3),'premarket_state':state,'premarket_at':now});self._transition(rec,'PREMARKET_RECHECK',f'NXT PRE {state} gap={gap:.2f}%',now)

    def _opening_eval(self,rec:dict,c:Candidate|None,dt:datetime,now:float)->None:
        if c is None:return
        sess=sessions_at(dt.date(),dt.hour*3600+dt.minute*60+dt.second)
        venue=Venue.KRX if sess.get('krx') and self._fresh(c.venue_state[Venue.KRX],now) else Venue.NXT if sess.get('nxt') and self._fresh(c.venue_state[Venue.NXT],now) else Venue.UNKNOWN
        if venue==Venue.UNKNOWN:return
        v=c.venue_state[venue];px=fnum(v.last_price);m=v.metrics or {}
        if not rec.get('opening_price'):rec['opening_price']=px;rec['opening_high']=px;rec['opening_low']=px
        rec['opening_high']=max(fnum(rec.get('opening_high'),px),px);rec['opening_low']=min(fnum(rec.get('opening_low'),px),px)
        op=fnum(rec.get('opening_price'),px);low=fnum(rec.get('opening_low'),px);draw=(px/op-1)*100 if op>0 else 0;bp=fnum(m.get('buy_pressure'),50);vgap=fnum(m.get('micro_vwap_gap'));acc=fnum(m.get('volume_accel'),1)
        rec.update({'last_live_price':px,'last_live_change':fnum(v.last_rate),'last_live_venue':venue.value,'last_live_at':now,'last_eval_at':now})
        if draw<=-4 or (vgap<=-2 and bp<40):self._transition(rec,'BREAKDOWN',f'draw={draw:.2f}% vwap={vgap:.2f} bp={bp:.0f}',now);return
        if draw<=-1 and bp<50 and vgap<0:rec['shakeout_seen']=True;self._transition(rec,'SHAKEOUT_WATCH',f'draw={draw:.2f}% sell pressure; observe only',now)
        s=dt.hour*3600+dt.minute*60+dt.second;rev_window=9*3600+10*60<=s<10*3600
        if rev_window and rec.get('shakeout_seen') and low>0 and px>=low*1.003 and bp>=56 and vgap>=-.10 and acc>=1.10:
            rec['reversal_seen']=True;self._transition(rec,'REVERSAL_EARLY',f'low reclaim + BP/VWAP/accel on {venue.value}',now)
        if rev_window and (rec.get('reversal_seen') or c.entry_state in ('REACCEL','DIRECT_ARM')) and self._rank_base(c)>=62:
            self._transition(rec,'BUY_READY_SHADOW','shadow handoff candidate; official BUY engine unchanged',now)

    def _display_tick(self,c:Candidate|None,phase:str,dt:datetime,now:float)->tuple[Venue|None,float|None,float|None,float|None,str]:
        """Return current display truth for the bridge.

        During any active/recheck phase, stale retained/reference prices are never emitted as
        current price. The bridge either has a fresh broker trade tick or explicitly returns
        DATA_WAIT. PRIOR_CLOSE_FROZEN is handled separately by the caller.
        """
        if c is None:
            return None,None,None,None,'CANDIDATE_NOT_RESIDENT'
        sess=sessions_at(dt.date(),dt.hour*3600+dt.minute*60+dt.second)
        preferred=[]
        if phase=='PREMARKET_RECHECK':
            if sess.get('nxt_phase')=='PRE':preferred=[Venue.NXT]
        else:
            if sess.get('krx'):preferred.append(Venue.KRX)
            if sess.get('nxt'):preferred.append(Venue.NXT)
        for venue in preferred:
            v=c.venue_state[venue]
            if self._fresh(v,now):
                age=max(0.0,(now-fnum(v.last_tick_at))*1000)
                return venue,fnum(v.last_price),fnum(v.last_rate),round(age,1),'LIVE_TRADE_TICK'
        return None,None,None,None,'NO_FRESH_TRADE_TICK'

    def _prior_rows(self,by_code:dict[str,Candidate],phase:str,dt:datetime,now:float)->list[dict[str,Any]]:
        rows=self._select_prior(visible_effective_day(dt,phase))
        for rec in rows:
            c=by_code.get(str(rec.get('code') or ''))
            if phase=='PRIOR_CLOSE_FROZEN':self._transition(rec,'PRIOR_CLOSE_FROZEN','overnight frozen evidence',now)
            elif phase=='PREMARKET_RECHECK':self._premarket(rec,c,dt,now)
            elif phase=='OPENING_HANDOFF':self._transition(rec,'OPENING_HANDOFF','candidate retained; handed to opening shadow',now)
            elif phase in ('SHAKEOUT_WATCH','REVERSAL_EARLY'):self._opening_eval(rec,c,dt,now)
            rec['bridge_score']=round(fnum(rec.get('close_score'))+self._continuity_bonus(rec),2)
        return rows

    def _today_rows(self,candidates:list[Candidate],now:float)->list[dict[str,Any]]:
        out=[]
        for c in candidates:
            if c.origin==Origin.PRIOR_CLOSE:continue
            v=c.current();base=self._rank_base(c)
            if not self._fresh(v,now) or (base<30 and not c.live_track_pin and not c.last_signal):continue
            out.append({'candidate_id':f'{trade_day()}:TODAY:{c.code}','code':c.code,'name':c.name or c.code,'badge':'TODAY','origin':'TODAY_NEW','venue':v.venue.value,'price':fnum(v.last_price),'change_rate':fnum(v.last_rate),'bridge_score':round(base,2),'repeat_total':int(c.valid_repeat_count or 0),'shadow_state':str(c.lifecycle_state or c.entry_state or 'TODAY_NEW'),'entry_state':str(c.entry_state),'source':'TODAY_NEW','fresh':True})
        return out

    def _build_locked(self,dt:datetime|None=None)->dict[str,Any]:
        dt=(dt or now_kst()).astimezone(KST);now=dt.timestamp();phase=phase_at(dt)
        with self.state.lock:candidates=list(self.state.candidates.values())
        by_code={c.code:c for c in candidates};self._capture_close(candidates,phase,dt,now);self._bootstrap_close_reconstructed(candidates,phase,dt,now)
        # Opening Bridge is an opening-session tool. After 10:00 the PRIOR/TODAY
        # competition is finished and the main realtime boards own the screen.
        # Keep the shadow records for verification, but do not keep rendering them.
        archived_prior_count=0
        if phase=='NORMAL_INTRADAY':
            archived_prior_count=len(self._select_prior(visible_effective_day(dt,phase)))
            prior=[];today=[]
        else:
            prior=self._prior_rows(by_code,phase,dt,now)
            # 09:00~10:00 only: PRIOR and TODAY_NEW compete on the same rank.
            # The phase boundary itself is the clock gate; no contradictory dt.hour<10 test.
            today=self._today_rows(candidates,now) if phase in ('SHAKEOUT_WATCH','REVERSAL_EARLY') else []
        visible=[]
        for rec in prior:
            c=by_code.get(str(rec.get('code') or ''))
            if phase=='PRIOR_CLOSE_FROZEN':
                venue_s=str(rec.get('venue') or 'UNKNOWN');price=fnum(rec.get('reference_price')) or None
                rate=fnum(rec.get('reference_change_rate')) if price is not None else None
                fresh=False;age_ms=None;price_source='PRIOR_CLOSE_FROZEN';wait_reason=''
            else:
                live_venue,price,rate,age_ms,price_source=self._display_tick(c,phase,dt,now)
                venue_s=live_venue.value if live_venue in (Venue.KRX,Venue.NXT) else 'UNKNOWN'
                fresh=price_source=='LIVE_TRADE_TICK';wait_reason='' if fresh else price_source
            visible.append({'candidate_id':rec.get('candidate_id'),'source_day':rec.get('source_day'),'effective_day':rec.get('effective_day'),'code':rec.get('code'),'name':rec.get('name'),'badge':'PRIOR','origin':'PRIOR_CLOSE','source':rec.get('source'),'venue':venue_s,'price':price,'change_rate':rate,'display_price_source':price_source,'display_age_ms':age_ms,'data_wait_reason':wait_reason,'bridge_score':fnum(rec.get('bridge_score') or rec.get('close_score')),'close_score':fnum(rec.get('close_score')),'repeat_total':int(rec.get('repeat_total') or 0),'shadow_state':rec.get('shadow_state'),'premarket_state':rec.get('premarket_state'),'premarket_change':rec.get('premarket_change'),'shakeout_seen':bool(rec.get('shakeout_seen')),'reversal_seen':bool(rec.get('reversal_seen')),'entry_state':c.entry_state if c else rec.get('entry_state_at_close'),'reference_price':rec.get('reference_price'),'fresh':fresh})
        visible.extend(today);visible.sort(key=lambda r:(fnum(r.get('bridge_score')),int(r.get('repeat_total') or 0),fnum(r.get('change_rate'))),reverse=True);rows=visible[:10]
        self.store['phase']=phase;self.store['updated_at']=now;changed=phase!=self._last_phase;self._last_phase=phase;self._persist(force=changed);self._last_ok_at=time.time();self._last_error=''
        boot=self.store.get('bootstrap') or {};cal=calendar_info(dt.date())
        sec=dt.hour*3600+dt.minute*60+dt.second
        # R44 UI contract: the Opening Profit Bridge is an opening-only panel.
        # Storage/capture/evaluation stays alive, but the panel itself is visible only 08:00~10:00 KST.
        opening_ui_visible=bool(self.ui_enabled and 8*3600 <= sec < 10*3600)
        return {'ok':True,'mode':self.MODE,'enabled':self.enabled,'ui_enabled':opening_ui_visible,'buy_handoff_enabled':False,'phase':phase,'title':display_title(phase),'market_policy':'venue-aware; NXT PRE never substituted for KRX; NXT MAIN begins 09:00:30','rows':rows,'prior_count':len(prior),'today_count':len(today),'archived_prior_count':archived_prior_count,'opening_tracking_active':opening_ui_visible,'stored_count':len(self.store.get('candidates',{})),'bootstrap_source':boot.get('source',''),'bootstrap_count':int(boot.get('count') or 0),'calendar':cal,'last_ok_at':self._last_ok_at,'last_error':''}

    def build(self,dt:datetime|None=None)->dict[str,Any]:
        if not self.enabled:return {'ok':True,'mode':self.MODE,'enabled':False,'ui_enabled':False,'buy_handoff_enabled':False,'phase':phase_at(dt or now_kst()),'rows':[]}
        try:
            with self.lock:return self._build_locked(dt)
        except Exception as e:
            self._last_error=f'{type(e).__name__}: {e}'[:240]
            return {'ok':False,'mode':self.MODE,'enabled':self.enabled,'ui_enabled':self.ui_enabled,'buy_handoff_enabled':False,'phase':phase_at(dt or now_kst()),'rows':[],'last_ok_at':self._last_ok_at,'last_error':self._last_error,'fail_open':True}

    async def _loop(self)->None:
        while not self._stop.is_set():
            self.build()
            try:await asyncio.wait_for(self._stop.wait(),timeout=5)
            except asyncio.TimeoutError:pass
    async def start(self)->None:
        if not self.enabled or self._task is not None:return
        self._stop.clear();self._task=asyncio.create_task(self._loop(),name='opening-profit-bridge-shadow')
    async def stop(self)->None:
        self._stop.set();t=self._task;self._task=None
        if t:
            try:await asyncio.wait_for(t,timeout=2)
            except Exception:t.cancel()
