from __future__ import annotations

import copy
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any

from app.config import SETTINGS
from app.domain import Candidate
from app.signal.early_edge import early_edge, discovery_scout_score, discovery_freshness
from app.addons.market_relative import market_overlay


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v if v is not None else default)
    except Exception:
        return default


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _gain_retention(c: Candidate, price: float) -> float:
    """0..100 retention using only already-observed prices; never future data."""
    sig = c.last_signal
    if sig and sig.signal_price > 0 and c.signal_high > sig.signal_price and price > 0:
        mfe = c.signal_high / sig.signal_price - 1.0
        cur = price / sig.signal_price - 1.0
        if mfe > 0:
            return _clamp(cur / mfe * 100.0)
    v = c.current()
    if v.day_high > v.day_low > 0 and price > 0:
        return _clamp((price - v.day_low) / max(v.day_high - v.day_low, 1e-9) * 100.0)
    return 50.0


def _energy_components(c: Candidate, now: float) -> tuple[float, dict[str, float], float, str]:
    v = c.current(); m = v.metrics or {}; price = _f(v.last_price)
    turn = _f(m.get('turnover_accel_30s'), 1.0) if m.get('turnover_accel_ready') else 1.0
    vol = _f(m.get('volume_accel'), 1.0) if m.get('volume_accel_ready') else 1.0
    bp = _f(m.get('buy_pressure'), 50.0); bpd = _f(m.get('buy_pressure_delta_30s'))
    i30 = _f(m.get('impulse_30s')); i60 = _f(m.get('impulse_60s')); i180 = _f(m.get('impulse_180s'))
    vgap = _f(m.get('micro_vwap_gap')); sgap = _f(m.get('session_vwap_gap'))
    smart = _f(m.get('smart_money_realtime_proxy_score')); sma = _f(m.get('smart_money_acceleration'), 1.0)
    net = _f(m.get('net_large_flow_30s')); rv = max(0.0, _f(c.metrics.get('discovery_rank_velocity_pos')))
    src = max(0.0, _f(c.metrics.get('discovery_source_count'), len(c.source_hits)))
    sector = _f(c.metrics.get('sector_score'))
    retention = _gain_retention(c, price)

    mass = _clamp((turn - 1.0) * 18.0 + (vol - 1.0) * 8.0, 0, 20)
    velocity = _clamp(max(0.0, i30) * 5.0 + max(0.0, i60) * 4.0 + max(0.0, i180) * 1.5, 0, 15)
    accel = _clamp(max(0.0, bpd) * .75 + max(0.0, sma - 1.0) * 7.0 + rv * .35, 0, 15)
    absorption = _clamp(max(0.0, bp - 50.0) * .55 + max(0.0, smart) * 1.2 + (2.0 if net > 0 else 0.0) + max(0.0, vgap) * 2.0, 0, 15)
    retain = _clamp((retention - 45.0) * .27 + max(0.0, sgap) * 2.0 + (3.0 if vgap >= -.15 else 0.0), 0, 15)
    relative = _clamp(max(0.0, sector) + rv * .30, 0, 10)
    network = _clamp(max(0.0, src - 1.0) * 1.7, 0, 5)
    reignition = 0.0
    if bool(m.get('sell_to_buy_flip')): reignition += 2.0
    if bool(m.get('smart_money_realtime_proxy_surge')): reignition += 1.5
    if c.entry_state == 'REACCEL': reignition += 2.0
    if str(c.metrics.get('nxt_second_wave_state') or '') in ('SECOND_WAVE_READY','SECOND_WAVE_BUY'): reignition += 2.0
    reignition = _clamp(reignition, 0, 5)
    score = _clamp(mass + velocity + accel + absorption + retain + relative + network + reignition)

    risk = 0.0
    rate = _f(v.last_rate)
    risk += _clamp(max(0.0, rate - 7.0) * 3.0, 0, 24)
    risk += _clamp(max(0.0, vgap - 1.8) * 9.0, 0, 18)
    risk += _clamp(max(0.0, i60 - 3.5) * 5.0, 0, 18)
    risk += 12 if bp < 45 else 0
    risk += _clamp(max(0.0, 55.0 - retention) * .45, 0, 18)
    risk = _clamp(risk)
    stage = 'POWER' if score >= 82 and risk <= 55 else 'COMPOUNDING' if score >= 73 else 'ROLLING' if score >= 62 else 'SEED'
    return round(score,1), {
        'mass':round(mass,1),'velocity':round(velocity,1),'acceleration':round(accel,1),'absorption':round(absorption,1),
        'retention':round(retain,1),'relative':round(relative,1),'network':round(network,1),'reignition':round(reignition,1),
    }, round(risk,1), stage


def _path_components(c: Candidate, energy: float, now: float) -> tuple[float, dict[str, float], str, float]:
    v = c.current(); m = v.metrics or {}; price = _f(v.last_price)
    turn = _f(m.get('turnover_accel_30s'), 1.0) if m.get('turnover_accel_ready') else 1.0
    vol = _f(m.get('volume_accel'), 1.0) if m.get('volume_accel_ready') else 1.0
    bp = _f(m.get('buy_pressure'), 50.0); bpd = _f(m.get('buy_pressure_delta_30s'))
    smart = _f(m.get('smart_money_realtime_proxy_score')); sma = _f(m.get('smart_money_acceleration'), 1.0)
    net = _f(m.get('net_large_flow_30s')); prog = _f(m.get('program_score')); vgap = _f(m.get('micro_vwap_gap')); sgap = _f(m.get('session_vwap_gap'))
    retention_pct = _gain_retention(c, price)
    repeat = _f(c.valid_repeat_count); rate = _f(v.last_rate)
    high = _f(v.day_high); low = _f(v.day_low)
    high_dist = ((price / high - 1.0) * 100.0) if price > 0 and high > 0 else -5.0

    # R492 PATH is intentionally a LIVE observable proxy until multi-session calibration matures.
    money = _clamp((turn - 1.0) * 14.0 + (vol - 1.0) * 5.0 + max(0.0, _f(m.get('turnover_60s')) / 100_000_000.0) * .7, 0, 25)
    flow = _clamp(max(0.0, bp - 50.0) * .55 + max(0.0, bpd) * .45 + max(0.0, smart) * 1.6 + max(0.0, sma - 1.0) * 3.0 + (2.0 if net > 0 else 0.0) + max(0.0, prog), 0, 25)
    retain = _clamp((retention_pct - 35.0) * .31, 0, 20)
    accept = _clamp((4.0 + max(0.0, 2.0 + high_dist) * 3.0) + max(0.0, vgap) * 2.0 + max(0.0, sgap) * 1.5 + min(3.0, repeat * .05), 0, 15)
    second = 0.0
    if c.entry_state == 'REACCEL': second += 7.0
    if bool(m.get('sell_to_buy_flip')): second += 3.0
    if bool(m.get('smart_money_realtime_proxy_surge')): second += 2.0
    if str(c.metrics.get('nxt_second_wave_state') or '') == 'SECOND_WAVE_BUY': second += 8.0
    elif str(c.metrics.get('nxt_second_wave_state') or '') == 'SECOND_WAVE_READY': second += 5.0
    if energy >= 80: second += 2.0
    second = _clamp(second, 0, 15)
    score = _clamp(money + flow + retain + accept + second)
    stage = 'POWER TREND' if score >= 84 and retain >= 13 and flow >= 15 else 'SECOND WAVE' if second >= 8 and score >= 72 else 'HIGH ACCEPT' if accept >= 10 and score >= 68 else 'BUILDING' if score >= 58 else 'EARLY'
    # Separate extension/distribution risk; gain itself is not an automatic disqualifier.
    risk = _clamp(max(0.0, vgap - 2.0) * 9.0 + max(0.0, 50.0 - retention_pct) * .5 + (10 if bp < 44 else 0) + (8 if rate > 14 and flow < 12 else 0))
    return round(score,1), {'money_regime':round(money,1),'dominant_flow':round(flow,1),'gain_retention':round(retain,1),'high_acceptance':round(accept,1),'second_wave':round(second,1),'retention_pct':round(retention_pct,1)}, stage, round(risk,1)


@dataclass(slots=True)
class EnergyPathEngine:
    state: Any
    _history: dict[str, deque] = field(default_factory=lambda: defaultdict(lambda: deque(maxlen=180)))
    _last_sample_at: float = 0.0
    _stable_energy_codes: list[str] = field(default_factory=list)
    _stable_path_codes: list[str] = field(default_factory=list)
    _energy_entered_at: dict[str, float] = field(default_factory=dict)
    _path_entered_at: dict[str, float] = field(default_factory=dict)
    _last_energy_rank_at: float = 0.0
    _last_path_rank_at: float = 0.0
    _last_live_energy: list[dict[str,Any]] = field(default_factory=list)
    _last_live_path: list[dict[str,Any]] = field(default_factory=list)
    _last_live_at: float = 0.0

    def mode(self) -> str:
        if not SETTINGS.r492_extension_enabled:
            return 'R491_SAFE'
        lm = str(getattr(self.state,'load_mode','NORMAL') or 'NORMAL')
        if lm == 'CRITICAL': return 'R491_SAFE'
        if lm == 'HIGH_LOAD': return 'DEGRADED'
        return 'NORMAL' if lm == 'NORMAL' else 'DEGRADED'

    def caps(self) -> tuple[int,int,int]:
        lm = str(getattr(self.state,'load_mode','NORMAL') or 'NORMAL')
        if lm == 'NORMAL': return SETTINGS.r492_shared_pool_cap, SETTINGS.r492_energy_candidate_cap, SETTINGS.r492_path_candidate_cap
        if lm == 'BUSY': return min(30,SETTINGS.r492_shared_pool_cap), min(18,SETTINGS.r492_energy_candidate_cap), min(20,SETTINGS.r492_path_candidate_cap)
        if lm == 'HIGH_LOAD': return min(20,SETTINGS.r492_shared_pool_cap), min(12,SETTINGS.r492_energy_candidate_cap), 0
        return 0,0,0

    @staticmethod
    def _fresh(c: Candidate, now: float) -> bool:
        v=c.current();m=v.metrics or {}
        return bool(v.last_price>0 and v.last_tick_at and now-v.last_tick_at<=9.0 and not v.continuity_reason and not v.resync_required and m.get('fresh',True))

    def _shared_pool(self, cands: list[Candidate], now: float, cap: int) -> list[Candidate]:
        scored=[]
        for c in cands:
            if not self._fresh(c,now): continue
            e=early_edge(c,now=now); scout=discovery_scout_score(c,now)
            v=c.current();m=v.metrics or {}
            flow=max(0.0,_f(m.get('buy_pressure'))-50.0)+max(0.0,_f(m.get('smart_money_realtime_proxy_score'))*2.0)+max(0.0,_f(m.get('turnover_accel_30s'),1)-1.0)*10.0
            key=max(_f(c.priority_score),_f(c.score),_f(e.get('score')),scout,flow)
            scored.append((key,_f(c.last_seen_at),c))
        scored.sort(key=lambda x:(x[0],x[1]),reverse=True)
        return [c for _,__,c in scored[:cap]]

    def _delta(self, code: str, now: float, pos: int, lookback: float) -> float:
        hist=self._history.get(code)
        if not hist: return 0.0
        current=hist[-1][pos]
        old=None
        for item in reversed(hist):
            if now-item[0] >= lookback:
                old=item[pos];break
        return round(current-old,1) if old is not None else 0.0

    def _stable(self, ranked:list[dict[str,Any]], now:float, board:str)->list[dict[str,Any]]:
        if board=='energy':
            old=list(self._stable_energy_codes); entered=self._energy_entered_at; last=self._last_energy_rank_at; rank_sec=SETTINGS.r492_energy_rank_sec; dwell=SETTINGS.r492_energy_min_dwell_sec; gap=SETTINGS.r492_energy_entry_gap
        else:
            old=list(self._stable_path_codes); entered=self._path_entered_at; last=self._last_path_rank_at; rank_sec=SETTINGS.r492_path_rank_sec; dwell=SETTINGS.r492_path_min_dwell_sec; gap=SETTINGS.r492_path_entry_gap
        by={r['code']:r for r in ranked}; slots=10
        if not old:
            out=ranked[:slots];old=[r['code'] for r in out]
            for c in old:entered[c]=now
            if board=='energy':self._stable_energy_codes=old;self._last_energy_rank_at=now
            else:self._stable_path_codes=old;self._last_path_rank_at=now
            return out
        existing=[by[c] for c in old if c in by];seen={r['code'] for r in existing}
        for r in ranked:
            if len(existing)>=slots:break
            if r['code'] not in seen:existing.append(r);seen.add(r['code']);entered.setdefault(r['code'],now)
        if last and now-last<rank_sec:
            out=existing[:slots]
        else:
            for new in ranked:
                if new['code'] in seen:continue
                repl=[(i,r) for i,r in enumerate(existing) if now-entered.get(r['code'],now)>=dwell]
                if not repl:break
                wi,weak=min(repl,key=lambda x:_f(x[1].get('rank_score')))
                if _f(new.get('rank_score')) < _f(weak.get('rank_score'))+gap:continue
                seen.discard(weak['code']);entered.pop(weak['code'],None);existing[wi]=new;seen.add(new['code']);entered[new['code']]=now
            existing.sort(key=lambda r:(_f(r.get('rank_score')),_f(r.get('delta')),_f(r.get('last_tick_at'))),reverse=True)
            out=existing[:slots]
            if board=='energy':self._last_energy_rank_at=now
            else:self._last_path_rank_at=now
        codes=[r['code'] for r in out]
        if board=='energy':self._stable_energy_codes=codes
        else:self._stable_path_codes=codes
        for c in list(entered):
            if c not in codes:entered.pop(c,None)
        return out

    def build(self, cands:list[Candidate], now:float, active:bool, pre_codes:set[str]|None=None) -> dict[str,Any]:
        mode=self.mode();shared_cap,energy_cap,path_cap=self.caps()
        if not active:
            return {'mode':'FROZEN','load_mode':getattr(self.state,'load_mode','NORMAL'),'shared_pool':0,'energy':copy.deepcopy(self._last_live_energy),'path':copy.deepcopy(self._last_live_path),'market_context':copy.deepcopy(getattr(self.state,'market_context',{})),'frozen_at':self._last_live_at or None}
        if mode=='R491_SAFE':
            return {'mode':'R491_SAFE','load_mode':getattr(self.state,'load_mode','CRITICAL'),'shared_pool':0,'energy':[],'path':[],'market_context':copy.deepcopy(getattr(self.state,'market_context',{})),'frozen_at':None}
        pool=self._shared_pool(cands,now,shared_cap)
        scored=[]
        pre_codes=pre_codes or set()
        for c in pool:
            e,ec,erisk,estage=_energy_components(c,now)
            p,pc,pstage,prisk=_path_components(c,e,now)
            scored.append((c,e,ec,erisk,estage,p,pc,pstage,prisk))
        # sample only once per ~30s. This is CPU-only state already in RAM.
        if now-self._last_sample_at>=25:
            for c,e,_,__,___,p,____,_____,______ in scored:self._history[c.code].append((now,e,p,c.current().last_price))
            self._last_sample_at=now
        energy=[];path=[]
        for c,e,ec,erisk,estage,p,pc,pstage,prisk in scored:
            v=c.current();fm=discovery_freshness(c,now)
            ed=self._delta(c.code,now,1,180);pd=self._delta(c.code,now,2,300)
            tags=[]
            if c.code in pre_codes:tags.append('PRE')
            if p>=70:tags.append('PATH')
            if e>=75:tags.append('ENERGY')
            mo=market_overlay(self.state,c,now,SETTINGS.r493_energy_market_adj_cap)
            path_mo=market_overlay(self.state,c,now,SETTINGS.r493_path_market_adj_cap)
            base={'code':c.code,'name':c.name or c.code,'venue':v.venue.value,'price':v.last_price,'change_rate':v.last_rate,'last_tick_at':v.last_tick_at,'fresh_label':fm.get('label',''),'overlap_tags':tags,**mo}
            energy.append({**base,'score':e,'rank_score_raw':e+max(0,ed)*.35,'rank_score':e+max(0,ed)*.35+_f(mo.get('market_adjustment')),'delta':ed,'stage':estage,'risk':erisk,'components':ec})
            pbase={**base,**{k:v for k,v in path_mo.items() if k.startswith('market_')}}
            path.append({**pbase,'score':p,'rank_score_raw':p+max(0,pd)*.2,'rank_score':p+max(0,pd)*.2+_f(path_mo.get('market_adjustment')),'delta':pd,'stage':pstage,'risk':prisk,'components':pc})
        energy.sort(key=lambda r:(r['rank_score'],r['score'],r['last_tick_at']),reverse=True)
        path.sort(key=lambda r:(r['rank_score'],r['score'],r['last_tick_at']),reverse=True)
        energy=self._stable(energy[:energy_cap],now,'energy') if energy_cap else []
        # Under HIGH_LOAD, PATH is the first feature paused; keep last rows rather than spend compute/rank churn.
        if path_cap:
            path=self._stable(path[:path_cap],now,'path')
        else:
            path=copy.deepcopy(self._last_live_path)
            for r in path:r['paused']=True
        self._last_live_energy=copy.deepcopy(energy);self._last_live_path=copy.deepcopy(path);self._last_live_at=now
        return {'mode':mode,'load_mode':getattr(self.state,'load_mode','NORMAL'),'shared_pool':len(pool),'energy_candidates':min(len(scored),energy_cap),'path_candidates':min(len(scored),path_cap) if path_cap else 0,'energy':energy[:10],'path':path[:10],'market_context':copy.deepcopy(getattr(self.state,'market_context',{})),'frozen_at':None}
