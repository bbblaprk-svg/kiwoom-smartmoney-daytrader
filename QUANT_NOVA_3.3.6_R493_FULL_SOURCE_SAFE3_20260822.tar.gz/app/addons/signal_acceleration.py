from __future__ import annotations

from datetime import datetime
from typing import Any

from app.config import SETTINGS
from app.domain import Candidate, Venue
from app.runtime.clock import KST, trade_day
from app.signal.early_edge import early_edge


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v if v is not None else default)
    except Exception:
        return default


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def _session_close_reference(venue: Venue, day: str | None = None) -> float:
    d = datetime.strptime(day or trade_day(), '%Y%m%d').replace(tzinfo=KST)
    if venue == Venue.KRX:
        d = d.replace(hour=15, minute=30, second=0, microsecond=0)
    else:
        d = d.replace(hour=20, minute=0, second=0, microsecond=0)
    return d.timestamp()


def _reference_fresh(v: Any, ref_at: float, max_age: float = 600.0) -> bool:
    if not v.last_tick_at or v.last_price <= 0:
        return False
    age = ref_at - _f(v.last_tick_at)
    return bool(-60.0 <= age <= max_age and not v.continuity_reason and not v.resync_required)


def signal_windows_5_15_30(c: Candidate, now: float) -> dict[str, Any]:
    """Count committed formal SIGNAL events in overlapping 5/15/30m windows.

    SIGNAL_REPEAT_RAW/TOP10/history noise is intentionally excluded. R49.1 adds a
    separate current-live-evidence lane, so formal cadence remains semantically clean.
    """
    n5 = n15 = n30 = 0
    last = 0.0
    states: set[str] = set()
    venues: set[str] = set()
    for e in list(c.history):
        if e.kind != 'SIGNAL':
            continue
        age = now - _f(e.at)
        if age < 0 or age > 1800:
            continue
        n30 += 1
        last = max(last, _f(e.at))
        states.add(str(e.state or 'SIGNAL'))
        venues.add(e.venue.value if e.venue else 'UNKNOWN')
        if age <= 900:
            n15 += 1
        if age <= 300:
            n5 += 1
    return {'n5': n5, 'n15': n15, 'n30': n30, 'last': last, 'states': states, 'venues': venues}


def signal_windows_legacy(c: Candidate, now: float) -> tuple[int, int, float]:
    w = signal_windows_5_15_30(c, now)
    n10 = 0
    for e in list(c.history):
        if e.kind != 'SIGNAL':
            continue
        age = now - _f(e.at)
        if 0 <= age <= 600:
            n10 += 1
    return n10, int(w['n30']), _f(w['last'])


def legacy_accel_metrics(n10: int, n30: int) -> tuple[float, float, float, float]:
    recent = max(0, int(n10)); total = max(recent, int(n30)); prev20 = max(0, total - recent)
    prev_rate = prev20 / 2.0; delta = recent - prev_rate; ratio = (recent + .5) / (prev_rate + .5)
    return float(prev20), round(prev_rate, 3), round(delta, 3), round(ratio, 3)


def legacy_accel_label(n10: int, n30: int) -> str:
    _, _, delta, _ = legacy_accel_metrics(n10, n30)
    if n10 >= 2 and delta >= 1.0: return '↑↑'
    if n10 >= 1 and delta >= .5: return '↑'
    if n30 >= 1 and delta <= -.75: return '↓'
    return '→'


def acceleration_metrics(w: dict[str, Any]) -> dict[str, float]:
    n5 = int(w['n5']); n15 = int(w['n15']); n30 = int(w['n30'])
    prev10 = max(0, n15 - n5); prev15 = max(0, n30 - n15)
    prev10_rate5 = prev10 / 2.0
    prev15_rate5 = prev15 / 3.0
    accel5 = n5 - prev10_rate5
    recent15_rate5 = n15 / 3.0
    accel15 = recent15_rate5 - prev15_rate5
    weighted = n5 * 3 + n15 * 2 + n30
    return {
        'prev10_count': float(prev10), 'prev15_count': float(prev15),
        'prev10_rate5': round(prev10_rate5, 3), 'prev15_rate5': round(prev15_rate5, 3),
        'accel5': round(accel5, 3), 'accel15': round(accel15, 3), 'weighted_count': float(weighted),
    }


def accel_label(w: dict[str, Any], a: dict[str, float], live_profile: dict[str, Any] | None = None) -> str:
    n5 = int(w['n5']); n15 = int(w['n15'])
    if n5 >= 2 and a['accel5'] >= 1.0: return '↑↑'
    if (n5 >= 1 and a['accel5'] >= .5) or (n15 >= 2 and a['accel15'] >= .35): return '↑'
    if live_profile and live_profile.get('strong') and _f(live_profile.get('accel_score')) >= 16: return '↑↑'
    if live_profile and live_profile.get('qualified') and _f(live_profile.get('accel_score')) >= 9: return '↑'
    if n15 >= 1 and a['accel5'] <= -.75 and a['accel15'] <= 0: return '↓'
    return '→'


def evidence_types(c: Candidate, m: dict[str, Any], w: dict[str, Any]) -> list[str]:
    out: list[str] = []
    if w['states']: out.append('FORMAL_SIGNAL')
    if _f(m.get('buy_pressure_delta_30s')) >= 3: out.append('BP_ACCEL')
    if bool(m.get('smart_money_realtime_proxy_surge')): out.append('SMART_SURGE')
    if bool(m.get('sell_to_buy_flip')): out.append('SELL_TO_BUY')
    if _f(m.get('smart_money_acceleration'), 1) >= 1.2: out.append('SMART_ACCEL')
    if bool(m.get('volume_accel_ready')) and _f(m.get('volume_accel'), 1) >= 1.25: out.append('VOLUME_ACCEL')
    if bool(m.get('turnover_accel_ready')) and _f(m.get('turnover_accel_30s'), 1) >= 1.15: out.append('TURNOVER_ACCEL')
    if bool(m.get('program_fresh')) and _f(m.get('program_delta')) > 0: out.append('PROGRAM_BUY')
    if _f(c.metrics.get('discovery_rank_velocity_pos')) >= 4: out.append('RANK_ACCEL')
    return out


def live_evidence_profile(c: Candidate, m: dict[str, Any], types: list[str]) -> dict[str, Any]:
    """Evaluate current, non-formal evidence for pre-surge discovery.

    This lane is display-only. It never writes ENTRY_V18, never creates a formal
    SIGNAL, and never changes broker subscription rules. A candidate needs both
    current flow and current activity; sheer historical repetition cannot qualify.
    """
    live_types = [x for x in types if x != 'FORMAL_SIGNAL']
    t = set(live_types)
    bp = 'BP_ACCEL' in t
    smart = bool(t & {'SMART_SURGE', 'SELL_TO_BUY', 'SMART_ACCEL', 'PROGRAM_BUY'})
    activity = bool(t & {'VOLUME_ACCEL', 'TURNOVER_ACCEL'})
    discovery = 'RANK_ACCEL' in t

    # 3+ diverse current evidences plus flow/activity are enough to keep the symbol
    # visible for a bounded episode. Strong=4+ and requires both BP and smart-flow.
    qualified = bool(len(live_types) >= 3 and activity and (bp or smart) and (smart or discovery))
    strong = bool(len(live_types) >= 4 and activity and bp and smart)

    bp_d = max(0.0, _f(m.get('buy_pressure_delta_30s')))
    sm_a = max(1.0, _f(m.get('smart_money_acceleration'), 1.0))
    vol = max(1.0, _f(m.get('volume_accel'), 1.0)) if bool(m.get('volume_accel_ready')) else 1.0
    turn = max(1.0, _f(m.get('turnover_accel_30s'), 1.0)) if bool(m.get('turnover_accel_ready')) else 1.0
    rank_v = max(0.0, _f(c.metrics.get('discovery_rank_velocity_pos')))
    accel = 0.0
    accel += _clamp(bp_d * 1.15, 0, 8.0)
    accel += _clamp((sm_a - 1.0) * 10.0, 0, 4.0)
    accel += 2.0 if 'SMART_SURGE' in t else 0.0
    accel += 1.0 if 'SELL_TO_BUY' in t else 0.0
    accel += _clamp((vol - 1.0) * 4.0, 0, 3.5)
    accel += _clamp((turn - 1.0) * 5.0, 0, 3.5)
    accel += _clamp(rank_v * .35, 0, 3.0)
    accel = _clamp(accel, 0, 25)
    return {
        'types': live_types,
        'count': len(live_types),
        'qualified': qualified,
        'strong': strong,
        'bp': bp,
        'smart': smart,
        'activity': activity,
        'discovery': discovery,
        'accel_score': round(accel, 1),
    }


def signal_acceleration_score(c: Candidate, m: dict[str, Any], w: dict[str, Any], a: dict[str, float], edge: dict[str, Any]) -> tuple[float, dict[str, float], list[str]]:
    """100pt display-only score.

    R49.1 keeps formal cadence intact but permits current live acceleration to supply
    the acceleration component before the first formal SIGNAL. This closes the R49
    blind spot without altering ENTRY_V18.
    """
    n5, n15, n30 = int(w['n5']), int(w['n15']), int(w['n30'])
    types = evidence_types(c, m, w)
    lp = live_evidence_profile(c, m, types)
    cadence = _clamp(n5 * 5.0 + n15 * 1.5 + n30 * .45, 0, 25)
    # A confirmed live-evidence lane gets a small bounded cadence proxy; it does not
    # masquerade as formal history but prevents a mathematically impossible pre-SIGNAL score.
    if lp['qualified']:
        cadence = max(cadence, _clamp(lp['count'] * 1.5, 0, 9.0))
    formal_accel = _clamp(max(0, a['accel5']) * 8.0 + max(0, a['accel15']) * 6.0, 0, 25)
    accel = max(formal_accel, _f(lp['accel_score']) if lp['qualified'] else 0.0)
    diversity = _clamp(len(types) * 3.0, 0, 15)
    bp = _f(m.get('buy_pressure'), 50); bp_d = _f(m.get('buy_pressure_delta_30s'))
    sm_a = _f(m.get('smart_money_acceleration'), 1); sm = _f(m.get('smart_money_realtime_proxy_score'))
    flow = _clamp(max(0, bp - 50) * .45 + max(0, bp_d) * .45 + max(0, sm_a - 1) * 4 + max(0, sm) * .35, 0, 15)
    if bool(m.get('smart_money_realtime_proxy_surge')): flow = min(15, flow + 3)
    if bool(m.get('sell_to_buy_flip')): flow = min(15, flow + 2)
    headroom = _clamp(_f(edge.get('headroom_score')) * .4, 0, 10)
    vgap = _f(m.get('micro_vwap_gap'))
    vwap = 5.0 if -.35 <= vgap <= .8 else 3.0 if -.7 <= vgap <= 1.35 else 0.0
    sector = _clamp(_f(c.metrics.get('sector_score')), 0, 5)
    score = cadence + accel + diversity + flow + headroom + vwap + sector
    if edge.get('chase_block'): score = min(score, 48.0)
    if _f(c.current().last_rate) >= 7.5: score = min(score, 42.0)
    components = {
        'cadence': round(cadence,1),'acceleration':round(accel,1),'formal_acceleration':round(formal_accel,1),
        'live_acceleration':round(_f(lp['accel_score']),1),'diversity':round(diversity,1),'flow':round(flow,1),
        'headroom':round(headroom,1),'vwap':round(vwap,1),'sector':round(sector,1)
    }
    return round(_clamp(score), 1), components, types


def entry_candidate_state(c: Candidate, m: dict[str, Any], w: dict[str, Any], a: dict[str, float], edge: dict[str, Any], score: float, types: list[str], now: float, live_fresh: bool = False) -> tuple[str, int, list[str]]:
    rate = _f(c.current().last_rate); vgap = _f(m.get('micro_vwap_gap')); bp = _f(m.get('buy_pressure'), 50)
    lp = live_evidence_profile(c, m, types)
    sm_ok = bool(m.get('smart_money_realtime_proxy_surge')) or bool(m.get('sell_to_buy_flip')) or _f(m.get('smart_money_acceleration'),1) >= 1.15
    flow_ok = bp >= 56 and (_f(m.get('buy_pressure_delta_30s')) >= 2 or sm_ok)
    formal_accel_ok = (int(w['n5']) >= 2 and a['accel5'] >= .5) or (int(w['n5']) >= 1 and a['accel5'] >= 1.0) or (int(w['n15']) >= 3 and a['accel15'] > 0)
    acceleration_ok = bool(formal_accel_ok or lp['strong'])
    price_ok = not bool(edge.get('chase_block')) and rate <= 5.5 and -.45 <= vgap <= 1.35
    activity_ok = (bool(m.get('volume_accel_ready')) and _f(m.get('volume_accel'),1) >= 1.25) or (bool(m.get('turnover_accel_ready')) and _f(m.get('turnover_accel_30s'),1) >= 1.15)
    last = _f(w.get('last'))
    formal_fresh = bool(last and now-last <= SETTINGS.signal_accel_entry_fresh_sec)
    freshness_ok = bool(formal_fresh or (live_fresh and lp['qualified']))
    checks = [('가속증거',acceleration_ok),('수급',flow_ok),('가격위치',price_ok),('거래가속',activity_ok),('실시간신선도',freshness_ok)]
    passed = sum(1 for _, ok in checks if ok)
    cooling = bool(edge.get('chase_block')) or rate >= 7.5 or (int(w['n15']) >= 3 and int(w['n5']) == 0 and not flow_ok and not lp['qualified'])
    if cooling:
        state = 'COOLING'
    elif score >= 62 and passed >= 4 and len(types) >= 2:
        state = '진입대상'
    else:
        state = '관찰'
    reasons = [name for name,ok in checks if ok]
    return state, passed, reasons


def pre_row(c: Candidate, now: float, active: bool, reference_at: float | None = None) -> dict[str, Any] | None:
    v = c.current(); m = v.metrics or {}; venue = v.venue
    if v.last_price <= 0 or c.entry_state == 'BUY':
        return None
    live_age = now - _f(v.last_tick_at) if v.last_tick_at else 10**9
    live_fresh = bool(v.last_price > 0 and live_age <= 9.0 and not v.continuity_reason and not v.resync_required and m.get('fresh', True))
    ref_at = now if active else (reference_at or _session_close_reference(venue))
    fresh = live_fresh if active else _reference_fresh(v, ref_at)
    w = signal_windows_5_15_30(c, ref_at); a = acceleration_metrics(w); edge = early_edge(c, now=ref_at)
    types = evidence_types(c, m, w); lp = live_evidence_profile(c, m, types)
    last_age = ref_at - _f(w['last']) if w['last'] else 10**9
    fast_scout = bool(edge.get('fast_scout'))
    formal_recent = bool(last_age <= SETTINGS.signal_accel_signal_ttl_sec)
    live_lane = bool(active and live_fresh and lp['qualified'] and not formal_recent and not fast_scout)

    # R49.1 anti-stickiness + pre-formal discovery:
    # stale pins still need CURRENT evidence. A strong live-evidence episode may qualify
    # before the first formal signal; DecisionPanelEngine caps that continuous episode at 10m.
    if active and not fresh:
        return None
    if active and not (formal_recent or fast_scout or lp['qualified']):
        return None
    if active and not w['n30'] and not ((fast_scout and len(types) >= 2) or lp['qualified']):
        return None

    score, components, types = signal_acceleration_score(c, m, w, a, edge)
    n10, n30_legacy, _ = signal_windows_legacy(c, ref_at)
    prev20, prev20_rate, accel_delta, accel_ratio = legacy_accel_metrics(n10, n30_legacy)
    state, passed, entry_reasons = entry_candidate_state(c, m, w, a, edge, score, types, ref_at, live_fresh=live_fresh)
    reasons = []
    if a['accel5'] >= .5: reasons.append(f"5분 가속 +{a['accel5']:.1f}")
    elif lp['strong']: reasons.append(f"LIVE 가속 {lp['accel_score']:.1f}")
    elif a['accel5'] <= -.75: reasons.append(f"5분 둔화 {a['accel5']:.1f}")
    if w['n5']: reasons.append(f"최근5분 {w['n5']}회")
    elif live_lane: reasons.append(f"공식신호 전 LIVE {lp['count']}종")
    if len(types) >= 2: reasons.append(f"동시증거 {len(types)}종")
    reasons.extend(list(edge.get('reasons') or [])[:2])
    return {
        'code':c.code,'name':c.name or c.code,'venue':venue.value,'price':v.last_price,'change_rate':v.last_rate,
        'score':score,'state':state,'window_mode':'LIVE' if active else 'CLOSE','frozen':not active,'reference_at':ref_at,
        'fresh':fresh,'repeat_total':c.valid_repeat_count,'signal_5m':int(w['n5']),'signal_15m':int(w['n15']),'signal_30m':int(w['n30']),
        'signal_10m':n10,'prev20_signal_count':int(prev20),'prev20_rate_10m':prev20_rate,
        'accel_delta':accel_delta,'accel_ratio':accel_ratio,'accel':accel_label(w,a,lp),'last_signal_at':_f(w['last']),
        'last_signal_age_sec':round(last_age,1) if last_age < 10**8 else None,'accel_5m':a['accel5'],'accel_15m':a['accel15'],
        'weighted_signal_count':a['weighted_count'],'signal_type_count':len(types),'signal_types':types[:8],
        'live_evidence_count':int(lp['count']),'live_evidence_types':list(lp['types'])[:8],'live_evidence_qualified':bool(lp['qualified']),
        'live_evidence_strong':bool(lp['strong']),'live_evidence_accel':_f(lp['accel_score']),'live_evidence_lane':live_lane,
        'formal_recent':formal_recent,
        'entry_candidate_checks':passed,'entry_candidate_reasons':entry_reasons,'rank_score':score,'rank_basis':'SIGNAL_ACCELERATION_5_15_30_PLUS_LIVE_EVIDENCE',
        'score_components':components,'early_edge_score':_f(edge.get('score')),'headroom_score':_f(edge.get('headroom_score')),'chase_penalty':_f(edge.get('penalty')),
        'fresh_age_sec':edge.get('fresh_age_sec'),'fresh_label':edge.get('fresh_label',''),'fast_scout':fast_scout,
        'rank_trend':edge.get('rank_trend','FLAT'),'rank_velocity':edge.get('rank_velocity',0.0),'fresh_window':bool(edge.get('fresh_window')),
        'rank_lane':'LIVE_EVIDENCE' if live_lane else ('FRESH' if fast_scout and not w['n30'] else 'SIGNAL'),
        'buy_pressure':round(_f(m.get('buy_pressure'),50),1),'volume_accel':round(_f(m.get('volume_accel'),1),2),
        'turnover_accel':round(_f(m.get('turnover_accel_30s'),1),2),'vwap_gap':round(_f(m.get('micro_vwap_gap')),2),
        'smart_money_score':round(_f(m.get('smart_money_realtime_proxy_score')),1),'reasons':reasons[:5],
        'entry_state':c.entry_state,'lifecycle_state':c.lifecycle_state,
    }
