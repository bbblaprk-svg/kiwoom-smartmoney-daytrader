from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Iterable

from app.config import SETTINGS, exploration_slots_for_mode
from app.domain import Candidate, Venue
from app.signal.early_edge import discovery_scout_score


@dataclass(frozen=True, slots=True)
class RotationResult:
    selected: set[str]
    added: set[str]
    removed: set[str]
    desired: int
    eligible: int
    rotated: int


class MarketRotation:
    """Bounded VERIFY-only rotation over already-discovered market candidates.

    This class never calls the broker.  Discovery supplies candidates from its
    existing fourteen ranking requests and WebSocket registration consumes only
    spare TRADE slots below the unchanged session ceiling.
    """

    def __init__(self) -> None:
        self.day = ''
        self.entered_at: dict[str, float] = {}
        self.exited_at: dict[str, float] = {}
        self.last_rotate_at = 0.0
        self.total_rotations = 0

    @staticmethod
    def target_for_mode(mode: str) -> int:
        return exploration_slots_for_mode(mode)

    @staticmethod
    def _recent(candidate: Candidate, now: float) -> bool:
        latest = max(candidate.source_hits.values(), default=0.0)
        return bool(latest and now - latest <= SETTINGS.discovery_source_ttl_sec)

    @staticmethod
    def _promising(candidate: Candidate) -> bool:
        for venue in (Venue.KRX, Venue.NXT):
            lane = candidate.venue_state[venue]
            metrics = lane.metrics
            if not metrics.get('fresh') or not metrics.get('volume_accel_ready'):
                continue
            rate = float(lane.last_rate or 0.0)
            accel = float(metrics.get('volume_accel') or 1.0)
            pressure = float(metrics.get('buy_pressure') or 50.0)
            strength = float(metrics.get('execution_strength') or 100.0)
            turnover = float(metrics.get('turnover_60s') or 0.0)
            vwap_gap = float(metrics.get('session_vwap_gap') or 0.0)
            if -0.5 <= rate < 15 and accel >= 1.25 and pressure >= 54 and strength >= 105 and turnover >= 30_000_000 and vwap_gap >= -0.2:
                return True
        return False

    @staticmethod
    def _rank(candidate: Candidate) -> tuple:
        # DiscoveryEngine computes EARLY EDGE once per rank cycle and stores only
        # bounded scalar results on the candidate. Rotation consumes those cached
        # values rather than rebuilding the full score for every candidate/sort.
        # This preserves the 1GB Lightsail latency budget and keeps this class
        # broker-call-free.
        m=candidate.metrics
        scout=float(m.get('discovery_scout_score') or discovery_scout_score(candidate))
        edge=float(m.get('early_edge_score') or 0.0)
        headroom=float(m.get('early_edge_headroom') or 0.0)
        return (
            scout,
            edge,
            headroom,
            max(candidate.source_hits.values(), default=0.0),
            candidate.rest_base,
            candidate.code,
        )

    def reset(self, day: str) -> None:
        self.day = day
        self.entered_at.clear()
        self.exited_at.clear()
        self.last_rotate_at = 0.0

    def select(
        self,
        candidates: Iterable[Candidate],
        current: set[str],
        blocked: set[str],
        desired: int,
        day: str,
        now: float | None = None,
    ) -> RotationResult:
        now = time.time() if now is None else float(now)
        if day != self.day:
            self.reset(day)
        desired = max(0, int(desired))
        rows = [candidate for candidate in candidates if candidate.code not in blocked and self._recent(candidate, now)]
        # Compute the EARLY-EDGE ordering once per cycle.  Rotation has a bounded
        # latency contract, so repeated score reconstruction inside several sort
        # keys is deliberately avoided.
        rank_by_code = {candidate.code: self._rank(candidate) for candidate in rows}
        rows.sort(key=lambda candidate: rank_by_code[candidate.code], reverse=True)
        by_code = {candidate.code: candidate for candidate in rows}
        selected = {code for code in current if code in by_code}
        removed = set(current) - selected

        # Load shedding and reduced headroom take effect immediately.  Prefer to
        # retain promising rows, then newer rows, while never exceeding desired.
        if len(selected) > desired:
            keep = sorted(
                selected,
                key=lambda code: (
                    self._promising(by_code[code]),
                    self.entered_at.get(code, now),
                    rank_by_code[code],
                ),
                reverse=True,
            )[:desired]
            dropped = selected - set(keep)
            selected = set(keep)
            removed.update(dropped)

        additions = [candidate for candidate in rows if candidate.code not in selected]
        additions.sort(
            key=lambda candidate: (
                now - self.exited_at.get(candidate.code, 0.0) >= SETTINGS.exploration_cooldown_sec,
                rank_by_code[candidate.code],
            ),
            reverse=True,
        )
        added: set[str] = set()

        # Fill vacant slots immediately, including the first cycle and recovery
        # from BUSY/HIGH load.  Recently exited rows are used only if necessary.
        missing = max(0, desired - len(selected))
        for candidate in additions[:missing]:
            selected.add(candidate.code)
            added.add(candidate.code)

        rotated = 0
        rotation_due = desired > 0 and now - self.last_rotate_at >= SETTINGS.exploration_rotate_sec
        if rotation_due and len(selected) >= desired:
            fresh_additions = [
                candidate for candidate in rows
                if candidate.code not in selected
                and now - self.exited_at.get(candidate.code, 0.0) >= SETTINGS.exploration_cooldown_sec
            ]
            removable = [
                code for code in selected
                if now - self.entered_at.get(code, now) >= SETTINGS.exploration_min_dwell_sec
                and (not self._promising(by_code[code]) or now - self.entered_at.get(code, now) >= SETTINGS.exploration_max_hold_sec)
            ]
            removable.sort(key=lambda code: (self._promising(by_code[code]), self.entered_at.get(code, now)))
            count = min(SETTINGS.exploration_rotation_batch, len(fresh_additions), len(removable))
            for old_code, candidate in zip(removable[:count], fresh_additions[:count], strict=True):
                selected.remove(old_code)
                selected.add(candidate.code)
                removed.add(old_code)
                added.add(candidate.code)
                rotated += 1
            self.last_rotate_at = now
            if rotated:
                self.total_rotations += rotated

        # Apply timestamps only after the final selection is known.
        for code in removed:
            self.entered_at.pop(code, None)
            self.exited_at[code] = now
        for code in added:
            self.entered_at[code] = now
        for code in selected:
            self.entered_at.setdefault(code, now)
        # Keep cooldown bookkeeping bounded to the candidate TTL horizon.
        cutoff = now - max(SETTINGS.exploration_cooldown_sec * 2, SETTINGS.discovery_source_ttl_sec * 2)
        self.exited_at = {code: at for code, at in self.exited_at.items() if at >= cutoff}
        return RotationResult(selected, added, removed, desired, len(rows), rotated)
