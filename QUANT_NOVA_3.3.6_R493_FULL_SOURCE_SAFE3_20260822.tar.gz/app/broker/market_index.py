from __future__ import annotations

import time
from typing import Any

from app.broker.kiwoom import REST
from app.runtime.clock import sessions


def _num(v: Any, default: float = 0.0) -> float:
    try:
        return float(str(v if v is not None else default).replace(',', '').strip() or default)
    except Exception:
        return default


def _regime(rate: float, breadth: float) -> str:
    if rate <= -2.0 or breadth <= -40.0:
        return 'PANIC'
    if rate <= -0.7 or breadth <= -20.0:
        return 'RISK_OFF'
    if rate >= 0.7 and breadth >= 10.0:
        return 'RISK_ON'
    return 'NEUTRAL'


class MarketIndexMonitor:
    """Low-priority KOSPI/KOSDAQ context using Kiwoom ka20001.

    It is deliberately isolated from the core discovery loop.  Two REST requests
    per refresh are made only during the KRX regular session, never in candidate/
    offline mode, and the caller can pause it under load.  Failure preserves the
    last good snapshot; consumers fail open with zero adjustment when stale.
    """

    API_ID = 'ka20001'
    API_PATH = '/api/dostk/sect'
    SPECS = (
        ('KOSPI', '001', {'mrkt_tp': '0', 'inds_cd': '001'}),
        ('KOSDAQ', '101', {'mrkt_tp': '1', 'inds_cd': '101'}),
    )

    def __init__(self, state: Any):
        self.state = state
        self.last_status: dict[str, Any] = {'active': False, 'source': 'KIWOOM_KA20001', 'updated_at': 0.0}

    @staticmethod
    def _parse(name: str, code: str, payload: dict[str, Any], now: float) -> dict[str, Any]:
        rate = _num(payload.get('flu_rt'))
        # ka20001 official response exposes five market-breadth buckets:
        # upl / rising / stdns / fall / lst.  Use all five so upper/lower-limit
        # names are not silently dropped from the denominator or direction.
        upper = int(abs(_num(payload.get('upl'))))
        rising = int(abs(_num(payload.get('rising'))))
        flat = int(abs(_num(payload.get('stdns'))))
        fall = int(abs(_num(payload.get('fall'))))
        lower = int(abs(_num(payload.get('lst'))))
        denom = max(1, upper + rising + flat + fall + lower)
        breadth = ((upper + rising) - (fall + lower)) / denom * 100.0
        return {
            'name': name,
            'market_code': code,
            'index': abs(_num(payload.get('cur_prc'))),
            'change_rate': round(rate, 3),
            'breadth': round(breadth, 2),
            'upper': upper,
            'rising': rising,
            'fall': fall,
            'lower': lower,
            'flat': flat,
            'breadth_total': denom,
            'regime': _regime(rate, breadth),
            'updated_at': now,
            'source': 'KIWOOM_KA20001',
            'ok': True,
        }

    async def cycle(self) -> dict[str, Any]:
        now = time.time()
        if not sessions().get('krx'):
            self.last_status = {'active': False, 'source': 'KIWOOM_KA20001', 'updated_at': now, 'reason': 'KRX_OFF_SESSION'}
            return self.last_status
        started = time.monotonic()
        fresh: dict[str, dict[str, Any]] = {}
        errors: dict[str, str] = {}
        for name, code, body in self.SPECS:
            try:
                status, payload = await REST.post(self.API_PATH, self.API_ID, dict(body))
                ok = status == 200 and int(payload.get('return_code', 0)) == 0
                if not ok:
                    errors[name] = str(payload.get('return_msg') or f'HTTP {status}')[:120]
                    continue
                fresh[name] = self._parse(name, code, payload, now)
            except Exception as exc:
                errors[name] = str(exc)[:120]
        if fresh:
            with self.state.lock:
                for name, row in fresh.items():
                    self.state.market_context[name] = row
                self.state.market_context['updated_at'] = now
                self.state.market_context['source'] = 'KIWOOM_KA20001'
            self.state.telemetry['market_index_success_count'] += 1
        if errors:
            self.state.telemetry['market_index_error_count'] += len(errors)
        latency_ms = (time.monotonic() - started) * 1000.0
        self.state.observe_latency('market_index_rest', latency_ms)
        self.last_status = {
            'active': True,
            'source': 'KIWOOM_KA20001',
            'updated_at': now,
            'markets': list(fresh),
            'errors': errors,
            'latency_ms': round(latency_ms, 1),
            'rest_calls': len(self.SPECS),
        }
        return self.last_status
