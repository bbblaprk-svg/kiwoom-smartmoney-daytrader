from __future__ import annotations
import asyncio,time
from app.broker.kiwoom import REST,extract_rows,row_identity,row_rate,row_price
from app.runtime.state import RuntimeState
from app.runtime.clock import sessions,trade_day
from app.domain import Origin
from app.runtime.load_control import hot_capacity
from app.config import SETTINGS,effective_ws_code_budget
from app.broker.market_rotation import MarketRotation
from app.signal.early_edge import discovery_scout_score, discovery_freshness, early_edge

RANK_SPECS=[
 ('orderbook_buy','ka10020',10,{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',17,{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',14,{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',20,{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',9,{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',10,{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',15,{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]

def _fund_like(name:str)->bool:
    n=(name or '').upper();return any(x in n for x in ('ETF','ETN','KODEX','TIGER','ACE ','KOSEF','SOL '))

def stex_for_session(sess:dict)->str:
    # 1=KRX only, 2=NXT only, 3=both. Never ask integrated rank data while one venue is in a scheduled matching gap.
    return '3' if sess.get('krx') and sess.get('nxt') else '1' if sess.get('krx') else '2'

class DiscoveryEngine:
    def __init__(self,state:RuntimeState):self.state=state;self.last_status={};self.rotation=MarketRotation()
    async def _fetch(self,market,source,api_id,weight,body_tpl,stex):
        b={k:(market if v=='{market}' else v) for k,v in body_tpl.items()};b['stex_tp']=stex
        try:
            status,j=await REST.post('/api/dostk/rkinfo',api_id,b);rows=extract_rows(j);return market,source,weight,status==200 and int(j.get('return_code',0))==0,rows,str(j.get('return_msg') or '')
        except Exception as e:return market,source,weight,False,[],str(e)
    async def cycle(self):
        sess=sessions();day=trade_day();started=time.time()
        if not sess['active']:return
        stex=stex_for_session(sess)
        tasks=[]
        for market in ('001','101'):
            for source,api_id,w,tpl in RANK_SPECS:tasks.append(asyncio.create_task(self._fetch(market,source,api_id,w,tpl,stex)))
        seen=set()
        for fut in asyncio.as_completed(tasks):
            market,source,w,ok,rows,msg=await fut;self.last_status[source]={'ok':ok,'rows':len(rows),'msg':msg[:120],'at':time.time()}
            if not ok:continue
            hit_at=time.time()
            for rank,r in enumerate(rows[:80],1):
                code,name=row_identity(r)
                if not code or _fund_like(name):continue
                c=self.state.candidate(code,name,Origin.TODAY_NEW,day);first=not c.source_hits
                prior_market=str(c.metrics.get('market_code') or '')
                if not prior_market:c.metrics['market_code']=market
                elif prior_market!=market:c.metrics['market_code_conflict']=int(c.metrics.get('market_code_conflict') or 0)+1
                previous_hit=float(c.source_hits.get(source) or 0.0);previous_rank=float(c.metrics.get(f'discovery_rank_{source}') or 0.0);previous_rank_at=float(c.metrics.get(f'discovery_rank_at_{source}') or 0.0)
                new_source=not previous_hit or hit_at-previous_hit>SETTINGS.discovery_source_ttl_sec
                if first and not c.metrics.get('discovery_first_seen_at'):c.metrics['discovery_first_seen_at']=hit_at
                if new_source:c.metrics[f'discovery_join_at_{source}']=hit_at
                if new_source:
                    # A source re-entry after TTL is fresh evidence, not a continuous
                    # rank climb.  Start velocity from zero and wait for the next
                    # observation before awarding rank-acceleration points.
                    c.metrics[f'discovery_rank_velocity_{source}']=0.0
                elif previous_rank>0 and previous_rank_at>0 and hit_at>previous_rank_at:
                    velocity=(previous_rank-rank)/max(hit_at-previous_rank_at,1.0)*60.0
                    old_v=float(c.metrics.get(f'discovery_rank_velocity_{source}') or 0.0)
                    c.metrics[f'discovery_rank_velocity_{source}']=round(old_v*.45+velocity*.55,3)
                c.metrics[f'discovery_rank_{source}']=rank;c.metrics[f'discovery_rank_at_{source}']=hit_at
                c.source_hits[source]=hit_at;c.metrics[f'discovery_rate_{source}']=row_rate(r);p=row_price(r)
                if first:c.append_history('DISCOVERY','FIRST_CAPTURE',0.0,f'{source} 최초포착',c.current().venue)
                # Discovery prices are context only. They never become signal/current prices.
                if p:c.metrics[f'discovery_price_{source}']=p
                seen.add(code)
        now=time.time()
        with self.state.lock:
            old_hot=set(self.state.hot_codes);old_exploration=set(self.state.exploration_codes)
            for c in self.state.candidates.values():
                for src,at in list(c.source_hits.items()):
                    if now-at>SETTINGS.discovery_source_ttl_sec:c.source_hits.pop(src,None)
                c.rest_base=sum(next((w for s,_,w,_ in RANK_SPECS if s==src),0) for src in c.source_hits)
                velocities=[float(c.metrics.get(f'discovery_rank_velocity_{src}') or 0.0) for src in c.source_hits]
                ranks=[float(c.metrics.get(f'discovery_rank_{src}') or 80.0) for src in c.source_hits]
                joins=[float(c.metrics.get(f'discovery_join_at_{src}') or 0.0) for src in c.source_hits]
                c.metrics['discovery_rank_velocity_pos']=round(sum(sorted((max(0.0,v) for v in velocities),reverse=True)[:3]),3)
                c.metrics['discovery_best_rank']=min(ranks,default=80.0)
                c.metrics['discovery_source_count']=len(c.source_hits)
                c.metrics['discovery_new_sources_60s']=sum(1 for at in joins if at and now-at<=60)
                c.metrics['discovery_scout_score']=discovery_scout_score(c,now)
                fresh_meta=discovery_freshness(c,now)
                c.metrics['fresh_scout_fast_track']=bool(fresh_meta['fast_track'])
                c.metrics['fresh_scout_age_sec']=fresh_meta['age_sec']
                c.metrics['fresh_scout_rank_trend']=fresh_meta['rank_trend']
                c.metrics['fresh_scout_until']=(float(fresh_meta['first_seen_at'])+SETTINGS.fresh_scout_fast_sec) if fresh_meta['fast_track'] and fresh_meta['first_seen_at'] else 0.0
                lane=c.current();lm=lane.metrics or {}
                scout_confirmed=bool(
                    lm.get('fresh') and not lane.continuity_reason and not lane.resync_required and (
                        float(lm.get('buy_pressure') or 0)>=55.0 or
                        (bool(lm.get('turnover_accel_ready')) and float(lm.get('turnover_accel_30s') or 1.0)>=1.15) or
                        (bool(lm.get('volume_accel_ready')) and float(lm.get('volume_accel') or 1.0)>=1.25) or
                        float(lm.get('smart_money_acceleration') or 1.0)>=1.15 or bool(lm.get('sell_to_buy_flip'))
                    )
                )
                c.metrics['fresh_scout_confirmed']=scout_confirmed
                edge=early_edge(c,now=now);c.metrics['early_edge_score']=edge['score'];c.metrics['early_edge_stage']=edge['stage'];c.metrics['early_edge_penalty']=edge['penalty'];c.metrics['early_edge_headroom']=edge['headroom_score']
            rows=list(self.state.candidates.values())
            rows.sort(key=lambda c:(c.live_track_pin,float(c.metrics.get('early_edge_score') or 0),float(c.metrics.get('discovery_scout_score') or 0),c.score,c.rest_base),reverse=True)
            cap=hot_capacity(self.state.load_mode);pinned={c.code for c in rows if c.live_track_pin};available=max(0,cap-len(pinned))
            # R4.2 widens the fresh inspection lane without increasing total WS capacity.
            # Select fresh/fast scouts BEFORE core so a new name cannot be starved merely
            # because it lacks TRADE-derived BP/SM metrics on its first discovery cycle.
            scout_slots=min(available,max(4,int(round(available*.30)))) if available else 0
            nonpinned=[c for c in rows if c.code not in pinned]
            scout_pool=[]
            for c in nonpinned:
                age=float(c.metrics.get('fresh_scout_age_sec') if c.metrics.get('fresh_scout_age_sec') is not None else 1e9)
                # 0~90s: discovery evidence alone earns bounded FAST TRACK inspection.
                # 90~180s: the symbol keeps the scout lane only if live TRADE data
                # confirmed flow/turnover. Failure therefore auto-exits the scout lane.
                if bool(c.metrics.get('fresh_scout_fast_track')):
                    scout_pool.append(c)
                elif age<=SETTINGS.fresh_scout_window_sec and bool(c.metrics.get('fresh_scout_confirmed')):
                    scout_pool.append(c)
            scouts=sorted(scout_pool,key=lambda c:(
                1 if bool(c.metrics.get('fresh_scout_fast_track')) else 0,
                float(c.metrics.get('discovery_scout_score') or 0),
                float(c.metrics.get('early_edge_score') or 0),
                -float(c.metrics.get('fresh_scout_age_sec') if c.metrics.get('fresh_scout_age_sec') is not None else 1e9),
                max(c.source_hits.values(),default=0.0),
            ),reverse=True)[:scout_slots]
            scout_codes={c.code for c in scouts}
            core_slots=max(0,available-len(scouts))
            core=[c for c in nonpinned if c.code not in scout_codes][:core_slots]
            # If there are fewer genuine fresh scouts than the reservation, give unused
            # capacity straight back to core; total registered codes never increases.
            if len(core)+len(scouts)<available:
                used={c.code for c in core+scouts}
                core.extend([c for c in nonpinned if c.code not in used][:available-len(core)-len(scouts)])
            hot=[c.code for c in core+scouts]
            new_hot=set(hot)|pinned
            self.state.telemetry['early_edge_hot_core_slots']=len(core);self.state.telemetry['early_edge_hot_scout_slots']=scout_slots;self.state.telemetry['early_edge_hot_scout_selected']=len(scouts)
            self.state.telemetry['fresh_scout_fast_track_selected']=sum(1 for c in scouts if bool(c.metrics.get('fresh_scout_fast_track')))
            self.state.telemetry['fresh_scout_confirmed_selected']=sum(1 for c in scouts if bool(c.metrics.get('fresh_scout_confirmed')))
            official_protected={
                c.code for c in rows
                if c.live_track_pin or c.entry_state=='BUY' or c.origin==Origin.PRIOR_CLOSE
            }
            protected=new_hot|set(self.state.followup_codes)|set(self.state.tracking_reservations)|official_protected
            budget=effective_ws_code_budget();trade_cap=min(max(SETTINGS.ws_trade_per_venue,min(len(pinned),budget)),budget)
            headroom=max(0,trade_cap-len(protected));desired=min(self.rotation.target_for_mode(self.state.load_mode),headroom)
            rotation=self.rotation.select(rows,old_exploration,protected,desired,day,now)
            new_exploration=set(rotation.selected)
            self.state.pinned_codes=pinned;self.state.hot_codes=new_hot;self.state.exploration_codes=new_exploration
            promoted={
                code for code in ((new_hot-old_hot)|((old_exploration-new_exploration)&protected))
                if code in self.state.candidates
                and (code in old_exploration or bool(self.state.candidates[code].metrics.get('exploration_verify_only')))
            }
            self.state.telemetry.update({
                'exploration_target_slots':rotation.desired,'exploration_active_codes':len(rotation.selected),
                'exploration_pool_size':rotation.eligible,'exploration_ws_headroom':headroom,
                'exploration_rotations':self.rotation.total_rotations,
                'exploration_added_count':int(self.state.telemetry.get('exploration_added_count') or 0)+len(rotation.added),
                'exploration_removed_count':int(self.state.telemetry.get('exploration_removed_count') or 0)+len(rotation.removed),
            })
        if rotation.added:self.state.prepare_exploration(rotation.added)
        if promoted:self.state.promote_exploration(promoted)
        self.last_status['_exploration']={'mode':self.state.load_mode,'target':rotation.desired,'active':len(rotation.selected),'eligible':rotation.eligible,'rotated':rotation.rotated,'total_rotations':self.rotation.total_rotations,'trade_cap':trade_cap,'headroom':headroom,'official_buy':'BLOCKED_VERIFY_ONLY','at':now}
        self.last_status['_cycle']={'duration_ms':round((time.time()-started)*1000,1),'seen':len(seen),'hot':len(self.state.hot_codes),'exploration':len(self.state.exploration_codes),'at':time.time()}
