from __future__ import annotations
import time
from datetime import datetime
from app.domain import Candidate,Origin,Venue
from app.runtime.clock import KST,lifecycle_phase,opening_windows,sec_of_day,trade_day

class OpeningBridge:
    """19:30 close candidate -> next-day premarket -> shakeout/reversal -> BUY_READY lifecycle."""
    def update(self,c:Candidate,phase:str|None=None,now:float|None=None):
        phase=phase or lifecycle_phase();now=now or time.time();best=c.best_signal_venue();v=c.venue_state[best] if best in (Venue.KRX,Venue.NXT) and c.venue_state[best].last_tick_at else c.current();m=v.metrics;old=c.lifecycle_state
        w=opening_windows(sec_of_day())
        # Explicit phases are used by replay/tests; real runtime uses the overlapping wall-clock windows.
        if phase=='SHAKEOUT_WATCH':w={'shakeout':True,'reversal':False}
        elif phase=='REVERSAL_WINDOW':w={'shakeout':w['shakeout'],'reversal':True}
        if c.origin==Origin.PRIOR_CLOSE:
            if phase=='PRIOR_CLOSE_FROZEN':new='PRIOR_CLOSE_FROZEN'
            elif phase=='PREMARKET_PREP':new='PRIOR_CLOSE_FROZEN'
            elif phase=='PREMARKET_RECHECK':
                if v.last_price>0:c.premarket_price=v.last_price;c.premarket_change=v.last_rate;c.premarket_valid=bool(m.get('fresh'))
                new='PREMARKET_RECHECK'
            elif phase=='OPENING_HANDOFF':new='OPENING_HANDOFF'
            elif w['shakeout'] or w['reversal'] or phase=='NORMAL_INTRADAY':
                if not c.opening_price and v.last_price>0:c.opening_price=v.last_price;c.opening_high=v.last_price;c.opening_low=v.last_price
                if v.last_price>0:c.opening_high=max(c.opening_high or v.last_price,v.last_price);c.opening_low=min(c.opening_low or v.last_price,v.last_price)
                if w['shakeout']:
                    shake=bool(c.opening_price and v.last_price<c.opening_price*.99 and float(m.get('buy_pressure') or 50)<50 and float(m.get('micro_vwap_gap') or 0)<0)
                    c.shakeout_state=c.shakeout_state or shake
                if w['reversal']:
                    vgap=m.get('micro_vwap_gap');vgap_ok=vgap is not None and float(vgap)>=-.10
                    reversal=bool(c.shakeout_state and float(m.get('buy_pressure') or 0)>=56 and vgap_ok and float(m.get('volume_accel') or 1)>=1.10 and v.last_price>=(c.opening_low or v.last_price)*1.003)
                    c.reversal_state=c.reversal_state or reversal
                if c.entry_state=='BUY':new='BUY'
                elif c.reversal_state and c.score>=62 and c.entry_state in ('PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM'):new='BUY_READY'
                elif c.reversal_state:new='REVERSAL_EARLY'
                elif c.shakeout_state:new='SHAKEOUT_WATCH'
                else:new='OPENING_ACTIVE' if (w['shakeout'] or w['reversal']) else ('BUY_READY' if c.entry_state in ('REACCEL','DIRECT_ARM') else 'NORMAL_INTRADAY')
            else:new=old
        else:
            if phase=='CLOSE_TRACK' and c.score>=64:new='CLOSE_TRACK';c.close_signal_price=c.close_signal_price or v.last_price;c.close_score=max(c.close_score,c.score)
            elif c.entry_state=='BUY':new='BUY'
            elif c.entry_state in ('REACCEL','DIRECT_ARM'):new='BUY_READY'
            else:new='TODAY_NEW'
        if new!=old:c.lifecycle_state=new;c.state_changed_at=now;c.append_history('LIFECYCLE',new,v.last_price,f'{old}→{new}',v.venue,now)

    @staticmethod
    def _stamp_is_day(ts:float,day:str)->bool:
        if not ts:return False
        try:return datetime.fromtimestamp(float(ts),KST).strftime('%Y%m%d')==str(day)
        except Exception:return False

    @classmethod
    def _prior_requalified_today(cls,c:Candidate,day:str)->bool:
        if c.origin!=Origin.PRIOR_CLOSE:return True
        evidence=[]
        if c.last_signal:evidence.append(float(c.last_signal.signal_time or 0))
        evidence.append(float(c.last_buy_at or 0))
        for venue in (Venue.KRX,Venue.NXT):
            lane=c.venue_state[venue].entry;evidence.extend((float(lane.last_formal_at or 0),float(lane.last_buy_at or 0)))
        return any(cls._stamp_is_day(ts,day) for ts in evidence)

    def close_candidates(self,candidates:list[Candidate],limit=20,phase:str|None=None)->list[Candidate]:
        phase=phase or lifecycle_phase();day=trade_day();rows=[]
        for c in candidates:
            if c.lifecycle_state=='CLOSE_TRACK':rows.append(c);continue
            if phase!='CLOSE_TRACK' or c.score<64:continue
            # A PRIOR can be renewed only by fresh same-day formal/signal evidence.
            if c.origin==Origin.PRIOR_CLOSE and not self._prior_requalified_today(c,day):continue
            rows.append(c)
        rows.sort(key=lambda c:(c.score,c.valid_repeat_count,c.current().last_rate),reverse=True)
        for i,c in enumerate(rows[:limit],1):c.close_rank=i
        return rows[:limit]
