from __future__ import annotations
import asyncio,contextlib,time
from datetime import datetime
from typing import Any
from app.config import SETTINGS
from app.domain import FeedState,Origin,Venue
from app.runtime.state import RuntimeState
from app.runtime.dispatcher import TradeDispatcher,CoalescingLane
from app.runtime.ingest import Ingestor
from app.runtime.watchdog import HardStallWatchdog
from app.runtime.health import RuntimeHealth
from app.runtime.display import DisplayState
from app.runtime.clock import KST,sessions,trade_day,lifecycle_phase
from app.tracking.live import LiveTracker
from app.storage.wal import DurableJournal
from app.storage.runtime_store import RuntimeStore
from app.storage.performance import PerformanceLedger
from app.storage.snapshot import atomic_json,RUNTIME_SNAPSHOT,DISPLAY_FALLBACK,PRIOR_CLOSE_SNAPSHOT
from app.signal.coordinator import SignalCoordinator
from app.broker.discovery import DiscoveryEngine
from app.broker.market_index import MarketIndexMonitor
from app.broker.websocket import KiwoomWebSocket
from app.broker.recovery import RestRecoveryEngine
from app.addons.max_profit_lab import MaxProfitLab

class NovaService:
    """Ground-up composition root with explicit Feed / Realtime / WAL / UI task boundaries."""
    def __init__(self):
        self.state=RuntimeState();self.tracker=LiveTracker();self.ingestor=Ingestor(self.state,self.tracker)
        self.trade_dispatcher=TradeDispatcher(self.ingestor.trade,self.ingestor.dropped);self.coalesce=CoalescingLane(self.ingestor.aux)
        self.journal=DurableJournal();self.state.history_sink=self.journal.append_important
        self.watchdog=HardStallWatchdog();self.health=RuntimeHealth(self.state,self.watchdog,self.trade_dispatcher,self.coalesce)
        self.display=DisplayState(self.state,self.tracker);self.store=RuntimeStore(self.state,self.display);self.performance=PerformanceLedger();self.coordinator=SignalCoordinator(self.state,self.journal)
        self.discovery=DiscoveryEngine(self.state);self.market_index=MarketIndexMonitor(self.state);self.ws=KiwoomWebSocket(self.state,self.trade_dispatcher,self.coalesce);self.recovery=RestRecoveryEngine(self.state);self.max_profit=MaxProfitLab(self.state)
        self.tasks:list[asyncio.Task]=[];self.started=False;self.stop_evt=asyncio.Event();self.current_day=trade_day()

    async def start(self):
        if self.started:return
        self.started=True;self.state.feed_state=FeedState.STARTING
        self.journal.start();self.trade_dispatcher.start();self.coalesce.start();self.watchdog.start()
        self.tasks=[asyncio.create_task(self.health.heartbeat(),name='heartbeat'),asyncio.create_task(self.health.load_loop(),name='load-control'),asyncio.create_task(self.display.run(),name='display-snapshot'),asyncio.create_task(self.coordinator.run(),name='signal-coordinator'),asyncio.create_task(self._restore_then_warm(),name='restore'),asyncio.create_task(self._maintenance(),name='maintenance'),asyncio.create_task(self._discovery_loop(),name='discovery'),asyncio.create_task(self._market_index_loop(),name='market-index'),asyncio.create_task(self.max_profit.run(),name='max-profit-verify')]
        # Transport preflight/login starts in parallel with disk restore.  The websocket
        # defers REG until restore_done, and SignalCoordinator remains fail-closed meanwhile.
        if not SETTINGS.offline and not SETTINGS.candidate_mode:self.tasks.append(asyncio.create_task(self.ws.run(),name='kiwoom-ws'))
        else:self.state.ws_status['last_error']='OFFLINE_MODE' if SETTINGS.offline else 'CANDIDATE_MODE'
        # Return immediately so liveness never waits on disk restore/network.

    async def _restore_then_warm(self):
        self.state.feed_state=FeedState.RESTORING
        try:await self.store.restore()
        except Exception as e:self.state.telemetry['restore_error_count']+=1;self.state.ws_status['restore_error']=str(e)[:180];self.state.restore_done=True
        # Preserve the old restore-before-WS safety invariant even though transport login now
        # runs in parallel: every restored lane must re-earn a live continuity baseline.
        restored=set(self.state.candidates)
        if restored:self.state.mark_resync(restored,'POST_RESTORE_WARMING')
        self.state.ws_status['resync_deferred']=False
        self.state.feed_state=FeedState.RESYNC if sessions()['active'] else FeedState.CLOSED;self.state.warming_until=time.time()+SETTINGS.warm_sec

    def _discovery_policy(self)->str:
        """Return RUN, BOOTSTRAP or PAUSE for the scarce REST discovery budget.

        3.3.1 paused Discovery for every RESYNC/WARMING/RECONNECTING state. On a cold
        start with no restored pinned/HOT symbols that created a circular wait: no targets ->
        no WS REG -> feed never leaves RESYNC -> Discovery stays paused forever. Bootstrap
        discovery is therefore an explicit exception only when there are no live targets yet.
        Once targets exist, recovery regains exclusive priority over the REST budget.
        """
        if self.state.feed_state not in (FeedState.RESYNC,FeedState.WARMING,FeedState.RECONNECTING):return 'RUN'
        targets=set(self.state.hot_codes)|set(self.state.pinned_codes)|set(self.state.followup_codes)
        return 'BOOTSTRAP' if not targets else 'PAUSE'

    async def _discovery_loop(self):
        while not self.stop_evt.is_set():
            if not self.state.restore_done:await asyncio.sleep(.1);continue
            if not SETTINGS.offline and not SETTINGS.candidate_mode:
                policy=self._discovery_policy()
                if policy=='PAUSE':
                    self.state.telemetry['discovery_paused_for_recovery_count']+=1
                else:
                    if policy=='BOOTSTRAP':self.state.telemetry['discovery_bootstrap_count']+=1
                    try:await self.discovery.cycle()
                    except Exception as e:self.state.telemetry['discovery_error_count']+=1;self.state.ws_status['discovery_error']=str(e)[:160]
            mul={'NORMAL':1.0,'BUSY':1.5,'HIGH_LOAD':2.5,'CRITICAL':4.0}.get(self.state.load_mode,1.0)
            await asyncio.sleep(max(2,SETTINGS.discovery_sec*mul))

    async def _market_index_loop(self):
        """R493 low-priority KOSPI/KOSDAQ context.

        It never runs in candidate/offline mode, pauses completely under HIGH/CRITICAL
        load, and backs off under BUSY.  Core discovery/BUY remains higher priority.
        """
        while not self.stop_evt.is_set():
            if not self.state.restore_done:
                await asyncio.sleep(.25);continue
            if SETTINGS.r493_market_index_enabled and not SETTINGS.offline and not SETTINGS.candidate_mode:
                lm=str(self.state.load_mode or 'NORMAL')
                if lm not in ('HIGH_LOAD','CRITICAL'):
                    try:
                        await self.market_index.cycle()
                    except Exception as e:
                        self.state.telemetry['market_index_error_count']+=1
                        self.state.ws_status['market_index_error']=str(e)[:160]
            lm=str(self.state.load_mode or 'NORMAL')
            if lm=='NORMAL':delay=SETTINGS.r493_market_index_sec
            elif lm=='BUSY':delay=SETTINGS.r493_market_index_busy_sec
            else:delay=max(SETTINGS.r493_market_index_busy_sec,180.0)
            await asyncio.sleep(delay)

    async def _maintenance(self):
        last_persist=0.0;last_prune=0.0;last_feed=0.0;last_performance=0.0;last_resync=0.0
        while not self.stop_evt.is_set():
            if not self.state.restore_done:await asyncio.sleep(.1);continue
            now=time.time();day=trade_day()
            if day!=self.current_day:await self._rollover(day);self.current_day=day;last_persist=0.0
            if now-last_feed>=1:self._update_feed_state(now);last_feed=now
            if now-last_resync>=SETTINGS.resync_interval_sec and self.state.feed_state in (FeedState.RESYNC,FeedState.WARMING,FeedState.RECONNECTING):
                await self.recovery.cycle();last_resync=now
            if now-last_prune>=30:
                stats=self.state.prune(SETTINGS.max_candidates,SETTINGS.fast_window_idle_sec);self.state.telemetry.update({f'prune_{k}':v for k,v in stats.items()});self.ws.integrity.prune_codes(day,set(self.state.hot_codes)|set(self.state.pinned_codes)|set(self.state.exploration_codes));last_prune=now
            if now-last_performance>=30:
                try:
                    ps=await asyncio.to_thread(self.performance.sync,self.state);self.state.followup_codes=set(ps.get('watch_codes') or []);self.state.telemetry['performance_pending_today']=ps.get('pending_today',0);self.state.telemetry['performance_finalized']=ps.get('finalized',0)
                except Exception as e:self.state.telemetry['performance_error_count']+=1;self.state.ws_status['performance_error']=str(e)[:160]
                last_performance=now
            if now-last_persist>=30:
                try:
                    runtime=self.store.build_runtime();snap=self.display.get();await asyncio.to_thread(atomic_json,RUNTIME_SNAPSHOT,runtime)
                    if lifecycle_phase()=='CLOSE_TRACK':await asyncio.to_thread(atomic_json,PRIOR_CLOSE_SNAPSHOT,self.store.build_prior())
                    # Never replace a useful close/live fallback with an empty/degraded board.
                    # When truth exists, persist and refresh the in-memory fallback atomically.
                    if self.display.snapshot_has_truth(snap):
                        await asyncio.to_thread(atomic_json,DISPLAY_FALLBACK,snap);self.display.set_fallback(snap)
                except Exception:self.state.telemetry['snapshot_error_count']+=1
                last_persist=now
            await asyncio.sleep(.5)

    def _update_feed_state(self,now:float):
        self.state.telemetry['ui_clients']=self.state.ui_clients;self.state.telemetry['db_queue_depth']=self.journal.health()['db_queue_depth']
        if SETTINGS.offline or SETTINGS.candidate_mode:self.state.feed_state=FeedState.WARMING if self.state.restore_done else FeedState.RESTORING;return
        sess=sessions();ws=self.state.ws_status
        if not sess['active']:self.state.feed_state=FeedState.CLOSED;return
        if not self.state.restore_done:self.state.feed_state=FeedState.RESTORING;return
        if int(self.state.telemetry.get('pinned_ws_overflow') or 0)>0:self.state.feed_state=FeedState.DEGRADED_TRACK;return
        if bool(ws.get('active_subscription_error')):self.state.feed_state=FeedState.DEGRADED;return
        if not ws.get('connected') or not ws.get('logged_in'):self.state.feed_state=FeedState.RECONNECTING;return
        if int(ws.get('registered') or 0)<=0:self.state.feed_state=FeedState.RESYNC;return
        if self.trade_dispatcher.oldest_age_ms()>500:self.state.feed_state=FeedState.DEGRADED;return
        last_msg=float(ws.get('last_message_at') or 0);last_trade=float(ws.get('last_trade_at') or 0)
        if not last_msg or now-last_msg>8:self.state.feed_state=FeedState.RECONNECTING;return
        # No trade for a quiet symbol is not a feed failure; global last message remains the liveness source.
        if now<self.state.warming_until:self.state.feed_state=FeedState.WARMING;return
        # Global feed liveness and per-venue signal eligibility are different contracts.
        # One quiet/recovering HOT symbol must not keep the entire transport in WARMING forever.
        # Per-venue MetricEngine remains fail-closed while resync_required/continuity_reason is set.
        active_codes=set(self.state.hot_codes)|set(self.state.pinned_codes)
        pending=0;missing_baseline=0;ready=0
        for code in active_codes:
            c=self.state.candidates.get(code)
            if not c:continue
            for venue,is_active in ((Venue.KRX,sess['krx']),(Venue.NXT,sess['nxt'])):
                if not is_active:continue
                v=c.venue_state[venue]
                if v.resync_required or v.continuity_reason:
                    pending+=1
                    if not v.resync_snapshot_at:missing_baseline+=1
                elif v.last_tick_at and now-v.last_tick_at<=max(8,SETTINGS.display_fresh_ms/1000):
                    ready+=1
        self.state.telemetry['resync_pending_key_count']=pending
        self.state.telemetry['resync_missing_baseline_key_count']=missing_baseline
        self.state.telemetry['signal_ready_key_count']=ready
        if active_codes and ready<=0:
            self.state.feed_state=FeedState.RESYNC if missing_baseline else FeedState.WARMING
            return
        if last_trade and now-last_trade<=max(8,SETTINGS.fresh_ms/1000*3):self.state.feed_state=FeedState.LIVE
        else:self.state.feed_state=FeedState.WARMING

    @staticmethod
    def _stamp_is_day(ts:float,day:str)->bool:
        if not ts:return False
        try:return datetime.fromtimestamp(float(ts),KST).strftime('%Y%m%d')==str(day)
        except Exception:return False

    @classmethod
    def _prior_requalified_on_day(cls,c,day:str)->bool:
        """A PRIOR candidate may earn one more day only from fresh same-day evidence.

        Old close_signal_price/close_score are historical evidence, never a renewal token.
        A renewal needs a same-day formal/signal/BUY timestamp AND a same-day trade tick.
        """
        if c.origin!=Origin.PRIOR_CLOSE:return False
        evidence=[]
        if c.last_signal:evidence.append(float(c.last_signal.signal_time or 0))
        evidence.append(float(c.last_buy_at or 0))
        for venue in (Venue.KRX,Venue.NXT):
            lane=c.venue_state[venue].entry
            evidence.extend((float(lane.last_formal_at or 0),float(lane.last_buy_at or 0)))
        if not any(cls._stamp_is_day(ts,day) for ts in evidence):return False
        return any(cls._stamp_is_day(c.venue_state[v].last_tick_at,day) and c.venue_state[v].last_price>0 for v in (Venue.KRX,Venue.NXT))

    async def _rollover(self,new_day:str):
        source_day=self.current_day
        with self.state.lock:
            prior=[]
            for c in self.state.candidates.values():
                requalified=self._prior_requalified_on_day(c,source_day)
                # One-trading-day TTL: only today's fresh CLOSE_TRACK or a PRIOR that
                # independently requalified today can become tomorrow's PRIOR.
                if c.lifecycle_state!='CLOSE_TRACK' and not (requalified and c.score>=64):continue
                cur=c.current();price=(cur.last_price if requalified and cur.last_price>0 else (c.close_signal_price or cur.last_price));score=(c.score if requalified and c.score>0 else (c.close_score or c.score))
                if price<=0 or score<=0:continue
                prior.append((c.code,c.name,price,score,c.close_rank,c.valid_repeat_count))
            self.state.candidates={};self.state.windows={};self.state.code_locks={};self.state.hot_codes=set();self.state.pinned_codes=set();self.state.followup_codes=set();self.state.exploration_codes=set();self.state.tracking_reservations={};self.state.dirty_keys=set();self.state.dirty_since={};self.state.urgent_dirty.clear()
            for code,name,price,score,rank,repeats in prior:
                c=self.state.candidate(code,name,Origin.PRIOR_CLOSE,new_day);c.close_signal_price=price;c.close_score=score;c.close_rank=rank;c.lifecycle_state='PRIOR_CLOSE_FROZEN';c.live_track_pin=True;c.venue_state[Venue.NXT].entry.valid_repeat_count=repeats;c.refresh_aggregate();self.state.pinned_codes.add(code)
        self.discovery.rotation.reset(new_day);self.ws.integrity.reset_for_day(new_day);self.state.feed_state=FeedState.WARMING;self.state.warming_until=time.time()+SETTINGS.warm_sec

    def liveness(self)->dict[str,Any]:
        age=(time.monotonic()-self.health.last_beat)*1000
        return {'ok':bool(self.started and age<5000),'version':SETTINGS.version,'feed_state':self.state.feed_state.value,'event_loop_beat_age_ms':round(age,1),'restore_done':self.state.restore_done,'uptime_sec':round(time.time()-self.state.started_at,1)}

    def realtime_health(self)->dict[str,Any]:
        x=self.health.snapshot();jh=self.journal.health();self.state.telemetry['db_queue_depth']=jh['db_queue_depth'];self.state.telemetry['db_write_latency_p95_ms']=jh['db_write_latency_p95_ms']
        x.update({'version':SETTINGS.version,'feed_state':self.state.feed_state.value,'connection_state':self.state.ws_status.get('connection_state'),'sessions':sessions(),'journal':jh,'discovery':dict(self.discovery.last_status),'market_index':dict(self.market_index.last_status),'market_context':dict(self.state.market_context),'performance':dict(self.performance.last_status),'max_profit_mode':'VERIFY_ONLY'})
        x['ok']=self.liveness()['ok'];x['feed_ok']=self.state.feed_state in (FeedState.LIVE,FeedState.CLOSED) if not (SETTINGS.offline or SETTINGS.candidate_mode) else False;return x

    async def stop(self):
        if not self.started:return
        self.stop_evt.set();self.coordinator.running=False
        with contextlib.suppress(Exception):await self.max_profit.flush_pending()
        for t in self.tasks:t.cancel()
        for t in self.tasks:
            with contextlib.suppress(asyncio.CancelledError,Exception):await t
        self.trade_dispatcher.stop();self.coalesce.stop();self.journal.stop();self.watchdog.stop();self.started=False

SERVICE=NovaService()
