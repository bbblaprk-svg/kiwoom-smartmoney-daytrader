from __future__ import annotations
import time
from dataclasses import dataclass
from app.domain import Candidate,Venue
from app.runtime.state import RuntimeState
from app.signal.smart_money import fast_proxy
from app.config import SETTINGS


def clamp(x,a=0,b=100):return max(a,min(b,x))

@dataclass(slots=True)
class ScoreDecision:
    score:float;confidence:float;stage:str;reasons:list[str];metrics:dict

class MetricEngine:
    """Incremental FAST-layer metrics from a venue-isolated fixed-memory window."""
    def __init__(self,state:RuntimeState):self.state=state

    def venue_metrics(self,c:Candidate,venue:Venue,now:float)->dict:
        w=self.state.window(c.code,venue);v=c.venue_state[venue]
        bundle=w.metric_bundle(now);r30=bundle['r30'];r60=bundle['r60'];prev30=bundle['prev30'];prev=bundle['prev'];r180=bundle['r180'];r5=bundle['r5']
        price=v.last_price or r60.get('close',0);p30=r30.get('open') or price;p60=r60.get('open') or price;p180=r180.get('open') or price
        impulse30=((price/p30-1)*100) if p30 and price else 0;impulse60=((price/p60-1)*100) if p60 and price else 0;impulse180=((price/p180-1)*100) if p180 and price else 0
        vol60=float(r60.get('abs_qty') or 0);prev_ready=int(prev.get('bucket_count') or 0)>=20 and float(prev.get('span_sec') or 0)>=15;volprev=(float(prev.get('abs_qty') or 0)/2) if prev_ready else 0
        accel=vol60/max(volprev,1) if prev_ready else 1.0
        signed=float(r60.get('signed_qty') or 0);buy_qty=max(0,(vol60+signed)/2);sell_qty=max(0,(vol60-signed)/2)
        bp=buy_qty/max(vol60,1)*100 if vol60 else 50;execution_strength=buy_qty/max(sell_qty,1)*100 if vol60 else 100
        r30_vol=float(r30.get('abs_qty') or 0);r30_signed=float(r30.get('signed_qty') or 0);prev30_vol=float(prev30.get('abs_qty') or 0);prev30_signed=float(prev30.get('signed_qty') or 0)
        r30_buy=max(0,(r30_vol+r30_signed)/2);prev30_buy=max(0,(prev30_vol+prev30_signed)/2)
        bp30=r30_buy/max(r30_vol,1)*100 if r30_vol else 50;bp_prev30=prev30_buy/max(prev30_vol,1)*100 if prev30_vol else 50
        prev30_ready=int(prev30.get('bucket_count') or 0)>=15 and float(prev30.get('span_sec') or 0)>=12 and int(r30.get('bucket_count') or 0)>=15 and float(r30.get('span_sec') or 0)>=12
        turn30=float(r30.get('pv') or 0);turn_prev30=float(prev30.get('pv') or 0);turn_accel30=turn30/max(turn_prev30,1) if prev30_ready else 1.0
        pos=int(r60.get('pos_count') or 0);neg=int(r60.get('neg_count') or 0);algo=pos/max(pos+neg,1)*100
        oldmax=float(bundle.get('old_high') or 0);breakout=max(0,(price/oldmax-1)*100) if oldmax and int(r5.get('count') or 0)>5 else 0
        pv=float(r5.get('pv') or 0);vv=float(r5.get('abs_qty') or 0);micro_vwap=pv/vv if vv else price;vgap=(price/micro_vwap-1)*100 if micro_vwap else 0
        session_vwap=v.session_pv/v.session_v if v.session_v else micro_vwap;session_gap=(price/session_vwap-1)*100 if session_vwap else 0
        hi=float(r5.get('high') or 0);lo=float(r5.get('low') or 0);range5=((hi-lo)/micro_vwap*100) if hi and lo and micro_vwap else 0
        one=float(r60.get('max_abs_qty') or 0)/max(vol60,1)
        sm=fast_proxy(r30,prev30,r60,bp,vgap)
        program_fresh=bool(v.program_at and now-v.program_at<=25);program_score=0.0
        if program_fresh:
            scale=max(abs(v.program_net),100000);program_score=clamp(v.program_delta/scale*4,-4,4)
        ob=v.orderbook_score if v.orderbook_at and now-v.orderbook_at<=10 else 0.0
        bid=float(v.metrics.get('best_bid') or 0);ask=float(v.metrics.get('best_ask') or 0);spread=((ask-bid)/((ask+bid)/2)*100) if ask>0 and bid>0 and ask>=bid else None
        orb_breakout=((price/v.orb_high-1)*100) if v.orb_high and price else 0
        return {
            'venue':venue.value,'price':price,'rate':v.last_rate,'tick_count_30s':int(r30.get('count') or 0),'tick_count_60s':int(r60.get('count') or 0),
            'turnover_30s':round(float(r30.get('pv') or 0),0),'turnover_60s':round(float(r60.get('pv') or 0),0),
            'impulse_30s':round(impulse30,3),'impulse_60s':round(impulse60,3),'impulse_180s':round(impulse180,3),
            'volume_accel':round(accel,3),'short_term_volume_accel':round(accel,3),'rvol_intraday':None,'rvol_ready':False,'volume_accel_ready':prev_ready,'volume_baseline_ticks':int(prev.get('count') or 0),
            'buy_pressure':round(bp,2),'buy_pressure_30s':round(bp30,2),'buy_pressure_prev30s':round(bp_prev30,2),'buy_pressure_delta_30s':round(bp30-bp_prev30,2) if prev30_ready else 0.0,
            'execution_strength':round(execution_strength,1),'algo_persistence':round(algo,2),
            'turnover_accel_30s':round(turn_accel30,3),'turnover_accel_ready':prev30_ready,'turnover_30s':round(turn30,0),'turnover_prev30s':round(turn_prev30,0),
            'micro_vwap':round(micro_vwap,4) if micro_vwap else None,'micro_vwap_gap':round(vgap,3),'session_vwap':round(session_vwap,4) if session_vwap else None,'session_vwap_gap':round(session_gap,3),
            'micro_breakout':round(breakout,3),'orb_high':v.orb_high or None,'orb_low':v.orb_low or None,'orb_breakout_pct':round(orb_breakout,3),
            'day_high':v.day_high or None,'day_low':v.day_low or None,'range5_pct':round(range5,3),'compression':round(clamp(1-range5/3,0,1),4),'one_tick_ratio':round(one,4),
            'smart_money_realtime_proxy_score':sm['score'],'smart_money_realtime_proxy_surge':sm['surge'],'smart_money_proxy_label':sm['label'],
            'smart50_count_60s':sm['early_count'],'smart70_count_60s':sm['strong_count'],'smart100_count_60s':sm['large_count'],'smart200_count_60s':sm['very_large_count'],
            'smart50_net_60s':round(sm['net_value'],0),'large_buy_value_30s':round(sm['buy_value_30s'],0),'large_sell_value_30s':round(sm['sell_value_30s'],0),
            'net_large_flow_30s':round(sm['net_value_30s'],0),'smart_money_acceleration':sm['acceleration'],'sell_to_buy_flip':sm['sell_to_buy_flip'],'relative_large_trade_ratio':sm['relative_large_trade_ratio'],
            'program_fresh':program_fresh,'program_net':v.program_net,'program_delta':v.program_delta,'program_score':round(program_score,2),'orderbook_presignal':round(ob,2),'spread_pct':round(spread,4) if spread is not None else None,
            'age_ms':round((now-v.last_tick_at)*1000) if v.last_tick_at else None,'continuity_ok':not(v.continuity_gap_until>now),
            'cum_volume':v.last_cum_volume,'cum_turnover':v.last_cum_turnover,
        }

    def score(self,c:Candidate,venue:Venue,session_active:bool)->ScoreDecision:
        now=time.time();v=c.venue_state[venue];age_ms=(now-v.last_tick_at)*1000 if v.last_tick_at else 10**12
        rest=min(30,c.rest_base*.55);reasons=[]
        if len(c.source_hits)>=3:reasons.append(f'독립순위 {len(c.source_hits)}중첩')
        if v.continuity_gap_until>now:age_ms=max(age_ms,SETTINGS.display_fresh_ms+1);reasons.append('실시간 연속성 재동기화')
        if not v.last_tick_at or age_ms>SETTINGS.display_fresh_ms:
            if not session_active:reasons.append('시장 종료 · 실시간 신호 비활성')
            elif v.last_tick_at:reasons.append(f'실체결 stale {age_ms/1000:.1f}s')
            else:reasons.append('실시간 체결 축적 중')
            return ScoreDecision(round(rest,1),min(35,len(c.source_hits)*8),'SEED',reasons[:5],{'fresh':False,'age_ms':age_ms,'venue':venue.value})
        m=self.venue_metrics(c,venue,now);other_v=Venue.NXT if venue==Venue.KRX else Venue.KRX;ov=c.venue_state[other_v]
        if v.resync_required or v.continuity_reason:
            m['fresh']=False;m['warming']=True;m['warm_span_sec']=round(float(self.state.window(c.code,venue).aggregate(now,60,micro=True).get('span_sec') or 0),1)
            return ScoreDecision(round(rest,1),min(35,len(c.source_hits)*8),'SEED',(reasons+['RESYNC/WARMING · 정식신호 차단'])[:5],m)
        dual=bool(ov.last_tick_at and now-ov.last_tick_at<=SETTINGS.fresh_ms/1000 and not ov.continuity_reason and bool(ov.metrics.get('fresh',False)))
        accel=m['volume_accel'];bp=m['buy_pressure'];imp=m['impulse_60s'];vgap=m['micro_vwap_gap'];sgap=m['session_vwap_gap'];br=m['micro_breakout'];one=m['one_tick_ratio']
        sector_score=float(c.metrics.get('sector_score') or 0);event_bonus=float(c.metrics.get('event_signal') or 0);sw_state=str(c.metrics.get('nxt_second_wave_state') or '')
        sw_bonus=5 if sw_state=='SECOND_WAVE_BUY' else 3 if sw_state=='SECOND_WAVE_READY' else 1.5 if sw_state=='SECOND_WAVE_BASE' else 0
        score=rest
        if m['volume_accel_ready']:score+=clamp((accel-1)*12,0,20)
        score+=clamp((bp-50)*.38,0,16)+clamp(imp*3.2,0,15)+clamp(vgap*3.2,0,5)+clamp(sgap*2.2,0,4)+clamp(br*6,0,9)+(5 if dual else 0)
        score+=float(m['smart_money_realtime_proxy_score'])+float(m['program_score'])+sector_score+float(m['orderbook_presignal'])+event_bonus+sw_bonus
        if v.last_rate>14:score-=12;reasons.append('과열 추격위험')
        if imp>4.5:score-=7
        if one>.5:score-=8;reasons.append('단일체결 편중')
        if m['volume_accel_ready'] and accel>=1.7:reasons.append(f'1분 체결가속 {accel:.1f}x')
        elif not m['volume_accel_ready']:reasons.append('거래량 기준선 축적 중')
        if m['smart50_count_60s']>=2:reasons.append(f"5천만+ 공격체결 {m['smart50_count_60s']}회")
        if m['sell_to_buy_flip']:reasons.append('대형체결 매도→매수 전환')
        if m['smart_money_realtime_proxy_surge']:reasons.append(f"SMART MONEY SURGE +{m['smart_money_realtime_proxy_score']:.1f}")
        if bp>=60:reasons.append(f'공격매수 우위 {bp:.0f}%')
        if imp>=.7:reasons.append(f'가격 선행 +{imp:.1f}%')
        if vgap>=.2:reasons.append(f'Micro VWAP +{vgap:.2f}%')
        if br>=.3:reasons.append(f'5분 미세돌파 +{br:.2f}%')
        if dual:reasons.append('KRX·NXT 동시확인')
        score=clamp(score,0,100);confidence=clamp(20+min(35,m['tick_count_60s']*1.2)+min(25,len(c.source_hits)*6)+(10 if dual else 0),0,100)
        stage='IGNITION' if score>=78 else 'PRESSURE' if score>=64 else 'WATCH' if score>=48 else 'SEED'
        fresh=age_ms<=SETTINGS.fresh_ms and m['continuity_ok']
        if not session_active:stage='SEED';score=min(score,47)
        elif not fresh and stage in ('PRESSURE','IGNITION'):stage='WATCH';score=min(score,63);reasons.insert(0,'실체결 freshness 부족')
        out={**m,'dual_venue':dual,'fresh':fresh,'sector_score':sector_score,'event_signal':event_bonus,'score_formula':'ENTRY_V18_PARITY_FROZEN_GROUNDUP'}
        return ScoreDecision(round(score,1),round(confidence,0),stage,reasons[:5],out)
