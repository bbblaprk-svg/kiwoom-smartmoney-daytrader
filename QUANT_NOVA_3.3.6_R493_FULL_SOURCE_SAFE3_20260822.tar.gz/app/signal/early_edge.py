from __future__ import annotations

import time
from typing import Any

from app.domain import Candidate, Venue
from app.config import SETTINGS


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value if value is not None else default)
    except Exception:
        return default


def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def discovery_freshness(candidate: Candidate, now: float | None = None) -> dict[str, Any]:
    """Fresh-discovery metadata shared by discovery, ranking and UI.

    Important: this function never calls the broker and never mutates official BUY
    state.  It only interprets evidence already collected by DiscoveryEngine.
    """
    now = time.time() if now is None else float(now)
    m = candidate.metrics
    first_seen = _f(m.get('discovery_first_seen_at'))
    age = max(0.0, now - first_seen) if first_seen else 10**9
    new_sources = max(0, int(_f(m.get('discovery_new_sources_60s'))))
    source_count = max(0, int(_f(m.get('discovery_source_count'), len(candidate.source_hits))))
    best_rank = max(1.0, _f(m.get('discovery_best_rank'), 80.0))
    rank_velocity = _f(m.get('discovery_rank_velocity_pos'))

    # A newly discovered name should not need a second rank observation before it
    # can receive temporary realtime inspection.  Either broad simultaneous entry
    # or a first appearance inside the top 20 is enough for a bounded 90s FAST SCOUT.
    fast_track = bool(first_seen and age <= SETTINGS.fresh_scout_fast_sec and (new_sources >= 2 or best_rank <= 20))
    fresh_window = bool(first_seen and age <= SETTINGS.fresh_scout_window_sec)
    rank_trend = 'UP' if rank_velocity >= 4 else 'FLAT'
    label = f'NEW {int(age)}초' if age <= SETTINGS.fresh_scout_window_sec else ''
    return {
        'first_seen_at': first_seen or None,
        'age_sec': round(age, 1) if age < 10**8 else None,
        'new_sources_60s': new_sources,
        'source_count': source_count,
        'best_rank': round(best_rank, 1),
        'rank_velocity': round(rank_velocity, 2),
        'rank_trend': rank_trend,
        'fast_track': fast_track,
        'fresh_window': fresh_window,
        'label': label,
    }


def discovery_scout_score(candidate: Candidate, now: float | None = None) -> float:
    """0~100 discovery-only score for newly strengthening names.

    First capture receives meaningful credit from rank quality/breadth/freshness,
    so rank velocity=0 on the first observation no longer delays genuinely fresh
    candidates.  No additional REST call is made here.
    """
    now = time.time() if now is None else float(now)
    m = candidate.metrics
    meta = discovery_freshness(candidate, now)
    velocity = max(0.0, _f(m.get('discovery_rank_velocity_pos')))
    new_sources = float(meta['new_sources_60s'])
    breadth = float(meta['source_count'])
    best_rank = float(meta['best_rank'])
    age = meta['age_sec'] if meta['age_sec'] is not None else 10**9

    velocity_score = _clamp(velocity * 1.35, 0, 34)
    join_score = _clamp(new_sources * 9.0, 0, 27)
    breadth_score = _clamp((breadth - 1.0) * 3.5, 0, 14)
    # First-time top-20 appearance gets real discovery credit before a second sample.
    rank_score = _clamp((40.0 - best_rank) * 0.55, 0, 14)
    freshness_score = 11.0 if age <= 45 else 8.0 if age <= SETTINGS.fresh_scout_fast_sec else 5.0 if age <= SETTINGS.fresh_scout_window_sec else 1.0 if age <= 300 else 0.0
    fast_bonus = 8.0 if meta['fast_track'] else 0.0
    return round(_clamp(velocity_score + join_score + breadth_score + rank_score + freshness_score + fast_bonus), 1)


def early_edge(candidate: Candidate, venue: Venue | None = None, now: float | None = None) -> dict[str, Any]:
    """PRE-BREAKOUT / EARLY-IGNITION ranking layer.

    R4.2 keeps official BUY frozen.  Discovery/display ranking prioritizes evidence
    that arrives before price extension, with a stronger freshness channel for
    newly discovered names and explicit bounded FAST SCOUT metadata.
    """
    now = time.time() if now is None else float(now)
    lane = candidate.venue_state[venue] if venue in (Venue.KRX, Venue.NXT) else candidate.current()
    m = lane.metrics or {}

    rate = _f(lane.last_rate)
    impulse = _f(m.get('impulse_60s'))
    vgap = _f(m.get('session_vwap_gap'))
    micro_gap = _f(m.get('micro_vwap_gap'))
    compression = _clamp(_f(m.get('compression')), 0, 1)
    one_tick = _clamp(_f(m.get('one_tick_ratio')), 0, 1)
    orderbook = _f(m.get('orderbook_presignal'))
    bp = _f(m.get('buy_pressure'), 50)
    bp_delta = _f(m.get('buy_pressure_delta_30s'))
    sm_accel = _f(m.get('smart_money_acceleration'), 1)
    sm_score = _f(m.get('smart_money_realtime_proxy_score'))
    flip = bool(m.get('sell_to_buy_flip'))
    turn_accel = _f(m.get('turnover_accel_30s'), 1)
    turn_ready = bool(m.get('turnover_accel_ready'))
    vol_accel = _f(m.get('volume_accel'), 1)
    vol_ready = bool(m.get('volume_accel_ready'))
    program_delta = _f(m.get('program_delta')) if bool(m.get('program_fresh')) else 0.0
    fresh = bool(m.get('fresh', False)) and not lane.continuity_reason and not lane.resync_required

    scout = discovery_scout_score(candidate, now)
    fresh_meta = discovery_freshness(candidate, now)

    # R4.2 100-point allocation: discovery 15 + flow 18 + turnover 12 +
    # compression 15 + headroom 25 + freshness 15.
    discovery_component = _clamp(scout * .15, 0, 15)

    flow_component = 0.0
    flow_component += _clamp((bp - 50.0) * .32, 0, 6)
    flow_component += _clamp(bp_delta * .40, 0, 6)
    flow_component += _clamp((sm_accel - 1.0) * 2.8, 0, 3)
    flow_component += _clamp(sm_score * .30, 0, 2)
    if flip:
        flow_component += 2
    if program_delta > 0:
        flow_component += 1
    flow_component = _clamp(flow_component, 0, 18)

    turnover_component = 0.0
    if turn_ready:
        turnover_component += _clamp((turn_accel - 1.0) * 7.0, 0, 9)
    if vol_ready:
        turnover_component += _clamp((vol_accel - 1.0) * 2.0, 0, 3)
    turnover_component = _clamp(turnover_component, 0, 12)

    compression_component = compression * 7.0
    compression_component += _clamp(orderbook, 0, 4)
    compression_component += 2.0 if one_tick <= .30 else 1.0 if one_tick <= .45 else 0.0
    if -.35 <= vgap <= .85:
        compression_component += 2
    compression_component = _clamp(compression_component, 0, 15)

    # Headroom explicitly rewards names that have not already travelled far.
    if -1.0 <= rate <= 2.5:
        rate_setup = 12.0
    elif 2.5 < rate <= 4.0:
        rate_setup = 9.0 - (rate - 2.5) * 1.3
    elif -2.5 <= rate < -1.0:
        rate_setup = 6.0
    elif 4.0 < rate <= 5.5:
        rate_setup = 4.0
    else:
        rate_setup = 0.0

    if .05 <= impulse <= 1.0:
        impulse_setup = 6.0
    elif -0.25 <= impulse < .05:
        impulse_setup = 4.0
    elif 1.0 < impulse <= 1.8:
        impulse_setup = 3.0
    else:
        impulse_setup = 0.0

    if -.35 <= vgap <= .8:
        vwap_setup = 4.0
    elif -.7 <= vgap < -.35 or .8 < vgap <= 1.4:
        vwap_setup = 2.0
    else:
        vwap_setup = 0.0

    breakout = _f(m.get('micro_breakout'))
    breakout_setup = 3.0 if 0 <= breakout <= .45 else 1.5 if .45 < breakout <= .9 else 0.0
    headroom_component = _clamp(rate_setup + impulse_setup + vwap_setup + breakout_setup, 0, 25)

    age = fresh_meta['age_sec'] if fresh_meta['age_sec'] is not None else 10**9
    if age <= 45:
        freshness_component = 15.0
    elif age <= SETTINGS.fresh_scout_fast_sec:
        freshness_component = 13.0
    elif age <= SETTINGS.fresh_scout_window_sec:
        freshness_component = 8.0
    elif age <= 360:
        freshness_component = 3.0
    else:
        freshness_component = 0.0

    penalty = 0.0
    if rate > 3.0:
        penalty += _clamp((rate - 3.0) * 2.0, 0, 4)
    if rate > 5.0:
        penalty += _clamp((rate - 5.0) * 5.0, 0, 20)
    if rate > 8.0:
        penalty += _clamp((rate - 8.0) * 7.0, 0, 25)
    if impulse > 1.8:
        penalty += _clamp((impulse - 1.8) * 6.0, 0, 12)
    if vgap > 1.4:
        penalty += _clamp((vgap - 1.4) * 4.0, 0, 10)
    if micro_gap > 1.3:
        penalty += _clamp((micro_gap - 1.3) * 4.0, 0, 8)
    if one_tick > .5:
        penalty += 7.0

    score = discovery_component + flow_component + turnover_component + compression_component + headroom_component + freshness_component - penalty
    # FAST SCOUT is only a discovery/display privilege.  It does not bypass fresh
    # broker-trade truth or official BUY conditions.
    if not fresh:
        score = min(score, 39.0)
    if rate >= 10.0:
        score = min(score, 45.0)
    if rate >= 15.0:
        score = min(score, 25.0)
    score = round(_clamp(score), 1)

    chase_block = bool(rate >= 7.0 or penalty >= 18.0)
    stage = 'EARLY_IGNITION' if score >= 72 and not chase_block else 'PRE_BREAKOUT' if score >= 58 and not chase_block else 'SCOUT' if score >= 42 else 'LATE_CHASE' if chase_block else 'WATCH'

    reasons: list[str] = []
    if fresh_meta['fast_track']:
        reasons.append('FAST SCOUT')
    if _f(candidate.metrics.get('discovery_rank_velocity_pos')) >= 4:
        reasons.append(f"순위상승 {_f(candidate.metrics.get('discovery_rank_velocity_pos')):.1f}/분")
    if _f(candidate.metrics.get('discovery_new_sources_60s')) >= 1:
        reasons.append(f"신규랭킹 {int(_f(candidate.metrics.get('discovery_new_sources_60s')))}개 합류")
    if bp_delta >= 4:
        reasons.append(f'BP 가속 +{bp_delta:.0f}p')
    if turn_ready and turn_accel >= 1.35:
        reasons.append(f'거래대금 가속 {turn_accel:.2f}x')
    if flip:
        reasons.append('대형체결 매도→매수 전환')
    if compression >= .65:
        reasons.append(f'압축 {compression:.2f}')
    if -.35 <= vgap <= .8:
        reasons.append('VWAP 근접')
    if penalty >= 8:
        reasons.append(f'추격감점 -{penalty:.0f}')

    return {
        'score': score,
        'stage': stage,
        'fresh': fresh,
        'chase_block': chase_block,
        'penalty': round(penalty, 1),
        'headroom_score': round(headroom_component, 1),
        'discovery_score': round(discovery_component, 1),
        'scout_score': scout,
        'flow_score': round(flow_component, 1),
        'turnover_score': round(turnover_component, 1),
        'compression_score': round(compression_component, 1),
        'freshness_score': round(freshness_component, 1),
        'fresh_age_sec': fresh_meta['age_sec'],
        'fresh_label': fresh_meta['label'],
        'fresh_window': fresh_meta['fresh_window'],
        'fast_scout': fresh_meta['fast_track'],
        'rank_trend': fresh_meta['rank_trend'],
        'rank_velocity': fresh_meta['rank_velocity'],
        'new_sources_60s': fresh_meta['new_sources_60s'],
        'best_rank': fresh_meta['best_rank'],
        'reasons': reasons[:5],
        'rate': rate,
        'venue': lane.venue.value,
    }
