# MAX PROFIT LAB — VERIFY ONLY invariants

1. The user-approved R4.3 CORE3 dashboard `<main>` block is locked at SHA-256 `f0e4b3529b2c0affe9809fe6c93c0090a05691b239937d804806862bb26451a4`.
2. `app/signal/policy.py` remains byte-frozen at SHA-256 `18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a`.
3. `ops/http_guard_v2.py` remains byte-frozen at SHA-256 `c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b`.
4. The lab consumes in-memory venue metrics. Market expansion reuses existing ranking REST responses and adds zero REST calls, zero subscription types and zero provider-ceiling increase.
5. Rotation uses only bounded spare TRADE slots (8/4/2/0 by load); it adds no PROGRAM or ORDERBOOK feed.
6. The lab never mutates official Candidate score/stage, ENTRY lane, BUY state, official WAL or tracking reservations. Promotion requires a discarded exploration window and fresh live warming.
7. The lab is served only at `/max-profit-lab`; no panel, button, row or link is inserted into the existing dashboard.
8. Candidate and category boards are capped at 10 rows. Preferred shares, SPACs and managed flags are separated from common shares.
9. Limit stability is explicitly trade/price-flow based. The lab does not claim orderbook queue-lock certainty.
10. Probability is hidden until the same stage has at least 300 samples and at least 30 successes. Published rates include a 95% Wilson interval.
11. Alerts default to OFF. Disabling alerts never disables scanning or VERIFY persistence. Alerts cannot place orders.
12. Only `quant-nova` may be replaced. Guard and Caddy are protected by pre/post container-ID comparison.
13. Failed image, health, API, WebSocket, rotation, invariant, swap or active-session trade-progress gates restore the exact pre-cutover container.
14. VERIFY candidate ranking is strict `QUALIFIED > DATA_WAIT > CONDITION_MISS`; this ordering never changes ENTRY_V18 or official BUY thresholds.
15. `DATA_WAIT` is allowed only when exactly one required non-price observation is unavailable and every available frozen threshold passes. Price/freshness/resync/continuity failures remain hard exclusions.
16. `CONDITION_MISS` is display-only and limited to at most two narrowly bounded threshold misses. DATA_WAIT/CONDITION_MISS rows cannot create a new lab sample/event, cannot alert, and report `official_buy_eligible=false`.
17. When fewer than 10 fresh/continuous candidates exist, the UI shows explicit empty slots rather than fabricating stocks; when near candidates exist they fill behind QUALIFIED rows with their exact missing/failing reasons.
