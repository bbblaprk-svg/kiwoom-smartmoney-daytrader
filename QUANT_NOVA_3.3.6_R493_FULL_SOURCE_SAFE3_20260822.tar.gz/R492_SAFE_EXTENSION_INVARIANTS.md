# R492 SAFE EXTENSION INVARIANTS

- R491 official BUY / ENTRY_V18, Kiwoom REST and broker WebSocket subscription types are unchanged.
- PRE eligibility is unchanged. R492 only reserves display membership capacity: NORMAL CORE16 + FRESH4, BUSY FRESH3, HIGH_LOAD FRESH2, CRITICAL FRESH0.
- ENERGY NOW and POWER PATH use only candidate/venue metrics already present in RuntimeState; no broker request is issued by these engines.
- Shared detailed candidate pool is capped at 40 in NORMAL. ENERGY evaluates at most 25 and PATH at most 30, with overlap sharing the same cached candidate data.
- Priority under load is PRE/BUY/NXT > ENERGY > PATH. HIGH_LOAD pauses PATH ranking; CRITICAL returns R491_SAFE and no R492 rows.
- ENERGY membership commits every 30 seconds with 90 second minimum dwell. PATH membership commits every 5 minutes with 15 minute minimum dwell.
- ENERGY/PATH are DISPLAY/VERIFY outputs. PATH is a live observable proxy until multi-session H1 calibration is applied; it is not a calibrated 2X probability.
- Closed sessions show only the last non-empty live ENERGY/PATH snapshot from this process; they do not fabricate new post-close candidates.
