# R47 SESSION CLOSE QUEUE DROP INVARIANTS

- Extends R46 session-close hard freeze.
- A score job dequeued after its venue is no longer in continuous session is dropped before MetricEngine, EntryPolicy, WAL, repeat accounting, OpeningBridge, or candidate history can mutate.
- Closed-session late queue jobs cannot append ENTRY_STATE, SIGNAL, BUY, TOP10 ENTER/EXIT/REENTER, or increment valid/raw repeat counters.
- Candidate score/stage/entry state remain exactly as committed at the live-session boundary when a late queued score job arrives after close.
- KRX closes independently from NXT: a late KRX job is dropped after KRX close while NXT jobs continue normally until NXT closes.
- Active-session scoring/BUY behavior is unchanged below the guard.
- R46 dashboard hard-freeze, R45 LARGE-CAP LAST-LIVE ONLY, R44 Opening 10:00 hide, official BUY policy, Kiwoom REST/WS, Guard and Caddy remain unchanged.
