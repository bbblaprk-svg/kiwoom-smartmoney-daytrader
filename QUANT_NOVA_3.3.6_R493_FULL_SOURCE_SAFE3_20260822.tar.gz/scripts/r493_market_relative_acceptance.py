from __future__ import annotations
import time
from app.addons.energy_path import EnergyPathEngine
from app.addons.market_relative import market_overlay
from app.domain import Venue
from app.runtime.state import RuntimeState


def seed(st, code, rate, market):
    c=st.candidate(code,code,trade_day='20260822');c.current_venue=Venue.KRX;c.metrics.update({'market_code':market,'discovery_source_count':3,'discovery_rank_velocity_pos':5})
    v=c.venue_state[Venue.KRX];v.last_price=10000;v.last_rate=rate;v.last_tick_at=time.time();v.day_low=9500;v.day_high=10200
    v.metrics.update({'fresh':True,'turnover_accel_ready':True,'turnover_accel_30s':1.6,'volume_accel_ready':True,'volume_accel':1.5,'buy_pressure':62,'buy_pressure_delta_30s':5,'impulse_30s':.4,'impulse_60s':.8,'impulse_180s':1.2,'micro_vwap_gap':.2,'session_vwap_gap':.4,'smart_money_realtime_proxy_score':3,'smart_money_acceleration':1.3,'turnover_60s':200_000_000})
    return c


def main():
    st=RuntimeState();now=time.time();st.load_mode='NORMAL'
    st.market_context['KOSPI']={'ok':True,'change_rate':-1.4,'breadth':-30,'regime':'RISK_OFF','updated_at':now,'source':'TEST'}
    st.market_context['KOSDAQ']={'ok':True,'change_rate':1.0,'breadth':20,'regime':'RISK_ON','updated_at':now,'source':'TEST'}
    a=seed(st,'111111',0.4,'001');b=seed(st,'222222',0.4,'101')
    oa=market_overlay(st,a,now,5);ob=market_overlay(st,b,now,5)
    assert oa['market_adjustment']>0 and oa['market_resilient'],oa
    assert ob['market_adjustment']<0,ob
    out=EnergyPathEngine(st).build([a,b],now,True,set())
    assert out['energy'] and out['path']
    by={r['code']:r for r in out['energy']}
    assert by['111111']['market_available'] is True
    assert 'rank_score_raw' in by['111111'] and by['111111']['rank_score']!=by['111111']['rank_score_raw']
    print('R493_MARKET_RELATIVE_ACCEPTANCE=PASS')

if __name__=='__main__':main()
