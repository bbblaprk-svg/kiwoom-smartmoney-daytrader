from __future__ import annotations

import asyncio
import hashlib
import json
import re
import sqlite3
import tempfile
import time
from pathlib import Path

from app.addons.max_profit_lab import MaxProfitLab
from app.config import SETTINGS
from app.domain import Venue
from app.runtime.state import RuntimeState


ROOT = Path(__file__).resolve().parents[1]


async def verify_shadow_store() -> dict:
    state = RuntimeState()
    state.restore_done = True
    candidate = state.candidate('123456', 'MAXPROFIT검증', trade_day='20260814')
    state.exploration_codes.add(candidate.code)
    lane = candidate.venue_state[Venue.KRX]
    now = time.time()
    lane.last_price = 10500
    lane.last_rate = 5.0
    lane.last_tick_at = now
    lane.last_recv_seq = 1
    lane.metrics.update({
        'fresh': True,
        'volume_accel': 1.8,
        'volume_accel_ready': True,
        'buy_pressure': 63,
        'execution_strength': 135,
        'turnover_60s': 350_000_000,
        'session_vwap_gap': .8,
        'impulse_60s': .7,
        'micro_breakout': .4,
    })
    before = (candidate.score, candidate.stage, candidate.entry_state, lane.score, lane.stage, dict(lane.metrics))
    with tempfile.TemporaryDirectory(prefix='nova-maxprofit-') as td:
        lab = MaxProfitLab(state, Path(td))
        lab.store.ensure()
        row = lab._evaluate(candidate, Venue.KRX, True, now + .1)
        assert row and row['stage'] == 'PRE_IGNITION', row
        assert row['selection_status'] == 'QUALIFIED'
        assert row['coverage_lane'] == 'ROTATION_VERIFY' and row['official_buy_eligible'] is False
        await lab.flush_pending()
        con = sqlite3.connect(Path(td) / 'max_profit_verify.sqlite3')
        counts = {
            'samples': con.execute('SELECT COUNT(*) FROM lab_samples').fetchone()[0],
            'events': con.execute('SELECT COUNT(*) FROM lab_events').fetchone()[0],
            'horizons': con.execute('SELECT COUNT(*) FROM lab_horizon_outcomes').fetchone()[0],
        }
        con.close()
    after = (candidate.score, candidate.stage, candidate.entry_state, lane.score, lane.stage, dict(lane.metrics))
    assert before == after, 'shadow observer mutated official candidate state'
    assert counts == {'samples': 1, 'events': 1, 'horizons': 3}, counts
    return {'stage': row['stage'], **counts}


def static_contracts() -> dict:
    policy_sha = hashlib.sha256((ROOT / 'app/signal/policy.py').read_bytes()).hexdigest()
    guard_sha = hashlib.sha256((ROOT / 'ops/http_guard_v2.py').read_bytes()).hexdigest()
    assert policy_sha == '18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a'
    assert guard_sha == 'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b'
    html = (ROOT / 'static/index.html').read_text(encoding='utf-8')
    main = re.search(r'<main>.*?</main>', html, re.S)
    assert main
    main_sha = hashlib.sha256(main.group(0).encode()).hexdigest()
    assert main_sha == 'f04ae99c607fbe0080d57ae869b4d9fe89b38b47f327bf12161ed4f3b76dad7c'
    lab_html = (ROOT / 'static/max-profit-lab.html').read_text(encoding='utf-8')
    lab_js = (ROOT / 'static/max-profit-lab.js').read_text(encoding='utf-8')
    api = (ROOT / 'app/api/app.py').read_text(encoding='utf-8')
    websocket = (ROOT / 'app/broker/websocket.py').read_text(encoding='utf-8')
    service = (ROOT / 'app/service.py').read_text(encoding='utf-8')
    rotation = (ROOT / 'app/broker/market_rotation.py').read_text(encoding='utf-8')
    coordinator = (ROOT / 'app/signal/coordinator.py').read_text(encoding='utf-8')
    for needle in ('alertMaster', 'candidateRows', 'statsRows', 'eventRows'):
        assert needle in lab_html, needle
    for needle in ('nova_max_profit_alerts_v1', 'Notification.permission', 'alert_seq', 'bell'):
        assert needle in lab_js, needle
    for needle in ('DATA WAIT', '조건미달', "selection_status||'QUALIFIED')!=='QUALIFIED'"):
        assert needle in lab_js, needle
    lab = (ROOT / 'app/addons/max_profit_lab.py').read_text(encoding='utf-8')
    for needle in ('single_missing_metric_rescue', 'DATA_WAIT', 'CONDITION_MISS', 'qualified_first_ranking', 'candidate_ranking', 'early_edge_score'):
        assert needle in lab, needle
    assert '/ws/max-profit-lab' in api and '/api/max-profit-lab' in api
    assert 'connection_window()' in websocket and 'SESSION_GAP' in websocket
    assert '_ws_after_restore' not in service and 'POST_RESTORE_WARMING' in service
    assert 'REST.post' not in rotation and 'exploration_codes' in websocket
    assert 'exploration_official_block_count' in coordinator and 'if exploration_only:return' in coordinator
    return {'policy_sha256': policy_sha, 'guard_sha256': guard_sha, 'main_dom_sha256': main_sha}


def main() -> None:
    result = {
        'ok': True,
        'version': SETTINGS.version,
        'mode': 'VERIFY_ONLY',
        'static': static_contracts(),
        'shadow_store': asyncio.run(verify_shadow_store()),
        'new_broker_rest_calls': 0,
        'new_ws_subscription_types': 0,
        'ws_registered_code_ceiling_increase': 0,
        'bounded_trade_rotation': True,
        'exploration_official_buy_blocked': True,
        'exploration_aux_feeds_added': False,
        'automatic_orders': False,
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    print('MAX_PROFIT_ACCEPTANCE=PASS')


if __name__ == '__main__':
    main()
