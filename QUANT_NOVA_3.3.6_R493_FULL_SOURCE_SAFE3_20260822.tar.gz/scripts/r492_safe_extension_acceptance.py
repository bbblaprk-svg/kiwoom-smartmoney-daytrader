from __future__ import annotations
import time
from app.addons.decision_panels import DecisionPanelEngine
from app.addons.energy_path import EnergyPathEngine
from app.domain import Venue
from app.runtime.state import RuntimeState


def seed(st:RuntimeState,code:str,rank:int,fresh_age:float=50.0):
    now=time.time();c=st.candidate(code,f'N{code}',trade_day='20260821');c.current_venue=Venue.KRX;c.score=68;c.priority_score=70
    c.metrics.update({'discovery_first_seen_at':now-fresh_age,'discovery_best_rank':rank,'discovery_source_count':3,'discovery_new_sources_60s':2,'discovery_rank_velocity_pos':5})
    v=c.venue_state[Venue.KRX];v.last_price=10000+rank;v.last_rate=2;v.last_tick_at=now;v.day_low=9500;v.day_high=10200;v.session_pv=1_000_000_000;v.session_v=100_000
    v.metrics.update({'fresh':True,'turnover_accel_ready':True,'turnover_accel_30s':1.8,'volume_accel_ready':True,'volume_accel':1.7,'buy_pressure':63,'buy_pressure_delta_30s':6,'impulse_30s':.5,'impulse_60s':1.0,'impulse_180s':1.6,'micro_vwap_gap':.3,'session_vwap_gap':.5,'smart_money_realtime_proxy_score':3.5,'smart_money_acceleration':1.4,'net_large_flow_30s':90_000_000,'program_score':1.0,'turnover_60s':300_000_000})
    return c


def main():
    st=RuntimeState();st.load_mode='NORMAL';rows=[seed(st,f'{i:06d}',i,50 if i<=8 else 2000) for i in range(1,31)]
    ep=EnergyPathEngine(st);out=ep.build(rows,time.time(),True,set())
    assert out['shared_pool']<=40 and len(out['energy'])<=10 and len(out['path'])<=10,out
    assert out['mode']=='NORMAL' and out['energy'] and out['path']
    st.load_mode='CRITICAL';safe=ep.build(rows,time.time()+1,True,set());assert safe['mode']=='R491_SAFE' and not safe['energy'] and not safe['path']
    dp=DecisionPanelEngine(st);ranked=[]
    for i in range(1,25):ranked.append({'code':f'{i:06d}','rank_score':100-i,'score':100-i,'discovery_age_sec':50 if i>=20 else 2000,'fast_scout':False,'live_evidence_lane':False})
    st.load_mode='NORMAL';mixed=dp._compose_r492_pre_fresh(ranked,time.time())[:20];assert sum(1 for r in mixed if r.get('r492_lane')=='FRESH')==4,mixed
    print('R492_SAFE_EXTENSION_ACCEPTANCE=PASS')

if __name__=='__main__':main()
