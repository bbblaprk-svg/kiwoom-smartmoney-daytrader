from __future__ import annotations
import hashlib
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.config import SETTINGS


def main():
    assert SETTINGS.discovery_anchor_slots==6
    assert SETTINGS.discovery_fresh_slots==4
    assert SETTINGS.discovery_display_hold_sec==20.0
    assert SETTINGS.discovery_display_immediate_gap==5.0
    assert SETTINGS.fresh_scout_fast_sec==90
    assert SETTINGS.fresh_scout_window_sec==180

    early=(ROOT/'app/signal/early_edge.py').read_text(encoding='utf-8')
    disc=(ROOT/'app/broker/discovery.py').read_text(encoding='utf-8')
    display=(ROOT/'app/runtime/display.py').read_text(encoding='utf-8')
    panels=(ROOT/'app/addons/decision_panels.py').read_text(encoding='utf-8')
    lab=(ROOT/'app/addons/max_profit_lab.py').read_text(encoding='utf-8')
    nova=(ROOT/'static/nova.js').read_text(encoding='utf-8')
    decision_js=(ROOT/'static/decision-panels.js').read_text(encoding='utf-8')
    lab_js=(ROOT/'static/max-profit-lab.js').read_text(encoding='utf-8')

    for needle in ('def discovery_freshness','fast_track','freshness_component = 15.0','freshness_component = 13.0','freshness_component = 8.0'):
        assert needle in early,needle
    for needle in ('fresh_scout_confirmed','fresh_scout_fast_track_selected','fresh_scout_confirmed_selected','scout_slots'):
        assert needle in disc,needle
    for needle in ('_compose_anchor_fresh','_stabilize_discovery','discovery_display_immediate_gap','rank_lane'):
        assert needle in display,needle
    for needle in ('_compose_anchor_fresh_rows','_stabilize_rows','_stabilize_signal_accel','pre_signal_slots','pre_rank_commit_sec','pre_min_dwell_sec','pre_newcomer_gap'):
        assert needle in panels,needle
    for needle in ('stable_codes_by_board','_stabilize_candidate_rows','Build every category from the complete ranked candidate set'):
        assert needle in lab,needle
    for blob in (nova,decision_js,lab_js):
        for needle in ('fresh_label','RANK ↑','FAST SCOUT','EARLY'):
            assert needle in blob,needle

    expected={
        'app/signal/policy.py':'18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a',
        'ops/http_guard_v2.py':'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b',
        'app/broker/kiwoom.py':'e10d936a2540a70d8a488e0460608a3c2a1a8bfaf95dc6206e706cce3afab0d1',
        'app/broker/websocket.py':'50fefc5faa1457210af758636279bea0bc3926e505bc91317962a0d451e35602',
    }
    for rel,sha in expected.items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==sha,(rel,sha)

    # Contract proof: no additional rank REST endpoint/spec and no WS ceiling change.
    assert disc.count("('orderbook_buy'")==1
    assert 'RANK_SPECS=[' in disc
    assert 'new WebSocket(' in nova
    print('R42_FRESH_SCOUT_ACCEPTANCE=PASS core_anchor=6 core_fresh=4 core_hold=20s fast=90s; PRE_PANEL=R49_SIGNAL_ACCEL_30S')
    print('R42_LIVE_METRICS_DURING_HOLD=PASS position_only=true')
    print('R42_PROTECTED_TRUTH=PASS official_buy=UNCHANGED rest_added=0 ws_types_added=0')

if __name__=='__main__':main()
