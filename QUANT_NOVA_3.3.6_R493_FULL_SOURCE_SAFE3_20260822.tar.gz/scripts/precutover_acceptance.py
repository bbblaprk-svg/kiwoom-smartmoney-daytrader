from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ENV={**os.environ,'PYTHONPATH':str(ROOT),'PYTHONDONTWRITEBYTECODE':'1'}
STEPS=[
 ('UNITTEST_ALL',[sys.executable,'-m','unittest','discover','-s',str(ROOT/'tests'),'-v']),
 ('IMAGE_CONTRACT',[sys.executable,str(ROOT/'scripts/image_contract.py'),str(ROOT)]),
 ('MASTER_AUDIT',[sys.executable,str(ROOT/'scripts/master_audit.py')]),
 ('MAX_PROFIT',[sys.executable,str(ROOT/'scripts/max_profit_acceptance.py')]),
 ('MARKET_ROTATION',[sys.executable,str(ROOT/'scripts/market_rotation_acceptance.py')]),
 ('FRESH_SCOUT',[sys.executable,str(ROOT/'scripts/r42_fresh_scout_acceptance.py')]),
 ('R492_SAFE_EXTENSION',[sys.executable,str(ROOT/'scripts/r492_safe_extension_acceptance.py')]),
 ('R493_MARKET_RELATIVE',[sys.executable,str(ROOT/'scripts/r493_market_relative_acceptance.py')]),
 ('VALIDATE_QUICK',[sys.executable,str(ROOT/'scripts/validate.py'),'--quick']),
]
for name,cmd in STEPS:
    print(f'===== PRECUTOVER {name} START =====',flush=True)
    cp=subprocess.run(cmd,cwd=ROOT,env=ENV)
    if cp.returncode:
        print(f'PRECUTOVER_FAILED_STEP={name} RC={cp.returncode}',flush=True)
        raise SystemExit(cp.returncode)
    print(f'===== PRECUTOVER {name} PASS =====',flush=True)
print('R493_PRECUTOVER_ACCEPTANCE=PASS',flush=True)
