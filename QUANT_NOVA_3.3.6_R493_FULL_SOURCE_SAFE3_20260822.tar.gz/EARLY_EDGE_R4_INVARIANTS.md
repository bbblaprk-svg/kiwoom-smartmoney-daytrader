# QUANT NOVA 3.3.4 R4 EARLY EDGE invariants

## Root objective
The discovery/ranking objective is **pre-breakout early capture**, not pursuit of names that have already rallied.

A candidate is preferred when market-rank attention, buy pressure, turnover and smart-money flow are accelerating while price remains relatively unextended and compressed near VWAP / a micro breakout setup.

## Scope changed in R4
- Existing seven DiscoveryEngine rank requests are reused. No broker REST request is added.
- Discovery stores bounded scalar rank-change metadata: rank velocity, new source joins, breadth, first-seen age and best rank.
- HOT subscription selection reserves a bounded scout share for newly climbing ranking names. The total HOT / WS budgets do not increase.
- MarketRotation VERIFY-only ranking is EARLY EDGE / scout first.
- FAST metrics add 30s-vs-previous-30s turnover acceleration and buy-pressure delta; the frozen official ENTRY_V18 score formula is unchanged.
- LARGE-CAP and PRE-IGNITION display ranking become EARLY EDGE first with explicit headroom / chase penalty.
- Main `prebuy` and `nxt_early` display boards rank by EARLY EDGE. `live_buy`, `position_manager`, Opening Bridge, NXT management/history remain management/truth boards and are not converted to discovery ranks.
- MAX PROFIT candidate list ranks by EARLY EDGE; stage progression is still recorded for VERIFY statistics/events.

## Explicit chase control
- Headroom is highest before large price expansion.
- Chase penalty starts after modest extension and becomes strong above +5% / +8%.
- +10% names are capped at EARLY EDGE 45; +15% names are capped at 25.
- Cumulative repeat count is never a primary EARLY EDGE feature.

## Frozen / protected contracts
- Official BUY policy is unchanged.
- `app/signal/policy.py` SHA256 remains `18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a`.
- HTTP Guard remains unchanged: `c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b`.
- Kiwoom REST and WebSocket transport source remain byte-identical to R3.
- No new broker REST API IDs and no new WebSocket subscription types.
- Main screen DOM structure remains byte-identical to R3; only existing JS-rendered score semantics change for discovery boards.
- Guard and Caddy are never replaced by this release.
