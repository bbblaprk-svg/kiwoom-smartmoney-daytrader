(()=>{
const $=id=>document.getElementById(id);const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,d=0)=>v===null||v===undefined||v===''?'-':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d,minimumFractionDigits:d});
const cls=v=>Number(v)>0?'up':Number(v)<0?'down':'';const freshMeta=r=>{const a=[];if(r?.fresh_label)a.push(String(r.fresh_label));if(String(r?.rank_trend||'')==='UP')a.push('RANK ↑');if(r?.fast_scout)a.push('FAST SCOUT');if(['PRE_BREAKOUT','EARLY_IGNITION'].includes(String(r?.early_edge_stage||'')))a.push('EARLY');return a.join(' · ')};let timer=null,busy=false,lastOk=0;
function empty(rank){return `<div class="drow empty"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>-</b><small>대기</small></div><div></div><div></div><div></div></div></div>`}
function largeRow(r,rank){
  if(!r)return empty(rank);
  const dc=String(r.decision||'WAIT'),coverage=String(r.coverage_status||'CORE');
  const display=coverage==='MARKET_BACKFILL'?'시장보완':dc==='DATA_WAIT'?'DATA WAIT':dc;
  const k=coverage==='MARKET_BACKFILL'?'decision-reference':dc==='DATA_WAIT'?'decision-data-wait':dc==='NOW'?'decision-now':dc==='WAIT'?'decision-wait':'decision-avoid';
  const prefix=(r.decision_mode==='CLOSE'&&coverage!=='MARKET_BACKFILL')?'종가 ':'';
  const entry=(coverage==='CORE'&&r.entry_low)?`${fmt(r.entry_low)}~${fmt(r.entry_high)}`:'대기';
  const reasons=esc((r.reasons||[]).slice(0,3).join(' · '));
  return `<div class="drow drow-large"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(r.entry_state)}${freshMeta(r)?' · '+esc(freshMeta(r)):''} · 반복 ${fmt(r.valid_repeat_count)}</small></div><div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="dscore">EE ${fmt(r.early_edge_score??r.score,1)}<br><small>종합 ${fmt(r.score,1)}</small></div><div class="ddecision ${k}"><b>${prefix}${esc(display)}</b></div></div><div class="dsub"><div class="dreasons">${reasons||'판정근거 대기'}</div><div class="dplan"><b>${coverage==='MARKET_BACKFILL'?'참고후보':dc==='DATA_WAIT'?'데이터 대기':'추천진입'} ${entry}</b><span>추격금지 ${r.chase_limit?`>${fmt(r.chase_limit)}`:'-'}</span><span>손절 ${fmt(r.stop)}</span><span>T1 ${fmt(r.t1)}</span><span>T2 ${fmt(r.t2)}</span></div></div></div>`
}
function tags(r){const a=(r?.overlap_tags||[]).filter(Boolean);return a.length?` · ${a.map(x=>`[${esc(x)}]`).join(' ')}`:''}
function mkt(r){if(!r?.market_available)return '';const rel=Number(r.market_relative_rate||0),adj=Number(r.market_adjustment||0),res=r.market_resilient?' · RESILIENT↑':'';return ` · ${esc(r.market_name||'MKT')} ${rel>=0?'+':''}${fmt(rel,2)}% · 보정 ${adj>=0?'+':''}${fmt(adj,1)}${res}`}
function energyRow(r,rank){
  if(!r)return empty(rank);const c=r.components||{},paused=r.paused?' · PAUSED':'';
  return `<div class="drow drow-r492"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(r.stage)}${tags(r)}${paused}${mkt(r)}</small></div><div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="dscore">E ${fmt(r.score,1)}<br><small>ΔE ${fmt(r.delta,1)}</small></div><div class="ddecision ${Number(r.risk)<=35?'decision-now':Number(r.risk)>=60?'decision-avoid':'decision-wait'}"><b>RISK ${fmt(r.risk,0)}</b></div></div><div class="dsub"><div class="dreasons">MASS ${fmt(c.mass,1)} · ACC ${fmt(c.acceleration,1)} · ABS ${fmt(c.absorption,1)} · RET ${fmt(c.retention,1)}</div><div class="dplan"><span>VEL ${fmt(c.velocity,1)}</span><span>REL ${fmt(c.relative,1)}</span><span>RE-IGN ${fmt(c.reignition,1)}</span></div></div></div>`
}
function pathRow(r,rank){
  if(!r)return empty(rank);const c=r.components||{},paused=r.paused?' · PAUSED':'';
  return `<div class="drow drow-r492"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(r.stage)}${tags(r)}${paused}${mkt(r)}</small></div><div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="dscore">PATH ${fmt(r.score,1)}<br><small>ΔP ${fmt(r.delta,1)}</small></div><div class="ddecision ${Number(r.risk)<=35?'decision-now':Number(r.risk)>=60?'decision-avoid':'decision-wait'}"><b>RISK ${fmt(r.risk,0)}</b></div></div><div class="dsub"><div class="dreasons">MONEY ${fmt(c.money_regime,1)} · FLOW ${fmt(c.dominant_flow,1)} · RETAIN ${fmt(c.retention_pct,0)}%</div><div class="dplan"><span>ACCEPT ${fmt(c.high_acceptance,1)}</span><span>2ND ${fmt(c.second_wave,1)}</span></div></div></div>`
}
function preRow(r,rank){
  if(!r)return empty(rank);
  const st=String(r.state||'관찰');
  const k=st==='진입대상'?'decision-entry-target':st==='COOLING'?'decision-cooling':'decision-watch';
  const close=r.window_mode==='CLOSE',prefix=close?'마감 ':'';
  const reasons=esc((r.reasons||[]).slice(0,4).join(' · '));
  const types=esc((r.signal_types||[]).slice(0,4).join('/'));const lane=String(r.rank_lane||'SIGNAL');const liveN=Number(r.live_evidence_count||0);
  return `<div class="drow drow-pre signal-accel-row"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(st)} · ${esc(lane)} · 증거 ${fmt(r.signal_type_count)}종 · LIVE ${fmt(liveN)}종 · 누적반복 ${fmt(r.repeat_total)}${mkt(r)}</small></div><div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="dscore">SA ${fmt(r.rank_score??r.score,1)}<br><small>EE ${fmt(r.early_edge_score,1)}</small></div><div class="ddecision ${k}"><b>${prefix}${esc(st)} ${esc(r.accel||'→')}</b></div></div><div class="dsub"><div class="dreasons">${reasons||types||'가속근거 대기'}</div><div class="dplan preplan"><b>${prefix}5분 ${fmt(r.signal_5m)} · 15분 ${fmt(r.signal_15m)} · 30분 ${fmt(r.signal_30m)}</b><span>LIVE ${fmt(liveN)}종</span><span>유형 ${fmt(r.signal_type_count)}종</span><span>BP ${fmt(r.buy_pressure,0)}%</span><span>거래 ${fmt(r.volume_accel,2)}x</span><span>VWAP ${fmt(r.vwap_gap,2)}%</span></div></div></div>`
}
function fill(id,rows,fn,pad=true,closed=false,limit=10){const root=$(id);if(!root)return;const a=(rows||[]).slice(0,limit);if(pad){while(a.length<limit)a.push(null);root.innerHTML=a.map((r,i)=>fn(r,i+1)).join('')}else{root.innerHTML=a.length?a.map((r,i)=>fn(r,i+1)).join(''):`<div class="drow empty"><div class="dtop"><div class="rank">-</div><div class="dname"><b>${closed?'오늘 LIVE 확인 종목 없음':'실시간 유효 종목 없음'}</b><small>${closed?'장마감 마지막 LIVE 기준':'조건 충족 종목만 표시'}</small></div></div></div>`}}
function render(j){
  fill('largecap_swing',j.largecap,largeRow,false,!j.market_active,10);fill('preignition_accel',j.preignition,preRow,false,!j.market_active,20);fill('energy_now',j.energy,energyRow,false,!j.market_active,10);fill('power_path',j.path,pathRow,false,!j.market_active,10);
  const a=$('largecap_contract'),b=$('preignition_contract'),e=$('energy_contract'),p=$('path_contract');
  if(a){const shown=(j.largecap||[]).length;a.textContent=j.market_active?`LIVE REALTIME ONLY · 표시 ${shown}/10 · DATA WAIT 제외 · 시장보완 0 · 공식 BUY 미반영`:shown?`SESSION CLOSED · LAST LIVE ${shown}/10 · DATA WAIT 0 · 시장보완 0 · 장마감 DATA WAIT 재구성 안함`:`SESSION CLOSED · 오늘 LIVE 확인 대형주 없음 · DATA WAIT 0 · 장마감 DATA WAIT 재구성 안함`};
  if(b){const c=j.circulation||{},shown=(j.preignition||[]).length,next=Math.max(0,Math.ceil(Number(j.next_pre_rank_in_sec||0)));b.textContent=j.market_active?`LIVE DATA 지속 · 순위 ${next}초 후 반영 · 30초 확정 / 최소체류 60초 / 신규 +3점 · R492 CORE/FRESH 슬롯 · 표시 ${shown}/20 · 진입대상≠BUY · LIVE ${c.live_evidence_active??'-'} / 만료 ${c.live_evidence_expired_10m??'-'}`:`SESSION CLOSED · SIGNAL ACCEL TOP20 마지막 LIVE FROZEN (${j.freeze_source||'CLOSE'}) · 공식 BUY 미반영`};
  const x=j.r492||{},mc=x.market_context||{},ki=mc.KOSPI||{},kq=mc.KOSDAQ||{};const mtxt=(ki.ok||kq.ok)?` · KOSPI ${fmt(ki.change_rate,2)}%/${esc(ki.regime||'-')} · KOSDAQ ${fmt(kq.change_rate,2)}%/${esc(kq.regime||'-')}`:' · 시장지수 대기';if(e)e.textContent=j.market_active?`R493 ${x.mode||'-'} · 공용후보 ${x.shared_pool??0}/40 · ENERGY 후보 ${x.energy_candidates??0}/25 · 30초 순위확정${mtxt} · 지수REST 2회/60초 · 새 WS 0`:`SESSION CLOSED · ENERGY 마지막 LIVE FROZEN${mtxt}`;if(p)p.textContent=j.market_active?`R493 ${x.mode||'-'} · PATH 후보 ${x.path_candidates??0}/30 · 5분 순위확정 · HIGH_LOAD시 PATH 우선정지${mtxt}`:`SESSION CLOSED · PATH 마지막 LIVE FROZEN${mtxt}`;
  lastOk=Date.now()
}
async function tick(){if(busy)return;busy=true;try{const f=window.NOVA_FETCH_JSON;if(typeof f!=='function')return;const j=await f('/api/decision-panels',3000);if(j&&j.ok)render(j)}catch(_){if(Date.now()-lastOk>8000){const a=$('largecap_contract'),b=$('preignition_contract');if(a)a.textContent='보조 패널 재연결 중 · 기준 NOVA에는 영향 없음';if(b)b.textContent='SIGNAL ACCELERATION 재연결 중 · 공식 BUY에는 영향 없음'}}finally{busy=false}}
function boot(){if(timer)return;tick();timer=setInterval(tick,1800)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
