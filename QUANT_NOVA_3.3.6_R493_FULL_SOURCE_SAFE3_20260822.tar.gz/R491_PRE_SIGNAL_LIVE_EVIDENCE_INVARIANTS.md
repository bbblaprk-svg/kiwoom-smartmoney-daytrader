# QUANT NOVA R49.1 — PRE-SIGNAL LIVE-EVIDENCE invariants

## Purpose
R49 simulation exposed a real blind spot: after FAST SCOUT expired, a symbol with strong current BP/Smart/volume/turnover/rank acceleration disappeared unless a formal SIGNAL had already been committed. R49.1 closes that display-only blind spot without relaxing or mutating ENTRY_V18.

## Pre-formal LIVE-EVIDENCE lane
- Formal 5m/15m/30m signal windows remain unchanged and contain only committed formal SIGNAL history.
- A symbol with no recent formal SIGNAL may remain eligible when current broker-trade truth is fresh and at least three independent live evidence types are present.
- Qualification requires current activity plus current flow; historical repeat count and a live tick by themselves are never sufficient.
- Strong pre-entry evidence requires at least four live evidence types and both BP acceleration and Smart/flow evidence plus activity acceleration.
- Current live evidence may contribute to the acceleration score before the first formal SIGNAL. It never writes a formal SIGNAL.

## Bounded anti-stickiness
- A continuous pre-formal LIVE-EVIDENCE episode may occupy the board for at most 600 seconds.
- The episode is revalidated on every live build; losing eligibility removes the row immediately from the eligible set.
- A live-evidence gap longer than 60 seconds rearms a future episode.
- A recent formal SIGNAL supersedes the live-only episode and uses the normal formal-signal lane.
- Stale `live_track_pin` status alone cannot qualify or extend the board row.

## Entry-target label
- `진입대상` remains display-only and is not ENTRY_V18 or BUY.
- The 4-of-5 checks are: acceleration evidence, current flow, price position/headroom, activity acceleration, and current-data freshness.
- Acceleration evidence may be satisfied by formal signal acceleration OR strong current LIVE-EVIDENCE.
- Overheated/chase-blocked rows remain `COOLING`.

## Rank stability
- TOP20 maximum; partial rows allowed; no force-fill.
- Live data updates continuously.
- Membership/order commits every 30 seconds.
- Newly admitted rows have a 60-second normal minimum dwell.
- Full-board newcomer replacement requires +3 points over the weakest replaceable row.
- Ineligible/stale/expired rows leave immediately and are not protected by dwell.

## Preserved contracts
- Official ENTRY_V18 policy SHA-256: `18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a`.
- HTTP Guard SHA-256: `c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b`.
- Kiwoom REST rank specifications unchanged.
- Kiwoom WebSocket subscription types and registered-code ceiling unchanged.
- R48 board independence remains.
- R47 close-session hard freeze and late score-queue drop remain.
- R45 LARGE-CAP LAST-LIVE-only close policy remains.
- Guard and Caddy remain deployment-protected.
