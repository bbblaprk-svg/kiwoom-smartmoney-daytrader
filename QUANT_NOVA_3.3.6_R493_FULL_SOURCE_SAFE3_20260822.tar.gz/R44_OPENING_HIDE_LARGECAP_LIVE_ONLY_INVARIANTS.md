# R44 UI SAFETY CONTRACT

- Baseline: R43.1 CORE3 OPENING 10AM EXPIRE.
- Opening Profit Bridge backend capture/storage remains enabled; UI is visible only 08:00~10:00 KST and hard-hidden afterward.
- LARGE-CAP SWING active-session rows require a fresh live price/continuity. DATA_WAIT and MARKET_BACKFILL rows do not occupy live slots. Fewer than 10 rows is valid.
- Official BUY/ENTRY policy unchanged.
- Kiwoom REST endpoints/cadence unchanged.
- Kiwoom WebSocket subscriptions/ceiling unchanged.
- Guard/Caddy and market ingestion unchanged.
