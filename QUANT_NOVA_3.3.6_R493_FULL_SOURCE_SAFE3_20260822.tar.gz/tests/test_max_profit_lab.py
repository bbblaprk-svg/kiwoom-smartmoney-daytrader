from __future__ import annotations

import hashlib
import re
import tempfile
import unittest
from datetime import date
from pathlib import Path

from app.addons.max_profit_lab import (
    MaxProfitLab,
    PROBABILITY_MIN_SAMPLES,
    PROBABILITY_MIN_SUCCESSES,
    instrument_category,
    protection_line,
    wilson_interval,
)
from app.domain import Venue
from app.runtime.clock import connection_window_at, sessions_at
from app.runtime.state import RuntimeState


class MaxProfitLabTests(unittest.TestCase):
    def seeded(self, rate: float = 5.0):
        state = RuntimeState()
        state.restore_done = True
        candidate = state.candidate('123456', '검증종목', trade_day='20260814')
        lane = candidate.venue_state[Venue.KRX]
        lane.last_price = 10000
        lane.last_rate = rate
        lane.last_tick_at = 2_000_000_000.0
        lane.last_recv_seq = 1
        lane.metrics.update({
            'fresh': True,
            'volume_accel': 1.8,
            'volume_accel_ready': True,
            'buy_pressure': 63,
            'execution_strength': 135,
            'turnover_60s': 350_000_000,
            'session_vwap_gap': .8,
            'impulse_60s': .7,
            'micro_breakout': .4,
            'smart_money_realtime_proxy_score': 3,
        })
        candidate.current_venue = Venue.KRX
        candidate.refresh_aggregate()
        return state, candidate, lane

    def test_preignition_shadow_is_read_only(self):
        state, candidate, lane = self.seeded(5.0)
        before = (candidate.score, candidate.stage, candidate.entry_state, lane.score, lane.stage, dict(lane.metrics))
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            row = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
        after = (candidate.score, candidate.stage, candidate.entry_state, lane.score, lane.stage, dict(lane.metrics))
        self.assertEqual(before, after)
        self.assertEqual(row['stage'], 'PRE_IGNITION')
        self.assertEqual(row['selection_status'], 'QUALIFIED')
        self.assertIsNone(row['probability_pct'])

    def test_single_transient_missing_metric_is_data_wait_not_dropped(self):
        state, candidate, lane = self.seeded(5.0)
        lane.metrics['volume_accel_ready'] = False
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            row = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
        self.assertIsNotNone(row)
        self.assertEqual(row['selection_status'], 'DATA_WAIT')
        self.assertEqual(row['target_stage'], 'PRE_IGNITION')
        self.assertIn('거래량 기준선 축적 중', row['selection_reasons'])
        self.assertFalse(row['official_buy_eligible'])
        self.assertEqual(lab.pending_samples, {})
        self.assertEqual(lab.pending_events, {})

    def test_single_missing_numeric_metric_is_data_wait_not_defaulted_to_failure(self):
        state, candidate, lane = self.seeded(5.0)
        lane.metrics['buy_pressure'] = None
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            row = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
        self.assertIsNotNone(row)
        self.assertEqual(row['selection_status'], 'DATA_WAIT')
        self.assertIn('매수압력 데이터 대기', row['selection_reasons'])
        self.assertNotIn('매수압력 급락', row['collapse_reasons'])

    def test_close_threshold_miss_is_visible_but_not_promoted(self):
        state, candidate, lane = self.seeded(5.0)
        lane.metrics['volume_accel'] = 1.40
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            row = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
        self.assertIsNotNone(row)
        self.assertEqual(row['selection_status'], 'CONDITION_MISS')
        self.assertEqual(row['target_stage'], 'PRE_IGNITION')
        self.assertTrue(any('거래가속' in x for x in row['selection_reasons']))
        self.assertFalse(row['official_buy_eligible'])
        self.assertEqual(lab.pending_samples, {})
        self.assertEqual(lab.pending_events, {})

    def test_far_from_threshold_is_still_excluded(self):
        state, candidate, lane = self.seeded(5.0)
        lane.metrics['volume_accel'] = 1.0
        lane.metrics['buy_pressure'] = 45
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            row = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
        self.assertIsNone(row)

    def test_limit_touch_stable_unlock_and_relock_are_trade_flow_based(self):
        state, candidate, lane = self.seeded(29.6)
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(state, Path(td))
            first = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + .1)
            stable = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + 3.2)
            lane.last_rate = 28.8
            lane.last_price = 9900
            lane.last_recv_seq = 2
            unlocked = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + 4.0)
            lane.last_rate = 29.6
            lane.last_price = 10000
            lane.last_recv_seq = 3
            relocked = lab._evaluate(candidate, Venue.KRX, True, lane.last_tick_at + 8.0)
        self.assertEqual(first['stage'], 'LIMIT_GUARD')
        self.assertEqual(stable['stage'], 'LIMIT_STABLE')
        self.assertEqual(unlocked['stage'], 'UNLOCK_WATCH')
        self.assertEqual(relocked['stage'], 'RELOCK')
        self.assertEqual(relocked['unlock_count'], 1)
        self.assertEqual(relocked['relock_count'], 1)

    def test_protection_line_never_decreases(self):
        line = protection_line(0, 10)
        self.assertEqual(line, 7.0)
        self.assertEqual(protection_line(line, 8), line)
        self.assertEqual(protection_line(line, 20), 16.0)

    def test_probability_contract_is_not_published_early(self):
        self.assertEqual(PROBABILITY_MIN_SAMPLES, 300)
        self.assertEqual(PROBABILITY_MIN_SUCCESSES, 30)
        low, high = wilson_interval(45, 300)
        self.assertLess(low, .15)
        self.assertGreater(high, .15)

    def test_instrument_categories_are_separated(self):
        self.assertEqual(instrument_category('테스트스팩12호'), 'SPAC')
        self.assertEqual(instrument_category('테스트우B'), 'PREFERRED')
        self.assertEqual(instrument_category('테스트', {'managed_stock': True}), 'MANAGED')
        self.assertEqual(instrument_category('삼성전자'), 'COMMON')


class RealtimeP0AndUiFreezeTests(unittest.TestCase):
    def test_transport_stays_open_across_matching_gaps(self):
        trading_day = date(2026, 8, 14)
        for second in (8 * 3600 + 55 * 60, 15 * 3600 + 35 * 60, 20 * 3600 + 2 * 60):
            self.assertFalse(sessions_at(trading_day, second)['active'])
            self.assertTrue(connection_window_at(trading_day, second)['open'])
        self.assertEqual(connection_window_at(trading_day, 8 * 3600 + 55 * 60)['state'], 'SESSION_GAP')
        self.assertEqual(connection_window_at(trading_day, 20 * 3600 + 2 * 60)['state'], 'CLOSING')

    def test_connection_and_restore_are_parallel_but_signal_gate_is_closed(self):
        root = Path(__file__).resolve().parents[1]
        service = (root / 'app/service.py').read_text(encoding='utf-8')
        websocket = (root / 'app/broker/websocket.py').read_text(encoding='utf-8')
        coordinator = (root / 'app/signal/coordinator.py').read_text(encoding='utf-8')
        self.assertNotIn('_ws_after_restore', service)
        self.assertIn('asyncio.create_task(self.ws.run()', service)
        self.assertIn('and self.state.restore_done and', websocket)
        self.assertIn('SESSION_GAP', websocket)
        self.assertIn('self.state.restore_done and', coordinator)

    def test_r49_requested_main_screen_dom_is_source_controlled(self):
        root = Path(__file__).resolve().parents[1]
        html = (root / 'static/index.html').read_text(encoding='utf-8')
        main = re.search(r'<main>.*?</main>', html, re.S)
        self.assertIsNotNone(main)
        self.assertEqual(hashlib.sha256(main.group(0).encode()).hexdigest(),
                         'f04ae99c607fbe0080d57ae869b4d9fe89b38b47f327bf12161ed4f3b76dad7c')
        self.assertNotIn('max-profit', main.group(0).lower())

    def test_frozen_policy_and_guard_bytes_are_unchanged(self):
        root = Path(__file__).resolve().parents[1]
        self.assertEqual(hashlib.sha256((root / 'app/signal/policy.py').read_bytes()).hexdigest(),
                         '18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a')
        self.assertEqual(hashlib.sha256((root / 'ops/http_guard_v2.py').read_bytes()).hexdigest(),
                         'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b')

    def test_p1_boot_connects_ws_before_rest_recovery(self):
        root = Path(__file__).resolve().parents[1]
        js = (root / 'static/nova.js').read_text(encoding='utf-8')
        start = js.index('async function boot()')
        boot = js[start:js.index('\n', start)]
        self.assertLess(boot.index('connect()'), boot.index('recoverSnapshot()'))
        sw = (root / 'static/sw.js').read_text(encoding='utf-8')
        self.assertIn("const CACHE='nova-shell-335-r492'", sw)
        self.assertNotIn('registration.unregister', sw)

    def test_alert_defaults_off_and_does_not_change_selection(self):
        root = Path(__file__).resolve().parents[1]
        js = (root / 'static/max-profit-lab.js').read_text(encoding='utf-8')
        self.assertIn("master:false", js)
        self.assertIn("prefs.master&&prefs.stages", js)
        self.assertIn("탐색과 VERIFY 기록은 계속", js)
        self.assertIn("selection_status||'QUALIFIED')!=='QUALIFIED'", js)
        self.assertIn('DATA WAIT', js)
        self.assertIn('조건미달', js)

    def test_cutover_has_exact_container_rollback_and_protected_services(self):
        root = Path(__file__).resolve().parents[1]
        shell = (root / 'ops/NOVA_3.3.4_SAFE_CUTOVER_AUTO_ROLLBACK.sh').read_text(encoding='utf-8')
        self.assertIn('AUTO ROLLBACK -> EXACT PRE-CUTOVER CONTAINER', shell)
        self.assertIn('dc rename "$BACKUP" "$APP"', shell)
        self.assertIn('verify_protected', shell)
        self.assertIn("contract.get('new_ws_subscription_types')==0", shell)
        self.assertIn("contract.get('ws_registered_code_ceiling_increase')==0", shell)
        self.assertIn("contract.get('exploration_official_buy_blocked') is True", shell)
        self.assertIn('market_rotation_acceptance.py', shell)
        for forbidden in ('dc stop nova-http-guard', 'dc rm nova-http-guard', 'dc stop caddy', 'dc rm caddy'):
            self.assertNotIn(forbidden, shell)


if __name__ == '__main__':
    unittest.main()
