import time,unittest
from unittest.mock import patch
from app.domain import Origin,Venue
from app.runtime.state import RuntimeState
from app.runtime.display import DisplayState
from app.tracking.live import LiveTracker

class R48BoardIndependenceTests(unittest.TestCase):
    def mk(self,st,code,entry='DISCOVERY',sm=False,near=False,now=None):
        now=now or time.time();c=st.candidate(code,code,Origin.TODAY_NEW,'20260820');v=c.venue_state[Venue.NXT]
        v.last_price=10000;v.last_rate=1.2;v.last_tick_at=now;v.last_recv_seq=1;v.score=64;c.current_venue=Venue.NXT
        v.entry.state=entry
        v.metrics.update({'fresh':True,'buy_pressure':60 if near or sm else 53,'algo_persistence':58 if near else 45,'micro_vwap_gap':.2,'impulse_60s':.4,
                          'volume_accel':1.4,'volume_accel_ready':True,'buy_pressure_delta_30s':5 if sm else 0,
                          'smart_money_realtime_proxy_score':2.4 if sm else .2,'smart_money_acceleration':1.5 if sm else 1.0,
                          'smart_money_realtime_proxy_surge':bool(sm),'sell_to_buy_flip':bool(sm),'turnover_accel_ready':True,'turnover_accel_30s':1.6 if sm else 1.0})
        c.metrics.update({'discovery_first_seen_at':now-30,'discovery_rank_velocity_pos':8,'discovery_new_sources_60s':2,'discovery_source_count':3,'discovery_best_rank':10})
        c.refresh_aggregate();return c
    def test_prebuy_and_nxt_smart_have_distinct_contracts(self):
        now=time.time();st=RuntimeState()
        entry=self.mk(st,'111111','DIRECT_ARM',sm=False,near=True,now=now)
        flow=self.mk(st,'222222','DISCOVERY',sm=True,near=False,now=now)
        both=self.mk(st,'333333','PRESSURE_BUILD',sm=True,near=True,now=now)
        d=DisplayState(st,LiveTracker())
        with patch('app.runtime.display.sessions',return_value={'active':True,'krx':False,'nxt':True}),patch('app.runtime.display.lifecycle_phase',return_value='PREMARKET_RECHECK'):
            self.assertTrue(d.build())
        b=d.get()['boards'];pre=[r['code'] for r in b['prebuy']];nxt=[r['code'] for r in b['nxt_early']]
        self.assertIn('111111',pre);self.assertNotIn('111111',nxt)
        self.assertIn('222222',nxt);self.assertNotIn('222222',pre)
        self.assertIn('333333',pre);self.assertIn('333333',nxt)
        self.assertNotEqual(pre,nxt)
        self.assertTrue(all(r.get('rank_basis')=='ENTRY_PROXIMITY' for r in b['prebuy']))
        self.assertTrue(all(r.get('rank_basis')=='NXT_SMART_FLOW' for r in b['nxt_early']))
    def test_no_forced_fill(self):
        now=time.time();st=RuntimeState();self.mk(st,'111111','DIRECT_ARM',False,True,now);self.mk(st,'222222','DISCOVERY',True,False,now)
        d=DisplayState(st,LiveTracker())
        with patch('app.runtime.display.sessions',return_value={'active':True,'krx':False,'nxt':True}),patch('app.runtime.display.lifecycle_phase',return_value='PREMARKET_RECHECK'):
            d.build()
        self.assertLessEqual(len(d.get()['boards']['prebuy']),1);self.assertLessEqual(len(d.get()['boards']['nxt_early']),1)
