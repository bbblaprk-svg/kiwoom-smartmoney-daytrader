import time, unittest
from app.addons.market_relative import market_overlay
from app.broker.market_index import MarketIndexMonitor
from app.domain import Venue
from app.runtime.state import RuntimeState

class R493MarketRelativeTest(unittest.TestCase):
    def _candidate(self, st, code='123456', rate=1.0, market='001'):
        c=st.candidate(code,'X',trade_day='20260822');c.current_venue=Venue.KRX;c.metrics['market_code']=market
        v=c.venue_state[Venue.KRX];v.last_price=10000;v.last_rate=rate;v.last_tick_at=time.time();v.metrics['fresh']=True
        return c
    def test_parse_index_and_regime(self):
        now=time.time();x=MarketIndexMonitor._parse('KOSPI','001',{'cur_prc':'2800.12','flu_rt':'-1.20','upl':'4','rising':'300','stdns':'100','fall':'500','lst':'6'},now)
        self.assertEqual(x['regime'],'RISK_OFF');self.assertLess(x['breadth'],0);self.assertEqual(x['change_rate'],-1.2)
        self.assertEqual(x['breadth_total'],910);self.assertEqual(x['upper'],4);self.assertEqual(x['lower'],6)

    def test_official_ka20001_response_shape_without_nonexistent_listed_field(self):
        now=time.time()
        payload={'cur_prc':'-2394.49','flu_rt':'-10.42','upl':'0','rising':'17','stdns':'183','fall':'130','lst':'3'}
        x=MarketIndexMonitor._parse('KOSPI','001',payload,now)
        self.assertEqual(x['change_rate'],-10.42)
        self.assertEqual(x['breadth_total'],333)
        self.assertAlmostEqual(x['breadth'],round((17-133)/333*100,2),places=2)
        self.assertEqual(x['regime'],'PANIC')
    def test_resilient_stock_gets_positive_overlay(self):
        st=RuntimeState();now=time.time();c=self._candidate(st,rate=0.2,market='001')
        st.market_context['KOSPI']={'ok':True,'change_rate':-1.5,'breadth':-35,'regime':'RISK_OFF','updated_at':now,'source':'TEST'}
        o=market_overlay(st,c,now,5.0)
        self.assertTrue(o['market_available']);self.assertTrue(o['market_resilient']);self.assertGreater(o['market_adjustment'],0);self.assertAlmostEqual(o['market_relative_rate'],1.7,places=2)
    def test_stale_context_fails_open_zero(self):
        st=RuntimeState();now=time.time();c=self._candidate(st,rate=2.0,market='101')
        st.market_context['KOSDAQ']={'ok':True,'change_rate':-2,'breadth':-50,'regime':'PANIC','updated_at':now-999,'source':'TEST'}
        o=market_overlay(st,c,now,5.0)
        self.assertFalse(o['market_available']);self.assertEqual(o['market_adjustment'],0.0)

if __name__=='__main__':unittest.main()
