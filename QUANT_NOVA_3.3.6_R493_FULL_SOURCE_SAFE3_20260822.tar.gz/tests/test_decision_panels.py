import time, unittest
from unittest.mock import patch
from app.domain import Venue, Origin
from app.runtime.state import RuntimeState
from app.addons.decision_panels import DecisionPanelEngine, _entry_plan, _accel_label, _accel_metrics, _largecap_row, _pre_row, _signal_windows
from app.signal.early_edge import early_edge, discovery_scout_score


def seeded_state(ref=None):
    st=RuntimeState();c=st.candidate('005930','삼성전자',Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
    now=ref or time.time();v.last_price=100000;v.last_rate=2.0;v.last_tick_at=now-1
    v.score=85;v.confidence=72
    v.metrics.update({'fresh':True,'buy_pressure':62,'volume_accel':1.6,'volume_accel_ready':True,'session_vwap':99500,'session_vwap_gap':.5,'micro_vwap_gap':.3,'smart_money_realtime_proxy_score':4,'smart_money_realtime_proxy_surge':True})
    c.current_venue=Venue.NXT;c.refresh_aggregate()
    return st,c,v


class DecisionPanelsTest(unittest.TestCase):
    def test_entry_plan_order(self):
        p=_entry_plan(100000,{'session_vwap':99500,'session_vwap_gap':.50})
        self.assertLessEqual(p['entry_low'],p['entry_high']);self.assertLess(p['stop'],p['entry_low']);self.assertGreater(p['t1'],p['entry_high']);self.assertGreater(p['t2'],p['t1'])

    def test_accel_labels(self):
        self.assertEqual(_accel_label(2,3),'↑↑');self.assertEqual(_accel_label(1,1),'↑');self.assertEqual(_accel_label(0,2),'↓');self.assertEqual(_accel_label(0,0),'→')

    def test_build_is_read_only(self):
        st,c,v=seeded_state();before=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));j=DecisionPanelEngine(st,0).build();after=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));self.assertEqual(before,after);self.assertTrue(j['contracts']['official_buy_logic_changed'] is False);self.assertEqual(j['contracts']['new_broker_rest_calls'],2);self.assertEqual(j['contracts']['new_ws_subscriptions'],0)

    def test_close_window_counts_are_relative_to_close_reference(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-2400)
        n10,n30,last=_signal_windows(c,ref)
        self.assertEqual((n10,n30),(1,2));self.assertEqual(last,ref-120)

    def test_closed_rows_keep_actionable_close_decision(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref);v.last_tick_at=ref-20;v.metrics['fresh']=False
        c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        lr=_largecap_row(c,ref+600,False,{'005930':'삼성전자'},reference_at=ref)
        pr=_pre_row(c,ref+600,False,reference_at=ref)
        self.assertIn(lr['decision'],('NOW','WAIT','AVOID'));self.assertNotEqual(lr['decision'],'CLOSED');self.assertEqual(lr['decision_mode'],'CLOSE');self.assertGreater(lr['score'],39)
        if lr['decision'] in ('NOW','WAIT'):
            self.assertIsNotNone(lr['entry_low']);self.assertIsNotNone(lr['chase_limit']);self.assertIsNotNone(lr['stop'])
        self.assertIn(pr['state'],('관찰','진입대상','COOLING'));self.assertNotEqual(pr['state'],'CLOSED');self.assertEqual(pr['window_mode'],'CLOSE');self.assertEqual((pr['signal_10m'],pr['signal_30m']),(1,2))

    def test_engine_freezes_last_live_snapshot_on_session_close(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-120);c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-900)
        eng=DecisionPanelEngine(st,0)
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref):
            live=eng.build()
        with patch('app.addons.decision_panels.sessions',return_value={'active':False}), patch('app.addons.decision_panels.time.time',return_value=ref+10):
            closed=eng.build()
        self.assertEqual(closed['freeze_source'],'LAST_LIVE');self.assertFalse(closed['market_active'])
        self.assertEqual(closed['largecap'][0]['score'],live['largecap'][0]['score']);self.assertEqual(closed['largecap'][0]['decision_mode'],'CLOSE')
        self.assertEqual(closed['preignition'][0]['signal_10m'],live['preignition'][0]['signal_10m']);self.assertEqual(closed['preignition'][0]['signal_30m'],live['preignition'][0]['signal_30m']);self.assertEqual(closed['preignition'][0]['window_mode'],'CLOSE')


    def test_largecap_closed_restart_never_reconstructs_data_wait_rows(self):
        ref=2_000_000_000.0;st=RuntimeState()
        # Persisted candidates exist, but this engine instance has never observed a LIVE large-cap board.
        for code in ('005930','000660','005380'):
            c=st.candidate(code,code,Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
            v.last_price=100000;v.last_rate=1.0;v.last_tick_at=ref-3600;v.score=75;v.confidence=60
            v.metrics.update({'fresh':False,'buy_pressure':55,'volume_accel':1.2,'volume_accel_ready':True,'session_vwap_gap':.1})
            c.current_venue=Venue.NXT;c.refresh_aggregate()
        eng=DecisionPanelEngine(st,0)
        with patch('app.addons.decision_panels.sessions',return_value={'active':False}), patch('app.addons.decision_panels.time.time',return_value=ref):
            j=eng.build()
        self.assertEqual(j['largecap'],[])
        self.assertEqual(j['largecap_freeze_source'],'NO_LIVE_SNAPSHOT')
        self.assertEqual(j['contracts']['largecap_close_policy'],'LAST_LIVE_ONLY_NO_RECONSTRUCTION_NO_DATA_WAIT')
        self.assertFalse(any(r.get('decision')=='DATA_WAIT' for r in j['largecap']))

    def test_largecap_close_keeps_last_nonempty_live_snapshot_through_transient_gap(self):
        ref=2_000_000_000.0;st,c,v=seeded_state(ref);eng=DecisionPanelEngine(st,0)
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref):
            live=eng.build()
        self.assertTrue(live['largecap'])
        # A transient active-session gap must not erase the last verified LIVE board.
        v.last_tick_at=ref-999;v.metrics['fresh']=False;eng._cache=None
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref+30):
            gap=eng.build()
        self.assertEqual(gap['largecap'],[])
        eng._cache=None
        with patch('app.addons.decision_panels.sessions',return_value={'active':False}), patch('app.addons.decision_panels.time.time',return_value=ref+60):
            closed=eng.build()
        self.assertEqual(len(closed['largecap']),1)
        self.assertEqual(closed['largecap_freeze_source'],'LAST_LIVE')
        self.assertNotEqual(closed['largecap'][0]['decision'],'DATA_WAIT')

    def test_pre_acceleration_deweights_old_repeat_and_rewards_recent_cadence(self):
        ref=2_000_000_000.0;st=RuntimeState()
        old=st.candidate('111111','누적강자',Origin.TODAY_NEW,'20260814');ov=old.venue_state[Venue.NXT]
        new=st.candidate('222222','신규가속',Origin.TODAY_NEW,'20260814');nv=new.venue_state[Venue.NXT]
        for c,v in ((old,ov),(new,nv)):
            v.last_price=100000;v.last_rate=2.0;v.last_tick_at=ref-1;v.score=72;v.confidence=60
            v.metrics.update({'fresh':True,'buy_pressure':62,'volume_accel':1.8,'volume_accel_ready':True,'micro_vwap_gap':.2,'smart_money_realtime_proxy_score':2})
            c.current_venue=Venue.NXT
        ov.entry.valid_repeat_count=80;old.refresh_aggregate()
        nv.entry.valid_repeat_count=3;new.refresh_aggregate()
        # Old winner: 10 signals in the earlier 20m but none in the latest 10m.
        for age in (700,800,900,1000,1100,1200,1300,1400,1500,1600):old.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-age)
        # Challenger: latest cadence is materially stronger than the preceding 20m.
        for age in (60,180,300,900):new.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-age)
        ro=_pre_row(old,ref,True);rn=_pre_row(new,ref,True)
        self.assertLess(ro['accel_delta'],0);self.assertGreater(rn['accel_delta'],0)
        self.assertEqual(ro['accel'],'↓');self.assertEqual(rn['accel'],'↑↑')
        self.assertGreater(rn['score'],ro['score'])
        self.assertIn(ro['state'],('관찰','COOLING'));self.assertNotEqual(ro['state'],'진입대상')

    def test_r49_pre_board_allows_partial_rows_and_exposes_top20_contract(self):
        ref=2_000_000_000.0;st=RuntimeState()
        # Only four candidates have fresh formal acceleration.  R49 must show four, not force-fill 20.
        for i in range(4):
            code=f'20{i:04d}';c=st.candidate(code,'가속'+str(i+1),Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
            v.last_price=50000+i*100;v.last_rate=1;v.last_tick_at=ref-1;v.score=60-i;v.confidence=55
            v.metrics.update({'fresh':True,'buy_pressure':61,'buy_pressure_delta_30s':8,'volume_accel':1.9,'volume_accel_ready':True,'turnover_accel_30s':2.2,'turnover_accel_ready':True,'compression':.8,'micro_vwap_gap':.1,'session_vwap_gap':.1,'impulse_60s':.35,'smart_money_realtime_proxy_score':2,'smart_money_acceleration':1.8})
            c.metrics.update({'discovery_first_seen_at':ref-240,'discovery_rank_velocity_pos':12,'discovery_new_sources_60s':1,'discovery_source_count':4,'discovery_best_rank':12})
            c.current_venue=Venue.NXT;c.refresh_aggregate()
            for age in (60,160,260,850):c.append_history('SIGNAL','READY',venue=Venue.NXT,at=ref-age)
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref):
            j=DecisionPanelEngine(st,0).build()
        self.assertEqual(len(j['preignition']),4)
        self.assertTrue(all(r.get('rank_basis')=='SIGNAL_ACCELERATION_5_15_30_PLUS_LIVE_EVIDENCE' for r in j['preignition']))
        self.assertEqual(j['contracts']['pre_signal_slots'],20)
        self.assertEqual(j['contracts']['pre_rank_commit_sec'],30.0)
        self.assertEqual(j['contracts']['pre_min_dwell_sec'],60.0)
        self.assertEqual(j['contracts']['pre_newcomer_gap'],3.0)
        self.assertFalse(j['contracts']['pre_official_buy_changed'])

    def test_r4_early_edge_prefers_pre_breakout_over_already_extended(self):
        ref=2_000_000_000.0;st=RuntimeState()
        early=st.candidate('311111','급등전',Origin.TODAY_NEW,'20260814');late=st.candidate('322222','이미급등',Origin.TODAY_NEW,'20260814')
        for c,rate in ((early,1.8),(late,10.5)):
            v=c.venue_state[Venue.NXT];v.last_price=100000;v.last_rate=rate;v.last_tick_at=ref-1
            v.metrics.update({'fresh':True,'buy_pressure':64,'buy_pressure_delta_30s':10,'volume_accel':1.8,'volume_accel_ready':True,'turnover_accel_30s':2.1,'turnover_accel_ready':True,'compression':.78,'session_vwap_gap':.25,'micro_vwap_gap':.20,'impulse_60s':.45,'smart_money_realtime_proxy_score':3,'smart_money_acceleration':1.7,'sell_to_buy_flip':True})
            c.metrics.update({'discovery_first_seen_at':ref-35,'discovery_rank_velocity_pos':10,'discovery_new_sources_60s':2,'discovery_source_count':4,'discovery_best_rank':9})
            c.current_venue=Venue.NXT;c.refresh_aggregate()
        e1=early_edge(early,Venue.NXT,ref);e2=early_edge(late,Venue.NXT,ref)
        self.assertGreater(e1['score'],e2['score']);self.assertGreaterEqual(e1['headroom_score'],14)
        self.assertTrue(e2['chase_block']);self.assertLessEqual(e2['score'],45)

    def test_r4_discovery_scout_rewards_rank_climb_and_new_table_join(self):
        ref=2_000_000_000.0;st=RuntimeState();a=st.candidate('333331','신규상승');b=st.candidate('333332','기존정체')
        a.metrics.update({'discovery_first_seen_at':ref-30,'discovery_rank_velocity_pos':15,'discovery_new_sources_60s':3,'discovery_source_count':4,'discovery_best_rank':8})
        b.metrics.update({'discovery_first_seen_at':ref-500,'discovery_rank_velocity_pos':0,'discovery_new_sources_60s':0,'discovery_source_count':4,'discovery_best_rank':8})
        self.assertGreater(discovery_scout_score(a,ref),discovery_scout_score(b,ref)+30)

    def test_largecap_live_session_shows_only_fresh_core_rows_without_backfill(self):
        ref=time.time();st=RuntimeState()
        core_codes=['005930','000660','005380','012330','017670','034020','066570','068270']
        for i,code in enumerate(core_codes):
            c=st.candidate(code,code,Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
            v.last_price=100000+i*1000;v.last_rate=1.0;v.last_tick_at=ref-1;v.score=70;v.confidence=60
            v.metrics.update({'fresh':True,'buy_pressure':60,'volume_accel':1.4,'volume_accel_ready':True,'session_vwap_gap':.2})
            c.current_venue=Venue.NXT;c.refresh_aggregate()
        # Make one operator large-cap stale: it must disappear, not become DATA_WAIT.
        st.candidates[core_codes[-1]].venue_state[Venue.NXT].last_tick_at=ref-60
        # Non-large-cap rows must not backfill a live large-cap board.
        for i,code in enumerate(['111111','222222','333333']):
            c=st.candidate(code,'시장보완'+str(i+1),Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT]
            v.last_price=50000+i*1000;v.last_rate=.5;v.last_tick_at=ref-1;v.score=80-i;v.confidence=65
            v.metrics.update({'fresh':True,'buy_pressure':63,'volume_accel':1.7,'volume_accel_ready':True,'session_vwap_gap':.1})
            c.current_venue=Venue.NXT;c.refresh_aggregate()
        with patch('app.addons.decision_panels.sessions',return_value={'active':True}), patch('app.addons.decision_panels.time.time',return_value=ref):
            j=DecisionPanelEngine(st,0).build()
        self.assertEqual(len(j['largecap']),7)
        self.assertTrue(all(r.get('coverage_status')=='CORE' for r in j['largecap']))
        self.assertTrue(all(r.get('fresh') and r.get('price') is not None and r.get('decision')!='DATA_WAIT' for r in j['largecap']))
        self.assertTrue(j['contracts']['largecap_live_only'])
        self.assertTrue(j['contracts']['largecap_allow_partial_rows'])

    def test_ipad_layout_keeps_full_width_tables_and_six_board_columns(self):
        from pathlib import Path
        root=Path(__file__).resolve().parents[1]
        nova=(root/'static/nova.css').read_text(encoding='utf-8')
        decision=(root/'static/decision-panels.css').read_text(encoding='utf-8')
        lab=(root/'static/max-profit-lab.css').read_text(encoding='utf-8')
        self.assertIn('@media(min-width:700px) and (max-width:1199px)',nova)
        self.assertIn('grid-template-columns:30px minmax(190px,2fr) 112px 78px 78px minmax(122px,1.15fr)',nova)
        self.assertIn('@media(min-width:700px) and (max-width:1199px)',decision)
        self.assertIn('.candidate-table,.stats-table{min-width:740px;table-layout:fixed}',lab)

    def test_mobile_panel_headers_allocate_layout_height(self):
        from pathlib import Path
        root=Path(__file__).resolve().parents[1]
        css=(root/'static/decision-panels.css').read_text(encoding='utf-8')
        bridge=(root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
        self.assertIn('.decision-panel h2{height:auto;min-height:34px',css)
        self.assertIn('#opening_bridge_panel h2{height:auto;min-height:34px',bridge)

    def test_r45_largecap_closed_ui_never_labels_data_wait_reconstruction(self):
        from pathlib import Path
        js=(Path(__file__).resolve().parents[1]/'static/decision-panels.js').read_text(encoding='utf-8')
        self.assertIn('오늘 LIVE 확인 대형주 없음',js)
        self.assertIn('장마감 DATA WAIT 재구성 안함',js)
        self.assertIn('LAST LIVE ${shown}/10 · DATA WAIT 0',js)

if __name__=='__main__':unittest.main()
