import hashlib
import time
import unittest
from pathlib import Path

from app.addons.decision_panels import DecisionPanelEngine
from app.addons.signal_acceleration import pre_row, signal_windows_5_15_30
from app.domain import Origin, Venue
from app.runtime.state import RuntimeState


REF = 2_000_000_000.0


def candidate(st, code, *, rate=1.5, fresh_seen_age=240, bp=64, bp_delta=8,
              sm=True, vol=1.8, turn=1.6, rank_vel=6):
    c = st.candidate(code, code, Origin.TODAY_NEW, '20260820')
    v = c.venue_state[Venue.NXT]
    v.last_price = 100000
    v.last_rate = rate
    v.last_tick_at = REF - 1
    v.score = 70
    v.confidence = 65
    v.metrics.update({
        'fresh': True,
        'buy_pressure': bp,
        'buy_pressure_delta_30s': bp_delta,
        'volume_accel': vol,
        'volume_accel_ready': True,
        'turnover_accel_30s': turn,
        'turnover_accel_ready': True,
        'micro_vwap_gap': .2,
        'session_vwap_gap': .2,
        'smart_money_realtime_proxy_score': 5 if sm else 0,
        'smart_money_realtime_proxy_surge': bool(sm),
        'smart_money_acceleration': 1.4 if sm else 1.0,
        'sell_to_buy_flip': bool(sm),
        'compression': .7,
        'impulse_60s': .3,
    })
    c.metrics.update({
        'discovery_first_seen_at': REF - fresh_seen_age,
        'discovery_rank_velocity_pos': rank_vel,
        'discovery_new_sources_60s': 1,
        'discovery_source_count': 3,
        'discovery_best_rank': 15,
        'sector_score': 4,
    })
    c.current_venue = Venue.NXT
    c.refresh_aggregate()
    return c


def add_signals(c, ages):
    for age in ages:
        c.append_history('SIGNAL', 'READY', venue=Venue.NXT, at=REF-age)


class R49SignalAccelerationTests(unittest.TestCase):
    def test_5_15_30_windows_count_formal_signals_only(self):
        st = RuntimeState(); c = candidate(st, '111111')
        add_signals(c, (60, 240, 600, 1200, 1700, 1900))
        c.append_history('TOP10_REENTER', 'READY', venue=Venue.NXT, at=REF-30)
        w = signal_windows_5_15_30(c, REF)
        self.assertEqual((w['n5'], w['n15'], w['n30']), (2, 3, 5))
        self.assertEqual(w['last'], REF-60)

    def test_recent_acceleration_beats_old_lifetime_repeat(self):
        st = RuntimeState()
        old = candidate(st, '111111', sm=False, bp_delta=0, rank_vel=0)
        new = candidate(st, '222222')
        old.venue_state[Venue.NXT].entry.valid_repeat_count = 80
        new.venue_state[Venue.NXT].entry.valid_repeat_count = 3
        old.refresh_aggregate(); new.refresh_aggregate()
        add_signals(old, (700,800,900,1000,1100,1200,1300,1400,1500,1600))
        add_signals(new, (30,90,180,500,800))
        ro = pre_row(old, REF, True); rn = pre_row(new, REF, True)
        self.assertIsNotNone(ro); self.assertIsNotNone(rn)
        self.assertGreater(rn['rank_score'], ro['rank_score'])
        self.assertGreater(rn['accel_5m'], ro['accel_5m'])
        self.assertEqual(ro['repeat_total'], 80)

    def test_stale_pinned_symbol_is_excluded_after_15m_without_fast_scout(self):
        st = RuntimeState(); c = candidate(st, '333333', fresh_seen_age=1000, rank_vel=0, sm=False, bp_delta=0, vol=1.0, turn=1.0, bp=52)
        c.live_track_pin = True
        add_signals(c, (1000, 1200))  # formal signals exist in 30m, but none in 15m
        self.assertIsNone(pre_row(c, REF, True))

    def test_fast_scout_with_two_live_evidence_types_can_enter_without_formal_signal(self):
        st = RuntimeState(); c = candidate(st, '444444', fresh_seen_age=30, bp_delta=8, sm=True)
        # best-rank <=20 + age <= FAST SCOUT window; live evidence supplies >=2 types.
        r = pre_row(c, REF, True)
        self.assertIsNotNone(r)
        self.assertEqual(r['signal_30m'], 0)
        self.assertTrue(r['fast_scout'])
        self.assertGreaterEqual(r['signal_type_count'], 2)
        self.assertEqual(r['rank_lane'], 'FRESH')

    def test_entry_target_is_display_only_and_does_not_require_entry_v18_state(self):
        st = RuntimeState(); c = candidate(st, '555555')
        self.assertEqual(c.entry_state, 'DISCOVERY')
        add_signals(c, (30,90,180,500,800))
        before = c.entry_state
        r = pre_row(c, REF, True)
        self.assertEqual(r['state'], '진입대상')
        self.assertGreaterEqual(r['entry_candidate_checks'], 4)
        self.assertEqual(c.entry_state, before)
        self.assertNotEqual(c.entry_state, 'BUY')

    def test_overheated_symbol_is_cooling_not_entry_target(self):
        st = RuntimeState(); c = candidate(st, '666666', rate=8.2)
        add_signals(c, (30,90,180,500,800))
        r = pre_row(c, REF, True)
        self.assertEqual(r['state'], 'COOLING')
        self.assertLessEqual(r['rank_score'], 42.0)

    def test_rank_membership_commits_every_30s_with_60s_dwell_and_plus3_gap(self):
        eng = DecisionPanelEngine(RuntimeState(), 0)
        initial = [{'code': f'{i:06d}', 'rank_score': 100-i, 'score': 100-i, 'state':'관찰', 'accel_5m':0, 'last_signal_at':REF}
                   for i in range(1, 21)]
        out0 = eng._stabilize_signal_accel(initial, REF)
        self.assertEqual([x['code'] for x in out0], [x['code'] for x in initial])

        # A much stronger newcomer appears at +10s: full board is held until rank commit.
        newcomer = {'code':'999999','rank_score':120,'score':120,'state':'진입대상','accel_5m':5,'last_signal_at':REF+10}
        ranked = [newcomer] + initial
        out10 = eng._stabilize_signal_accel(ranked, REF+10)
        self.assertNotIn('999999', [x['code'] for x in out10])

        # At the first 30s boundary, members are still inside the 60s minimum dwell.
        out31 = eng._stabilize_signal_accel(ranked, REF+31)
        self.assertNotIn('999999', [x['code'] for x in out31])

        # At +61s, dwell and 30s commit are both satisfied, so +3pt challenger can replace.
        out61 = eng._stabilize_signal_accel(ranked, REF+61)
        self.assertIn('999999', [x['code'] for x in out61])
        self.assertEqual(len(out61), 20)

    def test_newcomer_below_plus3_gap_does_not_replace(self):
        eng = DecisionPanelEngine(RuntimeState(), 0)
        initial = [{'code': f'{i:06d}', 'rank_score': 100-i, 'score': 100-i, 'state':'관찰', 'accel_5m':0, 'last_signal_at':REF}
                   for i in range(1, 21)]
        eng._stabilize_signal_accel(initial, REF)
        weak = min(x['rank_score'] for x in initial)  # 80
        newcomer = {'code':'999998','rank_score':weak+2.9,'score':weak+2.9,'state':'관찰','accel_5m':1,'last_signal_at':REF+61}
        out = eng._stabilize_signal_accel([newcomer]+initial, REF+61)
        self.assertNotIn('999998', [x['code'] for x in out])


    def test_strong_live_evidence_can_be_entry_target_after_fast_scout_without_formal_signal(self):
        st = RuntimeState(); c = candidate(st, '777771', fresh_seen_age=240, bp=64, bp_delta=7, sm=True, vol=1.8, turn=1.6, rank_vel=8)
        r = pre_row(c, REF, True)
        self.assertIsNotNone(r)
        self.assertEqual(r['signal_30m'], 0)
        self.assertFalse(r['fast_scout'])
        self.assertTrue(r['live_evidence_lane'])
        self.assertTrue(r['live_evidence_strong'])
        self.assertGreaterEqual(r['live_evidence_count'], 4)
        self.assertEqual(r['state'], '진입대상')
        self.assertEqual(c.entry_state, 'DISCOVERY')

    def test_weak_live_evidence_does_not_extend_preformal_lane(self):
        st = RuntimeState(); c = candidate(st, '777772', fresh_seen_age=240, bp=53, bp_delta=1, sm=False, vol=1.1, turn=1.05, rank_vel=1)
        self.assertIsNone(pre_row(c, REF, True))

    def test_stale_pin_can_requalify_only_with_current_strong_live_evidence(self):
        st = RuntimeState(); c = candidate(st, '777773', fresh_seen_age=1200, bp=64, bp_delta=7, sm=True, vol=1.8, turn=1.6, rank_vel=8)
        c.live_track_pin = True
        add_signals(c, (1000, 1200))
        r = pre_row(c, REF, True)
        self.assertIsNotNone(r)
        self.assertTrue(r['live_evidence_lane'])
        self.assertEqual(r['rank_lane'], 'LIVE_EVIDENCE')

    def test_live_evidence_episode_expires_after_10m(self):
        eng = DecisionPanelEngine(RuntimeState(), 0)
        row = {'code':'777774','live_evidence_lane':True,'rank_score':80,'score':80,'state':'진입대상'}
        out,stats = eng._apply_live_evidence_episode([dict(row)], REF)
        self.assertEqual(len(out),1); self.assertEqual(stats['live_evidence_expired_10m'],0)
        for dt in range(30, 601, 30):
            out,stats = eng._apply_live_evidence_episode([dict(row)], REF+dt)
        self.assertEqual(len(out),1)
        out,stats = eng._apply_live_evidence_episode([dict(row)], REF+601)
        self.assertEqual(out,[]); self.assertEqual(stats['live_evidence_expired_10m'],1)

    def test_live_evidence_episode_rearms_after_60s_gap(self):
        eng = DecisionPanelEngine(RuntimeState(), 0)
        row = {'code':'777775','live_evidence_lane':True,'rank_score':80,'score':80,'state':'관찰'}
        eng._apply_live_evidence_episode([dict(row)], REF)
        eng._apply_live_evidence_episode([dict(row)], REF+601)
        # no current live row for > reset sec -> episode state is cleared
        eng._apply_live_evidence_episode([], REF+662)
        out,stats = eng._apply_live_evidence_episode([dict(row)], REF+663)
        self.assertEqual(len(out),1); self.assertEqual(out[0]['live_evidence_episode_age_sec'],0.0)

    def test_recent_formal_signal_bypasses_live_episode_expiry(self):
        st = RuntimeState(); c = candidate(st, '777776', fresh_seen_age=1200, bp=64, bp_delta=7, sm=True, vol=1.8, turn=1.6, rank_vel=8)
        eng = DecisionPanelEngine(st, 0)
        r = pre_row(c, REF, True); self.assertTrue(r['live_evidence_lane'])
        eng._apply_live_evidence_episode([r], REF)
        eng._apply_live_evidence_episode([dict(r)], REF+601)
        c.append_history('SIGNAL','PRESSURE',venue=Venue.NXT,at=REF+602)
        c.current().last_tick_at=REF+602
        r2 = pre_row(c, REF+603, True)
        self.assertIsNotNone(r2); self.assertTrue(r2['formal_recent']); self.assertFalse(r2['live_evidence_lane'])
        out,stats = eng._apply_live_evidence_episode([r2], REF+603)
        self.assertEqual(len(out),1); self.assertEqual(stats['live_evidence_expired_10m'],0)

    def test_official_entry_policy_and_guard_bytes_are_unchanged(self):
        root = Path(__file__).resolve().parents[1]
        self.assertEqual(hashlib.sha256((root/'app/signal/policy.py').read_bytes()).hexdigest(),
                         '18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a')
        self.assertEqual(hashlib.sha256((root/'ops/http_guard_v2.py').read_bytes()).hexdigest(),
                         'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b')


if __name__ == '__main__':
    unittest.main()
