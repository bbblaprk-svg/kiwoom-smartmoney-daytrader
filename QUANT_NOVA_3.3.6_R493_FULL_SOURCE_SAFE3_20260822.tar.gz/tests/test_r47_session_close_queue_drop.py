import asyncio,time,unittest
from unittest.mock import patch
from app.domain import Origin,Venue
from app.runtime.state import RuntimeState
from app.signal.coordinator import SignalCoordinator

class _NoCommitJournal:
    def commit(self,*a,**k):
        raise AssertionError('CLOSED late score must not reach WAL')

class R47SessionCloseQueueDropTests(unittest.IsolatedAsyncioTestCase):
    def _seed(self,venue=Venue.NXT):
        st=RuntimeState();st.restore_done=True
        c=st.candidate('005930','삼성전자',Origin.TODAY_NEW,'20260819');v=c.venue_state[venue]
        now=time.time();v.last_price=100000;v.last_rate=2.0;v.last_tick_at=now;v.last_recv_seq=9;v.stage='IGNITION';v.score=88;v.confidence=90
        v.entry.state='PRESSURE_BUILD';v.entry.valid_repeat_count=3;c.current_venue=venue;c.raw_repeat_count=4;c.refresh_aggregate()
        return st,c,v

    async def test_closed_late_queue_job_is_total_noop_except_telemetry(self):
        st,c,v=self._seed();co=SignalCoordinator(st,_NoCommitJournal())
        before=(v.stage,v.score,v.entry.state,c.valid_repeat_count,c.raw_repeat_count,len(c.history),c.last_buy_at,c.entry_state)
        with patch('app.signal.coordinator.sessions',return_value={'active':False,'krx':False,'nxt':False}):
            for _ in range(100):
                await co.score_one(c.code,Venue.NXT,0,9)
        after=(v.stage,v.score,v.entry.state,c.valid_repeat_count,c.raw_repeat_count,len(c.history),c.last_buy_at,c.entry_state)
        self.assertEqual(after,before)
        self.assertEqual(int(st.telemetry.get('closed_score_drop_count') or 0),100)

    async def test_venue_specific_close_drops_only_closed_venue(self):
        st,c,v=self._seed(Venue.KRX);co=SignalCoordinator(st,_NoCommitJournal())
        before=(v.stage,v.score,v.entry.state,len(c.history))
        with patch('app.signal.coordinator.sessions',return_value={'active':True,'krx':False,'nxt':True}):
            await co.score_one(c.code,Venue.KRX,0,9)
        self.assertEqual((v.stage,v.score,v.entry.state,len(c.history)),before)
        self.assertEqual(int(st.telemetry.get('closed_score_drop_count') or 0),1)

if __name__=='__main__':unittest.main()
