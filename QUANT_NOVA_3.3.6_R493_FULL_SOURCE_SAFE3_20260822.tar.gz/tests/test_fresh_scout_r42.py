from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app.addons.max_profit_lab import MaxProfitLab
from app.config import SETTINGS
from app.domain import Origin, Venue
from app.runtime.display import DisplayState
from app.runtime.state import RuntimeState
from app.signal.early_edge import discovery_freshness, discovery_scout_score, early_edge
from app.tracking.live import LiveTracker


class FreshScoutR42Tests(unittest.TestCase):
    def candidate(self, state: RuntimeState, code: str, now: float, age: float, score: float, best_rank: int = 30, new_sources: int = 1):
        c = state.candidate(code, code, Origin.TODAY_NEW, '20260818')
        v = c.venue_state[Venue.NXT]
        v.last_price = 100000
        v.last_rate = 1.5
        v.last_tick_at = now - 0.5
        v.score = score
        v.metrics.update({
            'fresh': True,
            'buy_pressure': 63,
            'buy_pressure_delta_30s': 8,
            'volume_accel': 1.7,
            'volume_accel_ready': True,
            'turnover_accel_30s': 1.8,
            'turnover_accel_ready': True,
            'compression': .72,
            'session_vwap_gap': .2,
            'micro_vwap_gap': .15,
            'impulse_60s': .35,
            'smart_money_realtime_proxy_score': 2,
            'smart_money_acceleration': 1.5,
        })
        c.metrics.update({
            'discovery_first_seen_at': now - age,
            'discovery_rank_velocity_pos': 0,
            'discovery_new_sources_60s': new_sources,
            'discovery_source_count': max(1, new_sources),
            'discovery_best_rank': best_rank,
            'test_rank': score,
        })
        c.current_venue = Venue.NXT
        c.refresh_aggregate()
        return c

    def test_first_capture_top20_gets_fast_track_without_rank_velocity(self):
        now = 2_000_000_000.0
        st = RuntimeState()
        c = self.candidate(st, '410001', now, 1, 50, best_rank=14, new_sources=1)
        meta = discovery_freshness(c, now)
        self.assertEqual(meta['rank_velocity'], 0)
        self.assertTrue(meta['fast_track'])
        self.assertTrue(meta['fresh_window'])
        self.assertGreater(discovery_scout_score(c, now), 15)

    def test_first_capture_multi_rank_join_gets_fast_track_outside_top20(self):
        now = 2_000_000_000.0
        st = RuntimeState()
        c = self.candidate(st, '410002', now, 1, 50, best_rank=35, new_sources=2)
        self.assertTrue(discovery_freshness(c, now)['fast_track'])

    def test_freshness_is_strong_for_90s_then_decays_after_3m(self):
        now = 2_000_000_000.0
        st = RuntimeState()
        fast = self.candidate(st, '410003', now, 60, 50, best_rank=15, new_sources=2)
        old = self.candidate(st, '410004', now, 240, 50, best_rank=15, new_sources=0)
        ef = early_edge(fast, Venue.NXT, now)
        eo = early_edge(old, Venue.NXT, now)
        self.assertGreaterEqual(ef['freshness_score'], 13)
        self.assertLessEqual(eo['freshness_score'], 3)
        self.assertGreater(ef['score'], eo['score'])

    def test_membership_is_anchor6_fresh4(self):
        now = 2_000_000_000.0
        st = RuntimeState(); d = DisplayState(st, LiveTracker())
        ranked = []
        for i in range(8):
            ranked.append(self.candidate(st, f'42{i:04d}', now, 600, 95-i))
        for i in range(6):
            ranked.append(self.candidate(st, f'43{i:04d}', now, 30+i, 80-i, best_rank=10+i, new_sources=2))
        ranked.sort(key=lambda c: c.metrics['test_rank'], reverse=True)
        out = d._compose_anchor_fresh(ranked, now, lambda c: c.metrics['test_rank'])
        fresh = [c for c in out if discovery_freshness(c, now)['fresh_window']]
        anchors = [c for c in out if not discovery_freshness(c, now)['fresh_window']]
        self.assertEqual(len(out), 10)
        self.assertEqual(len(anchors), SETTINGS.discovery_anchor_slots)
        self.assertEqual(len(fresh), SETTINGS.discovery_fresh_slots)

    def test_hysteresis_holds_position_but_live_values_continue_changing(self):
        now = 2_000_000_000.0
        st = RuntimeState(); d = DisplayState(st, LiveTracker())
        ranked = [self.candidate(st, f'44{i:04d}', now, 500, 90-i) for i in range(10)]
        desired = d._compose_anchor_fresh(ranked, now, lambda c: c.metrics['test_rank'])
        first = d._stabilize_discovery('test', desired, ranked, now, lambda c: c.metrics['test_rank'], set())
        order1 = [c.code for c in first]
        # Realtime data/score changes while the visual row position is inside hold.
        moving = ranked[-1]
        moving.metrics['test_rank'] = 94.0
        moving.venue_state[Venue.NXT].last_price = 101500
        resorted = sorted(ranked, key=lambda c: c.metrics['test_rank'], reverse=True)
        desired2 = d._compose_anchor_fresh(resorted, now+5, lambda c: c.metrics['test_rank'])
        second = d._stabilize_discovery('test', desired2, resorted, now+5, lambda c: c.metrics['test_rank'], set())
        self.assertEqual([c.code for c in second], order1)
        row = next(c for c in second if c.code == moving.code)
        self.assertEqual(row.venue_state[Venue.NXT].last_price, 101500)
        self.assertEqual(row.metrics['test_rank'], 94.0)

    def test_five_point_superiority_replaces_weakest_during_hold(self):
        now = 2_000_000_000.0
        st = RuntimeState(); d = DisplayState(st, LiveTracker())
        base = [self.candidate(st, f'45{i:04d}', now, 500, 80-i) for i in range(10)]
        desired = d._compose_anchor_fresh(base, now, lambda c: c.metrics['test_rank'])
        first = d._stabilize_discovery('gap', desired, base, now, lambda c: c.metrics['test_rank'], set())
        weakest = min(c.metrics['test_rank'] for c in first)
        newcomer = self.candidate(st, '459999', now, 20, weakest + SETTINGS.discovery_display_immediate_gap + .1, best_rank=12, new_sources=2)
        ranked = sorted(base + [newcomer], key=lambda c: c.metrics['test_rank'], reverse=True)
        desired2 = d._compose_anchor_fresh(ranked, now+2, lambda c: c.metrics['test_rank'])
        out = d._stabilize_discovery('gap', desired2, ranked, now+2, lambda c: c.metrics['test_rank'], set())
        self.assertIn(newcomer.code, [c.code for c in out])

    def test_strong_fast_scout_can_enter_immediately_without_five_point_gap(self):
        now = 2_000_000_000.0
        st = RuntimeState(); d = DisplayState(st, LiveTracker())
        base = [self.candidate(st, f'46{i:04d}', now, 500, 80-i) for i in range(10)]
        first = d._stabilize_discovery('urgent', d._compose_anchor_fresh(base, now, lambda c:c.metrics['test_rank']), base, now, lambda c:c.metrics['test_rank'], set())
        weakest = min(c.metrics['test_rank'] for c in first)
        scout = self.candidate(st, '469999', now, 10, weakest + 1, best_rank=8, new_sources=2)
        ranked = sorted(base+[scout], key=lambda c:c.metrics['test_rank'], reverse=True)
        desired = d._compose_anchor_fresh(ranked, now+2, lambda c:c.metrics['test_rank'])
        out = d._stabilize_discovery('urgent', desired, ranked, now+2, lambda c:c.metrics['test_rank'], {scout.code})
        self.assertIn(scout.code, [c.code for c in out])

    def test_max_profit_tabs_have_independent_hysteresis_state(self):
        st = RuntimeState(); now = 2_000_000_000.0
        with tempfile.TemporaryDirectory() as td:
            lab = MaxProfitLab(st, Path(td))
            common = [{'code':f'C{i}', 'early_edge_score':90-i, 'fresh_window':False, 'headroom_score':20, 'last_tick_at':now} for i in range(10)]
            spac = [{'code':f'S{i}', 'early_edge_score':80-i, 'fresh_window':False, 'headroom_score':20, 'last_tick_at':now} for i in range(10)]
            co = lab._stabilize_candidate_rows('COMMON', common, now)
            sp = lab._stabilize_candidate_rows('SPAC', spac, now)
        self.assertEqual(len(co), 10); self.assertEqual(len(sp), 10)
        self.assertNotEqual(lab.stable_codes_by_board['COMMON'], lab.stable_codes_by_board['SPAC'])

    def test_r42_defaults_match_operator_contract(self):
        self.assertEqual(SETTINGS.discovery_anchor_slots, 6)
        self.assertEqual(SETTINGS.discovery_fresh_slots, 4)
        self.assertEqual(SETTINGS.discovery_display_hold_sec, 20.0)
        self.assertEqual(SETTINGS.discovery_display_immediate_gap, 5.0)
        self.assertEqual(SETTINGS.fresh_scout_fast_sec, 90.0)
        self.assertEqual(SETTINGS.fresh_scout_window_sec, 180.0)


if __name__ == '__main__':
    unittest.main()
