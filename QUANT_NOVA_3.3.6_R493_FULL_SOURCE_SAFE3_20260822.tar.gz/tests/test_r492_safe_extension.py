import time, unittest
from app.addons.energy_path import EnergyPathEngine
from app.runtime.state import RuntimeState
from app.domain import Venue

class R492SafeExtensionTest(unittest.TestCase):
    def test_critical_load_returns_r491_safe_without_rows(self):
        st=RuntimeState();st.load_mode='CRITICAL';out=EnergyPathEngine(st).build([],time.time(),True,set());self.assertEqual(out['mode'],'R491_SAFE');self.assertEqual(out['energy'],[]);self.assertEqual(out['path'],[])
    def test_engine_does_not_require_broker(self):
        st=RuntimeState();c=st.candidate('123456','X',trade_day='20260821');c.current_venue=Venue.KRX;v=c.venue_state[Venue.KRX];now=time.time();v.last_price=100;v.last_tick_at=now;v.day_low=95;v.day_high=103;v.metrics.update({'fresh':True,'buy_pressure':60,'turnover_accel_ready':True,'turnover_accel_30s':1.5,'volume_accel_ready':True,'volume_accel':1.4});out=EnergyPathEngine(st).build([c],now,True,set());self.assertLessEqual(len(out['energy']),10);self.assertLessEqual(len(out['path']),10)

if __name__=='__main__':unittest.main()
