from pathlib import Path
import unittest


class OpeningBridgeUiTest(unittest.TestCase):
    def setUp(self):
        self.root=Path(__file__).resolve().parents[1]

    def test_ui_version_is_r44(self):
        idx=(self.root/'static/index.html').read_text(encoding='utf-8')
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        self.assertIn('R4.2.1 SHADOW', idx)
        self.assertIn('R4.4 OPENING ONLY · BUY HANDOFF OFF', js)
        self.assertNotIn('R4.2.1 SHADOW · BUY HANDOFF OFF', js)

    def test_mobile_badge_is_compact_and_full_state_is_retained(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        css=(self.root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
        for state,label in [('PRIOR_CLOSE_FROZEN','FROZEN'),('PREMARKET_RECHECK','RECHECK'),('OPENING_HANDOFF','HANDOFF'),('SHAKEOUT_WATCH','SHAKEOUT'),('REVERSAL_EARLY','REVERSAL'),('BUY_READY_SHADOW','BUY READY')]:
            self.assertIn(f"{state}:'{label}'", js)
        self.assertIn('title=\"${fullState}\"', js)
        self.assertIn('.ob-origin{display:none}', css)
        self.assertIn('78px', css)

    def test_asset_cache_bust_changed(self):
        idx=(self.root/'static/index.html').read_text(encoding='utf-8')
        self.assertIn('opening-bridge-shadow.css?v=334-r43-core3&u=20260819-r45', idx)
        self.assertIn('opening-bridge-shadow.js?v=334-r43-core3&u=20260819-r45', idx)

    def test_core_three_boards_are_first_in_requested_order(self):
        idx=(self.root/'static/index.html').read_text(encoding='utf-8')
        p1=idx.index('① PRE-IGNITION · SIGNAL ACCELERATION TOP20')
        p2=idx.index('② 실시간 유망종목 자동발굴 · BUY 직전 TOP10')
        p3=idx.index('③ NXT 조기유입 · 스마트머니 Proxy TOP10')
        pl=idx.index('④ LARGE-CAP SWING DECISION TOP10')
        self.assertLess(p1,p2);self.assertLess(p2,p3);self.assertLess(p3,pl)

    def test_premarket_data_wait_is_compacted_not_ten_blank_rows(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        css=(self.root/'static/opening-bridge-shadow.css').read_text(encoding='utf-8')
        self.assertIn("phase==='PREMARKET_RECHECK'",js)
        self.assertIn('waitSummary(wait)',js)
        self.assertIn('후보는 보존 · 08:50 승계 · 화면만 축약',js)
        self.assertIn('.ob-wait-summary',css)

    def test_opening_bridge_is_hard_hidden_after_10(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        self.assertIn('openingWindowNow()',js)
        self.assertIn('mins>=480&&mins<600',js)
        self.assertIn('hidePanel(panel)',js)
        self.assertNotIn('sessionEnded(j)',js)

    def test_price_truth_labels_exist(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        self.assertIn('현재가 DATA WAIT',js)
        self.assertIn('LIVE_TRADE_TICK',js)
        self.assertIn('PRIOR_CLOSE_FROZEN',js)

    def test_r44_opening_panel_hard_hides_outside_0800_1000(self):
        js=(self.root/'static/opening-bridge-shadow.js').read_text(encoding='utf-8')
        self.assertIn('mins>=480&&mins<600',js)
        self.assertIn("panel.hidden=true",js)
        self.assertIn("panel.style.display='none'",js)
        self.assertIn('10:00 자동숨김',js)

if __name__=='__main__':
    unittest.main()
