import time, unittest
from pathlib import Path
from unittest.mock import patch

from app.domain import Origin, Venue
from app.runtime.state import RuntimeState
from app.runtime.display import DisplayState
from app.tracking.live import LiveTracker
from app.signal.early_edge import early_edge
from app.signal.metrics import MetricEngine


class EarlyEdgeR4Tests(unittest.TestCase):
    def _candidate(self, state, code, now, rate, repeat=0, edge=True):
        c=state.candidate(code,code,Origin.TODAY_NEW,'20260818');v=c.venue_state[Venue.NXT]
        v.last_price=100000;v.last_rate=rate;v.last_tick_at=now-1;v.last_recv_seq=1;v.score=70;v.confidence=65
        v.metrics.update({'fresh':True,'buy_pressure':64,'buy_pressure_delta_30s':9 if edge else 0,'volume_accel':1.8,'volume_accel_ready':True,
                          'turnover_accel_30s':2.0 if edge else 1.0,'turnover_accel_ready':True,'compression':.78 if edge else .25,
                          'session_vwap_gap':.2,'micro_vwap_gap':.15,'impulse_60s':.4 if edge else 1.5,'smart_money_realtime_proxy_score':3,
                          'smart_money_acceleration':1.7 if edge else 1.0,'sell_to_buy_flip':edge})
        v.entry.valid_repeat_count=repeat
        c.metrics.update({'discovery_first_seen_at':now-40 if edge else now-600,'discovery_rank_velocity_pos':12 if edge else 0,
                          'discovery_new_sources_60s':2 if edge else 0,'discovery_source_count':4,'discovery_best_rank':10})
        c.current_venue=Venue.NXT;c.refresh_aggregate();return c

    def test_prebuy_display_prefers_early_edge_over_old_repeat_strength(self):
        now=time.time();st=RuntimeState();early=self._candidate(st,'811111',now,1.8,repeat=2,edge=True);old=self._candidate(st,'822222',now,5.8,repeat=80,edge=False)
        # Old candidate has much higher legacy priority through cumulative repeat.
        self.assertGreater(old.priority_score,early.priority_score)
        d=DisplayState(st,LiveTracker())
        with patch('app.runtime.display.sessions',return_value={'active':True,'krx':False,'nxt':True}), patch('app.runtime.display.lifecycle_phase',return_value='NORMAL_INTRADAY'):
            self.assertTrue(d.build())
        rows=d.get()['boards']['prebuy'];self.assertEqual(rows,[])  # EARLY EDGE alone is no longer BUY-proximity
        self.assertGreater(early_edge(early,Venue.NXT,now)['score'],early_edge(old,Venue.NXT,now)['score'])


    def test_prebuy_early_edge_beats_late_direct_arm_readiness(self):
        now=time.time();st=RuntimeState();early=self._candidate(st,'844444',now,1.6,repeat=1,edge=True);late=self._candidate(st,'855555',now,5.8,repeat=30,edge=False)
        late.venue_state[Venue.NXT].entry.state='DIRECT_ARM';late.refresh_aggregate()
        self.assertEqual(late.entry_state,'DIRECT_ARM')
        self.assertEqual(early.entry_state,'DISCOVERY')
        d=DisplayState(st,LiveTracker())
        with patch('app.runtime.display.sessions',return_value={'active':True,'krx':False,'nxt':True}), patch('app.runtime.display.lifecycle_phase',return_value='NORMAL_INTRADAY'):
            self.assertTrue(d.build())
        rows=d.get()['boards']['prebuy']
        self.assertEqual(rows[0]['code'],late.code)
        self.assertEqual(rows[0]['rank_basis'],'ENTRY_PROXIMITY')

    def test_metric_engine_exposes_30s_flow_acceleration_without_changing_policy(self):
        now=time.time();st=RuntimeState();c=st.candidate('833333','FLOW',Origin.TODAY_NEW,'20260818');v=c.venue_state[Venue.NXT];c.current_venue=Venue.NXT
        w=st.window(c.code,Venue.NXT)
        # Previous 30s is lighter / less buy-biased than current 30s.
        for i in range(30):w.add(now-59+i,10000,100 if i%2 else -80)
        for i in range(30):w.add(now-29+i,10000,400 if i%5 else -50)
        v.last_price=10000;v.last_rate=1.0;v.last_tick_at=now
        m=MetricEngine(st).venue_metrics(c,Venue.NXT,now)
        self.assertTrue(m['turnover_accel_ready']);self.assertGreater(m['turnover_accel_30s'],1.5);self.assertGreater(m['buy_pressure_delta_30s'],0)

    def test_protected_sources_are_byte_frozen_against_r3_known_hashes(self):
        root=Path(__file__).resolve().parents[1]
        import hashlib
        expected={'app/signal/policy.py':'18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a',
                  'ops/http_guard_v2.py':'c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b',
                  'app/broker/kiwoom.py':'e10d936a2540a70d8a488e0460608a3c2a1a8bfaf95dc6206e706cce3afab0d1',
                  'app/broker/websocket.py':'50fefc5faa1457210af758636279bea0bc3926e505bc91317962a0d451e35602'}
        for rel,sha in expected.items():self.assertEqual(hashlib.sha256((root/rel).read_bytes()).hexdigest(),sha)

if __name__=='__main__':unittest.main()
