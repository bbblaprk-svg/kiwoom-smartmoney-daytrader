import time, unittest
from unittest.mock import patch
from app.domain import Origin, Venue
from app.runtime.state import RuntimeState
from app.runtime.display import DisplayState
from app.tracking.live import LiveTracker

class R46SessionCloseFreezeTests(unittest.TestCase):
    def _seed(self):
        now=time.time();st=RuntimeState();c=st.candidate('005930','삼성전자',Origin.TODAY_NEW,'20260819');v=c.venue_state[Venue.NXT]
        v.last_price=100000;v.last_rate=1.2;v.last_tick_at=now-1;v.last_recv_seq=7;v.score=70;v.confidence=80;v.entry.state='PRESSURE_BUILD'
        v.metrics.update({'fresh':True,'buy_pressure':65,'volume_accel':1.8,'volume_accel_ready':True,'session_vwap_gap':.2,'micro_vwap_gap':.1,'smart_money_realtime_proxy_score':2,'algo_persistence':60,'micro_vwap_gap':.1,'impulse_60s':.4})
        c.current_venue=Venue.NXT;c.live_track_pin=True;c.refresh_aggregate();return st,c

    def test_closed_refresh_is_read_only_and_history_frozen(self):
        st,c=self._seed();d=DisplayState(st,LiveTracker())
        with patch('app.runtime.display.sessions',return_value={'active':True,'krx':False,'nxt':True}),patch('app.runtime.display.lifecycle_phase',return_value='NORMAL_INTRADAY'):
            self.assertTrue(d.build())
        live=d.get();live_codes={k:[r.get('code') for r in v] for k,v in live['boards'].items()};hist=list(live['signal_history']);stats=dict(c.top10_stats_by_board)
        # Perturb candidate state after close. A closed display refresh must ignore this for board ranking/history.
        c.priority_score=1;c.score=1;c.append_history('TEST','AFTER_CLOSE_MUTATION',100000,'must not enter frozen UI',Venue.NXT,time.time())
        with patch('app.runtime.display.sessions',return_value={'active':False,'krx':False,'nxt':False}),patch('app.runtime.display.lifecycle_phase',return_value='PRIOR_CLOSE_FROZEN'):
            self.assertTrue(d.build());first=d.get();self.assertTrue(d.build());second=d.get()
        for snap in (first,second):
            self.assertEqual({k:[r.get('code') for r in v] for k,v in snap['boards'].items()},live_codes)
            self.assertEqual(snap['signal_history'],hist)
            self.assertTrue(snap['delivery']['close_hard_freeze'])
            self.assertEqual(snap['delivery']['ranking_writers'],'STOPPED');self.assertEqual(snap['delivery']['event_writers'],'STOPPED')
            for rows in snap['boards'].values():
                for row in rows:self.assertEqual(row.get('display_session_state'),'FROZEN')
        self.assertEqual(c.top10_stats_by_board,stats)

    def test_closed_without_live_fallback_never_writes_top10_events(self):
        st,c=self._seed();d=DisplayState(st,LiveTracker());before=len(c.history)
        with patch('app.runtime.display.sessions',return_value={'active':False,'krx':False,'nxt':False}),patch('app.runtime.display.lifecycle_phase',return_value='PRIOR_CLOSE_FROZEN'):
            self.assertTrue(d.build())
        self.assertEqual(len(c.history),before)
        self.assertFalse(any(e.state in ('TOP10_ENTER','TOP10_EXIT','TOP10_REENTER') for e in c.history))

if __name__=='__main__':unittest.main()
