# QUANT NOVA R49 — SIGNAL ACCELERATION TOP20 invariants

## Purpose
R49 replaces the PRE-IGNITION panel's old sticky `ANCHOR6 + FRESH4` presentation with a display-only real-time signal-acceleration board intended to surface *strengthening now* rather than lifetime repeat leaders.

## SIGNAL ACCELERATION TOP20
- Maximum 20 rows; partial rows are valid and no force-fill is allowed.
- Formal signal cadence is measured over overlapping 5m / 15m / 30m windows.
- Ranking uses recent cadence, acceleration, evidence diversity, live flow, headroom, VWAP position and sector context.
- Lifetime repeat count remains display context only; it is not a primary ranking key.
- Live metrics continue to update continuously, but membership/order commits every 30 seconds.
- A newly eligible symbol must beat the weakest replaceable row by at least 3 points.
- A newly admitted row receives a 60-second minimum dwell before normal replacement.
- Stale/ineligible rows may leave immediately; the dwell rule never keeps invalid data visible.

## Entry-target label
`진입대상` is a display-only pre-entry label, not an official BUY/ENTRY decision.
- It uses a 4-of-5 check: signal acceleration, live flow, price position, activity acceleration and <=3m formal-signal freshness.
- It also requires sufficient signal/evidence diversity and a minimum Signal Acceleration score.
- Overheated/chase-blocked rows are `COOLING` rather than `진입대상`.
- R49 does not mutate `ENTRY_V18`, `Candidate.entry_state`, BUY state, order routing or formal signal policy.

## Anti-stickiness / circulation
Root cause analysis found that formal signals intentionally set `live_track_pin=True`, and pinned codes are protected inside discovery capacity for performance tracking. The pin is not automatically cleared intra-day. This can create a feedback loop where old signaled symbols keep receiving live capacity and continue to look fresher than unseen symbols.

R49 does **not** remove those official tracking pins because that would alter signal follow-up/performance semantics. Instead, the SIGNAL ACCELERATION board has a read-only anti-stickiness gate:
- a normal pinned symbol needs a formal signal within the last 15 minutes to occupy the board;
- a genuinely new FAST SCOUT may enter without a formal signal only when at least two independent live evidence types are present;
- live ticks alone are insufficient to keep a stale pinned symbol on this board.

The existing bounded market rotation remains unchanged (24s check, 72s minimum dwell, 300s max hold for promising rows, 180s cooldown, batch 2 under default settings), and no WS capacity ceiling is increased.

## Preserved contracts
- R48 board independence remains: PREBUY = ENTRY proximity; NXT EARLY = NXT smart-flow evidence.
- R47 session-close hard freeze and late score-queue drop remain.
- R45 LARGE-CAP closed state remains LAST-LIVE ONLY with no DATA WAIT reconstruction.
- Opening Bridge remains hidden after 10:00 while records are retained.
- Official BUY/ENTRY policy SHA-256 remains `18cb96ef1afb9de48136d39c3e9b8216e62a94dccf0229aa027479783eb9151a`.
- HTTP Guard SHA-256 remains `c07332eb6951c51b433f42059133dd22b5e28a0c137f07b9f177f814dbe1ec1b`.
- No broker REST rank call is added.
- No WebSocket subscription type or registered-code ceiling is increased.
- Guard and Caddy are deployment-protected and must not be modified.
