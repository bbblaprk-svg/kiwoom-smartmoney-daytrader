"""Verify complete snapshot/restore bytes before allowing a previous Feed to restart."""
import hashlib
import json
import os
import shutil
from pathlib import Path
import sys


def manifest(root):
    root=Path(root);output={}
    for path in sorted(root.rglob('*')):
        if path.is_symlink() or not (path.is_file() or path.is_dir()):
            raise RuntimeError('unexpected data file type: '+str(path))
        name=path.relative_to(root).as_posix()
        if path.is_file():
            digest=hashlib.sha256()
            with path.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024),b''):digest.update(block)
            output[name]={'kind':'file','size':path.stat().st_size,'sha256':digest.hexdigest()}
        else:output[name]={'kind':'directory'}
    return output


def copy_contents(source, destination):
    source, destination = Path(source), Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    for path in sorted(source.rglob('*')):
        target = destination / path.relative_to(source)
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with path.open('rb') as src, target.open('wb') as dst:
                shutil.copyfileobj(src, dst, length=1024*1024)
                dst.flush()
                os.fsync(dst.fileno())
        if hasattr(os, 'chown'):
            st = path.stat()
            os.chown(target, st.st_uid, st.st_gid)
        shutil.copystat(path, target)
    shutil.copystat(source, destination)


def restore_in_place(data, backup, failed):
    data, backup, failed = map(Path, (data, backup, failed))
    expected = json.loads(backup.with_suffix('.manifest.json').read_text())
    if manifest(backup) != expected:
        raise RuntimeError('backup integrity check failed')
    if failed.exists():
        raise RuntimeError('failed-data evidence path already exists')
    current = manifest(data)
    copy_contents(data, failed)
    if manifest(failed) != current:
        raise RuntimeError('failed-data preservation check failed')
    # Retain the mount directory itself. All changed data has been preserved;
    # remove only extra/type-changed entries, then restore the saved bytes.
    for name in sorted(current, key=lambda x: (x.count('/'), x), reverse=True):
        if name not in expected or current[name]['kind'] != expected[name]['kind']:
            path = data / name
            if path.is_dir(): path.rmdir()
            else: path.unlink()
    copy_contents(backup, data)
    if manifest(data) != expected:
        raise RuntimeError('restored data integrity check failed')
    print('DATA_RESTORE_SHA_PASS entries=' + str(len(expected)))


if __name__=='__main__':
    if sys.argv[1] == 'restore-in-place':
        restore_in_place(*sys.argv[2:])
        raise SystemExit(0)
    mode,source,other=sys.argv[1:]
    if mode=='snapshot':
        original=manifest(source);backup=manifest(other)
        if original!=backup:raise SystemExit('SNAPSHOT_VERIFICATION_FAILED')
        Path(other).with_suffix('.manifest.json').write_text(json.dumps(original,sort_keys=True))
        print('DATA_SNAPSHOT_SHA_PASS entries='+str(len(original)))
    elif mode=='restore':
        expected=json.loads(Path(other).read_text())
        actual=manifest(source)
        if actual!=expected:raise SystemExit('RESTORE_VERIFICATION_FAILED: previous Feed remains stopped')
        print('DATA_RESTORE_SHA_PASS entries='+str(len(actual)))
    else:raise SystemExit('unknown data verification operation')
