import time, types
from datetime import datetime, timezone, timedelta
from pulse_edge.core.models import NormalizedEvent, Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.session.router import SessionRouter

router=SessionRouter()
immediate=FeatureEngine(router,None,None)
coalesced=FeatureEngine(router,None,None)
# Reference engine uses the exact same 2.1.11.1 formulas/state path but forces the
# historical immediate-recalc scheduling behavior.
def immediate_request(self,key,ts):
    self.recalc_requested += 1
    self._recalc(key,ts)
    self.recalc_executed += 1
immediate._request_recalc=types.MethodType(immediate_request, immediate)
base=datetime(2026,9,8,3,0,0,tzinfo=timezone.utc)

def event(rt,symbol,n,data):
    ts=base+timedelta(milliseconds=20*n)
    return NormalizedEvent(receive_time=ts,event_time=ts,source='burst-test',real_type=rt,symbol=symbol,venue=Venue.KRX,data=data)

events=[]
for si,symbol in enumerate(('005930','000660','035420','005380')):
    for i in range(220):
        n=si*10000+i*3
        price=70000+si*1000+(i%17)*10
        events.append(event('0B',symbol,n,{'price':str(price),'trade_volume':str(10+i%7),'change_rate':'0.5','cumulative_volume':str(10000+i*10),'cumulative_amount':str(700000000+i*700000),'buy_exec_volume':str(8+i%3),'sell_exec_volume':str(5+i%2),'net_buy_exec_volume':'3','instant_amount':str(price*(10+i%7))}))
        events.append(event('0D',symbol,n+1,{'ask1':str(price+10),'bid1':str(price-10),'ask1_qty':'100','bid1_qty':'120','total_ask_qty':'1000','total_bid_qty':'1200'}))
        if i%5==0:
            events.append(event('0w',symbol,n+2,{'program_net_buy_qty':str(i),'program_net_buy_qty_delta':'1','program_net_buy_amount':str(i*1000),'program_net_buy_amount_delta':'1000'}))

t0=time.perf_counter()
for e in events: immediate.ingest(e)
ref_sec=time.perf_counter()-t0

t0=time.perf_counter()
for e in events: coalesced.ingest(e)
coalesced.flush_due(force=True,max_batch=10000)
new_sec=time.perf_counter()-t0

for symbol in ('005930','000660','035420','005380'):
    key=(Venue.KRX,symbol)
    a=immediate.frames[key].model_dump()
    b=coalesced.frames[key].model_dump()
    if a != b:
        diffs=[k for k in a if a[k] != b[k]]
        raise SystemExit(f'FINAL_FRAME_MISMATCH {symbol} {diffs[:10]}')

stats=coalesced.recalc_runtime_stats()
if stats['pending'] != 0: raise SystemExit('PENDING_NOT_FLUSHED')
if stats['executed'] >= stats['requested'] // 4: raise SystemExit(f'COALESCING_TOO_WEAK {stats}')
ratio=new_sec/max(ref_sec,1e-9)
print(f'BURST_SEMANTICS_PASS events={len(events)} ref_sec={ref_sec:.4f} new_sec={new_sec:.4f} ratio={ratio:.3f} stats={stats}')

# Quote/program-before-first-trade regression: these events must be stored without
# repeatedly invoking a derived recalculation that cannot produce a frame.
pre=FeatureEngine(router,None,None)
for i in range(1000):
    pre.ingest(event('0D','051910',50000+i,{'ask1':'10010','bid1':'10000','ask1_qty':'100','bid1_qty':'120'}))
    if i % 5 == 0:
        pre.ingest(event('0w','051910',60000+i,{'program_net_buy_qty':str(i),'program_net_buy_qty_delta':'1'}))
pre_stats=pre.recalc_runtime_stats()
if pre.frames:
    raise SystemExit(f'QUOTE_ONLY_UNEXPECTED_FRAME {len(pre.frames)}')
if pre_stats['executed'] != 0 or pre_stats['pending'] != 0:
    raise SystemExit(f'QUOTE_ONLY_RECALC_REGRESSION {pre_stats}')
pre.ingest(event('0B','051910',70000,{'price':'10000','trade_volume':'10','change_rate':'0.1','cumulative_volume':'100','cumulative_amount':'1000000','instant_amount':'100000'}))
if (Venue.KRX,'051910') not in pre.frames:
    raise SystemExit('FIRST_TRADE_DID_NOT_CREATE_FRAME')
print(f'QUOTE_BEFORE_TRADE_GUARD_PASS stats={pre_stats}')

# Realtime capacity/priority regression: current rank order must win instead of
# ticker-code ordering, and a fresh scan must replace stale scan membership.
import asyncio
from pulse_edge.feed.ws import KiwoomWebSocket
async def _tok(): return 'x'
async def _payload(_): return None
async def subscription_test():
    ws=KiwoomWebSocket('ws://invalid',_tok,[],_payload,max_dynamic_items=34,background_reserve_items=10)
    await ws.set_background_items([f'B{i:03d}' for i in range(10)])
    first=[f'Z{i:03d}' for i in range(60)]
    await ws.add_stock_items(first)
    picked=ws.dynamic_stock_items
    event_picked=[x for x in picked if x.startswith('Z')]
    if event_picked != first[:24]:
        raise SystemExit(f'SUBSCRIPTION_PRIORITY_FAIL {event_picked[:8]}')
    second=[f'N{i:03d}' for i in range(60)]
    await ws.add_stock_items(second)
    picked2=ws.dynamic_stock_items
    event2=[x for x in picked2 if x.startswith('N')]
    if event2 != second[:24]:
        raise SystemExit(f'FRESH_SCAN_REPLACEMENT_FAIL {event2[:8]}')
    if any(x.startswith('Z') for x in picked2):
        raise SystemExit('STALE_EVENT_MEMBERSHIP_SURVIVED_FRESH_SCAN')
    print(f'SUBSCRIPTION_PRIORITY_PASS selected={len(picked2)} event={len(event2)} background={len([x for x in picked2 if x.startswith("B")])}')
asyncio.run(subscription_test())