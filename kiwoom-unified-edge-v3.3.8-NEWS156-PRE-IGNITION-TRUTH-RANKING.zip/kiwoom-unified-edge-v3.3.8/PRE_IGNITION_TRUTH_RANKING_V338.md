# v3.3.8 PRE-IGNITION TRUTH RANKING

목표: 이미 급등한 종목의 과거 등락률을 추격하지 않고, 급등 전 조짐을 실시간으로 포착합니다.

- 장중 현재등락률은 Kiwoom WebSocket TRADE_AUTO 최신값만 사용합니다.
- REST 랭킹의 등락률은 `발굴시 등락률`로만 보존하며 현재값으로 표시하지 않습니다.
- 실시간 수신이 없거나 stale이면 `현재등락 수신대기`로 표시하고 현재등락 점수를 주지 않습니다.
- 사전포착 최적구간은 현재 -1~+5% 중심, +8% 이상은 추격위험 감점입니다.
- 5분 거래량급증, 거래대금 가속, PRE-SURGE, 스마트머니 TURN/ACCUMULATION을 가점합니다.
- 기존 BUY 안전게이트와 KRX/NXT WebSocket registration/reception 경로는 변경하지 않습니다.
