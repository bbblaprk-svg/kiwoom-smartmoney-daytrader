# v3.3.8
- 장중 추천을 급등 후 강한종목에서 급등 전 사전포착 중심으로 변경.
- 현재등락률은 fresh Kiwoom WebSocket TRADE_AUTO만 사용.
- REST 등락률은 발굴시 스냅샷으로 분리.
- +8% 이상 추격위험 감점, -1~+5% 점화구간 우선.
- KRX/NXT 수신/등록, BUY 안전게이트 변경 없음.

# v3.2.16 — PRE-IGNITION VERIFIED REALTIME CORE

- Kiwoom 공식 국내주식 실시간 타입을 재검증하여 **주식체결 0B / 주식호가잔량 0D / 거래원 0F / 종목프로그램 0u / 장상태 0m / VI 0w**로 교정했습니다.
- 이전의 0B→체결, 0D→호가잔량 오해 가능성을 제거했습니다. 0D는 시간외호가이며 장중 orderbook 판단에 사용하지 않습니다.
- 30종목 모두 0A+0C+0w WebSocket Scout, FOCUS에는 0F 추가.
- 활성장 현재가/등락/신규진입 판단은 fresh Kiwoom 0A만 허용하고 종가·REST·ledger stale 가격 대체를 금지합니다.
- NXT `_NX` route + NXT-only bare-code session inference + KRX/NXT overlap ambiguous fail-closed를 적용했습니다.
- backend 40/80ms, SSE 100ms, UI 100ms로 앱 내부 지연을 줄였습니다.
- 8초 0A 무수신 시 REG soft recovery, 18초 지속 시 socket hard reconnect를 수행합니다.
- PRE-IGNITION은 tape/book/program/structure 4축 중 3축 이상을 요구하고 +4.5% 이상은 사전포착에서 제외, +6% 이상 신규추격을 hard block합니다.
- News v1.5.6 ROTATION PICKS는 discovery/context 전용이며 BUY 점수와 분리했습니다.
- `OFFICIAL_REALTIME_ROUTE_CHECK`, `REALTIME_TRUTH_CHECK`, `REALTIME_LATENCY_CHECK`, `PRE_IGNITION_CHECK`를 배포 회귀 게이트에 추가/강화했습니다.

# v3.2.12

- 14:40~15:35 KST 종가감사 구간에는 30종목 모두 WebSocket 정밀피드(체결·호가·프로그램)로 임시 승격해 스마트머니 미수집을 예방합니다.
- REST 추가 폴링은 하지 않아 LOW TRAFFIC 원칙을 유지합니다.
- 스마트머니 체크포인트를 FULL/PARTIAL로 구분합니다. PARTIAL은 미수집과 구분하지만 BUY/PRE-BUY 하드게이트를 통과시키지 않습니다.
- /api/health의 체크포인트 수를 FOCUS 12종목이 아니라 전체 30종목 기준으로 계산하도록 수정했습니다.
- health에 smartMoneyCheckpointFull / smartMoneyCheckpointPartial / closeAuditMode / closeAuditFullCount를 추가했습니다.

# v3.2.11
- 당일 종가근접 스마트머니 체크포인트 영속화/재기동 복원
- 스마트머니 미수집을 NEUTRAL과 분리하고 -6 신뢰도 감점 + PRE-BUY/BUY 차단
- ka10059 투자자수급을 수량(단주) 기준으로 통일, UI에 외국인/기관/프로그램 순매수 주수 명시
- /api/health에 version 및 smartMoneyCheckpoints 진단 추가

# v3.2.8 — PIPELINE GUARD V2 / COALESCED CLOSE SYNC

- 20:01 이후 KRX/NXT 미완료 동기화를 단일 pass로 합침
- KRX 종가시 NXT REST 호출 제거
- KRX 기본정보는 일봉 실패시만 fallback
- NXT 최종값은 WebSocket final 우선, REST 1회 fallback
- ka10059 기관/외인 우선, ka10008 외인상세 fallback-only
- close-sync state v5 및 reconnect cleanup map 초기화
- 실시간 WebSocket 처리와 종가 REST 복구를 계속 분리

# v3.2.7 — PIPELINE GUARD

- BUY 독립증거 게이트에서 execution+largeTrades를 동일 tape축으로 통합해 상관신호 이중가산 제거
- Smart Money TURN/MARKUP도 대형체결을 execution과 별도 독립축으로 세지 않고 프로그램/호가/가격/KRX·NXT 교차확인을 요구
- 새 설치 AUTO 시장선정 bootstrap 지원, 이후 AUTO LIGHT만 최대 2개/5분 보수적 교체
- LIGHT→FOCUS 승격에 전일 동시간 거래량비 보조축 추가(정밀피드 승격일 뿐 BUY 하드게이트는 불변)
- 모든 실시간 체결은 저장하고 고비용 신호평가만 체결 80ms/보조 180ms 기본 throttle
- quick promotion 경량경로로 burst 구간 이벤트루프 병목 완화
- 장중 추천 프로필 cache-only로 REST 직렬 폭주 차단
- 거래원(0F)은 스마트머니 보조증거로 유지하되 BUY 핵심피드 하드게이트에서 제외
- Smart Money 상태전환에 fresh trade/orderbook/program, EWMA 호가지지, 독립증거 수, persistence 요구
- 종가 공식수급 REST 우선, 신선 realtime fallback만 허용, 오래된 보존값은 display-only
- 학습 최소표본 60/12, 기본 보정 ±6, hard gate 불변
- BUY_ACTIVE를 BUY_MANAGE로 UI에 고정하고 데이터완전성/RR 표시
- health에 realtime type map/부하 telemetry와 BUY 엔진 정의와 일치한 smartMoneyReady 제공
- pipeline audit + 30종목 30,000 합성 이벤트 부하검사 추가

# v3.2.7 — CLOSE SYNC RESILIENCE

- KRX 15:32 실패 종목만 15:34/15:37/15:42/16:00 재시도
- NXT 20:01 실패 종목만 20:03/20:06/20:12/20:20 재시도
- 예약시각 서버 중단 시 재기동 즉시 catch-up
- 최종 예약 이후 제한적 5분 catch-up, 기본 총 7회
- 이전 유효 종가/일봉 보존과 오늘 공식 종가 확인 상태 분리
- 오늘 KRX 공식 종가 미확정 시 CLOSE_BUY 하드 차단
- 공식 수급 미확정 종목도 재시도 대상 유지
- watchlist 변경 시 장중 전체 REST 호출 제거
- `/api/health`에 closeSync/retry 상태 노출

# v3.2.7 — LOW TRAFFIC + MANAGED SIGNAL TABLE

- 장중 15분 전체 REST 스냅샷 제거
- KRX 15:32 / NXT 20:01 KST 자동 전체 종가동기화만 유지
- KRX/NXT WebSocket 실시간 수신 우선, stale일 때만 제한 REST 보조
- 정상장 관리신호 목표 4~6개: BUY 게이트는 유지하고 PRE-BUY/EARLY/안전 예비신호로 관리
- 약세장 상한 4, 강한장 상한 6
- 실시간 신호 관리 테이블 추가: 점수/현재가/진입기준가/수익률/등락률/KRX/NXT/스마트머니/신호시각
- 뉴스 1.5.1, Smart Money Behavior, KRX/NXT Dual Feed, Dual Close 및 승률학습 유지

## 3.2.9 — PHASED SMART MONEY
- Added SMART_NEG → SMART_NEUTRAL → SMART_BUILD → SMART_TURN → SMART_POS → SMART_CONFIRMED interpretation layer.
- 75+ candidates can remain PRE-BUY when core safety gates pass and Smart Money is merely unconfirmed, while negative Smart Money still vetoes entry.
- BUY remains hard-gated and requires confirmed Smart Money plus independent flow evidence.
- Added stage/remaining-condition metadata and PRE-BUY stage outcome recording at KRX official close.
