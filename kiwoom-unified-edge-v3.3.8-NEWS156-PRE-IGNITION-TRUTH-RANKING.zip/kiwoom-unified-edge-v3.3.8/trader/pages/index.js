import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, AlertTriangle, Bell, BookOpen, CheckCircle2, ChevronDown, CircleDollarSign,
  Gauge, LockKeyhole, Plus, RefreshCw, Settings, ShieldAlert, Trash2, TrendingDown,
  TrendingUp, Wifi, WifiOff, X,
} from 'lucide-react';

const EMPTY = {
  connection: { status: 'idle' }, stocks: [], positions: [], alerts: [], risk: {}, settings: {}, watchlist: [], performance: {}, tradeLedger: { rows: [], summary: {} }, managedSignals: { rows: [], regime: {}, target: {} }, recommendations: null, recommendationAutoApply: { enabled: false }, intradayRecommendations: null, intradayAutoApply: { enabled: false }, learningSettings: { enabled: true }, learningModel: null, preflight: {},
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `요청 실패 ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
function fmt(value, digits = 0) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number.toLocaleString('ko-KR', { maximumFractionDigits: digits }) : '-';
}
function fmtSignedShares(value) {
  const n = Number(value || 0);
  return `${n > 0 ? '+' : ''}${fmt(n)}주`;
}
function fmtWon(value) {
  const number = Number(value || 0);
  const absolute = Math.abs(number);
  if (absolute >= 100_000_000) return `${(number / 100_000_000).toFixed(1)}억`;
  if (absolute >= 10_000) return `${(number / 10_000).toFixed(0)}만`;
  return fmt(number);
}
function timeAgo(timestamp) {
  if (!timestamp) return '-';
  const seconds = Math.max(0, (Date.now() - Number(timestamp)) / 1000);
  if (seconds < 1) return '방금';
  if (seconds < 60) return `${seconds.toFixed(0)}초 전`;
  return `${(seconds / 60).toFixed(0)}분 전`;
}
function tone(value) { return Number(value) > 0 ? 'text-[#ff6b6b]' : Number(value) < 0 ? 'text-[#4ea1ff]' : 'text-[#d5dde5]'; }
function signalTone(action) {
  if (action === 'BUY') return 'border-[#1c6b46] bg-[#10271d] text-[#55e39a]';
  if (action === 'SELL') return 'border-[#7a2732] bg-[#311219] text-[#ff7b87]';
  if (action === 'EARLY_SELL') return 'border-[#8a4b20] bg-[#2f1d0f] text-[#ffad66]';
  if (action === 'RISK') return 'border-[#6b4b1f] bg-[#28200f] text-[#e7c36a]';
  if (action === 'EARLY') return 'border-[#6a571b] bg-[#2a240f] text-[#f1cf62]';
  if (action === 'BLOCKED') return 'border-[#665218] bg-[#2d2610] text-[#f6d365]';
  return 'border-[#29323d] bg-[#111820] text-[#93a4b5]';
}
function closeActionTone(action) {
  if (action === 'CLOSE_BUY' || action === 'HOLD') return signalTone('BUY');
  // 종가 약세는 보유자 매도지시가 아니라 다음 진입 제외 정보로만 표시한다.
  if (action === 'EXIT' || action === 'REDUCE' || action === 'NO_DATA') return signalTone('BLOCKED');
  return signalTone('EARLY');
}
function closeDisplayLabel(decision) {
  if (!decision) return '종가 판단';
  if (decision.action === 'EXIT' || decision.action === 'REDUCE') return '종가 약세 · 신규진입 제외';
  return decision.label || '종가 판단';
}
function dateTimeKo(value) {
  if (!value) return '-';
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime()) ? parsed.toLocaleString('ko-KR') : '-';
}
function priceBasisLabel(value) {
  return ({
    NXT_FINAL: '표시가격 NXT 최종가', NXT_CURRENT: '표시가격 NXT 현재가',
    KRX_OFFICIAL_CLOSE: '표시가격 KRX 공식 종가', KRX_CURRENT: '표시가격 KRX 현재/잠정',
    REALTIME_LAST: '실시간 체결가',
  }[value] || '표시가격');
}
function scorePoint(value) {
  const number = Number(value || 0);
  return `${number > 0 ? '+' : ''}${number}`;
}
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((char) => char.charCodeAt(0)));
}
const UI_FLUSH_MS = 50; // SSE 50ms coalescing + UI 50ms: upstream hot path와 분리된 화면 전달 지연 최소화

export default function Home() {
  const [data, setData] = useState(EMPTY);
  const [tab, setTab] = useState('unified');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [auth, setAuth] = useState({ checked: false, required: false, authenticated: false });
  const [token, setToken] = useState('');
  const [pushStatus, setPushStatus] = useState('');
  const pendingStocksRef = useRef(new Map());
  const pendingConnectionRef = useRef(null);
  const uiFlushTimerRef = useRef(null);

  const refresh = async (quiet = false) => {
    try {
      const next = await api('/api/dashboard');
      setData(next);
      setError('');
      if (!quiet) setLoading(false);
    } catch (err) {
      if (err.status === 401) setAuth((prev) => ({ ...prev, required: true, authenticated: false, checked: true }));
      else setError(err.message);
      if (!quiet) setLoading(false);
    }
  };

  useEffect(() => {
    api('/api/auth/check').then((result) => {
      setAuth({ checked: true, required: result.authRequired, authenticated: result.authenticated });
      if (result.authenticated) refresh(); else setLoading(false);
    }).catch((err) => { setError(err.message); setLoading(false); });
  }, []);

  useEffect(() => {
    if (!auth.authenticated) return undefined;
    const timer = setInterval(() => refresh(true), 30_000);
    const flushUi = () => {
      uiFlushTimerRef.current = null;
      const pending = [...pendingStocksRef.current.values()];
      const nextConnection = pendingConnectionRef.current;
      pendingStocksRef.current.clear();
      pendingConnectionRef.current = null;
      if (!pending.length && !nextConnection) return;
      setData((prev) => {
        const byCode = new Map((prev.stocks || []).map((stock) => [stock.code, stock]));
        for (const stock of pending) byCode.set(stock.code, stock);
        return { ...prev, stocks: [...byCode.values()], connection: nextConnection || prev.connection };
      });
    };
    const scheduleUiFlush = () => {
      if (uiFlushTimerRef.current) return;
      uiFlushTimerRef.current = setTimeout(flushUi, UI_FLUSH_MS);
    };
    const source = new EventSource('/api/events');
    source.onmessage = (event) => {
      let payload;
      try { payload = JSON.parse(event.data); } catch (_) { return; }
      if (payload.type === 'stock' && payload.stock) {
        pendingStocksRef.current.set(payload.stock.code, payload.stock);
        if (payload.connection) pendingConnectionRef.current = payload.connection;
        scheduleUiFlush();
      } else if (payload.type === 'connection' && payload.connection) {
        pendingConnectionRef.current = payload.connection;
        scheduleUiFlush();
      }
    };
    source.onerror = () => setError('실시간 화면 연결 재시도 중');
    source.onopen = () => setError('');
    return () => {
      clearInterval(timer);
      source.close();
      if (uiFlushTimerRef.current) clearTimeout(uiFlushTimerRef.current);
      uiFlushTimerRef.current = null;
      pendingStocksRef.current.clear();
      pendingConnectionRef.current = null;
    };
  }, [auth.authenticated]);

  const login = async (event) => {
    event.preventDefault();
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ token }) });
      setAuth({ checked: true, required: true, authenticated: true });
      setToken('');
      setLoading(true);
      await refresh();
    } catch (err) { setError(err.message); }
  };

  const enableNotifications = async () => {
    try {
      if (typeof Notification === 'undefined') throw new Error('이 브라우저는 알림 API를 지원하지 않습니다.');
      const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent || '');
      const standalone = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
      if (isIOS && !standalone) {
        throw new Error('아이폰 종료상태 푸시는 Safari 공유 → 홈 화면에 추가 후, 홈 화면 아이콘으로 앱을 열어 설정하세요.');
      }
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') throw new Error('아이폰 알림 권한이 허용되지 않았습니다.');
      if (!('serviceWorker' in navigator)) throw new Error('Service Worker를 지원하지 않습니다.');
      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;
      if (!registration.pushManager) throw new Error('PushManager를 지원하지 않습니다.');
      const keyInfo = await api('/api/push/public-key');
      if (!keyInfo.enabled || !keyInfo.publicKey) throw new Error('서버 VAPID 준비에 실패했습니다.');
      const existing = await registration.pushManager.getSubscription();
      if (existing) await existing.unsubscribe().catch(() => null);
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(keyInfo.publicKey),
      });
      await api('/api/push/subscribe', { method: 'POST', body: JSON.stringify(subscription) });
      const test = await api('/api/push/test', { method: 'POST', body: '{}' });
      setPushStatus(`아이폰 Web Push 실동작 확인 · 테스트 ${test.sent || 0}건 전송`);
      await refresh(true);
    } catch (err) { setPushStatus(err.message); }
  };


  const disableNotifications = async () => {
    try {
      let endpoint = null;
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.getRegistration('/').catch(() => null)
          || await navigator.serviceWorker.ready.catch(() => null);
        const subscription = registration?.pushManager ? await registration.pushManager.getSubscription().catch(() => null) : null;
        endpoint = subscription?.endpoint || null;
        await api('/api/push/subscribe', { method: 'DELETE', body: JSON.stringify({ endpoint, all: true }) });
        if (subscription) await subscription.unsubscribe().catch(() => null);
      } else {
        await api('/api/push/subscribe', { method: 'DELETE', body: JSON.stringify({ all: true }) });
      }
      setPushStatus('푸시 알림 해제 완료 · 서버 구독도 비활성화했습니다.');
      await refresh(true);
    } catch (err) { setPushStatus(`알림 해제 실패: ${err.message}`); }
  };

  if (!auth.checked || loading) return <Center><RefreshCw className="animate-spin" size={22} /> 데이터 준비 중</Center>;
  if (auth.required && !auth.authenticated) {
    return (
      <Center>
        <form onSubmit={login} className="w-full max-w-sm border border-[#26303b] bg-[#0d131a] rounded-2xl p-6 space-y-4">
          <LockKeyhole className="text-[#f5a623]" />
          <div><h1 className="font-bold text-lg">단타 앱 로그인</h1><p className="text-xs text-[#8190a0] mt-1">서버 환경변수 APP_ACCESS_TOKEN 값을 입력하세요.</p></div>
          <input className="input" type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="접근 암호" autoFocus />
          {error && <div className="text-xs text-[#ff7b87]">{error}</div>}
          <button className="primary-btn w-full" type="submit">로그인</button>
        </form>
      </Center>
    );
  }

  const connected = data.connection && data.connection.status === 'connected';
  const dataStatus = data.connection?.dataStatus || (connected ? 'SOCKET_ONLY' : 'OFFLINE');
  const liveDataOk = dataStatus === 'DATA_LIVE' || dataStatus === 'OFF_SESSION';
  const tabs = [
    ['unified', TrendingUp, '통합레이더'], ['live', Activity, '실시간'], ['ledger', TrendingUp, '종합기록부'], ['watch', Plus, '종목관리'], ['journal', BookOpen, '매매일지'], ['alerts', Bell, '알림'], ['settings', Settings, '설정'],
  ];

  return (
    <div className="min-h-screen bg-[#080b0f] text-[#e6edf3]">
      <header className="sticky top-0 z-30 bg-[#0b1016]/95 backdrop-blur border-b border-[#202832]">
        <div className="max-w-6xl mx-auto px-3 py-3 flex items-start justify-between gap-3">
          <div>
            <div className="text-[10px] tracking-[0.22em] text-[#738191]">UNIFIED NEWS + KRX·NXT EDGE · v3.3.3 · REALTIME FOUNDATION + NXT SUFFIX ROUTE + CLOSE FRESHNESS · READ ONLY</div>
            <h1 className="font-bold text-base mt-0.5">뉴스·KRX/NXT 통합 급등초입 레이더</h1>
            <div className="text-[11px] text-[#7e8c99] mt-1">뉴스 후보저수지 100 → 실시간 30 · PRE-BUY · 성과학습 · 수동종목 보호</div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] ${connected && liveDataOk ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#67303a] bg-[#2b1218] text-[#ff7b87]'}`}>
              {connected && liveDataOk ? <Wifi size={12} /> : <WifiOff size={12} />}{connected ? dataStatus : (data.connection?.status || 'idle')}
            </div>
            <div className="text-[10px] text-[#697786]">수신 {data.connection?.lastMessageAt ? new Date(data.connection.lastMessageAt).toLocaleTimeString('ko-KR') : '-'}</div>{data.connection?.marketStatus?.label && <div className="text-[10px] text-[#8b98a5]">{data.connection.marketStatus.label}</div>}
          </div>
        </div>
        {data.risk?.halted && <div className="bg-[#351119] text-[#ff8995] border-t border-[#6b2632] px-3 py-2 text-xs"><ShieldAlert size={13} className="inline mr-1" />신규진입 제한: {data.risk.reasons.join(' · ')} · 좋은 BUY 신호는 계속 표시</div>}
        {error && <div className="bg-[#30270f] text-[#f2d36b] border-t border-[#5c4c1e] px-3 py-2 text-xs">{error}</div>}
      </header>

      <nav className="sticky top-[88px] z-20 bg-[#0b1016] border-b border-[#202832] overflow-x-auto">
        <div className="max-w-6xl mx-auto px-2 flex">
          {tabs.map(([id, Icon, label]) => <button key={id} onClick={() => setTab(id)} className={`nav-btn ${tab === id ? 'active' : ''}`}><Icon size={14} />{label}</button>)}
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-3 py-4 pb-24">
        {tab === 'unified' && <UnifiedTab />}
        {tab === 'live' && <LiveTab data={data} onNotify={enableNotifications} onDisableNotify={disableNotifications} pushStatus={pushStatus} refresh={() => refresh()} />}
        {tab === 'ledger' && <LedgerTab data={data} />}
        {tab === 'watch' && <WatchlistTab data={data} onChanged={() => refresh()} />}
        {tab === 'journal' && <JournalTab data={data} onChanged={() => refresh()} />}
        {tab === 'alerts' && <AlertsTab alerts={data.alerts || []} onNotify={enableNotifications} onDisableNotify={disableNotifications} push={data.preflight?.push || {}} pushStatus={pushStatus} />}
        {tab === 'settings' && <SettingsTab settings={data.settings || {}} onSaved={() => refresh()} />}
      </main>
    </div>
  );
}

function Center({ children }) { return <div className="min-h-screen bg-[#080b0f] text-[#dce5ed] flex items-center justify-center gap-2 p-5">{children}</div>; }


function UnifiedTab() {
  const [u, setU] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const load = async (force = false) => {
    setBusy(true);
    try {
      const next = await api(force ? '/api/unified?force=1' : '/api/unified', force ? { method:'POST', body:'{}' } : {});
      setU(next); setErr('');
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  };
  useEffect(() => {
    load(false);
    const timer = setInterval(() => load(false), 30_000);
    return () => clearInterval(timer);
  }, []);
  if (!u) return <section className="panel p-5"><div className="flex items-center gap-2 text-sm"><RefreshCw size={16} className={busy ? 'animate-spin' : ''} />통합레이더 준비 중</div>{err && <div className="text-xs text-[#ff7b87] mt-2">{err}</div>}</section>;
  const counts = u.counts || {};
  const opportunities = u.opportunities || [];
  const reservoir = u.reservoir || [];
  const gates = u.gateStats || {};
  const stageLabel = (s) => ({ BUY:'BUY 확정', PRE_BUY:'PRE-BUY · 확인대기', EARLY:'EARLY · 조기관찰', WATCH:'상승 후보' }[s] || s);
  const stageClass = (s) => s === 'BUY' ? signalTone('BUY') : s === 'PRE_BUY' ? 'border-[#2b6c55] bg-[#0f241d] text-[#7ce8b4]' : s === 'EARLY' ? signalTone('EARLY') : signalTone('WAIT');
  const newsStageLabel = (s) => ({ STEALTH:'NEWS-STEALTH', EARLY:'NEWS-EARLY', VERIFY:'NEWS-VERIFY', WATCH:'NEWS-WATCH', CROWDED:'NEWS-CROWDED' }[String(s || '').toUpperCase()] || `NEWS-${String(s || '-').toUpperCase()}`);
  return <div className="space-y-4">
    <section className="panel p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><h2 className="section-title"><TrendingUp size={16} />통합 급등 레이더</h2><p className="help mt-1">뉴스가 200+ 유니버스에서 후보를 넓게 발굴하고, 상위 후보만 30종목 감시로 넘긴 뒤 키움 체결·호가·스마트머니가 실제 진입을 검증합니다.</p></div>
        <button className="secondary-btn" onClick={() => load(true)} disabled={busy}><RefreshCw size={14} className={busy ? 'animate-spin' : ''} />통합 후보 새로고침</button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3">
        <Summary label="현재 자동투입 후보" value={u.news?.reservoirCount || 0} icon={TrendingUp} />
        <Summary label="현재 감시" value={`${counts.watched || 0}/30`} icon={Activity} />
        <Summary label="PRE-BUY" value={counts.preBuy || 0} icon={CircleDollarSign} positive={Number(counts.preBuy)>0} />
        <Summary label="EARLY" value={counts.early || 0} icon={TrendingUp} positive={Number(counts.early)>0} />
        <Summary label="BUY 확정" value={counts.buy || 0} icon={CheckCircle2} positive={Number(counts.buy)>0} />
      </div>
      <div className="mt-3 text-[10px] text-[#8190a0]">뉴스엔진 {u.news?.connected ? `AWS 내부연결 · v${u.news.newsVersion || '-'}` : `연결대기${u.news?.error ? ` · ${u.news.error}` : ''}`} · 장중 자동적용 {u.intradayAutoApply?.enabled ? 'ON' : 'OFF'} · AUTO 경량만 5분/최대2종목 보수적 교체</div>
    </section>

    <section className="panel overflow-hidden">
      <div className="px-3 py-2.5 border-b border-[#202832]"><h2 className="section-title"><CircleDollarSign size={15} />오늘 최우선 · PRE-BUY 포함</h2><div className="text-[10px] text-[#718091] mt-1">BUY가 0개여도 어디까지 조건이 완성됐는지 보여줍니다. PRE-BUY는 매수확정이 아닙니다.</div></div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-3">
        {opportunities.length === 0 && <div className="empty md:col-span-2">현재 60점 이상 상승후보가 없습니다. 약한 장에서는 억지 BUY를 만들지 않습니다.</div>}
        {opportunities.map((row) => {
          const g = row.entryGuide || {};
          const wait = g.waitingLow && g.waitingHigh ? `${fmt(g.waitingLow)}~${fmt(g.waitingHigh)}원` : '-';
          return <div key={`unified-${row.code}`} className={`rounded-xl border p-3 ${stageClass(row.stage)}`}>
            <div className="flex justify-between gap-2"><div><strong>{row.name}</strong><span className="ml-2 text-[10px] opacity-70">{row.code}</span></div><span className="text-xs font-black">{stageLabel(row.stage)} · {row.readiness}%</span></div>
            <div className="grid grid-cols-3 gap-2 mt-2 text-[10px]"><div>현재가<strong className="block text-sm">{row.currentPrice ? `${fmt(row.currentPrice)}원` : '-'}</strong></div><div>매수대기<strong className="block text-sm">{row.stage === 'BUY' && g.entry ? `${fmt(g.entry)}원` : wait}</strong></div><div>R/R<strong className="block text-sm">{row.rr ? `${Number(row.rr).toFixed(2)}R` : '-'}</strong></div></div>
            <div className="mt-1 text-[9px] opacity-75">실시간 {row.realtimeVenue || '-'} · 실시간체결 · {row.realtimeTradeAgeMs != null ? `${(Number(row.realtimeTradeAgeMs)/1000).toFixed(1)}초전` : '미수신'} · 뉴스는 판정점수 미반영</div>
            <div className="mt-2 text-[10px]">품질 {Math.round(row.qualityScore)} · 수익우선 {Math.round(row.profitPriorityScore)} · 체결 {Math.round(row.tradeStrength)} · 점화전 {Math.round(row.preIgnitionScore || 0)} · PRE {Math.round(row.preSurgeScore)} · 스마트머니 {row.smartMoneyPhase || row.smartMoneyState} {row.smartMoneyConfidence ? `(${Math.round(row.smartMoneyConfidence)})` : ''}</div>
            {row.missingConditions?.length > 0 && row.stage !== 'BUY' && <div className="mt-1 text-[9px] text-[#f1cf62]">남은조건: {row.missingConditions.slice(0,3).join(' · ')}</div>}
            {row.news && <div className="mt-2 pt-2 border-t border-current/20 text-[9px]">뉴스 {newsStageLabel(row.news.edgeClass)} · 선취 {row.news.prepositionScore ?? '-'} · 선반영 {row.news.pricedInScore ?? '-'} · {row.news.source}</div>}
          </div>;
        })}
      </div>
    </section>

    <section className="panel p-4">
      <h2 className="section-title"><Gauge size={16} />오늘 BUY 차단원인</h2>
      <p className="help mt-1">조건을 무작정 낮추지 않고, 어떤 게이트 때문에 좋은 후보가 탈락하는지 10분 중복제거로 누적합니다.</p>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-xs"><div className="metric">BUY <strong>{gates.buy || 0}</strong></div><div className="metric">PRE-BUY <strong>{gates.preBuy || 0}</strong></div><div className="metric">EARLY <strong>{gates.early || 0}</strong></div><div className="metric">관찰표본 <strong>{gates.observed || 0}</strong></div></div>
      <div className="mt-3 space-y-1">{(gates.reasons || []).slice(0,8).map((r, i) => <div key={`gate-${i}`} className="flex justify-between text-[11px] border-b border-[#1d252e] py-1"><span>{r.reason}</span><strong>{r.count}회</strong></div>)}</div>
    </section>

    <section className="panel p-4">
      <h2 className="section-title"><TrendingUp size={16} />전체 뉴스랭킹 · 상위 20</h2>
      <p className="help mt-1">뉴스는 BUY 점수가 아니라 감시대상 선택에만 사용합니다. CROWDED/선반영 과다 후보는 자동진입 후보에서 제외됩니다.</p>
      <div className="mt-3 divide-y divide-[#202832]">{reservoir.slice(0,20).map((row, i) => <div key={`res-${row.code}`} className="py-2 flex items-start justify-between gap-3 text-xs"><div><strong>{i+1}. {row.name}</strong><span className="ml-2 text-[#718091]">{row.code}</span><div className="text-[9px] text-[#8190a0] mt-1">{(row.reasons || []).slice(0,2).join(' · ') || row.source}</div></div><div className="text-right whitespace-nowrap"><div className="font-bold">{newsStageLabel(row.edgeClass)}</div><div className="text-[9px] text-[#8190a0]">선취 {row.prepositionScore ?? '-'} · 선반영 {row.pricedInScore ?? '-'}{row.watched ? ' · 감시중' : ''}</div></div></div>)}</div>
    </section>

    <Notice icon={AlertTriangle}>확정 BUY 안전게이트(품질·수익우선·체결강도·데이터완전성·R/R·스마트머니)는 그대로입니다. 뉴스/학습은 무엇을 먼저 감시할지 개선하며 BUY를 강제로 만들지 않습니다.</Notice>
  </div>;
}

function LiveTab({ data, onNotify, onDisableNotify, pushStatus, refresh }) {
  const stocks = data.stocks || [];
  const [snapshotBusy, setSnapshotBusy] = useState(false);
  const [snapshotMessage, setSnapshotMessage] = useState('');
  const ordered = useMemo(() => [...stocks].sort((a, b) => {
    const closeRank = (stock) => ({ CLOSE_BUY: 0, HOLD: 1, WAIT: 2, REDUCE: 3, EXIT: 4, NO_DATA: 5 }[stock.closeDecision?.action] ?? 6);
    const liveRank = (stock) => {
      if (stock?.realtimeEligible !== true) return 4;
      return stock.signal?.confirmed && stock.signal.action === 'BUY'
        ? 0
        : stock.signal?.action === 'EARLY' && stock.signal?.preSurgeEligible ? 1
          : stock.signal?.action === 'EARLY' && stock.signal?.earlyDiscoveryEligible ? 2
            : stock.signal?.action === 'EARLY' ? 3 : 4;
    };
    const usesCloseSnapshot = (stock) => Boolean(
      !stock?.realtimeSessionActive && stock?.closeSnapshotFreshness?.rankEligible === true && (
        stock?.dataSource === 'CLOSE_SNAPSHOT'
        || (stock?.marketSnapshot?.phase?.code && stock.marketSnapshot.phase.code !== 'INTRADAY')
      )
    );
    const rankA = usesCloseSnapshot(a) ? closeRank(a) : liveRank(a);
    const rankB = usesCloseSnapshot(b) ? closeRank(b) : liveRank(b);
    // 같은 중요단계에서는 점수 미세변화로 행 위치가 계속 바뀌지 않도록 종목코드로 고정한다.
    return rankA - rankB || String(a.code || '').localeCompare(String(b.code || ''));
  }), [stocks]);
  const buys = stocks.filter((s) => s.realtimeEligible === true && s.signal?.confirmed && s.signal.action === 'BUY').length;
  const preIgnition = stocks.filter((s) => s.realtimeEligible === true && s.signal?.action === 'EARLY' && s.signal?.preIgnitionEligible).length;
  const earlyStrong = stocks.filter((s) => s.realtimeEligible === true && s.signal?.action === 'EARLY' && s.signal?.preSurgeEligible && !s.signal?.preIgnitionEligible).length;
  const earlyDiscovery = stocks.filter((s) => s.realtimeEligible === true && s.signal?.action === 'EARLY' && s.signal?.earlyDiscoveryEligible && !s.signal?.preSurgeEligible).length;
  const entryRestricted = stocks.filter((s) => s.realtimeEligible === true && s.signal?.action === 'BUY' && s.entryRestricted).length;
  const fresh = stocks.filter((s) => s.realtimeEligible === true).length;
  const closeReady = stocks.filter((s) => s.closeSnapshotFreshness?.rankEligible === true).length;
  const staleClose = stocks.filter((s) => s.marketSnapshot && s.closeSnapshotFreshness?.rankEligible !== true).length;
  const closeBuys = stocks.filter((s) => s.closeDecision?.action === 'CLOSE_BUY').length;
  const promoted = stocks.filter((s) => s.tier === 'LIGHT' && s.activeTier === 'FOCUS').length;
  const perf = data.performance?.quality85Plus || {};
  const winRate = perf.winRate == null ? '-' : `${Number(perf.winRate).toFixed(1)}%`;
  const syncSnapshots = async () => {
    setSnapshotBusy(true); setSnapshotMessage('종가·일봉 수동 REST 동기화 중…');
    try {
      const result = await api('/api/snapshots', { method: 'POST', body: '{}' });
      setSnapshotMessage(`종가 ${result.completed || 0}/${result.requested || stocks.length}종목 갱신`);
      await refresh();
    } catch (err) { setSnapshotMessage(err.message); }
    finally { setSnapshotBusy(false); }
  };

  return <div className="space-y-4">
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
      <Summary label="실시간 수신" value={`${fresh}/${stocks.length}`} icon={Wifi} />
      <Summary label="종가 확보" value={`${closeReady}/${stocks.length}`} icon={CircleDollarSign} positive={closeReady === stocks.length && stocks.length > 0} />
      <Summary label="종가매수 후보" value={closeBuys} icon={TrendingUp} positive />
      <Summary label="확정 매수" value={buys} icon={TrendingUp} positive />
      <Summary label="급등 사전포착" value={earlyStrong} icon={TrendingUp} positive />
      <Summary label="급등 조짐" value={earlyDiscovery} icon={Activity} positive />
      <Summary label="진입제한 BUY" value={entryRestricted} icon={ShieldAlert} />
      <Summary label="85점+ 실증승률" value={`${winRate} · n=${perf.sampleSize || 0}`} icon={Gauge} />
    </div>
    <div className="flex flex-wrap gap-2 items-center">
      <button className="secondary-btn" onClick={onNotify}><Bell size={14} />아이폰 푸시 켜기·테스트</button>
      <button className="secondary-btn" onClick={onDisableNotify}><Bell size={14} />푸시 알림 해제</button>
      <button className="secondary-btn" onClick={refresh}><RefreshCw size={14} />전체 동기화</button>
      <button className="secondary-btn" disabled={snapshotBusy} onClick={syncSnapshots}><CircleDollarSign size={14} />{snapshotBusy ? '종가 조회 중' : '종가 수동동기화'}</button>
      <span className="text-[11px] text-[#7e8c99]">{snapshotMessage || pushStatus || '홈 화면 설치 후 푸시 테스트 가능 · 앱 열린 상태는 SSE 즉시알림'}</span>
    </div>
    <Notice icon={Wifi}>LOW TRAFFIC: 장중은 KRX/NXT WebSocket 실시간 수신이 우선입니다. 종가 REST는 KRX 15:32·NXT 20:01에 실행하고 실패 종목만 재시도하며, 오늘 KRX 공식 종가가 미확정이면 CLOSE_BUY를 차단합니다.</Notice>
    <PreflightPanel preflight={data.preflight || {}} />
    <Notice icon={TrendingUp}>이 화면의 목적은 상승초입·급등후보 발견입니다. 일반 감시종목의 하락압력은 신규진입 필터로만 쓰며 매도신호로 표시하지 않습니다. 실제 보유종목은 매수가 기준 설정 손절가 도달 때만 푸시합니다.</Notice>
    <Notice icon={AlertTriangle}>품질점수와 종가점수는 적중확률이 아닙니다. 실제 체결성과를 누적해 별도로 검증해야 합니다.</Notice>
    {closeReady === 0 && <Notice icon={AlertTriangle}>종가 스냅샷이 없습니다. 자동 전체 REST 조회는 KRX/NXT 종가 시점에만 실행합니다. 필요할 때만 ‘종가 수동동기화’로 강제 조회할 수 있습니다.</Notice>}
    {!data.connection?.lastMessageAt && closeReady > 0 && <Notice icon={CheckCircle2}>실시간 체결이 없는 시간에는 날짜 freshness gate를 통과한 KRX 공식 종가·NXT 최종가만 표시합니다.</Notice>}
    {staleClose > 0 && <Notice icon={AlertTriangle}>오래된 종가 스냅샷 {staleClose}종목은 오늘 종가랭킹·현재가·종가판정에서 제외했습니다. 서버 재시작 시 현재 거래일 종가 catch-up을 자동 실행합니다.</Notice>}
    <ManagedSignalTable data={data} />
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
      {ordered.map((stock) => <StockCard key={stock.code} stock={stock} settings={data.settings || {}} risk={data.risk || {}} />)}
    </div>
  </div>;
}
function Summary({ label, value, icon: Icon, positive, negative, valueClass = '' }) {
  return <div className="panel p-3"><div className="flex items-center gap-1.5 text-[11px] text-[#7e8c99]"><Icon size={13} />{label}</div><div className={`text-xl font-bold mt-1 ${positive ? 'text-[#55e39a]' : negative ? 'text-[#ff7b87]' : valueClass}`}>{value}</div></div>;
}
function Notice({ icon: Icon, children }) { return <div className="border border-[#5a4818] bg-[#29220f] text-[#efd36c] rounded-xl px-3 py-2 text-xs"><Icon size={13} className="inline mr-1" />{children}</div>; }

function PreflightPanel({ preflight }) {
  const snapshots = preflight.snapshots || {};
  const flow = preflight.closingCoreFlow || {};
  const live = preflight.liveFeeds || {};
  const venue = preflight.actualVenue || {};
  const push = preflight.push || {};
  const feed = live.counts || {};
  const ready = preflight.overall === 'READY' || preflight.overall === 'PREMARKET_READY_WITH_LIVE_PENDING';
  const pushOperational = Boolean(push.operational);
  const lastPushTest = push.lastTest?.at ? new Date(push.lastTest.at).toLocaleString('ko-KR') : null;
  return <section className={`rounded-xl border px-3 py-3 ${ready ? 'border-[#254b39] bg-[#0f2119]' : 'border-[#604b1c] bg-[#29220f]'}`}>
    <div className="flex items-center justify-between gap-2"><div className="font-bold text-xs flex items-center gap-1.5"><CheckCircle2 size={14} />장전 사전점검</div><span className="text-[10px] font-bold">{preflight.overall || '확인중'}</span></div>
    <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-2 text-[10px]">
      <div>키움 연결<strong className="block text-sm">{preflight.connectionReady ? '정상' : '확인필요'}</strong></div>
      <div>종가/일봉<strong className="block text-sm">{snapshots.ready || 0}/{snapshots.target || 0}</strong></div>
      <div>공식 마감수급<strong className="block text-sm">{flow.ready || 0}/{flow.target || 0}</strong><span className="block text-[9px] text-[#7f918a]">P {flow.program || 0} · F {flow.foreign || 0} · I {flow.institution || 0}</span></div>
      <div>실시간 핵심피드<strong className="block text-sm">{live.expectedNow ? `${live.ready || 0}/${live.target || 0}` : '장중 대기'}</strong><span className="block text-[9px] text-[#7f918a]">체결 {feed.trade || 0} · 호가 {feed.orderbook || 0} · P {feed.program || 0} · 거래원 {feed.broker || 0}</span></div>
      <div>아이폰 Push<strong className="block text-sm">{push.intentionallyDisabled ? '사용자 해제 상태' : pushOperational ? `실동작 확인 · 구독 ${push.subscriptionCount || 0}` : push.vapidConfigured ? `VAPID 정상 · 테스트 필요` : '설정 필요'}</strong>{lastPushTest && !push.intentionallyDisabled && <span className="block text-[9px] text-[#7f918a]">최근 테스트 {lastPushTest}</span>}</div>
    </div>
    <div className="mt-2 text-[9px] text-[#8fa09a]">실제체결시장: {venue.expectedNow ? `${venue.known || 0}/${venue.target || 0} KRX/NXT 식별` : '장중 수신 시 KRX/NXT 식별'} · SOR는 경로일 뿐 실제 체결시장으로 단정하지 않습니다.</div>
    <div className="mt-1 text-[9px] text-[#8fa09a]">{preflight.dataStatus || 'DATA_CHECKING'} · 과거 스마트머니는 장중 실제 누적값만 인정하며 휴장 중 임의 생성하지 않습니다.{preflight.missingSummary ? ` · ${preflight.missingSummary}` : ''}</div>
  </section>;
}

function StockCard({ stock, settings, risk }) {
  const signal = stock.signal || {};
  const metrics = signal.metrics || {};
  const rawSnapshot = stock.marketSnapshot || null;
  const closeFreshness = stock.closeSnapshotFreshness || {};
  const snapshot = closeFreshness.rankEligible === true ? rawSnapshot : null;
  const closeDecision = stock.closeDecision || snapshot?.decision || null;
  const closingMode = Boolean(snapshot && closeDecision && !stock.realtimeSessionActive);
  const liveAge = timeAgo(stock.liveUpdatedAt || stock.updatedAt);
  const priceFresh = Boolean(stock.realtimeEligible);
  const realtimeMissing = Boolean(stock.realtimeSessionActive && !stock.realtimeRouted);
  const realtimeStale = Boolean(stock.realtimeSessionActive && stock.realtimeRouted && !stock.realtimeEligible);
  const realtimeSignalUsable = stock.realtimeEligible === true;
  const liveAction = !realtimeSignalUsable
    ? 'WAIT'
    : signal.confirmed
      ? (signal.action === 'BUY' ? 'BUY' : signal.action)
      : signal.action === 'EARLY' ? 'EARLY'
        : signal.action === 'BUY' ? 'WAIT' : signal.action;
  const action = closingMode ? closeDecision.action : liveAction;
  const plan = closingMode ? (['CLOSE_BUY', 'HOLD'].includes(closeDecision.action) ? closeDecision.plan : null) : (realtimeSignalUsable ? signal.plan : null);
  const riskBudget = Math.max(0, Number(settings.accountEquity || 0) * Number(settings.maxRiskPerTradePct || 0) / 100);
  const riskPerShare = plan ? Math.max(1, Number(plan.entry || 0) - Number(plan.stop || 0)) : 0;
  const riskQty = riskPerShare > 0 ? Math.floor(riskBudget / riskPerShare) : 0;
  const capitalQty = plan && Number(plan.entry) > 0 ? Math.floor(Number(settings.accountEquity || 0) * Number(settings.maxPositionPct || 33) / 100 / Number(plan.entry)) : 0;
  const suggestedQty = Math.max(0, Math.min(riskQty || 0, capitalQty || riskQty || 0));
  const feedAges = stock.feeds || {};
  const tierLabel = stock.activeTier === 'FOCUS' ? (stock.tier === 'LIGHT' ? '자동승격' : '집중') : '경량';
  const confirmText = closingMode ? (snapshot.phase?.label || '종가 판단')
    : !realtimeSignalUsable ? '실시간 체결 확인대기'
      : signal.confirmed && signal.action === 'BUY' ? (stock.entryRestricted ? 'BUY 확정 · 신규진입 제한' : 'BUY 확정')
        : signal.action === 'EARLY' ? (signal.preIgnitionEligible ? '점화전 사전포착' : signal.preSurgeEligible ? '급등 직전 확인' : signal.earlyDiscoveryEligible ? '급등 조짐' : '상승 조기관찰')
          : `체결확인 ${signal.confirmCount || 0}/${signal.requiredConfirmations || 3}`;
  const displayLabel = closingMode ? closeDisplayLabel(closeDecision) : (!realtimeSignalUsable ? '실시간 판단 보류' : (signal.label || '수신대기'));
  const displayTone = closingMode ? closeActionTone(action) : signalTone(action);
  const priceStatus = closingMode
    ? `${snapshot.krx?.dateText || snapshot.krx?.date || ''} · 종가 스냅샷`
    : realtimeMissing ? `실시간 시세 미수신 · ${Array.isArray(stock.realtimeExpectedVenues) ? stock.realtimeExpectedVenues.join('+') : ''}`
      : realtimeStale ? `${stock.realtimeVenue || '실시간'} 최근 체결 ${liveAge} · 신규판정 보류`
        : priceFresh ? `${stock.realtimeVenue || '실시간'} WebSocket · ${liveAge}` : liveAge;
  const reasonList = closingMode ? closeDecision.reasons : (realtimeSignalUsable ? signal.reasons : []);
  const warningList = closingMode ? closeDecision.warnings : (realtimeSignalUsable ? signal.warnings : ['실시간 체결 미수신·판정보류']);
  const vetoList = closingMode ? [] : (realtimeSignalUsable ? signal.vetoes : ['REALTIME_TRADE_REQUIRED']);
  const krx = snapshot?.krx || {};
  const nxt = snapshot?.nxt || {};
  const indicators = snapshot?.indicators || {};
  const closingFlow = snapshot?.closingFlow || {};
  const flowAvailability = closingFlow.availability || {};
  const completeness = snapshot?.completenessBreakdown || {};
  const isClosedSnapshot = closingMode && ['ALL_CLOSED', 'PRE_OPEN'].includes(snapshot?.phase?.code);
  const displayedChangeAvailable = stock.changePct !== null && stock.changePct !== undefined && Number.isFinite(Number(stock.changePct));
  const closedMetric = (value, formatter, available = true) => {
    if (isClosedSnapshot) return '휴장·미측정';
    if (!available) return '미수신';
    return formatter(value);
  };
  const decisionBasisText = closeDecision?.basis?.decisionPrice === 'KRX_OFFICIAL_CLOSE'
    ? '판단기준 KRX 공식 종가·일봉 · NXT는 괴리 확인/보정만 반영'
    : '판단기준 확인 필요';

  return <section className={`panel overflow-hidden ${action === 'CLOSE_BUY' || realtimeSignalUsable && signal.confirmed && signal.action === 'BUY' ? 'ring-1 ring-[#2e8b5e]' : ''}`}>
    <div className="p-3 border-b border-[#202832] flex items-start justify-between gap-2">
      <div>
        <div className="flex items-center gap-2"><span className="font-bold">{stock.name}</span><span className="text-[10px] text-[#728091]">{stock.code} · {stock.marketMode}</span><span className="badge">{tierLabel}</span>{closingMode && <span className="badge">종가</span>}{stock.vi?.active && <span className="badge-danger">VI</span>}</div>
        <div className="flex items-baseline gap-2 mt-1 flex-wrap"><span className="text-2xl font-black">{stock.price ? fmt(stock.price) : '-'}</span><span className={`text-sm font-bold ${displayedChangeAvailable ? tone(stock.changePct) : 'text-[#718091]'}`}>{displayedChangeAvailable ? `${Number(stock.changePct) > 0 ? '+' : ''}${Number(stock.changePct).toFixed(2)}%` : '등락률 미수집'}</span><span className={`text-[10px] ${closingMode || priceFresh ? 'text-[#55e39a]' : 'text-[#ff7b87]'}`}>{closingMode ? `${priceBasisLabel(stock.priceBasis)} · ${priceStatus}` : priceStatus}</span></div>
      </div>
      <div className={`border rounded-lg px-2.5 py-1.5 text-center min-w-[112px] ${displayTone}`}>
        <div className="text-[10px]">{confirmText}</div><div className="font-bold text-sm">{displayLabel}</div>
      </div>
    </div>
    <div className="p-3">
      {rawSnapshot && closeFreshness.rankEligible !== true && !stock.realtimeSessionActive && <div className="mb-3 rounded-xl border border-[#665218] bg-[#2d2610] px-3 py-2 text-[10px] text-[#f6d365]"><strong>종가 freshness 차단:</strong> 저장 스냅샷 {closeFreshness.krxDate || '-'}은(는) 현재 기준일 {closeFreshness.expectedDate || '-'}과 일치하지 않아 종가랭킹·현재가·매매판정에서 제외했습니다.</div>}
      {stock.realtimeSessionActive && !stock.realtimeEligible && <div className="mb-3 rounded-xl border border-[#6a3c2a] bg-[#21130f] px-3 py-2 text-[10px] text-[#ffb29a]"><strong>실시간 판단 보류:</strong> 활성 장중에는 Kiwoom WebSocket 체결만 현재가/신규진입 판단에 사용합니다. 종가·REST 값으로 대체하지 않습니다.</div>}
      {snapshot && <div className="mb-3 rounded-xl border border-[#26313c] bg-[#0a1016] p-2.5">
        <div className="flex justify-between gap-2 items-center mb-2"><div className="text-[11px] font-bold text-[#cbd6df]">{stock.realtimeSessionActive ? 'KRX·NXT 종가 스냅샷 · 참고용' : 'KRX·NXT 종가 스냅샷'}</div><div className="text-[9px] text-[#718091]">{snapshot.phase?.label || '-'} · {dateTimeKo(snapshot.fetchedAt)}</div></div>
        <div className="mb-2 rounded-lg border border-[#2a3540] bg-[#0d151d] px-2.5 py-2 text-[10px] text-[#9eafbf]"><strong className="text-[#d8e2eb]">계산기준 분리:</strong> {decisionBasisText}</div>
        <div className="grid grid-cols-3 gap-2">
          <Metric label={krx.final ? 'KRX 공식 종가' : 'KRX 현재/잠정'} value={krx.close ? `${fmt(krx.close)}원` : '-'} valueClass={tone(krx.changePct)} />
          <Metric label={nxt.final ? 'NXT 최종가' : 'NXT 현재/잠정'} value={nxt.available ? `${fmt(nxt.close)}원` : '미지원'} />
          <Metric label="NXT 괴리율" value={nxt.available ? `${Number(snapshot.nxtGapPct || 0) >= 0 ? '+' : ''}${Number(snapshot.nxtGapPct || 0).toFixed(2)}%` : '-'} valueClass={tone(snapshot.nxtGapPct)} />
          <Metric label="5일 이동평균" value={indicators.ma5 ? fmt(indicators.ma5) : '-'} />
          <Metric label="20일 이동평균" value={indicators.ma20 ? fmt(indicators.ma20) : '-'} />
          <Metric label="20일 거래량비" value={indicators.volumeRatio20 ? `${Number(indicators.volumeRatio20).toFixed(2)}x` : '-'} />
          <Metric label="고가 대비 종가" value={krx.high ? `${Number(indicators.closeFromHighPct || 0).toFixed(2)}%` : '-'} />
          <Metric label="누적 거래량" value={krx.volume ? fmt(krx.volume) : '-'} />
          <Metric label="거래대금" value={krx.tradeAmount ? fmtWon(krx.tradeAmount) : '-'} />
          <Metric label="마감 스마트머니" value={flowAvailability.smartMoney ? `${closingFlow.smartMoneyBehaviorState || closingFlow.smartMoneyState || 'NEUTRAL'} ${Number(closingFlow.smartMoneyConfidence || 0).toFixed(0)} · ${closingFlow.smartMoneyStatus === 'CHECKPOINT' ? '당일 종가근접 저장값' : '실시간'}` : '미수집 · 신뢰도 감점'} />
          <Metric label="마감 프로그램 순매수" value={flowAvailability.program ? fmtSignedShares(closingFlow.programNetQty) : '미수집'} valueClass={flowAvailability.program ? tone(closingFlow.programNetQty) : ''} />
          <Metric label="마감 외국인 순매수" value={flowAvailability.foreign ? fmtSignedShares(closingFlow.foreignNet) : '미수집'} valueClass={flowAvailability.foreign ? tone(closingFlow.foreignNet) : ''} />
          <Metric label="마감 기관 순매수" value={flowAvailability.institution ? fmtSignedShares(closingFlow.institutionNet) : '미수집'} valueClass={flowAvailability.institution ? tone(closingFlow.institutionNet) : ''} />
        </div>
        {closeDecision && <div className="mt-2 pt-2 border-t border-[#1d2731]">
          <div className="flex justify-between gap-3 items-center"><div><div className="text-[10px] text-[#8291a0]">종가 판단점수 · 확률 아님</div><div className={`text-lg font-black ${closeDecision.action === 'CLOSE_BUY' || closeDecision.action === 'HOLD' ? 'text-[#55e39a]' : 'text-[#f1cf62]'}`}>{closeDecision.score || 0}점 · {closeDisplayLabel(closeDecision)}</div></div>{snapshot.errors?.length > 0 && <div className="text-[9px] text-[#e5c45c] text-right">일부 조회 제한<br />{snapshot.errors.length}건</div>}</div>
          <details className="mt-2 rounded-lg border border-[#202b35] bg-[#0b1218] px-2.5 py-2 text-[10px]" open>
            <summary className="cursor-pointer font-bold text-[#aebdca]">점수 산출근거 보기</summary>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 mt-2">{(closeDecision.breakdown || []).map((item) => <div key={item.key} className="flex justify-between gap-2 border-b border-[#18212a] pb-1"><span><span className="text-[#9cabb9]">{item.label}</span><span className="block text-[9px] text-[#647383]">{item.detail}</span></span><strong className={item.points > 0 ? 'text-[#55e39a]' : item.points < 0 ? 'text-[#ff7b87]' : item.status === 'missing' ? 'text-[#e5c45c]' : 'text-[#9aa8b5]'}>{scorePoint(item.points)}</strong></div>)}</div>
          </details>
        </div>}
      </div>}
      <div className="grid grid-cols-3 gap-2">
        <Metric label={closingMode ? '종가점수' : '수익우선/품질'} value={closingMode ? `${closeDecision?.score || 0}` : `${signal.profitPriorityScore || 0}/${signal.qualityScore || 0}`} accent={closingMode ? (['CLOSE_BUY', 'HOLD'].includes(action) ? 'up' : undefined) : 'up'} />
        {!closingMode && <Metric label="급등 사전포착" value={`${signal.preSurgeScore || 0}점/${signal.preSurgeGroups || 0}그룹`} accent="up" />}
        {closingMode && closeDecision?.legacyScore != null && <Metric label="기존점수 비교" value={`${closeDecision.legacyScore} → ${closeDecision.score}`} />} 
        <Metric label="데이터 완전성" value={`${closingMode ? Number(snapshot?.completeness || 0).toFixed(0) : Number(signal.dataCompleteness || 0).toFixed(0)}%`} valueClass={closingMode && Number(snapshot?.completeness || 0) < 85 ? 'text-[#e5c45c]' : ''} />
        <Metric label="스마트머니 행동" value={closingMode
          ? (flowAvailability.smartMoney ? `${closingFlow.smartMoneyBehaviorState || closingFlow.smartMoneyState || 'NEUTRAL'} ${Number(closingFlow.smartMoneyConfidence || 0).toFixed(0)}` : '미수집')
          : `${signal.smartMoneyBehaviorState || stock.smartMoney?.behaviorState || signal.smartMoneyState || '-'} ${Number(signal.smartMoneyConfidence || stock.smartMoney?.confidence || 0).toFixed(0)}`} />
        {!closingMode && <Metric label="개미털기 추정지수" value={`${Number(signal.shakeoutScore || stock.smartMoney?.shakeoutScore || 0).toFixed(0)}/100`} valueClass={Number(signal.shakeoutScore || 0) >= 65 ? 'text-[#e5c45c]' : ''} />}
        {!closingMode && <Metric label="KRX 실시간" value={stock.venueFeeds?.KRX?.updatedAt ? `${(Number(stock.venueFeeds.KRX.ageMs || 0)/1000).toFixed(1)}초` : '미수신'} valueClass={stock.venueFeeds?.KRX?.ageMs > 5000 ? 'text-[#e5c45c]' : ''} />}
        {!closingMode && <Metric label="NXT 실시간" value={stock.venueFeeds?.NXT?.updatedAt ? `${(Number(stock.venueFeeds.NXT.ageMs || 0)/1000).toFixed(1)}초` : '미수신'} valueClass={stock.venueFeeds?.NXT?.ageMs > 5000 ? 'text-[#e5c45c]' : ''} />}
        <Metric label="체결강도" value={closedMetric(metrics.tradeStrength, (v) => v ? `${fmt(v)}%` : '미수신', Boolean(metrics.tradeStrength))} />
        <Metric label="5초 순공격대금" value={closedMetric(metrics.netBuyAmount5s, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.netBuyAmount5s) : ''} />
        <Metric label="매수 가속도" value={closedMetric(metrics.buyAcceleration, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.buyAcceleration) : ''} />
        <Metric label="1분 거래대금" value={closedMetric(metrics.turnover1m, fmtWon, Boolean(feedAges.tradeAt))} />
        <Metric label="1분 RVOL" value={closedMetric(metrics.rvol1m, (v) => v ? `${Number(v).toFixed(2)}x` : '미수신', Boolean(metrics.rvol1m))} />
        <Metric label="공격매수" value={closedMetric(metrics.buyRatio, (v) => v ? `${Number(v).toFixed(1)}%` : '미수신', Boolean(metrics.buyRatio))} />
        <Metric label="VWAP" value={closedMetric(metrics.vwap, (v) => v ? fmt(v) : '미수신', Boolean(metrics.vwap))} />
        <Metric label="호가 불균형" value={closedMetric(metrics.orderbookImbalance, (v) => v ? Number(v).toFixed(2) : '미수신', Boolean(feedAges.orderbookAt))} />
        <Metric label="프로그램 10초" value={closedMetric(metrics.programVelocity10s, fmtWon, Boolean(feedAges.programAt))} valueClass={!isClosedSnapshot ? tone(metrics.programVelocity10s) : ''} />
        <Metric label="대형체결 순매수" value={closedMetric(metrics.largeNetAmount1m, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.largeNetAmount1m) : ''} />
        <Metric label="외국계 변화" value={closedMetric(stock.broker?.foreignNetDelta, fmt, Boolean(feedAges.brokerAt))} valueClass={!isClosedSnapshot ? tone(stock.broker?.foreignNetDelta) : ''} />
        <Metric label="스프레드" value={closedMetric(metrics.spreadBps, (v) => v && v < 9000 ? `${Number(v).toFixed(1)}bp` : '미수신', Boolean(feedAges.orderbookAt))} />
      </div>
      {closingMode && <details className="mt-2 rounded-lg border border-[#202b35] bg-[#0b1218] px-2.5 py-2 text-[10px]"><summary className="cursor-pointer text-[#9eafbf]">데이터 완전성 구성 · KRX {completeness.groups?.krxCore || 0}/35 · 지표 {completeness.groups?.indicators || 0}/20 · NXT {completeness.groups?.nxt || 0}/15 · 마감수급 {completeness.groups?.closingFlow || 0}/30</summary>{completeness.missing?.length > 0 && <div className="mt-1 text-[#e5c45c]">미수집: {completeness.missing.join(', ')}</div>}<div className="mt-1 text-[#718091]">수급소스: {closingFlow.source || '-'} · 투자자수급 단위 주(단주) · 프로그램 주수량 우선 · 스마트머니 {closingFlow.smartMoneyStatus || (flowAvailability.smartMoney ? 'AVAILABLE' : 'MISSING')}{closingFlow.officialFlow?.errors?.length ? ` · REST 오류 ${closingFlow.officialFlow.errors.length}건` : ''}</div></details>}
      <div className="mt-3 space-y-1">
        {(reasonList || []).slice(0, 5).map((reason, index) => <div key={`r${index}`} className="text-[11px] text-[#72d9a5]"><CheckCircle2 size={11} className="inline mr-1" />{reason}</div>)}
        {(warningList || []).filter((reason) => !String(reason).includes('프로그램 순매수 급감') && !String(reason).includes('매도호가 우위') && !String(reason).includes('체결강도 약화')).slice(0, 3).map((reason, index) => <div key={`w${index}`} className="text-[11px] text-[#e5c45c]"><AlertTriangle size={11} className="inline mr-1" />{reason}</div>)}
        {(vetoList || []).slice(0, 3).map((reason, index) => <div key={`v${index}`} className="text-[11px] text-[#ff7b87]"><X size={11} className="inline mr-1" />{reason}</div>)}
      </div>
      {!closingMode && stock.entryRestricted && <div className="mt-2 rounded-lg border border-[#665218] bg-[#2d2610] px-2.5 py-2 text-[10px] text-[#f6d365]">{stock.entryRestrictionReason || '좋은 BUY 신호는 유지하되 현재 계좌 위험한도로 신규진입만 제한됩니다.'}</div>}
      <div className="mt-3 pt-2 border-t border-[#18212a] text-[10px] text-[#718091] flex flex-wrap gap-x-3 gap-y-1"><span>체결 {feedAges.tradeAt ? timeAgo(feedAges.tradeAt) : '장 종료/미수신'}</span><span>종가 {feedAges.snapshotAt ? timeAgo(feedAges.snapshotAt) : '-'}</span><span>호가 {timeAgo(feedAges.orderbookAt)}</span><span>프로그램 {timeAgo(feedAges.programAt)}</span><span>거래원 {timeAgo(feedAges.brokerAt)}</span><span>표시시장 {stock.market || '-'}</span><span>실제체결 {stock.lastTradeVenue === 'UNKNOWN' || !stock.lastTradeVenue ? (stock.marketMode === 'SOR' ? 'SOR·식별대기' : stock.marketMode || '-') : stock.lastTradeVenue}</span>{stock.lastTradeVenueSource && <span>시장근거 {stock.lastTradeVenueSource}</span>}{stock.tier === 'LIGHT' && <span>승격점수 {stock.promotionScore || 0}</span>}</div>
      {plan && <details className="mt-3 text-xs" open={closingMode}><summary className="cursor-pointer text-[#8ea0b2] flex items-center gap-1"><ChevronDown size={13} />{closingMode ? '종가 기준 매매계획' : '신호 발생 시 위험계획'}</summary><div className="grid grid-cols-4 gap-1 mt-2"><Plan label="손절" value={fmt(plan.stop)} /><Plan label="1차" value={fmt(plan.target1)} /><Plan label="2차" value={fmt(plan.target2)} /><Plan label="3차" value={fmt(plan.target3)} /></div><div className={`mt-2 rounded-lg border px-2.5 py-2 ${risk.halted ? 'border-[#6f2934] bg-[#2a1218] text-[#ff8d97]' : 'border-[#274535] bg-[#102019] text-[#75d9a8]'}`}>{risk.halted ? '계좌 손실 제한으로 신규매수 차단' : `권장 최대 ${fmt(suggestedQty)}주 · 1회 위험예산 ${fmt(riskBudget)}원`}</div></details>}
    </div>
  </section>;
}
function Metric({ label, value, accent, valueClass = '' }) { return <div className="metric"><div>{label}</div><strong className={`${accent === 'up' ? 'text-[#55e39a]' : accent === 'down' ? 'text-[#ff7b87]' : ''} ${valueClass}`}>{value}</strong></div>; }
function Plan({ label, value }) { return <div className="bg-[#0b1117] rounded-md p-1.5 text-center"><div className="text-[9px] text-[#718091]">{label}</div><div className="font-mono mt-0.5">{value}</div></div>; }


function returnTone(value) {
  return Number(value) > 0 ? 'text-[#ff6b6b]' : Number(value) < 0 ? 'text-[#4ea1ff]' : 'text-[#d5dde5]';
}
function returnText(value) {
  if (value == null || !Number.isFinite(Number(value))) return '-';
  const n = Number(value);
  return `${n > 0 ? '+' : ''}${n.toFixed(2)}%`;
}
function ledgerStatusTone(row) {
  if (row.status === 'BUY_ACTIVE') return 'border-[#1c6b46] bg-[#10271d] text-[#55e39a]';
  if (row.status === 'OBSERVING') return 'border-[#6a571b] bg-[#2a240f] text-[#f1cf62]';
  if (row.status === 'CLOSED') return 'border-[#33404d] bg-[#121a23] text-[#aebdca]';
  if (row.status === 'CANCELLED') return 'border-[#33404d] bg-[#121a23] text-[#aebdca]';
  if (row.status === 'SELL_ONLY' || String(row.signalStatus || '').includes('매도')) return 'border-[#7a2732] bg-[#311219] text-[#ff7b87]';
  return 'border-[#29323d] bg-[#111820] text-[#93a4b5]';
}
function liveLedgerRows(data) {
  const stocks = new Map((data.stocks || []).map((stock) => [stock.code, stock]));
  return (data.tradeLedger?.rows || []).map((row) => {
    if (row.status === 'CLOSED' || row.status === 'SELL_ONLY') return row;
    const stock = stocks.get(row.code) || null;
    const currentPrice = stock?.realtimeEligible === true ? Number(stock.realtimePrice || stock.price || 0) : 0;
    const returnPct = Number(row.entryPrice) > 0 && currentPrice > 0 ? (currentPrice - Number(row.entryPrice)) / Number(row.entryPrice) * 100 : null;
    return { ...row, currentPrice: currentPrice || null, returnPct, realtimeEligible: stock?.realtimeEligible === true };
  });
}
function observationStrengthView(row) {
  const obs = row?.observationStrength || {};
  const trend = String(obs.trend || 'NEW');
  const toneClass = trend === 'STRONG_UP' || trend === 'UP'
    ? 'text-[#55e39a]'
    : trend === 'DOWN' ? 'text-[#ff9b9b]' : 'text-[#9eafbf]';
  const label = obs.label || '초기관찰';
  const arrows = obs.arrows || '·';
  const adj = Number(obs.rankingAdjustment || 0);
  return { ...obs, trend, toneClass, label, arrows, adj };
}
function firstObservedPrice(row) {
  const events = Array.isArray(row?.timeline) ? row.timeline : [];
  const firstEarly = events.find((event) => event.action === 'EARLY' && Number(event.price) > 0);
  return Number(firstEarly?.price || 0) || null;
}
function entryGuidance(stock, row, signalSettings = {}) {
  const signal = stock?.signal || {};
  const metrics = signal.metrics || {};
  const plan = signal.plan || null;
  const realtimeOk = stock?.realtimeEligible === true && stock?.realtimePriceSource === 'KIWOOM_WEBSOCKET_TRADE_AUTO';
  const current = realtimeOk ? Number(stock?.realtimePrice || stock?.price || 0) : 0;
  const first = firstObservedPrice(row) || (row?.entrySignalAt ? Number(row?.entryBasisPrice || 0) || null : null);
  const action = row?.status === 'BUY_ACTIVE' ? 'BUY' : realtimeOk && signal.action === 'BUY' ? 'BUY' : realtimeOk && signal.action === 'EARLY' ? 'EARLY' : 'WAIT';
  if (!(current > 0)) return { action, firstObservedPrice: first, waitingLow: null, waitingHigh: null, entry: null, stop: null, target1: null, target2: null, target3: null, rr: null };
  if (action === 'BUY') {
    return {
      action, firstObservedPrice: first,
      waitingLow: null, waitingHigh: null,
      entry: Number(row?.entryPrice || plan?.entry || current) || null,
      stop: Number(row?.stopPrice || plan?.stop || 0) || null,
      target1: Number(row?.target1 || plan?.target1 || 0) || null,
      target2: Number(row?.target2 || plan?.target2 || 0) || null,
      target3: Number(row?.target3 || plan?.target3 || 0) || null,
      rr: Number(row?.expectedRewardRisk || plan?.expectedRewardRisk || 0) || null,
    };
  }
  if (action !== 'EARLY' || !plan) return { action, firstObservedPrice: first, waitingLow: null, waitingHigh: null, entry: null, stop: null, target1: null, target2: null, target3: null, rr: null };
  const stop = Number(plan.stop || 0);
  const risk = stop > 0 && current > stop ? current - stop : current * 0.008;
  const vwap = Number(metrics.vwap || 0);
  const recentLow = Number(metrics.recentLow || 0);
  const spreadBps = Number(metrics.spreadBps || 0);
  const maxVwapExtensionPct = Number(signalSettings?.maxVwapExtensionPct || 1.6);
  const pullback = Math.min(risk * 0.35, current * 0.006);
  const spreadBuffer = current * Math.max(0.001, Math.min(0.003, (spreadBps > 0 && spreadBps < 500 ? spreadBps / 10000 * 1.5 : 0.0015)));
  let low = current - pullback;
  if (vwap > 0 && vwap <= current) low = Math.max(low, vwap);
  if (recentLow > 0 && recentLow < current) low = Math.max(low, recentLow);
  let high = current + spreadBuffer;
  if (vwap > 0) high = Math.min(high, vwap * (1 + maxVwapExtensionPct / 100));
  if (high < low) high = low;
  return {
    action, firstObservedPrice: first,
    waitingLow: Math.round(low), waitingHigh: Math.round(high),
    entry: null, stop: Number(plan.stop || 0) || null,
    target1: Number(plan.target1 || 0) || null,
    target2: Number(plan.target2 || 0) || null,
    target3: Number(plan.target3 || 0) || null,
    rr: Number(plan.expectedRewardRisk || 0) || null,
  };
}
function liveGrowthEligible(stock, row) {
  if (row?.status === 'BUY_ACTIVE') return true; // 실제 포지션 기록은 유지하되 현재가는 realtimeEligible일 때만 갱신한다.
  if (stock?.realtimeEligible !== true) return false;
  if (stock?.signal?.action === 'BUY') return true;
  if (row?.status !== 'OBSERVING' && stock?.signal?.action !== 'EARLY') return false;
  // OBSERVING 기록이 남아 있어도 현재 실시간 신호가 WAIT/BLOCKED로 약해지면 후보화면에서 즉시 제외한다.
  return stock?.signal?.action === 'EARLY' && !stock?.signal?.negativePressureBlock && !stock?.signal?.vetoes?.length;
}
function ObservationStrengthBadge({ row, compact = false }) {
  const obs = observationStrengthView(row);
  const sampleCount = Number(obs.sampleCount || row?.observationSamples?.length || 0);
  return <div className={`${compact ? 'text-[9px]' : 'text-[10px]'} ${obs.toneClass}`}>
    <span className="font-black">관찰강화 {obs.arrows} {obs.label}</span>
    <span className="text-[#718091]"> · 측정 {sampleCount}회 · 보정 {obs.adj > 0 ? '+' : ''}{obs.adj}</span>
    {!compact && <div className="text-[9px] text-[#718091] mt-0.5">사전포착 Δ{Number(obs.scoreDelta || 0) > 0 ? '+' : ''}{Number(obs.scoreDelta || 0).toFixed(0)} · 체결강도 Δ{Number(obs.tradeStrengthDelta || 0) > 0 ? '+' : ''}{Number(obs.tradeStrengthDelta || 0).toFixed(0)} · 관찰횟수 자체는 확률 가산 없음</div>}
  </div>;
}

function ManagedSignalTable({ data }) {
  const portfolio = data.managedSignals || { rows: [], regime: {}, target: {} };
  const stockMap = new Map((data.stocks || []).map((stock) => [stock.code, stock]));
  const regime = portfolio.regime || {};
  const target = portfolio.target || {};
  // dashboard 전체 재조회(30초)를 기다리지 않고 SSE로 새 BUY/EARLY가 오면 즉시 관리테이블에 반영한다.
  const stageRank = { BUY: 0, BUY_MANAGE: 0, PRE_BUY: 1, PRE_IGNITION: 2, EARLY_STRONG: 3, EARLY: 4, RESERVE: 5 };
  const rowMap = new Map((portfolio.rows || []).map((row) => [row.code, row]));
  for (const stock of data.stocks || []) {
    const sig = stock.signal || {};
    const existing = rowMap.get(stock.code);
    if (stock.realtimeEligible !== true) {
      if (existing && !existing.boughtActive && existing.stage !== 'BUY_MANAGE') rowMap.delete(stock.code);
      continue;
    }
    if (existing && !existing.reserveOnly && !existing.boughtActive && existing.stage !== 'BUY_MANAGE' && !['BUY','EARLY'].includes(sig.action)) rowMap.delete(stock.code);
    if (!['BUY','EARLY'].includes(sig.action) || String(stock.activeTier || stock.tier || '') !== 'FOCUS') continue;
    const stage = sig.confirmed && sig.action === 'BUY' ? 'BUY' : sig.action === 'BUY' ? 'PRE_BUY' : sig.preIgnitionEligible ? 'PRE_IGNITION' : sig.preSurgeEligible ? 'EARLY_STRONG' : 'EARLY';
    const behavior = String(sig.smartMoneyBehaviorState || sig.metrics?.smartMoneyBehaviorState || 'NEUTRAL');
    if (['DISTRIBUTION','EXHAUSTION'].includes(behavior) || sig.negativePressureBlock || sig.crossVenueConflict) continue;
    const managementScore = Math.max(0, Math.min(100, Math.round(Number(sig.qualityScore || 0) * 0.4 + Number(sig.profitPriorityScore || 0) * 0.3 + Number(sig.preSurgeScore || 0) * 0.3)));
    rowMap.set(stock.code, { ...(existing || {}), code: stock.code, name: stock.name || stock.code, stage, stageLabel: stage === 'BUY' ? 'BUY 확정' : stage === 'PRE_BUY' ? 'PRE-BUY' : stage === 'PRE_IGNITION' ? '점화전 사전포착' : stage === 'EARLY_STRONG' ? '급등 직전 확인' : '조기관찰', managementScore: Math.max(Number(existing?.managementScore || 0), managementScore), qualityScore: Number(sig.qualityScore || 0), profitPriorityScore: Number(sig.profitPriorityScore || 0), preSurgeScore: Number(sig.preSurgeScore || 0), smartMoneyBehaviorState: behavior, smartMoneyConfidence: Number(sig.smartMoneyConfidence || sig.metrics?.smartMoneyConfidence || 0), shakeoutScore: Number(sig.shakeoutScore || sig.metrics?.shakeoutScore || 0), dataCompleteness: Number(sig.dataCompleteness || sig.metrics?.dataCompleteness || existing?.dataCompleteness || 0), expectedRewardRisk: Number(sig.plan?.expectedRR || sig.plan?.rr || sig.expectedRewardRisk || existing?.expectedRewardRisk || 0), currentPrice: Number(stock.realtimePrice || stock.price || 0), entryBasisPrice: Number(existing?.entryBasisPrice || sig.plan?.entry || stock.realtimePrice || stock.price || 0), entryBasisLabel: existing?.entryBasisLabel || (stage === 'BUY' ? 'BUY 진입가' : '관찰기준가'), signalAt: existing?.signalAt || sig.evaluatedAt || new Date().toISOString(), reserveOnly: false });
  }
  const rows = [...rowMap.values()].sort((a,b) => (stageRank[a.stage] ?? 9) - (stageRank[b.stage] ?? 9) || Number(b.managementScore || 0) - Number(a.managementScore || 0)).slice(0, Number(target.max || 6)).map((row,index)=>({ ...row, rank:index+1 }));
  const stageTone = (stage) => stage === 'BUY' || stage === 'BUY_MANAGE'
    ? 'text-[#55e39a]'
    : stage === 'PRE_BUY' || stage === 'PRE_IGNITION' || stage === 'EARLY_STRONG'
      ? 'text-[#f1cf62]'
      : stage === 'EARLY' ? 'text-[#d9c47d]' : 'text-[#8ea0b2]';
  return <section className="panel overflow-hidden">
    <div className="px-3 py-2.5 border-b border-[#202832] flex flex-wrap items-start justify-between gap-2">
      <div><h2 className="section-title"><TrendingUp size={15} />실시간 신호 관리 테이블</h2><div className="text-[10px] text-[#718091] mt-1">정상장 목표 {target.min ?? 4}~{target.max ?? 6}개 · 장중 EARLY→PRE-BUY→BUY 단계 표시 · BUY 확정 시 진입가 고정</div></div>
      <div className="text-right"><span className="badge">{regime.label || '시장판정중'}</span><div className="text-[9px] text-[#718091] mt-1">상승폭 {Number(regime.breadthPct || 0).toFixed(0)}% · 평균등락 {Number(regime.averageChangePct || 0).toFixed(2)}%</div></div>
    </div>
    <div className="overflow-x-auto">
      <table className="ledger-table min-w-[1240px]">
        <thead><tr><th>순위</th><th>단계</th><th>종목</th><th>관리점수</th><th>스마트머니</th><th>데이터</th><th>R/R</th><th>현재가</th><th>진입/기준가</th><th>수익률</th><th>등락률</th><th>KRX</th><th>NXT</th><th>신호시각</th></tr></thead>
        <tbody>{rows.length === 0 && <tr><td colSpan="14" className="text-center text-[#718091] py-8">{regime.code === 'CLOSED' ? '거래시간 외에는 신규 실시간 신호를 비웁니다. 장중 fresh 0B 체결이 들어오면 EARLY/PRE-BUY/BUY가 자동 표시됩니다.' : regime.code === 'WARMUP' ? '실시간 체결 워밍업 중입니다. fresh 0B가 확보되면 후보와 진입대기구간을 계산합니다.' : '현재 안전조건을 통과한 관리 신호가 없습니다. 신호 수를 맞추기 위해 BUY 조건을 강제로 낮추지 않습니다.'}</td></tr>}{rows.map((row) => { const live = stockMap.get(row.code) || {}; const realtimeOk = live.realtimeEligible === true; const currentPrice = realtimeOk ? Number(live.realtimePrice || live.price || 0) : 0; const liveChange = realtimeOk && live.changePct != null ? Number(live.changePct) : null; const liveReturn = row.entryBasisPrice > 0 && currentPrice > 0 ? ((currentPrice - row.entryBasisPrice) / row.entryBasisPrice * 100) : null; const krxPrice = Number(live.venueFeeds?.KRX?.price || 0); const nxtPrice = Number(live.venueFeeds?.NXT?.price || 0); const krxFresh = Boolean(live.venueFeeds?.KRX?.updatedAt && Date.now() - Number(live.venueFeeds.KRX.updatedAt) <= 5000); const nxtFresh = Boolean(live.venueFeeds?.NXT?.updatedAt && Date.now() - Number(live.venueFeeds.NXT.updatedAt) <= 5000); const guidance = entryGuidance(live, row, data.settings?.signal || {}); const entryText = (row.stage === 'BUY' || row.stage === 'BUY_MANAGE') && guidance.entry ? fmt(guidance.entry) : guidance.waitingLow && guidance.waitingHigh ? `${fmt(guidance.waitingLow)}~${fmt(guidance.waitingHigh)}` : row.entryBasisPrice ? fmt(row.entryBasisPrice) : '-'; const entryLabel = (row.stage === 'BUY' || row.stage === 'BUY_MANAGE') && guidance.entry ? '확정 진입가' : guidance.waitingLow && guidance.waitingHigh ? '매수대기구간' : (row.entryBasisLabel || '-'); return <tr key={`managed-${row.code}`}>
          <td className="text-center font-black">{row.rank}</td>
          <td><div className={`font-black whitespace-nowrap ${stageTone(row.stage)}`}>{row.stageLabel}</div>{row.reserveOnly && <div className="text-[9px] text-[#718091]">관찰용</div>}</td>
          <td><strong className="whitespace-nowrap">{row.name}</strong><div className="text-[9px] text-[#718091]">{row.code}</div></td>
          <td className="text-right"><strong>{fmt(row.managementScore)}점</strong><div className="text-[9px] text-[#718091]">품질 {fmt(row.qualityScore)} · 수익 {fmt(row.profitPriorityScore)} · 사전 {fmt(row.preSurgeScore)}</div></td>
          <td><strong className="whitespace-nowrap">{row.smartMoneyBehaviorState}</strong><div className="text-[9px] text-[#718091]">증거신뢰 {fmt(row.smartMoneyConfidence)}{row.shakeoutScore ? ` · 털기지수 ${fmt(row.shakeoutScore)}` : ''}</div></td>
          <td className={`text-right font-black ${Number(row.dataCompleteness || 0) >= 85 ? 'text-[#55e39a]' : Number(row.dataCompleteness || 0) >= 75 ? 'text-[#f1cf62]' : 'text-[#ef7373]'}`}>{fmt(row.dataCompleteness)}%</td>
          <td className="text-right font-mono">{Number(row.expectedRewardRisk || 0) > 0 ? `${Number(row.expectedRewardRisk).toFixed(2)}R` : '-'}</td>
          <td className="font-mono text-right font-black">{currentPrice ? fmt(currentPrice) : '-'}</td>
          <td className="font-mono text-right">{entryText}<div className="text-[9px] text-[#718091]">{entryLabel}</div></td>
          <td className={`font-black text-right ${returnTone(liveReturn)}`}>{returnText(liveReturn)}</td>
          <td className={`font-black text-right ${liveChange == null ? 'text-[#718091]' : tone(liveChange)}`}>{liveChange == null ? '-' : `${liveChange > 0 ? '+' : ''}${liveChange.toFixed(2)}%`}</td>
          <td className="font-mono text-right">{krxPrice ? fmt(krxPrice) : '-'}<div className={`text-[9px] ${krxFresh ? 'text-[#55e39a]' : 'text-[#718091]'}`}>{krxFresh ? '실시간' : '대기'}</div></td>
          <td className="font-mono text-right">{nxtPrice ? fmt(nxtPrice) : '-'}<div className={`text-[9px] ${nxtFresh ? 'text-[#55e39a]' : 'text-[#718091]'}`}>{nxtFresh ? '실시간' : '대기'}</div></td>
          <td className="whitespace-nowrap text-[10px]">{dateTimeKo(row.signalAt)}</td>
        </tr>; })}</tbody>
      </table>
    </div>
    <div className="px-3 py-2 text-[9px] text-[#7e8c99] border-t border-[#202832]">{portfolio.note || '관리점수는 확률이 아닙니다.'} · 스마트머니 신뢰도는 통계적 승률이 아니라 독립 증거의 일치도입니다. · 수익률은 BUY는 진입가, EARLY/예비신호는 최초포착가 또는 관찰기준가 대비입니다.</div>
  </section>;
}

function ActiveSignalBoard({ data }) {
  const allRows = liveLedgerRows(data).filter((row) => ['BUY_ACTIVE', 'OBSERVING'].includes(row.status));
  const stocks = data.stocks || [];
  const stockMap = new Map(stocks.map((stock) => [stock.code, stock]));
  const activeRows = allRows.filter((row) => liveGrowthEligible(stockMap.get(row.code) || {}, row));
  const activeMap = new Map(activeRows.map((row) => [row.code, row]));
  const codes = new Set([
    ...activeRows.map((row) => row.code),
    ...stocks.filter((stock) => stock.realtimeEligible === true && ['BUY', 'EARLY'].includes(stock.signal?.action) && liveGrowthEligible(stock, activeMap.get(stock.code))).map((stock) => stock.code),
  ]);
  const cards = [...codes].map((code) => {
    const stock = stockMap.get(code) || {};
    const row = activeMap.get(code) || null;
    const realtimeSignalUsable = stock.realtimeEligible === true;
    const rawAction = realtimeSignalUsable ? stock.signal?.action : (row?.status === 'BUY_ACTIVE' ? 'BUY' : 'WAIT');
    const action = realtimeSignalUsable && ['BUY', 'EARLY'].includes(rawAction) ? rawAction : (row?.status === 'BUY_ACTIVE' ? 'BUY' : 'WAIT');
    const confirmed = Boolean(realtimeSignalUsable && stock.signal?.confirmed);
    const preSurge = Number(stock.signal?.preSurgeScore || row?.preSurgeScore || 0);
    const label = action === 'BUY'
      ? (confirmed ? (stock.entryRestricted ? 'BUY 확정 · 신규진입 제한' : '매수신호 확정') : '매수신호 확인중')
      : stock.signal?.preSurgeEligible
        ? '급등 사전포착 · 수급확인'
        : stock.signal?.earlyDiscoveryEligible
          ? (stock.signal?.smartMoneyFeedReady ? '급등 조짐 · 강한 관찰' : '급등 조짐 · 수급확인중')
          : '상승 조기관찰';
    const priority = action === 'BUY' && confirmed ? 0 : stock.signal?.preSurgeEligible ? 1 : stock.signal?.earlyDiscoveryEligible ? 2 : action === 'BUY' ? 3 : 4;
    const firstAt = row?.entrySignalAt || row?.createdAt || null;
    return { code, stock, row, action, label, priority, firstAt };
  }).filter((item) => item.action !== 'WAIT').sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    const atA = a.firstAt ? new Date(a.firstAt).getTime() : 0;
    const atB = b.firstAt ? new Date(b.firstAt).getTime() : 0;
    if (atA && atB && atA !== atB) return atB - atA;
    return String(a.code).localeCompare(String(b.code));
  }).slice(0, 8);
  return <section className="panel overflow-hidden">
    <div className="px-3 py-2.5 border-b border-[#202832] flex items-center justify-between gap-2"><div><h2 className="section-title"><TrendingUp size={15} />급등 사전포착 · 매수후보</h2><div className="text-[10px] text-[#718091] mt-1">최초포착가 → 매수대기구간 → BUY 확정 진입가·손절·목표가 · 약화 후보 즉시 숨김 · 일반 매도잡신호는 숨김</div></div><span className="badge">수익추구 중심</span></div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-3">
      {cards.length === 0 && <div className="empty md:col-span-2">현재 살아 있는 급등 사전포착/매수 후보가 없습니다.</div>}
      {cards.map(({ code, stock, row, action, label }) => {
        const currentPrice = stock.realtimeEligible === true ? Number(stock.realtimePrice || stock.price || 0) : 0;
        const quality = Number(stock.signal?.qualityScore || row?.qualityScore || 0);
        const profit = Number(stock.signal?.profitPriorityScore || row?.profitPriorityScore || 0);
        const preSurge = Number(stock.signal?.preSurgeScore || row?.preSurgeScore || 0);
        const guidance = entryGuidance(stock, row, data.settings?.signal || {});
        const waitingText = guidance.waitingLow && guidance.waitingHigh ? `${fmt(guidance.waitingLow)}~${fmt(guidance.waitingHigh)}원` : '-';
        const firstText = guidance.firstObservedPrice ? `${fmt(guidance.firstObservedPrice)}원` : '-';
        return <div key={`sig-${code}`} className={`rounded-xl border px-3 py-2 ${signalTone(action)}`}>
          <div className="flex justify-between gap-2"><strong>{stock.name || row?.name || code}</strong><span className="text-xs font-bold">{label}</span></div>
          {action === 'EARLY' ? <>
            <div className="grid grid-cols-3 gap-2 mt-2 text-[10px]"><div>현재가<strong className="block text-sm">{currentPrice ? `${fmt(currentPrice)}원` : '-'}</strong></div><div>최초포착가<strong className="block text-sm">{firstText}</strong></div><div>매수대기구간<strong className="block text-sm text-[#f1cf62]">{waitingText}</strong></div></div>
            <div className="mt-1 text-[9px] text-[#9eafbf]">아직 BUY 확정 아님 · 대기구간은 VWAP·최근 변동폭·스프레드·추격제한을 이용한 관찰용 참고구간</div>
          </> : <>
            <div className="grid grid-cols-3 gap-2 mt-2 text-[10px]"><div>현재가<strong className="block text-sm">{currentPrice ? `${fmt(currentPrice)}원` : '-'}</strong></div><div>확정 진입가<strong className="block text-sm text-[#55e39a]">{guidance.entry ? `${fmt(guidance.entry)}원` : '-'}</strong></div><div>손절가<strong className="block text-sm">{guidance.stop ? `${fmt(guidance.stop)}원` : '-'}</strong></div></div>
            <div className="grid grid-cols-4 gap-2 mt-2 text-[10px]"><div>T1<strong className="block">{guidance.target1 ? fmt(guidance.target1) : '-'}</strong></div><div>T2<strong className="block">{guidance.target2 ? fmt(guidance.target2) : '-'}</strong></div><div>T3<strong className="block">{guidance.target3 ? fmt(guidance.target3) : '-'}</strong></div><div>R/R<strong className="block">{guidance.rr ? `${Number(guidance.rr).toFixed(1)}R` : '-'}</strong></div></div>
          </>}
          <div className="mt-1 text-[9px] opacity-75">실시간 {stock.realtimeVenue || '-'} · 실시간체결 · {stock.realtimeTradeAgeMs != null ? `${(Number(stock.realtimeTradeAgeMs)/1000).toFixed(1)}초전` : '미수신'}</div>
          <div className="mt-1 text-[9px] opacity-80">점화전 {Number(stock.signal?.preIgnitionScore || row?.preIgnitionScore || 0)}점 · 사전포착 {preSurge}점 · 수익우선 {profit}점 · 품질 {quality}점{stock.entryRestricted ? ' · 신규진입 제한' : ''}{row?.source === 'SIGNAL' && !row?.verified ? ' · 미검증' : ''}</div>
          {action === 'EARLY' && row && <div className="mt-1"><ObservationStrengthBadge row={row} compact /></div>}
        </div>;
      })}
    </div>
  </section>;
}

function timelineActionTone(action) {
  return signalTone(action === 'RISK' ? 'RISK' : action === 'EARLY_SELL' ? 'EARLY_SELL' : action === 'SELL' ? 'SELL' : action === 'BUY' ? 'BUY' : 'EARLY');
}
function timelineCompact(row) {
  const events = Array.isArray(row.timeline) ? row.timeline.filter((event) => ['EARLY', 'BUY'].includes(event.action)).slice(-6) : [];
  if (!events.length) return <span className="text-[#667584]">-</span>;
  return <div className="flex items-center gap-1 min-w-max">{events.map((event, index) => <span key={`${row.id}-tl-${index}`} className="inline-flex items-center gap-1"><span className={`rounded border px-1.5 py-0.5 text-[9px] font-bold ${timelineActionTone(event.action)}`}>{new Date(event.at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })} {event.label || event.action}</span>{index < events.length - 1 && <span className="text-[#566575]">→</span>}</span>)}</div>;
}
function growthStatusLabel(row) {
  if (row.source === 'POSITION') return row.status === 'closed' ? '실제매매 종료' : '실제 보유';
  if (row.status === 'BUY_ACTIVE') return '매수신호 발생중';
  if (row.status === 'OBSERVING') return '상승 조기관찰';
  if (row.status === 'CANCELLED') return '지난 관찰';
  if (row.status === 'CLOSED') return '신호 종료';
  return row.signalStatus || row.status;
}
function isGrowthLedgerRow(row) {
  const timeline = Array.isArray(row.timeline) ? row.timeline : [];
  const hasGrowthEvent = timeline.some((event) => ['EARLY', 'BUY'].includes(event.action));
  return row.source === 'POSITION'
    || hasGrowthEvent
    || row.status === 'BUY_ACTIVE'
    || Number(row.entryPrice || 0) > 0
    || String(row.signalStatus || '').includes('매수')
    || String(row.signalStatus || '').includes('조기관찰');
}
function ledgerImportance(row, stockMap) {
  const stock = stockMap.get(row.code) || {};
  const liveSignalUsable = stock.realtimeEligible === true;
  const action = liveSignalUsable && ['BUY', 'EARLY'].includes(stock.signal?.action)
    ? stock.signal.action
    : (row.status === 'BUY_ACTIVE' ? 'BUY' : row.status === 'OBSERVING' ? 'EARLY' : null);
  const confirmed = Boolean(liveSignalUsable && stock.signal?.confirmed);
  const preSurge = Number(stock.signal?.preSurgeScore || 0);
  let priority = 6;
  if (action === 'BUY' && confirmed) priority = 0;
  else if (liveSignalUsable && action === 'EARLY' && stock.signal?.preSurgeEligible) priority = 1;
  else if (liveSignalUsable && action === 'EARLY' && stock.signal?.earlyDiscoveryEligible) priority = 2;
  else if (action === 'BUY') priority = 3;
  else if (action === 'EARLY' || row.status === 'OBSERVING') priority = 4;
  if (row.status === 'CLOSED' || row.status === 'CANCELLED') priority = 9;
  const observationAdjustment = Number(row.observationStrength?.rankingAdjustment || 0);
  const score = action === 'EARLY'
    ? Math.max(preSurge + observationAdjustment, Number(stock.signal?.profitPriorityScore || row.profitPriorityScore || 0))
    : Number(stock.signal?.profitPriorityScore || row.profitPriorityScore || stock.signal?.qualityScore || row.qualityScore || 0);
  return { priority, score };
}

function LedgerTab({ data }) {
  const [filter, setFilter] = useState('active');
  const [sortMode, setSortMode] = useState('importance');
  const rows = liveLedgerRows(data).filter(isGrowthLedgerRow);
  const stockMap = new Map((data.stocks || []).map((stock) => [stock.code, stock]));
  const filtered = rows.filter((row) => {
    if (filter === 'active') {
      if (row.status === 'BUY_ACTIVE') return true;
      if (row.status === 'OBSERVING') return liveGrowthEligible(stockMap.get(row.code) || {}, row);
      return false;
    }
    if (filter === 'closed') return ['CLOSED', 'CANCELLED'].includes(row.status);
    if (filter === 'buy') return row.status === 'BUY_ACTIVE' || String(row.signalStatus || '').includes('매수');
    return true;
  }).sort((a, b) => {
    if (sortMode === 'latest') return new Date(b.lastSignalAt || b.updatedAt || b.createdAt || 0) - new Date(a.lastSignalAt || a.updatedAt || a.createdAt || 0);
    const pa = ledgerImportance(a, stockMap); const pb = ledgerImportance(b, stockMap);
    return pa.priority - pb.priority || pb.score - pa.score || new Date(b.lastSignalAt || b.updatedAt || 0) - new Date(a.lastSignalAt || a.updatedAt || 0);
  });
  const closed = rows.filter((row) => row.status === 'CLOSED' && Number.isFinite(Number(row.returnPct)));
  const wins = closed.filter((row) => Number(row.returnPct) > 0).length;
  const averageReturn = closed.length ? closed.reduce((sum, row) => sum + Number(row.returnPct || 0), 0) / closed.length : null;
  return <div className="space-y-4">
    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
      <Summary label="상승신호 발생중" value={rows.filter((row) => ['BUY_ACTIVE','OBSERVING'].includes(row.status)).length} icon={Activity} positive />
      <Summary label="종료기록" value={closed.length} icon={BookOpen} />
      <Summary label="승리기록" value={wins} icon={TrendingUp} positive />
      <Summary label="종료 승률" value={closed.length ? `${(wins / closed.length * 100).toFixed(1)}%` : '-'} icon={Gauge} />
      <Summary label="평균 수익률" value={averageReturn == null ? '-' : returnText(averageReturn)} icon={CircleDollarSign} valueClass={returnTone(averageReturn)} />
    </div>
    <Notice icon={TrendingUp}>종합기록부는 EARLY → BUY 중심입니다. 관찰 횟수 자체는 상승확률로 보지 않고, 사전포착점수·체결·스마트머니가 함께 개선될 때만 관찰우선도에 소폭 가산합니다. 현재 신호가 WAIT/BLOCKED로 약해진 OBSERVING 종목은 발생중/매수후보 화면에서 즉시 빠지고 지난 관찰에서만 확인합니다.</Notice>
    <Notice icon={AlertTriangle}>SIGNAL은 실제 주문 체결이 아니라 신호 발생가 기준 가상 성과이며, POSITION은 사용자가 입력한 실제 체결기록입니다. 200건 전에는 미검증입니다.</Notice>
    <section className="panel overflow-hidden">
      <div className="p-3 border-b border-[#202832] space-y-2"><div className="flex flex-wrap gap-2 items-center justify-between"><div><h2 className="section-title"><BookOpen size={16} />종합 발생기록부</h2><p className="help">급등 조짐 → 급등 사전포착 → BUY 확정 순으로 보여줍니다. 관찰강화 ↑↑↑는 반복횟수가 아니라 점수·체결·스마트머니의 동시 개선을 뜻합니다.</p></div><div className="flex gap-1 overflow-x-auto"><button className={sortMode === 'importance' ? 'primary-btn' : 'secondary-btn'} onClick={() => setSortMode('importance')}>중요도순</button><button className={sortMode === 'latest' ? 'primary-btn' : 'secondary-btn'} onClick={() => setSortMode('latest')}>최신발생순</button></div></div><div className="flex gap-1 overflow-x-auto">{[['active','발생중'],['buy','매수확정'],['all','상승신호 전체'],['closed','지난 관찰']].map(([id,label]) => <button key={id} className={filter === id ? 'primary-btn' : 'secondary-btn'} onClick={() => setFilter(id)}>{label}</button>)}</div></div>
      <div className="overflow-x-auto">
        <table className="ledger-table">
          <thead><tr><th>구분</th><th>상태</th><th>종목</th><th>관찰강화</th><th>신호진행</th><th>진입시점</th><th>종료시점</th><th>현재가</th><th>최초포착가</th><th>진입가</th><th>종료가</th><th>수익률</th><th>점수</th></tr></thead>
          <tbody>{filtered.length === 0 && <tr><td colSpan="13" className="text-center text-[#718091] py-8">상승신호 발생기록이 없습니다.</td></tr>}{filtered.map((row) => <tr key={row.id}>
            <td><span className="badge">{row.source === 'POSITION' ? '실제기록' : 'SIGNAL'}</span></td>
            <td><span className={`inline-flex rounded-full border px-2 py-1 text-[10px] font-bold whitespace-nowrap ${ledgerStatusTone(row)}`}>{growthStatusLabel(row)}</span>{row.entryRestricted && <div className="text-[9px] text-[#f6d365] mt-1">신규진입 제한</div>}{!row.verified && row.source === 'SIGNAL' && <div className="text-[9px] text-[#e5c45c] mt-1">미검증</div>}</td>
            <td><strong className="whitespace-nowrap">{row.name || row.code}</strong><div className="text-[9px] text-[#718091]">{row.code}{row.observationCycle ? ` · 오늘 관찰 ${row.observationCycle}회차` : ''}</div></td>
            <td>{row.source === 'SIGNAL' && (row.status === 'OBSERVING' || row.status === 'CANCELLED' || row.status === 'BUY_ACTIVE') ? <ObservationStrengthBadge row={row} /> : <span className="text-[#667584]">-</span>}</td>
            <td>{timelineCompact(row)}</td>
            <td className="whitespace-nowrap">{dateTimeKo(row.entryAt || row.entrySignalAt)}</td>
            <td className="whitespace-nowrap">{dateTimeKo(row.exitAt || row.exitSignalAt)}</td>
            <td className="font-mono text-right">{row.currentPrice ? fmt(row.currentPrice) : '-'}</td>
            <td className="font-mono text-right">{firstObservedPrice(row) ? fmt(firstObservedPrice(row)) : '-'}</td>
            <td className="font-mono text-right">{row.entryPrice ? fmt(row.entryPrice) : '-'}</td>
            <td className="font-mono text-right">{row.exitPrice ? fmt(row.exitPrice) : '-'}</td>
            <td className={`font-black text-right ${returnTone(row.returnPct)}`}>{returnText(row.returnPct)}</td>
            <td className="text-right">{row.qualityScore == null ? '-' : `${fmt(row.qualityScore)}점`}{row.profitPriorityScore ? <div className="text-[9px] text-[#55e39a]">수익우선 {fmt(row.profitPriorityScore)}</div> : null}</td>
          </tr>)}</tbody>
        </table>
      </div>
    </section>
  </div>;
}

function WatchlistTab({ data, onChanged }) {
  const [form, setForm] = useState({ name: '', market: 'SOR', tier: 'FOCUS' });
  const [message, setMessage] = useState('');
  const [recommendations, setRecommendations] = useState(data.recommendations || null);
  const [intradayRecommendations, setIntradayRecommendations] = useState(data.intradayRecommendations || null);
  const [recBusy, setRecBusy] = useState(false);
  const [autoApply, setAutoApply] = useState(data.recommendationAutoApply || { enabled: false });
  const [intradayAutoApply, setIntradayAutoApply] = useState(data.intradayAutoApply || { enabled: false });
  const [learningSettings, setLearningSettings] = useState(data.learningSettings || { enabled: true });
  const [learningModel, setLearningModel] = useState(data.learningModel || null);
  useEffect(() => { if (data.recommendations) setRecommendations(data.recommendations); }, [data.recommendations]);
  useEffect(() => { if (data.intradayRecommendations) setIntradayRecommendations(data.intradayRecommendations); }, [data.intradayRecommendations]);
  useEffect(() => { setAutoApply(data.recommendationAutoApply || { enabled: false }); }, [data.recommendationAutoApply]);
  useEffect(() => { setIntradayAutoApply(data.intradayAutoApply || { enabled: false }); }, [data.intradayAutoApply]);
  useEffect(() => { setLearningSettings(data.learningSettings || { enabled: true }); }, [data.learningSettings]);
  useEffect(() => { setLearningModel(data.learningModel || null); }, [data.learningModel]);
  const submit = async (event) => {
    event.preventDefault();
    try {
      await api('/api/watchlist', { method: 'POST', body: JSON.stringify(form) });
      setForm({ name: '', market: 'SOR', tier: 'FOCUS' });
      setMessage('수동종목으로 등록했습니다. 자동추천 적용 시에도 이 종목은 보호됩니다.');
      onChanged();
    } catch (err) { setMessage(err.message); }
  };
  const remove = async (code) => {
    try { await api(`/api/watchlist?code=${code}`, { method: 'DELETE' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const generate = async () => {
    setRecBusy(true); setMessage('');
    try {
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'generate' }) });
      setRecommendations(result.recommendations || null);
      if (result.learningSettings) setLearningSettings(result.learningSettings);
      if (result.learningModel) setLearningModel(result.learningModel);
      setMessage('오늘 자동추천 리스트를 새로 작성했습니다. 추천은 감시후보이며 BUY 신호가 아닙니다.');
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const apply = async () => {
    setRecBusy(true); setMessage('');
    try {
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'apply' }) });
      setRecommendations(result.recommendations || recommendations);
      setMessage(`자동추천 적용 완료 · 기존 수동 ${result.applied?.preservedManual || 0}개 보호 · 자동집중 ${result.applied?.autoFocus || 0} · 자동경량 ${result.applied?.autoLight || 0}`);
      onChanged();
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const toggleAutoApply = async () => {
    setRecBusy(true); setMessage('');
    try {
      const enabled = !autoApply?.enabled;
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'set_auto_apply', enabled }) });
      setAutoApply(result.autoApply || { enabled });
      setMessage(enabled
        ? '자동적용 ON · 다음 평일 20:15 신규 추천 생성 성공 시 수동종목을 보호하고 빈 집중/경량 슬롯을 자동으로 채웁니다.'
        : '자동적용 OFF · 추천목록만 자동 생성하며 감시종목 적용은 직접 눌러야 합니다.');
      onChanged();
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const generateIntraday = async () => {
    setRecBusy(true); setMessage('');
    try {
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'generate_intraday' }) });
      setIntradayRecommendations(result.intradayRecommendations || null);
      setIntradayAutoApply(result.intradayAutoApply || intradayAutoApply || { enabled: false });
      if (result.learningSettings) setLearningSettings(result.learningSettings);
      if (result.learningModel) setLearningModel(result.learningModel);
      if (result.autoApplied?.applied) {
        const a = result.autoApplied.appliedResult || {};
        setMessage(`장중 강한종목 갱신+자동적용 완료 · 수동 ${a.preservedManual || 0}개 보호 · 자동집중 ${a.autoFocus || 0} · 자동경량 ${a.autoLight || 0}`);
        onChanged();
      } else if (result.intradayRecommendations?.throttled) {
        setMessage('최근 60초 이내 갱신 결과를 유지합니다. 잦은 재조회·화면변경을 막았습니다.');
      } else if (result.autoApplied?.reason === 'MARKET_CLOSED') {
        setMessage('장중 강한종목 목록은 갱신했지만 현재 장중이 아니므로 자동적용은 하지 않았습니다.');
      } else {
        setMessage('장중 강한종목을 현재 시장 순위로 갱신했습니다. 장중 자동적용이 OFF이면 목록만 바뀝니다.');
      }
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const applyIntraday = async () => {
    setRecBusy(true); setMessage('');
    try {
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'apply_intraday' }) });
      setIntradayRecommendations(result.intradayRecommendations || intradayRecommendations);
      setMessage(`장중 강한종목 적용 완료 · 수동 ${result.applied?.preservedManual || 0}개 보호 · 자동집중 ${result.applied?.autoFocus || 0} · 자동경량 ${result.applied?.autoLight || 0}`);
      onChanged();
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const toggleIntradayAutoApply = async () => {
    setRecBusy(true); setMessage('');
    try {
      const enabled = !intradayAutoApply?.enabled;
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'set_intraday_auto_apply', enabled }) });
      setIntradayAutoApply(result.intradayAutoApply || { enabled });
      setMessage(enabled
        ? '장중 자동적용 ON · 버튼 갱신 시 즉시 반영하고, 장중에는 5분 주기로 AUTO 경량만 최대 2종목 보수적으로 교체합니다. 수동·고정·집중은 보호합니다.'
        : '장중 자동적용 OFF · 뉴스/시장 후보목록만 갱신하고 실제 감시종목은 직접 적용합니다. 자동 경량교체도 수행하지 않습니다.');
      onChanged();
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const toggleLearning = async () => {
    setRecBusy(true); setMessage('');
    try {
      const enabled = !learningSettings?.enabled;
      const result = await api('/api/recommendations', { method: 'POST', body: JSON.stringify({ action: 'set_learning_enabled', enabled }) });
      setLearningSettings(result.learningSettings || { enabled });
      setLearningModel(result.learningModel || learningModel);
      setMessage(enabled
        ? '성과학습 ON · 실제 EARLY/BUY 결과가 충분히 쌓이면 자동추천 점수만 ±10점 범위에서 보정합니다. BUY 안전게이트는 고정입니다.'
        : '성과학습 OFF · 자동추천은 시총균형·상대거래량·거래대금 가속·수급·모멘텀과 뉴스 EDGE를 사용하되 과거 EARLY/BUY 성과보정은 적용하지 않습니다.');
    } catch (err) { setMessage(err.message); } finally { setRecBusy(false); }
  };
  const addRecommended = async (stock, tier) => {
    try {
      await api('/api/watchlist', { method: 'POST', body: JSON.stringify({ code: stock.code, name: stock.name, market: 'SOR', tier }) });
      setMessage(`${stock.name}을(를) ${tier === 'FOCUS' ? '집중' : '경량'} 수동종목으로 등록했습니다.`);
      onChanged();
    } catch (err) { setMessage(err.message); }
  };
  const counts = data.watchCounts || { focus: 0, light: 0 };
  const focusCap = data.watchLimits?.focus || 8;
  const lightCap = data.watchLimits?.light || 18;
  const totalCap = data.watchLimits?.total || 30;
  const generated = recommendations?.generatedAt ? new Date(recommendations.generatedAt).toLocaleString('ko-KR') : '-';
  const intradayGenerated = intradayRecommendations?.generatedAt ? new Date(intradayRecommendations.generatedAt).toLocaleString('ko-KR') : '-';
  const RecommendationList = ({ title, rows, tier, capacity }) => <div className="rounded-xl border border-[#24303b] overflow-hidden">
    <div className="px-3 py-2 bg-[#0d141b] border-b border-[#24303b] flex justify-between"><strong className="text-sm">{title}</strong><span className="text-[10px] text-[#758494]">{rows?.length || 0}/{capacity}</span></div>
    {(rows || []).length === 0 && <div className="p-3 text-xs text-[#718091]">아직 추천이 없습니다.</div>}
    {(rows || []).map((stock) => <div key={`rec-${tier}-${stock.code}`} className="p-3 border-b border-[#18212a] last:border-0">
      <div className="flex justify-between gap-2 items-start"><div><strong>{stock.rank}. {stock.name}</strong><span className="ml-2 text-[10px] text-[#718091]">{stock.code}</span></div><div className="text-right"><span className="badge">추천 {fmt(stock.score)}점</span>{Number(stock.learningAdjustment || 0) !== 0 && <div className={`text-[9px] mt-1 ${Number(stock.learningAdjustment) > 0 ? 'text-[#55e39a]' : 'text-[#ffad66]'}`}>학습 {Number(stock.learningAdjustment) > 0 ? '+' : ''}{Number(stock.learningAdjustment).toFixed(1)}</div>}</div></div>
      <div className="flex flex-wrap gap-1 mt-1">
        {stock.currentChangeFresh ? <span className="badge">현재 {Number(stock.currentChangePct) >= 0 ? '+' : ''}{Number(stock.currentChangePct).toFixed(2)}%</span> : <span className="badge">현재등락 수신대기</span>}
        {Number.isFinite(Number(stock.discoveryChangePct)) && <span className="badge">발굴시 {Number(stock.discoveryChangePct) >= 0 ? '+' : ''}{Number(stock.discoveryChangePct).toFixed(2)}%</span>}
        {stock.preIgnitionChaseRisk && <span className="badge">추격위험</span>}
      </div>
      <div className="text-[10px] text-[#8b99a7] mt-1">{(stock.reasons || []).filter((x) => !String(x).startsWith('발굴시 ')).slice(0, 3).join(' · ') || '급등 전 거래·수급 점화 후보'}</div>
      <div className="flex flex-wrap gap-1 mt-1">{stock.marketCapLabel && <span className="badge">시총 {stock.marketCapLabel}</span>}{Number(stock.volumeSurgeRate || 0) > 0 && <span className="badge">거래량 +{Math.round(Number(stock.volumeSurgeRate))}%</span>}{Number(stock.turnoverAccelerationPct || 0) > 0 && <span className="badge">대금가속 +{Math.round(Number(stock.turnoverAccelerationPct))}%</span>}{Number(stock.preIgnitionBonus || 0) !== 0 && <span className="badge">사전포착 {Number(stock.preIgnitionBonus) > 0 ? '+' : ''}{Math.round(Number(stock.preIgnitionBonus))}</span>}</div>
      <button className="secondary-btn mt-2" onClick={() => addRecommended(stock, tier)}>{tier === 'FOCUS' ? '집중 수동등록' : '경량 수동등록'}</button>
    </div>)}
  </div>;
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><Plus size={16} />종목 추가 · 수동입력</h2>
      <p className="help">종목명만 입력하면 키움 종목 마스터에서 정확한 6자리 코드를 확인합니다. 수동으로 등록한 종목은 자동추천 전체적용을 눌러도 삭제·교체하지 않습니다.</p>
      <div className="text-xs text-[#8b98a5] mt-2">집중 {counts.focus || 0}/{focusCap} · 경량 {counts.light || 0}/{lightCap} · 전체 {data.watchlist?.length || 0}/{totalCap}</div>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-4 gap-2 mt-3">
        <input className="input md:col-span-1" placeholder="종목명만 입력 (예: 한미반도체)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <select className="input" value={form.market} onChange={(e) => setForm({ ...form, market: e.target.value })}><option value="SOR">SOR 통합</option><option value="KRX">KRX만</option><option value="NXT">NXT만</option></select>
        <select className="input" value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })}><option value="FOCUS">집중입력</option><option value="LIGHT">경량입력</option></select>
        <button className="primary-btn" type="submit"><Plus size={14} />수동등록</button>
      </form>{message && <div className="text-xs text-[#d6bd65] mt-2">{message}</div>}
    </section>

    <section className="panel p-4">
      <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="section-title"><Activity size={16} />급등 전 사전포착 · 집중 8 / 경량 18</h2><p className="help">이미 +8~10% 오른 종목을 추격하지 않고, 현재 -1~+5% 구간에서 5분 거래량급증·거래대금 가속·실시간 PRE-SURGE·스마트머니 점화가 먼저 나타나는 종목을 우선합니다. REST 등락률은 발굴시 스냅샷으로만 보존하고 현재 등락률은 Kiwoom WebSocket 최신값만 표시합니다.</p></div><span className="badge">마지막 장중갱신 {intradayGenerated}</span></div>
      <Notice icon={AlertTriangle}>장중 자동적용은 20:15 일일 자동적용과 별도입니다. ON이면 버튼 갱신 시 즉시 반영하고 장중에는 <strong>5분 주기로 AUTO 경량만 최대 2종목</strong> 보수적으로 교체합니다. 수동·고정·AUTO 집중은 보호하며 추천 자체는 BUY가 아닙니다.</Notice>
      <div className="flex flex-wrap gap-2 mt-3"><button className="primary-btn" disabled={recBusy} onClick={generateIntraday}><RefreshCw size={14} />{recBusy ? '처리 중...' : '장중 강한종목 갱신'}</button><button className="secondary-btn" disabled={recBusy || !intradayRecommendations} onClick={applyIntraday}>장중 목록 적용 · 수동보호</button><button className={intradayAutoApply?.enabled ? 'primary-btn' : 'secondary-btn'} disabled={recBusy} onClick={toggleIntradayAutoApply}>장중 자동적용 {intradayAutoApply?.enabled ? 'ON' : 'OFF'}</button></div>
      <div className={`mt-2 rounded-lg border px-3 py-2 text-[11px] ${intradayAutoApply?.enabled ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#303a45] bg-[#0d141b] text-[#91a0ae]'}`}>
        {intradayAutoApply?.enabled ? 'ON · 수동·고정·AUTO 집중을 보호하며 장중 후보갱신/5분 주기에서 AUTO 경량만 보수적으로 교체합니다.' : 'OFF · 장중 강한종목 목록만 갱신하고 실제 감시목록 적용은 직접 누릅니다.'}
        {intradayAutoApply?.lastAppliedAt ? <div className="mt-1 text-[10px]">마지막 장중 자동적용 {dateTimeKo(intradayAutoApply.lastAppliedAt)} · 수동보호 {intradayAutoApply.lastResult?.preservedManual ?? 0} · 자동집중 {intradayAutoApply.lastResult?.autoFocus ?? 0} · 자동경량 {intradayAutoApply.lastResult?.autoLight ?? 0}</div> : null}
        {intradayAutoApply?.lastError ? <div className="mt-1 text-[10px] text-[#ffad66]">최근 장중 자동적용 오류: {intradayAutoApply.lastError}</div> : null}
      </div>
      {intradayRecommendations?.sessionWarning && <div className="text-[10px] text-[#e1b65b] mt-2">{intradayRecommendations.sessionWarning}</div>}
      {intradayRecommendations?.refreshError && <div className="text-[10px] text-[#e1b65b] mt-2">최근 장중 갱신 오류: {intradayRecommendations.refreshError} · 이전 장중목록을 유지합니다.</div>}
      {intradayRecommendations?.throttled && <div className="text-[10px] text-[#8ea0af] mt-2">60초 재조회 제한 적용 · 동일 결과를 유지해 불필요한 API 호출과 화면변경을 막습니다.</div>}
      {intradayRecommendations?.sources && <div className="text-[10px] text-[#8ea0af] mt-2">시장풀 {intradayRecommendations.sources.marketPool || 0} · 거래량급증 {intradayRecommendations.sources.volumeSurge || 0} · 시총분포 1,000억미만 {intradayRecommendations.marketCapBuckets?.MICRO || 0} / 1,000~5,000억 {intradayRecommendations.marketCapBuckets?.SMALL || 0} / 5,000억~3조 {intradayRecommendations.marketCapBuckets?.MID || 0} / 3조이상 {intradayRecommendations.marketCapBuckets?.LARGE || 0} / 확인중 {intradayRecommendations.marketCapBuckets?.UNKNOWN || 0}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3"><RecommendationList title="장중 사전포착 8 · 급등 전 현재강도" rows={intradayRecommendations?.focus || []} tier="FOCUS" capacity={focusCap} /><RecommendationList title="조기점화 18 · 다음 승격 후보" rows={intradayRecommendations?.light || []} tier="LIGHT" capacity={lightCap} /></div>
    </section>

    <section className="panel p-4">
      <div className="flex flex-wrap items-start justify-between gap-2"><div><h2 className="section-title"><TrendingUp size={16} />매일 자동추천 · 집중 8 / 경량 18</h2><p className="help">시총별 시장풀 40(목표 8/14/10/8)에서 전일대비 거래량급증·상대거래량·거래대금과 외국인기관 흐름을 평가하고 뉴스 EDGE·선취·선반영·실제 EARLY/BUY 성과학습을 합칩니다. 절대 거래대금 상위만으로 중소형주가 밀리지 않게 합니다.</p></div><span className="badge">마지막 작성 {generated}</span></div>
      <Notice icon={AlertTriangle}>자동추천은 BUY 확정이 아닙니다. 실제 진입은 기존 엄격 스마트머니·체결강도·VWAP·수익우선·R/R 게이트를 그대로 통과해야 합니다. 수동종목이 우선이며 자동종목은 남는 슬롯만 채웁니다.</Notice>
      <div className={`mt-3 rounded-lg border px-3 py-2 text-[11px] ${learningSettings?.enabled ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#303a45] bg-[#0d141b] text-[#91a0ae]'}`}>
        <div className="flex flex-wrap items-center justify-between gap-2"><div><strong>성과학습 {learningSettings?.enabled ? 'ON' : 'OFF'}</strong> · {learningModel?.active ? `학습활성 ${learningModel.sampleSize}건` : `준비중 ${learningModel?.sampleSize || 0}/${learningModel?.minTotalSamples || 30}건`} · 자동추천 보정 최대 ±{learningModel?.maxAdjustment || 10}점</div><button className="secondary-btn" disabled={recBusy} onClick={toggleLearning}>성과학습 {learningSettings?.enabled ? '끄기' : '켜기'}</button></div>
        <div className="mt-1 text-[10px]">EARLY/BUY 실제 결과를 이용해 시총구간·상대거래량·거래대금가속·상승구간·외인기관·사전포착·스마트머니 패턴의 추천점수만 보정합니다. BUY 85/78/118/95%/1.5R 안전게이트는 학습이 변경하지 않습니다.</div>
      </div>
      <div className="flex flex-wrap gap-2 mt-3"><button className="primary-btn" disabled={recBusy} onClick={generate}>{recBusy ? '처리 중...' : '오늘 추천 새로 만들기'}</button><button className="secondary-btn" disabled={recBusy || !recommendations} onClick={apply}>추천 전체적용 · 수동종목 보호</button><button className={autoApply?.enabled ? 'primary-btn' : 'secondary-btn'} disabled={recBusy} onClick={toggleAutoApply}>자동적용 {autoApply?.enabled ? 'ON' : 'OFF'}</button></div>
      <div className={`mt-2 rounded-lg border px-3 py-2 text-[11px] ${autoApply?.enabled ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#303a45] bg-[#0d141b] text-[#91a0ae]'}`}>
        {autoApply?.enabled ? 'ON · 평일 20:15 신규 추천 생성 성공 직후 수동종목을 보호하고 빈 집중/경량 슬롯을 자동등록합니다.' : 'OFF · 추천은 자동 생성되지만 감시종목 등록은 수동입니다.'}
        {autoApply?.lastAppliedAt ? <div className="mt-1 text-[10px]">마지막 자동적용 {dateTimeKo(autoApply.lastAppliedAt)} · 수동보호 {autoApply.lastResult?.preservedManual ?? 0} · 자동집중 {autoApply.lastResult?.autoFocus ?? 0} · 자동경량 {autoApply.lastResult?.autoLight ?? 0}</div> : null}
        {autoApply?.lastError ? <div className="mt-1 text-[10px] text-[#ffad66]">최근 자동적용 오류: {autoApply.lastError}</div> : null}
      </div>
      {recommendations?.refreshError && <div className="text-[10px] text-[#e1b65b] mt-2">최근 갱신 오류: {recommendations.refreshError} · 이전 추천을 유지합니다.</div>}
      {recommendations?.sources && <div className="text-[10px] text-[#8ea0af] mt-2">시장풀 {recommendations.sources.marketPool || 0} · 거래량급증 {recommendations.sources.volumeSurge || 0} · 시총분포 1,000억미만 {recommendations.marketCapBuckets?.MICRO || 0} / 1,000~5,000억 {recommendations.marketCapBuckets?.SMALL || 0} / 5,000억~3조 {recommendations.marketCapBuckets?.MID || 0} / 3조이상 {recommendations.marketCapBuckets?.LARGE || 0} / 확인중 {recommendations.marketCapBuckets?.UNKNOWN || 0}</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3"><RecommendationList title="집중 추천 8 · 시총균형 full-depth" rows={recommendations?.focus || []} tier="FOCUS" capacity={focusCap} /><RecommendationList title="경량 추천 18 · 조기승격 후보" rows={recommendations?.light || []} tier="LIGHT" capacity={lightCap} /></div>
    </section>

    <section className="panel overflow-hidden"><div className="p-3 border-b border-[#202832] text-xs text-[#8190a0]">현재 감시 {data.watchlist?.length || 0}종목</div>{(data.watchlist || []).map((stock) => <div key={stock.code} className="px-3 py-3 border-b border-[#18212a] last:border-0 flex justify-between items-center"><div><strong>{stock.name}</strong><span className="ml-2 text-xs text-[#708091]">{stock.code} · {stock.market}</span><span className="ml-2 badge">{stock.fixed ? '고정집중' : stock.tier === 'LIGHT' ? '경량' : '집중'}</span>{!stock.fixed && <span className="ml-1 text-[9px] text-[#7d8c9b]">{stock.source === 'AUTO' ? '자동추천' : '수동보호'}</span>}</div>{!stock.fixed && <button className="icon-btn" onClick={() => remove(stock.code)} aria-label="삭제"><Trash2 size={15} /></button>}</div>)}</section>
  </div>;
}

function JournalTab({ data, onChanged }) {
  const [form, setForm] = useState({ code: data.watchlist?.[0]?.code || '', avgPrice: '', quantity: '', initialStopPrice: '', memo: '' });
  const [message, setMessage] = useState('');
  const open = async (event) => {
    event.preventDefault();
    try { const result = await api('/api/positions', { method: 'POST', body: JSON.stringify(form) }); setMessage(result.riskWarning || '포지션을 기록했습니다.'); setForm({ ...form, avgPrice: '', quantity: '', initialStopPrice: '', memo: '' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const close = async (position) => {
    const live = data.stocks?.find((s) => s.code === position.code);
    const current = live?.realtimeEligible === true ? Number(live.realtimePrice || live.price || 0) : position.avgPrice;
    const exitText = window.prompt('매도 체결가를 입력하세요.', String(current || ''));
    if (!exitText) return;
    const exitPrice = Number(exitText);
    try { await api('/api/positions', { method: 'PUT', body: JSON.stringify({ id: position.id, status: 'closed', exitPrice, exitTime: new Date().toISOString() }) }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const positions = data.positions || [];
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><BookOpen size={16} />수동 체결 기록</h2><p className="help">실제 주문을 전송하지 않습니다. 보유종목은 매수가 기준 설정 손절가만 실시간 경고하며, 목표가·트레일링으로 반복 매도 알림을 만들지 않습니다.</p>
      <form onSubmit={open} className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3"><select className="input" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })}>{(data.watchlist || []).map((s) => <option key={s.code} value={s.code}>{s.name}</option>)}</select><input className="input" inputMode="decimal" placeholder="매수가" value={form.avgPrice} onChange={(e) => setForm({ ...form, avgPrice: e.target.value })} /><input className="input" inputMode="numeric" placeholder="수량" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /><input className="input" inputMode="decimal" placeholder="최초 손절가(선택)" value={form.initialStopPrice} onChange={(e) => setForm({ ...form, initialStopPrice: e.target.value })} /><button className="primary-btn" type="submit">매수 기록</button></form>{message && <div className="text-xs text-[#e0c563] mt-2">{message}</div>}
    </section>
    <section className="space-y-2">{positions.length === 0 && <div className="empty">매매 기록이 없습니다.</div>}{positions.map((p) => { const live = data.stocks?.find((s) => s.code === p.code); const livePrice = live?.realtimeEligible === true ? Number(live.realtimePrice || live.price || 0) : 0; const pnl = p.status === 'closed' ? p.realizedPnl : livePrice > 0 ? (livePrice - p.avgPrice) * p.quantity : null; return <div className="panel p-3 flex items-center justify-between gap-3" key={p.id}><div><div className="font-bold">{live?.name || p.code} <span className="text-[10px] text-[#718091]">{p.status === 'closed' ? '청산' : '보유'}</span></div><div className="text-xs text-[#8493a2] mt-1">매수 {fmt(p.avgPrice)}원 × {fmt(p.quantity)}주 · 설정손절 {p.currentStopPrice ? fmt(p.currentStopPrice) : '-'}</div><div className={`text-sm font-bold mt-1 ${pnl == null ? 'text-[#718091]' : tone(pnl)}`}>{pnl == null ? '실시간 시세 미수신' : `${pnl >= 0 ? '+' : ''}${fmt(pnl)}원`}</div></div>{p.status !== 'closed' && <button className="danger-btn" onClick={() => close(p)}>매도 완료 기록</button>}</div>; })}</section>
  </div>;
}

function AlertsTab({ alerts, onNotify, onDisableNotify, push, pushStatus }) {
  const usefulAlerts = (alerts || []).filter((a) => a.action === 'BUY' || (a.action === 'SELL' && String(a.message || '').includes('손절가 도달')));
  return <div className="space-y-3">
    <section className="panel p-3">
      <div className="flex flex-wrap items-center justify-between gap-2"><div><div className="font-bold text-sm">알림 제어</div><div className="text-[11px] text-[#7e8c99] mt-1">기본 정책: 푸시는 확정 BUY와 실제 보유종목의 설정 손절가 도달만 전송 · EARLY는 화면/기록부 전용</div></div><span className={`px-2 py-1 rounded-lg text-[11px] border ${push?.intentionallyDisabled ? 'border-[#5f6770] text-[#aab4bd]' : 'border-[#1d563b] text-[#55e39a]'}`}>{push?.intentionallyDisabled ? '푸시 OFF' : `푸시 ${push?.subscriptionCount ? 'ON' : '미구독'}`}</span></div>
      <div className="flex flex-wrap gap-2 mt-3"><button className="secondary-btn" onClick={onNotify}><Bell size={14} />푸시 켜기·테스트</button><button className="secondary-btn" onClick={onDisableNotify}><Bell size={14} />푸시 알림 완전 해제</button></div>
      {pushStatus && <div className="text-[11px] text-[#9caab8] mt-2">{pushStatus}</div>}
    </section>
    {usefulAlerts.length === 0 && <div className="empty">확정 BUY/손절 알림이 없습니다.</div>}
    {usefulAlerts.map((a) => <div key={a.id} className="panel p-3"><div className="flex justify-between gap-2"><div className={`font-bold text-sm ${a.action === 'BUY' ? 'text-[#55e39a]' : 'text-[#ff7b87]'}`}>{a.name || a.code} {a.action === 'SELL' ? 'STOP' : a.action || ''}</div><div className="text-[10px] text-[#6f7d8b]">{new Date(a.time).toLocaleString('ko-KR')}</div></div><div className="text-xs mt-1 text-[#d0d9e1]">{a.message}</div></div>)}
  </div>;
}

function SettingsTab({ settings, onSaved }) {
  const [form, setForm] = useState(settings);
  const [message, setMessage] = useState('');
  useEffect(() => setForm(settings), [settings]);
  const set = (key, value) => setForm({ ...form, [key]: Number(value) });
  const setSignal = (key, value) => setForm({ ...form, signal: { ...(form.signal || {}), [key]: Number(value) } });
  const save = async () => { try { await api('/api/settings', { method: 'PUT', body: JSON.stringify(form) }); setMessage('저장했습니다.'); onSaved(); } catch (err) { setMessage(err.message); } };
  return <div className="space-y-4"><section className="panel p-4"><h2 className="section-title"><ShieldAlert size={16} />계좌 위험 제한</h2><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="당일 시작자산" value={form.dayStartingEquity} onChange={(v) => set('dayStartingEquity', v)} /><Field label="일일 최대손실 %" value={form.dailyMaxLossPct} onChange={(v) => set('dailyMaxLossPct', v)} /><Field label="연속손실 제한" value={form.maxConsecutiveLosses} onChange={(v) => set('maxConsecutiveLosses', v)} /><Field label="최대 동시보유" value={form.maxConcurrentPositions} onChange={(v) => set('maxConcurrentPositions', v)} /><Field label="1회 위험예산 %" value={form.maxRiskPerTradePct} onChange={(v) => set('maxRiskPerTradePct', v)} /><Field label="종목당 자금상한 %" value={form.maxPositionPct} onChange={(v) => set('maxPositionPct', v)} /><Field label="매수 수수료 %" value={form.buyFeePct} onChange={(v) => set('buyFeePct', v)} /><Field label="매도 수수료 %" value={form.sellFeePct} onChange={(v) => set('sellFeePct', v)} /><Field label="매도 세금 %" value={form.sellTaxPct} onChange={(v) => set('sellTaxPct', v)} /></div></section>
    <section className="panel p-4"><h2 className="section-title"><Gauge size={16} />급등 사전포착·BUY 임계값</h2><p className="help mt-1">매도/RISK 임계값은 내부 신규진입 안전필터로만 사용하므로 화면에서 조정하지 않습니다.</p><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="조기관찰 점수" value={form.signal?.earlyWatchScore} onChange={(v) => setSignal('earlyWatchScore', v)} /><Field label="급등 사전포착 점수" value={form.signal?.preSurgeEarlyScore} onChange={(v) => setSignal('preSurgeEarlyScore', v)} /><Field label="사전포착 최소그룹" value={form.signal?.preSurgeMinGroups} onChange={(v) => setSignal('preSurgeMinGroups', v)} /><Field label="확정 품질점수" value={form.signal?.minBuyScore} onChange={(v) => setSignal('minBuyScore', v)} /><Field label="강한매수 점수" value={form.signal?.strongBuyScore} onChange={(v) => setSignal('strongBuyScore', v)} /><Field label="최소 수익우선점수" value={form.signal?.minProfitPriorityScore} onChange={(v) => setSignal('minProfitPriorityScore', v)} /><Field label="강한 수익우선점수" value={form.signal?.strongProfitPriorityScore} onChange={(v) => setSignal('strongProfitPriorityScore', v)} /><Field label="데이터 완전성 %" value={form.signal?.minDataCompleteness} onChange={(v) => setSignal('minDataCompleteness', v)} /><Field label="체결 확인 횟수" value={form.signal?.confirmTicks} onChange={(v) => setSignal('confirmTicks', v)} /><Field label="조건 유지 ms" value={form.signal?.confirmHoldMs} onChange={(v) => setSignal('confirmHoldMs', v)} /><Field label="최대 스프레드 bp" value={form.signal?.maxSpreadBps} onChange={(v) => setSignal('maxSpreadBps', v)} /><Field label="최소 체결강도" value={form.signal?.minTradeStrength} onChange={(v) => setSignal('minTradeStrength', v)} /><Field label="최소 1분 거래대금" value={form.signal?.minOneMinuteTurnover} onChange={(v) => setSignal('minOneMinuteTurnover', v)} /><Field label="최소 RVOL" value={form.signal?.minRvol} onChange={(v) => setSignal('minRvol', v)} /><Field label="VWAP 최대이격 %" value={form.signal?.maxVwapExtensionPct} onChange={(v) => setSignal('maxVwapExtensionPct', v)} /><Field label="알림 재발생 초 (최소 300)" value={form.signal?.signalCooldownSeconds} onChange={(v) => setSignal('signalCooldownSeconds', v)} /><Field label="승격 15초 거래대금" value={form.signal?.promotionTurnover15s} onChange={(v) => setSignal('promotionTurnover15s', v)} /><Field label="승격 5초 순매수" value={form.signal?.promotionNetBuy5s} onChange={(v) => setSignal('promotionNetBuy5s', v)} /><Field label="승격 유지 초" value={form.signal?.promotionSeconds} onChange={(v) => setSignal('promotionSeconds', v)} /><Field label="동시 자동승격" value={form.signal?.maxPromotedLight} onChange={(v) => setSignal('maxPromotedLight', v)} /></div></section>
    <button className="primary-btn" onClick={save}>설정 저장</button>{message && <span className="text-xs text-[#d8c15f] ml-2">{message}</span>}
  </div>;
}
function Field({ label, value, onChange }) { return <label className="text-xs text-[#8998a7]"><span>{label}</span><input className="input mt-1" type="number" step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value)} /></label>; }
