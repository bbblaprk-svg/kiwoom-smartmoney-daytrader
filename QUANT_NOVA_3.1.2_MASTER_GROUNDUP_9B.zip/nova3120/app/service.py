from __future__ import annotations
import asyncio,contextlib,time
from typing import Any
from app.config import SETTINGS
from app.domain import FeedState,Origin,Venue
from app.runtime.state import RuntimeState
from app.runtime.dispatcher import TradeDispatcher,CoalescingLane
from app.runtime.ingest import Ingestor
from app.runtime.watchdog import HardStallWatchdog
from app.runtime.health import RuntimeHealth
from app.runtime.display import DisplayState
from app.runtime.clock import sessions,trade_day,lifecycle_phase
from app.tracking.live import LiveTracker
from app.storage.wal import DurableJournal
from app.storage.runtime_store import RuntimeStore
from app.storage.performance import PerformanceLedger
from app.storage.snapshot import atomic_json,RUNTIME_SNAPSHOT,DISPLAY_FALLBACK,PRIOR_CLOSE_SNAPSHOT
from app.signal.coordinator import SignalCoordinator
from app.broker.discovery import DiscoveryEngine
from app.broker.websocket import KiwoomWebSocket

class NovaService:
    """Ground-up composition root with explicit Feed / Realtime / WAL / UI task boundaries."""
    def __init__(self):
        self.state=RuntimeState();self.tracker=LiveTracker();self.ingestor=Ingestor(self.state,self.tracker)
        self.trade_dispatcher=TradeDispatcher(self.ingestor.trade,self.ingestor.dropped);self.coalesce=CoalescingLane(self.ingestor.aux)
        self.journal=DurableJournal();self.state.history_sink=self.journal.append_important
        self.watchdog=HardStallWatchdog();self.health=RuntimeHealth(self.state,self.watchdog,self.trade_dispatcher,self.coalesce)
        self.display=DisplayState(self.state,self.tracker);self.store=RuntimeStore(self.state,self.display);self.performance=PerformanceLedger();self.coordinator=SignalCoordinator(self.state,self.journal)
        self.discovery=DiscoveryEngine(self.state);self.ws=KiwoomWebSocket(self.state,self.trade_dispatcher,self.coalesce)
        self.tasks:list[asyncio.Task]=[];self.started=False;self.stop_evt=asyncio.Event();self.current_day=trade_day()

    async def start(self):
        if self.started:return
        self.started=True;self.state.feed_state=FeedState.STARTING
        self.journal.start();self.trade_dispatcher.start();self.coalesce.start();self.watchdog.start()
        self.tasks=[asyncio.create_task(self.health.heartbeat(),name='heartbeat'),asyncio.create_task(self.health.load_loop(),name='load-control'),asyncio.create_task(self.display.run(),name='display-snapshot'),asyncio.create_task(self.coordinator.run(),name='signal-coordinator'),asyncio.create_task(self._restore_then_warm(),name='restore'),asyncio.create_task(self._maintenance(),name='maintenance'),asyncio.create_task(self._discovery_loop(),name='discovery')]
        if not SETTINGS.offline and not SETTINGS.candidate_mode:self.tasks.append(asyncio.create_task(self._ws_after_restore(),name='kiwoom-ws'))
        else:self.state.ws_status['last_error']='OFFLINE_MODE' if SETTINGS.offline else 'CANDIDATE_MODE'
        # Return immediately so liveness never waits on disk restore/network.

    async def _restore_then_warm(self):
        self.state.feed_state=FeedState.RESTORING
        try:await self.store.restore()
        except Exception as e:self.state.telemetry['restore_error_count']+=1;self.state.ws_status['restore_error']=str(e)[:180];self.state.restore_done=True
        self.state.feed_state=FeedState.RESYNC if sessions()['active'] else FeedState.CLOSED;self.state.warming_until=time.time()+SETTINGS.warm_sec

    async def _ws_after_restore(self):
        while not self.state.restore_done and not self.stop_evt.is_set():await asyncio.sleep(.05)
        if not self.stop_evt.is_set():await self.ws.run()

    async def _discovery_loop(self):
        while not self.stop_evt.is_set():
            if not self.state.restore_done:await asyncio.sleep(.1);continue
            if not SETTINGS.offline and not SETTINGS.candidate_mode:
                try:await self.discovery.cycle()
                except Exception as e:self.state.telemetry['discovery_error_count']+=1;self.state.ws_status['discovery_error']=str(e)[:160]
            mul={'NORMAL':1.0,'BUSY':1.5,'HIGH_LOAD':2.5,'CRITICAL':4.0}.get(self.state.load_mode,1.0)
            await asyncio.sleep(max(2,SETTINGS.discovery_sec*mul))

    async def _maintenance(self):
        last_persist=0.0;last_prune=0.0;last_feed=0.0;last_performance=0.0
        while not self.stop_evt.is_set():
            if not self.state.restore_done:await asyncio.sleep(.1);continue
            now=time.time();day=trade_day()
            if day!=self.current_day:await self._rollover(day);self.current_day=day;last_persist=0.0
            if now-last_feed>=1:self._update_feed_state(now);last_feed=now
            if now-last_prune>=30:
                stats=self.state.prune(SETTINGS.max_candidates,SETTINGS.candidate_ttl_sec);self.state.telemetry.update({f'prune_{k}':v for k,v in stats.items()});self.ws.integrity.prune_codes(day,set(self.state.hot_codes)|set(self.state.pinned_codes));last_prune=now
            if now-last_performance>=30:
                try:
                    ps=await asyncio.to_thread(self.performance.sync,self.state);self.state.followup_codes=set(ps.get('watch_codes') or []);self.state.telemetry['performance_pending_today']=ps.get('pending_today',0);self.state.telemetry['performance_finalized']=ps.get('finalized',0)
                except Exception as e:self.state.telemetry['performance_error_count']+=1;self.state.ws_status['performance_error']=str(e)[:160]
                last_performance=now
            if now-last_persist>=30:
                try:
                    runtime=self.store.build_runtime();snap=self.display.get();await asyncio.to_thread(atomic_json,RUNTIME_SNAPSHOT,runtime)
                    if lifecycle_phase()=='CLOSE_TRACK':await asyncio.to_thread(atomic_json,PRIOR_CLOSE_SNAPSHOT,self.store.build_prior())
                    await asyncio.to_thread(atomic_json,DISPLAY_FALLBACK,snap)
                except Exception:self.state.telemetry['snapshot_error_count']+=1
                last_persist=now
            await asyncio.sleep(.5)

    def _update_feed_state(self,now:float):
        self.state.telemetry['ui_clients']=self.state.ui_clients;self.state.telemetry['db_queue_depth']=self.journal.health()['db_queue_depth']
        if SETTINGS.offline or SETTINGS.candidate_mode:self.state.feed_state=FeedState.WARMING if self.state.restore_done else FeedState.RESTORING;return
        sess=sessions();ws=self.state.ws_status
        if not sess['active']:self.state.feed_state=FeedState.CLOSED;return
        if not self.state.restore_done:self.state.feed_state=FeedState.RESTORING;return
        if int(self.state.telemetry.get('pinned_ws_overflow') or 0)>0 or int(ws.get('subscription_reject_count') or 0)>0:self.state.feed_state=FeedState.DEGRADED;return
        if not ws.get('connected') or not ws.get('logged_in'):self.state.feed_state=FeedState.RECONNECTING;return
        if int(ws.get('registered') or 0)<=0:self.state.feed_state=FeedState.RESYNC;return
        if self.trade_dispatcher.oldest_age_ms()>500:self.state.feed_state=FeedState.DEGRADED;return
        last_msg=float(ws.get('last_message_at') or 0);last_trade=float(ws.get('last_trade_at') or 0)
        if not last_msg or now-last_msg>8:self.state.feed_state=FeedState.RECONNECTING;return
        # No trade for a quiet symbol is not a feed failure; global last message remains the liveness source.
        if now<self.state.warming_until:self.state.feed_state=FeedState.WARMING;return
        if last_trade and now-last_trade<=max(8,SETTINGS.fresh_ms/1000*3):self.state.feed_state=FeedState.LIVE
        else:self.state.feed_state=FeedState.WARMING

    async def _rollover(self,new_day:str):
        with self.state.lock:
            prior=[]
            for c in self.state.candidates.values():
                if c.lifecycle_state=='CLOSE_TRACK' or (c.close_signal_price and c.close_score):prior.append((c.code,c.name,c.close_signal_price or c.current().last_price,c.close_score or c.score,c.close_rank,c.valid_repeat_count))
            self.state.candidates={};self.state.windows={};self.state.code_locks={};self.state.hot_codes=set();self.state.pinned_codes=set();self.state.followup_codes=set();self.state.tracking_reservations={};self.state.dirty_keys=set();self.state.dirty_since={}
            for code,name,price,score,rank,repeats in prior:
                c=self.state.candidate(code,name,Origin.PRIOR_CLOSE,new_day);c.close_signal_price=price;c.close_score=score;c.close_rank=rank;c.lifecycle_state='PRIOR_CLOSE_FROZEN';c.live_track_pin=True;c.venue_state[Venue.NXT].entry.valid_repeat_count=repeats;c.refresh_aggregate();self.state.pinned_codes.add(code)
        self.ws.integrity.reset_for_day(new_day);self.state.feed_state=FeedState.WARMING;self.state.warming_until=time.time()+SETTINGS.warm_sec

    def liveness(self)->dict[str,Any]:
        age=(time.monotonic()-self.health.last_beat)*1000
        return {'ok':bool(self.started and age<5000),'version':SETTINGS.version,'feed_state':self.state.feed_state.value,'event_loop_beat_age_ms':round(age,1),'restore_done':self.state.restore_done,'uptime_sec':round(time.time()-self.state.started_at,1)}

    def realtime_health(self)->dict[str,Any]:
        x=self.health.snapshot();jh=self.journal.health();self.state.telemetry['db_queue_depth']=jh['db_queue_depth'];self.state.telemetry['db_write_latency_p95_ms']=jh['db_write_latency_p95_ms']
        x.update({'version':SETTINGS.version,'feed_state':self.state.feed_state.value,'sessions':sessions(),'journal':jh,'discovery':dict(self.discovery.last_status),'performance':dict(self.performance.last_status)})
        x['ok']=self.liveness()['ok'];x['feed_ok']=self.state.feed_state in (FeedState.LIVE,FeedState.CLOSED) if not (SETTINGS.offline or SETTINGS.candidate_mode) else False;return x

    async def stop(self):
        if not self.started:return
        self.stop_evt.set();self.coordinator.running=False
        for t in self.tasks:t.cancel()
        for t in self.tasks:
            with contextlib.suppress(asyncio.CancelledError,Exception):await t
        self.trade_dispatcher.stop();self.coalesce.stop();self.journal.stop();self.watchdog.stop();self.started=False

SERVICE=NovaService()
