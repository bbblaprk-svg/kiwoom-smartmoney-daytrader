from __future__ import annotations
import asyncio,time,threading
from app.domain import Candidate,Venue,Origin
from app.runtime.state import RuntimeState
from app.runtime.projection import LiveDisplayProjection
from app.runtime.clock import lifecycle_phase,sec_of_day,sessions
from app.tracking.top5 import Top5Registry
from app.tracking.live import LiveTracker
from app.config import SETTINGS

class DisplayState:
    """Compact immutable display snapshots + board-level Delta Batch support."""
    def __init__(self,state:RuntimeState,tracker:LiveTracker):
        self.state=state;self.tracker=tracker;self.lock=threading.Lock();self.snapshot={'type':'snapshot','version':SETTINGS.version,'generation':0,'generated_at':time.time(),'feed_state':'STARTING','phase':'PRIOR_CLOSE_FROZEN','feed':{},'load_mode':'NORMAL','telemetry':{},'boards':{'prebuy':[],'opening':[],'live_buy':[],'nxt_early':[],'nxt_management':[],'position_manager':[]},'signal_history':[],'candidate_count':0,'hot_count':0,'pinned_count':0};self.fallback={};self.generation=0;self.top5=Top5Registry()
        self.stable_codes:dict[str,list[str]]={};self.last_rank_at:dict[str,float]={};self.last_emitted_tick:dict[tuple[str,Venue],float]={};self.projection=LiveDisplayProjection(SETTINGS.display_fresh_ms)
    def get(self):
        with self.lock:return self.snapshot
    def set_fallback(self,snap:dict):
        with self.lock:self.fallback=snap if isinstance(snap,dict) else {}
    def history(self,code:str):
        c=self.state.candidates.get(code)
        if not c:return []
        with self.state.code_lock(code):
            events=[{'at':x.at,'kind':x.kind,'state':x.state,'price':x.price,'reason':x.reason,'venue':x.venue.value} for x in list(c.history)]
            tracks=[{'at':t.signal_time,'kind':'OUTCOME','state':'SIGNAL_TRACK','price':t.signal_price,'reason':str(t.public()),'venue':t.venue.value} for t in list(c.signal_tracks)]
        return sorted(events+tracks,key=lambda x:x['at'])
    @staticmethod
    def _sort(rows:list[Candidate],key):return sorted(rows,key=key,reverse=True)

    def _stabilize(self,board:str,ranked:list[Candidate],now:float,immediate_codes:set[str]|None=None)->list[Candidate]:
        immediate_codes=immediate_codes or set();old=self.stable_codes.get(board,[]);by={c.code:c for c in ranked};raw=[c.code for c in ranked]
        force=bool(immediate_codes-set(old))
        if old and now-self.last_rank_at.get(board,0)<1.0 and not force:
            out=[by[x] for x in old if x in by]
            for c in ranked:
                if c.code not in {x.code for x in out}:out.append(c)
                if len(out)>=5:break
            return out[:5]
        desired=ranked[:5]
        if old and not force:
            desired_codes=[c.code for c in desired]
            # #5/#6 churn guard: an old member ranked 6th survives unless newcomer has a clear priority margin.
            for code in old:
                if code in desired_codes or code not in by or code not in raw:continue
                idx=raw.index(code)
                if idx<=5 and desired:
                    weakest=min(desired,key=lambda c:c.priority_score)
                    if by[code].priority_score+1.5>=weakest.priority_score:
                        desired=[c for c in desired if c.code!=weakest.code]+[by[code]];desired=self._sort(desired,lambda c:(c.priority_score,c.score,c.valid_repeat_count))[:5];desired_codes=[c.code for c in desired]
        self.stable_codes[board]=[c.code for c in desired];self.last_rank_at[board]=now;return desired

    @staticmethod
    def delta(prev:dict,cur:dict)->dict:
        patch={};keys=('feed_state','phase','feed','load_mode','telemetry','candidate_count','hot_count','pinned_count','signal_history')
        for k in keys:
            if prev.get(k)!=cur.get(k):patch[k]=cur.get(k)
        bp={};pb=prev.get('boards') or {};cb=cur.get('boards') or {}
        for k,v in cb.items():
            if pb.get(k)!=v:bp[k]=v
        if bp:patch['boards']=bp
        return {'type':'delta','version':cur.get('version'),'base_generation':prev.get('generation',0),'generation':cur.get('generation',0),'generated_at':cur.get('generated_at'),'patch':patch}

    def _observe_ui_latency(self,rows:list[Candidate],venue_override:Venue|None=None):
        now=time.time()
        for c in rows:
            v=c.venue_state[venue_override] if venue_override in (Venue.KRX,Venue.NXT) else c.current();k=(c.code,v.venue)
            if v.last_tick_at and v.last_tick_at>self.last_emitted_tick.get(k,0):
                self.state.observe_latency('tick_to_ui_ms',max(0,(now-v.last_tick_at)*1000));self.last_emitted_tick[k]=v.last_tick_at

    def build(self):
        now=time.time();phase=lifecycle_phase()
        with self.state.lock:cands=list(self.state.candidates.values());hot_count=len(self.state.hot_codes);pinned_count=len(self.state.pinned_codes)
        fresh=[c for c in cands if self.projection.has_live(c,now)]
        pre_rank=self._sort(fresh,lambda c:(1 if c.entry_state in ('REACCEL','DIRECT_ARM','BUY') else 0,c.priority_score,c.score,c.valid_repeat_count,c.current().last_rate))[:10]
        if phase in ('PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK'):
            opening_pool=[c for c in cands if c.origin==Origin.PRIOR_CLOSE or c.lifecycle_state in ('CLOSE_TRACK','PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK')]
        elif phase in ('OPENING_HANDOFF','SHAKEOUT_WATCH','REVERSAL_WINDOW'):
            opening_pool=[c for c in cands if c.lifecycle_state in ('OPENING_HANDOFF','OPENING_ACTIVE','SHAKEOUT_WATCH','REVERSAL_EARLY','BUY_READY','BUY')]
        elif phase=='CLOSE_TRACK':
            opening_pool=[c for c in cands if c.lifecycle_state=='CLOSE_TRACK']
        else:
            # After the opening lifecycle ends, prior-close identities remain in the general engine;
            # the dedicated opening board does not become a stale all-day prior-candidate table.
            opening_pool=[c for c in cands if c.lifecycle_state in ('REVERSAL_EARLY','BUY_READY','BUY') and c.origin==Origin.PRIOR_CLOSE]
        opening_rank=self._sort(opening_pool,lambda c:(1 if c.lifecycle_state in ('BUY','BUY_READY') else 0,1 if c.lifecycle_state=='REVERSAL_EARLY' else 0,c.priority_score or c.close_score,c.valid_repeat_count))[:10]
        live_rank=self._sort([c for c in cands if c.entry_state=='BUY' or c.lifecycle_state in ('BUY_READY','REVERSAL_EARLY')],lambda c:(1 if c.entry_state=='BUY' else 0,c.last_buy_at,c.priority_score,c.valid_repeat_count))[:10]
        nxt_rank=self._sort([c for c in cands if c.venue_state[Venue.NXT].last_tick_at and now-c.venue_state[Venue.NXT].last_tick_at<=SETTINGS.display_fresh_ms/1000+1],lambda c:(float(c.venue_state[Venue.NXT].metrics.get('smart_money_realtime_proxy_score') or 0),c.venue_state[Venue.NXT].score,c.venue_state[Venue.NXT].last_rate))[:10]
        nxt_mgmt_rank=self._sort([c for c in cands if c.live_track_pin and c.last_signal and c.last_signal.venue==Venue.NXT],lambda c:(1 if c.last_buy_venue==Venue.NXT else 0,c.valid_repeat_count,c.priority_score,c.last_signal.signal_time if c.last_signal else 0))[:10]
        pre=self._stabilize('prebuy',pre_rank,now,{c.code for c in pre_rank if c.entry_state=='BUY'})
        opening=self._stabilize('opening',opening_rank,now,{c.code for c in opening_rank if c.lifecycle_state in ('BUY_READY','BUY')})
        live_buy=self._stabilize('live_buy',live_rank,now,{c.code for c in live_rank if c.entry_state=='BUY'})
        nxt=self._stabilize('nxt_early',nxt_rank,now,{c.code for c in nxt_rank if c.last_buy_venue==Venue.NXT})
        nxt_mgmt=self._stabilize('nxt_management',nxt_mgmt_rank,now)
        # BUY positions are not score-ranked away. Keep the existing stable order and only append new
        # confirmed BUYs; this is a management board, not a discovery competition.
        buys=[c for c in cands if c.last_buy_price and c.last_buy_venue in (Venue.KRX,Venue.NXT)]
        by={c.code:c for c in buys};old_pos=self.stable_codes.get('position_manager',[])
        pos=[by[x] for x in old_pos if x in by]
        for c in sorted(buys,key=lambda x:x.last_buy_at):
            if c.code not in {x.code for x in pos}:pos.append(c)
        pos=pos[:5];self.stable_codes['position_manager']=[c.code for c in pos]
        candidate_boards={'prebuy':pre,'opening':opening,'live_buy':live_buy,'nxt_early':nxt,'nxt_management':nxt_mgmt}
        for name,rows in candidate_boards.items():self.top5.apply(name,rows,self.state.candidates)
        # Display projection is a read-only layer.  It never changes Candidate/ENTRY state.
        # PREBUY/general boards render the freshest live venue, rather than qualifying on
        # c.current() and then accidentally displaying a stale higher-score venue.
        boards={'prebuy':[self.projection.row(c,now) for c in pre],
                'opening':[self.projection.row(c,now,Venue.NXT if c.origin==Origin.PRIOR_CLOSE else Venue.UNKNOWN,False) for c in opening],
                'live_buy':[self.projection.row(c,now,c.last_buy_venue if c.last_buy_venue in (Venue.KRX,Venue.NXT) else Venue.UNKNOWN,False) for c in live_buy],
                'nxt_early':[self.projection.row(c,now,Venue.NXT,True) for c in nxt],
                'nxt_management':[self.projection.row(c,now,Venue.NXT,True) for c in nxt_mgmt],
                'position_manager':[self.projection.row(c,now,c.last_buy_venue,True) for c in pos]}
        projection_rows=[row for rows in boards.values() for row in rows]
        self.state.telemetry['display_projection_fallback_rows']=sum(1 for row in projection_rows if row.get('display_venue_fallback'))
        self.state.telemetry['display_projection_stale_rows']=sum(1 for row in projection_rows if row.get('display_stale'))
        for row,c in zip(boards['opening'],opening):
            if not row.get('price') and c.close_signal_price:row['reference_price']=c.close_signal_price;row['reference_price_type']='PRIOR_CLOSE'
        # Table-local overnight fallback only. It can never cover an active live table.
        if sec_of_day()<7*3600+30*60 and not sessions()['active']:
            with self.lock:fb=dict(self.fallback)
            for k in boards:
                if not boards[k] and (fb.get('boards') or {}).get(k):boards[k]=list((fb.get('boards') or {}).get(k) or [])[:5]
        self._observe_ui_latency(pre);self._observe_ui_latency(live_buy);self._observe_ui_latency(nxt,Venue.NXT)
        history=[]
        for c in cands:
            for e in list(c.history)[-4:]:history.append({'code':c.code,'name':c.name or c.code,'at':e.at,'state':e.state,'kind':e.kind,'price':e.price,'venue':e.venue.value,'reason':e.reason})
        history.sort(key=lambda x:x['at'],reverse=True)
        snap={'type':'snapshot','version':SETTINGS.version,'generated_at':now,'feed_state':self.state.feed_state.value,'generation':self.generation+1,'phase':phase,'feed':dict(self.state.ws_status),'load_mode':self.state.load_mode,'telemetry':dict(self.state.telemetry),'boards':boards,'signal_history':history[:30],'candidate_count':len(cands),'hot_count':hot_count,'pinned_count':pinned_count}
        with self.lock:self.generation+=1;self.snapshot=snap
    async def run(self):
        while True:self.build();await asyncio.sleep(SETTINGS.ui_delta_ms/1000)
