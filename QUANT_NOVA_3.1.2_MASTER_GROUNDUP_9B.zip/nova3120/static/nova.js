(()=>{
const $=id=>document.getElementById(id);let token=localStorage.getItem('nova_token')||'';let socket=null;let recoveryTimer=null;let livePollTimer=null;let lastSnap=null;
const api=async path=>{const h={'Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache'};if(token){h['X-App-Token']=token;h['Authorization']='Bearer '+token;}const sep=path.includes('?')?'&':'?';const r=await fetch(path+sep+'ui_ts='+Date.now(),{headers:h,cache:'no-store'});if(r.status===401||r.status===403)throw new Error('AUTH');if(!r.ok)throw new Error('HTTP_'+r.status);return r.json()};
const fmt=(v,d=0)=>v===null||v===undefined||v===''?'-':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d,minimumFractionDigits:d});
const cls=v=>Number(v)>0?'up':Number(v)<0?'down':'';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function rowHtml(r){if(!r)return `<div class="row empty"><div class="name"><b>-</b><small>대기</small></div><div></div><div></div><div></div><div></div></div>`;let re=Number(r.top5_reentry_count||0)>0?' · [재등장]':'';let sub=`${esc(r.venue||'-')} · ${esc(r.entry_state||r.stage||'-')}${re}`;let ret=r.buy_return??r.signal_return;return `<div class="row" data-code="${esc(r.code)}"><div class="name"><b>${esc(r.name||r.code)}</b><small>${sub}</small></div><div class="num">${fmt(r.price||r.reference_price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="num">${fmt(r.score,1)}점</div><div class="num ${cls(ret)}">${fmt(ret,2)}%</div><div class="state"><span class="badge">${esc(r.lifecycle_state||r.stage||'-')}</span><small style="display:block;color:#8995a8;margin-top:3px">반복 ${fmt(r.valid_repeat_count||0)}</small></div></div>`}
function board(id,rows){const arr=(rows||[]).slice(0,5);while(arr.length<5)arr.push(null);$(id).innerHTML=arr.map(rowHtml).join('');$(id).querySelectorAll('.row[data-code]').forEach(x=>x.onclick=()=>detail(x.dataset.code));}
function applyPayload(msg){if(msg?.type!=='delta')return msg;if(!lastSnap||Number(lastSnap.generation)!==Number(msg.base_generation))return null;const p=msg.patch||{};const next={...lastSnap,...p,generation:msg.generation,generated_at:msg.generated_at,type:'snapshot'};if(p.boards)next.boards={...(lastSnap.boards||{}),...p.boards};return next}
function render(s){lastSnap=s;$('version').textContent=s.version||'-';$('feed').textContent=s.feed_state|| (s.feed?.connected?'CONNECTED':(s.feed?.last_error||'WAIT')); $('phase').textContent=s.phase||'-';$('candidates').textContent=s.candidate_count||0;$('hot').textContent=s.hot_count||0;$('registered').textContent=s.feed?.registered||0;$('ws').textContent=s.feed?.connected?'OPEN':'CLOSED';$('rss').textContent=(s.telemetry?.rss_mb??'-')+'M';$('queue').textContent=s.telemetry?.trade_queue_depth??'-';$('lag').textContent=(s.telemetry?.event_loop_lag_p95_ms??'-')+'ms';for(const id of ['prebuy','opening','live_buy','nxt_early','nxt_management','position_manager'])board(id,s.boards?.[id]||[]);$('history').innerHTML=(s.signal_history||[]).map(h=>`<div class="hist"><span>${new Date(h.at*1000).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span><span>${h.name} · ${h.kind} · ${h.reason||''}</span><span>${h.state}</span></div>`).join('');}
async function detail(code){const scroll=window.scrollY;try{const [j,p]=await Promise.all([api('/api/signal-history/'+encodeURIComponent(code)),api('/api/performance/'+encodeURIComponent(code))]);$('modalTitle').textContent=code+' SIGNAL HISTORY';const hist=(j.rows||[]).map(x=>`<div class="detail"><label>${new Date(x.at*1000).toLocaleTimeString()}</label><div><b>${esc(x.kind)} · ${esc(x.state)}</b><br>${esc(x.reason||'')} · ${fmt(x.price)}</div></div>`).join('');const perf=(p.rows||[]).map(x=>`<div class="detail"><label>${x.horizon}거래일</label><div><b>${esc(x.target_day)} · ${esc(x.status)}</b><br>${esc(x.venue)} ${fmt(x.close_price)} · <span class="${cls(x.return_pct)}">${fmt(x.return_pct,2)}%</span></div></div>`).join('');$('modalBody').innerHTML=(hist||'기록 없음')+(perf?`<h4>1/3/5 거래일 성과</h4>${perf}`:'');$('modal').classList.remove('hidden');$('modal').dataset.scroll=scroll;}catch(e){}}
$('close').onclick=()=>{const y=Number($('modal').dataset.scroll||0);$('modal').classList.add('hidden');requestAnimationFrame(()=>scrollTo(0,y))};
async function auth(){
  try{
    let j=await api('/api/auth/check');
    if(!j.auth_required)return true;
    if(j.ok)return true;
    if(token){localStorage.removeItem('nova_token');token=''}
    const entered=(prompt('QUANT NOVA 접근 토큰')||'').trim();
    if(!entered){$('feed').textContent='AUTH REQUIRED';return false}
    token=entered;
    j=await api('/api/auth/check');
    if(j.ok){localStorage.setItem('nova_token',token);return true}
    localStorage.removeItem('nova_token');token='';
    $('feed').textContent='AUTH ERROR';return false
  }catch(e){
    $('feed').textContent=String(e).includes('AUTH')?'AUTH ERROR':'SERVER RETRY';
    return false
  }
}

function startLivePoll(){if(livePollTimer)return;livePollTimer=setInterval(async()=>{try{render(await api('/api/live-dashboard'))}catch(e){}},2000)};
function connect(){if(socket)try{socket.close()}catch(e){};const proto=location.protocol==='https:'?'wss':'ws';socket=new WebSocket(`${proto}://${location.host}/ws/live${token?'?token='+encodeURIComponent(token):''}`);socket.onmessage=e=>{try{const msg=JSON.parse(e.data);const next=applyPayload(msg);if(next)render(next);else api('/api/live-dashboard').then(render).catch(()=>{})}catch(_){}};socket.onopen=()=>{if(recoveryTimer){clearInterval(recoveryTimer);recoveryTimer=null}};socket.onclose=()=>{if(!recoveryTimer)recoveryTimer=setInterval(async()=>{try{render(await api('/api/live-dashboard'));connect()}catch(e){}},5000)};}
setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('ko-KR')},1000);
async function boot(){
  const ok=await auth();
  if(!ok){
    if($('feed').textContent==='SERVER RETRY')setTimeout(boot,3000);
    return;
  }
  try{render(await api('/api/live-dashboard'))}catch(e){$('feed').textContent='SERVER RETRY'}
  startLivePoll();connect();
  if('serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
}
boot();
})();
