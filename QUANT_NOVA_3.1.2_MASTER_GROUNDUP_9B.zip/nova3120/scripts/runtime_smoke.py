from __future__ import annotations
import argparse,asyncio,json,os,time,urllib.parse,urllib.request
import websockets

BOARDS={'prebuy','opening','live_buy','nxt_early','nxt_management','position_manager'}
TOKEN=os.getenv('APP_ACCESS_TOKEN','').strip()

def get(url:str,timeout=3):
    req=urllib.request.Request(url,headers={'X-App-Token':TOKEN} if TOKEN else {})
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)

async def ws_round(uri:str,n:int):
    if TOKEN:
        sep='&' if '?' in uri else '?';uri=uri+sep+'token='+urllib.parse.quote(TOKEN,safe='')
    async def one(_):
        async with websockets.connect(uri,open_timeout=3,close_timeout=1) as ws:
            msg=json.loads(await asyncio.wait_for(ws.recv(),3));assert msg.get('type') in ('snapshot','delta'),msg
            return int(msg.get('generation') or 0)
    return await asyncio.gather(*(one(i) for i in range(n)))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--base',default='http://127.0.0.1:8000');ap.add_argument('--ws',default='ws://127.0.0.1:8000/ws/live');ap.add_argument('--clients',type=int,default=3);ap.add_argument('--ready-timeout',type=float,default=30.0);a=ap.parse_args()
    deadline=time.time()+max(1.0,a.ready_timeout);ready=None
    while time.time()<deadline:
        try:
            live=get(a.base+'/api/livez');assert live.get('ok'),live
            ready=get(a.base+'/api/readyz')
            if ready.get('ok'):break
        except Exception:pass
        time.sleep(.2)
    assert ready and ready.get('ok'),ready
    dash=get(a.base+'/api/live-dashboard');assert set((dash.get('boards') or {}).keys())==BOARDS,(dash.get('boards') or {}).keys()
    health=get(a.base+'/api/realtime-health');assert health.get('ok'),health
    j=health.get('journal') or {};t=health.get('telemetry') or {};m=health.get('memory') or {}
    assert j.get('ready') is True,j
    assert int(j.get('db_init_fail') or 0)==0,j
    assert int(j.get('important_enqueue_fail') or 0)==0,j
    assert int(j.get('wal_hard_stall_exit') or 0)==0,j
    assert int(j.get('event_hard_stall_exit') or 0)==0,j
    for k in ('signal_price_mismatch_count','wrong_venue_price_count','signal_without_live_snapshot_count'):
        assert int(t.get(k) or 0)==0,(k,t.get(k))
    assert float(m.get('swap_mb') or 0)==0,m
    gens=asyncio.run(ws_round(a.ws,max(1,a.clients)))
    print(json.dumps({'RUNTIME_SMOKE':'PASS','version':live.get('version'),'clients':a.clients,'generation_min':min(gens),'generation_max':max(gens),'rss_mb':m.get('rss_mb'),'swap_mb':m.get('swap_mb')},ensure_ascii=False))
if __name__=='__main__':main()
