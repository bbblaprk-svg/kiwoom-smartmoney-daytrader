from __future__ import annotations
import asyncio, json, math, os, time, re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
import httpx, websockets
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_VERSION='NOVA-1.6.0'
KST=ZoneInfo('Asia/Seoul')
BASE=Path(__file__).resolve().parent.parent
DATA_DIR=Path(os.getenv('NOVA_DATA_DIR', str(BASE/'data')))
DATA_DIR.mkdir(parents=True, exist_ok=True)
EVENT_FILE=DATA_DIR/'signal_events.jsonl'
STATE_FILE=DATA_DIR/'performance_state.json'
LEARN_FILE=DATA_DIR/'adaptive_entry_model_v3.json'
TRAIN_FILE=DATA_DIR/'entry_training_events_v3.jsonl'
BUY_SIGNAL_FILE=DATA_DIR/'buy_entry_events_v3.jsonl'
BUY_SIGNAL_STATE=DATA_DIR/'buy_entry_state_v3.json'
API='https://api.kiwoom.com'
WS='wss://api.kiwoom.com:10000/api/dostk/websocket'
APP_KEY=os.getenv('KIWOOM_APP_KEY','').strip()
SECRET=(os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
DISCOVERY_SECONDS=max(10,int(os.getenv('NOVA_DISCOVERY_SECONDS','20')))
WS_LIMIT=max(20,min(80,int(os.getenv('NOVA_WS_LIMIT','60'))))
MIN_SCORE=float(os.getenv('NOVA_MIN_SCORE','58'))
FRESH_MS=max(1500,int(os.getenv('NOVA_FRESH_MS','5000')))
DISPLAY_FRESH_MS=max(FRESH_MS,int(os.getenv('NOVA_DISPLAY_FRESH_MS','12000')))
SMART_POLL_SECONDS=max(5,int(os.getenv('NOVA_SMART_POLL_SECONDS','8')))
SMART_POLL_BATCH=max(3,min(12,int(os.getenv('NOVA_SMART_POLL_BATCH','8'))))
LEARN_MIN_SAMPLES=max(30,int(os.getenv('NOVA_LEARN_MIN_SAMPLES','60')))
LEARN_MAX_ADJUST=float(os.getenv('NOVA_LEARN_MAX_ADJUST','0.30'))
SECTOR_MAX_BONUS=max(0.0,min(10.0,float(os.getenv('NOVA_SECTOR_MAX_BONUS','8'))))
# Balanced dual-entry policy.  The goal is not a signal quota: preserve high-quality pullback entries
# while adding a tightly gated DIRECT_IGNITION route for strong names that never offer a clean pullback.
ENTRY_PRESSURE_SCORE=float(os.getenv('NOVA_ENTRY_PRESSURE_SCORE','62'))
ENTRY_HOLD_SEC=max(5,int(os.getenv('NOVA_ENTRY_HOLD_SEC','8')) )
ENTRY_PULLBACK_MIN=float(os.getenv('NOVA_ENTRY_PULLBACK_MIN','0.12'))
ENTRY_PULLBACK_MAX=float(os.getenv('NOVA_ENTRY_PULLBACK_MAX','2.00'))
ENTRY_REACCEL_SEC=max(2,int(os.getenv('NOVA_ENTRY_REACCEL_SEC','3')) )
ENTRY_COOLDOWN_SEC=max(300,int(os.getenv('NOVA_ENTRY_COOLDOWN_SEC','600')) )
ENTRY_REENTRY_MIN_SEC=max(240,int(os.getenv('NOVA_ENTRY_REENTRY_MIN_SEC','420')) )
ENTRY_REENTRY_GAIN_PCT=float(os.getenv('NOVA_ENTRY_REENTRY_GAIN_PCT','1.20'))
ENTRY_MAX_DAILY=max(1,min(6,int(os.getenv('NOVA_ENTRY_MAX_DAILY','4'))))
ENTRY_MAX_VWAP_GAP=float(os.getenv('NOVA_ENTRY_MAX_VWAP_GAP','1.50'))
ENTRY_MAX_IMPULSE=float(os.getenv('NOVA_ENTRY_MAX_IMPULSE','2.50'))
ENTRY_MIN_BUY_PRESSURE=float(os.getenv('NOVA_ENTRY_MIN_BUY_PRESSURE','56'))
ENTRY_MIN_ALGO_PERSIST=float(os.getenv('NOVA_ENTRY_MIN_ALGO_PERSIST','55'))
DIRECT_SCORE=float(os.getenv('NOVA_DIRECT_SCORE','75'))
DIRECT_HOLD_SEC=max(3,int(os.getenv('NOVA_DIRECT_HOLD_SEC','6')) )
DIRECT_CONFIRM_SEC=max(2,int(os.getenv('NOVA_DIRECT_CONFIRM_SEC','3')) )
DIRECT_MIN_BUY_PRESSURE=float(os.getenv('NOVA_DIRECT_MIN_BUY_PRESSURE','61'))
DIRECT_MIN_ALGO_PERSIST=float(os.getenv('NOVA_DIRECT_MIN_ALGO_PERSIST','60'))
DIRECT_MIN_ACCEL=float(os.getenv('NOVA_DIRECT_MIN_ACCEL','1.65'))
DIRECT_MIN_BREAKOUT=float(os.getenv('NOVA_DIRECT_MIN_BREAKOUT','0.20'))
DIRECT_MIN_IMPULSE=float(os.getenv('NOVA_DIRECT_MIN_IMPULSE','0.25'))
DIRECT_MAX_IMPULSE=float(os.getenv('NOVA_DIRECT_MAX_IMPULSE','1.80'))
DIRECT_MAX_VWAP_GAP=float(os.getenv('NOVA_DIRECT_MAX_VWAP_GAP','1.10'))
SECTOR_MAP_FILE=DATA_DIR/'sector_map.json'

# Rally DNA: only completed sessions teach the next session. Intraday traces are compact
# snapshots of the information that was available at that moment; labels are assigned after close.
RALLY_MODEL_FILE=DATA_DIR/'rally_dna_model.json'
RALLY_SAMPLE_FILE=DATA_DIR/'rally_dna_samples.jsonl'
RALLY_REVIEW_FILE=DATA_DIR/'rally_daily_review.json'
RALLY_TRACE_INTERVAL=max(30,int(os.getenv('NOVA_RALLY_TRACE_INTERVAL','60')))
RALLY_TRACE_TOP=max(30,min(120,int(os.getenv('NOVA_RALLY_TRACE_TOP','80'))))
RALLY_MIN_SAMPLES=max(12,int(os.getenv('NOVA_RALLY_MIN_SAMPLES','30')))
RALLY_MAX_BONUS=max(0.0,min(10.0,float(os.getenv('NOVA_RALLY_MAX_BONUS','8'))))
RALLY_MAX_PENALTY=max(0.0,min(8.0,float(os.getenv('NOVA_RALLY_MAX_PENALTY','6'))))
RALLY_TRIGGER_RATE=float(os.getenv('NOVA_RALLY_TRIGGER_RATE','5.0'))
RALLY_TARGET_RATE=float(os.getenv('NOVA_RALLY_TARGET_RATE','10.0'))
RALLY_TRACE_KEEP_DAYS=max(5,int(os.getenv('NOVA_RALLY_TRACE_KEEP_DAYS','20')))
RALLY_FEATURES=['volume_accel','buy_pressure','algo_persistence','impulse','vwap_gap','micro_breakout','compression','dual_venue','program_delta','trust_delta','pension_delta','institution_delta','sector','overlap']

# Sector membership may be overridden by data/sector_map.json {"005930":"반도체",...}.
# The score itself is NEVER static: breadth/momentum/leader-follow diffusion are recomputed from live candidates.
SECTOR_RULES=[
 ('반도체',('반도체','삼성전자','하이닉스','DB하이텍','HPSP','원익IPS','테스','피에스케이','유진테크','하나마이크론','테크윙','이오테크닉스','주성엔지니어링','한미반도체','ISC','리노공업','가온칩스','에이디테크놀로지','오픈엣지')),
 ('로봇·자동화',('로보','로봇','레인보우','뉴로메카','두산로보틱스','에스피지','에스비비','유일로보틱스','티로보틱스','클로봇','하이젠알앤엠')),
 ('전력·전선·그리드',('전기','전선','일진전기','제룡','효성중공업','HD현대일렉트릭','LS ELECTRIC','LS에코','가온전선','대원전선','산일전기')),
 ('2차전지·ESS',('에코프로','포스코퓨처엠','엘앤에프','천보','대주전자재료','나노신소재','솔브레인','엔켐','동화기업','후성','2차전지','배터리','전고체','ESS')),
 ('방산·항공우주',('한화에어로','현대로템','LIG넥스원','한국항공우주','풍산','퍼스텍','SNT다이내믹스','우주','항공','방산')),
 ('조선·해양',('HD현대중공업','한화오션','삼성중공업','HD한국조선해양','HD현대미포','세진중공업','성광벤드','태광','조선','해양')),
 ('바이오·의료',('바이오','제약','헬스','셀트리온','유한양행','리가켐','알테오젠','에이비엘','펩트론','루닛','뷰노','메디','덴티','클래시스')),
 ('AI·소프트웨어',('AI','인공지능','소프트','더존','한글과컴퓨터','폴라리스','마음AI','솔트룩스','코난테크','플리토','엠로','NAVER','카카오')),
 ('자동차·자율주행',('현대차','기아','현대모비스','HL만도','에스엘','화신','성우하이텍','자동차','자율주행','모트렉스','스마트레이더','퓨런티어')),
 ('화학·소재',('케미칼','화학','소재','금양','코스모','롯데케미칼','금호석유','효성첨단소재','OCI','한솔케미칼','PI첨단소재')),
 ('원전·에너지',('두산에너빌리티','한전기술','한전KPS','우진','우리기술','비에이치아이','원전','원자력','태양광','풍력','에너지')),
 ('건설·인프라',('건설','건설기계','대우건설','현대건설','GS건설','DL이앤씨','HDC현대산업','두산밥캣','HD현대인프라코어')),
 ('금융·증권',('증권','금융','은행','보험','미래에셋','키움증권','한국금융','삼성증권','NH투자','KB금융','신한지주','하나금융')),
 ('소비·뷰티',('화장품','뷰티','아모레','LG생활건강','에이피알','실리콘투','브이티','클리오','코스맥스','한국콜마')),
]
ETF_PREFIX=('KODEX','TIGER','ACE ','RISE ','SOL ','HANARO','KOSEF','KBSTAR','PLUS ','TIMEFOLIO')


def num(x, d=0.0):
    try:
        s=str(x).strip().replace(',','')
        if not s:return d
        return float(s)
    except Exception:return d

def code6(x):
    s=str(x or '').strip().upper().replace('_NX','').replace('_AL','')
    m=re.search(r'(\d{6})',s)
    return m.group(1) if m else ''

def clamp(x,a=0,b=100): return max(a,min(b,x))
def now_kst(): return datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
def hmss(): return datetime.now(KST).strftime('%H:%M:%S')
def today_kst(): return datetime.now(KST).strftime('%Y%m%d')
def fmt_kst(ts, fmt='%Y-%m-%d %H:%M:%S'):
    return datetime.fromtimestamp(float(ts), KST).strftime(fmt) if ts else None
def kst_seconds():
    t=datetime.now(KST); return t.hour*3600+t.minute*60+t.second

def between(sec, a, b): return a <= sec < b

def market_session():
    """Operational session truth used only for UI/feed gating.
    KRX regular 09:00-15:30. NXT windows follow the validated service schedule
    used by the prior production collector: 08:00-08:50, 09:00:30-15:20, 15:40-20:00.
    """
    s=kst_seconds()
    krx=between(s,9*3600,15*3600+30*60)
    nxt=(between(s,8*3600,8*3600+50*60) or
         between(s,9*3600+30,15*3600+20*60) or
         between(s,15*3600+40*60,20*3600))
    if krx and nxt: phase='KRX+NXT LIVE'
    elif krx: phase='KRX LIVE'
    elif nxt: phase='NXT LIVE'
    elif s < 8*3600: phase='PRE-MARKET'
    elif s >= 20*3600: phase='MARKET CLOSED'
    else: phase='SESSION GAP'
    return {'krx':krx,'nxt':nxt,'active':krx or nxt,'phase':phase,'kst':hmss()}

STAGE_RANK={'SEED':0,'WATCH':1,'PRESSURE':2,'IGNITION':3,'BUY':4}
ENTRY_STATES=('DISCOVERY','PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM','BUY','COOLDOWN','REJECTED')

@dataclass
class Tick:
    ts: float; price: float; qty: float; rate: float; venue: str; cumvol: float=0; turnover: float=0

@dataclass
class Capture:
    stage: str
    at: float
    price: float
    score: float
    venue: str
    current_price: float=0
    current_return: float=0
    max_price: float=0
    max_return: float=0
    min_price: float=0
    min_return: float=0
    features: dict[str,float]=field(default_factory=dict)

@dataclass
class Candidate:
    code: str
    name: str=''
    sector: str=''
    sector_source: str=''
    source_hits: dict[str,float]=field(default_factory=dict)
    ticks: deque=field(default_factory=lambda:deque(maxlen=900))
    last_price: float=0
    rate: float=0
    venue: str=''
    last_fid9081: str=''
    last_tick_at: float=0
    first_seen: float=field(default_factory=time.time)
    score: float=0
    confidence: float=0
    stage: str='SEED'
    reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict)
    captures: dict[str,Capture]=field(default_factory=dict)
    highest_stage: str='SEED'
    smart: dict[str,Any]=field(default_factory=dict)
    smart_updated_at: float=0
    previous_stage: str='SEED'
    signal_count: int=0
    signal_count_today: int=0
    first_signal_at: float=0
    last_signal_at: float=0
    last_signal_price: float=0
    last_signal_score: float=0
    last_signal_stage: str=''
    last_signal_reasons: list[str]=field(default_factory=list)
    signal_max_price: float=0
    signal_min_price: float=0
    entry_state: str='DISCOVERY'
    entry_state_since: float=0
    pressure_started_at: float=0
    pressure_peak: float=0
    pullback_low: float=0
    reaccel_started_at: float=0
    reaccel_start_price: float=0
    cooldown_until: float=0
    last_buy_at: float=0
    last_buy_entry_id: str=''
    last_buy_route: str=''
    direct_started_at: float=0
    direct_start_price: float=0
    reentry_unlocked: bool=False
    reject_reason: str=''

class TokenManager:
    def __init__(self): self.token=''; self.exp=0; self.lock=asyncio.Lock()
    async def get(self):
        if self.token and time.time()<self.exp-120:return self.token
        async with self.lock:
            if self.token and time.time()<self.exp-120:return self.token
            if not APP_KEY or not SECRET: raise RuntimeError('KIWOOM_APP_KEY / KIWOOM_SECRET_KEY 환경변수 필요')
            async with httpx.AsyncClient(timeout=12) as c:
                r=await c.post(API+'/oauth2/token',json={'grant_type':'client_credentials','appkey':APP_KEY,'secretkey':SECRET})
                r.raise_for_status(); j=r.json()
                if int(j.get('return_code',0))!=0: raise RuntimeError(j.get('return_msg') or 'token error')
                self.token=j['token']; self.exp=time.time()+23*3600
                return self.token
TOK=TokenManager()

class NovaState:
    def __init__(self):
        self.candidates: dict[str,Candidate]={}
        self.rest_status={}
        self.ws_status={'connected':False,'ack':0,'last_error':'','last_message_at':0,'last_trade_at':0,'last_trade_code':'','last_trade_venue':'','last_fid9081':''}
        self.generated_at=0; self.lock=asyncio.Lock(); self.ws_codes=[]
        self.scan_cycles=0; self.raw_rest_samples={}; self.event_count=0; self.last_persist=0
        self.smart_cursor=0; self.smart_status={}; self.sector_status={}; self.learn={'samples':0,'positive':0,'weights':{},'last_update':None,'active':False}; self.buy_signal_events=0
        self.rally_model={}; self.rally_review={'reviewed_days':[]}; self.rally_status={'samples':0,'positive':0,'negative':0,'active':False,'effective_from_day':None,'last_review_day':None,'last_review_at':None,'types':{},'trace_rows_today':0}; self.last_rally_trace=0
    def get(self,code,name=''):
        if code not in self.candidates:self.candidates[code]=Candidate(code,name)
        elif name and not self.candidates[code].name:self.candidates[code].name=name
        return self.candidates[code]
STATE=NovaState()

def load_performance():
    try:
        if STATE_FILE.exists():
            saved=json.loads(STATE_FILE.read_text(encoding='utf-8'))
            for code,row in (saved.get('rows') or {}).items():
                c=STATE.get(code6(code) or code,str(row.get('name') or ''))
                for st,d in (row.get('captures') or {}).items():
                    try:
                        c.captures[st]=Capture(stage=str(d.get('stage') or str(st).split('@',1)[0]),at=float(d.get('at') or time.time()),price=float(d.get('price') or 0),score=float(d.get('score') or 0),venue=str(d.get('venue') or ''),current_price=float(d.get('current_price') or 0),current_return=float(d.get('current_return') or 0),max_price=float(d.get('max_price') or 0),max_return=float(d.get('max_return') or 0),min_price=float(d.get('min_price') or 0),min_return=float(d.get('min_return') or 0),features={k:float(v) for k,v in (d.get('features') or {}).items()})
                    except Exception:
                        pass
                if c.captures:
                    c.highest_stage=max((cap.stage for cap in c.captures.values()),key=lambda x:STAGE_RANK.get(x,0))
        if EVENT_FILE.exists():
            with EVENT_FILE.open('r',encoding='utf-8',errors='ignore') as f: STATE.event_count=sum(1 for _ in f)
    except Exception:
        pass

load_performance()

def load_buy_signal_state():
    try:
        if BUY_SIGNAL_STATE.exists():
            d=json.loads(BUY_SIGNAL_STATE.read_text(encoding='utf-8'))
            saved_day=str(d.get('day') or '')
            today=today_kst()
            for code,row in (d.get('rows') or {}).items():
                c=STATE.get(code6(code) or code,str(row.get('name') or ''))
                c.signal_count=int(row.get('signal_count') or 0)
                c.signal_count_today=int(row.get('signal_count_today') or 0) if saved_day==today else 0
                c.first_signal_at=float(row.get('first_signal_at') or 0)
                c.last_signal_at=float(row.get('last_signal_at') or 0)
                c.last_signal_price=float(row.get('last_signal_price') or 0)
                c.last_signal_score=float(row.get('last_signal_score') or 0)
                c.last_signal_stage=str(row.get('last_signal_stage') or '')
                c.last_signal_reasons=list(row.get('last_signal_reasons') or [])[:5]
                c.signal_max_price=float(row.get('signal_max_price') or c.last_signal_price or 0)
                c.signal_min_price=float(row.get('signal_min_price') or c.last_signal_price or 0)
                c.entry_state=str(row.get('entry_state') or 'DISCOVERY')
                c.entry_state_since=float(row.get('entry_state_since') or 0)
                c.pressure_started_at=float(row.get('pressure_started_at') or 0)
                c.pressure_peak=float(row.get('pressure_peak') or 0)
                c.pullback_low=float(row.get('pullback_low') or 0)
                c.reaccel_started_at=float(row.get('reaccel_started_at') or 0)
                c.reaccel_start_price=float(row.get('reaccel_start_price') or 0)
                c.cooldown_until=float(row.get('cooldown_until') or 0)
                c.last_buy_at=float(row.get('last_buy_at') or c.last_signal_at or 0)
                c.last_buy_entry_id=str(row.get('last_buy_entry_id') or '')
                c.last_buy_route=str(row.get('last_buy_route') or '')
                c.direct_started_at=float(row.get('direct_started_at') or 0)
                c.direct_start_price=float(row.get('direct_start_price') or 0)
                c.reentry_unlocked=bool(row.get('reentry_unlocked') or False)
                c.reject_reason=str(row.get('reject_reason') or '')
        if BUY_SIGNAL_FILE.exists():
            with BUY_SIGNAL_FILE.open('r',encoding='utf-8',errors='ignore') as f: STATE.buy_signal_events=sum(1 for _ in f)
    except Exception:
        pass

load_buy_signal_state()

FEATURE_KEYS=['rest','volume_accel','buy_pressure','impulse','vwap_gap','micro_breakout','dual_venue','program','trust','pension','institution','foreign','sector']
BASE_FEATURE_WEIGHTS={'rest':1.0,'volume_accel':1.0,'buy_pressure':1.0,'impulse':1.0,'vwap_gap':1.0,'micro_breakout':1.0,'dual_venue':1.0,'program':1.0,'trust':1.0,'pension':1.0,'institution':1.0,'foreign':0.7,'sector':1.0}

def load_learning():
    try:
        if LEARN_FILE.exists():
            d=json.loads(LEARN_FILE.read_text(encoding='utf-8'))
            w={k:float((d.get('weights') or {}).get(k,1.0)) for k in FEATURE_KEYS}
            STATE.learn={'samples':int(d.get('samples') or 0),'positive':int(d.get('positive') or 0),'weights':w,'last_update':d.get('last_update'),'active':int(d.get('samples') or 0)>=LEARN_MIN_SAMPLES}
        else: STATE.learn['weights']=dict(BASE_FEATURE_WEIGHTS)
    except Exception: STATE.learn['weights']=dict(BASE_FEATURE_WEIGHTS)
load_learning()
try:
    STATE.trained_ids=set()
    if TRAIN_FILE.exists():
        for line in TRAIN_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line); STATE.trained_ids.add(str(x.get('id') or ''))
            except Exception: pass
except Exception: STATE.trained_ids=set()

def learner_weight(k):
    if not STATE.learn.get('active'): return 1.0
    return clamp(float((STATE.learn.get('weights') or {}).get(k,1.0)),1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST)

def norm_signed(v, scale): return clamp(num(v)/max(scale,1),-1,1)

def feature_vector(c:Candidate):
    m=c.metrics; sm=c.smart or {}
    return {
      'rest': clamp(num(m.get('rest_base'))/80,0,1),
      'volume_accel': clamp((num(m.get('volume_accel'))-1)/2.5,0,1),
      'buy_pressure': clamp((num(m.get('buy_pressure'))-50)/30,0,1),
      'impulse': clamp(num(m.get('impulse_60s'))/3,0,1),
      'vwap_gap': clamp(num(m.get('vwap_gap'))/2,0,1),
      'micro_breakout': clamp(num(m.get('micro_breakout'))/2,0,1),
      'dual_venue': 1.0 if m.get('dual_venue') else 0.0,
      'program': norm_signed(sm.get('program_net'), max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),1)),
      'trust': norm_signed(sm.get('trust_net'), max(abs(num(sm.get('institution_net'))),1000)),
      'pension': norm_signed(sm.get('pension_net'), max(abs(num(sm.get('institution_net'))),1000)),
      'institution': norm_signed(sm.get('institution_net'), max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000)),
      'foreign': norm_signed(sm.get('foreign_net'), max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000)),
      'sector': clamp(num(m.get('sector_score'))/max(SECTOR_MAX_BONUS,1),-1,1),
    }

def rally_trace_file(day:str|None=None):
    return DATA_DIR/f"rally_trace_{day or today_kst()}.jsonl"

def _mean_vectors(rows):
    if not rows:return {k:0.0 for k in RALLY_FEATURES}
    return {k:round(sum(float((r or {}).get(k) or 0) for r in rows)/len(rows),6) for k in RALLY_FEATURES}

def _dist(a,b):
    if not a or not b:return 1.0
    return math.sqrt(sum((float(a.get(k,0))-float(b.get(k,0)))**2 for k in RALLY_FEATURES)/max(len(RALLY_FEATURES),1))

def rally_vector(c:Candidate, override:dict|None=None):
    m=dict(c.metrics or {}); m.update(override or {}); sm=c.smart or {}
    inst_scale=max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1_000_000)
    prog_scale=max(abs(num(sm.get('program_net'))),100_000)
    return {
      'volume_accel':clamp((num(m.get('volume_accel'),1)-1)/2.5,0,1),
      'buy_pressure':clamp((num(m.get('buy_pressure'),50)-50)/30,-1,1),
      'algo_persistence':clamp((num(m.get('algo_persistence'),50)-50)/35,-1,1),
      'impulse':clamp(num(m.get('impulse_60s'))/2.5,-1,1),
      'vwap_gap':clamp(num(m.get('vwap_gap'))/1.5,-1,1),
      'micro_breakout':clamp(num(m.get('micro_breakout'))/1.5,0,1),
      'compression':clamp(num(m.get('compression')),0,1),
      'dual_venue':1.0 if m.get('dual_venue') else 0.0,
      'program_delta':clamp(num(sm.get('program_delta'))/prog_scale,-1,1),
      'trust_delta':clamp(num(sm.get('trust_delta'))/inst_scale,-1,1),
      'pension_delta':clamp(num(sm.get('pension_delta'))/inst_scale,-1,1),
      'institution_delta':clamp(num(sm.get('institution_delta'))/inst_scale,-1,1),
      'sector':clamp(num(m.get('sector_score'))/max(SECTOR_MAX_BONUS,1),-1,1),
      'overlap':clamp(num(m.get('discovery_overlap'))/5,0,1),
    }

def rally_dna_type(v:dict, c:Candidate|None=None):
    scores={
      'ACCUMULATION':max(0,v.get('program_delta',0))+max(0,v.get('trust_delta',0))+max(0,v.get('pension_delta',0))+0.5*max(0,v.get('institution_delta',0))+0.5*max(0,v.get('buy_pressure',0)),
      'VOLUME_IGNITION':1.5*v.get('volume_accel',0)+v.get('buy_pressure',0)+0.8*v.get('algo_persistence',0)+0.5*v.get('impulse',0),
      'SECTOR_ROTATION':1.8*max(0,v.get('sector',0))+0.7*v.get('overlap',0)+0.5*v.get('volume_accel',0),
      'SQUEEZE_BREAKOUT':1.4*v.get('compression',0)+1.2*v.get('micro_breakout',0)+0.7*v.get('buy_pressure',0),
      'NEWS_SHOCK':1.5*max(0,v.get('impulse',0))+1.2*v.get('volume_accel',0)-0.5*v.get('compression',0),
    }
    return max(scores,key=scores.get) if scores else 'UNCLASSIFIED'

def load_rally_state():
    try:
        if RALLY_MODEL_FILE.exists(): STATE.rally_model=json.loads(RALLY_MODEL_FILE.read_text(encoding='utf-8'))
    except Exception: STATE.rally_model={}
    try:
        if RALLY_REVIEW_FILE.exists(): STATE.rally_review=json.loads(RALLY_REVIEW_FILE.read_text(encoding='utf-8'))
    except Exception: STATE.rally_review={'reviewed_days':[]}
    if not isinstance(STATE.rally_review.get('reviewed_days'),list):STATE.rally_review['reviewed_days']=[]
    m=STATE.rally_model or {}; samples=int(m.get('samples') or 0); pos=int(m.get('positive') or 0)
    effective=m.get('effective_from_day'); active=bool(samples>=RALLY_MIN_SAMPLES and effective and today_kst()>=str(effective))
    STATE.rally_status.update({'samples':samples,'positive':pos,'negative':max(0,samples-pos),'active':active,'effective_from_day':effective,'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'types':m.get('types') or {}})

load_rally_state()

def rally_model_status():
    m=STATE.rally_model or {}; samples=int(m.get('samples') or 0); effective=m.get('effective_from_day')
    active=bool(samples>=RALLY_MIN_SAMPLES and effective and today_kst()>=str(effective))
    STATE.rally_status.update({'samples':samples,'positive':int(m.get('positive') or 0),'negative':int(m.get('negative') or 0),'active':active,'effective_from_day':effective,'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'types':m.get('types') or {}})
    return STATE.rally_status

def rally_live_match(c:Candidate, override:dict|None=None):
    v=rally_vector(c,override); dna=rally_dna_type(v,c); st=rally_model_status(); m=STATE.rally_model or {}
    out={'active':False,'match':None,'trap':None,'bonus':0.0,'type':dna,'samples':int(st.get('samples') or 0),'effective_from_day':st.get('effective_from_day')}
    if not st.get('active'):return out
    pos=m.get('positive_centroid') or {}; neg=m.get('negative_centroid') or {}
    type_centroids=(m.get('type_centroids') or {})
    # Prefer the most similar successful DNA family once enough examples exist for that family.
    type_best=dna; type_sim=-1
    for typ,rec in type_centroids.items():
        if int(rec.get('count') or 0)<3:continue
        sim=1-_dist(v,rec.get('centroid') or {})
        if sim>type_sim:type_sim=sim;type_best=typ
    dp=_dist(v,pos); dn=_dist(v,neg) if neg else 1.0
    match=clamp(50+(dn-dp)*72,0,100) if neg else clamp((1-dp)*100,0,100)
    trap=clamp((1-dn)*100,0,100) if neg else 0
    confidence=min(1.0,int(m.get('samples') or 0)/120.0)
    bonus=0.0
    if match>=58:bonus+=(match-58)/42*RALLY_MAX_BONUS*confidence
    if trap>=62 and trap>match:bonus-=(trap-62)/38*RALLY_MAX_PENALTY*confidence
    # The DNA engine is a pre-ignition prior, never a license to chase an already extended price.
    if num(c.rate)>=10:bonus=min(bonus,0.0)
    out.update({'active':True,'match':round(match,1),'trap':round(trap,1),'bonus':round(clamp(bonus,-RALLY_MAX_PENALTY,RALLY_MAX_BONUS),1),'type':type_best,'vector':v})
    return out

def _trace_record(c:Candidate):
    return {'ts':round(time.time(),3),'c':c.code,'n':c.name,'p':c.last_price,'r':c.rate,'s':c.score,'st':c.stage,'sec':c.sector,'v':rally_vector(c)}

def append_rally_trace():
    sess=market_session()
    if not sess.get('active'):return 0
    picks=[]; seen=set()
    for c in ranked():
        if c.code in seen:continue
        if len(picks)>=RALLY_TRACE_TOP:break
        if c.last_price>0 and ((c.last_tick_at and time.time()-c.last_tick_at<=DISPLAY_FRESH_MS) and (c.score>=35 or c.rate>=2 or len(c.source_hits)>=3)):
            picks.append(c);seen.add(c.code)
    if not picks:return 0
    path=rally_trace_file()
    with path.open('a',encoding='utf-8') as f:
        for c in picks:f.write(json.dumps(_trace_record(c),ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.rally_status['trace_rows_today']=int(STATE.rally_status.get('trace_rows_today') or 0)+len(picks)
    return len(picks)

def _weighted_pre_vector(rows,event_ts):
    targets=[(3600,0.10),(1800,0.20),(900,0.30),(300,0.40)]; picked=[]; total=0.0; timeline={}
    for sec,w in targets:
        before=[x for x in rows if x['ts']<=event_ts-sec]
        if not before:continue
        x=max(before,key=lambda z:z['ts']); age=event_ts-x['ts']
        if age>sec+600:continue
        picked.append((x.get('v') or {},w));total+=w;timeline[f'T-{sec//60}m']={'ts':x['ts'],'rate':x.get('r'),'score':x.get('s'),'vector':x.get('v') or {}}
    if not picked:return None,timeline
    return {k:round(sum(v.get(k,0)*w for v,w in picked)/total,6) for k in RALLY_FEATURES},timeline

def _forward_stats(rows,idx,seconds=1800):
    base=num(rows[idx].get('p')); end_ts=rows[idx]['ts']+seconds; fw=[x for x in rows[idx:] if x['ts']<=end_ts and num(x.get('p'))>0]
    if not base or not fw:return {'mfe':0.0,'mae':0.0,'end':0.0}
    rets=[(num(x.get('p'))/base-1)*100 for x in fw]
    return {'mfe':round(max(rets),2),'mae':round(min(rets),2),'end':round(rets[-1],2)}

def rebuild_rally_model(review_day:str):
    samples=[];seen=set()
    if RALLY_SAMPLE_FILE.exists():
        for line in RALLY_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line); sid=str(x.get('id') or '')
                if sid and sid not in seen:seen.add(sid);samples.append(x)
            except Exception:pass
    samples=samples[-5000:]
    pos=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==1]; neg=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==0]
    types={}; type_centroids={}
    for x in samples:
        if int(x.get('label') or 0)!=1:continue
        typ=str(x.get('dna_type') or 'UNCLASSIFIED');types[typ]=types.get(typ,0)+1
    for typ,count in types.items():
        vs=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==1 and str(x.get('dna_type') or 'UNCLASSIFIED')==typ]
        type_centroids[typ]={'count':len(vs),'centroid':_mean_vectors(vs)}
    eff=(datetime.strptime(review_day,'%Y%m%d')+timedelta(days=1)).strftime('%Y%m%d')
    model={'version':'RALLY_DNA_V1','samples':len(samples),'positive':len(pos),'negative':len(neg),'positive_centroid':_mean_vectors(pos),'negative_centroid':_mean_vectors(neg),'types':types,'type_centroids':type_centroids,'last_review_day':review_day,'last_review_at':now_kst(),'effective_from_day':eff,'min_samples':RALLY_MIN_SAMPLES,'leakage_guard':'EOD_REVIEW_NEXT_DAY_ONLY'}
    tmp=RALLY_MODEL_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(RALLY_MODEL_FILE);STATE.rally_model=model;rally_model_status();return model

def review_rally_day(day:str):
    path=rally_trace_file(day)
    if not path.exists():return {'day':day,'samples_added':0,'reason':'trace_missing'}
    groups=defaultdict(list)
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        try:
            x=json.loads(line); code=code6(x.get('c')); ts=float(x.get('ts') or 0)
            if code and ts:groups[code].append(x)
        except Exception:pass
    # Existing IDs prevent duplicate review after restart.
    existing=set()
    if RALLY_SAMPLE_FILE.exists():
        for line in RALLY_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:existing.add(str(json.loads(line).get('id') or ''))
            except Exception:pass
    added=[]
    for code,rows in groups.items():
        rows.sort(key=lambda x:x['ts'])
        if len(rows)<6:continue
        peak_rate=max(num(x.get('r')) for x in rows)
        # Positive: learn the state BEFORE the first +5% area only if the next 30m truly expands.
        if peak_rate>=RALLY_TARGET_RATE:
            idx=None
            for i,x in enumerate(rows):
                if num(x.get('r'))>=RALLY_TRIGGER_RATE:
                    f=_forward_stats(rows,i,1800)
                    if f['mfe']>=3.0:idx=i;break
            if idx is not None:
                vec,timeline=_weighted_pre_vector(rows,rows[idx]['ts'])
                if vec:
                    stats=_forward_stats(rows,idx,1800); grade='A' if stats['mfe']>=7 or peak_rate>=20 else 'B' if stats['mfe']>=4 else 'C'
                    typ=rally_dna_type(vec)
                    sid=f'{day}:{code}:RALLY:{int(rows[idx]["ts"])}'
                    if sid not in existing:
                        added.append({'id':sid,'day':day,'code':code,'name':rows[idx].get('n'),'label':1,'kind':'RALLY','grade':grade,'dna_type':typ,'event_ts':rows[idx]['ts'],'event_rate':rows[idx].get('r'),'peak_rate':peak_rate,'mfe_30m':stats['mfe'],'mae_30m':stats['mae'],'end_30m':stats['end'],'vector':vec,'timeline':timeline})
                        existing.add(sid)
        # Negative teacher: strong-looking pressure that fails to expand and suffers adverse movement.
        cand=[(i,x) for i,x in enumerate(rows) if num(x.get('s'))>=65 and 0<=num(x.get('r'))<=8]
        if cand:
            i,x=max(cand,key=lambda z:num(z[1].get('s')));stats=_forward_stats(rows,i,1800)
            if stats['mfe']<1.8 and (stats['mae']<=-1.2 or stats['end']<=-0.5):
                vec=x.get('v') or {};sid=f'{day}:{code}:TRAP:{int(x["ts"])}'
                if sid not in existing and vec:
                    added.append({'id':sid,'day':day,'code':code,'name':x.get('n'),'label':0,'kind':'TRAP','grade':'TRAP','dna_type':rally_dna_type(vec),'event_ts':x['ts'],'event_rate':x.get('r'),'peak_rate':peak_rate,'mfe_30m':stats['mfe'],'mae_30m':stats['mae'],'end_30m':stats['end'],'vector':vec})
                    existing.add(sid)
    if added:
        with RALLY_SAMPLE_FILE.open('a',encoding='utf-8') as f:
            for x in added:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    reviewed=set(STATE.rally_review.get('reviewed_days') or []);reviewed.add(day)
    STATE.rally_review={'reviewed_days':sorted(reviewed)[-120:],'last_review_day':day,'last_review_at':now_kst(),'last_added':len(added)}
    tmp=RALLY_REVIEW_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(STATE.rally_review,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(RALLY_REVIEW_FILE)
    model=rebuild_rally_model(day)
    return {'day':day,'samples_added':len(added),'model_samples':model.get('samples'),'positive':model.get('positive'),'negative':model.get('negative'),'effective_from_day':model.get('effective_from_day')}

def prune_rally_traces():
    cutoff=(datetime.now(KST)-timedelta(days=RALLY_TRACE_KEEP_DAYS)).strftime('%Y%m%d')
    for p in DATA_DIR.glob('rally_trace_*.jsonl'):
        m=re.search(r'(\d{8})',p.name)
        if m and m.group(1)<cutoff:
            try:p.unlink()
            except Exception:pass

async def rally_trace_loop():
    while True:
        try:
            if market_session().get('active') and time.time()-STATE.last_rally_trace>=RALLY_TRACE_INTERVAL:
                append_rally_trace();STATE.last_rally_trace=time.time()
        except Exception as e:STATE.rally_status['trace_error']=str(e)[:120]
        await asyncio.sleep(5)

async def rally_review_loop():
    await asyncio.sleep(8)
    while True:
        try:
            reviewed=set(STATE.rally_review.get('reviewed_days') or []); today=today_kst(); sec=kst_seconds()
            # Recover missed reviews first, then review today's trace after all NXT trading has ended.
            days=[]
            for p in sorted(DATA_DIR.glob('rally_trace_*.jsonl')):
                m=re.search(r'(\d{8})',p.name)
                if m and m.group(1)<today and m.group(1) not in reviewed:days.append(m.group(1))
            if sec>=20*3600+5*60 and rally_trace_file(today).exists() and today not in reviewed:days.append(today)
            for d in days[-3:]:STATE.rally_status['last_review_result']=review_rally_day(d)
            prune_rally_traces();rally_model_status()
        except Exception as e:STATE.rally_status['review_error']=str(e)[:160]
        await asyncio.sleep(60)

def load_sector_overrides():
    try:
        if SECTOR_MAP_FILE.exists():
            d=json.loads(SECTOR_MAP_FILE.read_text(encoding='utf-8'))
            return {code6(k):str(v).strip() for k,v in d.items() if code6(k) and str(v).strip()}
    except Exception:
        pass
    return {}

SECTOR_OVERRIDES=load_sector_overrides()

def classify_sector(c:Candidate):
    if c.code in SECTOR_OVERRIDES:return SECTOR_OVERRIDES[c.code],'MAP'
    n=(c.name or '').upper().replace('㈜','').strip()
    if not n:return '미분류','NONE'
    if any(n.startswith(x) for x in ETF_PREFIX) or ' ETF' in n or ' ETN' in n:return 'ETF·지수','ETF'
    for sector,keys in SECTOR_RULES:
        for k in keys:
            if str(k).upper() in n:return sector,'NAME'
    return '미분류','NONE'

def update_sector_context():
    """Build a live sector breadth/leader/follower layer from current candidates.
    Static membership never creates points by itself. A sector needs >=3 contemporaneous candidates;
    the bonus is based on live rate, prior NOVA pressure, volume acceleration and buy pressure.
    """
    now=time.time(); groups=defaultdict(list)
    for c in STATE.candidates.values():
        sector,src=classify_sector(c); c.sector=sector; c.sector_source=src
        if sector in ('미분류','ETF·지수'): continue
        recent=(c.last_tick_at and now-c.last_tick_at<=90) or bool(c.source_hits)
        if recent: groups[sector].append(c)
    status={}
    for sector,members in groups.items():
        if len(members)<3:
            for c in members:c.metrics.update({'sector':sector,'sector_score':0.0,'sector_breadth':len(members),'sector_leader':'','sector_avg_rate':0.0,'sector_diffusion':0})
            continue
        rates=[num(c.rate) for c in members]
        avg=sum(rates)/len(rates)
        positive=sum(1 for c in members if c.rate>=0.7)
        active=sum(1 for c in members if num(c.metrics.get('volume_accel'),1)>=1.25 or num(c.metrics.get('buy_pressure'))>=54 or STAGE_RANK.get(c.stage,0)>=1)
        leader=max(members,key=lambda x:(x.rate,num(x.metrics.get('volume_accel'),1),num(x.metrics.get('buy_pressure')),len(x.source_hits)))
        breadth_ratio=positive/len(members); diffusion=active/len(members)
        base=0.0
        base+=clamp((positive-1)*1.15,0,3.5)
        base+=clamp((active-1)*0.8,0,2.4)
        base+=clamp((avg-0.3)*0.75,0,1.8)
        if num(leader.metrics.get('volume_accel'),1)>=1.25 and num(leader.metrics.get('buy_pressure'))>=55 and 0.8<=leader.rate<=10:base+=1.3
        if breadth_ratio>=0.60 and diffusion>=0.45:base+=1.0
        overheat=avg>6 or sum(1 for x in members if x.rate>10)>=max(2,len(members)//2)
        if avg>4.5:base-=1.5
        if overheat:base-=3.0
        base=clamp(base,-3,SECTOR_MAX_BONUS)
        for c in members:
            bonus=base
            follower=(c.code!=leader.code and 0<=c.rate<leader.rate and c.rate<8 and (num(c.metrics.get('volume_accel'),1)>=1.2 or num(c.metrics.get('buy_pressure'))>=53))
            if follower and 1.2<=leader.rate<=10:bonus+=1.2
            if c.code==leader.code and positive>=3:bonus+=0.5
            bonus=round(clamp(bonus,-3,SECTOR_MAX_BONUS),1)
            c.metrics.update({'sector':sector,'sector_score':bonus,'sector_breadth':positive,'sector_members':len(members),'sector_leader':leader.name or leader.code,'sector_leader_code':leader.code,'sector_avg_rate':round(avg,2),'sector_diffusion':active,'sector_follower':bool(follower),'sector_overheat':bool(overheat)})
        status[sector]={'score':round(base,1),'members':len(members),'breadth':positive,'diffusion':active,'avg_rate':round(avg,2),'leader':leader.name or leader.code,'leader_code':leader.code,'overheat':overheat}
    STATE.sector_status=dict(sorted(status.items(),key=lambda kv:(kv[1]['score'],kv[1]['breadth'],kv[1]['avg_rate']),reverse=True))

def persist_learning():
    tmp=LEARN_FILE.with_suffix('.tmp'); tmp.write_text(json.dumps(STATE.learn,ensure_ascii=False,separators=(',',':')),encoding='utf-8'); tmp.replace(LEARN_FILE)

def train_from_mature_captures():
    # Conservative online attribution: one label per capture after 30 minutes.
    now=time.time(); changed=False
    for c in STATE.candidates.values():
        for cap_key,cap in c.captures.items():
            if cap.stage!='BUY' or now-cap.at<1800: continue
            key=f'{c.code}:{cap_key}:{int(cap.at)}'
            if key in STATE.trained_ids: continue
            fv=cap.features or {}
            if not fv: fv=(c.metrics.get('capture_features') or {}).get(cap_key) or {}
            if not fv: continue
            y=1 if cap.current_return>=0.5 and cap.max_return>=2.0 and cap.min_return>-1.5 else 0
            STATE.trained_ids.add(key); STATE.learn['samples']=int(STATE.learn.get('samples') or 0)+1; STATE.learn['positive']=int(STATE.learn.get('positive') or 0)+y
            w=STATE.learn.setdefault('weights',dict(BASE_FEATURE_WEIGHTS)); lr=0.035/max(1,(STATE.learn['samples']/80)**0.5)
            for k in FEATURE_KEYS:
                x=float(fv.get(k) or 0); direction=(1 if y else -1)
                w[k]=round(clamp(float(w.get(k,1.0))+direction*lr*x,1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST),4)
            STATE.learn['last_update']=now_kst(); changed=True
            with TRAIN_FILE.open('a',encoding='utf-8') as f: f.write(json.dumps({'id':key,'label':y,'max_return':cap.max_return,'min_return':cap.min_return,'features':fv,'at':now_kst()},ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.learn['active']=int(STATE.learn.get('samples') or 0)>=LEARN_MIN_SAMPLES
    if changed: persist_learning()

RANK_SPECS=[
 ('orderbook_buy','ka10020',{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]
WEIGHTS={'orderbook_buy':10,'bid_surge':17,'residual_ratio_surge':14,'volume_surge':20,'change_leaders':9,'volume_top':10,'turnover_top':15}

async def kiwoom_post(path, api_id, body):
    token=await TOK.get()
    h={'authorization':f'Bearer {token}','api-id':api_id,'content-type':'application/json;charset=UTF-8'}
    async with httpx.AsyncClient(timeout=8) as c:
        r=await c.post(API+path,headers=h,json=body)
        data=r.json() if r.content else {}
        return r.status_code,data

def extract_rows(obj):
    if isinstance(obj,list):
        if obj and isinstance(obj[0],dict): return obj
        out=[]
        for x in obj: out+=extract_rows(x)
        return out
    if isinstance(obj,dict):
        best=[]
        for _,v in obj.items():
            if isinstance(v,list) and v and isinstance(v[0],dict) and len(v)>len(best): best=v
        return best
    return []

def row_identity(row):
    c=''; n=''
    for k in ['stk_cd','stk_code','code','item','종목코드']:
        if row.get(k): c=code6(row.get(k))
        if c:break
    for k in ['stk_nm','stk_name','name','종목명']:
        if row.get(k): n=str(row.get(k)); break
    return c,n

def capture_json(cap:Capture):
    d=asdict(cap); d['at_kst']=fmt_kst(cap.at); return d

def append_event(c:Candidate, cap:Capture):
    rec={'event':'STAGE_CAPTURE','version':APP_VERSION,'code':c.code,'name':c.name,'stage':cap.stage,'at':cap.at,'at_kst':fmt_kst(cap.at),'price':cap.price,'score':cap.score,'venue':cap.venue,'reasons':c.reasons,'metrics':c.metrics}
    with EVENT_FILE.open('a',encoding='utf-8') as f: f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.event_count+=1

def update_capture_performance(c:Candidate):
    if c.last_price<=0:return
    for cap in c.captures.values():
        if cap.price<=0:continue
        cap.current_price=c.last_price; cap.current_return=round((c.last_price/cap.price-1)*100,2)
        if cap.max_price<=0 or c.last_price>cap.max_price:cap.max_price=c.last_price
        if cap.min_price<=0 or c.last_price<cap.min_price:cap.min_price=c.last_price
        cap.max_return=round((cap.max_price/cap.price-1)*100,2)
        cap.min_return=round((cap.min_price/cap.price-1)*100,2)

def maybe_capture(c:Candidate, new_stage:str):
    if not c.last_price or STAGE_RANK.get(new_stage,0)<1:return
    # Every confirmed BUY needs its own capture.  A dict keyed only by 'BUY' silently trained
    # on the first BUY per stock and ignored later independent entries.
    key=new_stage
    if new_stage=='BUY' and c.last_buy_entry_id:
        key=f'BUY@{c.last_buy_entry_id}'
    if key not in c.captures:
        fv=feature_vector(c); cap=Capture(new_stage,time.time(),c.last_price,c.score,c.venue or c.last_fid9081,max_price=c.last_price,min_price=c.last_price,current_price=c.last_price,features=fv)
        c.captures[key]=cap; c.metrics.setdefault('capture_features',{})[key]=fv; append_event(c,cap)
    if STAGE_RANK[new_stage]>STAGE_RANK.get(c.highest_stage,0): c.highest_stage=new_stage
    update_capture_performance(c)

def persist_buy_signal_state():
    rows={}
    for c in STATE.candidates.values():
        if c.signal_count:
            rows[c.code]={
                'name':c.name,'signal_count':c.signal_count,'signal_count_today':c.signal_count_today,
                'first_signal_at':c.first_signal_at,'last_signal_at':c.last_signal_at,
                'last_signal_price':c.last_signal_price,'last_signal_score':c.last_signal_score,
                'last_signal_stage':c.last_signal_stage,'last_signal_reasons':c.last_signal_reasons,
                'signal_max_price':c.signal_max_price,'signal_min_price':c.signal_min_price,
                'entry_state':c.entry_state,'entry_state_since':c.entry_state_since,
                'pressure_started_at':c.pressure_started_at,'pressure_peak':c.pressure_peak,
                'pullback_low':c.pullback_low,'reaccel_started_at':c.reaccel_started_at,
                'reaccel_start_price':c.reaccel_start_price,'cooldown_until':c.cooldown_until,
                'last_buy_at':c.last_buy_at,'last_buy_entry_id':c.last_buy_entry_id,'last_buy_route':c.last_buy_route,
                'direct_started_at':c.direct_started_at,'direct_start_price':c.direct_start_price,'reentry_unlocked':c.reentry_unlocked,
                'reject_reason':c.reject_reason
            }
    tmp=BUY_SIGNAL_STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'version':APP_VERSION,'day':today_kst(),'updated_at':now_kst(),'rows':rows},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(BUY_SIGNAL_STATE)

def record_buy_signal(c:Candidate, stage:str='BUY', route:str='PULLBACK_REACCEL'):
    """Record only a confirmed BUY from one of the two independent entry routes.
    Raw PRESSURE/IGNITION remains discovery evidence and never increments buy counts.
    A dynamic-regime re-entry may unlock the base cooldown only after a new high + renewed flow.
    """
    if stage!='BUY' or c.last_price<=0:return False
    now=time.time(); today=today_kst()
    if c.signal_count_today>=ENTRY_MAX_DAILY:return False
    if c.last_buy_at and now-c.last_buy_at<ENTRY_COOLDOWN_SEC and not c.reentry_unlocked:return False
    c.signal_count+=1; c.signal_count_today+=1
    if not c.first_signal_at:c.first_signal_at=now
    c.last_signal_at=now;c.last_signal_price=c.last_price;c.last_signal_score=c.score;c.last_signal_stage='BUY'
    c.last_signal_reasons=list(c.reasons)[:5];c.signal_max_price=c.last_price;c.signal_min_price=c.last_price
    c.last_buy_at=now;c.last_buy_entry_id=f'{c.code}:{int(now)}';c.last_buy_route=route;c.cooldown_until=now+ENTRY_COOLDOWN_SEC;c.reentry_unlocked=False
    c.entry_state='BUY';c.entry_state_since=now;c.reject_reason=''
    maybe_capture(c,'BUY')
    path='DISCOVERY>PRESSURE_BUILD>PULLBACK>REACCEL>BUY' if route=='PULLBACK_REACCEL' else 'DISCOVERY>PRESSURE_BUILD>DIRECT_ARM>BUY'
    rec={'event':'BUY_CONFIRMED','policy':'ENTRY_V4_RALLY_DNA','version':APP_VERSION,'day':today,'id':c.last_buy_entry_id,'code':c.code,'name':c.name,'stage':'BUY','route':route,'at':now,'at_kst':now_kst(),'price':c.last_price,'change_rate':c.rate,'score':c.score,'confidence':c.confidence,'venue':c.venue,'fid9081':c.last_fid9081,'reasons':c.last_signal_reasons,'smart':c.smart,'metrics':c.metrics,'entry_state_path':path,'signal_count':c.signal_count,'signal_count_today':c.signal_count_today}
    with BUY_SIGNAL_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.buy_signal_events+=1; persist_buy_signal_state(); return True

def update_buy_signal_performance(c:Candidate):
    if c.last_price<=0 or c.last_signal_price<=0:return
    if c.signal_max_price<=0 or c.last_price>c.signal_max_price:c.signal_max_price=c.last_price
    if c.signal_min_price<=0 or c.last_price<c.signal_min_price:c.signal_min_price=c.last_price

def persist_performance(force=False):
    now=time.time()
    if not force and now-STATE.last_persist<10:return
    rows={}
    for c in STATE.candidates.values():
        if c.captures:
            rows[c.code]={'name':c.name,'last_price':c.last_price,'stage':c.stage,'captures':{k:capture_json(v) for k,v in c.captures.items()}}
    tmp=STATE_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'version':APP_VERSION,'updated_at':now_kst(),'rows':rows},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(STATE_FILE); STATE.last_persist=now
    persist_buy_signal_state()


def first_row(j, keys=()):
    for k in keys:
        v=j.get(k) if isinstance(j,dict) else None
        if isinstance(v,list) and v and isinstance(v[0],dict): return v[0]
    rows=extract_rows(j); return rows[0] if rows else {}

def first_num(row, keys):
    for k in keys:
        if k in row and str(row.get(k) or '').strip()!='': return num(row.get(k))
    return 0.0

async def poll_investor(c:Candidate):
    body={'dt':today_kst(),'stk_cd':c.code,'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1'}
    status,j=await kiwoom_post('/api/dostk/stkinfo','ka10059',body)
    ok=status==200 and int(j.get('return_code',0))==0; STATE.smart_status['ka10059']={'ok':ok,'msg':j.get('return_msg','')}
    if not ok:return
    r=first_row(j,('stk_invsr_orgn','stk_invsr_orgn_chart'))
    inst=first_num(r,['orgn']); trust=first_num(r,['invtrt']); pension=first_num(r,['penfnd_etc']); foreign=first_num(r,['frgnr_invsr'])
    prev_inst=num(c.smart.get('institution_net')); prev_trust=num(c.smart.get('trust_net')); prev_pension=num(c.smart.get('pension_net')); prev_foreign=num(c.smart.get('foreign_net'))
    c.smart.update({
        'institution_prev':prev_inst,'trust_prev':prev_trust,'pension_prev':prev_pension,'foreign_prev':prev_foreign,
        'institution_net':inst,'trust_net':trust,'pension_net':pension,'foreign_net':foreign,
        'institution_delta':inst-prev_inst,'trust_delta':trust-prev_trust,'pension_delta':pension-prev_pension,'foreign_delta':foreign-prev_foreign,
        'financial_net':first_num(r,['fnnc_invt']),'insurance_net':first_num(r,['insrnc'])
    })
    c.smart_updated_at=time.time()

async def poll_program(c:Candidate):
    # Official ka90004 stock-level program trading. A server-side schema change only disables this component; other smart-money evidence remains live.
    status,j=await kiwoom_post('/api/dostk/stkinfo','ka90004',{'stk_cd':c.code})
    ok=status==200 and int(j.get('return_code',0))==0; STATE.smart_status['ka90004']={'ok':ok,'msg':j.get('return_msg','')}
    if not ok:return
    r=first_row(j,('stk_prm_trde_prst','stk_prm_trde','prm_trde_prst'))
    buy=first_num(r,['buy_qty','buy_trde_qty','prm_buy_qty','buy_amt','prm_buy_amt'])
    sell=first_num(r,['sell_qty','sel_trde_qty','prm_sell_qty','sell_amt','prm_sell_amt'])
    net=first_num(r,['netprps_qty','netprps','prm_netprps_qty','netprps_amt','prm_netprps_amt'])
    if not net and (buy or sell): net=buy-sell
    prev=num(c.smart.get('program_net')); c.smart.update({'program_buy':buy,'program_sell':sell,'program_prev':prev,'program_net':net,'program_delta':net-prev})
    c.smart_updated_at=time.time()

async def smart_money_loop():
    while True:
        try:
            if not APP_KEY or not SECRET: await asyncio.sleep(5); continue
            top=ranked()[:max(20,WS_LIMIT)]
            if top:
                start=STATE.smart_cursor%len(top); batch=[top[(start+i)%len(top)] for i in range(min(SMART_POLL_BATCH,len(top)))]; STATE.smart_cursor=(start+len(batch))%len(top)
                for c in batch:
                    try: await poll_investor(c)
                    except Exception as e: STATE.smart_status['ka10059']={'ok':False,'msg':str(e)[:100]}
                    await asyncio.sleep(.18)
                    try: await poll_program(c)
                    except Exception as e: STATE.smart_status['ka90004']={'ok':False,'msg':str(e)[:100]}
                    await asyncio.sleep(.18)
                score_all()
            train_from_mature_captures(); persist_performance()
        except Exception: pass
        await asyncio.sleep(SMART_POLL_SECONDS)

async def discovery_loop():
    while True:
        started=time.time(); accum=defaultdict(dict)
        if APP_KEY and SECRET:
            for market in ('001','101'):
                for source,api_id,tpl in RANK_SPECS:
                    body={k:(market if v=='{market}' else v) for k,v in tpl.items()}
                    try:
                        status,j=await kiwoom_post('/api/dostk/rkinfo',api_id,body)
                        rows=extract_rows(j); STATE.rest_status[f'{source}:{market}']={'ok':status==200 and int(j.get('return_code',0))==0,'rows':len(rows),'msg':j.get('return_msg','')}
                        for idx,row in enumerate(rows[:80]):
                            c,n=row_identity(row)
                            if not c:continue
                            accum[c][source]=max(accum[c].get(source,0),WEIGHTS[source]*(1-0.55*idx/max(1,min(len(rows),80))))
                            STATE.get(c,n)
                    except Exception as e: STATE.rest_status[f'{source}:{market}']={'ok':False,'rows':0,'msg':str(e)[:120]}
            async with STATE.lock:
                now=time.time()
                for c,hits in accum.items():
                    cand=STATE.get(c); cand.source_hits=hits; cand.metrics['discovery_overlap']=len(hits); cand.metrics['rest_base']=sum(hits.values())
                for c in list(STATE.candidates):
                    x=STATE.candidates[c]
                    if not x.ticks and now-x.first_seen>1800 and c not in accum:STATE.candidates.pop(c,None)
                score_all(); STATE.generated_at=now; STATE.scan_cycles+=1; STATE.ws_codes=[x.code for x in ranked()[:WS_LIMIT]]
        persist_performance()
        await asyncio.sleep(max(2,DISCOVERY_SECONDS-(time.time()-started)))

def set_entry_state(c:Candidate, state:str, reason:str=''):
    now=time.time(); c.entry_state=state; c.entry_state_since=now; c.reject_reason=reason
    if state=='DISCOVERY':
        c.pressure_started_at=0;c.pressure_peak=0;c.pullback_low=0;c.reaccel_started_at=0;c.reaccel_start_price=0;c.direct_started_at=0;c.direct_start_price=0
    elif state=='PRESSURE_BUILD':
        c.pressure_started_at=now;c.pressure_peak=c.last_price;c.pullback_low=0;c.reaccel_started_at=0;c.reaccel_start_price=0;c.direct_started_at=0;c.direct_start_price=0
    elif state=='PULLBACK':
        c.pullback_low=c.last_price
    elif state=='REACCEL':
        c.reaccel_started_at=now;c.reaccel_start_price=c.last_price
    elif state=='DIRECT_ARM':
        c.direct_started_at=now;c.direct_start_price=c.last_price


def entry_hard_reject(c:Candidate):
    m=c.metrics
    reasons=[]
    if num(c.rate)>12: reasons.append('당일 상승률 과열')
    if num(m.get('impulse_60s'))>ENTRY_MAX_IMPULSE: reasons.append('1분 급등 과열')
    if num(m.get('vwap_gap'))>ENTRY_MAX_VWAP_GAP: reasons.append('VWAP 추격구간')
    if num(m.get('one_tick_ratio'))>0.45: reasons.append('단일체결 편중')
    if bool(m.get('sector_overheat')): reasons.append('섹터 과열')
    return reasons


def smart_direction_ok(c:Candidate):
    sm=c.smart or {}
    age=(time.time()-c.smart_updated_at) if c.smart_updated_at else 10**9
    if age>45: return True, '수급 갱신대기'
    pd=num(sm.get('program_delta')); td=num(sm.get('trust_delta')); pnd=num(sm.get('pension_delta')); ind=num(sm.get('institution_delta'))
    positives=sum(1 for x in (pd,td,pnd,ind) if x>0)
    negatives=sum(1 for x in (pd,td,pnd,ind) if x<0)
    if negatives>=3 and positives==0:return False,'프로그램·기관 수급 동반 둔화'
    return True,'스마트머니 방향 확인'


def direct_support_ok(c:Candidate):
    """Direct ignition needs either fresh smart-money confirmation or unusually broad live confirmation.
    This is deliberately stricter than the pullback route because no pullback protection exists.
    """
    sm=c.smart or {}; age=(time.time()-c.smart_updated_at) if c.smart_updated_at else 10**9
    deltas=(num(sm.get('program_delta')),num(sm.get('trust_delta')),num(sm.get('pension_delta')),num(sm.get('institution_delta')))
    positives=sum(1 for x in deltas if x>0); negatives=sum(1 for x in deltas if x<0)
    if age<=45:
        if negatives>=3:return False,'스마트머니 다중 둔화'
        if positives>=2 or (deltas[0]>0 and positives>=1):return True,'스마트머니 재가속 동조'
    m=c.metrics
    fallback=(bool(m.get('dual_venue')) and num(m.get('sector_score'))>=3 and num(m.get('sector_breadth'))>=3 and num(m.get('buy_pressure'))>=64)
    return (fallback, 'KRX·NXT+섹터 확산 대체확인' if fallback else 'DIRECT 수급근거 부족')


def dynamic_reentry_ok(c:Candidate, now:float):
    if not c.last_buy_at or not c.last_signal_price:return False,''
    elapsed=now-c.last_buy_at
    if elapsed<ENTRY_REENTRY_MIN_SEC:return False,''
    m=c.metrics; gain=(c.last_price/c.last_signal_price-1)*100 if c.last_signal_price else 0
    smart_ok,_=smart_direction_ok(c)
    ok=(gain>=ENTRY_REENTRY_GAIN_PCT and c.score>=72 and num(m.get('volume_accel'),1)>=1.5 and num(m.get('buy_pressure'))>=60 and num(m.get('algo_persistence'))>=60 and num(m.get('micro_breakout'))>=0.20 and smart_ok and not entry_hard_reject(c))
    return ok,(f'새 고점 +{gain:.1f}% · 거래량/수급 재가속' if ok else '')


def advance_entry_machine(c:Candidate, sess:dict, age_ms:float):
    """Balanced dual-path entry machine.

    Route A (high trust): DISCOVERY -> PRESSURE_BUILD -> PULLBACK -> REACCEL -> BUY.
    Route B (opportunity rescue): DISCOVERY -> PRESSURE_BUILD -> DIRECT_ARM -> BUY,
    only when momentum, order-flow, VWAP and smart/sector confirmation are all unusually strong.
    No market-wide signal quota is enforced.
    """
    now=time.time(); m=c.metrics; price=c.last_price
    if not price:return
    if not sess.get('active') or age_ms>FRESH_MS:
        if c.entry_state not in ('BUY','COOLDOWN'): set_entry_state(c,'DISCOVERY','세션/실체결 비활성')
        c.metrics.update({'entry_state':c.entry_state,'entry_reason':c.reject_reason,'entry_ready':False,'entry_route':''})
        return

    score=num(c.score); bp=num(m.get('buy_pressure')); accel=num(m.get('volume_accel'),1); algo=num(m.get('algo_persistence')); vgap=num(m.get('vwap_gap')); impulse=num(m.get('impulse_60s')); breakout=num(m.get('micro_breakout'))
    hard=entry_hard_reject(c); smart_ok,smart_note=smart_direction_ok(c); direct_ok,direct_note=direct_support_ok(c)

    # Cooldown is normally 10 minutes, but a truly new price/flow regime can unlock after 7 minutes.
    if c.cooldown_until>now:
        unlock,unlock_note=dynamic_reentry_ok(c,now)
        if unlock:
            c.reentry_unlocked=True;c.cooldown_until=0;set_entry_state(c,'DISCOVERY',unlock_note)
        else:
            if c.entry_state=='BUY' and now-c.entry_state_since<30: pass
            else:c.entry_state='COOLDOWN'
            c.metrics.update({'entry_state':c.entry_state,'entry_reason':'재신호 보호구간','entry_ready':False,'cooldown_sec':round(c.cooldown_until-now),'entry_route':c.last_buy_route})
            return
    if c.entry_state in ('BUY','COOLDOWN') and c.cooldown_until<=now:set_entry_state(c,'DISCOVERY')
    if c.signal_count_today>=ENTRY_MAX_DAILY:
        c.entry_state='COOLDOWN';c.metrics.update({'entry_state':'COOLDOWN','entry_reason':'일일 BUY 상한 도달','entry_ready':False,'entry_route':c.last_buy_route});return
    if c.entry_state=='REJECTED':
        if now-c.entry_state_since<20:
            c.metrics.update({'entry_state':'REJECTED','entry_reason':c.reject_reason,'entry_ready':False,'entry_route':''});return
        set_entry_state(c,'DISCOVERY')

    pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak>0 else 0
    recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low>0 else 0

    if c.entry_state=='DISCOVERY':
        if score>=ENTRY_PRESSURE_SCORE and bp>=53 and algo>=50 and not hard:
            set_entry_state(c,'PRESSURE_BUILD','압력 지속성 확인 중')

    elif c.entry_state=='PRESSURE_BUILD':
        c.pressure_peak=max(c.pressure_peak or price,price)
        pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak else 0
        held=now-c.pressure_started_at if c.pressure_started_at else 0
        # Direct route is checked before the pullback timeout. It requires a clean, not-yet-overextended breakout.
        direct_arm=(held>=DIRECT_HOLD_SEC and score>=DIRECT_SCORE and bp>=DIRECT_MIN_BUY_PRESSURE and accel>=DIRECT_MIN_ACCEL and algo>=DIRECT_MIN_ALGO_PERSIST and breakout>=DIRECT_MIN_BREAKOUT and DIRECT_MIN_IMPULSE<=impulse<=DIRECT_MAX_IMPULSE and 0.05<=vgap<=DIRECT_MAX_VWAP_GAP and pullback_pct<ENTRY_PULLBACK_MIN and num(c.rate)<=9.5 and direct_ok and not hard)
        if hard:
            set_entry_state(c,'REJECTED',' · '.join(hard[:2]))
        elif direct_arm:
            set_entry_state(c,'DIRECT_ARM',direct_note)
        elif score<52 or bp<48:
            set_entry_state(c,'DISCOVERY','압력 소멸')
        elif held>=ENTRY_HOLD_SEC and ENTRY_PULLBACK_MIN<=pullback_pct<=ENTRY_PULLBACK_MAX and score>=54:
            set_entry_state(c,'PULLBACK','건강한 눌림 확인')
        elif held>120:
            set_entry_state(c,'REJECTED','눌림·직접점화 모두 미확인')

    elif c.entry_state=='PULLBACK':
        c.pullback_low=min(c.pullback_low or price,price)
        pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak else 0
        recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low else 0
        if hard or pullback_pct>ENTRY_PULLBACK_MAX or score<46:
            set_entry_state(c,'REJECTED','눌림 실패/과열' if not hard else ' · '.join(hard[:2]))
        elif recovery_pct>=0.15 and bp>=ENTRY_MIN_BUY_PRESSURE and accel>=1.15 and algo>=ENTRY_MIN_ALGO_PERSIST and -0.20<=vgap<=1.35 and impulse<=2.20 and smart_ok:
            set_entry_state(c,'REACCEL','눌림 후 재가속 확인 중')

    elif c.entry_state=='REACCEL':
        recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low else 0
        if hard or score<54 or (c.pullback_low and price<c.pullback_low*0.998):
            set_entry_state(c,'PULLBACK','재가속 실패')
        else:
            confirm=(now-c.reaccel_started_at>=ENTRY_REACCEL_SEC and price>=c.reaccel_start_price*1.0004 and bp>=ENTRY_MIN_BUY_PRESSURE and accel>=1.10 and algo>=ENTRY_MIN_ALGO_PERSIST and -0.10<=vgap<=1.35 and impulse<=2.20 and smart_ok)
            if confirm:
                c.reasons=(['PULLBACK BUY · 눌림 후 재가속',f'공격매수 {bp:.0f}% · 알고리즘 {algo:.0f}%',smart_note]+list(c.reasons))[:5]
                record_buy_signal(c,'BUY','PULLBACK_REACCEL')

    elif c.entry_state=='DIRECT_ARM':
        elapsed=now-c.direct_started_at if c.direct_started_at else 0
        maintain=(score>=72 and bp>=59 and accel>=1.45 and algo>=58 and breakout>=0.15 and DIRECT_MIN_IMPULSE*0.6<=impulse<=DIRECT_MAX_IMPULSE and -0.02<=vgap<=1.15 and direct_ok and not hard and num(c.rate)<=10)
        if not maintain or (c.direct_start_price and price<c.direct_start_price*0.997):
            set_entry_state(c,'PRESSURE_BUILD','DIRECT 점화 확인 실패')
        elif elapsed>=DIRECT_CONFIRM_SEC and price>=c.direct_start_price*1.0008:
            c.reasons=(['DIRECT IGNITION BUY · 눌림 없는 초강세',f'가속 {accel:.1f}x · 공격매수 {bp:.0f}% · 알고리즘 {algo:.0f}%',direct_note]+list(c.reasons))[:5]
            record_buy_signal(c,'BUY','DIRECT_IGNITION')

    c.metrics.update({
        'entry_state':c.entry_state,'entry_reason':c.reject_reason or c.metrics.get('entry_reason') or '',
        'entry_ready':c.entry_state in ('REACCEL','DIRECT_ARM','BUY'),'entry_route':('DIRECT_IGNITION' if c.entry_state=='DIRECT_ARM' else 'PULLBACK_REACCEL' if c.entry_state in ('PULLBACK','REACCEL') else c.last_buy_route if c.entry_state in ('BUY','COOLDOWN') else ''),
        'pressure_hold_sec':round(now-c.pressure_started_at,1) if c.pressure_started_at else 0,
        'pressure_peak':c.pressure_peak,'pullback_pct':round(pullback_pct,3),'pullback_low':c.pullback_low,
        'recovery_pct':round(recovery_pct,3),'reaccel_sec':round(now-c.reaccel_started_at,1) if c.reaccel_started_at else 0,
        'direct_sec':round(now-c.direct_started_at,1) if c.direct_started_at else 0,'direct_start_price':c.direct_start_price,
        'cooldown_sec':max(0,round(c.cooldown_until-now)) if c.cooldown_until else 0,
        'smart_direction_ok':smart_ok,'smart_direction_note':smart_note,'direct_support_ok':direct_ok,'direct_support_note':direct_note,
        'entry_policy':'PULLBACK_REACCEL | DIRECT_IGNITION','normal_market_signal_target':'8-25/day market-wide (diagnostic only, never quota)'
    })

def calc(c:Candidate):
    ticks=list(c.ticks); now=time.time(); reasons=[]; sess=market_session()
    rest=min(30,num(c.metrics.get('rest_base'))*0.55)
    if len(c.source_hits)>=3: reasons.append(f'독립순위 {len(c.source_hits)}중첩')
    age_ms=(now-c.last_tick_at)*1000 if c.last_tick_at else 10**12
    if len(ticks)<4 or age_ms>DISPLAY_FRESH_MS:
        c.score=round(rest,1); c.confidence=min(35,len(c.source_hits)*8); c.stage='SEED'
        if not sess['active']: reasons.append('시장 종료 · 실시간 신호 비활성')
        elif c.last_tick_at: reasons.append(f'실체결 stale {age_ms/1000:.1f}s')
        else: reasons.append('실시간 체결 축적 중')
        c.reasons=reasons[:4]; c.metrics.update({'fresh':False,'one_tick_ratio':0.0}); update_capture_performance(c); update_buy_signal_performance(c); advance_entry_machine(c,sess,age_ms); c.previous_stage=c.stage; return
    recent=[t for t in ticks if now-t.ts<=60]; prev=[t for t in ticks if 60<now-t.ts<=180]; r5=[t for t in ticks if now-t.ts<=300]
    if not recent: recent=ticks[-10:]
    p0=recent[0].price; p1=recent[-1].price; impulse=(p1/p0-1)*100 if p0 else 0
    vol60=sum(abs(t.qty) for t in recent); volprev=sum(abs(t.qty) for t in prev)/2 if prev else max(vol60*.65,1); accel=vol60/max(volprev,1)
    signed=sum(t.qty for t in recent); buy_ratio=(signed/vol60*50+50) if vol60 else 50
    pos_ticks=sum(1 for t in recent if t.qty>0); neg_ticks=sum(1 for t in recent if t.qty<0); algo_persistence=(pos_ticks/max(pos_ticks+neg_ticks,1))*100
    prices=[t.price for t in r5 if t.price>0]; breakout=0
    if len(prices)>5:
        old=prices[:-max(2,len(prices)//5)]; oldmax=max(old) if old else max(prices); breakout=max(0,(p1/oldmax-1)*100) if oldmax else 0
    pv=sum(t.price*abs(t.qty) for t in r5); vv=sum(abs(t.qty) for t in r5); vwap=pv/vv if vv else p1; above=(p1/vwap-1)*100 if vwap else 0
    range5=((max(prices)-min(prices))/vwap*100) if prices and vwap else 0
    compression=clamp(1-range5/3.0,0,1)
    venues={t.venue for t in ticks if now-t.ts<=120 and t.venue in ('KRX','NXT')}; dual=len(venues)==2
    one_tick=max((abs(t.qty) for t in recent),default=0)/max(vol60,1)
    sm=c.smart or {}; inst=num(sm.get('institution_net')); trust=num(sm.get('trust_net')); pension=num(sm.get('pension_net')); foreign=num(sm.get('foreign_net')); prog=num(sm.get('program_net')); prog_delta=num(sm.get('program_delta'))
    inst_scale=max(abs(inst)+abs(foreign),1000000); smart_score=0
    program_ratio=prog/max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),100000)
    algo_score=clamp((algo_persistence-50)*0.18,0,8)+clamp(prog_delta/max(abs(prog),100000)*5,-4,5)
    trust_delta=num(sm.get('trust_delta')); pension_delta=num(sm.get('pension_delta')); inst_delta=num(sm.get('institution_delta')); foreign_delta=num(sm.get('foreign_delta'))
    smart_score+=clamp(program_ratio*10,-9,10)*learner_weight('program')+algo_score
    smart_score+=clamp(prog_delta/max(abs(prog),100000)*4,-4,4)*learner_weight('program')
    smart_score+=clamp(trust/inst_scale*9,-6,6)*learner_weight('trust')+clamp(trust_delta/inst_scale*6,-4,4)
    smart_score+=clamp(pension/inst_scale*10,-7,7)*learner_weight('pension')+clamp(pension_delta/inst_scale*7,-5,5)
    smart_score+=clamp(inst/inst_scale*8,-6,6)*learner_weight('institution')+clamp(inst_delta/inst_scale*5,-4,4)
    smart_score+=clamp(foreign/inst_scale*4,-3,3)*learner_weight('foreign')+clamp(foreign_delta/inst_scale*2,-2,2)
    sector_score=num(c.metrics.get('sector_score'))
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_breakout':round(breakout,2),'compression':round(compression,3),'range5_pct':round(range5,2),'dual_venue':dual,'algo_persistence':round(algo_persistence,1)})
    score=rest*learner_weight('rest')+clamp((accel-1)*12,0,20)*learner_weight('volume_accel')+clamp((buy_ratio-50)*0.38,0,16)*learner_weight('buy_pressure')+clamp(impulse*3.2,0,15)*learner_weight('impulse')+clamp(above*4.5,0,8)*learner_weight('vwap_gap')+clamp(breakout*6,0,9)*learner_weight('micro_breakout')+(5*learner_weight('dual_venue') if dual else 0)+smart_score+sector_score*learner_weight('sector')
    pre_dna_score=score
    dna=rally_live_match(c)
    score+=num(dna.get('bonus'))
    if c.rate>14:score-=12;reasons.append('과열 추격위험')
    if impulse>4.5:score-=7
    if one_tick>0.5:score-=8;reasons.append('단일체결 편중')
    if accel>=1.7:reasons.append(f'1분 체결가속 {accel:.1f}x')
    if buy_ratio>=60:reasons.append(f'공격매수 우위 {buy_ratio:.0f}%')
    if impulse>=0.7:reasons.append(f'가격 선행 +{impulse:.1f}%')
    if above>=0.2:reasons.append(f'VWAP +{above:.2f}%')
    if breakout>=0.3:reasons.append(f'5분 미세돌파 +{breakout:.2f}%')
    if dual:reasons.append('KRX·NXT 동시확인')
    if algo_score>=4:reasons.append(f'알고리즘 매수 지속 {algo_persistence:.0f}%')
    if sector_score>=3:reasons.append(f"섹터동조 {c.sector} +{sector_score:.1f}")
    if c.metrics.get('sector_follower') and sector_score>0:reasons.append('대표주→후발 확산')
    if c.metrics.get('sector_overheat'):reasons.append('섹터 과열 감점')
    if dna.get('active') and num(dna.get('match'))>=68:reasons.append(f"RALLY DNA {dna.get('type')} {num(dna.get('match')):.0f}%")
    if num(dna.get('bonus'))<0:reasons.append(f"TRAP DNA 감점 {num(dna.get('bonus')):.1f}")
    if prog>0:reasons.append(f'프로그램 순매수 {prog:,.0f}')
    if trust>0:reasons.append(f'투신 순매수 {trust:,.0f}')
    if pension>0:reasons.append(f'연기금 순매수 {pension:,.0f}')
    if inst>0 and (trust>0 or pension>0):reasons.append('기관 수급 동조')
    score=clamp(score); conf=clamp(20+min(35,len(recent)*1.2)+min(25,len(c.source_hits)*6)+(10 if dual else 0))
    stage='IGNITION' if score>=78 else 'PRESSURE' if score>=64 else 'WATCH' if score>=48 else 'SEED'
    # Never call stale/closed data PRESSURE/IGNITION.
    if not sess['active']:stage='SEED';score=min(score,47)
    elif age_ms>FRESH_MS and STAGE_RANK[stage]>STAGE_RANK['WATCH']:stage='WATCH';score=min(score,63);reasons.insert(0,'실체결 freshness 부족')
    prev_stage=c.stage
    c.score=round(score,1); c.confidence=round(conf,0); c.stage=stage; c.reasons=reasons[:5]
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_breakout':round(breakout,2),'dual_venue':dual,'tick_count_60s':len(recent),'fresh':age_ms<=FRESH_MS,'one_tick_ratio':round(one_tick,3),'smart_money_score':round(smart_score,2),'algo_score':round(algo_score,2),'algo_persistence':round(algo_persistence,1),'program_net':prog,'program_delta':prog_delta,'trust_net':trust,'trust_delta':trust_delta,'pension_net':pension,'pension_delta':pension_delta,'institution_net':inst,'institution_delta':inst_delta,'foreign_net':foreign,'foreign_delta':foreign_delta,'smart_age_ms':round((now-c.smart_updated_at)*1000) if c.smart_updated_at else None,'learn_active':bool(STATE.learn.get('active')),'sector':c.sector,'sector_score':round(sector_score,1),'sector_breadth':c.metrics.get('sector_breadth'),'sector_members':c.metrics.get('sector_members'),'sector_leader':c.metrics.get('sector_leader'),'sector_avg_rate':c.metrics.get('sector_avg_rate'),'sector_diffusion':c.metrics.get('sector_diffusion'),'sector_follower':bool(c.metrics.get('sector_follower')),'sector_overheat':bool(c.metrics.get('sector_overheat')),'compression':round(compression,3),'range5_pct':round(range5,2),'pre_dna_score':round(pre_dna_score,1),'rally_dna_active':bool(dna.get('active')),'rally_dna_match':dna.get('match'),'rally_dna_trap':dna.get('trap'),'rally_dna_bonus':dna.get('bonus'),'rally_dna_type':dna.get('type'),'rally_dna_samples':dna.get('samples'),'rally_dna_effective_from':dna.get('effective_from_day')})
    c.previous_stage=prev_stage
    maybe_capture(c,stage)
    advance_entry_machine(c,sess,age_ms)
    update_buy_signal_performance(c)
    c.previous_stage=stage

def score_all():
    update_sector_context()
    for c in STATE.candidates.values():calc(c)

def ranked():
    rows=list(STATE.candidates.values());rows.sort(key=lambda x:(x.score,x.confidence,x.last_tick_at),reverse=True);return rows

async def ws_loop():
    last_reg=();group=300
    while True:
        if not APP_KEY or not SECRET:await asyncio.sleep(5);continue
        try:
            token=await TOK.get()
            async with websockets.connect(WS,ping_interval=None,close_timeout=3,max_size=4_000_000) as ws:
                STATE.ws_status.update({'connected':True,'last_error':''});await ws.send(json.dumps({'trnm':'LOGIN','token':token}));logged=False
                while True:
                    codes=tuple(STATE.ws_codes[:WS_LIMIT])
                    if logged and codes and codes!=last_reg:
                        group+=1;data=[]
                        for c in codes:data.append({'item':[c],'type':['0B']})
                        for c in codes:data.append({'item':[c+'_NX'],'type':['0B']})
                        for i in range(0,len(data),40):await ws.send(json.dumps({'trnm':'REG','grp_no':str(group+i//40),'refresh':'1','data':data[i:i+40]}))
                        last_reg=codes
                    try:raw=await asyncio.wait_for(ws.recv(),timeout=2.0)
                    except asyncio.TimeoutError:continue
                    STATE.ws_status['last_message_at']=time.time();m=json.loads(raw)
                    if m.get('trnm')=='PING':await ws.send(raw);continue
                    if m.get('trnm')=='LOGIN':
                        if int(m.get('return_code',-1))!=0:raise RuntimeError(m.get('return_msg','LOGIN failed'))
                        logged=True;continue
                    if m.get('trnm')=='REG':
                        if int(m.get('return_code',-1))==0:STATE.ws_status['ack']=STATE.ws_status.get('ack',0)+1
                        continue
                    if m.get('trnm')!='REAL':continue
                    for d in m.get('data',[]):
                        if str(d.get('type'))!='0B':continue
                        v=d.get('values') or {};c=code6(d.get('item') or v.get('9001'))
                        if not c:continue
                        p=abs(num(v.get('10')));q=num(v.get('15'));rate=num(v.get('12'));fid9081=str(v.get('9081') or '').upper()
                        venue=fid9081 if fid9081 in ('KRX','NXT') else ('NXT' if str(d.get('item','')).upper().endswith('_NX') else 'KRX')
                        if p<=0:continue
                        now=time.time();cand=STATE.get(c);cand.last_price=p;cand.rate=rate;cand.venue=venue;cand.last_fid9081=fid9081 or venue;cand.last_tick_at=now
                        cand.ticks.append(Tick(now,p,q,rate,venue,abs(num(v.get('13'))),abs(num(v.get('14')))))
                        STATE.ws_status.update({'last_trade_at':now,'last_trade_code':c,'last_trade_venue':venue,'last_fid9081':cand.last_fid9081})
                        update_capture_performance(cand)
                    score_all();STATE.generated_at=time.time();persist_performance()
        except Exception as e:STATE.ws_status.update({'connected':False,'last_error':str(e)[:180]});await asyncio.sleep(2)

def feed_truth():
    now=time.time();sess=market_session();last=STATE.ws_status.get('last_trade_at') or 0;age_ms=round((now-last)*1000) if last else None
    if not APP_KEY or not SECRET:state='KEYS_MISSING'
    elif not sess['active']:state='MARKET_CLOSED'
    elif STATE.ws_status.get('connected') and age_ms is not None and age_ms<=FRESH_MS:state='LIVE'
    elif STATE.ws_status.get('connected'):state='CONNECTED_WAITING_TICK'
    else:state='DISCONNECTED'
    return {'state':state,'session':sess,'last_trade_at_kst':fmt_kst(last) if last else None,'last_trade_age_ms':age_ms,'last_trade_code':STATE.ws_status.get('last_trade_code'),'last_trade_venue':STATE.ws_status.get('last_trade_venue'),'last_fid9081':STATE.ws_status.get('last_fid9081')}

app=FastAPI(title='Quant Nova Ignition Radar',version=APP_VERSION)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')

@app.on_event('startup')
async def start():
    asyncio.create_task(discovery_loop(),name='nova-discovery');asyncio.create_task(ws_loop(),name='nova-websocket');asyncio.create_task(smart_money_loop(),name='nova-smart-money');asyncio.create_task(rally_trace_loop(),name='nova-rally-trace');asyncio.create_task(rally_review_loop(),name='nova-rally-review')

@app.get('/')
async def root():return FileResponse(BASE/'static/index.html')

@app.get('/api/nova')
async def nova():
    score_all();rows=[];now=time.time();truth=feed_truth()
    for i,c in enumerate(ranked()[:40],1):
        cap=None
        buy_caps=[x for x in c.captures.values() if x.stage=='BUY']
        if buy_caps: cap=max(buy_caps,key=lambda x:x.at)
        else:
            for st in ('IGNITION','PRESSURE','WATCH'):
                if st in c.captures:cap=c.captures[st];break
        evidence={
            'overlap':int(c.metrics.get('discovery_overlap') or 0),'volume_accel':c.metrics.get('volume_accel'),'buy_pressure':c.metrics.get('buy_pressure'),'vwap_gap':c.metrics.get('vwap_gap'),'micro_breakout':c.metrics.get('micro_breakout'),'dual_venue':bool(c.metrics.get('dual_venue')),'tick_count_60s':int(c.metrics.get('tick_count_60s') or 0),'fresh':bool(c.metrics.get('fresh')),'smart_money_score':c.metrics.get('smart_money_score'),'algo_score':c.metrics.get('algo_score'),'algo_persistence':c.metrics.get('algo_persistence'),'program_net':c.metrics.get('program_net'),'program_delta':c.metrics.get('program_delta'),'trust_net':c.metrics.get('trust_net'),'trust_delta':c.metrics.get('trust_delta'),'pension_net':c.metrics.get('pension_net'),'pension_delta':c.metrics.get('pension_delta'),'institution_net':c.metrics.get('institution_net'),'institution_delta':c.metrics.get('institution_delta'),'foreign_net':c.metrics.get('foreign_net'),'foreign_delta':c.metrics.get('foreign_delta'),'smart_age_ms':c.metrics.get('smart_age_ms'),'sector':c.sector,'sector_score':c.metrics.get('sector_score'),'sector_breadth':c.metrics.get('sector_breadth'),'sector_members':c.metrics.get('sector_members'),'sector_leader':c.metrics.get('sector_leader'),'sector_avg_rate':c.metrics.get('sector_avg_rate'),'sector_diffusion':c.metrics.get('sector_diffusion'),'sector_follower':bool(c.metrics.get('sector_follower')),'entry_state':c.entry_state,'entry_reason':c.metrics.get('entry_reason'),'entry_ready':bool(c.metrics.get('entry_ready')),'pressure_hold_sec':c.metrics.get('pressure_hold_sec'),'pullback_pct':c.metrics.get('pullback_pct'),'recovery_pct':c.metrics.get('recovery_pct'),'cooldown_sec':c.metrics.get('cooldown_sec'),'entry_route':c.metrics.get('entry_route'),'direct_sec':c.metrics.get('direct_sec'),'direct_support_ok':c.metrics.get('direct_support_ok'),'rally_dna_active':bool(c.metrics.get('rally_dna_active')),'rally_dna_match':c.metrics.get('rally_dna_match'),'rally_dna_trap':c.metrics.get('rally_dna_trap'),'rally_dna_bonus':c.metrics.get('rally_dna_bonus'),'rally_dna_type':c.metrics.get('rally_dna_type'),'rally_dna_samples':c.metrics.get('rally_dna_samples'),'compression':c.metrics.get('compression')
        }
        rows.append({'rank':i,'code':c.code,'name':c.name or c.code,'sector':c.sector,'sector_source':c.sector_source,'price':c.last_price,'change_rate':c.rate,'score':c.score,'confidence':c.confidence,'stage':c.stage,'entry_state':c.entry_state,'entry_reason':c.metrics.get('entry_reason') or c.reject_reason,'entry_ready':bool(c.metrics.get('entry_ready')),'reasons':c.reasons,'metrics':c.metrics,'evidence':evidence,'sources':list(c.source_hits),'venue':c.venue,'fid9081':c.last_fid9081,'last_tick_at_kst':fmt_kst(c.last_tick_at,'%H:%M:%S') if c.last_tick_at else None,'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None,'capture':capture_json(cap) if cap else None,'captures':{k:capture_json(v) for k,v in c.captures.items()}})
    ok_rest=sum(1 for x in STATE.rest_status.values() if x.get('ok'))
    return {'version':APP_VERSION,'generated_at':now_kst(),'threshold':MIN_SCORE,'rows':rows,'feed':truth,'health':{'ws':STATE.ws_status,'rest_ok':ok_rest,'rest_total':len(STATE.rest_status),'candidate_count':len(STATE.candidates),'subscribed':len(STATE.ws_codes),'scan_cycles':STATE.scan_cycles,'event_count':STATE.event_count,'smart_status':STATE.smart_status,'sector_status':STATE.sector_status,'learning':STATE.learn,'rally_dna':rally_model_status()},'policy':{'probability_note':'NOVA Score는 실시간 상대 우선순위입니다. 실제 승률은 누적 성과표본으로 별도 산출해야 합니다.','data_truth':'Kiwoom REST ranking + WebSocket 0B + FID9081 + investor/program flow + live sector breadth + RALLY DNA prior + freshness gate','universe':'고정 목록 없이 순위 API 중첩으로 계속 재구성','entry_policy':'점수는 발견용. 이중 BUY 상태기계에 전일 완료된 RALLY DNA 유사도만 소프트 가산/감점. 당일 미래데이터는 절대 사용하지 않음','time_truth':'Asia/Seoul ZoneInfo 기준'}}

@app.get('/api/buy-signals')
async def buy_signals():
    score_all(); now=time.time(); day=today_kst(); rows=[]
    for c in STATE.candidates.values():
        if c.signal_count_today<=0 or c.last_signal_at<=0:continue
        entry=c.last_signal_price
        ret=round((c.last_price/entry-1)*100,2) if entry>0 and c.last_price>0 else None
        maxret=round((c.signal_max_price/entry-1)*100,2) if entry>0 and c.signal_max_price>0 else None
        minret=round((c.signal_min_price/entry-1)*100,2) if entry>0 and c.signal_min_price>0 else None
        smart=c.smart or {}
        rows.append({
            'code':c.code,'name':c.name or c.code,'sector':c.sector,'sector_score':c.metrics.get('sector_score'),'sector_leader':c.metrics.get('sector_leader'),'stage':'BUY','entry_state':c.entry_state,'entry_id':c.last_buy_entry_id,'entry_route':c.last_buy_route,'entry_path':('DISCOVERY>PRESSURE_BUILD>DIRECT_ARM>BUY' if c.last_buy_route=='DIRECT_IGNITION' else 'DISCOVERY>PRESSURE_BUILD>PULLBACK>REACCEL>BUY'),
            'first_signal_at_kst':fmt_kst(c.first_signal_at,'%H:%M:%S') if c.first_signal_at else None,
            'last_signal_at_kst':fmt_kst(c.last_signal_at,'%H:%M:%S') if c.last_signal_at else None,
            'last_signal_age_sec':round(now-c.last_signal_at) if c.last_signal_at else None,
            'price':c.last_price,'change_rate':c.rate,'entry_price':entry,'signal_return':ret,'max_return':maxret,'min_return':minret,
            'signal_count':c.signal_count,'signal_count_today':c.signal_count_today,'score':c.score,'signal_score':c.last_signal_score,'confidence':c.confidence,
            'venue':c.venue,'fid9081':c.last_fid9081,'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None,
            'reasons':c.last_signal_reasons or c.reasons,
            'smart_money_score':c.metrics.get('smart_money_score'),'algo_persistence':c.metrics.get('algo_persistence'),
            'program_net':smart.get('program_net'),'program_delta':smart.get('program_delta'),'trust_net':smart.get('trust_net'),'trust_delta':smart.get('trust_delta'),'pension_net':smart.get('pension_net'),'pension_delta':smart.get('pension_delta'),'institution_net':smart.get('institution_net'),'institution_delta':smart.get('institution_delta'),'foreign_net':smart.get('foreign_net'),'foreign_delta':smart.get('foreign_delta'),'rally_dna_active':bool(c.metrics.get('rally_dna_active')),'rally_dna_match':c.metrics.get('rally_dna_match'),'rally_dna_trap':c.metrics.get('rally_dna_trap'),'rally_dna_bonus':c.metrics.get('rally_dna_bonus'),'rally_dna_type':c.metrics.get('rally_dna_type'),'rally_dna_samples':c.metrics.get('rally_dna_samples')
        })
    rows.sort(key=lambda x:(STAGE_RANK.get(x['stage'],0),x['score'],x['last_signal_at_kst'] or ''),reverse=True)
    return {'version':APP_VERSION,'day':day,'count':len(rows),'total_events':STATE.buy_signal_events,'generated_at':now_kst(),'rows':rows[:100]}

@app.get('/api/rally-dna')
async def rally_dna_api():
    st=rally_model_status();m=STATE.rally_model or {}
    return {'ok':True,'version':APP_VERSION,'status':st,'model':{'version':m.get('version'),'samples':m.get('samples',0),'positive':m.get('positive',0),'negative':m.get('negative',0),'types':m.get('types') or {},'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'effective_from_day':m.get('effective_from_day'),'leakage_guard':m.get('leakage_guard')},'review':STATE.rally_review,'generated_at':now_kst()}

@app.get('/api/performance')
async def performance():
    score_all();out=[]
    for c in STATE.candidates.values():
        for st,cap in c.captures.items():
            out.append({'code':c.code,'name':c.name,'stage':st,**capture_json(cap)})
    out.sort(key=lambda x:x['at'],reverse=True)
    return {'version':APP_VERSION,'count':len(out),'rows':out[:300]}

@app.get('/api/health')
async def health():
    return {'ok':True,'version':APP_VERSION,'feed':feed_truth(),'ws':STATE.ws_status,'rest':STATE.rest_status,'generated_at':now_kst(),'smart_money':STATE.smart_status,'sector':STATE.sector_status,'learning':STATE.learn,'data_files':{'events':str(EVENT_FILE),'performance':str(STATE_FILE),'learning':str(LEARN_FILE),'training':str(TRAIN_FILE),'buy_signals':str(BUY_SIGNAL_FILE),'buy_signal_state':str(BUY_SIGNAL_STATE),'rally_model':str(RALLY_MODEL_FILE),'rally_samples':str(RALLY_SAMPLE_FILE),'rally_review':str(RALLY_REVIEW_FILE),'rally_trace_today':str(rally_trace_file())},'entry_policy':{'version':'ENTRY_V4_RALLY_DNA','routes':['PULLBACK_REACCEL','DIRECT_IGNITION'],'hold_sec':ENTRY_HOLD_SEC,'pullback_min':ENTRY_PULLBACK_MIN,'pullback_max':ENTRY_PULLBACK_MAX,'reaccel_sec':ENTRY_REACCEL_SEC,'direct_score':DIRECT_SCORE,'direct_hold_sec':DIRECT_HOLD_SEC,'direct_confirm_sec':DIRECT_CONFIRM_SEC,'cooldown_sec':ENTRY_COOLDOWN_SEC,'reentry_min_sec':ENTRY_REENTRY_MIN_SEC,'reentry_gain_pct':ENTRY_REENTRY_GAIN_PCT,'max_daily':ENTRY_MAX_DAILY,'normal_market_signal_target':'8-25/day market-wide diagnostic only','quota_enforced':False,'timezone':'Asia/Seoul','rally_dna':'EOD review -> next-day only soft prior','rally_min_samples':RALLY_MIN_SAMPLES,'rally_max_bonus':RALLY_MAX_BONUS,'rally_max_penalty':RALLY_MAX_PENALTY}}
