# QUANT NOVA 1.6.0 · RALLY DNA SELF-LEARNING

기존 1.5.1의 BALANCED DUAL ENTRY를 유지하면서, **장 종료 후 자동 복기 → 급등 성공/실패 표본 생성 → 다음날부터만 점수 보정**하는 RALLY DNA 엔진을 추가했습니다.

## 핵심
- 장중 1분 간격으로 당시 이용 가능했던 후보 특징만 compact trace로 저장
- +5% 구간 진입 뒤 30분 내 +3% 이상 추가 확장하고 당일 +10% 이상 도달한 종목을 RALLY 성공표본으로 분류
- NOVA 65점 이상이었지만 30분 MFE < +1.8%이고 MAE <= -1.2% 또는 30분 종가효과 <= -0.5%인 종목을 TRAP 실패표본으로 분류
- T-60/T-30/T-15/T-5분 특징을 시간가중 평균해 DNA 벡터 생성
- ACCUMULATION / VOLUME_IGNITION / SECTOR_ROTATION / SQUEEZE_BREAKOUT / NEWS_SHOCK 유형 분류
- 최소 30개 복기표본 이전에는 WARM-UP. 이후에도 RALLY DNA는 최대 +8점, TRAP DNA는 최대 -6점의 **소프트 보정**만 수행
- 장 마감 후 만든 모델은 `effective_from_day=다음날`로 저장하여 당일 미래정보 누출 방지
- 원본 trace는 20일 보존, 학습 sample/model은 영구 보존

## 영구 데이터
- `data/rally_trace_YYYYMMDD.jsonl` 장중 시계열
- `data/rally_dna_samples.jsonl` 성공/실패 복기표본
- `data/rally_dna_model.json` 다음날 적용 모델
- `data/rally_daily_review.json` 일별 복기 완료상태

## 기존 보호
- KRX/NXT 실체결, FID9081, 프로그램/투신/연기금, 섹터확산, PULLBACK_REACCEL / DIRECT_IGNITION 상태기계 유지
- 기존 BUY 성과 자기학습은 별도 모델로 계속 유지
- RALLY DNA는 신규 BUY를 강제로 만들지 않으며 이미 +10% 이상 오른 종목에는 양의 DNA 가산을 차단
