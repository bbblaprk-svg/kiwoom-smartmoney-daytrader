# QUANT NOVA 3.1 Master Ground-Up 9 Runtime

This source tree is rebuilt from the 2026-08-12 integrated master specifications. It does not import a previous NOVA application tree and is not an in-container patch.

## Critical path

`Kiwoom broker WS -> TickIntegrity -> ProtectedTradeQueue -> Ingestor -> FixedMicroWindow -> MetricEngine -> frozen EntryPolicy -> one-writer FULL SQLite formal WAL -> LiveTracker -> immutable DisplayState -> /ws/live`

No REST request, signal calculation, SQLite write, JSONL write, or UI rendering occurs inside the broker WebSocket receive callback.

## Memory invariants

- Candidate count bounded; formal signals, confirmed BUYs, prior-close candidates, and due 1/3/5 follow-ups are protected.
- Trade backlog is four bounded FIFO shards; default 1,024 events per shard.
- Program/orderbook/discovery state is latest-value coalesced by `(kind, symbol, venue)`.
- Every accepted tick contributes to metrics, but memory is rate independent: 100 ms buckets for the newest 60 s and 1 s buckets through 330 s.
- Windows for inactive symbols are pruned.
- Formal and important history queues are bounded.
- Docker deployment sets `memory == memory-swap`, so the NOVA container cannot enter swap-thrash; OOM/restart is observable and fails deployment soak.

## Truth invariants

- KRX and NXT have independent state, integrity, windows, entry state machines, prices, and outcomes.
- A raw item/FID venue conflict fails closed.
- Formal signal price/time/recv_seq come from the exact decision tick and are immutable.
- Formal signal/BUY memory state is mutated only after SQLite `synchronous=FULL` COMMIT acknowledgement.
- One SQLite writer gives formal records priority over important history; there is no competing writer lock.
- Important lifecycle history cannot silently disappear: queue exhaustion or write stall terminates the process for recovery.
- Queue or WebSocket gaps fail closed, clear stale score/windows, and require a new monotonic live sequence to rewarm.
- Process restart restores committed truth first, then RESYNC/WARMING; prior-day intraday rows do not contaminate a new trading day.
- 1/3/5 trading-day outcomes are original-venue locked and finalize only from an exact target-day verified live close; otherwise remain pending.

## Liveness and recovery

- Event-loop heartbeat is watched by an independent OS thread. A hard loop stall exits the process so Docker restart policy can recover it.
- Formal WAL and important-history transactions have independent hard-stall exits.
- Docker `HEALTHCHECK` calls `/api/livez`; installer also tests HTTP, WebSocket, memory/swap, journal counters, mismatch counters, and real broker feed when the market is active.
- `/api/livez` is process/event-loop liveness; `/api/readyz` separately requires state restore plus durable-journal readiness, so startup races cannot be mistaken for deploy readiness.

## UI invariants

- Five fixed rows per board; values change, layout does not.
- Candidate boards can compete/re-rank; confirmed BUY position-manager rows are not evicted by score ranking.
- One `/ws/live` connection remains an optional low-latency path. A source-controlled 2-second `/api/live-dashboard` poll runs independently so a half-open/blocked browser WebSocket cannot freeze the UI. The HTTP guard explicitly bypasses its stale-while-revalidate cache for live dashboard/board APIs, so current-price projection is never served from a historical guard cache.
- Delta batches are generated from compact display state; UI never reads the live calculation object graph directly. The browser sends the access token as `Authorization: Bearer`, which the clean HTTP guard forwards without runtime JS injection.
- Overnight fallback is board-local, only while the market is closed, and cannot overlay live boards after the lifecycle transition.
- Signal detail includes time history plus 1/3/5 trading-day outcomes.
- **Live display truth:** board eligibility and rendered `price/change_rate` are projected from the same fresh venue tick. A higher score on a stale KRX/NXT venue can never select the displayed current price.
- `signal_price` and BUY identity remain immutable and venue-locked. Display-current price is a separate read-only projection and never mutates EntryPolicy, Candidate signal state, WAL, MFE/MAE identity, or repeat counts.
- Venue-strict management boards (NXT management and confirmed-position management) fail closed when their required venue is stale: current price/return become unavailable instead of borrowing the other market's price.

## Deployment invariants

- Build from `python:3.12-slim-bookworm` and pinned requirements.
- No `docker commit`, no in-container `sed`, no running `main.py` replacement.
- Existing active container is stopped but preserved intact to release memory; production data is snapshotted after stop.
- Clean candidate uses the copied data and no-swap cgroup.
- Only after candidate gates pass is the old container renamed to an immutable rollback name and the new active created.
- Any post-cutover gate failure restores the old container.

## Groundup-9 deployment boundary
Groundup-9 does not build, install Python packages, compile source, or execute unit tests on the 1 GB Lightsail host.
The immutable image is built and tested on GitHub Actions and published to GHCR. Lightsail only pulls the validated image, runs a bounded offline candidate, then performs an atomic cutover.
The active container hard limit is 448 MiB with container swap disabled (`--memory-swap` equals `--memory`).
The old container is preserved by rename and is not mutated. Rollback restores its original name and original running/stopped state.

## Groundup-9 clean HTTP boundary
The deployment image contains `ops/http_guard_v2.py`, the unpatched source-controlled HTTP guard. Deployment replaces any prior emergency R3/R6/R7 guard source only after the new active runtime passes soak, copies the new static bundle, restarts the guard, and verifies public API/UI. This removes the debug-patch lineage from the production HTTP path.
