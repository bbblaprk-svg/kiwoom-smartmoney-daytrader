#!/usr/bin/env python3
from __future__ import annotations
import json,os,select,socket,threading,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.error import HTTPError
from urllib.request import Request,urlopen
from urllib.parse import urlparse

HOST=os.getenv('GUARD_HOST','0.0.0.0');PORT=int(os.getenv('GUARD_PORT','8080'));UPSTREAM=os.getenv('NOVA_UPSTREAM','http://quant-nova:8000').rstrip('/')
GET_TIMEOUT=float(os.getenv('NOVA_GUARD_GET_TIMEOUT','2.0'));WRITE_TIMEOUT=float(os.getenv('NOVA_GUARD_WRITE_TIMEOUT','8'));MAX_BODY=int(os.getenv('NOVA_GUARD_MAX_BODY',str(20*1024*1024)));MAX_UPSTREAM=int(os.getenv('NOVA_GUARD_MAX_UPSTREAM','24'))
_slots=threading.BoundedSemaphore(MAX_UPSTREAM);_state_lock=threading.Lock();_state={'started_at':time.time(),'requests':0,'http_ok':0,'http_fail':0,'ws_ok':0,'ws_fail':0,'busy':0,'last_upstream_ok_at':0.0,'last_error':''}
def inc(k,n=1):
    with _state_lock:_state[k]=int(_state.get(k,0))+n
def mark_ok():
    with _state_lock:_state['last_upstream_ok_at']=time.time();_state['last_error']=''
def mark_fail(e):
    with _state_lock:_state['last_error']=str(e)[:180]
def snapshot():
    with _state_lock:return dict(_state)
def upstream_request(method,path,headers,body=None,timeout=None):
    if not _slots.acquire(False):inc('busy');raise RuntimeError('upstream_busy')
    try:
        h={'User-Agent':'NOVA-HTTP-GUARD/5.0','Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache'}
        for k in ('Authorization','X-App-Token','X-Access-Token','Content-Type','Accept','Accept-Encoding','If-None-Match','If-Modified-Since'):
            v=headers.get(k)
            if v:h[k]=v
        try:
            with urlopen(Request(UPSTREAM+path,data=body,headers=h,method=method),timeout=timeout or GET_TIMEOUT) as r:
                data=r.read(MAX_BODY+1)
                if len(data)>MAX_BODY:raise RuntimeError('body_too_large')
                mark_ok();inc('http_ok');return int(r.status),r.headers.get('Content-Type','application/octet-stream'),data
        except HTTPError as e:
            data=e.read(MAX_BODY+1);mark_ok();return int(e.code),e.headers.get('Content-Type','application/json'),data[:MAX_BODY]
    except Exception as e:inc('http_fail');mark_fail(e);raise
    finally:_slots.release()
class Server(ThreadingHTTPServer):daemon_threads=True;allow_reuse_address=True;request_queue_size=256
class H(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1';server_version='NOVAHTTPGuard/5.0'
    def log_message(self,*a):return
    def sendb(self,status,ct,b,extra=None):
        self.send_response(status);self.send_header('Content-Type',ct);self.send_header('Content-Length',str(len(b)));self.send_header('Connection','close');self.send_header('X-NOVA-HTTP-Guard','5');self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');self.send_header('Pragma','no-cache');self.send_header('Expires','0')
        for k,v in (extra or {}).items():self.send_header(k,str(v))
        self.end_headers()
        if self.command!='HEAD':
            try:self.wfile.write(b)
            except (BrokenPipeError,ConnectionResetError):pass
    def sendj(self,status,obj,extra=None):self.sendb(status,'application/json; charset=utf-8',json.dumps(obj,separators=(',',':')).encode(),extra)
    def do_HEAD(self):return self.do_GET()
    def do_GET(self):
        inc('requests');clean=self.path.split('?',1)[0]
        if clean=='/_guard/health':
            st=snapshot();age=None if not st['last_upstream_ok_at'] else round(time.time()-st['last_upstream_ok_at'],3);return self.sendj(200,{'ok':True,'guard':'NOVA_HTTP_LIVE_BRIDGE_V1','api_cache_enabled':False,'static_cache_enabled':False,'static_proxy':'UPSTREAM_SINGLE_SOURCE','websocket_tunnel':True,'last_upstream_ok_age_sec':age,'stats':st})
        if clean=='/_guard/upstream':
            t=time.time()
            try:status,_,_=upstream_request('GET','/api/livez',self.headers,timeout=1.5);return self.sendj(200 if status==200 else 503,{'ok':status==200,'status':status,'elapsed_ms':round((time.time()-t)*1000,2)})
            except Exception as e:return self.sendj(503,{'ok':False,'error':str(e)[:160],'elapsed_ms':round((time.time()-t)*1000,2)})
        if clean.startswith('/ws/') and self.headers.get('Upgrade','').lower()=='websocket':return self.websocket_proxy()
        try:
            st,ct,b=upstream_request('GET',self.path,self.headers,timeout=max(GET_TIMEOUT,2.0));return self.sendb(st,ct,b,{'X-NOVA-Upstream':'SINGLE_SOURCE_DIRECT'})
        except Exception as e:return self.sendj(503,{'ok':False,'error':'UPSTREAM_HTTP_UNAVAILABLE','detail':str(e)[:140]},{'Retry-After':'1'})
    def websocket_proxy(self):
        u=urlparse(UPSTREAM);host=u.hostname or 'quant-nova';port=u.port or 80
        if u.scheme!='http':return self.sendj(502,{'ok':False,'error':'WS_UPSTREAM_SCHEME_UNSUPPORTED'})
        upstream=None;handshake=False
        try:
            upstream=socket.create_connection((host,port),timeout=5);upstream.settimeout(5);lines=[f'GET {self.path} HTTP/1.1\r\n',f'Host: {host}:{port}\r\n']
            for k,v in self.headers.items():
                if k.lower() in {'host','proxy-connection'}:continue
                lines.append(f'{k}: {v}\r\n')
            lines.append('\r\n');upstream.sendall(''.join(lines).encode('latin-1','replace'));buf=b''
            while b'\r\n\r\n' not in buf and len(buf)<65536:
                part=upstream.recv(4096)
                if not part:break
                buf+=part
            if not buf:raise RuntimeError('empty_websocket_handshake')
            self.connection.sendall(buf);handshake=True
            if b' 101 ' not in buf.split(b'\r\n',1)[0]:self.close_connection=True;return
            inc('ws_ok');self.connection.settimeout(None);upstream.settimeout(None);sockets=[self.connection,upstream]
            while True:
                readable,_,bad=select.select(sockets,[],sockets,30)
                if bad:break
                if not readable:continue
                for src in readable:
                    dst=upstream if src is self.connection else self.connection;data=src.recv(65536)
                    if not data:self.close_connection=True;return
                    dst.sendall(data)
        except Exception as e:
            inc('ws_fail');mark_fail(e)
            if not handshake:
                try:self.sendj(502,{'ok':False,'error':'WS_UPSTREAM_UNAVAILABLE','detail':str(e)[:120]})
                except Exception:pass
        finally:
            if upstream is not None:
                try:upstream.close()
                except Exception:pass
            self.close_connection=True
    def writeproxy(self):
        inc('requests');n=int(self.headers.get('Content-Length') or 0)
        if n>MAX_BODY:return self.sendj(413,{'detail':'Payload too large'})
        body=self.rfile.read(n) if n else b''
        try:st,ct,b=upstream_request(self.command,self.path,self.headers,body,WRITE_TIMEOUT);return self.sendb(st,ct,b,{'X-NOVA-Upstream':'SINGLE_SOURCE_DIRECT'})
        except Exception as e:return self.sendj(503,{'ok':False,'error':'UPSTREAM_WRITE_UNAVAILABLE','detail':str(e)[:120]})
    do_POST=writeproxy;do_PUT=writeproxy;do_PATCH=writeproxy;do_DELETE=writeproxy
if __name__=='__main__':
    print(f'NOVA_HTTP_GUARD=START version=5 port={PORT} static=UPSTREAM_SINGLE_SOURCE upstream={UPSTREAM}',flush=True);Server((HOST,PORT),H).serve_forever()
