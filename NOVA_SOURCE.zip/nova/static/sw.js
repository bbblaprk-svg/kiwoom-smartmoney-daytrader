self.addEventListener('install',event=>{self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil((async()=>{
  try{for(const key of await caches.keys()){if(key.startsWith('nova'))await caches.delete(key)}}catch(_){ }
  try{await self.clients.claim()}catch(_){ }
  try{await self.registration.unregister()}catch(_){ }
})())});
