from __future__ import annotations
import time
from app.domain import Candidate,Origin,Venue
from app.runtime.clock import lifecycle_phase

class OpeningBridge:
    """19:30 close candidate -> next-day premarket -> shakeout/reversal -> BUY_READY lifecycle."""
    def update(self,c:Candidate,phase:str|None=None,now:float|None=None):
        phase=phase or lifecycle_phase();now=now or time.time();best=c.best_signal_venue();v=c.venue_state[best] if best in (Venue.KRX,Venue.NXT) and c.venue_state[best].last_tick_at else c.current();m=v.metrics;old=c.lifecycle_state
        if c.origin==Origin.PRIOR_CLOSE:
            if phase=='PRIOR_CLOSE_FROZEN':new='PRIOR_CLOSE_FROZEN'
            elif phase=='PREMARKET_RECHECK':
                if v.last_price>0:c.premarket_price=v.last_price;c.premarket_change=v.last_rate;c.premarket_valid=bool(m.get('fresh'))
                new='PREMARKET_RECHECK'
            elif phase=='OPENING_HANDOFF':new='OPENING_HANDOFF'
            elif phase in ('SHAKEOUT_WATCH','REVERSAL_WINDOW','NORMAL_INTRADAY'):
                if not c.opening_price and v.last_price>0:c.opening_price=v.last_price;c.opening_high=v.last_price;c.opening_low=v.last_price
                if v.last_price>0:c.opening_high=max(c.opening_high or v.last_price,v.last_price);c.opening_low=min(c.opening_low or v.last_price,v.last_price)
                if phase=='SHAKEOUT_WATCH':
                    shake=bool(c.opening_price and v.last_price<c.opening_price*.99 and float(m.get('buy_pressure') or 50)<50 and float(m.get('micro_vwap_gap') or 0)<0)
                    c.shakeout_state=c.shakeout_state or shake;new='SHAKEOUT_WATCH' if c.shakeout_state else 'OPENING_ACTIVE'
                elif phase=='REVERSAL_WINDOW':
                    vgap=m.get('micro_vwap_gap');vgap_ok=vgap is not None and float(vgap)>=-.10
                    reversal=bool(c.shakeout_state and float(m.get('buy_pressure') or 0)>=56 and vgap_ok and float(m.get('volume_accel') or 1)>=1.10 and v.last_price>=(c.opening_low or v.last_price)*1.003)
                    c.reversal_state=c.reversal_state or reversal;new='REVERSAL_EARLY' if c.reversal_state else ('SHAKEOUT_WATCH' if c.shakeout_state else 'OPENING_ACTIVE')
                    if c.reversal_state and c.score>=62 and c.entry_state in ('PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM'):new='BUY_READY'
                else:new='BUY' if c.entry_state=='BUY' else 'BUY_READY' if c.entry_state in ('REACCEL','DIRECT_ARM') else 'NORMAL_INTRADAY'
            else:new=old
        else:
            if phase=='CLOSE_TRACK' and c.score>=64:new='CLOSE_TRACK';c.close_signal_price=c.close_signal_price or v.last_price;c.close_score=max(c.close_score,c.score)
            elif c.entry_state=='BUY':new='BUY'
            elif c.entry_state in ('REACCEL','DIRECT_ARM'):new='BUY_READY'
            else:new='TODAY_NEW'
        if new!=old:c.lifecycle_state=new;c.state_changed_at=now;c.append_history('LIFECYCLE',new,v.last_price,f'{old}→{new}',v.venue,now)

    def close_candidates(self,candidates:list[Candidate],limit=20,phase:str|None=None)->list[Candidate]:
        phase=phase or lifecycle_phase();rows=[c for c in candidates if c.lifecycle_state=='CLOSE_TRACK' or (phase=='CLOSE_TRACK' and c.score>=64)]
        rows.sort(key=lambda c:(c.score,c.valid_repeat_count,c.current().last_rate),reverse=True)
        for i,c in enumerate(rows[:limit],1):c.close_rank=i
        return rows[:limit]
