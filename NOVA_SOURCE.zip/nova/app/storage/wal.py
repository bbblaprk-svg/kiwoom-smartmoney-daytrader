from __future__ import annotations
import json,os,queue,sqlite3,threading,time
from collections import deque
from dataclasses import dataclass,field
from pathlib import Path
from typing import Any,Callable
from app.config import SETTINGS

@dataclass(slots=True,frozen=True)
class CommitResult:
    ok:bool; inserted:bool=False; error:str=''
    def __bool__(self): return self.ok

@dataclass(slots=True)
class WalRequest:
    record:dict[str,Any]
    ack:threading.Event=field(default_factory=threading.Event)
    lock:threading.Lock=field(default_factory=threading.Lock)
    enqueued_at:float=field(default_factory=time.monotonic)
    started_at:float=0.0; started:bool=False; cancelled:bool=False
    ok:bool=False; inserted:bool=False; error:str=''

class DurableJournal:
    """Priority durable journal with no disk I/O on the asyncio realtime path.

    One SQLite writer owns all database writes. Formal SIGNAL/BUY requests always have priority
    over important lifecycle/history records, eliminating competing SQLite writer locks. Formal
    state mutates only after synchronous=FULL COMMIT acknowledgement. Important history is bounded
    and fail-hard rather than silently dropped. Noncritical diagnostics use a separate bounded
    JSONL writer where drops are observable and allowed.
    """
    EXIT_FORMAL_STALL=79
    EXIT_IMPORTANT_STALL=80
    EXIT_DB_INIT=81

    def __init__(self,data_dir:Path|None=None,hard_stall_sec:float|None=None,event_stall_sec:float|None=None,exit_fn:Callable[[int],None]|None=None):
        self.data_dir=data_dir or SETTINGS.data_dir
        self.wal_path=self.data_dir/'signal_wal.sqlite3'; self.event_path=self.data_dir/'events.jsonl'
        self.legacy_wal_path=self.data_dir/'signal_wal.jsonl'
        self.critical=queue.Queue(maxsize=SETTINGS.journal_critical_max)
        self.important=queue.Queue(maxsize=SETTINGS.journal_important_max)
        self.noncritical=queue.Queue(maxsize=SETTINGS.journal_noncritical_max)
        self.stop_evt=threading.Event(); self.threads:list[threading.Thread]=[]
        self.active_lock=threading.Lock(); self.active_since=0.0; self.active_kind=''
        self.ready_evt=threading.Event(); self.init_error=''
        self.hard_stall_sec=float(hard_stall_sec or SETTINGS.wal_hard_stall_sec)
        self.event_stall_sec=float(event_stall_sec or SETTINGS.event_wal_hard_stall_sec)
        self.exit_fn=exit_fn or os._exit
        self.write_ms=deque(maxlen=800); self.wait_ms=deque(maxlen=800); self.event_write_ms=deque(maxlen=800)
        self.stats={
            'critical_committed':0,'critical_failed':0,'critical_cancelled_before_start':0,
            'critical_group_commits':0,'critical_group_max':0,'wal_hard_stall_exit':0,
            'important_committed':0,'important_enqueue_fail':0,'important_group_commits':0,
            'event_hard_stall_exit':0,'db_init_fail':0,
            'noncritical_written':0,'noncritical_dropped':0,
        }

    def start(self):
        if self.threads:return
        self.stop_evt.clear(); self.ready_evt.clear(); self.init_error=''
        for target,name in ((self._sqlite_worker,'nova-wal-sqlite'),(self._event_worker,'nova-wal-events'),(self._stall_monitor,'nova-wal-stall-watch')):
            t=threading.Thread(target=target,name=name,daemon=True); t.start(); self.threads.append(t)

    def stop(self):
        self.stop_evt.set()
        for t in self.threads:t.join(timeout=3)
        self.threads=[]

    def commit(self,record:dict[str,Any],timeout:float=.75)->CommitResult:
        req=WalRequest(record=dict(record))
        try:self.critical.put_nowait(req)
        except queue.Full:
            self.stats['critical_failed']+=1; return CommitResult(False,False,'QUEUE_FULL')
        if req.ack.wait(max(.05,timeout)):return CommitResult(req.ok,req.inserted,req.error)
        with req.lock:
            if not req.started:
                req.cancelled=True; self.stats['critical_cancelled_before_start']+=1; self.stats['critical_failed']+=1
                return CommitResult(False,False,'CANCELLED_BEFORE_START')
        # Once SQLite BEGIN has started, the caller must not guess the transaction outcome.
        # Independent stall monitor terminates the process if storage never returns.
        req.ack.wait(); return CommitResult(req.ok,req.inserted,req.error)

    def append_important(self,record:dict[str,Any])->bool:
        try:self.important.put_nowait(dict(record)); return True
        except queue.Full:
            self.stats['important_enqueue_fail']+=1; self.exit_fn(self.EXIT_IMPORTANT_STALL); return False

    def append(self,record:dict[str,Any])->bool:
        try:self.noncritical.put_nowait(dict(record)); return True
        except queue.Full:self.stats['noncritical_dropped']+=1; return False

    @staticmethod
    def _pct(xs,p):
        ys=sorted(xs); return round(ys[int(p*(len(ys)-1))],2) if ys else 0.0

    def health(self)->dict[str,Any]:
        with self.active_lock:active_since=self.active_since; active_kind=self.active_kind
        age=round(time.monotonic()-active_since,3) if active_since else 0.0
        return {
            **self.stats,'ready':self.ready_evt.is_set(),'init_error':self.init_error,
            'critical_depth':self.critical.qsize(),'important_depth':self.important.qsize(),'noncritical_depth':self.noncritical.qsize(),
            'active_kind':active_kind,'critical_active_age_sec':age if active_kind=='critical' else 0.0,
            'important_active_age_sec':age if active_kind=='important' else 0.0,
            'db_queue_depth':self.critical.qsize()+self.important.qsize()+self.noncritical.qsize(),
            'db_write_latency_p95_ms':self._pct(self.write_ms,.95),'db_queue_wait_p95_ms':self._pct(self.wait_ms,.95),
            'important_write_latency_p95_ms':self._pct(self.event_write_ms,.95),
            'wal_backend':'ONE_WRITER_SQLITE_FULL_PRIORITY+BOUNDED_JSONL'
        }

    def _open_db(self):
        self.data_dir.mkdir(parents=True,exist_ok=True)
        con=sqlite3.connect(self.wal_path,timeout=10,isolation_level=None,check_same_thread=False)
        # Only this one connection ever changes/uses the SQLite write mode.
        con.execute('PRAGMA journal_mode=WAL'); con.execute('PRAGMA synchronous=FULL')
        con.execute('PRAGMA busy_timeout=3000'); con.execute('PRAGMA temp_store=MEMORY')
        con.execute('''CREATE TABLE IF NOT EXISTS formal_wal(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, signal_id TEXT UNIQUE, event TEXT NOT NULL,
            day TEXT, code TEXT, venue TEXT, created_at REAL NOT NULL, payload TEXT NOT NULL)''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_formal_day_code ON formal_wal(day,code,seq)')
        con.execute('''CREATE TABLE IF NOT EXISTS important_history(
            seq INTEGER PRIMARY KEY AUTOINCREMENT, event_key TEXT UNIQUE, day TEXT, code TEXT,
            kind TEXT, created_at REAL NOT NULL, payload TEXT NOT NULL)''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_history_day_code ON important_history(day,code,seq)')
        return con

    @staticmethod
    def _history_key(r:dict[str,Any])->str:
        return str(r.get('event_key') or f"{r.get('code','')}:{r.get('kind','')}:{r.get('state','')}:{r.get('venue','')}:{float(r.get('at') or 0):.6f}")

    def _set_active(self,kind:str,at:float|None=None):
        with self.active_lock:self.active_kind=kind; self.active_since=at or time.monotonic()
    def _clear_active(self):
        with self.active_lock:self.active_kind=''; self.active_since=0.0

    def _pull_critical(self)->list[WalRequest]:
        try:first=self.critical.get_nowait()
        except queue.Empty:return []
        pulled=[first]
        for _ in range(31):
            try:pulled.append(self.critical.get_nowait())
            except queue.Empty:break
        active=[]
        for req in pulled:
            with req.lock:
                if req.cancelled:
                    req.error='CANCELLED_BEFORE_START'; req.ok=False; req.ack.set(); self.critical.task_done(); continue
                req.started=True; req.started_at=time.monotonic(); active.append(req); self.wait_ms.append((req.started_at-req.enqueued_at)*1000)
        return active

    def _write_critical(self,con,batch:list[WalRequest]):
        if not batch:return
        self._set_active('critical',min(r.started_at for r in batch)); t0=time.monotonic()
        try:
            con.execute('BEGIN IMMEDIATE')
            for req in batch:
                r=req.record; sid=str(r.get('signal_id') or f"{r.get('event','EVENT')}:{r.get('day','')}:{r.get('code','')}:{r.get('venue','')}:{int(req.enqueued_at*1_000_000)}")
                cur=con.execute('INSERT OR IGNORE INTO formal_wal(signal_id,event,day,code,venue,created_at,payload) VALUES(?,?,?,?,?,?,?)',
                    (sid,str(r.get('event') or ''),str(r.get('day') or r.get('trade_day') or ''),str(r.get('code') or ''),str(r.get('venue') or ''),
                     float(r.get('signal_time') or r.get('created_at') or time.time()),json.dumps(r,ensure_ascii=False,separators=(',',':'))))
                req.inserted=(cur.rowcount==1)
            con.execute('COMMIT'); self.write_ms.append((time.monotonic()-t0)*1000)
            self.stats['critical_group_commits']+=1; self.stats['critical_group_max']=max(self.stats['critical_group_max'],len(batch))
            for req in batch:req.ok=True; self.stats['critical_committed']+=1
        except Exception as e:
            try:con.execute('ROLLBACK')
            except Exception:pass
            for req in batch:req.error=str(e); req.ok=False; self.stats['critical_failed']+=1
        finally:
            self._clear_active()
            for req in batch:req.ack.set(); self.critical.task_done()

    def _pull_important(self)->list[dict[str,Any]]:
        try:first=self.important.get(timeout=.05)
        except queue.Empty:return []
        batch=[first]
        # Keep important transactions short so a formal signal is never held behind a long batch.
        for _ in range(15):
            if not self.critical.empty():break
            try:batch.append(self.important.get_nowait())
            except queue.Empty:break
        return batch

    def _write_important(self,con,batch:list[dict[str,Any]]):
        if not batch:return
        self._set_active('important'); t0=time.monotonic()
        try:
            con.execute('BEGIN IMMEDIATE')
            for r in batch:
                at=float(r.get('at') or r.get('created_at') or time.time())
                day=str(r.get('day') or r.get('trade_day') or time.strftime('%Y%m%d',time.localtime(at)))
                con.execute('INSERT OR IGNORE INTO important_history(event_key,day,code,kind,created_at,payload) VALUES(?,?,?,?,?,?)',
                    (self._history_key(r),day,str(r.get('code') or ''),str(r.get('kind') or r.get('event') or ''),at,json.dumps(r,ensure_ascii=False,separators=(',',':'))))
            con.execute('COMMIT'); self.stats['important_group_commits']+=1; self.stats['important_committed']+=len(batch); self.event_write_ms.append((time.monotonic()-t0)*1000)
        except Exception:
            try:con.execute('ROLLBACK')
            except Exception:pass
            self.stats['important_enqueue_fail']+=len(batch); self.exit_fn(self.EXIT_IMPORTANT_STALL)
        finally:
            self._clear_active()
            for _ in batch:self.important.task_done()

    def _sqlite_worker(self):
        try:
            con=self._open_db(); self.ready_evt.set()
        except Exception as e:
            self.init_error=str(e)[:240]; self.stats['db_init_fail']+=1; self.ready_evt.set(); self.exit_fn(self.EXIT_DB_INIT); return
        try:
            while not self.stop_evt.is_set() or not self.critical.empty() or not self.important.empty():
                critical=self._pull_critical()
                if critical:self._write_critical(con,critical); continue
                important=self._pull_important()
                if important:self._write_important(con,important); continue
                time.sleep(.01)
        finally:con.close()

    @staticmethod
    def _line(record:dict[str,Any])->bytes:
        return (json.dumps(record,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    @staticmethod
    def _write_all(fd:int,data:bytes):
        view=memoryview(data)
        while view:
            n=os.write(fd,view)
            if n<=0:raise OSError('EVENT_SHORT_WRITE')
            view=view[n:]

    def _event_worker(self):
        self.data_dir.mkdir(parents=True,exist_ok=True)
        fd=os.open(self.event_path,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o640); last_sync=time.monotonic()
        try:
            while not self.stop_evt.is_set() or not self.noncritical.empty():
                try:rec=self.noncritical.get(timeout=.2)
                except queue.Empty:
                    if time.monotonic()-last_sync>1:os.fsync(fd); last_sync=time.monotonic()
                    continue
                try:self._write_all(fd,self._line(rec)); self.stats['noncritical_written']+=1
                finally:self.noncritical.task_done()
                if time.monotonic()-last_sync>.5:os.fsync(fd); last_sync=time.monotonic()
        finally:os.fsync(fd); os.close(fd)

    def _stall_monitor(self):
        while not self.stop_evt.wait(.25):
            with self.active_lock:active=self.active_since; kind=self.active_kind
            if not active:continue
            age=time.monotonic()-active
            if kind=='critical' and age>self.hard_stall_sec:
                self.stats['wal_hard_stall_exit']+=1; self.exit_fn(self.EXIT_FORMAL_STALL); return
            if kind=='important' and age>self.event_stall_sec:
                self.stats['event_hard_stall_exit']+=1; self.exit_fn(self.EXIT_IMPORTANT_STALL); return
