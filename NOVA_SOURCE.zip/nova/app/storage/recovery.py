from __future__ import annotations
import json,sqlite3
from collections import defaultdict,deque
from pathlib import Path
from app.config import SETTINGS
from app.storage.snapshot import read_json,RUNTIME_SNAPSHOT,PRIOR_CLOSE_SNAPSHOT,DISPLAY_FALLBACK


def tail_jsonl(path:Path,max_lines:int=500,max_bytes:int=8_000_000)->list[dict]:
    """True tail: read from EOF, never scan an unbounded journal at startup."""
    if not path.exists():return []
    try:
        size=path.stat().st_size;pos=size;buf=b'';need=max_lines+1;read_bytes=0
        with path.open('rb') as f:
            while pos>0 and buf.count(b'\n')<need and read_bytes<max_bytes:
                n=min(262_144,pos,max_bytes-read_bytes);pos-=n;f.seek(pos);chunk=f.read(n);buf=chunk+buf;read_bytes+=len(chunk)
        lines=buf.splitlines()[-max_lines:];out=[]
        for line in lines:
            try:out.append(json.loads(line.decode('utf-8','ignore')))
            except Exception:continue
        return out
    except Exception:return []


def _read_sqlite_payloads(path:Path,table:str,max_rows:int)->list[dict]:
    if not path.exists():return []
    try:
        con=sqlite3.connect(f'file:{path}?mode=ro',uri=True,timeout=3)
        try:
            rows=con.execute(f'SELECT payload FROM {table} ORDER BY seq DESC LIMIT ?',(max_rows,)).fetchall();out=[]
            for (payload,) in reversed(rows):
                try:out.append(json.loads(payload))
                except Exception:continue
            return out
        finally:con.close()
    except Exception:return []


def read_committed_wal(path:Path,max_rows:int=1600)->list[dict]:
    """Compatibility reader for diagnostics only. Runtime restore uses summarize_formal_day()."""
    return _read_sqlite_payloads(path,'formal_wal',max_rows)


def read_committed_history(path:Path,max_rows:int=2000)->list[dict]:
    return _read_sqlite_payloads(path,'important_history',max_rows)


def summarize_formal_day(path:Path,day:str,tracks_per_code:int=64)->dict:
    """Stream an entire trading day's committed formal WAL into bounded recovery state.

    The cursor is consumed row-by-row, so a high-signal day never creates an unbounded list in RAM.
    Counts are exact for the whole day while only the most recent N track records per symbol are kept.
    """
    out={'codes':{},'row_count':0,'source':'sqlite'}
    if not path.exists():return out
    try:
        con=sqlite3.connect(f'file:{path}?mode=ro',uri=True,timeout=5)
        try:
            cur=con.execute("SELECT payload FROM formal_wal WHERE day=? AND event IN ('SIGNAL_CONFIRMED','BUY_CONFIRMED') ORDER BY seq ASC",(day,))
            for (payload,) in cur:
                try:r=json.loads(payload)
                except Exception:continue
                code=str(r.get('code') or '');venue=str(r.get('venue') or '')
                if not code or venue not in ('KRX','NXT'):continue
                event=str(r.get('event') or '');valid=not (event=='SIGNAL_CONFIRMED' and r.get('valid_repeat') is False)
                c=out['codes'].setdefault(code,{'name':str(r.get('name') or ''),'origin':str(r.get('origin') or 'TODAY_NEW'),'first':None,'last':None,'tracks':deque(maxlen=max(1,tracks_per_code)),'lanes':defaultdict(lambda:{'formal_raw_count':0,'valid_repeat_count':0,'buy_count_today':0,'last_formal_stage':'SEED','last_formal_at':0.0,'last_evidence_signature':'','last_buy':None})})
                lane=c['lanes'][venue]
                if event=='SIGNAL_CONFIRMED':lane['formal_raw_count']+=1
                at=float(r.get('signal_time') or r.get('created_at') or 0)
                lane['last_formal_stage']=str(r.get('stage') or lane['last_formal_stage']);lane['last_formal_at']=max(lane['last_formal_at'],at)
                if valid:
                    lane['valid_repeat_count']+=1;lane['last_evidence_signature']=str(r.get('evidence_signature') or lane['last_evidence_signature'])
                    c['first']=c['first'] or r;c['last']=r;c['tracks'].append(r)
                if event=='BUY_CONFIRMED':lane['buy_count_today']+=1;lane['last_buy']=r
                out['row_count']+=1
        finally:con.close()
        for c in out['codes'].values():c['tracks']=list(c['tracks']);c['lanes']={k:dict(v) for k,v in c['lanes'].items()}
        return out
    except Exception as e:
        out['error']=str(e)[:200];return out


def restore_seed(day:str|None=None)->dict:
    db=SETTINGS.data_dir/'signal_wal.sqlite3';d=str(day or '')
    formal=summarize_formal_day(db,d) if d else {'codes':{},'row_count':0,'source':'sqlite'}
    history=read_committed_history(db,2000)
    if not history:history=tail_jsonl(SETTINGS.data_dir/'events.jsonl',1500) # legacy fallback only
    return {'runtime':read_json(RUNTIME_SNAPSHOT,{}) or {},'prior_close':read_json(PRIOR_CLOSE_SNAPSHOT,{}) or {},'formal_summary':formal,'history':history,'display_fallback':read_json(DISPLAY_FALLBACK,{}) or {}}


def read_timeline_for_code(path:Path,code:str,max_rows:int=2000)->list[dict]:
    """Durable per-symbol timeline from both formal WAL and important lifecycle history."""
    if not path.exists():return []
    try:
        con=sqlite3.connect(f'file:{path}?mode=ro',uri=True,timeout=3)
        out=[]
        try:
            for (payload,) in con.execute('SELECT payload FROM important_history WHERE code=? ORDER BY seq DESC LIMIT ?',(code,max_rows)).fetchall():
                try:r=json.loads(payload);out.append({'at':float(r.get('at') or r.get('created_at') or 0),'kind':str(r.get('kind') or r.get('event') or ''),'state':str(r.get('state') or ''),'price':float(r.get('price') or 0),'reason':str(r.get('reason') or ''),'venue':str(r.get('venue') or 'UNKNOWN')})
                except Exception:continue
            for (payload,) in con.execute('SELECT payload FROM formal_wal WHERE code=? ORDER BY seq DESC LIMIT ?',(code,max_rows)).fetchall():
                try:
                    r=json.loads(payload);reasons=r.get('reasons') or [];reason=' · '.join(str(x) for x in reasons[:4])
                    out.append({'at':float(r.get('signal_time') or r.get('created_at') or 0),'kind':str(r.get('event') or 'SIGNAL'),'state':str(r.get('stage') or ''),'price':float(r.get('signal_price') or 0),'reason':reason,'venue':str(r.get('venue') or 'UNKNOWN'),'signal_id':str(r.get('signal_id') or '')})
                except Exception:continue
        finally:con.close()
        uniq={}
        for x in out:uniq[(round(x.get('at',0),6),x.get('kind'),x.get('state'),x.get('price'),x.get('venue'),x.get('signal_id',''))]=x
        return sorted(uniq.values(),key=lambda x:x.get('at',0))[-max_rows:]
    except Exception:return []
