from __future__ import annotations
import json,os,tempfile
from pathlib import Path
from typing import Any
from app.config import SETTINGS


def atomic_json(path:Path,payload:dict[str,Any]):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(payload,f,ensure_ascii=False,separators=(',',':'));f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
        dfd=os.open(path.parent,os.O_RDONLY);os.fsync(dfd);os.close(dfd)
    finally:
        try:
            if os.path.exists(tmp):os.unlink(tmp)
        except Exception:pass


def read_json(path:Path,default=None):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except Exception:return default

RUNTIME_SNAPSHOT=SETTINGS.data_dir/'runtime_snapshot.json'
PRIOR_CLOSE_SNAPSHOT=SETTINGS.data_dir/'prior_close_candidates.json'
DISPLAY_FALLBACK=SETTINGS.data_dir/'display_fallback.json'
