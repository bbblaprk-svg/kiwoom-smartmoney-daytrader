from __future__ import annotations
import time
from app.domain import Candidate

class Top5Registry:
    def __init__(self):self.members:dict[str,set[str]]={}
    @staticmethod
    def _quality(c:Candidate)->tuple[float,str]:
        v=c.current();m=v.metrics;q=0;why=[]
        if c.valid_repeat_count>=2:q+=2;why.append('유효반복')
        if c.entry_state in ('REACCEL','DIRECT_ARM','BUY'):q+=2;why.append('등급상승')
        if float(m.get('micro_vwap_gap') or -9)>=0:q+=1;why.append('VWAP회복')
        if float(m.get('buy_pressure') or 0)>=60:q+=1;why.append('공격매수회복')
        if float(m.get('volume_accel') or 1)>=1.5:q+=1;why.append('거래가속')
        if bool(m.get('smart_money_realtime_proxy_surge')):q+=2;why.append('SMART_MONEY_SURGE')
        return q,' + '.join(why[:4]) or '순위 재진입'
    def apply(self,board:str,rows:list[Candidate],all_candidates:dict[str,Candidate]):
        now=time.time();new={c.code for c in rows[:5]};old=self.members.get(board,set())
        for c in rows[:5]:
            if c.code not in old:
                if c.top5_enter_count:
                    c.top5_reentry_count+=1;q,reason=self._quality(c);c.reentry_quality=q;c.append_history('TOP5','TOP5_REENTER',c.current().last_price,f'{board} · {reason}',c.current().venue,now)
                else:c.append_history('TOP5','TOP5_ENTER',c.current().last_price,board,c.current().venue,now)
                c.top5_enter_count+=1;c.last_top5_enter_at=now;c.refresh_aggregate()
        for code in old-new:
            c=all_candidates.get(code)
            if c:c.last_top5_exit_at=now;c.append_history('TOP5','TOP5_EXIT',c.current().last_price,board,c.current().venue,now)
        self.members[board]=new
