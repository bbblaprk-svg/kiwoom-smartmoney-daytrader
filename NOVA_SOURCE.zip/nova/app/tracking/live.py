from __future__ import annotations
from app.domain import Candidate,Venue,SignalTrack

class LiveTracker:
    """Venue-locked signal performance. KRX and NXT are never mixed."""
    def add_signal(self,c:Candidate,signal_id:str,venue:Venue,price:float,at:float):
        c.signal_tracks.append(SignalTrack(signal_id,venue,price,at,price,price,price,at))
        c.signal_high=price;c.signal_low=price

    def on_tick(self,c:Candidate,venue:Venue):
        v=c.venue_state[venue];p=v.last_price
        if p<=0:return
        # Recent formal signals remain independently trackable; bounded at 64 per candidate.
        for t in c.signal_tracks:
            if t.venue==venue:
                t.current=p;t.high=max(t.high,p);t.low=min(t.low,p);t.last_tick_at=v.last_tick_at
        if c.last_signal and c.last_signal.venue==venue:
            c.signal_high=max(c.signal_high or p,p);c.signal_low=min(c.signal_low or p,p)
        if c.last_buy_price and c.last_buy_venue==venue:
            c.buy_high=max(c.buy_high or p,p);c.buy_low=min(c.buy_low or p,p)

    def signal_outcome(self,c:Candidate)->dict:
        if not c.last_signal:return {}
        for t in reversed(c.signal_tracks):
            if t.signal_id==c.last_signal.signal_id:return t.public()
        v=c.venue_state[c.last_signal.venue];p=v.last_price;sig=c.last_signal
        ret=(p/sig.signal_price-1)*100 if p and sig.signal_price else None
        return {'signal_id':sig.signal_id,'venue':sig.venue.value,'current_return':round(ret,2) if ret is not None else None,'current_price':p,'last_tick_at':v.last_tick_at}
