from __future__ import annotations
import asyncio,time,threading
from app.domain import Candidate,Venue,Origin
from app.runtime.state import RuntimeState
from app.runtime.projection import LiveDisplayProjection
from app.runtime.clock import lifecycle_phase,sec_of_day,sessions
from app.tracking.top5 import Top5Registry
from app.tracking.live import LiveTracker
from app.config import SETTINGS

class DisplayState:
    """Single-writer display snapshot with self-healing read-through freshness.

    The trading engine is authoritative.  The browser must never depend on one
    background display task staying alive forever, so API/WS readers can rebuild
    a stale snapshot from current in-memory engine state without mutating signal
    policy or candidate state.
    """
    def __init__(self,state:RuntimeState,tracker:LiveTracker):
        self.state=state;self.tracker=tracker;self.lock=threading.Lock();self.build_lock=threading.Lock()
        self.snapshot={'type':'snapshot','version':SETTINGS.version,'generation':0,'generated_at':time.time(),'feed_state':'STARTING','phase':'PRIOR_CLOSE_FROZEN','feed':{},'load_mode':'NORMAL','telemetry':{},'boards':{'prebuy':[],'opening':[],'live_buy':[],'nxt_early':[],'nxt_management':[],'position_manager':[]},'signal_history':[],'candidate_count':0,'hot_count':0,'pinned_count':0,'delivery':{'bridge':'LIVE_BRIDGE_V1','source':'INITIAL'}}
        self.fallback={};self.generation=0;self.top5=Top5Registry();self.last_build_error='';self.last_build_error_at=0.0;self.last_build_ok_at=0.0
        self.stable_codes:dict[str,list[str]]={};self.last_rank_at:dict[str,float]={};self.last_emitted_tick:dict[tuple[str,Venue],float]={};self.projection=LiveDisplayProjection(SETTINGS.display_fresh_ms)
    def get(self):
        with self.lock:return self.snapshot
    def get_fresh(self,max_age_sec:float|None=None):
        max_age=max_age_sec if max_age_sec is not None else max(1.0,SETTINGS.ui_delta_ms/1000*6)
        with self.lock:
            snap=self.snapshot;age=max(0.0,time.time()-float(snap.get('generated_at') or 0))
        if age>max_age:
            self.build(source='READ_THROUGH',blocking=False)
            with self.lock:snap=self.snapshot
        return snap
    def set_fallback(self,snap:dict):
        with self.lock:self.fallback=snap if isinstance(snap,dict) else {}
    def history(self,code:str):
        c=self.state.candidates.get(code)
        if not c:return []
        with self.state.code_lock(code):
            events=[{'at':x.at,'kind':x.kind,'state':x.state,'price':x.price,'reason':x.reason,'venue':x.venue.value} for x in list(c.history)]
            tracks=[{'at':t.signal_time,'kind':'OUTCOME','state':'SIGNAL_TRACK','price':t.signal_price,'reason':str(t.public()),'venue':t.venue.value} for t in list(c.signal_tracks)]
        return sorted(events+tracks,key=lambda x:x['at'])
    @staticmethod
    def _sort(rows:list[Candidate],key):return sorted(rows,key=key,reverse=True)
    @staticmethod
    def _row_quality(row:dict)->int:
        if not isinstance(row,dict):return 0
        q=0
        if row.get('price') not in (None,0,'') or row.get('reference_price') not in (None,0,''):q+=4
        if row.get('change_rate') is not None:q+=2
        if float(row.get('score') or 0)>0:q+=2
        if float(row.get('priority_score') or 0)>0:q+=1
        if int(row.get('valid_repeat_count') or 0)>0:q+=1
        return q
    @classmethod
    def _merge_frozen_board(cls,current:list[dict],fallback:list[dict])->list[dict]:
        cur=[dict(x) for x in (current or []) if isinstance(x,dict)];fb=[dict(x) for x in (fallback or []) if isinstance(x,dict)]
        by_cur={str(x.get('code') or ''):x for x in cur if x.get('code')};used=set();out=[]
        # Preserve the last committed board order whenever it contains usable truth, but never
        # prefer a degraded/blank fallback row over a richer runtime-restored row.
        for old in fb[:5]:
            code=str(old.get('code') or '');now=by_cur.get(code)
            pick=old if cls._row_quality(old)>=cls._row_quality(now or {}) else now
            if pick is not None:out.append(dict(pick));used.add(code)
        for row in cur:
            code=str(row.get('code') or '')
            if code and code in used:continue
            out.append(dict(row));used.add(code)
            if len(out)>=5:break
        return out[:5]
    @classmethod
    def snapshot_has_truth(cls,snap:dict)->bool:
        boards=(snap.get('boards') or {}) if isinstance(snap,dict) else {}
        return any(cls._row_quality(r)>=4 for rows in boards.values() for r in (rows or []) if isinstance(r,dict))
    @staticmethod
    def delta(prev:dict,cur:dict)->dict:
        patch={};keys=('feed_state','phase','feed','load_mode','telemetry','candidate_count','hot_count','pinned_count','signal_history','delivery')
        for k in keys:
            if prev.get(k)!=cur.get(k):patch[k]=cur.get(k)
        bp={};pb=prev.get('boards') or {};cb=cur.get('boards') or {}
        for k,v in cb.items():
            if pb.get(k)!=v:bp[k]=v
        if bp:patch['boards']=bp
        return {'type':'delta','version':cur.get('version'),'base_generation':prev.get('generation',0),'generation':cur.get('generation',0),'generated_at':cur.get('generated_at'),'patch':patch}
    def _stabilize(self,board:str,ranked:list[Candidate],now:float,immediate_codes:set[str]|None=None)->list[Candidate]:
        immediate_codes=immediate_codes or set();old=self.stable_codes.get(board,[]);by={c.code:c for c in ranked};raw=[c.code for c in ranked]
        force=bool(immediate_codes-set(old))
        if old and now-self.last_rank_at.get(board,0)<1.0 and not force:
            out=[by[x] for x in old if x in by]
            seen={x.code for x in out}
            for c in ranked:
                if c.code not in seen:out.append(c);seen.add(c.code)
                if len(out)>=5:break
            return out[:5]
        desired=ranked[:5]
        if old and not force:
            desired_codes=[c.code for c in desired]
            for code in old:
                if code in desired_codes or code not in by or code not in raw:continue
                idx=raw.index(code)
                if idx<=5 and desired:
                    weakest=min(desired,key=lambda c:c.priority_score)
                    if by[code].priority_score+1.5>=weakest.priority_score:
                        desired=[c for c in desired if c.code!=weakest.code]+[by[code]];desired=self._sort(desired,lambda c:(c.priority_score,c.score,c.valid_repeat_count))[:5];desired_codes=[c.code for c in desired]
        self.stable_codes[board]=[c.code for c in desired];self.last_rank_at[board]=now;return desired
    def _observe_ui_latency(self,rows:list[Candidate],venue_override:Venue|None=None):
        now=time.time()
        for c in rows:
            v=c.venue_state[venue_override] if venue_override in (Venue.KRX,Venue.NXT) else c.current();k=(c.code,v.venue)
            if v.last_tick_at and v.last_tick_at>self.last_emitted_tick.get(k,0):
                self.state.observe_latency('tick_to_ui_ms',max(0,(now-v.last_tick_at)*1000));self.last_emitted_tick[k]=v.last_tick_at
    def build(self,source:str='BACKGROUND',blocking:bool=True):
        acquired=self.build_lock.acquire(blocking=blocking)
        if not acquired:return False
        try:
            now=time.time();phase=lifecycle_phase();sess=sessions();active=bool(sess['active'])
            with self.state.lock:cands=list(self.state.candidates.values());hot_count=len(self.state.hot_codes);pinned_count=len(self.state.pinned_codes)
            fresh=[c for c in cands if self.projection.has_live(c,now)]
            pre_source=fresh if active else [c for c in cands if c.current().last_price>0 or c.live_track_pin or c.last_signal]
            pre_rank=self._sort(pre_source,lambda c:(1 if c.entry_state in ('REACCEL','DIRECT_ARM','BUY') else 0,c.priority_score,c.score,c.valid_repeat_count,c.current().last_rate,c.last_signal.signal_time if c.last_signal else 0))[:10]
            if phase in ('PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK'):
                opening_pool=[c for c in cands if c.origin==Origin.PRIOR_CLOSE or c.lifecycle_state in ('CLOSE_TRACK','PRIOR_CLOSE_FROZEN','PREMARKET_RECHECK')]
            elif phase in ('OPENING_HANDOFF','SHAKEOUT_WATCH','REVERSAL_WINDOW'):
                opening_pool=[c for c in cands if c.lifecycle_state in ('OPENING_HANDOFF','OPENING_ACTIVE','SHAKEOUT_WATCH','REVERSAL_EARLY','BUY_READY','BUY')]
            elif phase=='CLOSE_TRACK':opening_pool=[c for c in cands if c.lifecycle_state=='CLOSE_TRACK']
            else:opening_pool=[c for c in cands if c.lifecycle_state in ('REVERSAL_EARLY','BUY_READY','BUY') and c.origin==Origin.PRIOR_CLOSE]
            opening_rank=self._sort(opening_pool,lambda c:(1 if c.lifecycle_state in ('BUY','BUY_READY') else 0,1 if c.lifecycle_state=='REVERSAL_EARLY' else 0,c.priority_score or c.close_score,c.valid_repeat_count))[:10]
            live_rank=self._sort([c for c in cands if c.entry_state=='BUY' or c.lifecycle_state in ('BUY_READY','REVERSAL_EARLY')],lambda c:(1 if c.entry_state=='BUY' else 0,c.last_buy_at,c.priority_score,c.valid_repeat_count))[:10]
            nxt_pool=[c for c in cands if (c.venue_state[Venue.NXT].last_tick_at and now-c.venue_state[Venue.NXT].last_tick_at<=SETTINGS.display_fresh_ms/1000+1)] if active else [c for c in cands if c.venue_state[Venue.NXT].last_price>0 or (c.last_signal and c.last_signal.venue==Venue.NXT)]
            nxt_rank=self._sort(nxt_pool,lambda c:(float(c.venue_state[Venue.NXT].metrics.get('smart_money_realtime_proxy_score') or 0),c.venue_state[Venue.NXT].score,c.valid_repeat_count,c.venue_state[Venue.NXT].last_rate,c.last_signal.signal_time if c.last_signal else 0))[:10]
            nxt_mgmt_rank=self._sort([c for c in cands if c.live_track_pin and c.last_signal and c.last_signal.venue==Venue.NXT],lambda c:(1 if c.last_buy_venue==Venue.NXT else 0,c.valid_repeat_count,c.priority_score,c.last_signal.signal_time if c.last_signal else 0))[:10]
            pre=self._stabilize('prebuy',pre_rank,now,{c.code for c in pre_rank if c.entry_state=='BUY'});opening=self._stabilize('opening',opening_rank,now,{c.code for c in opening_rank if c.lifecycle_state in ('BUY_READY','BUY')});live_buy=self._stabilize('live_buy',live_rank,now,{c.code for c in live_rank if c.entry_state=='BUY'});nxt=self._stabilize('nxt_early',nxt_rank,now,{c.code for c in nxt_rank if c.last_buy_venue==Venue.NXT});nxt_mgmt=self._stabilize('nxt_management',nxt_mgmt_rank,now)
            buys=[c for c in cands if c.last_buy_price and c.last_buy_venue in (Venue.KRX,Venue.NXT)];by={c.code:c for c in buys};old_pos=self.stable_codes.get('position_manager',[]);pos=[by[x] for x in old_pos if x in by]
            pos_codes={x.code for x in pos}
            for c in sorted(buys,key=lambda x:x.last_buy_at):
                if c.code not in pos_codes:pos.append(c);pos_codes.add(c.code)
            pos=pos[:5];self.stable_codes['position_manager']=[c.code for c in pos]
            for name,rows in {'prebuy':pre,'opening':opening,'live_buy':live_buy,'nxt_early':nxt,'nxt_management':nxt_mgmt}.items():self.top5.apply(name,rows,self.state.candidates)
            boards={'prebuy':[self.projection.row(c,now,allow_frozen=not active) for c in pre],'opening':[self.projection.row(c,now,Venue.NXT if c.origin==Origin.PRIOR_CLOSE else Venue.UNKNOWN,False,not active) for c in opening],'live_buy':[self.projection.row(c,now,c.last_buy_venue if c.last_buy_venue in (Venue.KRX,Venue.NXT) else Venue.UNKNOWN,False,not active) for c in live_buy],'nxt_early':[self.projection.row(c,now,Venue.NXT,True,not active) for c in nxt],'nxt_management':[self.projection.row(c,now,Venue.NXT,True,not active) for c in nxt_mgmt],'position_manager':[self.projection.row(c,now,c.last_buy_venue,True,not active) for c in pos]}
            projection_rows=[row for rows in boards.values() for row in rows];self.state.telemetry['display_projection_fallback_rows']=sum(1 for row in projection_rows if row.get('display_venue_fallback'));self.state.telemetry['display_projection_stale_rows']=sum(1 for row in projection_rows if row.get('display_stale'))
            for row,c in zip(boards['opening'],opening):
                if not row.get('price') and c.close_signal_price:row['reference_price']=c.close_signal_price;row['reference_price_type']='PRIOR_CLOSE'
            # Outside all continuous venues the dashboard becomes a frozen session-close view.
            # Merge the last committed board with runtime-restored candidate truth, choosing the
            # richer row per symbol.  Frozen values are explicitly labelled and never qualify signals.
            if not active:
                with self.lock:fb=dict(self.fallback)
                fb_boards=(fb.get('boards') or {}) if isinstance(fb,dict) else {}
                for k in boards:boards[k]=self._merge_frozen_board(boards[k],fb_boards.get(k) or [])
            self._observe_ui_latency(pre);self._observe_ui_latency(live_buy);self._observe_ui_latency(nxt,Venue.NXT)
            history=[]
            for c in cands:
                for e in list(c.history)[-4:]:history.append({'code':c.code,'name':c.name or c.code,'at':e.at,'state':e.state,'kind':e.kind,'price':e.price,'venue':e.venue.value,'reason':e.reason})
            history.sort(key=lambda x:x['at'],reverse=True)
            delivery={'bridge':'LIVE_BRIDGE_V1','source':source,'display_task_alive':True,'market_active':active,'display_mode':'LIVE' if active else 'SESSION_CLOSE_FROZEN','last_build_error':self.last_build_error,'last_build_error_at':self.last_build_error_at}
            snap={'type':'snapshot','version':SETTINGS.version,'generated_at':now,'feed_state':self.state.feed_state.value,'generation':self.generation+1,'phase':phase,'feed':dict(self.state.ws_status),'load_mode':self.state.load_mode,'telemetry':dict(self.state.telemetry),'boards':boards,'signal_history':history[:30],'candidate_count':len(cands),'hot_count':hot_count,'pinned_count':pinned_count,'delivery':delivery}
            with self.lock:
                self.generation+=1;self.snapshot=snap
                # Keep the exact latest live board in memory so the 20:00 close transition freezes
                # the immediately preceding display rather than the fallback loaded at process start.
                if active and self.snapshot_has_truth(snap):self.fallback=snap
            self.last_build_ok_at=now;self.last_build_error='';return True
        except Exception as e:
            self.last_build_error=f'{type(e).__name__}: {e}'[:240];self.last_build_error_at=time.time();self.state.telemetry['display_build_error_count']=int(self.state.telemetry.get('display_build_error_count') or 0)+1;self.state.ws_status['display_error']=self.last_build_error;return False
        finally:self.build_lock.release()
    async def run(self):
        while True:
            self.build(source='BACKGROUND',blocking=False)
            await asyncio.sleep(max(.1,SETTINGS.ui_delta_ms/1000))
