from __future__ import annotations
import threading,time
from collections import defaultdict,deque
from app.domain import Candidate, Venue, FeedState, Origin
from app.runtime.window import FixedMicroWindow

class RuntimeState:
    def __init__(self):
        self.lock=threading.RLock();self.code_locks:dict[str,threading.RLock]={}
        self.candidates:dict[str,Candidate]={};self.windows:dict[tuple[str,Venue],FixedMicroWindow]={}
        self.feed_state=FeedState.STARTING
        self.ws_status={'connected':False,'logged_in':False,'last_message_at':0.0,'last_trade_at':0.0,'last_error':'','reconnects':0,'registered':0,'registered_groups':0,'gap_count':0,'resync_count':0,'subscription_reject_count':0}
        self.telemetry=defaultdict(float)
        self.telemetry.update({
            'dropped_signal_tick_count':0,'dropped_candidate_tick_count':0,'signal_price_mismatch_count':0,
            'wrong_venue_price_count':0,'stale_signal_count':0,'signal_without_live_snapshot_count':0,
            'duplicate_tick_reject_count':0,'out_of_order_tick_count':0,'stale_tick_reject_count':0,'cumulative_rollback_count':0,
            'journal_fail_closed_count':0,'wal_duplicate_commit_count':0,'unrecovered_data_gap_count':0,'ws_messages_per_sec':0,
            'ws_receive_latency_ms':0,'receiver_queue_depth':0,'receiver_queue_oldest_age_ms':0,
            'signal_queue_depth':0,'signal_queue_oldest_age_ms':0,'ui_queue_depth':0,'ui_clients':0,
            'dispatch_handler_error_count':0,'tracking_capacity_block_count':0,'pinned_ws_overflow':0,
            'display_projection_fallback_rows':0,'display_projection_stale_rows':0,
        })
        self.hot_codes:set[str]=set();self.pinned_codes:set[str]=set();self.followup_codes:set[str]=set();self.tracking_reservations:dict[str,int]={}
        self.dirty_keys:set[tuple[str,Venue]]=set();self.dirty_since:dict[tuple[str,Venue],float]={}
        self.generated_at=0.0;self.last_score_at=0.0;self.started_at=time.time();self.restore_done=False;self.warming_until=0.0
        self.ui_clients=0;self.load_mode='NORMAL';self.history_sink=None
        self.latencies:dict[str,deque[float]]=defaultdict(lambda:deque(maxlen=1200))

    def code_lock(self,code:str):
        with self.lock:
            lk=self.code_locks.get(code)
            if lk is None:lk=threading.RLock();self.code_locks[code]=lk
            return lk

    def candidate(self,code:str,name:str='',origin:Origin=Origin.TODAY_NEW,trade_day:str='')->Candidate:
        with self.lock:
            c=self.candidates.get(code)
            if c is None:
                c=Candidate(code=code,name=name,origin=origin,trade_day=trade_day,state_changed_at=time.time(),history_sink=self.history_sink)
                self.candidates[code]=c
            elif name and not c.name:c.name=name
            if trade_day and not c.trade_day:c.trade_day=trade_day
            if c.history_sink is None and self.history_sink is not None:c.history_sink=self.history_sink
            c.last_seen_at=time.time();return c

    def reserve_tracking_slot(self,code:str,budget:int)->tuple[bool,bool]:
        """Atomically reserve one unique real-time tracking slot for an unpinned code.

        The second return value says whether this caller owns a reservation reference that must be
        released. Concurrent KRX/NXT scoring for the same code shares one unique slot while keeping
        a reference count so one task cannot prematurely free another task's in-flight reservation.
        """
        with self.lock:
            if code in self.pinned_codes:return True,False
            n=int(self.tracking_reservations.get(code) or 0)
            if n:
                self.tracking_reservations[code]=n+1;return True,True
            unique=set(self.pinned_codes)|set(self.tracking_reservations)
            if len(unique)>=budget:return False,False
            self.tracking_reservations[code]=1;return True,True

    def release_tracking_slot(self,code:str):
        with self.lock:
            n=int(self.tracking_reservations.get(code) or 0)
            if n<=1:self.tracking_reservations.pop(code,None)
            else:self.tracking_reservations[code]=n-1

    def window(self,code:str,venue:Venue)->FixedMicroWindow:
        with self.lock:
            k=(code,venue);w=self.windows.get(k)
            if w is None:w=FixedMicroWindow();self.windows[k]=w
            return w

    def mark_dirty(self,code:str,venue:Venue):
        if venue not in (Venue.KRX,Venue.NXT):return
        now=time.monotonic();k=(code,venue)
        with self.lock:
            self.dirty_keys.add(k);self.dirty_since.setdefault(k,now)

    def pop_dirty(self,limit:int=128)->list[tuple[str,Venue,float]]:
        now=time.monotonic();out=[]
        with self.lock:
            while self.dirty_keys and len(out)<limit:
                k=self.dirty_keys.pop();since=self.dirty_since.pop(k,now);out.append((k[0],k[1],max(0,(now-since)*1000)))
            self.telemetry['signal_queue_depth']=len(self.dirty_keys)
            if self.dirty_since:self.telemetry['signal_queue_oldest_age_ms']=max(0,(now-min(self.dirty_since.values()))*1000)
            else:self.telemetry['signal_queue_oldest_age_ms']=0
        return out

    def observe_latency(self,name:str,value_ms:float):
        if value_ms<0:return
        with self.lock:self.latencies[name].append(float(value_ms))

    def latency_percentiles(self,name:str)->dict[str,float]:
        with self.lock:xs=sorted(self.latencies.get(name,()))
        if not xs:return {'p50':0.0,'p95':0.0,'p99':0.0}
        def q(p):return round(xs[int(p*(len(xs)-1))],2)
        return {'p50':q(.50),'p95':q(.95),'p99':q(.99)}

    def mark_resync(self,codes:set[str]|list[str],reason:str='WS_RESYNC'):
        now=time.time();count=0
        for code in list(codes):
            c=self.candidates.get(code)
            if not c:continue
            with self.code_lock(code):
                for venue,v in c.venue_state.items():
                    v.continuity_gap_until=float('inf');v.continuity_reason=reason;v.recovery_count=0;v.recovery_started_at=0.0
                    # Never let a pre-gap score/stage rank as if it were current truth. Durable BUY
                    # identity is preserved in its entry lane; non-BUY entry pressure must re-earn.
                    v.score=0.0;v.confidence=0.0;v.stage='SEED';v.reasons=['실시간 재동기화 필요'];v.metrics['fresh']=False;v.metrics['continuity_ok']=False
                    if v.entry.state not in ('BUY','COOLDOWN'):
                        v.entry.state='DISCOVERY';v.entry.pressure_started_at=0.0;v.entry.pressure_peak=0.0;v.entry.pullback_low=0.0;v.entry.reaccel_started_at=0.0;v.entry.direct_started_at=0.0
                    self.windows.pop((code,venue),None);self.mark_dirty(code,venue)
                c.metrics['rt_continuity_ok']=False;c.refresh_aggregate();count+=1
        self.ws_status['gap_count']=int(self.ws_status.get('gap_count') or 0)+1
        self.ws_status['resync_count']=int(self.ws_status.get('resync_count') or 0)+1
        self.telemetry['unrecovered_data_gap_count']=count

    def prune(self,max_candidates:int,window_idle_sec:float=600.0)->dict:
        now=time.time()
        with self.lock:
            protected={code for code,c in self.candidates.items() if c.live_track_pin or c.origin==Origin.PRIOR_CLOSE or c.entry_state=='BUY'} | set(self.pinned_codes) | set(self.followup_codes)
            if len(self.candidates)>max_candidates:
                removable=[c for c in self.candidates.values() if c.code not in protected]
                removable.sort(key=lambda c:(c.last_seen_at,max(c.source_hits.values(),default=0.0),c.priority_score,c.rest_base),reverse=True)
                keep={c.code for c in removable[:max(0,max_candidates-len(protected))]}|protected
                removed=[code for code in list(self.candidates) if code not in keep]
                for code in removed:
                    self.candidates.pop(code,None);self.code_locks.pop(code,None);self.hot_codes.discard(code)
                    for k in [k for k in self.dirty_keys if k[0]==code]:self.dirty_keys.discard(k);self.dirty_since.pop(k,None)
                    for k in [k for k in self.windows if k[0]==code]:self.windows.pop(k,None)
            else:removed=[]
            active=set(self.hot_codes)|protected
            for k,w in list(self.windows.items()):
                if k[0] not in active and w.last_ts and now-w.last_ts>window_idle_sec:self.windows.pop(k,None)
            return {'removed_candidates':len(removed),'candidates':len(self.candidates),'windows':len(self.windows)}

STATE=RuntimeState()
