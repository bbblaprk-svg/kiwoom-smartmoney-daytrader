from __future__ import annotations
import hashlib, time
from collections import deque, defaultdict
from dataclasses import dataclass
from app.domain import TradeTick, Venue

@dataclass(slots=True)
class IntegrityResult:
    accepted: bool
    reason: str=''
    duplicate: bool=False
    out_of_order: bool=False
    cum_rollback: bool=False

class TickIntegrity:
    """Per trade-day + venue + code truth guard. No cross-venue state is shared."""
    def __init__(self):
        self.last:dict[tuple[str,Venue,str],TradeTick]={}
        self.fingerprints:dict[tuple[str,Venue,str],deque[str]]=defaultdict(lambda:deque(maxlen=64))
        self.stats=defaultdict(int)

    @staticmethod
    def fingerprint(raw_item:str, exchange_time:str, price:float, qty:float, cum_volume:float)->str:
        raw=f'{raw_item}|{exchange_time}|{price:.8f}|{qty:.8f}|{cum_volume:.8f}'.encode()
        return hashlib.blake2s(raw,digest_size=10).hexdigest()


    def reset_for_day(self, day:str):
        """Drop prior-day integrity state so a long-lived process cannot grow by trading day."""
        self.last={k:v for k,v in self.last.items() if k[0]==day}
        self.fingerprints=defaultdict(lambda:deque(maxlen=64),{k:v for k,v in self.fingerprints.items() if k[0]==day})

    def prune_codes(self, day:str, keep:set[str]):
        self.last={k:v for k,v in self.last.items() if k[0]==day and k[2] in keep}
        self.fingerprints=defaultdict(lambda:deque(maxlen=64),{k:v for k,v in self.fingerprints.items() if k[0]==day and k[2] in keep})

    def validate(self, day:str, tick:TradeTick)->IntegrityResult:
        if tick.venue not in (Venue.KRX,Venue.NXT) or tick.price<=0:
            self.stats['invalid']+=1;return IntegrityResult(False,'VENUE_OR_PRICE_INVALID')
        k=(day,tick.venue,tick.code); fps=self.fingerprints[k]
        if tick.fingerprint and tick.fingerprint in fps:
            self.stats['duplicate']+=1;return IntegrityResult(False,'DUPLICATE',duplicate=True)
        prev=self.last.get(k)
        # Provider HHMMSS may repeat. Reject only a clear backwards move while cumulative volume does not advance.
        if prev and tick.exchange_time and prev.exchange_time and tick.exchange_time < prev.exchange_time and tick.cum_volume<=prev.cum_volume:
            self.stats['out_of_order']+=1;return IntegrityResult(False,'OUT_OF_ORDER',out_of_order=True)
        if prev and tick.cum_volume>0 and prev.cum_volume>0 and tick.cum_volume < prev.cum_volume*0.98:
            self.stats['cum_rollback']+=1;return IntegrityResult(False,'CUMULATIVE_ROLLBACK',cum_rollback=True)
        if tick.fingerprint:fps.append(tick.fingerprint)
        self.last[k]=tick;self.stats['accepted']+=1;return IntegrityResult(True)
