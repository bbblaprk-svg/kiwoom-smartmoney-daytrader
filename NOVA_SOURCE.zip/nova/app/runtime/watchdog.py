from __future__ import annotations
import os,threading,time
from app.config import SETTINGS

class HardStallWatchdog:
    """Independent OS thread. It survives an asyncio event-loop deadlock."""
    def __init__(self,stall_sec:float|None=None,grace_sec:float|None=None,exit_code:int=78):
        self.stall_sec=stall_sec or SETTINGS.hard_stall_sec;self.grace_sec=grace_sec or SETTINGS.hard_stall_grace_sec;self.exit_code=exit_code
        self.last_beat=time.monotonic();self.started=time.monotonic();self.stop_evt=threading.Event();self.thread=None
    def beat(self):self.last_beat=time.monotonic()
    def start(self):
        def run():
            while not self.stop_evt.wait(1.0):
                now=time.monotonic()
                if now-self.started<self.grace_sec:continue
                if now-self.last_beat>self.stall_sec:os._exit(self.exit_code)
        self.thread=threading.Thread(target=run,name='nova-hard-stall-watchdog',daemon=True);self.thread.start()
    def stop(self):self.stop_evt.set()
