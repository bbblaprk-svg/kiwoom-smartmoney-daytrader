from __future__ import annotations
from app.config import SETTINGS

def load_mode(cpu_pct:float,rss_mb:float,queue_age_ms:float,queue_depth:int)->str:
    cap=SETTINGS.trade_queue_per_shard*SETTINGS.trade_shards
    if rss_mb>=SETTINGS.rss_hard_mb or cpu_pct>=90 or queue_age_ms>500 or queue_depth>cap*.8:return 'CRITICAL'
    if rss_mb>=SETTINGS.rss_soft_mb or cpu_pct>=80 or queue_age_ms>250 or queue_depth>cap*.55:return 'HIGH_LOAD'
    if cpu_pct>=70 or queue_age_ms>100 or queue_depth>cap*.30:return 'BUSY'
    return 'NORMAL'

def hot_capacity(mode:str)->int:
    return {'NORMAL':min(SETTINGS.hot_max,max(SETTINGS.hot_min,SETTINGS.hot_target)),'BUSY':40,'HIGH_LOAD':30,'CRITICAL':SETTINGS.hot_min}.get(mode,SETTINGS.hot_target)
