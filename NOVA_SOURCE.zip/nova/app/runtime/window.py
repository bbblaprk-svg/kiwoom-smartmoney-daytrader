from __future__ import annotations
from dataclasses import dataclass
from collections import deque
import math

@dataclass(slots=True)
class Bucket:
    start: float
    open: float=0.0
    high: float=0.0
    low: float=0.0
    close: float=0.0
    abs_qty: float=0.0
    signed_qty: float=0.0
    pv: float=0.0
    count: int=0
    pos_count: int=0
    neg_count: int=0
    max_abs_qty: float=0.0
    max_tick_notional: float=0.0
    smart50_buy_count: int=0
    smart70_buy_count: int=0
    smart100_buy_count: int=0
    smart200_buy_count: int=0
    smart50_sell_count: int=0
    smart50_buy_value: float=0.0
    smart50_sell_value: float=0.0

    def add(self, price:float, qty:float):
        a=abs(qty); n=price*a
        if not self.count:self.open=self.high=self.low=price
        self.high=max(self.high,price);self.low=min(self.low,price);self.close=price
        self.abs_qty+=a;self.signed_qty+=qty;self.pv+=price*a;self.count+=1
        self.pos_count += 1 if qty>0 else 0; self.neg_count += 1 if qty<0 else 0
        self.max_abs_qty=max(self.max_abs_qty,a); self.max_tick_notional=max(self.max_tick_notional,n)
        if qty>0:
            if n>=50_000_000:self.smart50_buy_count+=1;self.smart50_buy_value+=n
            if n>=70_000_000:self.smart70_buy_count+=1
            if n>=100_000_000:self.smart100_buy_count+=1
            if n>=200_000_000:self.smart200_buy_count+=1
        elif qty<0 and n>=50_000_000:
            self.smart50_sell_count+=1;self.smart50_sell_value+=n

class FixedMicroWindow:
    """Every tick is consumed, but memory is rate-independent.

    100ms buckets retain the last 60 seconds; 1s buckets retain 330 seconds.
    No raw-tick list grows with trade frequency. Per-tick max/count/value fields preserve
    one-tick concentration and smart-money tier counts used by the signal policy.
    """
    __slots__=('micro','seconds','last_price','last_ts')
    def __init__(self):
        self.micro:deque[Bucket]=deque(maxlen=620)
        self.seconds:deque[Bucket]=deque(maxlen=335)
        self.last_price=0.0;self.last_ts=0.0

    @staticmethod
    def _key(ts:float, span:float)->float: return math.floor(ts/span)*span

    def _add_to(self, q:deque[Bucket], start:float, price:float, qty:float):
        if not q or q[-1].start!=start:q.append(Bucket(start=start))
        q[-1].add(price,qty)

    def add(self, ts:float, price:float, qty:float):
        self._add_to(self.micro,self._key(ts,0.1),price,qty)
        self._add_to(self.seconds,self._key(ts,1.0),price,qty)
        self.last_price=price;self.last_ts=ts

    def _rows(self, now:float, seconds:float, micro:bool=False, older_than:float=0.0):
        q=self.micro if micro else self.seconds
        lo=now-seconds;hi=now-older_than if older_than else now+1
        return [b for b in q if lo<=b.start<=hi]

    def aggregate(self, now:float, seconds:float, older_than:float=0.0, micro:bool=False)->dict:
        rows=self._rows(now,seconds,micro,older_than)
        if not rows:return {'bucket_count':0,'span_sec':0.0,'count':0,'abs_qty':0.0,'signed_qty':0.0,'pv':0.0,'high':0.0,'low':0.0,'open':0.0,'close':0.0,'pos_count':0,'neg_count':0,'max_abs_qty':0.0,'max_tick_notional':0.0,'smart50_buy_count':0,'smart70_buy_count':0,'smart100_buy_count':0,'smart200_buy_count':0,'smart50_sell_count':0,'smart50_buy_value':0.0,'smart50_sell_value':0.0}
        return {
            'bucket_count':len(rows),'span_sec':max(0.0,rows[-1].start-rows[0].start) if len(rows)>1 else 0.0,
            'count':sum(x.count for x in rows),'abs_qty':sum(x.abs_qty for x in rows),'signed_qty':sum(x.signed_qty for x in rows),'pv':sum(x.pv for x in rows),
            'high':max(x.high for x in rows if x.count),'low':min(x.low for x in rows if x.count),'open':next(x.open for x in rows if x.count),'close':next(x.close for x in reversed(rows) if x.count),
            'pos_count':sum(x.pos_count for x in rows),'neg_count':sum(x.neg_count for x in rows),'max_abs_qty':max(x.max_abs_qty for x in rows),
            'max_tick_notional':max(x.max_tick_notional for x in rows),'smart50_buy_count':sum(x.smart50_buy_count for x in rows),'smart70_buy_count':sum(x.smart70_buy_count for x in rows),
            'smart100_buy_count':sum(x.smart100_buy_count for x in rows),'smart200_buy_count':sum(x.smart200_buy_count for x in rows),'smart50_sell_count':sum(x.smart50_sell_count for x in rows),
            'smart50_buy_value':sum(x.smart50_buy_value for x in rows),'smart50_sell_value':sum(x.smart50_sell_value for x in rows),
        }

    def old_high(self, now:float, seconds:float=300.0, newest_fraction:float=.2)->float:
        rows=self._rows(now,seconds,False,seconds*newest_fraction)
        return max((x.high for x in rows if x.count),default=0.0)

    def memory_slots(self)->int:return len(self.micro)+len(self.seconds)
