from __future__ import annotations

def clamp(x,a,b):return max(a,min(b,x))

def fast_proxy(recent30:dict,prev30:dict,full60:dict,buy_pressure:float,vwap_gap:float)->dict:
    early=int(full60.get('smart50_buy_count') or 0);strong=int(full60.get('smart70_buy_count') or 0);large=int(full60.get('smart100_buy_count') or 0);very=int(full60.get('smart200_buy_count') or 0);sells=int(full60.get('smart50_sell_count') or 0)
    buy=float(full60.get('smart50_buy_value') or 0);sell=float(full60.get('smart50_sell_value') or 0);net=buy-sell
    rb=float(recent30.get('smart50_buy_value') or 0);rs=float(recent30.get('smart50_sell_value') or 0);pb=float(prev30.get('smart50_buy_value') or 0);ps=float(prev30.get('smart50_sell_value') or 0)
    recent_net=rb-rs;prev_net=pb-ps
    flip=bool(prev_net<0 and recent_net>max(50_000_000,abs(prev_net)*.5))
    accel=rb/max(pb,25_000_000)
    total_notional=float(full60.get('pv') or 0);relative=(buy+sell)/max(total_notional,1)
    score=early*.40+strong*.35+large*.70+very*1.10-sells*.40
    score+=clamp(net/100_000_000*.65,-3,4)+clamp((accel-1)*.6,-.5,1.5)+clamp(relative*4,0,1.5)
    if buy_pressure>=60:score+=.75
    if vwap_gap>=0:score+=.45
    if flip:score+=.85
    # A single 50M print never creates SURGE. Repetition/accumulation + flow confirmation is required.
    surge=bool((early>=2 and net>=120_000_000 and buy_pressure>=57 and vwap_gap>=-.15 and (accel>=1.10 or flip)) or (large>=2 and net>0))
    if surge:score+=1
    return {
        'score':round(clamp(score,-4,6),2),'surge':surge,'early_count':early,'strong_count':strong,'large_count':large,'very_large_count':very,'sell_count':sells,
        'buy_value':buy,'sell_value':sell,'net_value':net,'buy_value_30s':rb,'sell_value_30s':rs,'net_value_30s':recent_net,
        'previous_net_30s':prev_net,'acceleration':round(accel,3),'sell_to_buy_flip':flip,'relative_large_trade_ratio':round(relative,4),
        'label':'REALTIME_PROXY_NOT_INVESTOR_IDENTITY'
    }
