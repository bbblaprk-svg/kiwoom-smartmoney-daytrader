from __future__ import annotations
import asyncio,json,random,re,time,time as _time
from datetime import datetime
from zoneinfo import ZoneInfo
import httpx,websockets
from app.config import SETTINGS
from app.domain import Venue


def num(v,default=0.0):
    try:return float(str(v).replace(',','').strip() or default)
    except Exception:return default

def code6(x)->str:
    m=re.search(r'(\d{6})',str(x or ''));return m.group(1) if m else ''

def venue_from_item(raw_item:str,fid9081:str='')->Venue:
    item=str(raw_item or '').strip().upper();fid=str(fid9081 or '').strip().upper()
    explicit=Venue.NXT if item.endswith('_NX') else Venue.KRX if re.fullmatch(r'\d{6}',item) else Venue.UNKNOWN
    f=Venue.NXT if fid=='NXT' else Venue.KRX if fid=='KRX' else Venue.UNKNOWN
    if explicit==Venue.UNKNOWN:return f
    if f!=Venue.UNKNOWN and f!=explicit:return Venue.UNKNOWN
    return explicit

KST=ZoneInfo('Asia/Seoul')

def _token_expiry_epoch(payload:dict,now:float|None=None)->float:
    """Use Kiwoom's expires_dt when present; fall back conservatively only if parsing is impossible."""
    base=time.time() if now is None else float(now)
    raw=str((payload or {}).get('expires_dt') or '').strip()
    if raw:
        try:
            exp=datetime.strptime(raw,'%Y%m%d%H%M%S').replace(tzinfo=KST).timestamp()
            if exp<=base+60:raise RuntimeError('KIWOOM_TOKEN_EXPIRY_NOT_FUTURE')
            return exp
        except RuntimeError:
            raise
        except Exception:
            pass
    return base+23*3600

class TokenManager:
    def __init__(self):self.token='';self.exp=0.0;self.lock=asyncio.Lock()
    def _valid(self)->bool:return bool(self.token) and time.time()<self.exp-120
    async def invalidate(self,expected_token:str='')->bool:
        async with self.lock:
            if expected_token and self.token and self.token!=expected_token:return False
            self.token='';self.exp=0.0;return True
    async def get(self):
        if self._valid():return self.token
        async with self.lock:
            if self._valid():return self.token
            if not SETTINGS.app_key or not SETTINGS.secret:raise RuntimeError('KIWOOM_APP_KEY / KIWOOM_SECRET_KEY required')
            async with httpx.AsyncClient(timeout=8) as c:
                r=await c.post(SETTINGS.api_base+'/oauth2/token',json={'grant_type':'client_credentials','appkey':SETTINGS.app_key,'secretkey':SETTINGS.secret})
                try:j=r.json()
                except Exception:j={'return_code':-999,'return_msg':r.text[:180]}
                if r.status_code!=200 or int(j.get('return_code',0))!=0:raise RuntimeError(j.get('return_msg') or f'token http {r.status_code}')
                token=str(j.get('token') or '').strip()
                if not token:raise RuntimeError('KIWOOM_TOKEN_MISSING')
                self.token=token;self.exp=_token_expiry_epoch(j);return self.token
TOKENS=TokenManager()

class RestPacer:
    def __init__(self):self.lock=asyncio.Lock();self.last=0.0;self.sem=asyncio.Semaphore(SETTINGS.rest_max_inflight);self.client=httpx.AsyncClient(timeout=httpx.Timeout(8,connect=4),limits=httpx.Limits(max_connections=SETTINGS.rest_max_inflight,max_keepalive_connections=SETTINGS.rest_max_inflight))
    async def _pace(self):
        async with self.lock:
            d=SETTINGS.rest_pace_sec-(time.monotonic()-self.last)
            if d>0:await asyncio.sleep(d)
            self.last=time.monotonic()
    async def post(self,path:str,api_id:str,body:dict):
        for attempt in range(2):
            await self._pace();token=await TOKENS.get()
            async with self.sem:
                r=await self.client.post(SETTINGS.api_base+path,headers={'authorization':'Bearer '+token,'api-id':api_id,'Content-Type':'application/json;charset=UTF-8'},json=body)
            try:j=r.json()
            except Exception:j={'return_code':-999,'return_msg':r.text[:180]}
            if r.status_code in (401,403) and attempt==0:
                await TOKENS.invalidate(token);continue
            return r.status_code,j
        raise RuntimeError('KIWOOM_REST_AUTH_RETRY_EXHAUSTED')
REST=RestPacer()

def extract_rows(obj):
    if isinstance(obj,list):return obj if obj and isinstance(obj[0],dict) else sum((extract_rows(x) for x in obj),[])
    if isinstance(obj,dict):
        best=[]
        for v in obj.values():
            if isinstance(v,list) and v and isinstance(v[0],dict) and len(v)>len(best):best=v
        return best
    return []

def row_identity(r:dict):
    code='';name=''
    for k in ('stk_cd','stk_code','code','item','종목코드'):
        if r.get(k):code=code6(r.get(k))
        if code:break
    for k in ('stk_nm','stk_name','name','종목명'):
        if r.get(k):name=str(r[k]);break
    return code,name

def row_rate(r:dict):
    for k in ('chg_rt','pre_rt','flu_rt','rate','change_rate','updown_rate','pred_pre_rt','diff_rate_for_gjga'):
        if str(r.get(k) or '').strip():return num(r.get(k))
    return 0.0

def row_price(r:dict):
    for k in ('cur_prc','curr_pric','now_prc','cur_pric','stck_prpr','price','현재가'):
        if str(r.get(k) or '').strip():
            x=abs(num(r.get(k)))
            if x:return x
    return 0.0
