from __future__ import annotations
import asyncio,json,random,time
from datetime import datetime
from zoneinfo import ZoneInfo
import websockets
from app.broker.kiwoom import TOKENS,venue_from_item,num,code6
from app.config import SETTINGS,effective_ws_code_budget
from app.domain import TradeTick,ProgramTick,OrderbookTick,Venue
from app.runtime.integrity import TickIntegrity
from app.runtime.dispatcher import TradeDispatcher,CoalescingLane,Envelope
from app.runtime.state import RuntimeState
from app.runtime.clock import sessions,trade_day

class KiwoomWebSocket:
    def __init__(self,state:RuntimeState,trade_dispatcher:TradeDispatcher,coalesce:CoalescingLane):
        self.state=state;self.trade_dispatcher=trade_dispatcher;self.coalesce=coalesce;self.integrity=TickIntegrity();self.recv_seq=0;self.registered={};self._rate_sec=0;self._rate_count=0

    def _targets(self):
        sess=sessions();codes=sorted(self.state.hot_codes);pinned=sorted(self.state.pinned_codes);followup=sorted(self.state.followup_codes)
        # Pinned names stay first. Ordinary HOT shrinks automatically under load.
        ordered=[]
        for x in pinned+followup+codes:
            if x not in ordered:ordered.append(x)
        budget=effective_ws_code_budget();hard=max(SETTINGS.ws_trade_per_venue,min(len(pinned),budget));hard=min(hard,budget);trade=ordered[:hard]
        self.state.telemetry['pinned_ws_overflow']=max(0,len(pinned)-budget)
        program=ordered[:SETTINGS.ws_program_cap];orderbook=ordered[:SETTINGS.ws_orderbook_cap]
        return sess,trade,program,orderbook

    async def _await_control_ack(self,ws,trnm:str):
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            try:raw=await asyncio.wait_for(ws.recv(),timeout=min(1.0,max(.05,deadline-time.monotonic())))
            except asyncio.TimeoutError:continue
            m=json.loads(raw)
            if m.get('trnm')=='PING':await ws.send(raw);continue
            if m.get('trnm')==trnm:
                if int(m.get('return_code',-1))!=0:
                    self.state.ws_status['subscription_reject_count']=int(self.state.ws_status.get('subscription_reject_count') or 0)+1
                    raise RuntimeError(str(m.get('return_msg') or f'{trnm} failed'))
                return
            await self._dispatch_message(m)
        raise RuntimeError(f'{trnm} ACK timeout')

    async def _send_group(self,ws,grp:str,items:list[str],typ:str):
        # refresh=1 preserves other already-registered groups. A changed group is explicitly
        # removed first in _refresh_registry, preventing stale HOT symbols from accumulating.
        packet={'trnm':'REG','grp_no':grp,'refresh':'1','data':[{'item':items,'type':[typ]}]}
        await ws.send(json.dumps(packet,ensure_ascii=False));await self._await_control_ack(ws,'REG')

    async def _remove_group(self,ws,grp:str,items:list[str]|None=None,typ:str=''):
        # REMOVE with only grp_no deletes the group. When items/type are supplied, Kiwoom's
        # partial-remove path deletes only stale members and keeps retained symbols uninterrupted.
        packet={'trnm':'REMOVE','grp_no':grp}
        if items:packet['data']=[{'item':items,'type':[typ]}]
        await ws.send(json.dumps(packet,ensure_ascii=False));await self._await_control_ack(ws,'REMOVE')

    async def _refresh_registry(self,ws):
        sess,trade,program,orderbook=self._targets();desired={}
        if sess['krx']:desired['410']=(trade,'0B')
        if sess['nxt']:desired['411']=([x+'_NX' for x in trade],'0B')
        aux_items=[]
        for x in program:
            if sess['krx']:aux_items.append(x)
            if sess['nxt']:aux_items.append(x+'_NX')
        if aux_items:desired['420']=(aux_items,'0u')
        ob_items=[]
        for x in orderbook:
            if sess['krx']:ob_items.append(x)
            if sess['nxt']:ob_items.append(x+'_NX')
        if ob_items:desired['430']=(ob_items,'0D')
        # Exact diff update: obsolete groups are removed as groups; changed groups use partial
        # REMOVE + additive REG so retained symbols are never torn down merely because rankings rotate.
        obsolete=sorted(set(self.registered)-set(desired))
        for grp in obsolete:
            await self._remove_group(ws,grp);self.registered.pop(grp,None)
        for grp,(items,typ) in desired.items():
            sig=(tuple(items),typ);old=self.registered.get(grp)
            if old==sig:continue
            if old is None:
                await self._send_group(ws,grp,items,typ);self.registered[grp]=sig;continue
            old_items,old_typ=old
            if old_typ!=typ:
                await self._remove_group(ws,grp);await self._send_group(ws,grp,items,typ);self.registered[grp]=sig;continue
            old_set=set(old_items);new_set=set(items);removed=sorted(old_set-new_set);added=[x for x in items if x not in old_set]
            if removed:await self._remove_group(ws,grp,removed,typ)
            if added:await self._send_group(ws,grp,added,typ)
            self.registered[grp]=sig
        self.state.ws_status['registered']=len(set(trade));self.state.ws_status['registered_groups']=len(desired);self.integrity.prune_codes(trade_day(),set(trade))

    def _mark_message(self):
        sec=int(time.time())
        if sec!=self._rate_sec:
            if self._rate_sec:self.state.telemetry['ws_messages_per_sec']=self._rate_count
            self._rate_sec=sec;self._rate_count=0
        self._rate_count+=1

    def _provider_latency(self,exchange_time:str,receive_wall:float):
        raw=''.join(ch for ch in str(exchange_time or '') if ch.isdigit())
        if len(raw)<6:return None
        try:
            n=datetime.fromtimestamp(receive_wall,ZoneInfo('Asia/Seoul'));hh=int(raw[:2]);mm=int(raw[2:4]);ss=int(raw[4:6]);provider=n.replace(hour=hh,minute=mm,second=ss,microsecond=0).timestamp();d=(receive_wall-provider)*1000
            return d if -2000<=d<=120000 else None
        except Exception:return None

    async def _dispatch_message(self,m:dict):
        if m.get('trnm')!='REAL':return
        self._mark_message()
        for d in m.get('data') or []:
            typ=str(d.get('type') or '');v=d.get('values') or {};raw_item=str(d.get('item') or v.get('9001') or '');code=code6(raw_item)
            if not code:continue
            noww=time.time();nowm=time.monotonic();self.recv_seq+=1
            if typ=='0B':
                p=abs(num(v.get('10')));q=num(v.get('15'));rate=num(v.get('12'));fid=str(v.get('9081') or '').upper();venue=venue_from_item(raw_item,fid)
                if p<=0 or venue==Venue.UNKNOWN:
                    self.state.telemetry['stale_tick_reject_count']+=1;continue
                cumv=abs(num(v.get('13')));turn=abs(num(v.get('14')));ex=str(v.get('20') or '')
                lat=self._provider_latency(ex,noww)
                if lat is not None:self.state.telemetry['ws_receive_latency_ms']=round(lat,1)
                fp=self.integrity.fingerprint(raw_item,ex,p,q,cumv)
                tick=TradeTick(code,venue,p,q,rate,cumv,turn,ex,noww,nowm,self.recv_seq,raw_item,fid,fp)
                ir=self.integrity.validate(trade_day(),tick)
                if not ir.accepted:
                    if ir.duplicate:self.state.telemetry['duplicate_tick_reject_count']+=1
                    if ir.out_of_order:self.state.telemetry['out_of_order_tick_count']+=1
                    if ir.cum_rollback:self.state.telemetry['cumulative_rollback_count']+=1
                    continue
                pinned=code in self.state.pinned_codes
                self.trade_dispatcher.submit(Envelope('TRADE',code,tick,nowm,pinned))
                self.state.ws_status.update({'last_trade_at':noww,'last_trade_code':code,'last_trade_venue':venue.value,'last_message_at':noww})
            elif typ=='0u':
                venue=venue_from_item(raw_item,str(v.get('9081') or ''));net=num(v.get('212'));delta=num(v.get('213'));buy=num(v.get('208'));sell=num(v.get('204'))
                if venue!=Venue.UNKNOWN:self.coalesce.submit('PROGRAM',code,ProgramTick(code,venue,buy,sell,net,delta,noww))
            elif typ=='0D':
                venue=venue_from_item(raw_item,str(v.get('9081') or ''))
                if venue==Venue.UNKNOWN:continue
                asks=[abs(num(v.get(str(k)))) for k in range(61,71)];bids=[abs(num(v.get(str(k)))) for k in range(71,81)];ap=[abs(num(v.get(str(k)))) for k in range(41,51)];bp=[abs(num(v.get(str(k)))) for k in range(51,61)]
                self.coalesce.submit('ORDERBOOK',code,OrderbookTick(code,venue,sum(bids),sum(asks),max(bp or [0]),min([x for x in ap if x>0] or [0]),noww))

    async def run(self):
        backoff=1.0
        while True:
            if not SETTINGS.app_key or not SETTINGS.secret:
                self.state.ws_status['last_error']='KEYS_MISSING';await asyncio.sleep(5);continue
            if not sessions()['active']:
                self.state.ws_status.update({'connected':False,'logged_in':False,'registered':0});self.registered={};await asyncio.sleep(3);continue
            try:
                token=await TOKENS.get();self.registered={}
                async with websockets.connect(SETTINGS.ws_url,ping_interval=None,close_timeout=3,max_size=6_000_000) as ws:
                    self.state.ws_status.update({'connected':True,'logged_in':False,'last_error':'','reconnects':int(self.state.ws_status.get('reconnects') or 0)+1,'resync_started_at':time.time()})
                    self.state.mark_resync(set(self.state.hot_codes)|set(self.state.pinned_codes),'WS_RECONNECT_WARMING')
                    await ws.send(json.dumps({'trnm':'LOGIN','token':token}));last_reg=0.0
                    while True:
                        if not sessions()['active']:break
                        if self.state.ws_status.get('logged_in') and (time.monotonic()-last_reg>1):await self._refresh_registry(ws);last_reg=time.monotonic()
                        try:raw=await asyncio.wait_for(ws.recv(),timeout=.5)
                        except asyncio.TimeoutError:continue
                        m=json.loads(raw);self.state.ws_status['last_message_at']=time.time()
                        if m.get('trnm')=='PING':await ws.send(raw);continue
                        if m.get('trnm')=='LOGIN':
                            if int(m.get('return_code',-1))!=0:
                                await TOKENS.invalidate(token)
                                raise RuntimeError(str(m.get('return_msg') or 'LOGIN failed'))
                            self.state.ws_status['logged_in']=True;continue
                        if m.get('trnm')=='REG':continue
                        await self._dispatch_message(m)
                backoff=1.0
            except Exception as e:
                self.state.ws_status.update({'connected':False,'logged_in':False,'registered':0,'last_error':str(e)[:180]});self.registered={}
                self.state.mark_resync(set(self.state.hot_codes)|set(self.state.pinned_codes),'WS_DISCONNECT')
                await asyncio.sleep(backoff*(1+random.uniform(-.15,.15)));backoff=min(10,backoff*2)
