from __future__ import annotations
import asyncio,time
from app.broker.kiwoom import REST,extract_rows,row_identity,row_rate,row_price
from app.runtime.state import RuntimeState
from app.runtime.clock import sessions,trade_day
from app.domain import Origin
from app.runtime.load_control import hot_capacity
from app.config import SETTINGS

RANK_SPECS=[
 ('orderbook_buy','ka10020',10,{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',17,{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',14,{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',20,{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',9,{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',10,{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',15,{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]

def _fund_like(name:str)->bool:
    n=(name or '').upper();return any(x in n for x in ('ETF','ETN','KODEX','TIGER','ACE ','KOSEF','SOL '))

def stex_for_session(sess:dict)->str:
    # 1=KRX only, 2=NXT only, 3=both. Never ask integrated rank data while one venue is in a scheduled matching gap.
    return '3' if sess.get('krx') and sess.get('nxt') else '1' if sess.get('krx') else '2'

class DiscoveryEngine:
    def __init__(self,state:RuntimeState):self.state=state;self.last_status={}
    async def _fetch(self,market,source,api_id,weight,body_tpl,stex):
        b={k:(market if v=='{market}' else v) for k,v in body_tpl.items()};b['stex_tp']=stex
        try:
            status,j=await REST.post('/api/dostk/rkinfo',api_id,b);rows=extract_rows(j);return source,weight,status==200 and int(j.get('return_code',0))==0,rows,str(j.get('return_msg') or '')
        except Exception as e:return source,weight,False,[],str(e)
    async def cycle(self):
        sess=sessions();day=trade_day();started=time.time()
        if not sess['active']:return
        stex=stex_for_session(sess)
        tasks=[]
        for market in ('001','101'):
            for source,api_id,w,tpl in RANK_SPECS:tasks.append(asyncio.create_task(self._fetch(market,source,api_id,w,tpl,stex)))
        seen=set()
        for fut in asyncio.as_completed(tasks):
            source,w,ok,rows,msg=await fut;self.last_status[source]={'ok':ok,'rows':len(rows),'msg':msg[:120],'at':time.time()}
            if not ok:continue
            for r in rows[:80]:
                code,name=row_identity(r)
                if not code or _fund_like(name):continue
                c=self.state.candidate(code,name,Origin.TODAY_NEW,day);first=not c.source_hits
                c.source_hits[source]=time.time();c.metrics[f'discovery_rate_{source}']=row_rate(r);p=row_price(r)
                if first:c.append_history('DISCOVERY','FIRST_CAPTURE',0.0,f'{source} 최초포착',c.current().venue)
                # Discovery prices are context only. They never become signal/current prices.
                if p:c.metrics[f'discovery_price_{source}']=p
                seen.add(code)
        now=time.time()
        with self.state.lock:
            for c in self.state.candidates.values():
                for src,at in list(c.source_hits.items()):
                    if now-at>SETTINGS.discovery_source_ttl_sec:c.source_hits.pop(src,None)
                c.rest_base=sum(next((w for s,_,w,_ in RANK_SPECS if s==src),0) for src in c.source_hits)
            rows=sorted(self.state.candidates.values(),key=lambda c:(c.live_track_pin,c.priority_score,c.score,c.rest_base,len(c.source_hits)),reverse=True)
            cap=hot_capacity(self.state.load_mode);pinned={c.code for c in rows if c.live_track_pin};hot=[c.code for c in rows if c.code not in pinned][:max(0,cap-len(pinned))]
            self.state.pinned_codes=pinned;self.state.hot_codes=set(hot)|pinned
        self.last_status['_cycle']={'duration_ms':round((time.time()-started)*1000,1),'seen':len(seen),'hot':len(self.state.hot_codes),'at':time.time()}
