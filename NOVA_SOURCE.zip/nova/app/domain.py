from __future__ import annotations
from dataclasses import dataclass, field
from enum import StrEnum
from collections import deque
from typing import Any
import time

class Venue(StrEnum):
    KRX='KRX'; NXT='NXT'; UNKNOWN='UNKNOWN'

class FeedState(StrEnum):
    STARTING='STARTING'; RESTORING='RESTORING'; RESYNC='RESYNC'; WARMING='WARMING'; LIVE='LIVE'; RECONNECTING='RECONNECTING'; CLOSED='CLOSED'; DEGRADED='DEGRADED'

class Origin(StrEnum):
    PRIOR_CLOSE='PRIOR_CLOSE'; TODAY_NEW='TODAY_NEW'

@dataclass(slots=True)
class TradeTick:
    code: str; venue: Venue; price: float; qty: float; rate: float; cum_volume: float; cum_turnover: float
    exchange_time: str; receive_wall: float; receive_mono: float; recv_seq: int
    raw_item: str=''; fid9081: str=''; fingerprint: str=''

@dataclass(slots=True)
class ProgramTick:
    code: str; venue: Venue; buy: float; sell: float; net: float; delta: float; receive_wall: float

@dataclass(slots=True)
class OrderbookTick:
    code: str; venue: Venue; bid_total: float; ask_total: float; best_bid: float; best_ask: float; receive_wall: float

@dataclass(slots=True)
class EntryLane:
    state: str='DISCOVERY'
    state_since: float=0.0
    pressure_started_at: float=0.0
    pressure_peak: float=0.0
    pullback_low: float=0.0
    reaccel_started_at: float=0.0
    reaccel_start_price: float=0.0
    direct_started_at: float=0.0
    direct_start_price: float=0.0
    cooldown_until: float=0.0
    last_buy_at: float=0.0
    last_buy_price: float=0.0
    last_buy_route: str=''
    buy_count_today: int=0
    formal_raw_count: int=0
    valid_repeat_count: int=0
    last_formal_stage: str='SEED'
    last_formal_at: float=0.0
    last_evidence_signature: str=''

@dataclass(slots=True)
class SignalEvent:
    signal_id: str; day: str; code: str; name: str; venue: Venue; stage: str; route: str
    signal_time: float; signal_price: float; signal_change_rate: float; recv_seq: int; exchange_time: str
    server_receive_time: float; reasons: list[str]; metrics: dict[str, Any]; repeat_no: int=1
    origin: Origin=Origin.TODAY_NEW

@dataclass(slots=True)
class SignalTrack:
    signal_id:str; venue:Venue; signal_price:float; signal_time:float; high:float; low:float; current:float; last_tick_at:float=0.0
    def public(self)->dict[str,Any]:
        ret=((self.current/self.signal_price-1)*100) if self.current and self.signal_price else None
        mfe=((self.high/self.signal_price-1)*100) if self.high and self.signal_price else None
        mae=((self.low/self.signal_price-1)*100) if self.low and self.signal_price else None
        return {'signal_id':self.signal_id,'venue':self.venue.value,'signal_price':self.signal_price,'signal_time':self.signal_time,
                'current_price':self.current,'current_return':round(ret,2) if ret is not None else None,
                'mfe':round(mfe,2) if mfe is not None else None,'mae':round(mae,2) if mae is not None else None,
                'last_tick_at':self.last_tick_at}

@dataclass(slots=True)
class HistoryEvent:
    at: float; kind: str; state: str; price: float=0.0; reason: str=''; venue: Venue=Venue.UNKNOWN

@dataclass(slots=True)
class VenueState:
    venue: Venue
    last_price: float=0.0; last_rate: float=0.0; last_tick_at: float=0.0; last_exchange_time: str=''; last_recv_seq: int=0
    last_cum_volume: float=0.0; last_cum_turnover: float=0.0; session_pv: float=0.0; session_v: float=0.0
    day_open: float=0.0; day_high: float=0.0; day_low: float=0.0; orb_high: float=0.0; orb_low: float=0.0
    program_net: float=0.0; program_delta: float=0.0; program_at: float=0.0
    orderbook_score: float=0.0; orderbook_at: float=0.0
    continuity_gap_until: float=0.0; continuity_reason: str=''; recovery_count: int=0; recovery_started_at: float=0.0
    score: float=0.0; confidence: float=0.0; stage: str='SEED'; reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict); entry: EntryLane=field(default_factory=EntryLane)

@dataclass(slots=True)
class Candidate:
    code: str; name: str=''; trade_day: str=''; origin: Origin=Origin.TODAY_NEW
    source_hits: dict[str,float]=field(default_factory=dict); rest_base: float=0.0
    score: float=0.0; priority_score: float=0.0; confidence: float=0.0; stage: str='SEED'; reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict)
    venue_state: dict[Venue,VenueState]=field(default_factory=lambda:{Venue.KRX:VenueState(Venue.KRX),Venue.NXT:VenueState(Venue.NXT)})
    current_venue: Venue=Venue.UNKNOWN
    live_track_pin: bool=False; lifecycle_state: str='TODAY_NEW'; state_changed_at: float=0.0
    valid_repeat_count: int=0; raw_repeat_count: int=0
    top5_enter_count: int=0; top5_reentry_count: int=0; last_top5_enter_at: float=0.0; last_top5_exit_at: float=0.0; reentry_quality: float=0.0
    history: deque[HistoryEvent]=field(default_factory=lambda:deque(maxlen=256)); signal_tracks: deque[SignalTrack]=field(default_factory=lambda:deque(maxlen=64))
    first_signal: SignalEvent|None=None; last_signal: SignalEvent|None=None
    signal_high: float=0.0; signal_low: float=0.0; buy_high: float=0.0; buy_low: float=0.0
    last_buy_at: float=0.0; last_buy_price: float=0.0; last_buy_route: str=''; last_buy_venue: Venue=Venue.UNKNOWN
    close_signal_price: float=0.0; close_score: float=0.0; close_rank: int=0
    premarket_price: float=0.0; premarket_change: float=0.0; premarket_valid: bool=False
    opening_price: float=0.0; opening_high: float=0.0; opening_low: float=0.0; shakeout_state: bool=False; reversal_state: bool=False
    last_seen_at: float=field(default_factory=time.time); history_sink: Any=None

    @property
    def entry_state(self)->str:
        if self.last_buy_venue in (Venue.KRX,Venue.NXT) and self.venue_state[self.last_buy_venue].entry.state=='BUY':return 'BUY'
        lanes=[self.venue_state[Venue.KRX].entry.state,self.venue_state[Venue.NXT].entry.state]
        rank={'BUY':9,'DIRECT_ARM':8,'REACCEL':7,'PULLBACK':6,'PRESSURE_BUILD':5,'COOLDOWN':4,'REJECTED':3,'DISCOVERY':1}
        return max(lanes,key=lambda x:rank.get(x,0))

    @property
    def signal_count_today(self)->int:return sum(v.entry.buy_count_today for v in self.venue_state.values())

    def current(self) -> VenueState:
        if self.current_venue in (Venue.KRX,Venue.NXT): return self.venue_state[self.current_venue]
        a=self.venue_state[Venue.NXT]; b=self.venue_state[Venue.KRX]
        return a if a.last_tick_at>=b.last_tick_at else b

    def best_signal_venue(self)->Venue:
        rows=[self.venue_state[Venue.KRX],self.venue_state[Venue.NXT]]
        rows.sort(key=lambda v:(v.score,v.last_tick_at),reverse=True)
        return rows[0].venue if rows else Venue.UNKNOWN

    def refresh_aggregate(self):
        rows=[self.venue_state[Venue.KRX],self.venue_state[Venue.NXT]]
        best=max(rows,key=lambda v:(v.score,v.last_tick_at))
        self.score=best.score;self.confidence=best.confidence;self.stage=best.stage;self.reasons=list(best.reasons)
        self.valid_repeat_count=sum(v.entry.valid_repeat_count for v in rows)
        self.raw_repeat_count=sum(v.entry.formal_raw_count for v in rows)
        sm=max(float(v.metrics.get('smart_money_realtime_proxy_score') or 0) for v in rows)
        surge=any(bool(v.metrics.get('smart_money_realtime_proxy_surge')) for v in rows)
        entry_bonus=8 if self.entry_state=='BUY' else 5 if self.entry_state in ('DIRECT_ARM','REACCEL') else 2 if self.entry_state in ('PRESSURE_BUILD','PULLBACK') else 0
        life_bonus=5 if self.lifecycle_state=='REVERSAL_EARLY' else 7 if self.lifecycle_state=='BUY_READY' else 0
        repeat_bonus=min(10,self.valid_repeat_count*2.0)
        reentry_bonus=min(4,self.reentry_quality)
        self.priority_score=round(min(100,max(0,self.score+repeat_bonus+(3 if surge else 0)+min(3,max(0,sm))+entry_bonus+life_bonus+reentry_bonus)),1)
        # Preserve slow/candidate fields, expose current fast metrics under an explicit namespace.
        self.metrics['fast']=dict(self.venue_state[self.current().venue].metrics)
        self.metrics['priority_score']=self.priority_score

    def append_history(self, kind:str, state:str, price:float=0.0, reason:str='', venue:Venue=Venue.UNKNOWN, at:float|None=None):
        ev=HistoryEvent(at or time.time(),kind,state,price,reason,venue)
        # Important lifecycle history is accepted by the independent persistence lane before it is
        # exposed in memory. Queue exhaustion is fail-hard in DurableJournal, never a silent loss.
        if self.history_sink:
            ok=self.history_sink({'event':'HISTORY','day':self.trade_day,'code':self.code,'name':self.name,'at':ev.at,'kind':ev.kind,'state':ev.state,'price':ev.price,'reason':ev.reason,'venue':ev.venue.value})
            if ok is False:return False
        self.history.append(ev);return True

    def public(self,display_venue:Venue|None=None) -> dict[str,Any]:
        v=self.venue_state[display_venue] if display_venue in (Venue.KRX,Venue.NXT) else self.current(); sig=self.last_signal
        sv=self.venue_state.get(sig.venue) if sig else None
        bv=self.venue_state.get(self.last_buy_venue) if self.last_buy_venue in (Venue.KRX,Venue.NXT) else None
        signal_ret=((sv.last_price/sig.signal_price-1)*100) if sig and sv and sig.signal_price>0 and sv.last_price>0 else None
        buy_ret=((bv.last_price/self.last_buy_price-1)*100) if bv and self.last_buy_price>0 and bv.last_price>0 else None
        outcome=None
        if sig:
            for t in reversed(self.signal_tracks):
                if t.signal_id==sig.signal_id:outcome=t.public();break
        return {
            'code':self.code,'name':self.name or self.code,'origin':self.origin.value,'venue':v.venue.value,
            'price':v.last_price,'change_rate':v.last_rate,'score':self.score,'priority_score':self.priority_score,'confidence':self.confidence,
            'stage':self.stage,'entry_state':self.entry_state,'lifecycle_state':self.lifecycle_state,
            'reasons':self.reasons[:5],'metrics':{**self.metrics,'fast':dict(v.metrics)},'valid_repeat_count':self.valid_repeat_count,'raw_repeat_count':self.raw_repeat_count,
            'live_track_pin':self.live_track_pin,'signal_price':sig.signal_price if sig else None,'signal_time':sig.signal_time if sig else None,
            'signal_return':round(signal_ret,2) if signal_ret is not None else None,'signal_mfe':outcome.get('mfe') if outcome else None,'signal_mae':outcome.get('mae') if outcome else None,
            'buy_price':self.last_buy_price or None,'buy_return':round(buy_ret,2) if buy_ret is not None else None,
            'signal_high':self.signal_high or None,'signal_low':self.signal_low or None,'signal_venue':sig.venue.value if sig else None,
            'buy_venue':self.last_buy_venue.value if self.last_buy_venue!=Venue.UNKNOWN else None,
            'top5_enter_count':self.top5_enter_count,'top5_reentry_count':self.top5_reentry_count,'reentry_quality':round(self.reentry_quality,2),
            'last_tick_at':v.last_tick_at,'exchange_time':v.last_exchange_time,'last_seen_at':self.last_seen_at,
            'venue_scores':{x.value:self.venue_state[x].score for x in (Venue.KRX,Venue.NXT)},
        }
