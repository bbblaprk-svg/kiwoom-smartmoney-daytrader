# QUANT NOVA 2026-08-12 Integrated Master Spec -> NOVA 3.0 Master Ground-Up

This is a reconstruction trace, not a patch log. The two master specification files under `spec/` are the design authority. The runtime never imports an older NOVA application tree.

| Master section | Implementation | Verification |
|---|---|---|
| 0-A priorities | Integrity -> Signal Accuracy -> No Bottleneck -> Early Discovery is encoded in fail-closed gates and load control | `master_audit.py`, `test_core.py` |
| 0-B bottleneck prohibitions | WS receive only parses/validates/enqueues; bounded trade lanes; REST pacer; one UI WS; disk off asyncio path | AST audit + dispatcher/load tests |
| 0-C telemetry | latency p50/p95/p99, queue depth/oldest age, drops, RSS/swap, CPU, WS/recovery counters | `/api/realtime-health` |
| 0-D realtime success | `TickIntegrity`, feed state machine, cumulative rollback guard, resync/warming | integrity/recovery tests |
| 0-E signal accuracy | exact source tick `signal_price`, immutable `signal_id`, venue lock, WAL before mutation | frozen policy + WAL tests |
| 0-F task isolation | broker receiver / dispatcher / signal coordinator / journal / display / discovery are separate components | module architecture audit |
| 0-G early discovery | paced whole-market rank discovery + fast Smart Money proxy + dynamic HOT | discovery/smart_money modules |
| 0-H fixed priorities | protected signal ticks; load sheds ordinary candidates first | queue overflow tests |
| 1 fixed principles | live pin, repeat signals, UI delta, no global snapshot overlay | state/display/top5 tests |
| 2 main path | Broker WS -> integrity -> bounded dispatcher -> fixed windows -> score -> policy -> WAL -> tracker -> display | architecture audit |
| 3 whole market + precision | REST ranks build candidates; HOT only receives precision WS; pinned/follow-up precede HOT | discovery + WS target tests |
| 4 signal data | trade, cumulative volume/turnover, micro/session VWAP, program/orderbook context, Smart Money proxy | metrics/ingest |
| 5 signal price integrity | exact decision tick price/time/recv_seq/venue persisted atomically | `test_buy_wal_uses_exact_source_tick_time...` |
| 6 live performance | venue-locked current return/MFE/MAE and BUY return | `LiveTracker`, candidate public tests |
| 7 KRX/NXT separation | `(trade_day,venue,code)` integrity + `(code,venue)` window/state | venue isolation tests |
| 8 time/order integrity | fingerprint, exchange time, recv_seq, cumulative rollback | `TickIntegrity` |
| 9 latency targets | explicit telemetry and queue-age load thresholds | health/load control |
| 10 reconnect/restart | reconnect resets registry and RESYNC; process restart restores durable truth then WARMING | WS/runtime store tests |
| 11 cumulative recovery | cumulative broker fields reconstruct session VWAP; rollback fails closed | ingest tests |
| 12 freshness | formal signal requires fresh exact tick; freshness is a last safety gate | coordinator/metrics |
| 13 durable journal | one SQLite FULL synchronous priority writer; formal ACK before state; important history fail-hard | WAL unit/stress tests |
| 14 receiver separation | no signal calculation/DB/REST inside WS receive callback | AST audit |
| 15 bounded priority | 4 sharded bounded trade FIFO + pinned protection; aux latest-value coalescing | dispatcher tests |
| 16 REST recovery | token single-flight + request pacing + bounded inflight; no browser REST swarm | broker REST + UI audit |
| 17 HTTP/WS split | `/ws/live` dedicated upgrade endpoint; `/api/*` compact recovery endpoints | API/WS smoke tests; public proxy checked at deploy if configured |
| 18 UI traffic | one WebSocket; 250 ms display snapshot/delta; one 5 s recovery timer only while WS closed | JS audit + 1/3/10 WS-client test |
| 19 load control | NORMAL/BUSY/HIGH_LOAD/CRITICAL reduces HOT capacity before signal tracking | `load_control.py` |
| 20 repeats | mechanical repeats separated from independent evidence; valid repeats raise priority | coordinator tests |
| 20-A Smart Money | 50M EARLY, 70M STRONG, 100M LARGE, 200M VERY_LARGE; proxy label never claims investor identity | smart_money tests |
| 21 opening bridge | CLOSE_TRACK -> FROZEN -> PREMARKET -> HANDOFF -> SHAKEOUT -> REVERSAL -> BUY_READY | opening tests |
| 22 candidate lifecycle | explicit origin/lifecycle/state timestamps | domain/opening |
| 23 PRIOR + TODAY competition | same ranking pool while origin remains explicit | display/ranking |
| 24 shakeout/reversal | opening state machine uses live venue metrics | opening tests |
| 25 display order | pre-BUY, opening, BUY, NXT early, NXT management, history, post-BUY manager | fixed HTML boards |
| 26 five useful slots | every board renders exactly five rows including empty placeholders | UI code |
| 27 fixed slots | stable code list and 1 s rank cadence with churn guard | DisplayState |
| 28 fixed-screen meaning | layout fixed; values remain live; position manager not score-evicted | display tests |
| 29 shake targets | fixed row heights/columns; delta push; no DOM-wide replacement | CSS/JS audit |
| 30 fixed widths | tabular numerals, fixed grid columns, ellipsis | CSS |
| 31 iPhone/iPad | single-column mobile, two-column >=800px, no forced horizontal table | CSS |
| 32 slot essentials | name/state, price/rate, score, return, repeat/state | `rowHtml` |
| 33 live BUY | confirmed BUY board plus venue-locked outcomes | display |
| 34 board replacement nature | candidate boards rank; position board stays in BUY order | display unit test |
| 35 timeline | important history durable SQLite before memory exposure | history WAL tests |
| 36 click history | `/api/signal-history/{code}` + detail modal; 1/3/5 outcomes included | API/UI smoke |
| 37 reentry | enter/exit/reenter counters and `[재등장]` display | Top5 tests/UI |
| 38 reentry quality | bounded reentry quality contributes to priority | domain/top5 |
| 39 track after Top5 exit | live pin protects signal symbols; 1/3/5 slow-side venue-locked ledger | live/performance tests |
| 40 snapshot | board-local fallback only while closed before 07:30; live board always wins | display logic |
| 41 candidate fields | master candidate fields represented in `Candidate`/`VenueState` | domain audit |
| 42 six mandatory fixes | all six represented: recv_seq truth, reconnect vs restart, WAL, UI WS path, no stale restore, dynamic HOT/bounded queue | master audit |
| 43 integrated checklist | unit, full load, HTTP/WS 1/3/10, persistence/recovery, installer gates | validation report |
| 44 implementation order | module dependency follows master priority, entry policy frozen | build graph/audit |
| 45 final architecture | buildable ground-up tree, no in-container patch lineage | clean build contract |
| 46 ten live indicators | realtime-health carries feed, latencies, queue age, drops, WS, CPU/RAM, mismatch | API health |
| 47 final purpose | integrity and accuracy gates precede discovery/score opportunity | architecture invariant |

## 1/3/5 trading-day outcome integrity

`PerformanceLedger` is deliberately slow-side. It imports only committed formal signals, locks every result to the original signal venue, subscribes a bounded set of due follow-up symbols, and finalizes only from a verified live tick on the exact target trading day after that venue closes. If a verified target-day close was not observed, the result remains `PENDING`; a later-day price is never substituted.

## Frozen BUY policy

Numeric ENTRY_V18 values are owned by `SIGNAL_POLICY_FROZEN.json` and checked by unit tests plus `master_audit.py`. Runtime architecture changes are not allowed to modify those thresholds implicitly.

## Exchange-session truth guard (Groundup-3)
- KRX continuous trade: 09:00~15:30.
- NXT continuous trade windows: PRE 08:00~08:50, MAIN 09:00:30~15:20, AFTER 15:40~20:00.
- The broad NXT 08:00~20:00 operating day is not treated as uninterrupted trade liveness.
- REST `stex_tp` follows the actually active venue: 1=KRX only, 2=NXT only, 3=dual.

## G8 host-safety deployment trace
- 1 GB host Docker build: prohibited by installer contract.
- Image build/test: GitHub Actions only.
- Image identity: app version + source ZIP SHA label + repository source label.
- Candidate: 384 MiB hard cap, no container swap, candidate mode, no host port.
- Active: 448 MiB hard cap, no container swap, host port preserved.
- Rollback: old immutable container name/state restored; no live source patching.
