from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.confluence.models import ConfluenceGrade
from pulse_edge.core.models import Venue
from pulse_edge.regime.models import MarketRegimeState


class DecisionPrimaryRoute(StrEnum):
    OBSERVE = "OBSERVE"
    SMART_PRE = "SMART_PRE"
    IGNITION = "IGNITION"
    EARLY_FOLLOWER = "EARLY_FOLLOWER"
    SECOND_WAVE = "SECOND_WAVE"
    ORB_RETEST = "ORB_RETEST"
    SQUEEZE_RELEASE = "SQUEEZE_RELEASE"
    VWAP_RECLAIM = "VWAP_RECLAIM"
    NXT_BRIDGE = "NXT_BRIDGE"


class PreBuyAction(StrEnum):
    WATCH = "WATCH"
    READY = "READY"
    EARLY_BUY = "EARLY_BUY"
    STRONG_EARLY_BUY = "STRONG_EARLY_BUY"
    BUY = "BUY"


class PreBuyStage(StrEnum):
    DATA_WAIT = "DATA_WAIT"
    BLOCKED_SHADOW = "BLOCKED_SHADOW"
    PREBUY_WATCH_SHADOW = "PREBUY_WATCH_SHADOW"
    PREBUY_SHADOW = "PREBUY_SHADOW"
    READY_SHADOW = "READY_SHADOW"
    ENTRY_ELIGIBLE_SHADOW = "ENTRY_ELIGIBLE_SHADOW"
    A_PLUS_ELIGIBLE_SHADOW = "A_PLUS_ELIGIBLE_SHADOW"


class PreBuyDecisionFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    price: float | None = None
    change_rate: float | None = None
    stage: PreBuyStage = PreBuyStage.DATA_WAIT
    action: PreBuyAction = PreBuyAction.WATCH
    action_signal_price: float | None = None
    absorption_model: str | None = None
    absorption_stage: str | None = None
    absorption_score_100: float | None = None
    absorption_price_hold_pass: bool = False
    selling_deceleration_confirmed: bool = False
    market_rs: float | None = None
    primary_route: DecisionPrimaryRoute = DecisionPrimaryRoute.OBSERVE
    supporting_routes: list[str] = Field(default_factory=list)

    confluence_grade: ConfluenceGrade = ConfluenceGrade.NONE
    confluence_score_100: float = 0.0
    evidence_count: int = 0
    regime_state: MarketRegimeState = MarketRegimeState.DATA_WAIT
    regime_score_100: float = 50.0

    # Immutable current-decision frame facts used by later compression layers.
    sector_name: str | None = None
    sector_code: str | None = None
    smart_flow_state: str = "DATA_WAIT"
    smart_flow_score_100: float | None = None
    smart_flow_confirmed_windows: int = 0
    microprice_bias_pct: float | None = None
    spread_pct: float | None = None
    money_5m: float | None = None
    tick_age_sec: float | None = None
    quote_age_sec: float | None = None
    discovery_source_count: int = 0
    universe_eligible: bool = False
    universe_eligibility_reasons: list[str] = Field(default_factory=list)
    gate_results: dict[str, bool] = Field(default_factory=dict)

    base_hard_gate_pass: bool = False
    hard_gate_pass: bool = False
    persistence_count: int = 0
    persistence_required: int = 3
    gate_failures: list[str] = Field(default_factory=list)

    route_score_100: float | None = None
    entry_reference_low: float | None = None
    entry_reference_high: float | None = None
    entry_reference_basis: str | None = None
    invalidation_price: float | None = None
    invalidation_basis: str | None = None

    reasons: list[str] = Field(default_factory=list)
    missing_requirements: list[str] = Field(default_factory=list)
    risk_flags: list[str] = Field(default_factory=list)
    upstream_asof_age_sec: float | None = None

    official_signal_enabled: bool = False
    order_action_enabled: bool = False
