from __future__ import annotations
import asyncio,json,time
from pathlib import Path
from fastapi import FastAPI,WebSocket,WebSocketDisconnect,Request,HTTPException
from fastapi.responses import FileResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from app.config import SETTINGS
from app.service import SERVICE
from app.storage.recovery import read_timeline_for_code
from app.addons.decision_panels import DecisionPanelEngine

app=FastAPI(title='QUANT NOVA',version=SETTINGS.version,docs_url=None,redoc_url=None)
DECISION_PANELS=DecisionPanelEngine(SERVICE.state)
STATIC=Path(__file__).resolve().parents[2]/'static'
app.mount('/static',StaticFiles(directory=str(STATIC)),name='static')

_PUBLIC={'/','/api/livez','/api/readyz','/api/auth/check','/manifest.webmanifest','/sw.js'}

def _token_from_request(req:Request)->str:
    h=req.headers.get('authorization','')
    if h.lower().startswith('bearer '):return h[7:].strip()
    return (req.headers.get('x-app-token') or req.query_params.get('token') or '').strip()

def _authorized(token:str)->bool:return not SETTINGS.ui_access_token or token==SETTINGS.ui_access_token

@app.middleware('http')
async def auth_middleware(request:Request,call_next):
    path=request.url.path
    if SETTINGS.ui_access_token and path.startswith('/api/') and path not in _PUBLIC and not _authorized(_token_from_request(request)):
        return JSONResponse({'ok':False,'error':'unauthorized'},status_code=401,headers={'Cache-Control':'no-store'})
    response=await call_next(request)
    if path.startswith('/api/') or path in ('/','/index.html','/sw.js','/manifest.webmanifest') or path.startswith('/static/'):
        response.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0';response.headers['Pragma']='no-cache';response.headers['Expires']='0'
    response.headers['X-NOVA-Version']=SETTINGS.version
    return response

@app.on_event('startup')
async def startup():await SERVICE.start()

@app.on_event('shutdown')
async def shutdown():await SERVICE.stop()

@app.get('/')
async def root():return FileResponse(STATIC/'index.html')

@app.get('/manifest.webmanifest')
async def manifest():return FileResponse(STATIC/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
async def sw():return FileResponse(STATIC/'sw.js',media_type='application/javascript')

@app.get('/api/auth/check')
async def auth_check(request:Request):
    required=bool(SETTINGS.ui_access_token);return {'ok':_authorized(_token_from_request(request)),'auth_required':required}

@app.get('/api/livez')
async def livez():return SERVICE.liveness()

@app.get('/api/readyz')
async def readyz():
    live=SERVICE.liveness(); journal=SERVICE.journal.health()
    ready=bool(live.get('ok') and SERVICE.state.restore_done and journal.get('ready') and not journal.get('init_error'))
    return {'ok':ready,'version':SETTINGS.version,'restore_done':SERVICE.state.restore_done,'journal_ready':bool(journal.get('ready')),'journal_init_error':journal.get('init_error') or '','feed_state':SERVICE.state.feed_state.value}

@app.get('/api/version')
async def version():return {'ok':True,'version':SETTINGS.version,'architecture':'GROUNDUP','signal_policy':'ENTRY_V18_PARITY_FROZEN'}

@app.get('/api/realtime-health')
async def realtime_health():return SERVICE.realtime_health()

@app.get('/api/live-dashboard')
async def dashboard():return SERVICE.display.get_fresh()

@app.get('/api/nova')
async def nova():return SERVICE.display.get_fresh()

@app.get('/api/screen-state')
async def screen_state():return {'ok':True,'source':'LIVE_BRIDGE_V2_TOP10_DELTA','snapshot':SERVICE.display.get_fresh()}

@app.get('/api/decision-panels')
async def decision_panels():return DECISION_PANELS.build()

@app.get('/api/prebuy-recommendations')
async def prebuy():return {'ok':True,'rows':SERVICE.display.get_fresh().get('boards',{}).get('prebuy',[])}

@app.get('/api/buy-signals')
async def buy_signals():return {'ok':True,'rows':SERVICE.display.get_fresh().get('boards',{}).get('live_buy',[])}

@app.get('/api/nxt-alerts')
async def nxt_alerts():return {'ok':True,'rows':SERVICE.display.get_fresh().get('boards',{}).get('nxt_early',[])}

@app.get('/api/nxt-signal-table')
async def nxt_signal_table():return {'ok':True,'rows':SERVICE.display.get_fresh().get('boards',{}).get('nxt_management',[])}

@app.get('/api/position-manager')
async def position_manager():return {'ok':True,'rows':SERVICE.display.get_fresh().get('boards',{}).get('position_manager',[]),'note':'confirmed BUY positions; score does not evict rows'}

@app.get('/api/opening-profit-bridge')
async def opening_profit_bridge():return {'ok':True,'phase':SERVICE.display.get_fresh().get('phase'),'rows':SERVICE.display.get_fresh().get('boards',{}).get('opening',[])}

@app.get('/api/opening-shakeout-reversal')
async def opening_shakeout_reversal():
    rows=SERVICE.display.get_fresh().get('boards',{}).get('opening',[])
    return {'ok':True,'shakeout':[r for r in rows if r.get('lifecycle_state')=='SHAKEOUT_WATCH'],'reversal':[r for r in rows if r.get('lifecycle_state') in ('REVERSAL_EARLY','BUY_READY','BUY')],'rows':rows}

@app.get('/api/signal-history/{code}')
async def signal_history(code:str):
    durable=await asyncio.to_thread(read_timeline_for_code,SETTINGS.data_dir/'signal_wal.sqlite3',code,2000);live=SERVICE.display.history(code);rows=durable+live;uniq={}
    for x in rows:uniq[(round(float(x.get('at') or 0),6),x.get('kind'),x.get('state'),float(x.get('price') or 0),x.get('venue'))]=x
    return {'ok':True,'code':code,'rows':sorted(uniq.values(),key=lambda x:float(x.get('at') or 0))[-2000:]}

@app.get('/api/performance/{code}')
async def performance(code:str):return {'ok':True,'code':code,'rows':await asyncio.to_thread(SERVICE.performance.rows_for_code,code)}

@app.get('/api/ws-contract')
async def ws_contract():return {'ok':True,'contract':{'trade_type':'0B','program_type':'0u','orderbook_type':'0D','ui_path':'/ws/live','broker_ws':SETTINGS.ws_url}}

@app.websocket('/ws/live')
async def ws_live(ws:WebSocket):
    token=(ws.query_params.get('token') or '').strip()
    if SETTINGS.ui_access_token and not _authorized(token):
        await ws.close(code=4401);return
    await ws.accept();SERVICE.state.ui_clients+=1;last_gen=-1;last_sent=0.0
    try:
        while True:
            gen,payload=SERVICE.display.wire_for(last_gen);now=time.monotonic()
            if payload:
                t0=time.perf_counter();await ws.send_text(payload);SERVICE.state.observe_latency('ui_push_ms',(time.perf_counter()-t0)*1000)
                snap=SERVICE.display.get()
                if snap.get('generated_at'):SERVICE.state.observe_latency('display_to_push_ms',max(0,(time.time()-float(snap['generated_at']))*1000))
                last_gen=gen;last_sent=now
            elif now-last_sent>=2.0:
                snap=SERVICE.display.get();hb=json.dumps({'type':'heartbeat','version':snap.get('version'),'generation':gen,'generated_at':snap.get('generated_at'),'feed_state':snap.get('feed_state')},ensure_ascii=False,separators=(',',':'))
                await ws.send_text(hb);last_sent=now
            await asyncio.sleep(.1)
    except WebSocketDisconnect:pass
    finally:SERVICE.state.ui_clients=max(0,SERVICE.state.ui_clients-1)
