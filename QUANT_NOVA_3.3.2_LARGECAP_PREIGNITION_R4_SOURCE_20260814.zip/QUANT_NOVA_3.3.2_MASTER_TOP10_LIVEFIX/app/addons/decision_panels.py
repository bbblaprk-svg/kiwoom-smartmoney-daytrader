from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import Any

from app.domain import Candidate, Venue
from app.runtime.clock import sessions

# Operator-defined liquid large-cap swing universe.  This is intentionally metadata only:
# it does not call a broker, change subscriptions, or claim to calculate live market cap.
_DEFAULT_LARGECAP = {
    '005930':'삼성전자','000660':'SK하이닉스','373220':'LG에너지솔루션','207940':'삼성바이오로직스',
    '005380':'현대차','000270':'기아','068270':'셀트리온','005490':'POSCO홀딩스','035420':'NAVER','035720':'카카오',
    '012450':'한화에어로스페이스','105560':'KB금융','055550':'신한지주','086790':'하나금융지주','316140':'우리금융지주',
    '028260':'삼성물산','032830':'삼성생명','012330':'현대모비스','009150':'삼성전기','066570':'LG전자','051910':'LG화학',
    '006400':'삼성SDI','003670':'포스코퓨처엠','010130':'고려아연','096770':'SK이노베이션','034020':'두산에너빌리티',
    '042660':'한화오션','329180':'HD현대중공업','267260':'HD현대일렉트릭','047810':'한국항공우주','034730':'SK','003550':'LG',
    '015760':'한국전력','017670':'SK텔레콤','030200':'KT','259960':'크래프톤','352820':'하이브','018260':'삼성에스디에스',
    '010950':'S-Oil','011200':'HMM','090430':'아모레퍼시픽','161390':'한국타이어앤테크놀로지','011070':'LG이노텍',
    '000810':'삼성화재','024110':'기업은행','138040':'메리츠금융지주','323410':'카카오뱅크','247540':'에코프로비엠',
    '086520':'에코프로','196170':'알테오젠','005940':'NH투자증권','006800':'미래에셋증권','000720':'현대건설',
}


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v if v is not None else default)
    except Exception:
        return default


def _round_price(x: float) -> float:
    # Display-only approximation of Korean equity tick sizing.  It is deliberately conservative;
    # the broker/exchange remains the execution source of truth.
    if x <= 0:
        return 0.0
    if x < 2_000: tick = 1
    elif x < 5_000: tick = 5
    elif x < 20_000: tick = 10
    elif x < 50_000: tick = 50
    elif x < 200_000: tick = 100
    elif x < 500_000: tick = 500
    else: tick = 1_000
    return round(x / tick) * tick


def _universe() -> dict[str, str]:
    out = dict(_DEFAULT_LARGECAP)
    raw = os.getenv('NOVA_LARGECAP_CODES', '').strip()
    if raw:
        for part in raw.split(','):
            code = part.strip().split(':', 1)[0].strip()
            if len(code) == 6 and code.isdigit():
                out.setdefault(code, code)
    return out


def _fresh_row(c: Candidate, now: float, max_age: float = 9.0) -> tuple[Venue, Any, dict[str, Any], bool]:
    v = c.current()
    m = v.metrics or {}
    age = now - _f(v.last_tick_at) if v.last_tick_at else 10**9
    fresh = bool(v.last_price > 0 and age <= max_age and not v.continuity_reason and not v.resync_required and m.get('fresh', True))
    return v.venue, v, m, fresh


def _signal_windows(c: Candidate, now: float) -> tuple[int, int, float]:
    n10 = n30 = 0
    last = 0.0
    for e in list(c.history):
        if e.kind != 'SIGNAL':
            continue
        age = now - _f(e.at)
        if age < 0:
            continue
        if age <= 1800:
            n30 += 1
            last = max(last, _f(e.at))
            if age <= 600:
                n10 += 1
    return n10, n30, last


def _accel_label(n10: int, n30: int) -> str:
    if n10 >= 2 and n30 >= 3: return '↑↑'
    if n10 >= 1: return '↑'
    if n30 >= 1: return '↓'
    return '→'


def _entry_plan(price: float, m: dict[str, Any]) -> dict[str, float | None]:
    if price <= 0:
        return {'entry_low':None,'entry_high':None,'chase_limit':None,'stop':None,'t1':None,'t2':None}
    svwap = _f(m.get('session_vwap'))
    vgap = _f(m.get('session_vwap_gap'))
    if svwap <= 0 and abs(vgap) < 20:
        svwap = price / (1 + vgap / 100) if (1 + vgap / 100) > 0 else 0
    anchor = svwap if svwap > 0 and abs(price / svwap - 1) <= .035 else price
    low = max(price * .985, anchor * .995)
    high = min(price * 1.002, anchor * 1.006)
    if low > high:
        low, high = price * .994, price * 1.002
    mid = (low + high) / 2
    return {
        'entry_low':_round_price(low),'entry_high':_round_price(high),'chase_limit':_round_price(max(high * 1.012, price * 1.008)),
        'stop':_round_price(mid * .96),'t1':_round_price(mid * 1.06),'t2':_round_price(mid * 1.10),
    }


def _largecap_score(c: Candidate, m: dict[str, Any], fresh: bool) -> tuple[float, list[str]]:
    priority = _f(c.priority_score); base = _f(c.score); conf = _f(c.confidence)
    bp = _f(m.get('buy_pressure'), 50); acc = _f(m.get('volume_accel'), 1); vgap = _f(m.get('session_vwap_gap'))
    sm = _f(m.get('smart_money_realtime_proxy_score')); rate = _f(c.current().last_rate)
    score = priority * .42 + base * .25 + conf * .08
    score += _clamp((bp - 50) * .40, 0, 10)
    if bool(m.get('volume_accel_ready')): score += _clamp((acc - 1) * 12, 0, 10)
    score += _clamp(sm, 0, 8) + min(8, c.valid_repeat_count * 1.6)
    if -.35 <= vgap <= 1.5: score += 5
    elif vgap < -1.0: score -= 5
    elif vgap > 2.5: score -= 7
    if bool(m.get('program_fresh')) and _f(m.get('program_delta')) > 0: score += 3
    if c.entry_state in ('REACCEL','DIRECT_ARM'): score += 6
    if c.lifecycle_state in ('REVERSAL_EARLY','BUY_READY'): score += 5
    if rate > 8: score -= min(18, (rate - 8) * 2.0)
    if rate < -5: score -= 6
    if not fresh: score = min(score, 39)
    reasons=[]
    if bp >= 57: reasons.append(f'공격매수 {bp:.0f}%')
    if bool(m.get('volume_accel_ready')) and acc >= 1.25: reasons.append(f'거래가속 {acc:.1f}x')
    if -.35 <= vgap <= 1.5: reasons.append(f'VWAP {vgap:+.2f}%')
    if sm >= 2 or bool(m.get('smart_money_realtime_proxy_surge')): reasons.append(f'SM +{sm:.1f}')
    if c.valid_repeat_count: reasons.append(f'반복 {c.valid_repeat_count}')
    return round(_clamp(score), 1), reasons[:4]


def _largecap_row(c: Candidate, now: float, active: bool, names: dict[str, str]) -> dict[str, Any] | None:
    venue, v, m, fresh = _fresh_row(c, now)
    if v.last_price <= 0:
        return None
    score, reasons = _largecap_score(c, m, fresh)
    bp = _f(m.get('buy_pressure'), 50); acc = _f(m.get('volume_accel'), 1); vgap = _f(m.get('session_vwap_gap'))
    rate = _f(v.last_rate)
    if not active:
        decision = 'CLOSED'
    elif fresh and score >= 72 and -2.5 <= rate <= 7.5 and bp >= 54 and vgap >= -.55 and (not m.get('volume_accel_ready') or acc >= 1.05):
        decision = 'NOW'
    elif score >= 56:
        decision = 'WAIT'
    else:
        decision = 'AVOID'
    plan = _entry_plan(_f(v.last_price), m) if decision in ('NOW','WAIT') else {'entry_low':None,'entry_high':None,'chase_limit':None,'stop':None,'t1':None,'t2':None}
    return {
        'code':c.code,'name':c.name or names.get(c.code) or c.code,'venue':venue.value,'price':v.last_price,'change_rate':v.last_rate,
        'score':score,'decision':decision,'fresh':fresh,'last_tick_at':v.last_tick_at,'valid_repeat_count':c.valid_repeat_count,
        'entry_state':c.entry_state,'lifecycle_state':c.lifecycle_state,'buy_pressure':round(bp,1),'volume_accel':round(acc,2),
        'vwap_gap':round(vgap,2),'smart_money_score':round(_f(m.get('smart_money_realtime_proxy_score')),1),'reasons':reasons,
        **plan,
    }


def _pre_score(c: Candidate, m: dict[str, Any], fresh: bool, n10: int, n30: int) -> tuple[float, list[str]]:
    priority = _f(c.priority_score); base = _f(c.score); bp = _f(m.get('buy_pressure'),50); acc = _f(m.get('volume_accel'),1)
    vgap = _f(m.get('micro_vwap_gap')); sm = _f(m.get('smart_money_realtime_proxy_score')); rate = _f(c.current().last_rate)
    score = priority * .48 + base * .22
    score += min(10, c.valid_repeat_count * 1.8) + min(12, n10 * 4 + max(0, n30 - n10) * 1.5)
    score += _clamp((bp - 50) * .35, 0, 9)
    if bool(m.get('volume_accel_ready')): score += _clamp((acc - 1) * 10, 0, 9)
    score += _clamp(sm, 0, 8)
    if vgap >= 0: score += 4
    if bool(m.get('sell_to_buy_flip')): score += 4
    if c.entry_state in ('PRESSURE_BUILD','PULLBACK'): score += 3
    if c.entry_state in ('REACCEL','DIRECT_ARM'): score += 7
    if c.lifecycle_state in ('REVERSAL_EARLY','BUY_READY'): score += 5
    if rate > 12: score -= min(20, (rate - 12) * 2.2)
    if not fresh: score = min(score, 39)
    reasons=[]
    if n10: reasons.append(f'10분 유효신호 {n10}')
    if c.valid_repeat_count: reasons.append(f'누적반복 {c.valid_repeat_count}')
    if bool(m.get('volume_accel_ready')) and acc >= 1.25: reasons.append(f'거래가속 {acc:.1f}x')
    if bp >= 57: reasons.append(f'공격매수 {bp:.0f}%')
    if sm >= 2 or bool(m.get('smart_money_realtime_proxy_surge')): reasons.append(f'SM +{sm:.1f}')
    if vgap >= 0: reasons.append('VWAP 상단')
    return round(_clamp(score),1), reasons[:4]


def _pre_row(c: Candidate, now: float, active: bool) -> dict[str, Any] | None:
    venue, v, m, fresh = _fresh_row(c, now)
    if v.last_price <= 0 or c.entry_state == 'BUY':
        return None
    n10,n30,last = _signal_windows(c,now)
    score,reasons = _pre_score(c,m,fresh,n10,n30)
    bp=_f(m.get('buy_pressure'),50);acc=_f(m.get('volume_accel'),1);vgap=_f(m.get('micro_vwap_gap'))
    if not active: state='CLOSED'
    elif fresh and score>=72 and bp>=55 and vgap>=-.25 and (n10>=1 or c.valid_repeat_count>=2 or bool(m.get('smart_money_realtime_proxy_surge'))): state='CONFIRM'
    elif score>=58: state='PRE'
    else: state='WATCH'
    return {
        'code':c.code,'name':c.name or c.code,'venue':venue.value,'price':v.last_price,'change_rate':v.last_rate,'score':score,'state':state,
        'fresh':fresh,'repeat_total':c.valid_repeat_count,'signal_10m':n10,'signal_30m':n30,'accel':_accel_label(n10,n30),'last_signal_at':last,
        'buy_pressure':round(bp,1),'volume_accel':round(acc,2),'vwap_gap':round(vgap,2),'smart_money_score':round(_f(m.get('smart_money_realtime_proxy_score')),1),
        'entry_state':c.entry_state,'lifecycle_state':c.lifecycle_state,'reasons':reasons,
    }


@dataclass(slots=True)
class DecisionPanelEngine:
    state: Any
    cache_ttl: float = 0.75
    _cache_at: float = 0.0
    _cache: dict[str, Any] | None = None

    def build(self) -> dict[str, Any]:
        now=time.time()
        if self._cache is not None and now-self._cache_at <= self.cache_ttl:
            return self._cache
        sess=sessions();active=bool(sess.get('active'))
        with self.state.lock:
            cands=list(self.state.candidates.values())
        names=_universe()
        large=[]
        pre=[]
        for c in cands:
            if c.code in names:
                r=_largecap_row(c,now,active,names)
                if r:large.append(r)
            p=_pre_row(c,now,active)
            if p and (p['fresh'] or not active):pre.append(p)
        decision_rank={'NOW':3,'WAIT':2,'AVOID':1,'CLOSED':0}
        pre_rank={'CONFIRM':3,'PRE':2,'WATCH':1,'CLOSED':0}
        large.sort(key=lambda r:(decision_rank.get(r['decision'],0),r['score'],r['valid_repeat_count'],r['last_tick_at']),reverse=True)
        pre.sort(key=lambda r:(pre_rank.get(r['state'],0),r['score'],r['signal_10m'],r['repeat_total'],r['last_signal_at']),reverse=True)
        out={
            'ok':True,'generated_at':now,'market_active':active,'feed_state':self.state.feed_state.value,
            'largecap':large[:10],'preignition':pre[:10],
            'contracts':{
                'official_buy_logic_changed':False,'new_broker_rest_calls':0,'new_ws_subscriptions':0,
                'largecap_universe':'OPERATOR_STATIC_UNIVERSE + NOVA_LARGECAP_CODES override','decision_only':True,
                'repeat_ranking':'VERIFY/DISPLAY ONLY; does not mutate official signal state',
            },
        }
        self._cache_at=now;self._cache=out
        return out
