import time, unittest
from app.domain import Venue, Origin
from app.runtime.state import RuntimeState
from app.addons.decision_panels import DecisionPanelEngine, _entry_plan, _accel_label

class DecisionPanelsTest(unittest.TestCase):
    def test_entry_plan_order(self):
        p=_entry_plan(100000,{'session_vwap':99500,'session_vwap_gap':.50})
        self.assertLessEqual(p['entry_low'],p['entry_high']);self.assertLess(p['stop'],p['entry_low']);self.assertGreater(p['t1'],p['entry_high']);self.assertGreater(p['t2'],p['t1'])
    def test_accel_labels(self):
        self.assertEqual(_accel_label(2,3),'↑↑');self.assertEqual(_accel_label(1,1),'↑');self.assertEqual(_accel_label(0,2),'↓');self.assertEqual(_accel_label(0,0),'→')
    def test_build_is_read_only(self):
        st=RuntimeState();c=st.candidate('005930','삼성전자',Origin.TODAY_NEW,'20260814');v=c.venue_state[Venue.NXT];now=time.time();v.last_price=100000;v.last_rate=2.0;v.last_tick_at=now;v.metrics.update({'fresh':True,'buy_pressure':62,'volume_accel':1.6,'volume_accel_ready':True,'session_vwap':99500,'session_vwap_gap':.5,'micro_vwap_gap':.3,'smart_money_realtime_proxy_score':4,'smart_money_realtime_proxy_surge':True});v.score=75;c.current_venue=Venue.NXT;c.refresh_aggregate();before=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));j=DecisionPanelEngine(st,0).build();after=(c.valid_repeat_count,c.entry_state,c.lifecycle_state,v.score,dict(v.metrics));self.assertEqual(before,after);self.assertTrue(j['contracts']['official_buy_logic_changed'] is False);self.assertEqual(j['contracts']['new_broker_rest_calls'],0);self.assertEqual(j['contracts']['new_ws_subscriptions'],0)

if __name__=='__main__':unittest.main()
