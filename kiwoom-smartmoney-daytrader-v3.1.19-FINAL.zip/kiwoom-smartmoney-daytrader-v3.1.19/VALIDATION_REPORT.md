# V3.1.19 FINAL validation

V3.1.19 is based on V3.1.18 adaptive-learning / 30-stock monitoring and adds entry guidance and live candidate cleanup without changing Kiwoom receive paths.

## Added
- EARLY candidate: current price, first observed price, and a **watch-only buy waiting range**.
- Waiting range uses already-calculated VWAP, recent low/range-derived risk plan, spread and the existing VWAP chase limit. It does **not** create a BUY by itself.
- Confirmed BUY: confirmed entry price, stop, T1/T2/T3 and R/R are shown together.
- An OBSERVING ledger row is no longer enough to keep a stock on the live candidate board. If the **current** signal weakens to WAIT/BLOCKED, the stock immediately disappears from the live candidate board and the `발생중` ledger filter; history remains stored for validation/learning.
- The first EARLY price is read from the existing signal timeline, so no new market-data field or API call was added.

## Safety gates unchanged
Confirmed BUY still requires the existing V3.1.18 gates, including quality >= 85, profit-priority >= 78, trade strength >= 118, completeness >= 95%, R/R >= 1.5 and SmartMoney TURN/EXPANSION where configured.

## Kiwoom receive-path immutability check
The following files are byte-identical to V3.1.18:
- `lib/kiwoomClient.js`
- `lib/flowCollector.js`
- `lib/realtimeStore.js`
- `worker/kiwoomRealtime.js`
- `lib/signalEngine.js`

Therefore REST/WebSocket/TR/FID parsing, realtime metric collection and the signal engine were not changed in this patch. The new waiting range is a presentation-layer guidance derived from fields V3.1.18 already calculates.

## Regression tests
`npm run check` passed all existing checks plus `check:entry-guidance`.

## 30-stock load test
100,000 synthetic ticks / 30 symbols:
- throughput: 64,893 ticks/s
- event-loop p95: 25.95 ms
- event-loop max: 40.67 ms
- errors: 0
- RSS: 110.3 MB
- final pending/active: 0 / 0

This is a synthetic in-process load test, not a guarantee of live-market latency.

## Build note
This workspace has no installed `node_modules`, so a local Next.js production build was not run here. The Lightsail updater is designed to perform `npm install`, all regression checks, a 30-stock load check, and `next build` inside Docker before replacing the existing container. A failure triggers rollback.
