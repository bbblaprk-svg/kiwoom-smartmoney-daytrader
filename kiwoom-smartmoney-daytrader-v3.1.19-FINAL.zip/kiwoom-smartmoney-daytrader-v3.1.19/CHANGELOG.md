# v3.1.19 — ENTRY GUIDANCE + LIVE CANDIDATE CLEANUP

- v3.1.18 자기학습·30종목 구조 유지.
- EARLY 카드: 현재가, 최초포착가, VWAP/최근변동폭/스프레드/추격제한 기반 매수대기구간 표시.
- BUY 확정 카드: 확정 진입가, 손절가, T1/T2/T3, R/R 표시.
- OBSERVING 기록이 남아 있어도 현재 신호가 WAIT/BLOCKED로 약해지면 급등 매수후보 및 종합기록부 `발생중`에서 즉시 제외.
- 지난 관찰 데이터는 삭제하지 않아 성과학습/검증에 보존.
- Kiwoom REST/WebSocket/TR/FID 수집 파일과 signalEngine은 v3.1.18과 동일.

# CHANGELOG

## v3.1.19 — Bounded Adaptive Learning + 30-stock Universe
- 실제 EARLY/BUY 성과를 다음 자동추천 점수에 자동반영하는 제한적 자기학습 추가.
- EARLY 30분 성과를 주 학습표본으로 사용, 표본 부족 시 BUY 성과 보조.
- 거래대금/모멘텀/외인기관/PRE-SURGE/스마트머니 패턴별 성과를 학습.
- 표본 30건 전에는 학습 보정 비활성, 세부 버킷 8건 미만은 0점 처리.
- 과적합 방지를 위한 shrinkage 적용, 전체 보정 ±10점 제한.
- 확정 BUY 안전게이트는 자동학습이 절대 변경하지 않음.
- 감시범위 20 → 30종목: 고정4 + 집중8 + 경량18.
- 추가 10종목은 경량 체결감시로만 늘려 full-depth 동시대상은 기존 최대14 유지.
- 일일/장중 자동추천 8+8 → 8+18.
- 성과학습 ON/OFF UI와 학습표본/보정치 표시 추가.
