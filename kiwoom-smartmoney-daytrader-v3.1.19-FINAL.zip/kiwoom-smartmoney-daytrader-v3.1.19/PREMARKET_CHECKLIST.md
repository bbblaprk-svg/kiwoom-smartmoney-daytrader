# V3.1.19 premarket / intraday checklist

1. Header shows `v3.1.19`.
2. `/api/health` returns `ok:true`; during market hours check Kiwoom `connected` and live feed readiness.
3. Watch structure remains fixed 4 + user focus 8 + light 18 = max 30.
4. In `급등 사전포착 · 매수후보`, EARLY cards show **최초포착가** and **매수대기구간**, not an asserted entry price.
5. A stock that weakens to WAIT/BLOCKED disappears from the live candidate board on the next UI flush (about 1.5 s) while its history remains available.
6. BUY-confirmed cards show **확정 진입가 / 손절가 / T1 / T2 / T3 / R/R**.
7. The waiting range is advisory only. BUY gates remain unchanged and must confirm before treating it as a BUY signal.
8. Adaptive learning remains limited to recommendation ranking; it does not lower BUY safety gates.
9. During the first live session, monitor `/api/health` for event-loop latency, pending post-processing and memory with the 30-stock list.
