# Lightsail v3.1.19 FINAL 업데이트

GitHub 루트 파일:
- Dockerfile
- kiwoom-smartmoney-daytrader-v3.1.19-FINAL.zip
- update-lightsail-v3.1.19-FINAL.sh

업데이트는 기존 `.env`와 `kiwoom-data` 볼륨을 보존합니다. `MAX_FOCUS_USER_STOCKS=8`, `MAX_LIGHT_USER_STOCKS=18`을 적용합니다. Kiwoom 키/시크릿, REST/WebSocket 주소, TR/FID 관련 기존 환경값은 덮어쓰지 않습니다.

AWS 빌드에서 전체 회귀검사, 30종목 부하검사, Next.js build가 모두 성공해야 교체되며 실패하면 기존 컨테이너를 자동 복구합니다.
