const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kiwoom-v315-rec-'));
process.env.STORE_FILE_PATH = path.join(root, 'store.json');
process.env.STORE_KEY_DIR = path.join(root, 'keys');
process.env.MAX_FOCUS_USER_STOCKS = '8';
process.env.MAX_LIGHT_USER_STOCKS = '18';

function mkRows(startCode, count, marketBias = 0) {
  return Array.from({ length: count }, (_, i) => {
    const code = String(startCode + i).padStart(6, '0');
    return {
      stk_cd: code,
      stk_nm: `테스트${code}`,
      cur_prc: String(10000 + i * 100),
      flu_rt: String(2 + (i % 8) + marketBias),
      now_trde_qty: String(1000000 - i * 10000),
      trde_prica: String(500000 - i * 1000),
      now_rank: String(i + 1),
    };
  });
}

const client = require('../lib/kiwoomClient');
const apiCalls = [];
client.kiwoomPost = async (_path, apiId, body) => {
  apiCalls.push({ apiId, body: { ...body } });
  if (apiId === 'ka10032') {
    const rows = body.mrkt_tp === '001' ? mkRows(100100, 24, 0) : mkRows(200100, 24, 1);
    return { data: { trde_prica_upper: rows, return_code: 0 } };
  }
  if (apiId === 'ka90009') {
    const rows = [...mkRows(100100, 24), ...mkRows(200100, 24)].map((row, i) => ({
      ...row,
      frgnr_invsr: i % 3 === 0 ? '2000' : '500',
      orgn: i % 4 === 0 ? '1500' : '300',
    }));
    return { data: { opaf_invsr_trde: rows, return_code: 0 } };
  }
  throw new Error(`unexpected api ${apiId}`);
};
const realtime = require('../lib/realtimeStore');
const originalGetPublicStock = realtime.getPublicStock;
realtime.getPublicStock = (code) => {
  if (code === '100111') {
    return {
      code,
      liveUpdatedAt: Date.now(),
      signal: {
        action: 'EARLY', preSurgeScore: 90, preSurgeGroups: 5,
        smartMoneyState: 'TURN', dataCompleteness: 100,
      },
      smartMoney: { state: 'TURN' },
    };
  }
  return null;
};
delete require.cache[require.resolve('../lib/recommendationEngine')];
const engine = require('../lib/recommendationEngine');
const store = require('../lib/store');

(async () => {
  try {
    await store.setItem('watchlist:user', [
      { code: '300001', name: '수동집중', market: 'SOR', tier: 'FOCUS', source: 'MANUAL' },
      { code: '300002', name: '수동경량', market: 'SOR', tier: 'LIGHT', source: 'MANUAL' },
    ]);
    const rec = await engine.generateDailyRecommendations({ force: true });
    assert.strictEqual(rec.focus.length, 8, '집중 추천 8개 미생성');
    assert.strictEqual(rec.light.length, 18, '경량 추천 18개 미생성');
    assert.deepStrictEqual(apiCalls.map((x) => x.apiId), ['ka10032', 'ka10032', 'ka90009'], '추천 TR 구성 변경 감지');
    assert(apiCalls.slice(0, 2).every((x) => x.body.mang_stk_incls === '0' && x.body.stex_tp === '3'), '거래대금 TR 공식 입력값 오류');
    assert(apiCalls[2].body.mrkt_tp === '000' && apiCalls[2].body.amt_qty_tp === '1' && apiCalls[2].body.trde_tp === '0' && apiCalls[2].body.stex_tp === '3', '외국인기관 TR 공식 입력값 오류');
    assert(rec.focus[0].score >= rec.focus[7].score, '추천 점수 정렬 오류');
    const applied = await engine.applyRecommendations(rec);
    assert.strictEqual(applied.preservedManual, 2, '수동종목 보호 실패');
    assert.strictEqual(applied.autoFocus, 7, '집중 남은 슬롯 자동채움 실패');
    assert.strictEqual(applied.autoLight, 17, '경량 남은 슬롯 자동채움 실패');
    const saved = await store.getItem('watchlist:user');
    assert(saved.some((s) => s.code === '300001' && s.source === 'MANUAL'), '수동집중 삭제됨');
    assert(saved.some((s) => s.code === '300002' && s.source === 'MANUAL'), '수동경량 삭제됨');
    assert.strictEqual(saved.filter((s) => s.tier === 'FOCUS').length, 8);
    assert.strictEqual(saved.filter((s) => s.tier === 'LIGHT').length, 18);

    // 수동 경량종목이 추천 집중 상위와 겹쳐도 집중 자동슬롯은 다음 후보로 백필되어야 한다.
    await store.setItem('watchlist:user', [
      { code: '300001', name: '수동집중', market: 'SOR', tier: 'FOCUS', source: 'MANUAL' },
      { code: '100100', name: '추천겹침1', market: 'SOR', tier: 'LIGHT', source: 'MANUAL' },
      { code: '100101', name: '추천겹침2', market: 'SOR', tier: 'LIGHT', source: 'MANUAL' },
    ]);
    const crossTier = await engine.applyRecommendations(rec);
    assert.strictEqual(crossTier.preservedManual, 3, '교차 tier 수동종목 보호 실패');
    assert.strictEqual(crossTier.autoFocus, 7, '추천겹침 시 집중 백필 실패');
    assert.strictEqual(crossTier.autoLight, 16, '추천겹침 시 경량 백필 실패');
    const crossSaved = await store.getItem('watchlist:user');
    assert.strictEqual(crossSaved.filter((s) => s.tier === 'FOCUS').length, 8, '교차 tier 적용 후 집중 8 미충족');
    assert.strictEqual(crossSaved.filter((s) => s.tier === 'LIGHT').length, 18, '교차 tier 적용 후 경량 18 미충족');

    // 자동적용은 기본 OFF이며, ON으로 저장된 경우에만 새 당일 추천을 적용한다.
    const defaultAuto = await engine.getAutoApplyStatus();
    assert.strictEqual(defaultAuto.enabled, false, '자동적용 기본값은 OFF여야 함');
    const disabledResult = await engine.autoApplyRecommendationsIfEnabled(rec, { dateKey: rec.generatedKstDate });
    assert.strictEqual(disabledResult.applied, false, 'OFF 상태에서 자동적용됨');
    assert.strictEqual(disabledResult.reason, 'DISABLED');
    const enabledStatus = await engine.setAutoApplyEnabled(true);
    assert.strictEqual(enabledStatus.enabled, true, '자동적용 ON 저장 실패');
    await store.setItem('watchlist:user', [
      { code: '300001', name: '수동집중', market: 'SOR', tier: 'FOCUS', source: 'MANUAL' },
      { code: '300002', name: '수동경량', market: 'SOR', tier: 'LIGHT', source: 'MANUAL' },
    ]);
    const autoApplied = await engine.autoApplyRecommendationsIfEnabled(rec, { dateKey: rec.generatedKstDate });
    assert.strictEqual(autoApplied.applied, true, 'ON 상태 자동적용 실패');
    assert.strictEqual(autoApplied.appliedResult.preservedManual, 2, '자동적용 시 수동종목 보호 실패');
    assert.strictEqual(autoApplied.appliedResult.autoFocus, 7, '자동적용 집중 슬롯 오류');
    assert.strictEqual(autoApplied.appliedResult.autoLight, 17, '자동적용 경량 슬롯 오류');
    const autoStatus = await engine.getAutoApplyStatus();
    assert.strictEqual(autoStatus.lastAppliedKstDate, rec.generatedKstDate, '마지막 자동적용 일자 저장 실패');
    const staleAttempt = await engine.autoApplyRecommendationsIfEnabled({ ...rec, stale: true }, { dateKey: rec.generatedKstDate });
    assert.strictEqual(staleAttempt.applied, false, 'stale 추천 자동적용 금지 실패');
    assert.strictEqual(staleAttempt.reason, 'FRESH_RECOMMENDATION_REQUIRED');
    await engine.setAutoApplyEnabled(false);

    // 장중 강한종목: 현재 시장순위 재조회 + 이미 감시 중인 종목의 실시간 PRE-SURGE 보너스.
    apiCalls.length = 0;
    const marketNow = Date.parse('2026-08-03T01:00:00.000Z'); // 월요일 KST 10:00
    const intraday = await engine.generateIntradayRecommendations({ force: true, nowMs: marketNow });
    assert.strictEqual(intraday.generatedMode, 'INTRADAY');
    assert.strictEqual(intraday.marketActive, true, '장중 시간 판정 실패');
    assert.strictEqual(intraday.focus.length, 8, '장중 집중8 미생성');
    assert.strictEqual(intraday.light.length, 18, '장중 경량18 미생성');
    assert.deepStrictEqual(apiCalls.map((x) => x.apiId), ['ka10032', 'ka10032', 'ka90009'], '장중 추천은 검증된 3개 순위 TR만 사용해야 함');
    const boosted = [...intraday.focus, ...intraday.light].find((x) => x.code === '100111');
    assert(boosted && boosted.liveSignalBonus > 0, '실시간 PRE-SURGE 보너스 반영 실패');
    assert((boosted.reasons || []).some((x) => x.includes('실시간 사전포착')), '실시간 보너스 이유 표시 실패');

    // 60초 이내 재클릭은 REST를 다시 호출하지 않는다.
    const callCountBeforeThrottle = apiCalls.length;
    const throttled = await engine.generateIntradayRecommendations({ force: true, nowMs: marketNow + 30_000 });
    assert.strictEqual(throttled.throttled, true, '장중 60초 재조회 제한 실패');
    assert.strictEqual(apiCalls.length, callCountBeforeThrottle, '60초 이내 REST 재호출 발생');

    // 장중 자동적용은 별도 기본 OFF, ON일 때도 수동종목 보호.
    const intradayDefault = await engine.getIntradayAutoApplyStatus();
    assert.strictEqual(intradayDefault.enabled, false, '장중 자동적용 기본값은 OFF여야 함');
    const intradayDisabled = await engine.autoApplyIntradayIfEnabled(intraday, { nowMs: marketNow });
    assert.strictEqual(intradayDisabled.reason, 'DISABLED');
    await engine.setIntradayAutoApplyEnabled(true);
    await store.setItem('watchlist:user', [
      { code: '300001', name: '수동집중', market: 'SOR', tier: 'FOCUS', source: 'MANUAL' },
      { code: '300002', name: '수동경량', market: 'SOR', tier: 'LIGHT', source: 'MANUAL' },
      { code: '399999', name: '이전자동', market: 'SOR', tier: 'FOCUS', source: 'AUTO' },
    ]);
    const intradayApplied = await engine.autoApplyIntradayIfEnabled(intraday, { nowMs: marketNow });
    assert.strictEqual(intradayApplied.applied, true, '장중 자동적용 ON 적용 실패');
    assert.strictEqual(intradayApplied.appliedResult.preservedManual, 2, '장중 자동적용 수동보호 실패');
    const intradaySaved = await store.getItem('watchlist:user');
    assert(intradaySaved.some((x) => x.code === '300001' && x.source === 'MANUAL'), '장중 자동적용이 수동집중을 삭제함');
    assert(intradaySaved.some((x) => x.code === '300002' && x.source === 'MANUAL'), '장중 자동적용이 수동경량을 삭제함');
    assert(!intradaySaved.some((x) => x.code === '399999'), '장중 자동적용에서 기존 AUTO 교체 실패');

    // 같은 추천의 중복 자동적용은 막고, 장중 밖 자동적용도 막는다.
    const duplicateApply = await engine.autoApplyIntradayIfEnabled(intraday, { nowMs: marketNow + 10_000 });
    assert.strictEqual(duplicateApply.reason, 'ALREADY_APPLIED', '동일 장중추천 중복적용 차단 실패');
    const closedNow = Date.parse('2026-08-03T12:00:00.000Z'); // KST 21:00
    const marketClosedApply = await engine.autoApplyIntradayIfEnabled({ ...intraday, generatedAt: new Date(closedNow).toISOString(), marketActive: false }, { nowMs: closedNow });
    assert.strictEqual(marketClosedApply.reason, 'MARKET_CLOSED', '장중 밖 자동적용 차단 실패');
    await engine.setIntradayAutoApplyEnabled(false);

    console.log('RECOMMENDATION CHECK OK: 일일8+18, 장중강한8+18, 실시간 PRE-SURGE 보너스, 60초 제한, 수동보호, 일일/장중 자동적용 분리');
  } finally {
    realtime.getPublicStock = originalGetPublicStock;
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch((error) => { console.error(error); process.exit(1); });
