from __future__ import annotations

import json
import os
import threading
from copy import deepcopy
from datetime import datetime, time, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")


class OperatorSnapshotStore:
    """Persistent display-only snapshots for closed-session operator boards.

    Snapshots are never read by ranking, scoring, discovery, DUAL, PRE-BUY,
    NXT-native or order logic. They exist only so the last valid operator view
    survives CLOSED, browser refreshes and container restarts.
    """

    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._data: dict[str, dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        with self._lock:
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
                if isinstance(raw, dict):
                    self._data = raw
            except Exception:
                self._data = {}

    def save(self, key: str, payload: dict[str, Any], now: datetime | None = None) -> bool:
        items = payload.get("items")
        boards = payload.get("boards")
        has_items = isinstance(items, list) and len(items) > 0
        has_board_items = isinstance(boards, dict) and any(
            isinstance(v, dict) and isinstance(v.get("items"), list) and len(v.get("items")) > 0
            for v in boards.values()
        )
        if not has_items and not has_board_items:
            return False
        now = now or datetime.now(timezone.utc)
        entry = {
            "captured_at": now.isoformat(),
            "session_date_kst": now.astimezone(KST).date().isoformat(),
            "payload": deepcopy(payload),
        }
        with self._lock:
            self._data[key] = entry
            tmp = self.path.with_suffix(self.path.suffix + ".tmp")
            tmp.write_text(json.dumps(self._data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            os.replace(tmp, self.path)
        return True

    def get_valid(
        self,
        key: str,
        now: datetime,
        *,
        is_trading_day: Callable[[Any], bool],
    ) -> dict[str, Any] | None:
        with self._lock:
            entry = deepcopy(self._data.get(key))
        if not entry or not isinstance(entry.get("payload"), dict):
            return None
        local = now.astimezone(KST)
        snap_day = str(entry.get("session_date_kst") or "")
        today = local.date().isoformat()
        # Same-session snapshots are always eligible for a board that has
        # already closed. On weekends/holidays retain the last trading snapshot.
        # On the next trading day, previous-day snapshots expire at 07:30 KST.
        if snap_day != today and is_trading_day(local.date()) and local.time().replace(tzinfo=None) >= time(7, 30):
            return None
        out = deepcopy(entry["payload"])
        out["snapshot_frozen"] = True
        out["snapshot_captured_at"] = entry.get("captured_at")
        out["snapshot_session_date_kst"] = snap_day
        return out
