"""Feed-OFF HTTP contract check; can run in the built image without extra dependencies."""
import json
import sys
import urllib.request

RELEASE = '2.1.11.10_POSTCLOSE_SNAPSHOT_CPU_SAFE'
PATHS = ['/', '/assets/pulse.js', '/assets/pulse.css', '/api/smart-money/top?limit=10',
         '/api/presentation/current-decision', '/api/nxt-native/top?limit=10',
         '/api/dual-absorption/top?limit=10', '/api/prebuy/top?limit=10',
         '/api/session', '/api/feed-truth', '/api/runtime-truth', '/api/diagnostics/pipeline']


def fetch(base, path):
    with urllib.request.urlopen(base.rstrip('/') + path, timeout=8) as r:
        if r.status != 200:
            raise RuntimeError(f'{path}: HTTP {r.status}')
        return r.read()


def verify(base, feed):
    h = json.loads(fetch(base, '/health'))
    assert h.get('ok') is True and h.get('project') == 'PULSE EDGE', 'wrong app'
    assert h.get('runtime_safety_release') == RELEASE, 'wrong release'
    assert h.get('feed_enabled') is feed, 'wrong Feed mode'
    assert h.get('runtime_feature_recalc', {}).get('min_interval_ms') == 500, 'recalc contract'
    for path in PATHS:
        body = fetch(base, path)
        if path.startswith('/api/'):
            json.loads(body)
        elif path == '/assets/pulse.js':
            js = body.decode()
            assert '/api/smart-money/top?limit=10' in js
            assert '/api/history/candidates' not in js
            assert "initRows('#candidateHistoryBody',20,10" in js
            assert 'Math.min(500,Math.max(20,count))' in js
        elif path == '/assets/pulse.css':
            assert b'candidate-history-wrap' in body
    print('HTTP_CONTRACT_PASS feed=' + str(feed).lower())


if __name__ == '__main__':
    verify(sys.argv[1], sys.argv[2] == 'true')
