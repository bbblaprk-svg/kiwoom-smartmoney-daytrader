# QUANT NOVA 1.2.0 — Adaptive Smart Money

급등 전 압력을 실시간으로 탐지하는 NOVA 1.1.0에 자기학습과 스마트머니 수급을 추가한 버전입니다.

핵심:
- Kiwoom REST 순위 + KRX/NXT WebSocket 0B/FID9081
- 종목별 투자자기관별 ka10059: 기관계, 투신(invtrt), 연기금등(penfnd_etc), 외국인
- 종목별 프로그램매매 ka90004: 프로그램 순매수/변화량(지원 응답일 때 자동 반영, 실패 시 해당 항목만 fail-open)
- 체결 방향 지속성 기반 알고리즘 매수 패턴
- PRESSURE/IGNITION 포착 30분 후 결과를 온라인 학습
- 최소 60개 표본 전에는 학습 가중치 비활성
- 학습 가중치는 기본값 대비 ±30% 제한
- 학습은 점수 우선순위만 보정하며 자동 주문/포지션 크기를 확대하지 않음

영구 데이터:
- /app/data/signal_events.jsonl
- /app/data/performance_state.json
- /app/data/adaptive_model.json
- /app/data/training_events.jsonl
