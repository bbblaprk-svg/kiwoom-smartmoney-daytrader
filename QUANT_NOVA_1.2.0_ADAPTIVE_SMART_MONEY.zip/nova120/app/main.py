from __future__ import annotations
import asyncio, json, math, os, time, re
from collections import defaultdict, deque
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
import httpx, websockets
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_VERSION='NOVA-1.2.0'
SEOUL_OFFSET=9*3600
BASE=Path(__file__).resolve().parent.parent
DATA_DIR=Path(os.getenv('NOVA_DATA_DIR', str(BASE/'data')))
DATA_DIR.mkdir(parents=True, exist_ok=True)
EVENT_FILE=DATA_DIR/'signal_events.jsonl'
STATE_FILE=DATA_DIR/'performance_state.json'
LEARN_FILE=DATA_DIR/'adaptive_model.json'
TRAIN_FILE=DATA_DIR/'training_events.jsonl'
API='https://api.kiwoom.com'
WS='wss://api.kiwoom.com:10000/api/dostk/websocket'
APP_KEY=os.getenv('KIWOOM_APP_KEY','').strip()
SECRET=(os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
DISCOVERY_SECONDS=max(10,int(os.getenv('NOVA_DISCOVERY_SECONDS','20')))
WS_LIMIT=max(20,min(80,int(os.getenv('NOVA_WS_LIMIT','60'))))
MIN_SCORE=float(os.getenv('NOVA_MIN_SCORE','58'))
FRESH_MS=max(1500,int(os.getenv('NOVA_FRESH_MS','5000')))
DISPLAY_FRESH_MS=max(FRESH_MS,int(os.getenv('NOVA_DISPLAY_FRESH_MS','12000')))
SMART_POLL_SECONDS=max(5,int(os.getenv('NOVA_SMART_POLL_SECONDS','8')))
SMART_POLL_BATCH=max(3,min(12,int(os.getenv('NOVA_SMART_POLL_BATCH','8'))))
LEARN_MIN_SAMPLES=max(30,int(os.getenv('NOVA_LEARN_MIN_SAMPLES','60')))
LEARN_MAX_ADJUST=float(os.getenv('NOVA_LEARN_MAX_ADJUST','0.30'))


def num(x, d=0.0):
    try:
        s=str(x).strip().replace(',','')
        if not s:return d
        return float(s)
    except Exception:return d

def code6(x):
    s=str(x or '').strip().upper().replace('_NX','').replace('_AL','')
    m=re.search(r'(\d{6})',s)
    return m.group(1) if m else ''

def clamp(x,a=0,b=100): return max(a,min(b,x))
def now_kst_epoch(): return time.time()+SEOUL_OFFSET
def now_kst(): return time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(now_kst_epoch()))
def hmss(): return time.strftime('%H:%M:%S', time.gmtime(now_kst_epoch()))
def kst_seconds():
    t=time.gmtime(now_kst_epoch()); return t.tm_hour*3600+t.tm_min*60+t.tm_sec

def between(sec, a, b): return a <= sec < b

def market_session():
    """Operational session truth used only for UI/feed gating.
    KRX regular 09:00-15:30. NXT windows follow the validated service schedule
    used by the prior production collector: 08:00-08:50, 09:00:30-15:20, 15:40-20:00.
    """
    s=kst_seconds()
    krx=between(s,9*3600,15*3600+30*60)
    nxt=(between(s,8*3600,8*3600+50*60) or
         between(s,9*3600+30,15*3600+20*60) or
         between(s,15*3600+40*60,20*3600))
    if krx and nxt: phase='KRX+NXT LIVE'
    elif krx: phase='KRX LIVE'
    elif nxt: phase='NXT LIVE'
    elif s < 8*3600: phase='PRE-MARKET'
    elif s >= 20*3600: phase='MARKET CLOSED'
    else: phase='SESSION GAP'
    return {'krx':krx,'nxt':nxt,'active':krx or nxt,'phase':phase,'kst':hmss()}

STAGE_RANK={'SEED':0,'WATCH':1,'PRESSURE':2,'IGNITION':3}

@dataclass
class Tick:
    ts: float; price: float; qty: float; rate: float; venue: str; cumvol: float=0; turnover: float=0

@dataclass
class Capture:
    stage: str
    at: float
    price: float
    score: float
    venue: str
    current_price: float=0
    current_return: float=0
    max_price: float=0
    max_return: float=0
    min_price: float=0
    min_return: float=0
    features: dict[str,float]=field(default_factory=dict)

@dataclass
class Candidate:
    code: str
    name: str=''
    source_hits: dict[str,float]=field(default_factory=dict)
    ticks: deque=field(default_factory=lambda:deque(maxlen=900))
    last_price: float=0
    rate: float=0
    venue: str=''
    last_fid9081: str=''
    last_tick_at: float=0
    first_seen: float=field(default_factory=time.time)
    score: float=0
    confidence: float=0
    stage: str='SEED'
    reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict)
    captures: dict[str,Capture]=field(default_factory=dict)
    highest_stage: str='SEED'
    smart: dict[str,Any]=field(default_factory=dict)
    smart_updated_at: float=0

class TokenManager:
    def __init__(self): self.token=''; self.exp=0; self.lock=asyncio.Lock()
    async def get(self):
        if self.token and time.time()<self.exp-120:return self.token
        async with self.lock:
            if self.token and time.time()<self.exp-120:return self.token
            if not APP_KEY or not SECRET: raise RuntimeError('KIWOOM_APP_KEY / KIWOOM_SECRET_KEY 환경변수 필요')
            async with httpx.AsyncClient(timeout=12) as c:
                r=await c.post(API+'/oauth2/token',json={'grant_type':'client_credentials','appkey':APP_KEY,'secretkey':SECRET})
                r.raise_for_status(); j=r.json()
                if int(j.get('return_code',0))!=0: raise RuntimeError(j.get('return_msg') or 'token error')
                self.token=j['token']; self.exp=time.time()+23*3600
                return self.token
TOK=TokenManager()

class NovaState:
    def __init__(self):
        self.candidates: dict[str,Candidate]={}
        self.rest_status={}
        self.ws_status={'connected':False,'ack':0,'last_error':'','last_message_at':0,'last_trade_at':0,'last_trade_code':'','last_trade_venue':'','last_fid9081':''}
        self.generated_at=0; self.lock=asyncio.Lock(); self.ws_codes=[]
        self.scan_cycles=0; self.raw_rest_samples={}; self.event_count=0; self.last_persist=0
        self.smart_cursor=0; self.smart_status={}; self.learn={'samples':0,'positive':0,'weights':{},'last_update':None,'active':False}
    def get(self,code,name=''):
        if code not in self.candidates:self.candidates[code]=Candidate(code,name)
        elif name and not self.candidates[code].name:self.candidates[code].name=name
        return self.candidates[code]
STATE=NovaState()

def load_performance():
    try:
        if STATE_FILE.exists():
            saved=json.loads(STATE_FILE.read_text(encoding='utf-8'))
            for code,row in (saved.get('rows') or {}).items():
                c=STATE.get(code6(code) or code,str(row.get('name') or ''))
                for st,d in (row.get('captures') or {}).items():
                    try:
                        c.captures[st]=Capture(stage=st,at=float(d.get('at') or time.time()),price=float(d.get('price') or 0),score=float(d.get('score') or 0),venue=str(d.get('venue') or ''),current_price=float(d.get('current_price') or 0),current_return=float(d.get('current_return') or 0),max_price=float(d.get('max_price') or 0),max_return=float(d.get('max_return') or 0),min_price=float(d.get('min_price') or 0),min_return=float(d.get('min_return') or 0),features={k:float(v) for k,v in (d.get('features') or {}).items()})
                    except Exception:
                        pass
                if c.captures:
                    c.highest_stage=max(c.captures,key=lambda x:STAGE_RANK.get(x,0))
        if EVENT_FILE.exists():
            with EVENT_FILE.open('r',encoding='utf-8',errors='ignore') as f: STATE.event_count=sum(1 for _ in f)
    except Exception:
        pass

load_performance()

FEATURE_KEYS=['rest','volume_accel','buy_pressure','impulse','vwap_gap','micro_breakout','dual_venue','program','trust','pension','institution','foreign']
BASE_FEATURE_WEIGHTS={'rest':1.0,'volume_accel':1.0,'buy_pressure':1.0,'impulse':1.0,'vwap_gap':1.0,'micro_breakout':1.0,'dual_venue':1.0,'program':1.0,'trust':1.0,'pension':1.0,'institution':1.0,'foreign':0.7}

def load_learning():
    try:
        if LEARN_FILE.exists():
            d=json.loads(LEARN_FILE.read_text(encoding='utf-8'))
            w={k:float((d.get('weights') or {}).get(k,1.0)) for k in FEATURE_KEYS}
            STATE.learn={'samples':int(d.get('samples') or 0),'positive':int(d.get('positive') or 0),'weights':w,'last_update':d.get('last_update'),'active':int(d.get('samples') or 0)>=LEARN_MIN_SAMPLES}
        else: STATE.learn['weights']=dict(BASE_FEATURE_WEIGHTS)
    except Exception: STATE.learn['weights']=dict(BASE_FEATURE_WEIGHTS)
load_learning()
try:
    STATE.trained_ids=set()
    if TRAIN_FILE.exists():
        for line in TRAIN_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line); STATE.trained_ids.add(str(x.get('id') or ''))
            except Exception: pass
except Exception: STATE.trained_ids=set()

def learner_weight(k):
    if not STATE.learn.get('active'): return 1.0
    return clamp(float((STATE.learn.get('weights') or {}).get(k,1.0)),1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST)

def norm_signed(v, scale): return clamp(num(v)/max(scale,1),-1,1)

def feature_vector(c:Candidate):
    m=c.metrics; sm=c.smart or {}
    return {
      'rest': clamp(num(m.get('rest_base'))/80,0,1),
      'volume_accel': clamp((num(m.get('volume_accel'))-1)/2.5,0,1),
      'buy_pressure': clamp((num(m.get('buy_pressure'))-50)/30,0,1),
      'impulse': clamp(num(m.get('impulse_60s'))/3,0,1),
      'vwap_gap': clamp(num(m.get('vwap_gap'))/2,0,1),
      'micro_breakout': clamp(num(m.get('micro_breakout'))/2,0,1),
      'dual_venue': 1.0 if m.get('dual_venue') else 0.0,
      'program': norm_signed(sm.get('program_net'), max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),1)),
      'trust': norm_signed(sm.get('trust_net'), max(abs(num(sm.get('institution_net'))),1000)),
      'pension': norm_signed(sm.get('pension_net'), max(abs(num(sm.get('institution_net'))),1000)),
      'institution': norm_signed(sm.get('institution_net'), max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000)),
      'foreign': norm_signed(sm.get('foreign_net'), max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000)),
    }

def persist_learning():
    tmp=LEARN_FILE.with_suffix('.tmp'); tmp.write_text(json.dumps(STATE.learn,ensure_ascii=False,separators=(',',':')),encoding='utf-8'); tmp.replace(LEARN_FILE)

def train_from_mature_captures():
    # Conservative online attribution: one label per capture after 30 minutes.
    now=time.time(); changed=False
    for c in STATE.candidates.values():
        for st,cap in c.captures.items():
            if st not in ('PRESSURE','IGNITION') or now-cap.at<1800: continue
            key=f'{c.code}:{st}:{int(cap.at)}'
            if key in STATE.trained_ids: continue
            fv=cap.features or {}
            if not fv: fv=(c.metrics.get('capture_features') or {}).get(st) or {}
            if not fv: continue
            y=1 if cap.max_return>=2.0 and cap.min_return>-2.5 else 0
            STATE.trained_ids.add(key); STATE.learn['samples']=int(STATE.learn.get('samples') or 0)+1; STATE.learn['positive']=int(STATE.learn.get('positive') or 0)+y
            w=STATE.learn.setdefault('weights',dict(BASE_FEATURE_WEIGHTS)); lr=0.035/max(1,(STATE.learn['samples']/80)**0.5)
            for k in FEATURE_KEYS:
                x=float(fv.get(k) or 0); direction=(1 if y else -1)
                w[k]=round(clamp(float(w.get(k,1.0))+direction*lr*x,1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST),4)
            STATE.learn['last_update']=now_kst(); changed=True
            with TRAIN_FILE.open('a',encoding='utf-8') as f: f.write(json.dumps({'id':key,'label':y,'max_return':cap.max_return,'min_return':cap.min_return,'features':fv,'at':now_kst()},ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.learn['active']=int(STATE.learn.get('samples') or 0)>=LEARN_MIN_SAMPLES
    if changed: persist_learning()

RANK_SPECS=[
 ('orderbook_buy','ka10020',{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]
WEIGHTS={'orderbook_buy':10,'bid_surge':17,'residual_ratio_surge':14,'volume_surge':20,'change_leaders':9,'volume_top':10,'turnover_top':15}

async def kiwoom_post(path, api_id, body):
    token=await TOK.get()
    h={'authorization':f'Bearer {token}','api-id':api_id,'content-type':'application/json;charset=UTF-8'}
    async with httpx.AsyncClient(timeout=8) as c:
        r=await c.post(API+path,headers=h,json=body)
        data=r.json() if r.content else {}
        return r.status_code,data

def extract_rows(obj):
    if isinstance(obj,list):
        if obj and isinstance(obj[0],dict): return obj
        out=[]
        for x in obj: out+=extract_rows(x)
        return out
    if isinstance(obj,dict):
        best=[]
        for _,v in obj.items():
            if isinstance(v,list) and v and isinstance(v[0],dict) and len(v)>len(best): best=v
        return best
    return []

def row_identity(row):
    c=''; n=''
    for k in ['stk_cd','stk_code','code','item','종목코드']:
        if row.get(k): c=code6(row.get(k))
        if c:break
    for k in ['stk_nm','stk_name','name','종목명']:
        if row.get(k): n=str(row.get(k)); break
    return c,n

def capture_json(cap:Capture):
    d=asdict(cap); d['at_kst']=time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(cap.at+SEOUL_OFFSET)); return d

def append_event(c:Candidate, cap:Capture):
    rec={'event':'STAGE_CAPTURE','version':APP_VERSION,'code':c.code,'name':c.name,'stage':cap.stage,'at':cap.at,'at_kst':time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(cap.at+SEOUL_OFFSET)),'price':cap.price,'score':cap.score,'venue':cap.venue,'reasons':c.reasons,'metrics':c.metrics}
    with EVENT_FILE.open('a',encoding='utf-8') as f: f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.event_count+=1

def update_capture_performance(c:Candidate):
    if c.last_price<=0:return
    for cap in c.captures.values():
        if cap.price<=0:continue
        cap.current_price=c.last_price; cap.current_return=round((c.last_price/cap.price-1)*100,2)
        if cap.max_price<=0 or c.last_price>cap.max_price:cap.max_price=c.last_price
        if cap.min_price<=0 or c.last_price<cap.min_price:cap.min_price=c.last_price
        cap.max_return=round((cap.max_price/cap.price-1)*100,2)
        cap.min_return=round((cap.min_price/cap.price-1)*100,2)

def maybe_capture(c:Candidate, new_stage:str):
    if not c.last_price or STAGE_RANK.get(new_stage,0)<1:return
    if new_stage not in c.captures:
        fv=feature_vector(c); cap=Capture(new_stage,time.time(),c.last_price,c.score,c.venue or c.last_fid9081,max_price=c.last_price,min_price=c.last_price,current_price=c.last_price,features=fv)
        c.captures[new_stage]=cap; c.metrics.setdefault('capture_features',{})[new_stage]=fv; append_event(c,cap)
    if STAGE_RANK[new_stage]>STAGE_RANK.get(c.highest_stage,0): c.highest_stage=new_stage
    update_capture_performance(c)

def persist_performance(force=False):
    now=time.time()
    if not force and now-STATE.last_persist<10:return
    rows={}
    for c in STATE.candidates.values():
        if c.captures:
            rows[c.code]={'name':c.name,'last_price':c.last_price,'stage':c.stage,'captures':{k:capture_json(v) for k,v in c.captures.items()}}
    tmp=STATE_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'version':APP_VERSION,'updated_at':now_kst(),'rows':rows},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(STATE_FILE); STATE.last_persist=now

def today_kst(): return time.strftime('%Y%m%d',time.gmtime(now_kst_epoch()))

def first_row(j, keys=()):
    for k in keys:
        v=j.get(k) if isinstance(j,dict) else None
        if isinstance(v,list) and v and isinstance(v[0],dict): return v[0]
    rows=extract_rows(j); return rows[0] if rows else {}

def first_num(row, keys):
    for k in keys:
        if k in row and str(row.get(k) or '').strip()!='': return num(row.get(k))
    return 0.0

async def poll_investor(c:Candidate):
    body={'dt':today_kst(),'stk_cd':c.code,'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1'}
    status,j=await kiwoom_post('/api/dostk/stkinfo','ka10059',body)
    ok=status==200 and int(j.get('return_code',0))==0; STATE.smart_status['ka10059']={'ok':ok,'msg':j.get('return_msg','')}
    if not ok:return
    r=first_row(j,('stk_invsr_orgn','stk_invsr_orgn_chart'))
    c.smart.update({'institution_net':first_num(r,['orgn']),'trust_net':first_num(r,['invtrt']),'pension_net':first_num(r,['penfnd_etc']),'foreign_net':first_num(r,['frgnr_invsr']),'financial_net':first_num(r,['fnnc_invt']),'insurance_net':first_num(r,['insrnc'])})
    c.smart_updated_at=time.time()

async def poll_program(c:Candidate):
    # Official ka90004 stock-level program trading. A server-side schema change only disables this component; other smart-money evidence remains live.
    status,j=await kiwoom_post('/api/dostk/stkinfo','ka90004',{'stk_cd':c.code})
    ok=status==200 and int(j.get('return_code',0))==0; STATE.smart_status['ka90004']={'ok':ok,'msg':j.get('return_msg','')}
    if not ok:return
    r=first_row(j,('stk_prm_trde_prst','stk_prm_trde','prm_trde_prst'))
    buy=first_num(r,['buy_qty','buy_trde_qty','prm_buy_qty','buy_amt','prm_buy_amt'])
    sell=first_num(r,['sell_qty','sel_trde_qty','prm_sell_qty','sell_amt','prm_sell_amt'])
    net=first_num(r,['netprps_qty','netprps','prm_netprps_qty','netprps_amt','prm_netprps_amt'])
    if not net and (buy or sell): net=buy-sell
    prev=num(c.smart.get('program_net')); c.smart.update({'program_buy':buy,'program_sell':sell,'program_prev':prev,'program_net':net,'program_delta':net-prev})
    c.smart_updated_at=time.time()

async def smart_money_loop():
    while True:
        try:
            if not APP_KEY or not SECRET: await asyncio.sleep(5); continue
            top=ranked()[:max(20,WS_LIMIT)]
            if top:
                start=STATE.smart_cursor%len(top); batch=[top[(start+i)%len(top)] for i in range(min(SMART_POLL_BATCH,len(top)))]; STATE.smart_cursor=(start+len(batch))%len(top)
                for c in batch:
                    try: await poll_investor(c)
                    except Exception as e: STATE.smart_status['ka10059']={'ok':False,'msg':str(e)[:100]}
                    await asyncio.sleep(.18)
                    try: await poll_program(c)
                    except Exception as e: STATE.smart_status['ka90004']={'ok':False,'msg':str(e)[:100]}
                    await asyncio.sleep(.18)
                score_all()
            train_from_mature_captures(); persist_performance()
        except Exception: pass
        await asyncio.sleep(SMART_POLL_SECONDS)

async def discovery_loop():
    while True:
        started=time.time(); accum=defaultdict(dict)
        if APP_KEY and SECRET:
            for market in ('001','101'):
                for source,api_id,tpl in RANK_SPECS:
                    body={k:(market if v=='{market}' else v) for k,v in tpl.items()}
                    try:
                        status,j=await kiwoom_post('/api/dostk/rkinfo',api_id,body)
                        rows=extract_rows(j); STATE.rest_status[f'{source}:{market}']={'ok':status==200 and int(j.get('return_code',0))==0,'rows':len(rows),'msg':j.get('return_msg','')}
                        for idx,row in enumerate(rows[:80]):
                            c,n=row_identity(row)
                            if not c:continue
                            accum[c][source]=max(accum[c].get(source,0),WEIGHTS[source]*(1-0.55*idx/max(1,min(len(rows),80))))
                            STATE.get(c,n)
                    except Exception as e: STATE.rest_status[f'{source}:{market}']={'ok':False,'rows':0,'msg':str(e)[:120]}
            async with STATE.lock:
                now=time.time()
                for c,hits in accum.items():
                    cand=STATE.get(c); cand.source_hits=hits; cand.metrics['discovery_overlap']=len(hits); cand.metrics['rest_base']=sum(hits.values())
                for c in list(STATE.candidates):
                    x=STATE.candidates[c]
                    if not x.ticks and now-x.first_seen>1800 and c not in accum:STATE.candidates.pop(c,None)
                score_all(); STATE.generated_at=now; STATE.scan_cycles+=1; STATE.ws_codes=[x.code for x in ranked()[:WS_LIMIT]]
        persist_performance()
        await asyncio.sleep(max(2,DISCOVERY_SECONDS-(time.time()-started)))

def calc(c:Candidate):
    ticks=list(c.ticks); now=time.time(); reasons=[]; sess=market_session()
    rest=min(30,num(c.metrics.get('rest_base'))*0.55)
    if len(c.source_hits)>=3: reasons.append(f'독립순위 {len(c.source_hits)}중첩')
    age_ms=(now-c.last_tick_at)*1000 if c.last_tick_at else 10**12
    if len(ticks)<4 or age_ms>DISPLAY_FRESH_MS:
        c.score=round(rest,1); c.confidence=min(35,len(c.source_hits)*8); c.stage='SEED'
        if not sess['active']: reasons.append('시장 종료 · 실시간 신호 비활성')
        elif c.last_tick_at: reasons.append(f'실체결 stale {age_ms/1000:.1f}s')
        else: reasons.append('실시간 체결 축적 중')
        c.reasons=reasons[:4]; update_capture_performance(c); return
    recent=[t for t in ticks if now-t.ts<=60]; prev=[t for t in ticks if 60<now-t.ts<=180]; r5=[t for t in ticks if now-t.ts<=300]
    if not recent: recent=ticks[-10:]
    p0=recent[0].price; p1=recent[-1].price; impulse=(p1/p0-1)*100 if p0 else 0
    vol60=sum(abs(t.qty) for t in recent); volprev=sum(abs(t.qty) for t in prev)/2 if prev else max(vol60*.65,1); accel=vol60/max(volprev,1)
    signed=sum(t.qty for t in recent); buy_ratio=(signed/vol60*50+50) if vol60 else 50
    pos_ticks=sum(1 for t in recent if t.qty>0); neg_ticks=sum(1 for t in recent if t.qty<0); algo_persistence=(pos_ticks/max(pos_ticks+neg_ticks,1))*100
    prices=[t.price for t in r5 if t.price>0]; breakout=0
    if len(prices)>5:
        old=prices[:-max(2,len(prices)//5)]; oldmax=max(old) if old else max(prices); breakout=max(0,(p1/oldmax-1)*100) if oldmax else 0
    pv=sum(t.price*abs(t.qty) for t in r5); vv=sum(abs(t.qty) for t in r5); vwap=pv/vv if vv else p1; above=(p1/vwap-1)*100 if vwap else 0
    venues={t.venue for t in ticks if now-t.ts<=120 and t.venue in ('KRX','NXT')}; dual=len(venues)==2
    one_tick=max((abs(t.qty) for t in recent),default=0)/max(vol60,1)
    sm=c.smart or {}; inst=num(sm.get('institution_net')); trust=num(sm.get('trust_net')); pension=num(sm.get('pension_net')); foreign=num(sm.get('foreign_net')); prog=num(sm.get('program_net')); prog_delta=num(sm.get('program_delta'))
    inst_scale=max(abs(inst)+abs(foreign),1000000); smart_score=0
    program_ratio=prog/max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),100000)
    algo_score=clamp((algo_persistence-50)*0.18,0,8)+clamp(prog_delta/max(abs(prog),100000)*5,-4,5)
    smart_score+=clamp(program_ratio*12,-10,12)*learner_weight('program')+algo_score
    smart_score+=clamp(trust/inst_scale*12,-8,8)*learner_weight('trust')
    smart_score+=clamp(pension/inst_scale*14,-9,9)*learner_weight('pension')
    smart_score+=clamp(inst/inst_scale*10,-7,7)*learner_weight('institution')
    smart_score+=clamp(foreign/inst_scale*5,-4,4)*learner_weight('foreign')
    score=rest*learner_weight('rest')+clamp((accel-1)*12,0,20)*learner_weight('volume_accel')+clamp((buy_ratio-50)*0.38,0,16)*learner_weight('buy_pressure')+clamp(impulse*3.2,0,15)*learner_weight('impulse')+clamp(above*4.5,0,8)*learner_weight('vwap_gap')+clamp(breakout*6,0,9)*learner_weight('micro_breakout')+(5*learner_weight('dual_venue') if dual else 0)+smart_score
    if c.rate>14:score-=12;reasons.append('과열 추격위험')
    if impulse>4.5:score-=7
    if one_tick>0.5:score-=8;reasons.append('단일체결 편중')
    if accel>=1.7:reasons.append(f'1분 체결가속 {accel:.1f}x')
    if buy_ratio>=60:reasons.append(f'공격매수 우위 {buy_ratio:.0f}%')
    if impulse>=0.7:reasons.append(f'가격 선행 +{impulse:.1f}%')
    if above>=0.2:reasons.append(f'VWAP +{above:.2f}%')
    if breakout>=0.3:reasons.append(f'5분 미세돌파 +{breakout:.2f}%')
    if dual:reasons.append('KRX·NXT 동시확인')
    if algo_score>=4:reasons.append(f'알고리즘 매수 지속 {algo_persistence:.0f}%')
    if prog>0:reasons.append(f'프로그램 순매수 {prog:,.0f}')
    if trust>0:reasons.append(f'투신 순매수 {trust:,.0f}')
    if pension>0:reasons.append(f'연기금 순매수 {pension:,.0f}')
    if inst>0 and (trust>0 or pension>0):reasons.append('기관 수급 동조')
    score=clamp(score); conf=clamp(20+min(35,len(recent)*1.2)+min(25,len(c.source_hits)*6)+(10 if dual else 0))
    stage='IGNITION' if score>=78 else 'PRESSURE' if score>=64 else 'WATCH' if score>=48 else 'SEED'
    # Never call stale/closed data PRESSURE/IGNITION.
    if not sess['active']:stage='SEED';score=min(score,47)
    elif age_ms>FRESH_MS and STAGE_RANK[stage]>STAGE_RANK['WATCH']:stage='WATCH';score=min(score,63);reasons.insert(0,'실체결 freshness 부족')
    c.score=round(score,1); c.confidence=round(conf,0); c.stage=stage; c.reasons=reasons[:5]
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_breakout':round(breakout,2),'dual_venue':dual,'tick_count_60s':len(recent),'fresh':age_ms<=FRESH_MS,'smart_money_score':round(smart_score,2),'algo_score':round(algo_score,2),'algo_persistence':round(algo_persistence,1),'program_net':prog,'program_delta':prog_delta,'trust_net':trust,'pension_net':pension,'institution_net':inst,'foreign_net':foreign,'smart_age_ms':round((now-c.smart_updated_at)*1000) if c.smart_updated_at else None,'learn_active':bool(STATE.learn.get('active'))})
    maybe_capture(c,stage)

def score_all():
    for c in STATE.candidates.values():calc(c)

def ranked():
    rows=list(STATE.candidates.values());rows.sort(key=lambda x:(x.score,x.confidence,x.last_tick_at),reverse=True);return rows

async def ws_loop():
    last_reg=();group=300
    while True:
        if not APP_KEY or not SECRET:await asyncio.sleep(5);continue
        try:
            token=await TOK.get()
            async with websockets.connect(WS,ping_interval=None,close_timeout=3,max_size=4_000_000) as ws:
                STATE.ws_status.update({'connected':True,'last_error':''});await ws.send(json.dumps({'trnm':'LOGIN','token':token}));logged=False
                while True:
                    codes=tuple(STATE.ws_codes[:WS_LIMIT])
                    if logged and codes and codes!=last_reg:
                        group+=1;data=[]
                        for c in codes:data.append({'item':[c],'type':['0B']})
                        for c in codes:data.append({'item':[c+'_NX'],'type':['0B']})
                        for i in range(0,len(data),40):await ws.send(json.dumps({'trnm':'REG','grp_no':str(group+i//40),'refresh':'1','data':data[i:i+40]}))
                        last_reg=codes
                    try:raw=await asyncio.wait_for(ws.recv(),timeout=2.0)
                    except asyncio.TimeoutError:continue
                    STATE.ws_status['last_message_at']=time.time();m=json.loads(raw)
                    if m.get('trnm')=='PING':await ws.send(raw);continue
                    if m.get('trnm')=='LOGIN':
                        if int(m.get('return_code',-1))!=0:raise RuntimeError(m.get('return_msg','LOGIN failed'))
                        logged=True;continue
                    if m.get('trnm')=='REG':
                        if int(m.get('return_code',-1))==0:STATE.ws_status['ack']=STATE.ws_status.get('ack',0)+1
                        continue
                    if m.get('trnm')!='REAL':continue
                    for d in m.get('data',[]):
                        if str(d.get('type'))!='0B':continue
                        v=d.get('values') or {};c=code6(d.get('item') or v.get('9001'))
                        if not c:continue
                        p=abs(num(v.get('10')));q=num(v.get('15'));rate=num(v.get('12'));fid9081=str(v.get('9081') or '').upper()
                        venue=fid9081 if fid9081 in ('KRX','NXT') else ('NXT' if str(d.get('item','')).upper().endswith('_NX') else 'KRX')
                        if p<=0:continue
                        now=time.time();cand=STATE.get(c);cand.last_price=p;cand.rate=rate;cand.venue=venue;cand.last_fid9081=fid9081 or venue;cand.last_tick_at=now
                        cand.ticks.append(Tick(now,p,q,rate,venue,abs(num(v.get('13'))),abs(num(v.get('14')))))
                        STATE.ws_status.update({'last_trade_at':now,'last_trade_code':c,'last_trade_venue':venue,'last_fid9081':cand.last_fid9081})
                        update_capture_performance(cand)
                    score_all();STATE.generated_at=time.time();persist_performance()
        except Exception as e:STATE.ws_status.update({'connected':False,'last_error':str(e)[:180]});await asyncio.sleep(2)

def feed_truth():
    now=time.time();sess=market_session();last=STATE.ws_status.get('last_trade_at') or 0;age_ms=round((now-last)*1000) if last else None
    if not APP_KEY or not SECRET:state='KEYS_MISSING'
    elif not sess['active']:state='MARKET_CLOSED'
    elif STATE.ws_status.get('connected') and age_ms is not None and age_ms<=FRESH_MS:state='LIVE'
    elif STATE.ws_status.get('connected'):state='CONNECTED_WAITING_TICK'
    else:state='DISCONNECTED'
    return {'state':state,'session':sess,'last_trade_at_kst':time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime(last+SEOUL_OFFSET)) if last else None,'last_trade_age_ms':age_ms,'last_trade_code':STATE.ws_status.get('last_trade_code'),'last_trade_venue':STATE.ws_status.get('last_trade_venue'),'last_fid9081':STATE.ws_status.get('last_fid9081')}

app=FastAPI(title='Quant Nova Ignition Radar',version=APP_VERSION)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')

@app.on_event('startup')
async def start():
    asyncio.create_task(discovery_loop(),name='nova-discovery');asyncio.create_task(ws_loop(),name='nova-websocket');asyncio.create_task(smart_money_loop(),name='nova-smart-money')

@app.get('/')
async def root():return FileResponse(BASE/'static/index.html')

@app.get('/api/nova')
async def nova():
    score_all();rows=[];now=time.time();truth=feed_truth()
    for i,c in enumerate(ranked()[:40],1):
        cap=None
        for st in ('IGNITION','PRESSURE','WATCH'):
            if st in c.captures:cap=c.captures[st];break
        evidence={
            'overlap':int(c.metrics.get('discovery_overlap') or 0),'volume_accel':c.metrics.get('volume_accel'),'buy_pressure':c.metrics.get('buy_pressure'),'vwap_gap':c.metrics.get('vwap_gap'),'micro_breakout':c.metrics.get('micro_breakout'),'dual_venue':bool(c.metrics.get('dual_venue')),'tick_count_60s':int(c.metrics.get('tick_count_60s') or 0),'fresh':bool(c.metrics.get('fresh')),'smart_money_score':c.metrics.get('smart_money_score'),'algo_score':c.metrics.get('algo_score'),'algo_persistence':c.metrics.get('algo_persistence'),'program_net':c.metrics.get('program_net'),'program_delta':c.metrics.get('program_delta'),'trust_net':c.metrics.get('trust_net'),'pension_net':c.metrics.get('pension_net'),'institution_net':c.metrics.get('institution_net'),'foreign_net':c.metrics.get('foreign_net'),'smart_age_ms':c.metrics.get('smart_age_ms')
        }
        rows.append({'rank':i,'code':c.code,'name':c.name or c.code,'price':c.last_price,'change_rate':c.rate,'score':c.score,'confidence':c.confidence,'stage':c.stage,'reasons':c.reasons,'metrics':c.metrics,'evidence':evidence,'sources':list(c.source_hits),'venue':c.venue,'fid9081':c.last_fid9081,'last_tick_at_kst':time.strftime('%H:%M:%S',time.gmtime(c.last_tick_at+SEOUL_OFFSET)) if c.last_tick_at else None,'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None,'capture':capture_json(cap) if cap else None,'captures':{k:capture_json(v) for k,v in c.captures.items()}})
    ok_rest=sum(1 for x in STATE.rest_status.values() if x.get('ok'))
    return {'version':APP_VERSION,'generated_at':now_kst(),'threshold':MIN_SCORE,'rows':rows,'feed':truth,'health':{'ws':STATE.ws_status,'rest_ok':ok_rest,'rest_total':len(STATE.rest_status),'candidate_count':len(STATE.candidates),'subscribed':len(STATE.ws_codes),'scan_cycles':STATE.scan_cycles,'event_count':STATE.event_count,'smart_status':STATE.smart_status,'learning':STATE.learn},'policy':{'probability_note':'NOVA Score는 실시간 상대 우선순위입니다. 실제 승률은 누적 성과표본으로 별도 산출해야 합니다.','data_truth':'Kiwoom REST ranking + WebSocket 0B + FID9081 + ka10059 investor flow + ka90004 program flow + freshness gate','universe':'고정 목록 없이 순위 API 중첩으로 계속 재구성'}}

@app.get('/api/performance')
async def performance():
    score_all();out=[]
    for c in STATE.candidates.values():
        for st,cap in c.captures.items():
            out.append({'code':c.code,'name':c.name,'stage':st,**capture_json(cap)})
    out.sort(key=lambda x:x['at'],reverse=True)
    return {'version':APP_VERSION,'count':len(out),'rows':out[:300]}

@app.get('/api/health')
async def health():
    return {'ok':True,'version':APP_VERSION,'feed':feed_truth(),'ws':STATE.ws_status,'rest':STATE.rest_status,'generated_at':now_kst(),'smart_money':STATE.smart_status,'learning':STATE.learn,'data_files':{'events':str(EVENT_FILE),'performance':str(STATE_FILE),'learning':str(LEARN_FILE),'training':str(TRAIN_FILE)}}
