# QUANT NOVA 1.1.0 — Realtime Truth & Performance

핵심 변경:
- 화면/엔진 버전 동기화: NOVA-1.1.0
- KST 시장 세션 인식: 장 종료/세션 공백에는 PRESSURE·IGNITION 비활성
- 실체결 진실: 마지막 체결시각, age(ms), 거래소, FID9081 표시
- freshness gate: 오래된 체결로 상위 신호를 유지하지 않음
- Evidence Panel: 순위중첩, 1분 체결가속, 공격매수, VWAP, 미세돌파, KRX·NXT 동시확인
- Performance Ledger: WATCH/PRESSURE/IGNITION 최초 포착가와 현재/최대/최저 수익률 저장
- `/api/performance` 제공
- `/app/data` 영속화 권장

NOVA Score는 수익확률이 아니라 실시간 우선순위이며, 실제 승률은 축적된 포착 이벤트로 별도 검증해야 합니다.
