from __future__ import annotations
from datetime import datetime,date,timedelta
from zoneinfo import ZoneInfo
import json
from pathlib import Path
KST=ZoneInfo('Asia/Seoul')
_HOLIDAY_FILE=Path(__file__).resolve().parents[2]/'config'/'krx_holidays.json'
try:
    _RAW=json.loads(_HOLIDAY_FILE.read_text(encoding='utf-8'))
    if isinstance(_RAW,dict):
        _h=_RAW.get('holidays') or _RAW.get('dates') or []
        if isinstance(_h,dict):_h=[x for rows in _h.values() for x in (rows or [])]
        _HOLIDAYS=set(str(x).replace('-','') for x in _h)
    elif isinstance(_RAW,list):_HOLIDAYS=set(str(x).replace('-','') for x in _RAW)
    else:_HOLIDAYS=set()
except Exception:_HOLIDAYS=set()

def now_kst() -> datetime:return datetime.now(KST)
def trading_day_for(d:date)->date:
    while not is_trading_date(d):d-=timedelta(days=1)
    return d

def trade_day() -> str:
    # Non-trading weekends/holidays keep the most recent trading-day key. This prevents
    # midnight/weekend rollovers from clearing Friday close candidates before Monday handoff.
    return trading_day_for(now_kst().date()).strftime('%Y%m%d')
def sec_of_day() -> int:
    n=now_kst();return n.hour*3600+n.minute*60+n.second

def is_trading_date(d:date)->bool:return d.weekday()<5 and d.strftime('%Y%m%d') not in _HOLIDAYS
def is_trading_day() -> bool:return is_trading_date(now_kst().date())
def next_trading_day(day:str)->str:
    d=datetime.strptime(day,'%Y%m%d').date()+timedelta(days=1)
    while not is_trading_date(d):d+=timedelta(days=1)
    return d.strftime('%Y%m%d')

def advance_trading_day(day:str,steps:int)->str:
    out=str(day)
    for _ in range(max(0,int(steps))):out=next_trading_day(out)
    return out

def sessions_at(d:date,s:int) -> dict:
    """Continuous-trade session truth for KRX/NXT.

    NXT's 08:00~20:00 operating day contains auction/rest gaps. Realtime trade
    liveness must follow the actual continuous matching windows, otherwise a healthy
    socket is falsely treated as stale during 08:50~09:00:30 or 15:20~15:40.
    """
    wd=is_trading_date(d)
    krx=wd and 9*3600 <= s < 15*3600+30*60
    nxt_pre=wd and 8*3600 <= s < 8*3600+50*60
    nxt_main=wd and 9*3600+30 <= s < 15*3600+20*60
    nxt_after=wd and 15*3600+40*60 <= s < 20*3600
    nxt=nxt_pre or nxt_main or nxt_after
    nxt_phase='PRE' if nxt_pre else 'MAIN' if nxt_main else 'AFTER' if nxt_after else 'CLOSED'
    return {'krx':krx,'nxt':nxt,'active':krx or nxt,'phase':('DUAL' if krx and nxt else 'KRX' if krx else 'NXT' if nxt else 'CLOSED'),'nxt_phase':nxt_phase}

def sessions() -> dict:
    n=now_kst();return sessions_at(n.date(),n.hour*3600+n.minute*60+n.second)

def lifecycle_phase() -> str:
    s=sec_of_day()
    if 19*3600+30*60 <= s < 20*3600:return 'CLOSE_TRACK'
    if s >= 20*3600 or s < 8*3600:return 'PRIOR_CLOSE_FROZEN'
    if 8*3600 <= s < 8*3600+50*60:return 'PREMARKET_RECHECK'
    if 8*3600+50*60 <= s < 9*3600:return 'OPENING_HANDOFF'
    if 9*3600 <= s < 9*3600+10*60:return 'SHAKEOUT_WATCH'
    if 9*3600+10*60 <= s < 10*3600:return 'REVERSAL_WINDOW'
    return 'NORMAL_INTRADAY'
