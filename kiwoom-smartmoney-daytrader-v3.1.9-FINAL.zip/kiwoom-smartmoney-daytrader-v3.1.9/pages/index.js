import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, AlertTriangle, Bell, BookOpen, CheckCircle2, ChevronDown, CircleDollarSign,
  Gauge, LockKeyhole, Plus, RefreshCw, Settings, ShieldAlert, Trash2, TrendingDown,
  TrendingUp, Wifi, WifiOff, X,
} from 'lucide-react';

const EMPTY = {
  connection: { status: 'idle' }, stocks: [], positions: [], alerts: [], risk: {}, settings: {}, watchlist: [], performance: {}, tradeLedger: { rows: [], summary: {} }, preflight: {},
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `요청 실패 ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
function fmt(value, digits = 0) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number.toLocaleString('ko-KR', { maximumFractionDigits: digits }) : '-';
}
function fmtWon(value) {
  const number = Number(value || 0);
  const absolute = Math.abs(number);
  if (absolute >= 100_000_000) return `${(number / 100_000_000).toFixed(1)}억`;
  if (absolute >= 10_000) return `${(number / 10_000).toFixed(0)}만`;
  return fmt(number);
}
function timeAgo(timestamp) {
  if (!timestamp) return '-';
  const seconds = Math.max(0, (Date.now() - Number(timestamp)) / 1000);
  if (seconds < 1) return '방금';
  if (seconds < 60) return `${seconds.toFixed(0)}초 전`;
  return `${(seconds / 60).toFixed(0)}분 전`;
}
function tone(value) { return Number(value) > 0 ? 'text-[#ff6b6b]' : Number(value) < 0 ? 'text-[#4ea1ff]' : 'text-[#d5dde5]'; }
function signalTone(action) {
  if (action === 'BUY') return 'border-[#1c6b46] bg-[#10271d] text-[#55e39a]';
  if (action === 'SELL') return 'border-[#7a2732] bg-[#311219] text-[#ff7b87]';
  if (action === 'EARLY_SELL') return 'border-[#8a4b20] bg-[#2f1d0f] text-[#ffad66]';
  if (action === 'RISK') return 'border-[#6b4b1f] bg-[#28200f] text-[#e7c36a]';
  if (action === 'EARLY') return 'border-[#6a571b] bg-[#2a240f] text-[#f1cf62]';
  if (action === 'BLOCKED') return 'border-[#665218] bg-[#2d2610] text-[#f6d365]';
  return 'border-[#29323d] bg-[#111820] text-[#93a4b5]';
}
function closeActionTone(action) {
  if (action === 'CLOSE_BUY' || action === 'HOLD') return signalTone('BUY');
  if (action === 'EXIT' || action === 'REDUCE') return signalTone('SELL');
  if (action === 'NO_DATA') return signalTone('BLOCKED');
  return signalTone('EARLY');
}
function dateTimeKo(value) {
  if (!value) return '-';
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime()) ? parsed.toLocaleString('ko-KR') : '-';
}
function priceBasisLabel(value) {
  return ({
    NXT_FINAL: '표시가격 NXT 최종가', NXT_CURRENT: '표시가격 NXT 현재가',
    KRX_OFFICIAL_CLOSE: '표시가격 KRX 공식 종가', KRX_CURRENT: '표시가격 KRX 현재/잠정',
    REALTIME_LAST: '실시간 체결가',
  }[value] || '표시가격');
}
function scorePoint(value) {
  const number = Number(value || 0);
  return `${number > 0 ? '+' : ''}${number}`;
}
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((char) => char.charCodeAt(0)));
}
function beep(action = 'BUY') {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = String(action || '').includes('SELL') || action === 'RISK' ? 420 : 820;
    gain.gain.value = 0.06;
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.22);
  } catch (_) {}
}

export default function Home() {
  const [data, setData] = useState(EMPTY);
  const [tab, setTab] = useState('live');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [auth, setAuth] = useState({ checked: false, required: false, authenticated: false });
  const [token, setToken] = useState('');
  const [pushStatus, setPushStatus] = useState('');
  const lastAlertId = useRef(null);
  const liveSignalRef = useRef(new Map());

  const refresh = async (quiet = false) => {
    try {
      const next = await api('/api/dashboard');
      setData(next);
      setError('');
      if (!quiet) setLoading(false);
      const newest = next.alerts && next.alerts[0];
      if (newest && lastAlertId.current && newest.id !== lastAlertId.current) {
        beep(newest.action);
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          new Notification(`${newest.name || newest.code || '종목'} ${newest.action || '알림'}`, { body: newest.message });
        }
      }
      if (newest) lastAlertId.current = newest.id;
    } catch (err) {
      if (err.status === 401) setAuth((prev) => ({ ...prev, required: true, authenticated: false, checked: true }));
      else setError(err.message);
      if (!quiet) setLoading(false);
    }
  };

  useEffect(() => {
    api('/api/auth/check').then((result) => {
      setAuth({ checked: true, required: result.authRequired, authenticated: result.authenticated });
      if (result.authenticated) refresh(); else setLoading(false);
    }).catch((err) => { setError(err.message); setLoading(false); });
  }, []);

  useEffect(() => {
    if (!auth.authenticated) return undefined;
    const timer = setInterval(() => refresh(true), 30_000);
    const source = new EventSource('/api/events');
    source.onmessage = (event) => {
      let payload;
      try { payload = JSON.parse(event.data); } catch (_) { return; }
      if (payload.type === 'stock' && payload.stock) {
        const nextStock = payload.stock;
        const isEarly = nextStock.signal?.action === 'EARLY' && nextStock.signal?.smartMoneyState === 'TURN';
        const isEarlySell = nextStock.signal?.action === 'EARLY_SELL' && nextStock.signal?.earlySellEligible;
        const signalKey = nextStock.signal?.confirmed
          ? `${nextStock.signal.action}:${nextStock.signal.smartMoneyState}`
          : isEarlySell ? `EARLY_SELL:${nextStock.signal.sellPressureGroups || 0}`
            : isEarly ? `EARLY:${nextStock.signal.smartMoneyState}` : 'NONE';
        const previousKey = liveSignalRef.current.get(nextStock.code) || 'NONE';
        if (signalKey !== 'NONE' && signalKey !== previousKey) {
          beep(['SELL', 'EARLY_SELL'].includes(nextStock.signal.action) ? 'SELL' : 'BUY');
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            const scoreText = nextStock.signal.action === 'SELL'
              ? `매도위험 ${nextStock.signal.sellScore || 0}점`
              : nextStock.signal.action === 'EARLY_SELL'
                ? `급락위험 ${nextStock.signal.riskScore || 0}점`
                : `품질 ${nextStock.signal.qualityScore || 0}점`;
            new Notification(`${nextStock.name} ${nextStock.signal.label}`, { body: `${scoreText} · ${fmt(nextStock.price)}원` });
          }
        }
        if (signalKey !== 'NONE' && signalKey !== previousKey) refresh(true);
        liveSignalRef.current.set(nextStock.code, signalKey);
        setData((prev) => ({
          ...prev,
          stocks: [...(prev.stocks || []).filter((stock) => stock.code !== nextStock.code), nextStock],
          connection: payload.connection || prev.connection,
        }));
      } else if (payload.type === 'connection' && payload.connection) {
        setData((prev) => ({ ...prev, connection: payload.connection }));
      }
    };
    source.onerror = () => setError('실시간 화면 연결 재시도 중');
    source.onopen = () => setError('');
    return () => { clearInterval(timer); source.close(); };
  }, [auth.authenticated]);

  const login = async (event) => {
    event.preventDefault();
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ token }) });
      setAuth({ checked: true, required: true, authenticated: true });
      setToken('');
      setLoading(true);
      await refresh();
    } catch (err) { setError(err.message); }
  };

  const enableNotifications = async () => {
    try {
      if (typeof Notification === 'undefined') throw new Error('이 브라우저는 알림 API를 지원하지 않습니다.');
      const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent || '');
      const standalone = window.matchMedia?.('(display-mode: standalone)').matches || navigator.standalone === true;
      if (isIOS && !standalone) {
        throw new Error('아이폰 종료상태 푸시는 Safari 공유 → 홈 화면에 추가 후, 홈 화면 아이콘으로 앱을 열어 설정하세요.');
      }
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') throw new Error('아이폰 알림 권한이 허용되지 않았습니다.');
      if (!('serviceWorker' in navigator)) throw new Error('Service Worker를 지원하지 않습니다.');
      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;
      if (!registration.pushManager) throw new Error('PushManager를 지원하지 않습니다.');
      const keyInfo = await api('/api/push/public-key');
      if (!keyInfo.enabled || !keyInfo.publicKey) throw new Error('서버 VAPID 준비에 실패했습니다.');
      const existing = await registration.pushManager.getSubscription();
      if (existing) await existing.unsubscribe().catch(() => null);
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(keyInfo.publicKey),
      });
      await api('/api/push/subscribe', { method: 'POST', body: JSON.stringify(subscription) });
      const test = await api('/api/push/test', { method: 'POST', body: '{}' });
      setPushStatus(`아이폰 Web Push 실동작 확인 · 테스트 ${test.sent || 0}건 전송`);
      await refresh(true);
    } catch (err) { setPushStatus(err.message); }
  };

  if (!auth.checked || loading) return <Center><RefreshCw className="animate-spin" size={22} /> 데이터 준비 중</Center>;
  if (auth.required && !auth.authenticated) {
    return (
      <Center>
        <form onSubmit={login} className="w-full max-w-sm border border-[#26303b] bg-[#0d131a] rounded-2xl p-6 space-y-4">
          <LockKeyhole className="text-[#f5a623]" />
          <div><h1 className="font-bold text-lg">단타 앱 로그인</h1><p className="text-xs text-[#8190a0] mt-1">서버 환경변수 APP_ACCESS_TOKEN 값을 입력하세요.</p></div>
          <input className="input" type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="접근 암호" autoFocus />
          {error && <div className="text-xs text-[#ff7b87]">{error}</div>}
          <button className="primary-btn w-full" type="submit">로그인</button>
        </form>
      </Center>
    );
  }

  const connected = data.connection && data.connection.status === 'connected';
  const tabs = [
    ['live', Activity, '실시간'], ['ledger', TrendingUp, '종합기록부'], ['watch', Plus, '종목관리'], ['journal', BookOpen, '매매일지'], ['alerts', Bell, '알림'], ['settings', Settings, '설정'],
  ];

  return (
    <div className="min-h-screen bg-[#080b0f] text-[#e6edf3]">
      <header className="sticky top-0 z-30 bg-[#0b1016]/95 backdrop-blur border-b border-[#202832]">
        <div className="max-w-6xl mx-auto px-3 py-3 flex items-start justify-between gap-3">
          <div>
            <div className="text-[10px] tracking-[0.22em] text-[#738191]">KIWOOM REALTIME DAY TRADER · v3.1.9 · READ ONLY</div>
            <h1 className="font-bold text-base mt-0.5">KRX·NXT 실시간·종가 단타 신호</h1>
            <div className="text-[11px] text-[#7e8c99] mt-1">고정 4 + 집중입력 4 + 경량입력 4 · 수익우선 신호·실시간 수익률·종합 발생기록부</div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] ${connected ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#67303a] bg-[#2b1218] text-[#ff7b87]'}`}>
              {connected ? <Wifi size={12} /> : <WifiOff size={12} />}{data.connection?.status || 'idle'}
            </div>
            <div className="text-[10px] text-[#697786]">수신 {data.connection?.lastMessageAt ? new Date(data.connection.lastMessageAt).toLocaleTimeString('ko-KR') : '-'}</div>{data.connection?.marketStatus?.label && <div className="text-[10px] text-[#8b98a5]">{data.connection.marketStatus.label}</div>}
          </div>
        </div>
        {data.risk?.halted && <div className="bg-[#351119] text-[#ff8995] border-t border-[#6b2632] px-3 py-2 text-xs"><ShieldAlert size={13} className="inline mr-1" />신규매수 차단: {data.risk.reasons.join(' · ')} · 매도/청산은 항상 허용</div>}
        {error && <div className="bg-[#30270f] text-[#f2d36b] border-t border-[#5c4c1e] px-3 py-2 text-xs">{error}</div>}
      </header>

      <nav className="sticky top-[88px] z-20 bg-[#0b1016] border-b border-[#202832] overflow-x-auto">
        <div className="max-w-6xl mx-auto px-2 flex">
          {tabs.map(([id, Icon, label]) => <button key={id} onClick={() => setTab(id)} className={`nav-btn ${tab === id ? 'active' : ''}`}><Icon size={14} />{label}</button>)}
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-3 py-4 pb-24">
        {tab === 'live' && <LiveTab data={data} onNotify={enableNotifications} pushStatus={pushStatus} refresh={() => refresh()} />}
        {tab === 'ledger' && <LedgerTab data={data} />}
        {tab === 'watch' && <WatchlistTab data={data} onChanged={() => refresh()} />}
        {tab === 'journal' && <JournalTab data={data} onChanged={() => refresh()} />}
        {tab === 'alerts' && <AlertsTab alerts={data.alerts || []} />}
        {tab === 'settings' && <SettingsTab settings={data.settings || {}} onSaved={() => refresh()} />}
      </main>
    </div>
  );
}

function Center({ children }) { return <div className="min-h-screen bg-[#080b0f] text-[#dce5ed] flex items-center justify-center gap-2 p-5">{children}</div>; }

function LiveTab({ data, onNotify, pushStatus, refresh }) {
  const stocks = data.stocks || [];
  const [snapshotBusy, setSnapshotBusy] = useState(false);
  const [snapshotMessage, setSnapshotMessage] = useState('');
  const ordered = useMemo(() => [...stocks].sort((a, b) => {
    const closeRank = (stock) => ({ CLOSE_BUY: 0, HOLD: 1, WAIT: 2, REDUCE: 3, EXIT: 4, NO_DATA: 5 }[stock.closeDecision?.action] ?? 6);
    const liveRank = (stock) => stock.signal?.confirmed
      ? (stock.signal.action === 'SELL' ? 0 : stock.signal.action === 'BUY' ? 2 : 3)
      : stock.signal?.action === 'EARLY_SELL' ? 1
        : stock.signal?.action === 'RISK' ? 3
          : stock.signal?.action === 'EARLY' ? 4 : 5;
    const usesCloseSnapshot = (stock) => Boolean(
      stock?.dataSource === 'CLOSE_SNAPSHOT'
      || (stock?.marketSnapshot?.phase?.code && stock.marketSnapshot.phase.code !== 'INTRADAY')
    );
    const rankA = usesCloseSnapshot(a) ? closeRank(a) : liveRank(a);
    const rankB = usesCloseSnapshot(b) ? closeRank(b) : liveRank(b);
    return rankA - rankB
      || Number(b.closeDecision?.score || b.signal?.profitPriorityScore || b.signal?.qualityScore || 0) - Number(a.closeDecision?.score || a.signal?.profitPriorityScore || a.signal?.qualityScore || 0);
  }), [stocks]);
  const buys = stocks.filter((s) => s.signal?.confirmed && s.signal.action === 'BUY').length;
  const sells = stocks.filter((s) => s.signal?.confirmed && s.signal.action === 'SELL').length;
  const earlySells = stocks.filter((s) => s.signal?.action === 'EARLY_SELL').length;
  const riskWatches = stocks.filter((s) => s.signal?.action === 'RISK').length;
  const fresh = stocks.filter((s) => Date.now() - Number(s.liveUpdatedAt || s.updatedAt || 0) < 2500).length;
  const closeReady = stocks.filter((s) => Number(s.marketSnapshot?.krx?.close || 0) > 0).length;
  const closeBuys = stocks.filter((s) => s.closeDecision?.action === 'CLOSE_BUY').length;
  const promoted = stocks.filter((s) => s.tier === 'LIGHT' && s.activeTier === 'FOCUS').length;
  const perf = data.performance?.quality85Plus || {};
  const winRate = perf.winRate == null ? '-' : `${Number(perf.winRate).toFixed(1)}%`;
  const syncSnapshots = async () => {
    setSnapshotBusy(true); setSnapshotMessage('종가·일봉 동기화 중…');
    try {
      const result = await api('/api/snapshots', { method: 'POST', body: '{}' });
      setSnapshotMessage(`종가 ${result.completed || 0}/${result.requested || stocks.length}종목 갱신`);
      await refresh();
    } catch (err) { setSnapshotMessage(err.message); }
    finally { setSnapshotBusy(false); }
  };

  return <div className="space-y-4">
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
      <Summary label="실시간 수신" value={`${fresh}/${stocks.length}`} icon={Wifi} />
      <Summary label="종가 확보" value={`${closeReady}/${stocks.length}`} icon={CircleDollarSign} positive={closeReady === stocks.length && stocks.length > 0} />
      <Summary label="종가매수 후보" value={closeBuys} icon={TrendingUp} positive />
      <Summary label="확정 매수" value={buys} icon={TrendingUp} positive />
      <Summary label="급락 조기경보" value={earlySells} icon={ShieldAlert} negative />
      <Summary label="급락 전조" value={riskWatches} icon={AlertTriangle} />
      <Summary label="매도·청산" value={sells} icon={TrendingDown} negative />
      <Summary label="85점+ 실증승률" value={`${winRate} · n=${perf.sampleSize || 0}`} icon={Gauge} />
    </div>
    <div className="flex flex-wrap gap-2 items-center">
      <button className="secondary-btn" onClick={onNotify}><Bell size={14} />아이폰 푸시 켜기·테스트</button>
      <button className="secondary-btn" onClick={refresh}><RefreshCw size={14} />전체 동기화</button>
      <button className="secondary-btn" disabled={snapshotBusy} onClick={syncSnapshots}><CircleDollarSign size={14} />{snapshotBusy ? '종가 조회 중' : '종가 동기화'}</button>
      <span className="text-[11px] text-[#7e8c99]">{snapshotMessage || pushStatus || '홈 화면 설치 후 푸시 테스트 가능 · 앱 열린 상태는 SSE 즉시알림'}</span>
    </div>
    <PreflightPanel preflight={data.preflight || {}} />
    <Notice icon={AlertTriangle}>품질점수와 종가점수는 적중확률이 아닙니다. 실제 체결성과를 누적해 별도로 검증해야 합니다.</Notice>
    {closeReady === 0 && <Notice icon={AlertTriangle}>종가 스냅샷이 없습니다. ‘종가 동기화’를 누르면 KRX 일봉·NXT 최종가를 REST로 조회해 저장합니다.</Notice>}
    {!data.connection?.lastMessageAt && closeReady > 0 && <Notice icon={CheckCircle2}>실시간 체결이 없는 시간에는 저장된 KRX 종가·NXT 최종가와 종가판단을 표시합니다.</Notice>}
    <ActiveSignalBoard data={data} />
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
      {ordered.map((stock) => <StockCard key={stock.code} stock={stock} settings={data.settings || {}} risk={data.risk || {}} />)}
    </div>
  </div>;
}
function Summary({ label, value, icon: Icon, positive, negative, valueClass = '' }) {
  return <div className="panel p-3"><div className="flex items-center gap-1.5 text-[11px] text-[#7e8c99]"><Icon size={13} />{label}</div><div className={`text-xl font-bold mt-1 ${positive ? 'text-[#55e39a]' : negative ? 'text-[#ff7b87]' : valueClass}`}>{value}</div></div>;
}
function Notice({ icon: Icon, children }) { return <div className="border border-[#5a4818] bg-[#29220f] text-[#efd36c] rounded-xl px-3 py-2 text-xs"><Icon size={13} className="inline mr-1" />{children}</div>; }

function PreflightPanel({ preflight }) {
  const snapshots = preflight.snapshots || {};
  const flow = preflight.closingCoreFlow || {};
  const live = preflight.liveFeeds || {};
  const venue = preflight.actualVenue || {};
  const push = preflight.push || {};
  const feed = live.counts || {};
  const ready = preflight.overall === 'READY' || preflight.overall === 'PREMARKET_READY_WITH_LIVE_PENDING';
  const pushOperational = Boolean(push.operational);
  const lastPushTest = push.lastTest?.at ? new Date(push.lastTest.at).toLocaleString('ko-KR') : null;
  return <section className={`rounded-xl border px-3 py-3 ${ready ? 'border-[#254b39] bg-[#0f2119]' : 'border-[#604b1c] bg-[#29220f]'}`}>
    <div className="flex items-center justify-between gap-2"><div className="font-bold text-xs flex items-center gap-1.5"><CheckCircle2 size={14} />장전 사전점검</div><span className="text-[10px] font-bold">{preflight.overall || '확인중'}</span></div>
    <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-2 text-[10px]">
      <div>키움 연결<strong className="block text-sm">{preflight.connectionReady ? '정상' : '확인필요'}</strong></div>
      <div>종가/일봉<strong className="block text-sm">{snapshots.ready || 0}/{snapshots.target || 0}</strong></div>
      <div>공식 마감수급<strong className="block text-sm">{flow.ready || 0}/{flow.target || 0}</strong><span className="block text-[9px] text-[#7f918a]">P {flow.program || 0} · F {flow.foreign || 0} · I {flow.institution || 0}</span></div>
      <div>실시간 핵심피드<strong className="block text-sm">{live.expectedNow ? `${live.ready || 0}/${live.target || 0}` : '장중 대기'}</strong><span className="block text-[9px] text-[#7f918a]">체결 {feed.trade || 0} · 호가 {feed.orderbook || 0} · P {feed.program || 0} · 거래원 {feed.broker || 0}</span></div>
      <div>아이폰 Push<strong className="block text-sm">{pushOperational ? `실동작 확인 · 구독 ${push.subscriptionCount || 0}` : push.vapidConfigured ? `VAPID 정상 · 테스트 필요` : '설정 필요'}</strong>{lastPushTest && <span className="block text-[9px] text-[#7f918a]">최근 테스트 {lastPushTest}</span>}</div>
    </div>
    <div className="mt-2 text-[9px] text-[#8fa09a]">실제체결시장: {venue.expectedNow ? `${venue.known || 0}/${venue.target || 0} KRX/NXT 식별` : '장중 수신 시 KRX/NXT 식별'} · SOR는 경로일 뿐 실제 체결시장으로 단정하지 않습니다.</div>
    <div className="mt-1 text-[9px] text-[#8fa09a]">{preflight.dataStatus || 'DATA_CHECKING'} · 과거 스마트머니는 장중 실제 누적값만 인정하며 휴장 중 임의 생성하지 않습니다.{preflight.missingSummary ? ` · ${preflight.missingSummary}` : ''}</div>
  </section>;
}

function StockCard({ stock, settings, risk }) {
  const signal = stock.signal || {};
  const metrics = signal.metrics || {};
  const snapshot = stock.marketSnapshot || null;
  const closeDecision = stock.closeDecision || snapshot?.decision || null;
  const closingMode = Boolean(snapshot && closeDecision && (stock.dataSource === 'CLOSE_SNAPSHOT' || snapshot.phase?.code !== 'INTRADAY'));
  const liveAge = timeAgo(stock.liveUpdatedAt || stock.updatedAt);
  const priceFresh = Date.now() - Number(stock.liveUpdatedAt || stock.updatedAt || 0) < 2500;
  const liveAction = signal.confirmed
    ? signal.action
    : ['EARLY', 'EARLY_SELL', 'RISK'].includes(signal.action) ? signal.action
      : signal.action === 'BUY' || signal.action === 'SELL' ? 'WAIT' : signal.action;
  const action = closingMode ? closeDecision.action : liveAction;
  const plan = closingMode ? closeDecision.plan : signal.plan;
  const riskBudget = Math.max(0, Number(settings.accountEquity || 0) * Number(settings.maxRiskPerTradePct || 0) / 100);
  const riskPerShare = plan ? Math.max(1, Number(plan.entry || 0) - Number(plan.stop || 0)) : 0;
  const riskQty = riskPerShare > 0 ? Math.floor(riskBudget / riskPerShare) : 0;
  const capitalQty = plan && Number(plan.entry) > 0 ? Math.floor(Number(settings.accountEquity || 0) * Number(settings.maxPositionPct || 33) / 100 / Number(plan.entry)) : 0;
  const suggestedQty = Math.max(0, Math.min(riskQty || 0, capitalQty || riskQty || 0));
  const feedAges = stock.feeds || {};
  const tierLabel = stock.activeTier === 'FOCUS' ? (stock.tier === 'LIGHT' ? '자동승격' : '집중') : '경량';
  const confirmText = closingMode ? (snapshot.phase?.label || '종가 판단')
    : signal.confirmed ? '확정 신호'
      : signal.action === 'EARLY_SELL' ? `급락 조기경보 · 하락압력 ${signal.sellPressureGroups || 0}개`
        : signal.action === 'RISK' ? `급락 전조 · 하락압력 ${signal.sellPressureGroups || 0}개`
          : signal.action === 'EARLY' ? '조기관찰'
            : `체결확인 ${signal.confirmCount || 0}/${signal.requiredConfirmations || 3}`;
  const displayLabel = closingMode ? closeDecision.label : (signal.label || '수신대기');
  const displayTone = closingMode ? closeActionTone(action) : signalTone(action);
  const priceStatus = closingMode
    ? `${snapshot.krx?.dateText || snapshot.krx?.date || ''} · 종가 스냅샷`
    : priceFresh ? liveAge : stock.dataSource === 'REST_SNAPSHOT' ? 'REST 스냅샷' : liveAge;
  const reasonList = closingMode ? closeDecision.reasons : signal.reasons;
  const warningList = closingMode ? closeDecision.warnings : signal.warnings;
  const vetoList = closingMode ? [] : signal.vetoes;
  const krx = snapshot?.krx || {};
  const nxt = snapshot?.nxt || {};
  const indicators = snapshot?.indicators || {};
  const closingFlow = snapshot?.closingFlow || {};
  const flowAvailability = closingFlow.availability || {};
  const completeness = snapshot?.completenessBreakdown || {};
  const isClosedSnapshot = closingMode && ['ALL_CLOSED', 'PRE_OPEN'].includes(snapshot?.phase?.code);
  const displayedChangeAvailable = stock.changePct !== null && stock.changePct !== undefined && Number.isFinite(Number(stock.changePct));
  const closedMetric = (value, formatter, available = true) => {
    if (isClosedSnapshot) return '휴장·미측정';
    if (!available) return '미수신';
    return formatter(value);
  };
  const decisionBasisText = closeDecision?.basis?.decisionPrice === 'KRX_OFFICIAL_CLOSE'
    ? '판단기준 KRX 공식 종가·일봉 · NXT는 괴리 확인/보정만 반영'
    : '판단기준 확인 필요';

  return <section className={`panel overflow-hidden ${action === 'CLOSE_BUY' || signal.confirmed && signal.action === 'BUY' ? 'ring-1 ring-[#2e8b5e]' : action === 'EXIT' || signal.confirmed && signal.action === 'SELL' ? 'ring-1 ring-[#98404b]' : ''}`}>
    <div className="p-3 border-b border-[#202832] flex items-start justify-between gap-2">
      <div>
        <div className="flex items-center gap-2"><span className="font-bold">{stock.name}</span><span className="text-[10px] text-[#728091]">{stock.code} · {stock.marketMode}</span><span className="badge">{tierLabel}</span>{closingMode && <span className="badge">종가</span>}{stock.vi?.active && <span className="badge-danger">VI</span>}</div>
        <div className="flex items-baseline gap-2 mt-1 flex-wrap"><span className="text-2xl font-black">{stock.price ? fmt(stock.price) : '-'}</span><span className={`text-sm font-bold ${displayedChangeAvailable ? tone(stock.changePct) : 'text-[#718091]'}`}>{displayedChangeAvailable ? `${Number(stock.changePct) > 0 ? '+' : ''}${Number(stock.changePct).toFixed(2)}%` : '등락률 미수집'}</span><span className={`text-[10px] ${closingMode || priceFresh ? 'text-[#55e39a]' : 'text-[#ff7b87]'}`}>{closingMode ? `${priceBasisLabel(stock.priceBasis)} · ${priceStatus}` : priceStatus}</span></div>
      </div>
      <div className={`border rounded-lg px-2.5 py-1.5 text-center min-w-[112px] ${displayTone}`}>
        <div className="text-[10px]">{confirmText}</div><div className="font-bold text-sm">{displayLabel}</div>
      </div>
    </div>
    <div className="p-3">
      {snapshot && <div className="mb-3 rounded-xl border border-[#26313c] bg-[#0a1016] p-2.5">
        <div className="flex justify-between gap-2 items-center mb-2"><div className="text-[11px] font-bold text-[#cbd6df]">KRX·NXT 종가 스냅샷</div><div className="text-[9px] text-[#718091]">{snapshot.phase?.label || '-'} · {dateTimeKo(snapshot.fetchedAt)}</div></div>
        <div className="mb-2 rounded-lg border border-[#2a3540] bg-[#0d151d] px-2.5 py-2 text-[10px] text-[#9eafbf]"><strong className="text-[#d8e2eb]">계산기준 분리:</strong> {decisionBasisText}</div>
        <div className="grid grid-cols-3 gap-2">
          <Metric label={krx.final ? 'KRX 공식 종가' : 'KRX 현재/잠정'} value={krx.close ? `${fmt(krx.close)}원` : '-'} valueClass={tone(krx.changePct)} />
          <Metric label={nxt.final ? 'NXT 최종가' : 'NXT 현재/잠정'} value={nxt.available ? `${fmt(nxt.close)}원` : '미지원'} />
          <Metric label="NXT 괴리율" value={nxt.available ? `${Number(snapshot.nxtGapPct || 0) >= 0 ? '+' : ''}${Number(snapshot.nxtGapPct || 0).toFixed(2)}%` : '-'} valueClass={tone(snapshot.nxtGapPct)} />
          <Metric label="5일 이동평균" value={indicators.ma5 ? fmt(indicators.ma5) : '-'} />
          <Metric label="20일 이동평균" value={indicators.ma20 ? fmt(indicators.ma20) : '-'} />
          <Metric label="20일 거래량비" value={indicators.volumeRatio20 ? `${Number(indicators.volumeRatio20).toFixed(2)}x` : '-'} />
          <Metric label="고가 대비 종가" value={krx.high ? `${Number(indicators.closeFromHighPct || 0).toFixed(2)}%` : '-'} />
          <Metric label="누적 거래량" value={krx.volume ? fmt(krx.volume) : '-'} />
          <Metric label="거래대금" value={krx.tradeAmount ? fmtWon(krx.tradeAmount) : '-'} />
          <Metric label="마감 스마트머니" value={flowAvailability.smartMoney ? closingFlow.smartMoneyState || 'NEUTRAL' : '미수집'} />
          <Metric label="마감 프로그램" value={flowAvailability.program ? fmtWon(closingFlow.programNetAmount) : '미수집'} valueClass={flowAvailability.program ? tone(closingFlow.programNetAmount) : ''} />
          <Metric label="마감 외국계 변화" value={flowAvailability.foreign ? fmt(closingFlow.foreignNetDelta) : '미수집'} valueClass={flowAvailability.foreign ? tone(closingFlow.foreignNetDelta) : ''} />
          <Metric label="마감 기관 순매수" value={flowAvailability.institution ? fmtWon(closingFlow.institutionNet) : '미수집'} valueClass={flowAvailability.institution ? tone(closingFlow.institutionNet) : ''} />
        </div>
        {closeDecision && <div className="mt-2 pt-2 border-t border-[#1d2731]">
          <div className="flex justify-between gap-3 items-center"><div><div className="text-[10px] text-[#8291a0]">종가 판단점수 · 확률 아님</div><div className={`text-lg font-black ${closeDecision.action === 'CLOSE_BUY' || closeDecision.action === 'HOLD' ? 'text-[#55e39a]' : closeDecision.action === 'EXIT' || closeDecision.action === 'REDUCE' ? 'text-[#ff7b87]' : 'text-[#f1cf62]'}`}>{closeDecision.score || 0}점 · {closeDecision.label}</div></div>{snapshot.errors?.length > 0 && <div className="text-[9px] text-[#e5c45c] text-right">일부 조회 제한<br />{snapshot.errors.length}건</div>}</div>
          <details className="mt-2 rounded-lg border border-[#202b35] bg-[#0b1218] px-2.5 py-2 text-[10px]" open>
            <summary className="cursor-pointer font-bold text-[#aebdca]">점수 산출근거 보기</summary>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 mt-2">{(closeDecision.breakdown || []).map((item) => <div key={item.key} className="flex justify-between gap-2 border-b border-[#18212a] pb-1"><span><span className="text-[#9cabb9]">{item.label}</span><span className="block text-[9px] text-[#647383]">{item.detail}</span></span><strong className={item.points > 0 ? 'text-[#55e39a]' : item.points < 0 ? 'text-[#ff7b87]' : item.status === 'missing' ? 'text-[#e5c45c]' : 'text-[#9aa8b5]'}>{scorePoint(item.points)}</strong></div>)}</div>
          </details>
        </div>}
      </div>}
      <div className="grid grid-cols-3 gap-2">
        <Metric label={closingMode ? '종가점수' : '수익우선/품질'} value={closingMode ? `${closeDecision?.score || 0}` : `${signal.profitPriorityScore || 0}/${signal.qualityScore || 0}`} accent={action === 'EXIT' || action === 'REDUCE' ? 'down' : 'up'} />
        <Metric label="데이터 완전성" value={`${closingMode ? Number(snapshot?.completeness || 0).toFixed(0) : Number(signal.dataCompleteness || 0).toFixed(0)}%`} valueClass={closingMode && Number(snapshot?.completeness || 0) < 85 ? 'text-[#e5c45c]' : ''} />
        <Metric label="스마트머니" value={closingMode ? (flowAvailability.smartMoney ? closingFlow.smartMoneyState || 'NEUTRAL' : '미수집') : signal.smartMoneyState || stock.smartMoney?.state || '-'} />
        <Metric label="체결강도" value={closedMetric(metrics.tradeStrength, (v) => v ? `${fmt(v)}%` : '미수신', Boolean(metrics.tradeStrength))} />
        <Metric label="5초 순공격대금" value={closedMetric(metrics.netBuyAmount5s, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.netBuyAmount5s) : ''} />
        <Metric label="매수 가속도" value={closedMetric(metrics.buyAcceleration, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.buyAcceleration) : ''} />
        <Metric label="1분 거래대금" value={closedMetric(metrics.turnover1m, fmtWon, Boolean(feedAges.tradeAt))} />
        <Metric label="1분 RVOL" value={closedMetric(metrics.rvol1m, (v) => v ? `${Number(v).toFixed(2)}x` : '미수신', Boolean(metrics.rvol1m))} />
        <Metric label="공격매수" value={closedMetric(metrics.buyRatio, (v) => v ? `${Number(v).toFixed(1)}%` : '미수신', Boolean(metrics.buyRatio))} />
        <Metric label="VWAP" value={closedMetric(metrics.vwap, (v) => v ? fmt(v) : '미수신', Boolean(metrics.vwap))} />
        <Metric label="호가 불균형" value={closedMetric(metrics.orderbookImbalance, (v) => v ? Number(v).toFixed(2) : '미수신', Boolean(feedAges.orderbookAt))} />
        <Metric label="프로그램 10초" value={closedMetric(metrics.programVelocity10s, fmtWon, Boolean(feedAges.programAt))} valueClass={!isClosedSnapshot ? tone(metrics.programVelocity10s) : ''} />
        <Metric label="대형체결 순매수" value={closedMetric(metrics.largeNetAmount1m, fmtWon, Boolean(feedAges.tradeAt))} valueClass={!isClosedSnapshot ? tone(metrics.largeNetAmount1m) : ''} />
        <Metric label="외국계 변화" value={closedMetric(stock.broker?.foreignNetDelta, fmt, Boolean(feedAges.brokerAt))} valueClass={!isClosedSnapshot ? tone(stock.broker?.foreignNetDelta) : ''} />
        <Metric label="스프레드" value={closedMetric(metrics.spreadBps, (v) => v && v < 9000 ? `${Number(v).toFixed(1)}bp` : '미수신', Boolean(feedAges.orderbookAt))} />
      </div>
      {closingMode && <details className="mt-2 rounded-lg border border-[#202b35] bg-[#0b1218] px-2.5 py-2 text-[10px]"><summary className="cursor-pointer text-[#9eafbf]">데이터 완전성 구성 · KRX {completeness.groups?.krxCore || 0}/35 · 지표 {completeness.groups?.indicators || 0}/20 · NXT {completeness.groups?.nxt || 0}/15 · 마감수급 {completeness.groups?.closingFlow || 0}/30</summary>{completeness.missing?.length > 0 && <div className="mt-1 text-[#e5c45c]">미수집: {completeness.missing.join(', ')}</div>}<div className="mt-1 text-[#718091]">수급소스: {closingFlow.source || '-'}{closingFlow.officialFlow?.errors?.length ? ` · REST 오류 ${closingFlow.officialFlow.errors.length}건` : ''}</div></details>}
      <div className="mt-3 space-y-1">
        {(reasonList || []).slice(0, 5).map((reason, index) => <div key={`r${index}`} className="text-[11px] text-[#72d9a5]"><CheckCircle2 size={11} className="inline mr-1" />{reason}</div>)}
        {(warningList || []).slice(0, 4).map((reason, index) => <div key={`w${index}`} className="text-[11px] text-[#e5c45c]"><AlertTriangle size={11} className="inline mr-1" />{reason}</div>)}
        {(vetoList || []).slice(0, 3).map((reason, index) => <div key={`v${index}`} className="text-[11px] text-[#ff7b87]"><X size={11} className="inline mr-1" />{reason}</div>)}
      </div>
      <div className="mt-3 pt-2 border-t border-[#18212a] text-[10px] text-[#718091] flex flex-wrap gap-x-3 gap-y-1"><span>체결 {feedAges.tradeAt ? timeAgo(feedAges.tradeAt) : '장 종료/미수신'}</span><span>종가 {feedAges.snapshotAt ? timeAgo(feedAges.snapshotAt) : '-'}</span><span>호가 {timeAgo(feedAges.orderbookAt)}</span><span>프로그램 {timeAgo(feedAges.programAt)}</span><span>거래원 {timeAgo(feedAges.brokerAt)}</span><span>표시시장 {stock.market || '-'}</span><span>실제체결 {stock.lastTradeVenue === 'UNKNOWN' || !stock.lastTradeVenue ? (stock.marketMode === 'SOR' ? 'SOR·식별대기' : stock.marketMode || '-') : stock.lastTradeVenue}</span>{stock.lastTradeVenueSource && <span>시장근거 {stock.lastTradeVenueSource}</span>}{stock.tier === 'LIGHT' && <span>승격점수 {stock.promotionScore || 0}</span>}</div>
      {plan && <details className="mt-3 text-xs" open={closingMode}><summary className="cursor-pointer text-[#8ea0b2] flex items-center gap-1"><ChevronDown size={13} />{closingMode ? '종가 기준 매매계획' : '신호 발생 시 위험계획'}</summary><div className="grid grid-cols-4 gap-1 mt-2"><Plan label="손절" value={fmt(plan.stop)} /><Plan label="1차" value={fmt(plan.target1)} /><Plan label="2차" value={fmt(plan.target2)} /><Plan label="3차" value={fmt(plan.target3)} /></div><div className={`mt-2 rounded-lg border px-2.5 py-2 ${risk.halted ? 'border-[#6f2934] bg-[#2a1218] text-[#ff8d97]' : 'border-[#274535] bg-[#102019] text-[#75d9a8]'}`}>{risk.halted ? '계좌 손실 제한으로 신규매수 차단' : `권장 최대 ${fmt(suggestedQty)}주 · 1회 위험예산 ${fmt(riskBudget)}원`}</div></details>}
    </div>
  </section>;
}
function Metric({ label, value, accent, valueClass = '' }) { return <div className="metric"><div>{label}</div><strong className={`${accent === 'up' ? 'text-[#55e39a]' : accent === 'down' ? 'text-[#ff7b87]' : ''} ${valueClass}`}>{value}</strong></div>; }
function Plan({ label, value }) { return <div className="bg-[#0b1117] rounded-md p-1.5 text-center"><div className="text-[9px] text-[#718091]">{label}</div><div className="font-mono mt-0.5">{value}</div></div>; }


function returnTone(value) {
  return Number(value) > 0 ? 'text-[#ff6b6b]' : Number(value) < 0 ? 'text-[#4ea1ff]' : 'text-[#d5dde5]';
}
function returnText(value) {
  if (value == null || !Number.isFinite(Number(value))) return '-';
  const n = Number(value);
  return `${n > 0 ? '+' : ''}${n.toFixed(2)}%`;
}
function ledgerStatusTone(row) {
  if (row.status === 'BUY_ACTIVE') return 'border-[#1c6b46] bg-[#10271d] text-[#55e39a]';
  if (row.status === 'OBSERVING') return 'border-[#6a571b] bg-[#2a240f] text-[#f1cf62]';
  if (row.status === 'SELL_ONLY' || String(row.signalStatus || '').includes('매도')) return 'border-[#7a2732] bg-[#311219] text-[#ff7b87]';
  if (row.status === 'CLOSED') return 'border-[#33404d] bg-[#121a23] text-[#aebdca]';
  return 'border-[#29323d] bg-[#111820] text-[#93a4b5]';
}
function liveLedgerRows(data) {
  const prices = new Map((data.stocks || []).map((stock) => [stock.code, Number(stock.price || 0)]));
  return (data.tradeLedger?.rows || []).map((row) => {
    if (row.status === 'CLOSED' || row.status === 'SELL_ONLY') return row;
    const currentPrice = prices.get(row.code) || Number(row.currentPrice || 0);
    const returnPct = Number(row.entryPrice) > 0 && currentPrice > 0 ? (currentPrice - Number(row.entryPrice)) / Number(row.entryPrice) * 100 : row.returnPct;
    return { ...row, currentPrice: currentPrice || row.currentPrice, returnPct };
  });
}
function ActiveSignalBoard({ data }) {
  const activeRows = liveLedgerRows(data).filter((row) => ['BUY_ACTIVE', 'OBSERVING'].includes(row.status));
  const stocks = data.stocks || [];
  const stockMap = new Map(stocks.map((stock) => [stock.code, stock]));
  const activeMap = new Map(activeRows.map((row) => [row.code, row]));
  const codes = new Set([
    ...activeRows.map((row) => row.code),
    ...stocks.filter((stock) => ['BUY', 'SELL', 'EARLY', 'EARLY_SELL', 'RISK'].includes(stock.signal?.action)).map((stock) => stock.code),
  ]);
  const cards = [...codes].map((code) => {
    const stock = stockMap.get(code) || {};
    const row = activeMap.get(code) || null;
    const action = stock.signal?.action || (row?.status === 'OBSERVING' ? 'EARLY' : row?.status === 'BUY_ACTIVE' ? 'BUY' : 'WAIT');
    const confirmed = Boolean(stock.signal?.confirmed);
    const label = stock.signal?.action === 'BUY'
      ? (confirmed ? '매수신호 확정·발생중' : '매수신호 확인중')
      : stock.signal?.action === 'SELL'
        ? (confirmed ? '매도신호 확정·발생중' : '매도신호 확인중')
        : stock.signal?.action === 'EARLY_SELL'
          ? '급락위험·매도 조기경보'
          : stock.signal?.action === 'RISK'
            ? '급락 전조 관찰'
            : stock.signal?.action === 'EARLY'
              ? '조기관찰 발생중'
              : (row?.signalStatus || '신호 추적중');
    const priority = action === 'SELL' ? 0 : action === 'EARLY_SELL' ? 1 : action === 'RISK' ? 2 : action === 'BUY' && confirmed ? 3 : action === 'BUY' ? 4 : action === 'EARLY' ? 5 : 6;
    const score = action === 'SELL' ? Number(stock.signal?.sellScore || row?.sellScore || 0) : ['EARLY_SELL', 'RISK'].includes(action) ? Number(stock.signal?.riskScore || 0) : Number(stock.signal?.profitPriorityScore || row?.profitPriorityScore || stock.signal?.qualityScore || row?.qualityScore || 0);
    return { code, stock, row, action, label, priority, score };
  }).sort((a, b) => a.priority - b.priority || b.score - a.score).slice(0, 8);
  return <section className="panel overflow-hidden">
    <div className="px-3 py-2.5 border-b border-[#202832] flex items-center justify-between gap-2"><div><h2 className="section-title"><TrendingUp size={15} />매수·매도 신호 한눈에</h2><div className="text-[10px] text-[#718091] mt-1">확인중·발생중·진입 후 수익률을 종목별로 즉시 표시</div></div><span className="badge">검증 전 신호 포함</span></div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-3">
      {cards.length === 0 && <div className="empty md:col-span-2">현재 매수·매도 발생중 신호가 없습니다.</div>}
      {cards.map(({ code, stock, row, action, label }) => {
        const currentPrice = Number(stock.price || row?.currentPrice || 0);
        const quality = Number(stock.signal?.qualityScore || row?.qualityScore || 0);
        const profit = Number(stock.signal?.profitPriorityScore || row?.profitPriorityScore || 0);
        const sell = Number(stock.signal?.sellScore || row?.sellScore || 0);
        return <div key={`sig-${code}`} className={`rounded-xl border px-3 py-2 ${signalTone(action)}`}><div className="flex justify-between gap-2"><strong>{stock.name || row?.name || code}</strong><span className="text-xs font-bold">{label}</span></div><div className="grid grid-cols-3 gap-2 mt-2 text-[10px]"><div>현재가<strong className="block text-sm">{currentPrice ? `${fmt(currentPrice)}원` : '-'}</strong></div><div>진입가<strong className="block text-sm">{row?.entryPrice ? `${fmt(row.entryPrice)}원` : '-'}</strong></div><div>수익률<strong className={`block text-sm ${returnTone(row?.returnPct)}`}>{returnText(row?.returnPct)}</strong></div></div><div className="mt-1 text-[9px] opacity-80">{action === 'SELL' ? `매도 ${sell}점` : ['EARLY_SELL','RISK'].includes(action) ? `급락위험 ${stock.signal?.riskScore || 0}점 · 압력 ${stock.signal?.sellPressureGroups || 0}개` : `수익우선 ${profit}점 · 품질 ${quality}점`}{row?.source === 'SIGNAL' && !row?.verified ? ' · 미검증' : ''}</div></div>;
      })}
    </div>
  </section>;
}
function LedgerTab({ data }) {
  const [filter, setFilter] = useState('all');
  const rows = liveLedgerRows(data);
  const filtered = rows.filter((row) => {
    if (filter === 'active') return ['BUY_ACTIVE', 'OBSERVING'].includes(row.status);
    if (filter === 'closed') return row.status === 'CLOSED';
    if (filter === 'buy') return row.status === 'BUY_ACTIVE' || String(row.signalStatus || '').includes('매수');
    if (filter === 'sell') return row.status === 'SELL_ONLY' || String(row.signalStatus || '').includes('매도');
    return true;
  });
  const summary = data.tradeLedger?.summary || {};
  return <div className="space-y-4">
    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
      <Summary label="발생중" value={summary.active || 0} icon={Activity} positive />
      <Summary label="종료기록" value={summary.closed || 0} icon={BookOpen} />
      <Summary label="승리기록" value={summary.wins || 0} icon={TrendingUp} positive />
      <Summary label="종료 승률" value={summary.winRate == null ? '-' : `${Number(summary.winRate).toFixed(1)}%`} icon={Gauge} />
      <Summary label="평균 수익률" value={summary.averageReturnPct == null ? '-' : returnText(summary.averageReturnPct)} icon={CircleDollarSign} valueClass={returnTone(summary.averageReturnPct)} />
    </div>
    <Notice icon={AlertTriangle}>SIGNAL은 실제 주문 체결이 아니라 신호 발생가 기준 가상 성과이며, POSITION은 사용자가 입력한 실제 체결기록입니다. 200건 전에는 미검증입니다.</Notice>
    <section className="panel overflow-hidden">
      <div className="p-3 border-b border-[#202832] flex flex-wrap gap-2 items-center justify-between"><div><h2 className="section-title"><BookOpen size={16} />종합 발생기록부</h2><p className="help">진입시점·매도시점·현재가·진입가·매도가·실시간 수익률을 한 표에서 확인합니다.</p></div><div className="flex gap-1 overflow-x-auto">{[['all','전체'],['active','발생중'],['buy','매수'],['sell','매도'],['closed','종료']].map(([id,label]) => <button key={id} className={filter === id ? 'primary-btn' : 'secondary-btn'} onClick={() => setFilter(id)}>{label}</button>)}</div></div>
      <div className="overflow-x-auto">
        <table className="ledger-table">
          <thead><tr><th>구분</th><th>상태</th><th>종목</th><th>진입시점</th><th>매도시점</th><th>현재가</th><th>진입가</th><th>매도가</th><th>수익률</th><th>점수</th></tr></thead>
          <tbody>{filtered.length === 0 && <tr><td colSpan="10" className="text-center text-[#718091] py-8">발생기록이 없습니다.</td></tr>}{filtered.map((row) => <tr key={row.id}>
            <td><span className="badge">{row.source === 'POSITION' ? '실제기록' : 'SIGNAL'}</span></td>
            <td><span className={`inline-flex rounded-full border px-2 py-1 text-[10px] font-bold whitespace-nowrap ${ledgerStatusTone(row)}`}>{row.signalStatus || row.status}</span>{!row.verified && row.source === 'SIGNAL' && <div className="text-[9px] text-[#e5c45c] mt-1">미검증</div>}</td>
            <td><strong className="whitespace-nowrap">{row.name || row.code}</strong><div className="text-[9px] text-[#718091]">{row.code}</div></td>
            <td className="whitespace-nowrap">{dateTimeKo(row.entryAt || row.entrySignalAt)}</td>
            <td className="whitespace-nowrap">{dateTimeKo(row.exitAt || row.exitSignalAt)}</td>
            <td className="font-mono text-right">{row.currentPrice ? fmt(row.currentPrice) : '-'}</td>
            <td className="font-mono text-right">{row.entryPrice ? fmt(row.entryPrice) : '-'}</td>
            <td className="font-mono text-right">{row.exitPrice ? fmt(row.exitPrice) : '-'}</td>
            <td className={`font-black text-right ${returnTone(row.returnPct)}`}>{returnText(row.returnPct)}</td>
            <td className="text-right">{row.qualityScore == null ? '-' : `${fmt(row.qualityScore)}점`}{row.profitPriorityScore ? <div className="text-[9px] text-[#55e39a]">수익우선 {fmt(row.profitPriorityScore)}</div> : null}{row.sellScore ? <div className="text-[9px] text-[#ff7b87]">매도 {fmt(row.sellScore)}</div> : null}</td>
          </tr>)}</tbody>
        </table>
      </div>
    </section>
  </div>;
}

function WatchlistTab({ data, onChanged }) {
  const [form, setForm] = useState({ name: '', market: 'SOR', tier: 'FOCUS' });
  const [message, setMessage] = useState('');
  const submit = async (event) => {
    event.preventDefault();
    try {
      await api('/api/watchlist', { method: 'POST', body: JSON.stringify(form) });
      setForm({ name: '', market: 'SOR', tier: 'FOCUS' });
      setMessage('등록했습니다. 집중/경량 구독은 30초 이내 갱신됩니다.');
      onChanged();
    } catch (err) { setMessage(err.message); }
  };
  const remove = async (code) => {
    try { await api(`/api/watchlist?code=${code}`, { method: 'DELETE' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const counts = data.watchCounts || { focus: 0, light: 0 };
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><Plus size={16} />종목 추가</h2>
      <p className="help">종목명만 입력하면 키움 종목 마스터에서 정확한 6자리 코드를 자동 확인해 등록합니다. 집중입력 4개는 체결·10호가·거래원·프로그램을 모두 수신하고, 경량입력 4개는 체결 감시 후 급증 시 자동승격됩니다.</p>
      <div className="text-xs text-[#8b98a5] mt-2">집중 {counts.focus || 0}/4 · 경량 {counts.light || 0}/4</div>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-4 gap-2 mt-3">
        <input className="input md:col-span-1" placeholder="종목명만 입력 (예: 한미반도체)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <select className="input" value={form.market} onChange={(e) => setForm({ ...form, market: e.target.value })}><option value="SOR">SOR 통합</option><option value="KRX">KRX만</option><option value="NXT">NXT만</option></select>
        <select className="input" value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })}><option value="FOCUS">집중입력</option><option value="LIGHT">경량입력</option></select>
        <button className="primary-btn" type="submit"><Plus size={14} />등록</button>
      </form>{message && <div className="text-xs text-[#d6bd65] mt-2">{message}</div>}
    </section>
    <section className="panel overflow-hidden"><div className="p-3 border-b border-[#202832] text-xs text-[#8190a0]">현재 감시 {data.watchlist?.length || 0}종목</div>{(data.watchlist || []).map((stock) => <div key={stock.code} className="px-3 py-3 border-b border-[#18212a] last:border-0 flex justify-between items-center"><div><strong>{stock.name}</strong><span className="ml-2 text-xs text-[#708091]">{stock.code} · {stock.market}</span><span className="ml-2 badge">{stock.fixed ? '고정집중' : stock.tier === 'LIGHT' ? '경량' : '집중'}</span></div>{!stock.fixed && <button className="icon-btn" onClick={() => remove(stock.code)} aria-label="삭제"><Trash2 size={15} /></button>}</div>)}</section>
  </div>;
}
function JournalTab({ data, onChanged }) {
  const [form, setForm] = useState({ code: data.watchlist?.[0]?.code || '', avgPrice: '', quantity: '', initialStopPrice: '', memo: '' });
  const [message, setMessage] = useState('');
  const open = async (event) => {
    event.preventDefault();
    try { const result = await api('/api/positions', { method: 'POST', body: JSON.stringify(form) }); setMessage(result.riskWarning || '포지션을 기록했습니다.'); setForm({ ...form, avgPrice: '', quantity: '', initialStopPrice: '', memo: '' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const close = async (position) => {
    const current = data.stocks?.find((s) => s.code === position.code)?.price || position.avgPrice;
    const exitText = window.prompt('매도 체결가를 입력하세요.', String(current || ''));
    if (!exitText) return;
    const exitPrice = Number(exitText);
    try { await api('/api/positions', { method: 'PUT', body: JSON.stringify({ id: position.id, status: 'closed', exitPrice, exitTime: new Date().toISOString() }) }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const positions = data.positions || [];
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><BookOpen size={16} />수동 체결 기록</h2><p className="help">실제 주문을 전송하지 않습니다. 키움 주문 연동 전까지 체결 후 기록용이며, 서버가 손절·목표가를 실시간 감시합니다.</p>
      <form onSubmit={open} className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3"><select className="input" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })}>{(data.watchlist || []).map((s) => <option key={s.code} value={s.code}>{s.name}</option>)}</select><input className="input" inputMode="decimal" placeholder="매수가" value={form.avgPrice} onChange={(e) => setForm({ ...form, avgPrice: e.target.value })} /><input className="input" inputMode="numeric" placeholder="수량" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /><input className="input" inputMode="decimal" placeholder="최초 손절가(선택)" value={form.initialStopPrice} onChange={(e) => setForm({ ...form, initialStopPrice: e.target.value })} /><button className="primary-btn" type="submit">매수 기록</button></form>{message && <div className="text-xs text-[#e0c563] mt-2">{message}</div>}
    </section>
    <section className="space-y-2">{positions.length === 0 && <div className="empty">매매 기록이 없습니다.</div>}{positions.map((p) => { const live = data.stocks?.find((s) => s.code === p.code); const pnl = p.status === 'closed' ? p.realizedPnl : live?.price ? (live.price - p.avgPrice) * p.quantity : 0; return <div className="panel p-3 flex items-center justify-between gap-3" key={p.id}><div><div className="font-bold">{live?.name || p.code} <span className="text-[10px] text-[#718091]">{p.status === 'closed' ? '청산' : '보유'}</span></div><div className="text-xs text-[#8493a2] mt-1">매수 {fmt(p.avgPrice)}원 × {fmt(p.quantity)}주 · 수정손절 {p.currentStopPrice ? fmt(p.currentStopPrice) : '-'}</div><div className={`text-sm font-bold mt-1 ${tone(pnl)}`}>{pnl >= 0 ? '+' : ''}{fmt(pnl)}원</div></div>{p.status !== 'closed' && <button className="danger-btn" onClick={() => close(p)}>매도 완료 기록</button>}</div>; })}</section>
  </div>;
}

function AlertsTab({ alerts }) { return <div className="space-y-2">{alerts.length === 0 && <div className="empty">아직 알림이 없습니다.</div>}{alerts.map((a) => <div key={a.id} className="panel p-3"><div className="flex justify-between gap-2"><div className={`font-bold text-sm ${a.action === 'BUY' ? 'text-[#55e39a]' : a.action === 'SELL' ? 'text-[#ff7b87]' : ''}`}>{a.name || a.code} {a.action || ''}</div><div className="text-[10px] text-[#6f7d8b]">{new Date(a.time).toLocaleString('ko-KR')}</div></div><div className="text-xs mt-1 text-[#d0d9e1]">{a.message}</div></div>)}</div>; }

function SettingsTab({ settings, onSaved }) {
  const [form, setForm] = useState(settings);
  const [message, setMessage] = useState('');
  useEffect(() => setForm(settings), [settings]);
  const set = (key, value) => setForm({ ...form, [key]: Number(value) });
  const setSignal = (key, value) => setForm({ ...form, signal: { ...(form.signal || {}), [key]: Number(value) } });
  const save = async () => { try { await api('/api/settings', { method: 'PUT', body: JSON.stringify(form) }); setMessage('저장했습니다.'); onSaved(); } catch (err) { setMessage(err.message); } };
  return <div className="space-y-4"><section className="panel p-4"><h2 className="section-title"><ShieldAlert size={16} />계좌 위험 제한</h2><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="당일 시작자산" value={form.dayStartingEquity} onChange={(v) => set('dayStartingEquity', v)} /><Field label="일일 최대손실 %" value={form.dailyMaxLossPct} onChange={(v) => set('dailyMaxLossPct', v)} /><Field label="연속손실 제한" value={form.maxConsecutiveLosses} onChange={(v) => set('maxConsecutiveLosses', v)} /><Field label="최대 동시보유" value={form.maxConcurrentPositions} onChange={(v) => set('maxConcurrentPositions', v)} /><Field label="1회 위험예산 %" value={form.maxRiskPerTradePct} onChange={(v) => set('maxRiskPerTradePct', v)} /><Field label="종목당 자금상한 %" value={form.maxPositionPct} onChange={(v) => set('maxPositionPct', v)} /><Field label="매수 수수료 %" value={form.buyFeePct} onChange={(v) => set('buyFeePct', v)} /><Field label="매도 수수료 %" value={form.sellFeePct} onChange={(v) => set('sellFeePct', v)} /><Field label="매도 세금 %" value={form.sellTaxPct} onChange={(v) => set('sellTaxPct', v)} /></div></section>
    <section className="panel p-4"><h2 className="section-title"><Gauge size={16} />실시간 신호 임계값</h2><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="조기관찰 점수" value={form.signal?.earlyWatchScore} onChange={(v) => setSignal('earlyWatchScore', v)} /><Field label="확정 품질점수" value={form.signal?.minBuyScore} onChange={(v) => setSignal('minBuyScore', v)} /><Field label="강한매수 점수" value={form.signal?.strongBuyScore} onChange={(v) => setSignal('strongBuyScore', v)} /><Field label="최소 수익우선점수" value={form.signal?.minProfitPriorityScore} onChange={(v) => setSignal('minProfitPriorityScore', v)} /><Field label="강한 수익우선점수" value={form.signal?.strongProfitPriorityScore} onChange={(v) => setSignal('strongProfitPriorityScore', v)} /><Field label="데이터 완전성 %" value={form.signal?.minDataCompleteness} onChange={(v) => setSignal('minDataCompleteness', v)} /><Field label="체결 확인 횟수" value={form.signal?.confirmTicks} onChange={(v) => setSignal('confirmTicks', v)} /><Field label="조건 유지 ms" value={form.signal?.confirmHoldMs} onChange={(v) => setSignal('confirmHoldMs', v)} /><Field label="최대 스프레드 bp" value={form.signal?.maxSpreadBps} onChange={(v) => setSignal('maxSpreadBps', v)} /><Field label="최소 체결강도" value={form.signal?.minTradeStrength} onChange={(v) => setSignal('minTradeStrength', v)} /><Field label="최소 1분 거래대금" value={form.signal?.minOneMinuteTurnover} onChange={(v) => setSignal('minOneMinuteTurnover', v)} /><Field label="급락 전조 점수" value={form.signal?.riskWatchScore} onChange={(v) => setSignal('riskWatchScore', v)} /><Field label="급락 조기경보 점수" value={form.signal?.earlySellScore} onChange={(v) => setSignal('earlySellScore', v)} /><Field label="조기경보 하락그룹" value={form.signal?.earlySellMinGroups} onChange={(v) => setSignal('earlySellMinGroups', v)} /><Field label="최소 RVOL" value={form.signal?.minRvol} onChange={(v) => setSignal('minRvol', v)} /><Field label="VWAP 최대이격 %" value={form.signal?.maxVwapExtensionPct} onChange={(v) => setSignal('maxVwapExtensionPct', v)} /><Field label="알림 재발생 초" value={form.signal?.signalCooldownSeconds} onChange={(v) => setSignal('signalCooldownSeconds', v)} /><Field label="승격 15초 거래대금" value={form.signal?.promotionTurnover15s} onChange={(v) => setSignal('promotionTurnover15s', v)} /><Field label="승격 5초 순매수" value={form.signal?.promotionNetBuy5s} onChange={(v) => setSignal('promotionNetBuy5s', v)} /><Field label="승격 유지 초" value={form.signal?.promotionSeconds} onChange={(v) => setSignal('promotionSeconds', v)} /><Field label="동시 자동승격" value={form.signal?.maxPromotedLight} onChange={(v) => setSignal('maxPromotedLight', v)} /></div></section>
    <button className="primary-btn" onClick={save}>설정 저장</button>{message && <span className="text-xs text-[#d8c15f] ml-2">{message}</span>}
  </div>;
}
function Field({ label, value, onChange }) { return <label className="text-xs text-[#8998a7]"><span>{label}</span><input className="input mt-1" type="number" step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value)} /></label>; }
