const { getItem, getList } = require('../../lib/store');
const { mergeWatchlist, countUserTiers } = require('../../lib/stocks');
const { mergeSettings } = require('../../lib/settings');
const { getSnapshot, setSignalSettings } = require('../../lib/realtimeStore');
const { accountRisk } = require('../../lib/risk');
const { getPerformanceSummary } = require('../../lib/signalPerformance');
const { getLedger } = require('../../lib/signalLedger');
const { requireAuth } = require('../../lib/auth');
const { buildPreflight } = require('../../lib/preflight');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    const [userStocks, savedSettings, positions, alerts, performance] = await Promise.all([
      getItem('watchlist:user'), getItem('settings'), getItem('positions'), getList('alerts', 0, 49), getPerformanceSummary(),
    ]);
    const watchlist = mergeWatchlist(userStocks || []);
    const settings = mergeSettings(savedSettings);
    setSignalSettings(settings.signal);
    const snapshot = getSnapshot(watchlist);
    const safePositions = Array.isArray(positions) ? positions : [];
    const tradeLedger = await getLedger({ stocks: snapshot.stocks, positions: safePositions, limit: 300 });
    const preflight = await buildPreflight(snapshot.stocks, snapshot.connection);
    return res.status(200).json({
      ...snapshot,
      preflight,
      positions: safePositions,
      risk: accountRisk(safePositions, settings),
      alerts: Array.isArray(alerts) ? alerts : [],
      tradeLedger,
      watchlist,
      watchCounts: countUserTiers(userStocks || []),
      performance,
      settings,
      readOnly: true,
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
