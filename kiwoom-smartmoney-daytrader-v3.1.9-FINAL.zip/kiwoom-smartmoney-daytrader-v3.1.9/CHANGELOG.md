## v3.1.9 FINAL — 급락 조기경보·실제체결시장·아이폰 Push 사전점검

- RISK → EARLY_SELL → SELL 단계 추가. 기존 BUY/SELL 임계값은 유지.
- SOR는 경로로만 표시하고, 실시간 메시지에서 KRX/NXT가 식별된 경우에만 실제 체결시장으로 확정 표시합니다. 미식별 시 `SOR·식별대기`로 둡니다.
- 장전 사전점검 패널 추가: 종가/일봉, 공식 마감수급, 장중 핵심피드, 체결시장 식별, Push 상태.
- VAPID 자동 생성·영속 보관 및 실제 Web Push 테스트 API/UI 추가.
- 키움 공식 최신 목록 기준 종목별프로그램매매현황 TR을 ka90004로 최종 교정(ka90003은 프로그램순매수상위50).

## v3.1.8 FINAL — 장전 신뢰성 하드닝

- 당시 TR 매핑을 재검토했으나, v3.1.9에서 키움 공식 최신 목록을 다시 대조해 ka90004가 종목별프로그램매매현황임을 확정하고 교정했습니다.
- 프로그램 피드 신선도 기준을 데이터완전성과 BUY 게이트 모두 20초로 통일했습니다.
- 첫 프로그램/거래원 표본에서 가짜 전환·가짜 외국계 변화가 생기지 않도록 baseline 처리했습니다.
- BUY용 스마트머니 준비상태는 체결 5건 이상, 프로그램 2표본 이상을 요구합니다. SELL/STOP/VI 위험청산 경로는 이 준비 게이트와 독립입니다.
- /api/health에 trade/orderbook/program/broker 준비 종목 수를 분리 노출합니다.
- 품질 85, 수익우선 78, 체결강도 118, VWAP 이격 감점 공식은 변경하지 않았습니다.

## v3.1.7 FINAL — 수급 누락 복구·동일 종가 보존

- (당시 적용) 종목별 프로그램매매 REST TR을 ka90004로 변경했으나, v3.1.9에서 공식 최신 목록 재대조 후 ka90004로 최종 교정했습니다.
- 휴장/과거 종가에서 ka90013 일별 프로그램 추이 보강 경로를 추가했습니다.
- 같은 KRX 종가 날짜를 다시 동기화할 때 이미 저장된 마감 스마트머니/프로그램/외국계/기관 수급을 지우지 않고 보존합니다.
- 과거 실시간 스마트머니가 한 번도 저장되지 않은 날짜는 임의 추정값으로 채우지 않습니다.


## v3.1.6 FINAL — profit-priority shadow validation

- Added `blockedByProfitPriority` without changing the 78-point threshold or VWAP extension penalty.
- Signals rejected only by the profit-priority gate are written to a hidden shadow ledger.
- Shadow rows track live price, maximum/minimum return, and the first available return at or after 15 minutes.
- Shadow rows are excluded from alerts, SSE/UI ledgers, and the existing 200-signal quality validation sample.
- AWS Lightsail build uses the public npm registry explicitly and still requires unit, integration, storage, load, and Next.js build success before replacing the old container.
# 변경내역

## v3.1.6

- 종합 발생기록부 추가
  - SIGNAL/실제 POSITION 구분
  - 진입시점·매도시점·현재가·진입가·매도가·실시간/확정 수익률 표시
  - 매수/매도 확인중·확정·조기관찰·목표도달·손절·시간청산 상태 표시
- 실시간 화면에 매수·매도 신호 한눈에 보드 추가
- 수익우선점수 추가
  - 품질·유동성·기대손익비 가점, 스프레드·VWAP 추격 감점
  - BUY에 최소 수익우선점수 게이트 적용
- 단일 로컬 JSON 전체 재기록을 키별 원자 파일 저장으로 변경
- 알림 저장과 포지션 최고가·기록부 현재가 저장 배치화
- Redis 알림을 `LPUSH/LTRIM` 리스트 구조로 저장해 전체 배열 재기록 제거
- 종목별 비동기 후처리 최신상태 병합·동시성 제한·오류계측
- `/api/health`에 이벤트 루프·저장 큐·알림·후처리·메모리 지표 추가
- 저장검사와 12종목/12,000틱 합성 부하검사 추가

## v3.1.2

- 종가 데이터 완전성을 단순 OHLCV 개수로 계산하던 방식을 수정
  - KRX 핵심 35점, 기술지표 20점, NXT 15점, 마감 수급 30점으로 분리
  - 스마트머니·프로그램·외국계 자료가 없으면 더 이상 100%로 표시하지 않음
  - 누락 항목과 영역별 점수를 화면에서 확인 가능
- KRX와 NXT 계산 기준을 명시적으로 분리
  - 종가 판단가격과 이동평균·거래량 지표는 KRX 공식 종가·일봉 사용
  - NXT 가격은 KRX 종가 대비 괴리 확인 및 제한적 점수 보정에만 사용
  - NXT 표시가격에 KRX 등락률이나 NXT 괴리율을 등락률로 혼합하지 않음
- 휴장·장 종료 시 실시간 지표의 0 표시를 `휴장·미측정`으로 변경
- 종가점수의 항목별 가감점과 계산 근거를 화면에 표시
- 저장된 구형 종가 스냅샷을 불러올 때 완전성을 새 기준으로 다시 계산
- 운영 보안 강화
  - production 환경에서 `APP_ACCESS_TOKEN`, `APP_SESSION_SECRET`이 없거나 짧으면 서버 부팅 중단
  - 두 비밀값이 동일한 경우도 부팅 차단
- Safari 실시간/종가 혼합 정렬 회귀검사 유지

## v3.1.0–v3.1.1

- 키움 REST `ka10081` 일봉 OHLCV 스냅샷 추가
- KRX 종가와 NXT 현재/최종가 분리 표시
- 5일·20일 이동평균, 20일 거래량비, 고가 대비 마감 위치 계산
- 종가매수·보유·관망·절반축소·청산 판단 엔진 추가
- 마감 직전 스마트머니·프로그램·외국계 추정값 보존
- 앱 시작·15분 주기·KRX/NXT 종료 시 종가 자동 동기화
- 로컬 JSON 영속 저장과 Docker named volume 지원
- 실시간/종가 혼합 정렬 Safari client-side exception 수정

## v3.0.0

- 고정 집중 4 + 사용자 집중 4 + 사용자 경량 4 구조
- 경량 체결 전용 구독과 자동승격
- 증분 롤링 계산, 스마트머니 상태기계, 다중 확인 조건
- 품질점수와 실증승률 분리
- SSE 즉시전달과 단위·통합검사 추가

## v3.1.6
- 종목관리 입력을 종목명 단일 입력 방식으로 단순화했습니다.
- 등록 시 키움 공식 종목정보 리스트(ka10099)를 조회해 종목명을 정확히 6자리 종목코드로 변환합니다.
- 종목 마스터는 6시간 메모리 캐시하며, 이름을 찾지 못하면 1회 강제 새로고침 후 재검색합니다.
- 등록 후 ka10001로 공식 종목명을 다시 검증합니다.
