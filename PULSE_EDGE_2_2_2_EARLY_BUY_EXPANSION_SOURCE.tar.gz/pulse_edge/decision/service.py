from __future__ import annotations

from datetime import datetime, timezone

from pulse_edge.bridge.service import KrxNxtBridgeService
from pulse_edge.confluence.service import ConfluenceService
from pulse_edge.core.models import Venue
from pulse_edge.decision.engine import PreBuyDecisionEngine
from pulse_edge.decision.models import PreBuyAction, PreBuyDecisionFrame, PreBuyStage
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.ignition.service import IgnitionService
from pulse_edge.patterns.service import PatternCompletionService
from pulse_edge.pullback.service import PullbackSecondWaveService
from pulse_edge.smart_money.service import SmartMoneyService
from pulse_edge.spillover.service import SectorSpilloverService
from pulse_edge.absorption.service import SupplyAbsorptionService


class PreBuyDecisionService:
    def __init__(
        self,
        *,
        features: FeatureEngine,
        smart_money: SmartMoneyService,
        confluence: ConfluenceService,
        ignition: IgnitionService,
        spillover: SectorSpilloverService,
        pullback: PullbackSecondWaveService,
        patterns: PatternCompletionService,
        bridge: KrxNxtBridgeService,
        engine: PreBuyDecisionEngine,
        absorption: SupplyAbsorptionService | None = None,
        upstream_max_age_sec: float = 15.0,
        max_rows: int = 100,
    ) -> None:
        self.features = features
        self.smart_money = smart_money
        self.confluence = confluence
        self.ignition = ignition
        self.spillover = spillover
        self.pullback = pullback
        self.patterns = patterns
        self.bridge = bridge
        self.engine = engine
        self.absorption = absorption
        self.upstream_max_age_sec = max(3.5, float(upstream_max_age_sec))
        self.max_rows = max(10, int(max_rows))
        self.frames: dict[tuple[Venue, str], PreBuyDecisionFrame] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None
        # 2.2.1 current-session slot rotation only; no history restore/feedback.
        self._progress: dict[tuple[Venue, str], tuple[datetime, tuple]] = {}
        self.stagnation_sec = 600.0
        self.prebuy_extension_exclude_pct = 5.0

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> list[PreBuyDecisionFrame]:
        now = asof or datetime.now(timezone.utc)
        rows: list[PreBuyDecisionFrame] = []
        keep: set[tuple[Venue, str]] = set()
        current = self.confluence.top(max(20, min(int(limit), 200)))
        for conf in current:
            age = max(0.0, (now - conf.asof).total_seconds())
            key = (conf.venue, conf.symbol)
            if age > self.upstream_max_age_sec:
                self.frames.pop(key, None)
                continue
            feature = self.features.frames.get(key)
            smart = self.smart_money.frames.get(key)
            bridge = self.bridge.frames.get(conf.symbol) if conf.venue == Venue.NXT else None
            frame = self.engine.evaluate(
                conf,
                feature,
                smart,
                self.ignition.frames.get(key),
                self.spillover.frames.get(key),
                self.pullback.frames.get(key),
                self.patterns.orb_frames.get(key),
                self.patterns.squeeze_frames.get(key),
                self.patterns.reclaim_frames.get(key),
                bridge,
                self.absorption.frames.get(key) if self.absorption is not None and conf.venue == Venue.KRX else None,
                asof=now,
                upstream_age_sec=age,
            )
            if frame.stage == PreBuyStage.DATA_WAIT:
                self.frames.pop(key, None)
                self._progress.pop(key, None)
                continue
            # PRE-BUY is a pre-surge board. Extended names release the slot.
            if frame.change_rate is not None and frame.change_rate >= self.prebuy_extension_exclude_pct:
                self.frames.pop(key, None)
                self._progress.pop(key, None)
                continue
            signature = (
                frame.stage.value, frame.action.value, frame.evidence_count,
                round(frame.confluence_score_100, 1),
                round(frame.smart_flow_score_100 or 0.0, 1),
                frame.primary_route.value,
            )
            prev = self._progress.get(key)
            if prev is None or prev[1] != signature:
                self._progress[key] = (now, signature)
            elif (now - prev[0]).total_seconds() >= self.stagnation_sec:
                self.frames.pop(key, None)
                continue
            self.frames[key] = frame
            keep.add(key)
            rows.append(frame)

        for key in list(self.frames):
            if key not in keep:
                self.frames.pop(key, None)
        live_keys = set(self.confluence.frames) if hasattr(self.confluence, "frames") else keep
        for key in list(self._progress):
            if key not in live_keys:
                self._progress.pop(key, None)
        ranked = self._sorted(list(self.frames.values()))[: self.max_rows]
        self.frames = {(r.venue, r.symbol): r for r in ranked}
        self.last_refresh_at = now
        self.last_error = None
        return self._sorted(rows)

    def top(self, limit: int = 10) -> list[PreBuyDecisionFrame]:
        return self._sorted(list(self.frames.values()))[: max(1, min(int(limit), 100))]

    @staticmethod
    def _sorted(rows: list[PreBuyDecisionFrame]) -> list[PreBuyDecisionFrame]:
        action_order = {
            PreBuyAction.BUY: 5,
            PreBuyAction.STRONG_EARLY_BUY: 4,
            PreBuyAction.EARLY_BUY: 3,
            PreBuyAction.READY: 2,
            PreBuyAction.WATCH: 1,
        }
        order = {
            PreBuyStage.A_PLUS_ELIGIBLE_SHADOW: 7,
            PreBuyStage.ENTRY_ELIGIBLE_SHADOW: 6,
            PreBuyStage.READY_SHADOW: 5,
            PreBuyStage.PREBUY_SHADOW: 4,
            PreBuyStage.PREBUY_WATCH_SHADOW: 3,
            PreBuyStage.BLOCKED_SHADOW: 2,
            PreBuyStage.DATA_WAIT: 1,
        }
        return sorted(
            rows,
            key=lambda x: (
                action_order.get(x.action, 0),
                order.get(x.stage, 0),
                x.evidence_count,
                x.confluence_score_100,
                x.route_score_100 or 0.0,
                x.regime_score_100,
            ),
            reverse=True,
        )
