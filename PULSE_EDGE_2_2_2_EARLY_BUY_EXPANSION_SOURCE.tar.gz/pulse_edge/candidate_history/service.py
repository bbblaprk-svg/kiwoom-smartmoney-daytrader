from __future__ import annotations
from datetime import datetime, timezone
from pulse_edge.core.models import Venue

class CandidateHistoryService:
    """Material-change sampler only. No DB I/O here; main loop flushes batches off event loop."""
    def __init__(self, prebuy, max_queue: int=1000):
        self.prebuy=prebuy
        self.max_queue=max(100,int(max_queue))
        self._last={}
        self._queue=[]
        self.dropped=0
        self.last_sample_at=None
    def sample(self, now=None):
        now=now or datetime.now(timezone.utc)
        frames=list(self.prebuy.frames.values()) if self.prebuy is not None else []
        live=set()
        for f in frames:
            if f.venue != Venue.KRX: continue
            key=(f.venue.value,f.symbol); live.add(key)
            sig=(f.stage.value,f.primary_route.value,round(f.confluence_score_100,1),round(f.smart_flow_score_100 or 0.0,1),f.evidence_count)
            if self._last.get(key)==sig: continue
            reason='FIRST_SEEN' if key not in self._last else 'MATERIAL_CHANGE'
            self._last[key]=sig
            row=(now.isoformat(),f.venue.value,f.symbol,f.stage.value,f.primary_route.value,f.price,f.change_rate,f.confluence_score_100,f.smart_flow_score_100,f.evidence_count,reason)
            if len(self._queue)>=self.max_queue:
                self._queue.pop(0); self.dropped += 1
            self._queue.append(row)
        # Record disappearance once, then release memory. This is diagnostic only.
        for key in list(self._last):
            if key not in live:
                venue,symbol=key
                row=(now.isoformat(),venue,symbol,'REMOVED',None,None,None,None,None,None,'SLOT_RELEASED')
                if len(self._queue)>=self.max_queue:
                    self._queue.pop(0); self.dropped += 1
                self._queue.append(row); self._last.pop(key,None)
        self.last_sample_at=now
    def drain(self, limit=200):
        n=max(1,min(int(limit),500))
        out=self._queue[:n]; del self._queue[:n]; return out
    @property
    def queue_depth(self): return len(self._queue)
