from __future__ import annotations
import sqlite3, threading
from pathlib import Path
from typing import Iterable

class CandidateHistoryStore:
    """One-way diagnostic history. Never read by current ranking/scoring."""
    def __init__(self, path: str) -> None:
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(path, check_same_thread=False, timeout=2.0)
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._db.execute("PRAGMA busy_timeout=2000")
            self._db.execute("""CREATE TABLE IF NOT EXISTS candidate_history (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              event_at TEXT NOT NULL, venue TEXT NOT NULL, symbol TEXT NOT NULL,
              stage TEXT NOT NULL, route TEXT, price REAL, change_rate REAL,
              score REAL, flow REAL, evidence_count INTEGER, reason TEXT NOT NULL
            )""")
            self._db.execute("CREATE INDEX IF NOT EXISTS idx_candidate_recent ON candidate_history(event_at DESC)")
            self._db.commit()
    def append_batch(self, rows: Iterable[tuple]) -> int:
        rows=list(rows)
        if not rows: return 0
        with self._lock:
            self._db.executemany("""INSERT INTO candidate_history
              (event_at,venue,symbol,stage,route,price,change_rate,score,flow,evidence_count,reason)
              VALUES (?,?,?,?,?,?,?,?,?,?,?)""", rows)
            self._db.commit()
        return len(rows)
    def recent(self, limit: int=100) -> list[dict]:
        n=max(1,min(int(limit),500))
        with self._lock:
            self._db.row_factory=sqlite3.Row
            rows=self._db.execute("SELECT * FROM candidate_history ORDER BY id DESC LIMIT ?",(n,)).fetchall()
        return [dict(r) for r in rows]
    def close(self):
        with self._lock:
            self._db.commit(); self._db.close()
