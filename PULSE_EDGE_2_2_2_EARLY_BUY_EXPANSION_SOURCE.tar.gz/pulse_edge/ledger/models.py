from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from pydantic import BaseModel, Field

from pulse_edge.core.models import Venue


class EpisodeStatus(StrEnum):
    ACTIVE = "ACTIVE"
    ENDED = "ENDED"


class OutcomeHorizon(StrEnum):
    M10 = "10M"
    M30 = "30M"
    CLOSE = "CLOSE"
    D1 = "1D"
    D3 = "3D"
    D5 = "5D"


class SignalEpisode(BaseModel):
    episode_id: str
    trading_day: str
    venue: Venue
    symbol: str
    first_seen_at: datetime
    first_seen_price: float | None = None
    first_route: str | None = None
    signal_at: datetime
    signal_price: float
    signal_action: str | None = None
    primary_route: str
    current_stage: str
    last_stage_at: datetime
    last_price: float | None = None
    highest_price: float | None = None
    lowest_price: float | None = None
    mfe_pct: float | None = None
    mae_pct: float | None = None
    evidence_count: int = 0
    confluence_grade: str | None = None
    confluence_score_100: float | None = None
    regime_state: str | None = None
    smart_flow_state: str | None = None
    data_age_sec: float | None = None
    invalidation_price: float | None = None
    status: EpisodeStatus = EpisodeStatus.ACTIVE
    end_at: datetime | None = None
    end_price: float | None = None
    end_reason: str | None = None
    last_update_at: datetime


class SignalEvent(BaseModel):
    event_id: int
    episode_id: str
    event_at: datetime
    event_type: str
    stage: str | None = None
    price: float | None = None
    primary_route: str | None = None
    evidence_count: int | None = None
    confluence_grade: str | None = None
    confluence_score_100: float | None = None
    regime_state: str | None = None
    smart_flow_state: str | None = None
    risk_flags: list[str] = Field(default_factory=list)
    gate_failures: list[str] = Field(default_factory=list)
    details: dict = Field(default_factory=dict)


class SignalOutcome(BaseModel):
    episode_id: str
    horizon: OutcomeHorizon
    due_at: datetime | None = None
    captured_at: datetime | None = None
    price: float | None = None
    return_pct: float | None = None
    late_by_sec: float | None = None
    source_trading_day: str | None = None
    source_kind: str | None = None
    status: str = "PENDING"
