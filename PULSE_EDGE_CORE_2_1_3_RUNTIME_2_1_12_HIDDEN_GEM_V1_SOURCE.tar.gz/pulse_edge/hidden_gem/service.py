from __future__ import annotations
from collections import deque
from datetime import datetime, timedelta, timezone
from math import isfinite
from typing import Any
from pydantic import BaseModel, Field
from pulse_edge.core.models import Venue
from pulse_edge.absorption.models import FactTrust

class HiddenGemFrame(BaseModel):
    venue: Venue
    symbol: str
    asof: datetime
    data_status: str = 'UNAVAILABLE'
    stage: str = 'WATCH'
    score_100: float = 0.0
    purity_score: float = 0.0
    energy_compression: float = 0.0
    ignition_proximity: float = 0.0
    ignition_probability_estimated: float = 0.0
    sustainability_1_5d: float = 0.0
    final_rank_score: float = 0.0
    preemptive_fit: str = 'WATCH'
    price_hold_pass: bool = False
    price: float | None = None
    change_rate: float | None = None
    session_vwap: float | None = None
    vwap_state: str = 'UNAVAILABLE'
    rvol_same_time: float | None = None
    atr_compression: float | None = None
    range_compression: float | None = None
    rising_lows: bool | None = None
    rs_level: float | None = None
    rs_velocity: float | None = None
    sector_name: str | None = None
    sector_rs: float | None = None
    sector_breadth: float | None = None
    ofi_2m: float | None = None
    aggressive_buy_ratio_2m: float | None = None
    large_trade_buy_persistence_2m: float | None = None
    foreign_net: float | None = None
    institution_net: float | None = None
    program_net: float | None = None
    seller_velocity: float | None = None
    absorption_ratio: float | None = None
    absorption_ratio_delta: float | None = None
    microstructure_score_30: float = 0.0
    price_hold_compression_score_25: float = 0.0
    turnover_score_20: float = 0.0
    sector_score_15: float = 0.0
    ignition_score_10: float = 0.0
    reasons: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)

class HiddenGemService:
    '''Replacement decision/ranking brain. Existing feed/runtime are facts only.'''
    def __init__(self, features, absorption=None, sectors=None):
        self.features=features; self.absorption=absorption; self.sectors=sectors
        self.frames: dict[tuple[Venue,str],HiddenGemFrame]={}
        self.last_refresh_at=None; self.last_error=None
        self._last_promoted: dict[tuple[Venue,str],tuple[str,float,datetime]]={}

    @staticmethod
    def _clamp(x,lo=0.0,hi=100.0): return max(lo,min(hi,float(x)))
    @staticmethod
    def _trust_ok(v): return str(getattr(v,'value',v)) in {'LIVE','CONFIRMED'}
    @staticmethod
    def _range(points):
        ps=[p.price for p in points if p.price and p.price>0]
        return None if len(ps)<2 else (max(ps)-min(ps))/ps[-1]*100.0
    @staticmethod
    def _lows(points, chunks=3):
        if len(points)<9:return None
        n=max(3,len(points)//chunks); lows=[]
        for i in range(chunks):
            seg=points[max(0,len(points)-(chunks-i)*n):max(0,len(points)-(chunks-i-1)*n) or None]
            if seg:lows.append(min(p.price for p in seg if p.price>0))
        return len(lows)==chunks and all(b>=a for a,b in zip(lows,lows[1:]))

    def refresh(self, limit=120, asof=None):
        now=asof or datetime.now(timezone.utc); rows=[]
        items=list(self.features.frames.items())
        items.sort(key=lambda kv: kv[1].asof, reverse=True)
        for (venue,symbol),f in items[:max(40,int(limit)*3)]:
            row=self._one(venue,symbol,f,now)
            if row:self.frames[(venue,symbol)]=row; rows.append(row)
        self.last_refresh_at=now; self.last_error=None
        return self._sorted(rows)

    def _one(self,venue,symbol,f,now):
        age=max(0.0,(now-f.asof).total_seconds())
        data_status='LIVE' if age<=3.5 else 'CONFIRMED' if age<=15 else 'STALE'
        a=self.absorption.get(symbol) if venue==Venue.KRX and self.absorption else None
        if a is not None and not self._trust_ok(a.price_trust): data_status='STALE'
        price=f.price; ch=f.change_rate
        if price is None or ch is None:return None
        # Hidden-gem price hard filter. +5% is never a new candidate.
        price_eligible=(-1.0 <= ch <= 3.0)
        hard_overheated=ch>=5.0
        trades=list(self.features.trades.get((venue,symbol),()))
        cutoff=now-timedelta(minutes=30); trades=[p for p in trades if cutoff < p.ts <= now]
        w10=[p for p in trades if p.ts>now-timedelta(minutes=10)]
        prev10=[p for p in trades if now-timedelta(minutes=20)<p.ts<=now-timedelta(minutes=10)]
        r10=self._range(w10); rp=self._range(prev10)
        compression=None if r10 is None or rp in (None,0) else self._clamp((1-r10/rp)*100)
        rising=self._lows(w10)
        vwap_ok=f.session_vwap is not None and price >= f.session_vwap*0.9985
        # PRICE HOLD hard gate: current price resilience + rising lows + VWAP defence + bounded recent damage.
        dd=abs(min(0.0,f.return_10m_pct or 0.0))
        ph_parts=[bool(rising),vwap_ok,dd<=0.8,(f.rs_level is None or f.rs_level>=-0.35)]
        price_hold=sum(ph_parts)>=3 and bool(rising) and vwap_ok
        # Microstructure 30: no duplicate divergence bonus.
        micro=0.0
        if f.aggressive_buy_ratio_2m is not None: micro += self._clamp((f.aggressive_buy_ratio_2m-45)*0.6,0,9)
        if f.ofi_2m is not None: micro += self._clamp((f.ofi_2m+0.15)*20,0,7)
        if f.large_trade_buy_persistence_2m is not None: micro += self._clamp((f.large_trade_buy_persistence_2m-40)*0.14,0,6)
        if a is not None:
            if a.absorption_ratio is not None: micro += self._clamp((a.absorption_ratio-0.5)*8,0,4)
            if a.seller_sell_deceleration_confirmed: micro += 4
        micro=self._clamp(micro,0,30)
        phc=0.0
        phc += 8 if rising else 0; phc += 6 if vwap_ok else 0
        phc += self._clamp(compression or 0,0,100)*0.07
        phc += 4 if dd<=0.5 else 2 if dd<=0.8 else 0
        phc=self._clamp(phc,0,25)
        # TOD RVOL is accepted only in sane bounded range; absurd denominator artifacts never score.
        rv=f.rvol_same_time if f.rvol_same_time is not None and isfinite(f.rvol_same_time) and 0<=f.rvol_same_time<=20 else None
        turn=0.0
        if rv is not None: turn += self._clamp((rv-0.8)*10,0,10)
        if f.money_acceleration is not None and f.money_acceleration>0: turn += 5
        if f.money_velocity_5m is not None and f.money_velocity_5m>0: turn += 3
        if f.large_trade_buy_persistence_2m is not None and f.large_trade_buy_persistence_2m>=60: turn += 2
        turn=self._clamp(turn,0,20)
        sec=self.sectors.frame_for(symbol,now) if self.sectors else None
        sector_rs=(ch-sec.member_median_change) if sec and sec.member_median_change is not None else None
        breadth=(sec.member_positive_ratio if sec and sec.member_positive_ratio is not None else sec.breadth_ratio if sec else None)
        ss=0.0
        if f.rs_level is not None: ss+=self._clamp((f.rs_level+0.5)*4,0,5)
        if sector_rs is not None: ss+=self._clamp((sector_rs+0.5)*3,0,5)
        if breadth is not None: ss+=self._clamp(breadth*5 if breadth<=1 else breadth*0.05,0,5)
        ss=self._clamp(ss,0,15)
        ign=0.0
        if price_hold: ign+=2
        if compression is not None and compression>=30: ign+=2
        if f.ofi_30s is not None and f.ofi_30s>0.12: ign+=2
        if f.aggressive_buy_ratio_30s is not None and f.aggressive_buy_ratio_30s>=55: ign+=2
        if f.money_acceleration is not None and f.money_acceleration>0: ign+=2
        score=self._clamp(micro+phc+turn+ss+ign)
        # Purity rewards under-reaction and penalizes already-released energy.
        purity=95.0
        if ch< -1: purity-=20
        if ch>2.0: purity-=min(35,(ch-2)*18)
        if ch>3: purity-=20
        if hard_overheated: purity=0
        if rv is not None and rv>5: purity-=10
        purity=self._clamp(purity)
        energy=self._clamp((phc/25*35)+(turn/20*30)+(micro/30*35))
        ignition_prox=self._clamp(ign*10 + max(0,score-70)*1.5)
        sustain=self._clamp(50 + (ss/15*25) + (phc/25*20) - max(0,ch-2)*8)
        final=self._clamp(ignition_prox*.45+purity*.30+sustain*.25)
        truth_pass=data_status in {'LIVE','CONFIRMED'} and (venue==Venue.NXT or (a is not None and self._trust_ok(a.investor_trust)))
        # Supply state derives from new score components, not legacy absorption stage/score.
        supply_tight=price_hold and micro>=14 and phc>=15 and turn>=7
        supply_exhaust=supply_tight and (a is None or a.seller_sell_deceleration_confirmed) and (f.ofi_2m is None or f.ofi_2m>=0)
        if hard_overheated: stage='IGNITION'; fit='EXCLUDE'
        elif not truth_pass or not price_hold: stage='WATCH'; fit='WATCH'
        elif score>=94 and supply_exhaust: stage='IGNITION_IMMINENT'; fit='A' if price_eligible else 'B'
        elif score>=88 and supply_tight: stage='PRE_IGNITION'; fit='A' if price_eligible else 'B'
        elif score>=80 and supply_tight: stage='SUPPLY_TIGHT'; fit='B'
        elif score>=70: stage='ABSORB'; fit='WATCH'
        else: stage='WATCH'; fit='WATCH'
        reasons=[]; risks=[]
        if price_hold: reasons.append('PRICE_HOLD_PASS')
        if rising: reasons.append('RISING_LOWS')
        if compression is not None and compression>=30: reasons.append('PRICE_COMPRESSION')
        if rv is not None and rv>=1.3: reasons.append('TOD_RVOL_BUILD')
        if a and a.seller_sell_deceleration_confirmed: reasons.append('SELLING_DECELERATION')
        if f.ofi_2m is not None and f.ofi_2m>0.1: reasons.append('OFI_IMPROVING')
        if not truth_pass: risks.append('DATA_TRUTH_NOT_CONFIRMED')
        if not price_hold: risks.append('PRICE_HOLD_FAIL')
        if hard_overheated: risks.append('ALREADY_5PCT_PLUS')
        return HiddenGemFrame(venue=venue,symbol=symbol,asof=f.asof,data_status=data_status,stage=stage,score_100=round(score,2),
          purity_score=round(purity,2),energy_compression=round(energy,2),ignition_proximity=round(ignition_prox,2),
          ignition_probability_estimated=round(ignition_prox,2),sustainability_1_5d=round(sustain,2),final_rank_score=round(final,2),
          preemptive_fit=fit,price_hold_pass=price_hold,price=price,change_rate=ch,session_vwap=f.session_vwap,
          vwap_state='ABOVE' if vwap_ok else 'BELOW',rvol_same_time=rv,atr_compression=compression,range_compression=compression,
          rising_lows=rising,rs_level=f.rs_level,rs_velocity=f.rs_velocity,sector_name=getattr(sec,'sector_name',None),sector_rs=sector_rs,
          sector_breadth=breadth,ofi_2m=f.ofi_2m,aggressive_buy_ratio_2m=f.aggressive_buy_ratio_2m,
          large_trade_buy_persistence_2m=f.large_trade_buy_persistence_2m,foreign_net=getattr(a,'foreign_net',None),
          institution_net=getattr(a,'institution_net',None),program_net=f.program_net_buy_amount,seller_velocity=getattr(a,'seller_new_sell_velocity_per_min',None),
          absorption_ratio=getattr(a,'absorption_ratio',None),absorption_ratio_delta=getattr(a,'absorption_ratio_delta',None),
          microstructure_score_30=round(micro,2),price_hold_compression_score_25=round(phc,2),turnover_score_20=round(turn,2),
          sector_score_15=round(ss,2),ignition_score_10=round(ign,2),reasons=reasons,risks=risks)

    @staticmethod
    def _sorted(rows):
        return sorted(rows,key=lambda r:(r.preemptive_fit=='A',r.stage in {'PRE_IGNITION','IGNITION_IMMINENT'},r.final_rank_score,r.score_100),reverse=True)
    def top(self,limit=7, venue=None, include_watch=True):
        rows=list(self.frames.values())
        if venue: rows=[r for r in rows if r.venue==venue]
        rows=[r for r in rows if r.change_rate is not None and r.change_rate<5]
        rows=self._sorted(rows)
        qualified=[r for r in rows if r.preemptive_fit in {'A','B'}]
        if qualified:return qualified[:max(1,min(int(limit),20))]
        return rows[:min(3,max(1,int(limit)))] if include_watch else []
