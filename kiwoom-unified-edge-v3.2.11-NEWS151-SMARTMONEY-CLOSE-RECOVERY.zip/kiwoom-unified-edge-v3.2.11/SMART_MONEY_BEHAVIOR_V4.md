# SMART MONEY BEHAVIOR V4 — v3.2.5

## 목적
스마트머니의 실제 알고리즘을 안다고 가정하지 않고, 시장에 남는 **체결·호가·수급·가격반응 흔적**으로 행동상태를 추정한다. `shakeoutScore`는 경험적 추정지수(0~100)이며 검증된 확률이 아니다.

## 상태기계
`ACCUMULATION → SHAKEOUT → TURN → MARKUP → DISTRIBUTION / EXHAUSTION`

- **ACCUMULATION**: 매도 압력이 있어도 가격이 잘 밀리지 않고 매수호가가 재보충되며 프로그램/대형체결이 중립 이상.
- **SHAKEOUT**: 단기 급락·손절 유도형 움직임 + 실제 매도흡수 + 저점방어가 동시 확인. 이 상태만으로 BUY 금지.
- **TURN**: SHAKEOUT/ACCUMULATION 이후 5초 공격매수·매수가속·VWAP 재탈환 또는 프로그램 전환이 확인된 상태.
- **MARKUP**: 15초 순공격매수·체결강도·프로그램·가격돌파가 동행.
- **DISTRIBUTION**: 공격매도 + 프로그램 매도 + 호가 약화가 동시 진행.
- **EXHAUSTION**: 가격은 버티거나 오르지만 체결/프로그램/대형체결이 둔화.

## 점수 중복 방지
스마트머니 상태는 체결·호가·프로그램에서 파생되므로 동일 정보를 다시 큰 가점으로 더하지 않는다. 실시간 품질점수의 행동보정은 TURN +5, MARKUP +4, ACCUMULATION +2, SHAKEOUT +1, DISTRIBUTION -10, EXHAUSTION -8 이내다. 대신 확정 BUY는 **TURN/MARKUP + 행동신뢰도 65 이상**을 필수 게이트로 사용한다.

## KRX·NXT 실시간 구조
- 한 Kiwoom WebSocket 세션에서 KRX `005930`와 NXT `005930_NX`를 각각 등록한다.
- FOCUS는 체결/호가/거래원/프로그램, LIGHT는 체결을 두 거래소에서 수신한다.
- 각 거래소 데이터는 별도 상태로 보관하고, 합산 거래량/거래대금 및 통합 rolling은 실제 도착한 체결만으로 계산한다.
- KRX/NXT 모두 5초 이내 신선할 때 `dualVenueReady=true`로 두 시장의 순공격 방향 일치도를 계산한다. 반대 방향이면 확정 BUY를 보류한다.
- NXT 구독은 8개 단위 배치로 등록하여 특정 NXT 미지원 종목의 실패가 전체 NXT 피드 실패로 번지는 것을 줄인다.

## 장애 방어
- WebSocket 프레임 자체가 45초 이상 없으면 자동 재연결.
- FOCUS 거래소 체결이 12초 이상 stale이면 해당 거래소의 실제 체결시간에만 5초마다 한 종목씩 REST 현재가를 보조 확인한다. NXT는 프리 08:00~08:50, 메인 09:00:30~15:20, 애프터 15:40~20:00(KST)로 구분한다.
- REST 보조 데이터는 화면 연속성과 장애판단에만 쓰며 체결 rolling, 스마트머니 상태, 확정 BUY freshness에는 넣지 않는다. 가짜 체결을 만들지 않기 위함이다.

## 학습
CLOSE_BUY 신호는 KRX 공식 종가를 진입가로 저장하고 TREND/FLOOR_REVERSAL, 스마트머니 행동상태, 행동신뢰도, shakeoutScore, 투신·연기금, NXT 괴리와 함께 결과를 기록한다. 기존 최소표본 게이트와 최대 ±5점 보정은 유지한다.
