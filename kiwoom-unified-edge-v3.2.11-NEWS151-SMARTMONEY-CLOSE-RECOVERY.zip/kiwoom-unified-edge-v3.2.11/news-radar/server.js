require('./lib/loadEnv')();
const { createServer } = require('http');
const fs = require('fs');
const path = require('path');
const { assertCredentials, isAuthenticated, validateAccessToken, setSessionCookie, clearSessionCookie, isSameOrigin } = require('./lib/auth');
const { Poller } = require('./worker/poller');
const { listWatchlist, addToWatchlist, removeFromWatchlist, MAX_ITEMS } = require('./lib/watchlist');
const { listTopics, addTopic, removeTopic, MAX_TOPICS } = require('./lib/macroTopics');
const newsStore = require('./lib/newsStore');
const store = require('./lib/store');
const logger = require('./lib/logger');
const { BackupManager } = require('./lib/backup');
const { rssCacheStats } = require('./lib/sources/rss');
const { buildThemeBriefs } = require('./lib/themeBrief');
const { buildSemiconductorBriefs } = require('./lib/semiconductorBrief');
const { UNIVERSE, EXPANDED_UNIVERSE, getUniverseStats } = require('./lib/autoUniverse');
const { buildAffectedStocks } = require('./lib/affectedStocks');
const { buildEarlyEdges } = require('./lib/earlyEdge');
const { buildForeignLeadBriefs } = require('./lib/foreignLead');
const { buildActiveMonitor, MAX_ACTIVE } = require('./lib/activeMonitor');
const { buildSecondOrderBriefs, buildSecondOrderCandidates, buildExpandedDiscovery } = require('./lib/secondOrder');
const { getMarketPulse, status: marketPulseStatus } = require('./lib/marketPulse');
const { getUsMarketDesk, status: usMarketDeskStatus } = require('./lib/usMarketDesk');
const nextUsSession = require('./lib/nextUsSession');
const { getMarketSnapshots, providerStatus } = require('./lib/marketSnapshot');
const calibrationEngine = require('./lib/predictionCalibration');
const { buildDiscoveryFeed } = require('./lib/discoveryFeed');

assertCredentials();

const poller = new Poller();
const backups = new BackupManager();
global.__NEWS_POLLER__ = poller;
const PUBLIC_DIR = path.join(__dirname, 'public');
const VERSION = process.env.APP_VERSION || '1.5.1';
const loginAttempts = new Map();
const sseConnections = new Set();
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 10;
const MAX_SSE_CONNECTIONS = Math.max(5, Number(process.env.SSE_MAX_CONNECTIONS || 30));

function applySecurityHeaders(res, api = false) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  if (api) res.setHeader('Cache-Control', 'no-store');
}

function sendJson(res, status, data) {
  if (res.writableEnded) return;
  applySecurityHeaders(res, true);
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function sendMethodNotAllowed(res, allowed) {
  res.setHeader('Allow', allowed.join(', '));
  sendJson(res, 405, { error: 'Method Not Allowed' });
}

async function readJson(req, maxBytes = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(Object.assign(new Error('요청 본문이 너무 큽니다.'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (_) { reject(Object.assign(new Error('JSON 형식이 올바르지 않습니다.'), { statusCode: 400 })); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) {
  return String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
}

function requireAuth(req, res) {
  if (isAuthenticated(req)) return true;
  sendJson(res, 401, { error: '인증이 필요합니다.' });
  return false;
}

function requireInternalBridge(req, res) {
  const configured = String(process.env.INTERNAL_BRIDGE_TOKEN || '');
  const provided = String(req.headers['x-internal-bridge-token'] || '');
  if (configured && provided && configured.length === provided.length) {
    const crypto = require('crypto');
    const ok = crypto.timingSafeEqual(Buffer.from(configured), Buffer.from(provided));
    if (ok) return true;
  }
  if (isAuthenticated(req)) return true;
  sendJson(res, 401, { error: '내부 브리지 인증이 필요합니다.' });
  return false;
}

function requireSameOrigin(req, res) {
  if (isSameOrigin(req)) return true;
  sendJson(res, 403, { error: '허용되지 않은 요청 출처입니다.' });
  return false;
}

async function healthPayload(req) {
  const storage = await store.healthCheck();
  const ready = Boolean(storage.ok && poller.started && !poller.stopping);
  const base = { ok: true, ready, version: VERSION, uptimeSec: Math.round(process.uptime()), time: new Date().toISOString() };
  if (!isAuthenticated(req)) return { status: ready ? 200 : 503, body: base };
  const [watchlist, topics, calibration, nextUsForecast] = await Promise.all([listWatchlist(), listTopics(), calibrationEngine.summary(), nextUsSession.summary()]);
  const snapshot = poller.getSnapshot();
  const naverJobCount = watchlist.length + topics.length;
  const naverCycleMinutes = snapshot.settings.naverTickMs
    ? Math.round((naverJobCount * snapshot.settings.naverTickMs / 60000) * 10) / 10
    : null;
  return {
    status: ready ? 200 : 503,
    body: {
      ...base,
      memoryMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      storage,
      store: store.getMetrics(),
      news: newsStore.getStats(),
      rssHttpCache: rssCacheStats(),
      backups: backups.getStatus(),
      poller: snapshot,
      inventory: { watchlist: watchlist.length, watchlistMax: MAX_ITEMS, autoUniverse: UNIVERSE.length, autoUniverseMax: getUniverseStats().max, expandedUniverse: getUniverseStats().expandedCount, expandOnly: getUniverseStats().expandOnlyCount, activeMonitorMax: MAX_ACTIVE, macroTopics: topics.length, naverJobCount, naverCycleMinutes },
      marketSnapshotProvider: providerStatus(),
      globalMarketProvider: marketPulseStatus(),
      usMarketDeskProvider: usMarketDeskStatus(),
      nextUsSessionProvider: nextUsSession.status(),
      calibration: { ...calibration, storage: calibrationEngine.storageStatus() },
      nextUsForecast: { ...nextUsForecast, storage: nextUsSession.storageStatus() },
      sourcesConfigured: {
        official: Boolean(snapshot.settings.officialFeedCount),
        naverPublic: Boolean(snapshot.settings.naverPublicEnabled),
        naver: !snapshot.officialOnlyFreeMode && Boolean(process.env.NAVER_CLIENT_ID && process.env.NAVER_CLIENT_SECRET),
        dart: !snapshot.officialOnlyFreeMode && Boolean(process.env.DART_API_KEY),
        rss: !snapshot.officialOnlyFreeMode && Boolean((process.env.RSS_FEED_URLS || '').trim()),
        finnhub: !snapshot.officialOnlyFreeMode && Boolean(process.env.FINNHUB_API_KEY),
      },
    },
  };
}

function startSse(req, res) {
  if (!requireAuth(req, res)) return;
  if (sseConnections.size >= MAX_SSE_CONNECTIONS) return sendJson(res, 503, { error: '실시간 연결 한도를 초과했습니다.' });
  applySecurityHeaders(res, true);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write('event: ready\ndata: {"ok":true}\n\n');
  sseConnections.add(res);
  const unsubscribe = newsStore.onNewItem((items) => {
    for (const item of items) if (!res.writableEnded) res.write(`event: news\ndata: ${JSON.stringify(item)}\n\n`);
  });
  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(`: ping ${Date.now()}\n\n`);
  }, 20000);
  if (heartbeat.unref) heartbeat.unref();
  const cleanup = () => {
    clearInterval(heartbeat);
    unsubscribe();
    sseConnections.delete(res);
    if (!res.writableEnded) res.end();
  };
  req.once('close', cleanup);
  req.once('aborted', cleanup);
}

function serveStatic(res, fileName, contentType, cacheControl = 'no-cache') {
  const file = path.join(PUBLIC_DIR, fileName);
  fs.readFile(file, (error, data) => {
    if (error) return sendJson(res, 404, { error: 'Not Found' });
    applySecurityHeaders(res, false);
    res.writeHead(200, { 'Content-Type': contentType, 'Content-Length': data.length, 'Cache-Control': cacheControl });
    res.end(data);
  });
}

async function route(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  req.query = Object.fromEntries(url.searchParams.entries());
  const pathname = url.pathname;

  if (pathname === '/' && req.method === 'GET') return serveStatic(res, 'index.html', 'text/html; charset=utf-8');
  if (pathname === '/app.js' && req.method === 'GET') return serveStatic(res, 'app.js', 'application/javascript; charset=utf-8', 'public, max-age=300');
  if (pathname === '/styles.css' && req.method === 'GET') return serveStatic(res, 'styles.css', 'text/css; charset=utf-8', 'public, max-age=300');
  if (pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }

  if (pathname === '/api/auth/check') {
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    return sendJson(res, 200, { authenticated: isAuthenticated(req), version: VERSION });
  }
  if (pathname === '/api/auth/login') {
    if (req.method !== 'POST') return sendMethodNotAllowed(res, ['POST']);
    if (!requireSameOrigin(req, res)) return;
    const ip = clientIp(req);
    const now = Date.now();
    const entry = loginAttempts.get(ip) || { count: 0, startedAt: now };
    if (now - entry.startedAt > LOGIN_WINDOW_MS) { entry.count = 0; entry.startedAt = now; }
    if (entry.count >= MAX_LOGIN_ATTEMPTS) return sendJson(res, 429, { error: '로그인 시도가 너무 많습니다. 잠시 후 다시 시도하세요.' });
    const body = await readJson(req);
    if (!validateAccessToken(String(body.token || ''))) {
      entry.count += 1;
      loginAttempts.set(ip, entry);
      return sendJson(res, 401, { error: '접근 토큰이 올바르지 않습니다.' });
    }
    loginAttempts.delete(ip);
    setSessionCookie(res);
    const accessRefresh = poller.triggerAccessRefresh('login');
    return sendJson(res, 200, { ok: true, accessRefresh });
  }
  if (pathname === '/api/auth/logout') {
    if (req.method !== 'POST') return sendMethodNotAllowed(res, ['POST']);
    if (!requireSameOrigin(req, res)) return;
    clearSessionCookie(res);
    return sendJson(res, 200, { ok: true });
  }
  if (pathname === '/api/events') {
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    return startSse(req, res);
  }
  if (pathname === '/api/health') {
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const payload = await healthPayload(req);
    return sendJson(res, payload.status, payload.body);
  }

  if (pathname === '/api/discovery-feed') {
    if (!requireInternalBridge(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const startedAt = Date.now();
    const items = await newsStore.list({ limit: 250, includeCoverage: true });
    // Kiwoom 통합앱의 30초 후보저수지용 내부 전용 경로.
    // v1.5.1은 수집 시 이미 계산된 matched + relatedStocks TOP3를 재사용해
    // 장중마다 AUTO200 전체를 다시 계산하던 동기식 병목을 제거한다.
    const feed = buildDiscoveryFeed(items, { externalCandidates: [], limit: Number(req.query.limit || 100) });
    const generationMs = Date.now() - startedAt;
    if (generationMs > 1000) logger.warn('discovery_feed_slow', { generationMs, sourceItems: items.length, candidates: feed.candidateCount });
    return sendJson(res, 200, { ...feed, version: VERSION, generationMs, directKiwoomDisabled: true });
  }
  if (pathname === '/api/export') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const payload = await backups.snapshotPayload();
    const body = JSON.stringify(payload);
    applySecurityHeaders(res, true);
    res.setHeader('Content-Disposition', `attachment; filename=kr-news-radar-backup-${payload.exportedAt.slice(0, 10)}.json`);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
    return res.end(body);
  }
  if (pathname === '/api/admin/backup') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'POST') return sendMethodNotAllowed(res, ['POST']);
    if (!requireSameOrigin(req, res)) return;
    const result = await backups.create('manual');
    return sendJson(res, 200, { ok: true, file: result?.fileName, bytes: result?.bytes });
  }
  if (pathname === '/api/news') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('news_api');
    const category = ['stock', 'macro'].includes(req.query.category) ? req.query.category : undefined;
    const limit = Math.max(1, Math.min(500, Number(req.query.limit || 150)));
    const code = String(req.query.code || '').trim().slice(0, 100) || undefined;
    const important = ['1', 'true', 'yes'].includes(String(req.query.important || '').toLowerCase());
    const smart = ['1', 'true', 'yes'].includes(String(req.query.smart || '').toLowerCase());
    const semiai = ['1', 'true', 'yes'].includes(String(req.query.semiai || '').toLowerCase());
    const minScore = req.query.minScore === undefined ? undefined : Number(req.query.minScore);
    return sendJson(res, 200, {
      items: await newsStore.list({ code, category, important, smart, semiai, minScore, limit }),
      accessRefresh,
    });
  }
  if (pathname === '/api/theme-briefs') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('theme_briefs_api');
    const items = await newsStore.list({ limit: 500 });
    return sendJson(res, 200, { items: buildThemeBriefs(items, { limit: 24, perTheme: 3 }), accessRefresh });
  }
  if (pathname === '/api/semiconductor-briefs') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('semiconductor_briefs_api');
    const [items, watchlist] = await Promise.all([newsStore.list({ limit: 700 }), listWatchlist()]);
    return sendJson(res, 200, { items: buildSemiconductorBriefs(items, { limit: 24, perChain: 4, watchlist }), accessRefresh });
  }
  if (pathname === '/api/universe') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const q = String(req.query.q || '').trim().toLowerCase();
    const expanded = ['1','true','yes'].includes(String(req.query.expanded || '').toLowerCase());
    const base = expanded ? EXPANDED_UNIVERSE : UNIVERSE;
    const rows = q ? base.filter((row) => `${row.name} ${(row.roles || []).join(' ')} ${(row.themes || []).join(' ')}`.toLowerCase().includes(q)) : base;
    return sendJson(res, 200, { items: rows.slice(0, expanded ? 300 : 200), stats: getUniverseStats(), scope: expanded ? 'AUTO200+EXPAND' : 'AUTO200' });
  }
  if (pathname === '/api/second-order') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('second_order_api');
    const items = await newsStore.list({ limit: 700, includeCoverage: true });
    return sendJson(res, 200, {
      items: buildSecondOrderBriefs(items, { limit: 30 }),
      candidates: buildSecondOrderCandidates(items, { limit: 50 }),
      universe: getUniverseStats(),
      policy: { mode: 'DIRECT_MEDIA_PLUS_SECOND_ORDER', maxPerArticle: Number(process.env.SECOND_ORDER_MAX_PER_ARTICLE || 5), windowHours: Number(process.env.SECOND_ORDER_WINDOW_HOURS || 48) },
      accessRefresh,
    });
  }
  if (pathname === '/api/market-pulse') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const items = await newsStore.list({ limit: 700, includeCoverage: true });
    const force = ['1','true','yes'].includes(String(req.query.force || '').toLowerCase());
    return sendJson(res, 200, await getMarketPulse(items, { force }));
  }
  if (pathname === '/api/us-market-desk') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const items = await newsStore.list({ limit: 700, includeCoverage: true });
    const force = ['1','true','yes'].includes(String(req.query.force || '').toLowerCase());
    const pulse = await getMarketPulse(items, { force }).catch(() => null);
    return sendJson(res, 200, await getUsMarketDesk(items, pulse, { force }));
  }
  if (pathname === '/api/next-us-session') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const items = await newsStore.list({ limit: 250, includeCoverage: true });
    const force = ['1','true','yes'].includes(String(req.query.force || '').toLowerCase());
    const pulse = await getMarketPulse(items, { force }).catch(() => null);
    const desk = await getUsMarketDesk(items, pulse, { force }).catch(() => null);
    return sendJson(res, 200, await nextUsSession.getNextUsSession(items, pulse, desk, { force }));
  }
  if (pathname === '/api/next-us-session-state') {
    if (!requireAuth(req, res)) return;
    if (req.method === 'GET') {
      const state = await nextUsSession.exportState();
      return sendJson(res, 200, { state, summary: nextUsSession.statsFor(state), storage: nextUsSession.storageStatus() });
    }
    if (req.method !== 'POST') return sendMethodNotAllowed(res, ['GET','POST']);
    if (!requireSameOrigin(req, res)) return;
    const body = await readJson(req, 2 * 1024 * 1024);
    const result = await nextUsSession.importState(body.state || body, { onlyIfEmpty: body.onlyIfEmpty === true });
    return sendJson(res, 200, { restored: result.restored, restoredCount: result.restoredCount || 0, reason: result.reason || null, summary: result.summary, storage: nextUsSession.storageStatus() });
  }
  if (pathname === '/api/early-edge') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('early_edge_api');
    const [items, market] = await Promise.all([newsStore.list({ limit: 700, includeCoverage: true }), getMarketSnapshots()]);
    return sendJson(res, 200, { items: buildEarlyEdges(items, { limit: 20, marketSnapshots: market.map }), universe: getUniverseStats(), maxCandidatesPerNews: 3, scoring: { preposition: '공급망·병목·CAPEX·해외선행', pricedIn: market.status === 'connected' ? '뉴스확산+시세반응' : '뉴스확산 추정(시세연동 대기)' }, market: { status: market.status, updatedAt: market.updatedAt, error: market.error }, accessRefresh });
  }
  if (pathname === '/api/active-monitor') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const items = await newsStore.list({ limit: 700, includeCoverage: true });
    // 뉴스가 조용한 날에도 미국장 2차 영향 후보를 ACTIVE20 후보 풀에 합칩니다.
    // 후보 풀은 40개까지 계산해 보정확률이 TOP20 진입에 실제로 영향을 주게 합니다.
    // Kiwoom 직접호출은 하지 않고 연결된 V3.1.x /api/dashboard를 1회 읽습니다.
    const pulse = await getMarketPulse(items).catch(() => null);
    const usDesk = await getUsMarketDesk(items, pulse).catch(() => null);
    const nextForecast = await nextUsSession.getNextUsSession(items, pulse, usDesk).catch(() => null);
    const externalCandidates = [
      ...(nextForecast?.firstOrder || []),
      ...(nextForecast?.secondOrder || []),
      ...(usDesk?.firstOrder || []),
      ...(usDesk?.secondOrder || []),
      ...((pulse?.analysis?.domesticCandidates || []).map((row) => ({ ...row, direction: row.direction || 'positive', depth: row.depth || 2 }))),
    ];
    const preliminary = buildActiveMonitor(items, { snapshots: {}, limit: 40, externalCandidates });
    const market = await getMarketSnapshots({ targets: preliminary.slice(0, MAX_ACTIVE), force: ['1','true','yes'].includes(String(req.query.force || '').toLowerCase()) });
    let rawItems = buildActiveMonitor(items, { snapshots: market.map, limit: 40, externalCandidates });
    const missingSet = new Set((market.missing || []).map((x) => String(x)));
    if ((market.provider || '') === 'smartmoney-bridge') {
      rawItems = rawItems.map((row) => {
        const missing = !row.quoteConnected && (missingSet.has(String(row.code || '')) || missingSet.has(String(row.name || '')));
        return {
          ...row,
          quoteStatus: row.quoteConnected ? '공유시세 수신' : (missing ? '공유앱 미감시' : '공유시세 대기'),
          management: row.quoteConnected ? row.management : (missing ? '공유앱 미감시' : row.management),
        };
      });
    }
    const calibrated = await calibrationEngine.observeAndCalibrate(rawItems, market.map || {});
    const finalItems = calibrated.rows.slice(0, MAX_ACTIVE);
    const ps = providerStatus();
    return sendJson(res, 200, {
      items: finalItems,
      max: MAX_ACTIVE,
      universe: getUniverseStats(),
      calibration: calibrated.summary,
      market: {
        status: market.status, provider: market.provider || ps.mode, updatedAt: market.updatedAt,
        error: market.error, configured: ps.configured, requested: market.requested ?? preliminary.length,
        received: market.received ?? finalItems.filter((row) => row.quoteConnected).length,
        missing: market.missing || [],
        sourceApp: (market.provider || ps.mode) === 'smartmoney-bridge' ? (market.sourceVersion || 'V3.1.x') : null,
        directKiwoomDisabled: true, usMarketImpactCandidates: externalCandidates.length, usMarketSession: usDesk?.session?.label || null, nextUsSession: nextForecast ? { targetDate: nextForecast.target?.targetDate, dominant: nextForecast.dominant, probability: nextForecast.calibratedProbabilities?.[nextForecast.dominant] } : null, expandedUniverse: getUniverseStats().expandedCount,
      },
      fields: ['순위','현재가','등락률','외국인/기관/프로그램 수급','거래량증가율','선취','선반영','원모델확률','D1/D2/D3 보정확률','보정 상승확률','신뢰도','관리판정'],
      ranking: { basis: 'calibratedProbability_desc', horizon: '1~3거래일', probabilityType: 'AUTO_CALIBRATED', empiricalHitRate: calibrated.summary.horizons?.[3]?.samples >= calibrated.summary.minSamples },
    });
  }
  if (pathname === '/api/calibration') {
    if (!requireAuth(req, res)) return;
    if (req.method === 'GET') {
      const state = await calibrationEngine.exportState();
      return sendJson(res, 200, { state, summary: calibrationEngine.statsFor(state.predictions), storage: calibrationEngine.storageStatus() });
    }
    if (req.method !== 'POST') return sendMethodNotAllowed(res, ['GET','POST']);
    if (!requireSameOrigin(req, res)) return;
    const body = await readJson(req, 2 * 1024 * 1024);
    const result = await calibrationEngine.importState(body.state || body, { onlyIfEmpty: body.onlyIfEmpty !== false });
    return sendJson(res, 200, { restored: result.restored, restoredCount: result.restoredCount || 0, reason: result.reason || null, summary: result.summary, storage: calibrationEngine.storageStatus() });
  }
  if (pathname === '/api/foreign-leads') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('foreign_leads_api');
    const items = await newsStore.list({ limit: 700, includeCoverage: true });
    return sendJson(res, 200, { items: buildForeignLeadBriefs(items, { limit: 24 }), universe: getUniverseStats(), maxCandidatesPerNews: 3, accessRefresh });
  }
  if (pathname === '/api/affected-stocks') {
    if (!requireAuth(req, res)) return;
    if (req.method !== 'GET') return sendMethodNotAllowed(res, ['GET']);
    const accessRefresh = poller.triggerAccessRefresh('affected_stocks_api');
    const items = await newsStore.list({ limit: 700 });
    return sendJson(res, 200, { items: buildExpandedDiscovery(items, { limit: 40 }), universe: getUniverseStats(), freshnessPolicy: { mode: 'FRESH_PLUS_SECOND_ORDER', naverUnknownTimeExcludedFromFresh: true, unknownTimeAllowedAsLowConfidenceSecondOrder: true, duplicateStoryScoreSuppressed: true, freshHours: Number(process.env.AUTO200_FRESH_HOURS || 6), contextCooldownHours: Number(process.env.AUTO200_CONTEXT_COOLDOWN_HOURS || 18), maxPerCatalyst: Number(process.env.AUTO200_MAX_PER_CATALYST || 2) }, accessRefresh });
  }
  if (pathname === '/api/watchlist') {
    if (!requireAuth(req, res)) return;
    if (req.method === 'GET') return sendJson(res, 200, { items: await listWatchlist(), max: MAX_ITEMS });
    if (!requireSameOrigin(req, res)) return;
    const body = await readJson(req);
    if (req.method === 'POST') return sendJson(res, 201, { item: await addToWatchlist(body) });
    if (req.method === 'DELETE') {
      if (!body.id) return sendJson(res, 400, { error: 'id가 필요합니다.' });
      return sendJson(res, 200, { items: await removeFromWatchlist(body.id) });
    }
    return sendMethodNotAllowed(res, ['GET', 'POST', 'DELETE']);
  }
  if (pathname === '/api/macro') {
    if (!requireAuth(req, res)) return;
    if (req.method === 'GET') return sendJson(res, 200, { items: await listTopics(), max: MAX_TOPICS });
    if (!requireSameOrigin(req, res)) return;
    const body = await readJson(req);
    if (req.method === 'POST') return sendJson(res, 201, { item: await addTopic(body) });
    if (req.method === 'DELETE') {
      if (!body.id) return sendJson(res, 400, { error: 'id가 필요합니다.' });
      return sendJson(res, 200, { items: await removeTopic(body.id) });
    }
    return sendMethodNotAllowed(res, ['GET', 'POST', 'DELETE']);
  }
  return sendJson(res, 404, { error: 'Not Found' });
}

async function main() {
  const storage = await store.healthCheck();
  if (!storage.ok) throw new Error(`저장소 사용 불가: ${storage.error}`);
  if (process.env.NODE_ENV === 'production' && !process.env.STORE_DIR) {
    logger.warn('store_dir_not_explicit', { dataDir: storage.dataDir, hint: '무료 Render 모드에서는 /tmp 임시저장을 사용하며 재시작 시 최신 원문을 다시 수집합니다.' });
  }
  await poller.start();
  backups.start();

  const server = createServer((req, res) => {
    route(req, res).catch((error) => {
      const status = Number(error.statusCode || 500);
      if (status >= 500) logger.error('request_failed', { method: req.method, url: req.url, error: error.message });
      sendJson(res, status, { error: status >= 500 ? '서버 처리 중 오류가 발생했습니다.' : error.message });
    });
  });
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 70000;
  server.requestTimeout = 30000;
  server.on('clientError', (error, socket) => {
    logger.warn('http_client_error', { error: error.message });
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
  });

  const port = Number(process.env.PORT || 3000);
  server.listen(port, () => logger.info('server_listening', { port, env: process.env.NODE_ENV || 'development', version: VERSION, dataDir: storage.dataDir }));

  let shuttingDown = false;
  const shutdown = async (signal) => {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info('shutdown_started', { signal });
    const force = setTimeout(() => process.exit(1), 15000);
    if (force.unref) force.unref();
    for (const connection of sseConnections) if (!connection.writableEnded) connection.end();
    const closed = new Promise((resolve) => server.close(resolve));
    await Promise.allSettled([poller.stop(), backups.stop()]);
    await closed;
    clearTimeout(force);
    process.exit(0);
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (error) => logger.error('unhandled_rejection', { error: error?.message || String(error) }));
  process.on('uncaughtException', (error) => {
    logger.error('uncaught_exception', { error: error.message, stack: error.stack });
    shutdown('uncaughtException');
  });
}

main().catch((error) => {
  logger.error('startup_failed', { error: error.message, stack: error.stack });
  process.exit(1);
});
