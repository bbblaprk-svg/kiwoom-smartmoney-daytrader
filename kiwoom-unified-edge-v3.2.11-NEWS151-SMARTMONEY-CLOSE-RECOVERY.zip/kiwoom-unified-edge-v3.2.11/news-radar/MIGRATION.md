# v1.3.9 → v1.5.0

유지
- US MARKET LIVE DESK
- 프리/정규/애프터 구분
- 약 2천자 현재 미국장 분석
- AUTO200 + EXPAND
- ACTIVE20 상승확률 TOP20
- D+1/D+2/D+3 국내종목 확률보정
- V3.1.x read-only 공유시세

추가
- 앱 최상단 `NEXT US SESSION` 클릭형 카드
- 다음 미국 정규장 상승/중립/하락 확률
- 거시·정책 30 / 시장선행 25 / 기업·산업 20 / 크로스애셋 15 / 뉴스심리 10 가중
- 유사뉴스 클러스터링/중복기사 감점
- 약 2천자 익일 전망
- 위험요인 / 개장 전 체크 / 미국 섹터 전망
- 국내 1차·2차·EXPAND 후보
- NEXT US 후보 ACTIVE20 합류
- QQQ 60 + SPY 40 실제 다음장 결과 기반 적중률/Brier score 자동보정
- 미국장 예측 기록 browser mirror + 백업 포함
