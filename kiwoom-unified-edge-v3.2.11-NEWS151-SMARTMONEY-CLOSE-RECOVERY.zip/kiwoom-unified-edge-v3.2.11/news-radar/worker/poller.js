const os = require('os');
const { listWatchlist, updateWatchlistItem } = require('../lib/watchlist');
const { listTopics } = require('../lib/macroTopics');
const { searchNews } = require('../lib/sources/naverNews');
const { searchNaverPublic } = require('../lib/sources/naverPublic');
const { resolveCorpCode, fetchDisclosures } = require('../lib/sources/dart');
const { fetchFeed } = require('../lib/sources/rss');
const { fetchMarketNews } = require('../lib/sources/finnhub');
const { getOfficialSources, weightedOfficialJobs, envBool } = require('../lib/officialSources');
const newsStore = require('../lib/newsStore');
const dailyBudget = require('../lib/dailyBudget');
const store = require('../lib/store');
const logger = require('../lib/logger');

const CURSOR_KEY = 'poller:cursors:v3';
const KST_OFFSET_MS = 9 * 3600000;

function envInt(name, fallback, min, max) {
  const value = Number(process.env[name] || fallback);
  return Math.max(min, Math.min(max, Number.isFinite(value) ? value : fallback));
}

function sourceStatus(configured) {
  return {
    configured,
    running: false,
    lastRunAt: null,
    lastSuccessAt: null,
    lastError: null,
    lastWarning: null,
    lastDurationMs: null,
    lastJob: null,
    nextRunAt: null,
    backoffUntil: null,
    consecutiveFailures: 0,
    totalRuns: 0,
    totalCalls: 0,
    totalFetched: 0,
    totalAdded: 0,
    skipped: 0,
  };
}

function koreaClock(now = Date.now()) {
  const date = new Date(now + KST_OFFSET_MS);
  return {
    year: date.getUTCFullYear(), month: date.getUTCMonth(), day: date.getUTCDate(),
    weekday: date.getUTCDay(), hour: date.getUTCHours(), minute: date.getUTCMinutes(),
    iso: date.toISOString().replace('Z', '+09:00'),
  };
}

function isKoreaWeekend(now = Date.now()) {
  const day = koreaClock(now).weekday;
  return day === 0 || day === 6;
}

function msToNextKoreaDay() {
  const now = Date.now();
  const koreaNow = new Date(now + KST_OFFSET_MS);
  const nextUtc = Date.UTC(koreaNow.getUTCFullYear(), koreaNow.getUTCMonth(), koreaNow.getUTCDate() + 1) - KST_OFFSET_MS;
  return Math.max(60000, nextUtc - now + 5000);
}

function msToNextKoreaWeekday(hour = 5, minute = 50) {
  const now = Date.now();
  const current = koreaClock(now);
  for (let add = 0; add <= 7; add += 1) {
    const candidateUtc = Date.UTC(current.year, current.month, current.day + add, hour, minute) - KST_OFFSET_MS;
    if (candidateUtc <= now + 1000) continue;
    const weekday = koreaClock(candidateUtc).weekday;
    if (weekday !== 0 && weekday !== 6) return Math.max(60000, candidateUtc - now);
  }
  return 12 * 3600000;
}

function koreaMinuteOfDay(now = Date.now()) {
  const clock = koreaClock(now);
  return clock.hour * 60 + clock.minute;
}

function inKoreaWindow(startMinute, endMinute, now = Date.now()) {
  const minute = koreaMinuteOfDay(now);
  if (startMinute === endMinute) return true;
  if (startMinute < endMinute) return minute >= startMinute && minute < endMinute;
  return minute >= startMinute || minute < endMinute;
}

function msToNextKoreaWindowStart(startMinute, now = Date.now()) {
  const current = koreaClock(now);
  const startHour = Math.floor(startMinute / 60);
  const startMin = startMinute % 60;
  for (let add = 0; add <= 7; add += 1) {
    const candidateUtc = Date.UTC(current.year, current.month, current.day + add, startHour, startMin) - KST_OFFSET_MS;
    if (candidateUtc <= now + 1000) continue;
    const weekday = koreaClock(candidateUtc).weekday;
    if (weekday !== 0 && weekday !== 6) return Math.max(60000, candidateUtc - now);
  }
  return 12 * 3600000;
}

function collectionMode(now = Date.now()) {
  const clock = koreaClock(now);
  if (clock.weekday === 0 || clock.weekday === 6) return 'weekend-48h-active';
  if (clock.hour >= 21 || clock.hour < 7) return 'us-session-fast';
  if (clock.hour < 10) return 'kr-premarket-open-fast';
  if (clock.hour < 16) return 'kr-market-normal';
  return 'aftermarket-low-duty';
}

class Poller {
  constructor() {
    this.started = false;
    this.stopping = false;
    this.timers = new Map();
    this.active = new Map();
    this.cursor = { naver: 0, naverPass: 0, naverPublic: 0, dart: 0, official: 0 };
    this.cursorDirty = false;
    this.cursorTimer = null;
    this.weekendPause = envBool('WEEKEND_PAUSE', false);
    this.lowDutyWindows = envBool('LOW_DUTY_WINDOWS', true);
    this.officialOnlyFreeMode = envBool('OFFICIAL_ONLY_FREE_MODE', false);
    this.accessRefreshEnabled = envBool('ACCESS_REFRESH_ENABLED', true);
    this.accessRefreshMinMs = envInt('ACCESS_REFRESH_MIN_MS', 10 * 60 * 1000, 60000, 6 * 3600000);
    this.accessRefreshMaxSources = envInt('ACCESS_REFRESH_MAX_SOURCES', 10, 1, 20);
    this.weekendViewHours = envInt('WEEKEND_VIEW_HOURS', 48, 12, 48);
    this.weekendTickMs = envInt('WEEKEND_TICK_MS', 180000, 60000, 1800000);
    this.accessRefreshPromise = null;
    this.accessRefresh = {
      running: false, lastRunAt: null, lastSuccessAt: null, lastError: null, lastReason: null,
      lastCalls: 0, lastFetched: 0, lastAdded: 0, totalRuns: 0, nextAllowedAt: null,
    };

    this.naverPublicEnabled = envBool('NAVER_PUBLIC_ENABLED', true);
    this.naverPublicIntervalMs = envInt('NAVER_PUBLIC_INTERVAL_MS', 360000, 120000, 3600000);
    this.naverPublicQueries = String(process.env.NAVER_PUBLIC_QUERIES || '반도체 HBM AI|자율주행 SDV|로봇 휴머노이드|산업자동화 스마트팩토리|전력기기 변압기 전선|데이터센터 전력인프라|의료로봇 헬스케어AI|화학 첨단소재|2차전지 전기차|원전 SMR|방산 우주|조선 해운')
      .split('|').map((value) => value.trim()).filter(Boolean).slice(0, 12);

    this.naverDailyBudget = envInt('NAVER_DAILY_BUDGET', 16000, 100, 24000);
    const budgetFloorMs = Math.ceil(86400000 / this.naverDailyBudget);
    this.naverTickMs = Math.max(budgetFloorMs, envInt('NAVER_TICK_MS', 8000, 3000, 3600000));
    this.dartTickMs = envInt('DART_TICK_MS', 20000, 5000, 3600000);
    this.rssIntervalMs = envInt('RSS_POLL_INTERVAL_MS', 180000, 30000, 86400000);
    this.finnhubIntervalMs = envInt('FINNHUB_POLL_INTERVAL_MS', 120000, 30000, 86400000);
    this.officialFastMs = envInt('OFFICIAL_TICK_FAST_MS', 20000, 10000, 3600000);
    this.officialMarketMs = envInt('OFFICIAL_TICK_MARKET_MS', 45000, 15000, 3600000);
    this.officialQuietMs = envInt('OFFICIAL_TICK_QUIET_MS', 90000, 30000, 3600000);

    this.rssUrls = this.officialOnlyFreeMode ? [] : (process.env.RSS_FEED_URLS || '').split(',').map((value) => value.trim()).filter(Boolean);
    this.officialSources = getOfficialSources();
    this.officialJobs = weightedOfficialJobs(this.officialSources);
    this.status = {
      official: sourceStatus(this.officialJobs.length > 0),
      naverPublic: sourceStatus(this.naverPublicEnabled && this.naverPublicQueries.length > 0),
      naver: sourceStatus(!this.officialOnlyFreeMode && Boolean(process.env.NAVER_CLIENT_ID && process.env.NAVER_CLIENT_SECRET)),
      dart: sourceStatus(!this.officialOnlyFreeMode && Boolean(process.env.DART_API_KEY)),
      rss: sourceStatus(!this.officialOnlyFreeMode && this.rssUrls.length > 0),
      finnhub: sourceStatus(!this.officialOnlyFreeMode && Boolean(process.env.FINNHUB_API_KEY)),
    };
  }

  officialInterval() {
    const mode = collectionMode();
    if (mode === 'weekend-48h-active') return this.weekendTickMs;
    if (mode === 'us-session-fast' || mode === 'kr-premarket-open-fast') return this.officialFastMs;
    if (mode === 'kr-market-normal') return this.officialMarketMs;
    return this.officialQuietMs;
  }

  weekendGate(job) {
    if (this.weekendPause && isKoreaWeekend()) {
      return { skipped: 'weekend_pause', job: `${job}: 주말 휴식`, nextDelayMs: msToNextKoreaWeekday() };
    }
    return null;
  }

  sourceWindowGate(job, startMinute, endMinute) {
    const weekend = this.weekendGate(job);
    if (weekend) return weekend;
    // WEEKEND_PAUSE=false이면 주말에도 48시간 뉴스 수집을 계속합니다.
    // 평일 전용 시간창은 주말에는 적용하지 않아 다음 월요일까지 건너뛰는 현상을 막습니다.
    if (isKoreaWeekend()) return null;
    if (!this.lowDutyWindows || inKoreaWindow(startMinute, endMinute)) return null;
    return {
      skipped: 'outside_active_window',
      job: `${job}: 비활성 시간대 휴면`,
      nextDelayMs: msToNextKoreaWindowStart(startMinute),
    };
  }

  async start() {
    if (this.started) return;
    this.started = true;
    this.stopping = false;
    await dailyBudget.ensureLoaded();
    const savedCursor = await store.getItem(CURSOR_KEY).catch(() => null);
    if (savedCursor && typeof savedCursor === 'object') this.cursor = { ...this.cursor, ...savedCursor };
    await newsStore.ensureLoaded();

    if (this.status.official.configured) this.schedule('official', 500, () => this.officialInterval(), () => this.runOfficialOne());
    if (this.status.naverPublic.configured) this.schedule('naverPublic', 2500, () => this.naverPublicIntervalMs, () => this.runNaverPublicOne());
    if (this.status.naver.configured) this.schedule('naver', 3000, () => this.naverTickMs, () => this.runNaverOne());
    if (this.status.dart.configured) this.schedule('dart', 5000, () => this.dartTickMs, () => this.runDartOne());
    if (this.status.rss.configured) this.schedule('rss', 7000, () => this.rssIntervalMs, () => this.runRss());
    if (this.status.finnhub.configured) this.schedule('finnhub', 9000, () => this.finnhubIntervalMs, () => this.runFinnhub());

    logger.info('poller_started', {
      host: os.hostname(), mode: collectionMode(), weekendPause: this.weekendPause, officialOnlyFreeMode: this.officialOnlyFreeMode,
      officialSources: this.officialSources.map((source) => source.id),
      officialJobs: this.officialJobs.length, accessRefreshEnabled: this.accessRefreshEnabled, weekendViewHours: this.weekendViewHours,
      naverPublicEnabled: this.naverPublicEnabled, naverPublicQueries: this.naverPublicQueries.length, naverPublicIntervalMs: this.naverPublicIntervalMs,
      naverTickMs: this.naverTickMs,
      naverDailyBudget: this.naverDailyBudget, dartTickMs: this.dartTickMs, customRssFeeds: this.rssUrls.length,
    });
  }

  schedule(name, initialDelay, intervalProvider, task) {
    const arm = (delay) => {
      if (this.stopping) return;
      const status = this.status[name];
      status.nextRunAt = new Date(Date.now() + delay).toISOString();
      const timer = setTimeout(async () => {
        this.timers.delete(name);
        const result = await this.runExclusive(name, task);
        if (this.stopping) return;
        const backoffMs = status.backoffUntil ? Math.max(0, new Date(status.backoffUntil).getTime() - Date.now()) : 0;
        const requestedDelay = Number(result?.nextDelayMs || 0);
        arm(Math.max(intervalProvider(), backoffMs, requestedDelay));
      }, delay);
      if (timer.unref) timer.unref();
      this.timers.set(name, timer);
    };
    arm(initialDelay);
  }

  async runExclusive(name, task) {
    const status = this.status[name];
    if (status.running || this.active.has(name)) {
      status.skipped += 1;
      return { skipped: 'overlap' };
    }
    status.running = true;
    status.lastRunAt = new Date().toISOString();
    status.totalRuns += 1;
    const started = Date.now();
    const promise = (async () => {
      try {
        const result = await task();
        status.lastDurationMs = Date.now() - started;
        status.lastJob = result?.job || status.lastJob;
        status.lastWarning = result?.warning || null;
        status.totalCalls += Number(result?.calls || 0);
        status.totalFetched += Number(result?.fetched || 0);
        status.totalAdded += Number(result?.added || 0);
        if (result?.skipped) {
          status.skipped += 1;
        } else {
          status.lastSuccessAt = new Date().toISOString();
          status.lastError = null;
          status.backoffUntil = null;
          status.consecutiveFailures = 0;
        }
        return result || {};
      } catch (error) {
        status.lastDurationMs = Date.now() - started;
        status.lastError = error.message;
        status.consecutiveFailures += 1;
        const base = name === 'official' ? 10000 : name === 'naverPublic' ? 30000 : name === 'naver' ? 15000 : 30000;
        const calculated = Math.min(30 * 60 * 1000, base * (2 ** Math.min(8, status.consecutiveFailures - 1)));
        const backoffMs = Math.max(Number(error.retryAfterMs || 0), calculated);
        status.backoffUntil = new Date(Date.now() + backoffMs).toISOString();
        logger.warn('poller_source_failed', { source: name, error: error.message, backoffMs, failures: status.consecutiveFailures });
        return { failed: true, nextDelayMs: backoffMs };
      } finally {
        status.running = false;
        this.active.delete(name);
      }
    })();
    this.active.set(name, promise);
    return promise;
  }

  markCursorDirty() {
    this.cursorDirty = true;
    if (this.cursorTimer) return;
    this.cursorTimer = setTimeout(() => this.persistCursor().catch(() => null), 30000);
    if (this.cursorTimer.unref) this.cursorTimer.unref();
  }

  async persistCursor() {
    if (this.cursorTimer) clearTimeout(this.cursorTimer);
    this.cursorTimer = null;
    if (!this.cursorDirty) return;
    this.cursorDirty = false;
    await store.setItem(CURSOR_KEY, this.cursor);
  }

  accessRefreshSnapshot(extra = {}) {
    return {
      enabled: this.accessRefreshEnabled,
      weekend: isKoreaWeekend(),
      weekendViewHours: this.weekendViewHours,
      ...this.accessRefresh,
      ...extra,
    };
  }

  triggerAccessRefresh(reason = 'user_access') {
    if (!this.accessRefreshEnabled) return this.accessRefreshSnapshot({ triggered: false, skipped: 'disabled' });
    if (!this.officialSources.length && !this.naverPublicEnabled) return this.accessRefreshSnapshot({ triggered: false, skipped: 'no_news_sources' });
    if (this.accessRefresh.running || this.accessRefreshPromise) {
      return this.accessRefreshSnapshot({ triggered: false, skipped: 'already_running' });
    }
    const now = Date.now();
    const nextAllowed = new Date(this.accessRefresh.nextAllowedAt || 0).getTime();
    if (Number.isFinite(nextAllowed) && nextAllowed > now) {
      return this.accessRefreshSnapshot({ triggered: false, skipped: 'throttled' });
    }

    this.accessRefresh.running = true;
    this.accessRefresh.lastRunAt = new Date(now).toISOString();
    this.accessRefresh.lastReason = reason;
    this.accessRefresh.lastError = null;
    this.accessRefresh.totalRuns += 1;
    this.accessRefresh.nextAllowedAt = new Date(now + this.accessRefreshMinMs).toISOString();

    const promise = this.runAccessRefreshBatch(reason)
      .then((result) => {
        this.accessRefresh.lastCalls = result.calls;
        this.accessRefresh.lastFetched = result.fetched;
        this.accessRefresh.lastAdded = result.added;
        if (result.calls > 0) this.accessRefresh.lastSuccessAt = new Date().toISOString();
        if (result.errors.length) this.accessRefresh.lastError = result.errors.join(' | ').slice(0, 1200);
        if (result.calls === 0) this.accessRefresh.nextAllowedAt = new Date(Date.now() + 60000).toISOString();
        logger.info('access_refresh_finished', { reason, ...result });
        return result;
      })
      .catch((error) => {
        this.accessRefresh.lastError = error.message;
        logger.warn('access_refresh_failed', { reason, error: error.message });
        return { calls: 0, fetched: 0, added: 0, errors: [error.message] };
      })
      .finally(() => {
        this.accessRefresh.running = false;
        this.accessRefreshPromise = null;
      });
    this.accessRefreshPromise = promise;
    return this.accessRefreshSnapshot({ triggered: true });
  }

  async runAccessRefreshBatch(reason = 'user_access') {
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    const sourceLeadWeight = (source) => {
      const tier = String(source?.tier || '');
      if (source?.official || tier === 'primary') return 400;
      if (source?.primaryIndexed || tier === 'primary-index') return 350;
      if (tier.startsWith('international')) return 250;
      if (tier.startsWith('domestic')) return 80;
      return 100;
    };
    const sources = [...this.officialSources]
      .sort((a, b) => (sourceLeadWeight(b) + Number(b.priority || 0) * 10) - (sourceLeadWeight(a) + Number(a.priority || 0) * 10))
      .slice(0, this.accessRefreshMaxSources);

    // 무료 Render가 잠든 뒤 깨어났을 때 6개 피드를 직렬로 읽으면 1분 이상 걸릴 수 있습니다.
    // 3개씩 병렬 처리해 사용자가 접속한 뒤 보통 한두 번 새로고침 안에 결과가 보이게 합니다.
    const rows = [];
    const concurrency = Math.min(3, Math.max(1, sources.length));
    let cursor = 0;
    const worker = async () => {
      while (!this.stopping) {
        const index = cursor;
        cursor += 1;
        if (index >= sources.length) return;
        const source = sources[index];
        try {
          const results = await fetchFeed(source.url, { sourceMeta: source, timeoutMs: 8000 });
          const inserted = await newsStore.ingest(results, watchlist, topics);
          rows.push({ source: source.id, ok: true, calls: 1, fetched: results.length, added: inserted.length });
        } catch (error) {
          rows.push({ source: source.id, ok: false, calls: 0, fetched: 0, added: 0, error: error.message });
        }
      }
    };
    await Promise.all(Array.from({ length: concurrency }, () => worker()));

    if (this.naverPublicEnabled && this.naverPublicQueries.length && !this.stopping) {
      const qIndex = this.cursor.naverPublic % this.naverPublicQueries.length;
      const query = this.naverPublicQueries[qIndex];
      this.cursor.naverPublic = (qIndex + 1) % this.naverPublicQueries.length;
      this.markCursorDirty();
      try {
        const results = await searchNaverPublic(query, { timeoutMs: 8000 });
        const inserted = await newsStore.ingest(results, watchlist, topics);
        rows.push({ source: 'naver-public', ok: true, calls: 1, fetched: results.length, added: inserted.length });
      } catch (error) {
        rows.push({ source: 'naver-public', ok: false, calls: 0, fetched: 0, added: 0, error: error.message });
      }
    }

    const calls = rows.reduce((sum, row) => sum + row.calls, 0);
    const fetched = rows.reduce((sum, row) => sum + row.fetched, 0);
    const added = rows.reduce((sum, row) => sum + row.added, 0);
    const errors = rows.filter((row) => !row.ok).map((row) => `${row.source}: ${row.error}`);
    return { calls, fetched, added, errors, reason, sources: sources.map((source) => source.id), rows };
  }

  async runOfficialOne() {
    const pause = this.weekendGate('뉴스 직접피드');
    if (pause) return pause;
    if (!this.officialJobs.length) return { skipped: 'no_official_sources', job: '뉴스피드 없음' };
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    const index = this.cursor.official % this.officialJobs.length;
    const source = this.officialJobs[index];
    this.cursor.official = (index + 1) % this.officialJobs.length;
    this.markCursorDirty();
    const results = await fetchFeed(source.url, { sourceMeta: source, timeoutMs: 12000 });
    const added = await newsStore.ingest(results, watchlist, topics);
    return { calls: 1, fetched: results.length, added: added.length, job: source.label };
  }

  async runNaverPublicOne() {
    const pause = this.weekendGate('네이버 공개뉴스');
    if (pause) return pause;
    if (!this.naverPublicEnabled || !this.naverPublicQueries.length) return { skipped: 'disabled', job: '네이버 공개뉴스 비활성' };
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    const index = this.cursor.naverPublic % this.naverPublicQueries.length;
    const query = this.naverPublicQueries[index];
    this.cursor.naverPublic = (index + 1) % this.naverPublicQueries.length;
    this.markCursorDirty();
    const results = await searchNaverPublic(query, { timeoutMs: 9000 });
    const added = await newsStore.ingest(results, watchlist, topics);
    return { calls: 1, fetched: results.length, added: added.length, job: `네이버 48h: ${query}` };
  }

  async runNaverOne() {
    const pause = this.sourceWindowGate('네이버 확인', 5 * 60 + 50, 20 * 60 + 30);
    if (pause) return pause;
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    const jobs = [
      ...watchlist.map((item) => ({ type: 'stock', id: item.id, label: item.name, query: item.name })),
      ...topics.map((topic) => ({ type: 'macro', id: topic.id, label: topic.label, keywords: topic.keywords || [] })),
    ];
    if (!jobs.length) return { skipped: 'no_jobs', job: '대상 없음' };

    const allowed = await dailyBudget.consume('naver', this.naverDailyBudget, 1);
    if (!allowed) return { skipped: 'daily_budget_exhausted', job: '일일 한도 대기', nextDelayMs: msToNextKoreaDay() };

    const index = this.cursor.naver % jobs.length;
    const job = jobs[index];
    this.cursor.naver = (index + 1) % jobs.length;
    if (this.cursor.naver === 0) this.cursor.naverPass += 1;
    this.markCursorDirty();

    let query = job.query;
    if (job.type === 'macro') {
      const keywords = job.keywords.filter(Boolean);
      query = keywords.length ? keywords[this.cursor.naverPass % keywords.length] : job.label;
    }
    const results = await searchNews(query, {
      clientId: process.env.NAVER_CLIENT_ID,
      clientSecret: process.env.NAVER_CLIENT_SECRET,
      display: envInt('NAVER_DISPLAY', 20, 1, 100),
    });
    const added = await newsStore.ingest(results, watchlist, topics);
    return { calls: 1, fetched: results.length, added: added.length, job: `${job.type}:${job.label} (${query})` };
  }

  async runDartOne() {
    const pause = this.sourceWindowGate('DART', 7 * 60, 19 * 60 + 30);
    if (pause) return pause;
    const watchlist = (await listWatchlist()).filter((item) => item.code);
    if (!watchlist.length) return { skipped: 'no_stock_codes', job: '종목코드 없음' };
    const topics = await listTopics();
    const index = this.cursor.dart % watchlist.length;
    const item = watchlist[index];
    this.cursor.dart = (index + 1) % watchlist.length;
    this.markCursorDirty();

    let corpCode = item.corpCode;
    if (!corpCode) {
      corpCode = await resolveCorpCode(item.code, process.env.DART_API_KEY);
      if (corpCode) await updateWatchlistItem(item.id, { corpCode });
    }
    if (!corpCode) return { skipped: 'corp_code_not_found', job: `DART:${item.name}` };
    const results = await fetchDisclosures(corpCode, { apiKey: process.env.DART_API_KEY });
    const tagged = results.map((row) => ({ ...row, corpNameHint: { id: item.id, name: item.name, code: item.code } }));
    const added = await newsStore.ingest(tagged, watchlist, topics);
    return { calls: 1, fetched: results.length, added: added.length, job: `DART:${item.name}` };
  }

  async runRss() {
    const pause = this.weekendGate('사용자 RSS');
    if (pause) return pause;
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    let calls = 0;
    let fetched = 0;
    let addedCount = 0;
    const errors = [];
    for (const url of this.rssUrls) {
      try {
        const results = await fetchFeed(url);
        calls += 1;
        fetched += results.length;
        const added = await newsStore.ingest(results, watchlist, topics);
        addedCount += added.length;
      } catch (error) {
        let host = url;
        try { host = new URL(url).hostname; } catch (_) { /* 원문 URL 사용 */ }
        errors.push(`${host}: ${error.message}`);
      }
    }
    if (errors.length === this.rssUrls.length) throw new Error(`모든 RSS 피드 실패: ${errors.join(' | ')}`);
    return { calls, fetched, added: addedCount, warning: errors.length ? errors.join(' | ') : null, job: `사용자 RSS ${this.rssUrls.length}개` };
  }

  async runFinnhub() {
    const pause = this.sourceWindowGate('Finnhub', 20 * 60 + 30, 10 * 60);
    if (pause) return pause;
    const [watchlist, topics] = await Promise.all([listWatchlist(), listTopics()]);
    const results = await fetchMarketNews({ apiKey: process.env.FINNHUB_API_KEY, category: 'general' });
    const added = await newsStore.ingest(results, watchlist, topics);
    return { calls: 1, fetched: results.length, added: added.length, job: 'Finnhub 확인용' };
  }

  getSnapshot() {
    const sourceCopy = JSON.parse(JSON.stringify(this.status));
    return {
      started: this.started,
      stopping: this.stopping,
      mode: collectionMode(),
      koreaClock: koreaClock(),
      weekendPause: this.weekendPause,
      lowDutyWindows: this.lowDutyWindows,
      officialOnlyFreeMode: this.officialOnlyFreeMode,
      accessRefresh: this.accessRefreshSnapshot(),
      sources: sourceCopy,
      settings: {
        officialFastMs: this.officialFastMs,
        officialMarketMs: this.officialMarketMs,
        officialQuietMs: this.officialQuietMs,
        officialFeedCount: this.officialSources.length,
        newsFeedCount: this.officialSources.length + (this.naverPublicEnabled ? 1 : 0),
        naverPublicEnabled: this.naverPublicEnabled,
        naverPublicIntervalMs: this.naverPublicIntervalMs,
        naverPublicQueryCount: this.naverPublicQueries.length,
        officialOnlyFreeMode: this.officialOnlyFreeMode,
        officialWeightedJobs: this.officialJobs.length,
        accessRefreshEnabled: this.accessRefreshEnabled,
        accessRefreshMinMs: this.accessRefreshMinMs,
        accessRefreshMaxSources: this.accessRefreshMaxSources,
        weekendViewHours: this.weekendViewHours,
        weekendTickMs: this.weekendTickMs,
        newsViewHours: 48,
        naverTickMs: this.naverTickMs,
        naverDailyBudget: this.naverDailyBudget,
        dartTickMs: this.dartTickMs,
        rssIntervalMs: this.rssIntervalMs,
        finnhubIntervalMs: this.finnhubIntervalMs,
        rssFeedCount: this.rssUrls.length,
        sourceWindowsKst: { naver: '05:50-20:30', dart: '07:00-19:30', finnhub: '20:30-10:00' },
      },
      officialSources: this.officialSources.map(({ id, label, priority, tags, tier, official }) => ({ id, label, priority, tags, tier, official })),
      naverPublic: { enabled: this.naverPublicEnabled, queryCount: this.naverPublicQueries.length },
      budget: dailyBudget.snapshot({ naver: this.naverDailyBudget }),
      cursors: { ...this.cursor },
    };
  }

  async stop() {
    if (this.stopping) return;
    this.stopping = true;
    for (const timer of this.timers.values()) clearTimeout(timer);
    this.timers.clear();
    if (this.cursorTimer) clearTimeout(this.cursorTimer);
    this.cursorTimer = null;
    await Promise.allSettled([...this.active.values(), ...(this.accessRefreshPromise ? [this.accessRefreshPromise] : [])]);
    await Promise.allSettled([this.persistCursor(), dailyBudget.flush(), newsStore.flush(), store.flush()]);
    logger.info('poller_stopped');
  }
}

module.exports = {
  Poller, msToNextKoreaDay, msToNextKoreaWeekday, isKoreaWeekend, koreaClock, collectionMode,
  koreaMinuteOfDay, inKoreaWindow, msToNextKoreaWindowStart,
};
