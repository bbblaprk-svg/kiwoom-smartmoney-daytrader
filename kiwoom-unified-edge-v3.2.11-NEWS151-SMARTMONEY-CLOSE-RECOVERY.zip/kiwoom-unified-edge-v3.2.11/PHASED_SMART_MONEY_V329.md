# v3.2.9 Phased Smart Money

- SMART_NEG → SMART_NEUTRAL → SMART_BUILD → SMART_TURN → SMART_POS → SMART_CONFIRMED
- EARLY 65~74, PRE-BUY 75~84 when core safety gates pass and no negative veto, BUY 85+ only with confirmed smart-money/independent flow gates.
- SMART_NEUTRAL/BUILD no longer erases a 75+ candidate; it remains PRE-BUY with remaining conditions.
- DISTRIBUTION/EXHAUSTION, strong cross-venue conflict, or broad negative flow still veto PRE-BUY/BUY.
- CLOSE_BUY and PRE_BUY stage entry prices are recorded separately for forward outcome learning. Learning remains bounded and cannot relax BUY hard gates.
