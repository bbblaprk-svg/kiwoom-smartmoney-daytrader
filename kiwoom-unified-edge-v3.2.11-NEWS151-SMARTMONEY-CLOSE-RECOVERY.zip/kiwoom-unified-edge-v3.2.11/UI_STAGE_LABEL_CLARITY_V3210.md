# v3.2.10 UI Stage Label Clarity

- News discovery labels are now prefixed with `NEWS-`: `NEWS-STEALTH`, `NEWS-EARLY`, `NEWS-VERIFY`, `NEWS-WATCH`, `NEWS-CROWDED`.
- Trading stages remain `EARLY`, `PRE-BUY`, and `BUY`.
- Unified summary label `뉴스 후보저수지` is renamed to `현재 자동투입 후보`.
- Reservoir section title is renamed to `전체 뉴스랭킹 · 상위 20`.
- No trading thresholds, KRX/NXT feed logic, Smart Money scoring, close-sync, or LOW TRAFFIC policy were changed.
