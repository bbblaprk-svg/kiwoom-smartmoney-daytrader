# v3.2.11 Validation Report

- `npm run check`: PASS (기존 회귀검사 + smart-money-close-recovery)
- `npm run check:load`: PASS, 30종목 12,000 events, errors 0, finalPending 0
- `npm run build`: 로컬 작업환경에 Next 실행파일이 없어 미실행(`next: not found`). Docker 배포는 npm install 후 build를 수행하도록 기존 가드 유지.
- 최종 배포 ZIP은 재압축 후 SOURCE_MANIFEST/BUNDLE_MANIFEST를 깨끗한 폴더에서 재검증합니다.

핵심 변경: 같은 날 14:40~15:35 KST에 확보한 FOCUS 스마트머니 핵심증거만 체크포인트로 인정하고 재시작 후 복원합니다. 이전 거래일/장중 오래된 값은 종가 스마트머니로 재사용하지 않습니다.
