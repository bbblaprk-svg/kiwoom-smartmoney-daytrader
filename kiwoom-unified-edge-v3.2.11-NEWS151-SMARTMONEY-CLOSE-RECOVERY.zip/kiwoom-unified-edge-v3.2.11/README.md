# Kiwoom Unified Edge v3.2.7 PIPELINE GUARD + News Radar v1.5.1

## v3.2.7 핵심
- KRX/NXT WebSocket-first 실시간 파이프라인 유지, 모든 체결은 저장하고 고비용 신호평가만 throttle
- 체결 burst 시 quick promotion + 종목별 평가간격으로 이벤트루프 병목 완화
- Smart Money Behavior: ACCUMULATION → SHAKEOUT → TURN → MARKUP → DISTRIBUTION/EXHAUSTION
- 단일 호가/단일 점수 대신 신선한 실체결·호가 EWMA·프로그램·VWAP·KRX/NXT 독립증거 요구. 체결강도·대형체결·흡수는 같은 tape축으로 묶어 중복가산 방지
- 거래원(0F)은 저빈도 보조확인으로 사용하고 BUY 핵심피드 하드게이트에서 제외
- 장중 전체 REST 제거, stale 종목 보조조회와 KRX/NXT 종가 동기화만 유지
- 종가동기화 실패 종목만 단계적 재시도 + 재기동 catch-up + 공식 KRX 종가/수급 미확정 CLOSE_BUY 차단
- 장중 추천 프로필은 cache-only로 REST 직렬 폭주 차단
- 새 설치는 안전 자동적용 모드에서 시장순위 3회/5분 수준으로 AUTO FOCUS/LIGHT를 1회 채운 뒤 AUTO LIGHT만 최대 2종목씩 5분 주기 교체. 수동·고정·AUTO FOCUS 보호
- LIGHT는 체결 전용으로 넓게 감시하고, 절대거래대금 또는 전일 동시간 거래량급증+공격매수 조건으로 최대 2종목을 FOCUS 정밀피드로 승격
- 정상장 관리신호 약 4~6개 목표. BUY 임계값을 낮춰 숫자를 억지로 채우지 않음
- BUY_ACTIVE 종목은 `BUY_MANAGE`로 테이블에 고정 유지
- 관리 테이블: 단계/종목/점수/증거신뢰/데이터/현재가/진입가/수익률/등락률/RR/KRX/NXT/신호시간
- 학습은 전체 60/버킷 12표본 이후 순위점수만 기본 ±6 범위로 보정, 하드게이트 불변
- CLOSE_BUY 성과에 MFE/MAE/R/관찰 bars 기록
- 사용자가 기록한 실제 매수/매도 체결도 진입 당시 앱 BUY/CLOSE_BUY 문맥이 있으면 별도 저장하고, 실제 성과 60건 이후 선택학습의 우선 데이터로 사용
- News Radar 1.5.1-unified 유지

상세 재점검 결과는 `PIPELINE_AUDIT_V327.md`를 참고하세요.
