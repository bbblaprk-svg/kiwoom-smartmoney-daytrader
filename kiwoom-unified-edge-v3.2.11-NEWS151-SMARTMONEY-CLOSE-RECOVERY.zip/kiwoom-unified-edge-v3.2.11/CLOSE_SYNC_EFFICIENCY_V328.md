# v3.2.8 Close Sync Efficiency Guard

## Why
v3.2.7 could restart after 20:01 KST with both KRX_CLOSE and NXT_CLOSE incomplete. The scheduler evaluated KRX first and returned, so it could run a full KRX recovery pass and then another NXT pass. A real runtime check showed hundreds of REST calls while NXT_CLOSE was still waiting.

## v3.2.8
- state key upgraded to `market:close-sync:v5:*`
- after 20:01, if KRX and NXT are both pending, one `NXT_CLOSE` snapshot pass validates both stages
- KRX_CLOSE does not call NXT REST while NXT is still trading
- daily OHLCV is primary for KRX close; `ka10001` KRX basic info is fallback-only when daily data fails
- if same-day KRX close and official flow were already confirmed, NXT_CLOSE uses the latest fresh NXT WebSocket final price first; otherwise only one NXT `ka10001(_NX)` fallback call is used
- `ka10059` supplies institution + foreign net first; `ka10008` is fallback-only when investor data is unavailable
- failed symbols only remain retry targets
- previous valid snapshots remain preserved; CLOSE_BUY still requires today's official KRX close confirmation
- WebSocket trade/orderbook/program processing remains independent of close-sync REST queue

## Expected REST shape for 30 symbols
- KRX close normal path: daily + investor + program, roughly 3 calls/symbol plus exceptional fallbacks
- NXT close after successful KRX sync: usually 0 REST when a fresh WebSocket final exists, otherwise up to 1 NXT quote call/symbol
- restart after 20:01 with both stages incomplete: one combined pass instead of two full passes

These are design budgets, not guarantees; failed APIs and token retries can add requests.
