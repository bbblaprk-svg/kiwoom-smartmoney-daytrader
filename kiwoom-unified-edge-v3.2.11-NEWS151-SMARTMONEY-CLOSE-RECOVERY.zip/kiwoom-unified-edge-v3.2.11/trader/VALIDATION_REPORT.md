# v3.2.9 Validation Report

Validation performed on the final source tree before packaging.

- `npm run check`: PASS, including phased-smart-money regression.
- `npm run check:load`: PASS — 30 symbols / 12,000 mixed realtime events / errors 0 / final pending 0.
- Smart-money phase mapping regression: PASS.
- Existing KRX/NXT, close-sync, learning, portfolio, pipeline, storage, REST and integration regressions: PASS.
- Final source and bundle SHA-256 manifests are regenerated from the packaged tree and verified after clean re-extraction.

These are software regression/load checks, not a guarantee of trading win rate or external broker/network availability.
