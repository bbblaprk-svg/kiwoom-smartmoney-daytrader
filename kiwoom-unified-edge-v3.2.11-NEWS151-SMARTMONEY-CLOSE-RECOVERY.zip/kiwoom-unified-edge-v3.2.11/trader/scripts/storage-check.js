const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'kiwoom-v313-store-'));
process.env.STORE_FILE_PATH = path.join(root, 'store.json');
process.env.STORE_KEY_DIR = path.join(root, 'keys');
process.env.ALERT_BATCH_MS = '20';

const store = require('../lib/store');
const { recordAlert, flushAlerts } = require('../lib/notifications');
const ledger = require('../lib/signalLedger');

(async () => {
  try {
    await store.setItem('settings', { sample: 1 });
    await store.setItem('positions', [{ id: 'p1' }]);
    const keyFiles = fs.readdirSync(process.env.STORE_KEY_DIR).filter((name) => name.endsWith('.json'));
    assert.strictEqual(keyFiles.length, 2, '키별 파일 저장이 분리되지 않음');
    assert.strictEqual((await store.getItem('settings')).sample, 1);

    await Promise.all(Array.from({ length: 40 }, (_, i) => recordAlert({ type: 'buy', action: 'BUY', code: '005930', price: 70000 + i, message: `alert-${i}` })));
    await flushAlerts();
    const alerts = await store.getList('alerts', 0, 999);
    assert.strictEqual(alerts.length, 40, '알림 배치 저장 누락');
    assert.strictEqual(alerts[0].message, 'alert-39', '알림 최신순 정렬 오류');

    await ledger.recordSignal({
      code: '005930', name: '삼성전자', action: 'BUY', price: 70000,
      qualityScore: 90, profitPriorityScore: 86, reasons: ['test'],
      plan: { stop: 69000, target1: 71000, target2: 72000, target3: 73000, expectedRewardRisk: 1.7 },
      at: Date.now(), verified: false,
    });
    await ledger.updatePrice('005930', 70700, Date.now() + 1000);
    let result = await ledger.getLedger({ stocks: [{ code: '005930', name: '삼성전자', price: 70700 }], positions: [] });
    let row = result.rows.find((item) => item.code === '005930');
    assert(row && row.status === 'BUY_ACTIVE');
    assert(Math.abs(row.returnPct - 1) < 0.001, `실시간 수익률 계산 오류 ${row.returnPct}`);

    // v3.1.16: 일반 SELL/RISK 단계로 닫지 않고, 신호 진입가 기준 계획 손절가 도달 때만 종료한다.
    await ledger.updatePrice('005930', 68800, Date.now() + 2000);
    await ledger.persistNow();
    result = await ledger.getLedger({ stocks: [{ code: '005930', name: '삼성전자', price: 68800 }], positions: [] });
    row = result.rows.find((item) => item.code === '005930');
    assert.strictEqual(row.status, 'CLOSED');
    assert.strictEqual(row.exitPrice, 68800);
    assert(row.returnPct < 0, `손절 종료 수익률 오류 ${row.returnPct}`);
    assert.deepStrictEqual(row.timeline.map((x) => x.action), ['BUY'], '일반 매도잡신호가 타임라인에 끼어들면 안 됨');

    const shadowAt = Date.now() + 3000;
    await ledger.recordShadowSignal({
      code: '000660', name: 'SK하이닉스', price: 200000,
      qualityScore: 90, profitPriorityScore: 77, minProfitPriorityScore: 78,
      vwapDistancePct: 1.2, spreadBps: 12, reasons: ['수익우선 점수 부족'], at: shadowAt,
    });
    await ledger.updatePrice('000660', 202000, shadowAt + 5 * 60_000);
    await ledger.updatePrice('000660', 203000, shadowAt + 15 * 60_000 + 1);
    await ledger.persistShadowNow();
    const shadowRows = await ledger.getShadowSignalsForValidation();
    const shadow = shadowRows.find((item) => item.code === '000660');
    assert(shadow, '수익우선 차단 shadow 신호 누락');
    assert.strictEqual(shadow.hidden, true, 'shadow 신호는 UI 비노출이어야 함');
    assert.strictEqual(shadow.status, 'COMPLETED_15M', '15분 추적 완료 상태 오류');
    assert(Math.abs(shadow.return15mPct - 1.5) < 0.001, `15분 shadow 수익률 오류 ${shadow.return15mPct}`);
    const publicLedger = await ledger.getLedger({ stocks: [{ code: '000660', name: 'SK하이닉스', price: 203000 }], positions: [] });
    assert(!publicLedger.rows.some((item) => item.source === 'SHADOW_PROFIT_PRIORITY'), 'shadow 신호가 사용자 UI 기록부에 노출됨');

    const metrics = store.getStoreMetrics();
    assert.strictEqual(metrics.usingLocalFile, true);
    console.log('STORAGE CHECK OK: 키별 저장, 알림 배치, BUY→손절가 단순종료, shadow 15분 추적');
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
