const assert = require('assert');
const { evaluateOpportunity, buildUnifiedOpportunities } = require('../lib/unifiedOpportunity');
const { featureBuckets } = require('../lib/adaptiveLearning');

const settings = { signal: { minBuyScore:85, minProfitPriorityScore:78, minTradeStrength:118, minDataCompleteness:95, minOneMinuteTurnover:100_000_000, minIndependentGroups:4, maxVwapExtensionPct:1.6 } };
const stock = {
  code:'123456', name:'통합테스트', price:10000, changePct:4.2, tier:'FOCUS', activeTier:'FOCUS',
  signal:{ action:'EARLY', confirmed:false, qualityScore:88, profitPriorityScore:80, dataCompleteness:96, independentGroups:4, smartMoneyFeedReady:false, smartMoneyState:'ABSORPTION', negativePressureBlock:false, vetoes:[], preSurgeScore:84,
    plan:{entry:10000, stop:9850, target1:10240, target2:10320, target3:10450, expectedRewardRisk:1.6},
    metrics:{tradeStrength:126, turnover1m:180_000_000, vwap:9950, recentLow:9920, spreadBps:9, rvol1m:2.1}
  }
};
const news = {code:'123456', source:'EARLY EDGE', newsScore:82, priorityScore:84, prepositionScore:86, pricedInScore:24, edgeClass:'STEALTH', reasons:['해외선행']};
const row = evaluateOpportunity(stock, settings, news);
assert.equal(row.stage, 'PRE_BUY');
assert(row.readiness >= 78);
assert(row.missingConditions.some((x)=>x.includes('스마트머니')));
assert(row.entryGuide.waitingLow > 0 && row.entryGuide.waitingHigh >= row.entryGuide.waitingLow);
const rows = buildUnifiedOpportunities([stock], settings, {items:[news]});
assert.equal(rows[0].stage, 'PRE_BUY');
const buckets = featureBuckets({newsEdgeClass:'STEALTH',prepositionScore:86,pricedInScore:24});
assert.equal(buckets.newsEdge,'STEALTH');
assert.equal(buckets.preposition,'80_PLUS');
assert.equal(buckets.pricedIn,'LOW');
console.log('UNIFIED INTEGRATION CHECK OK: PRE-BUY, 뉴스선취/선반영 학습버킷, 매수대기구간');
