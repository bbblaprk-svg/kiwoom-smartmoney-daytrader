const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { spawnSync } = require('child_process');
const {
  CORE_STOCKS, mergeWatchlist, splitWatchlist, toKiwoomCode,
  MAX_FOCUS_USER_STOCKS, MAX_LIGHT_USER_STOCKS,
} = require('../lib/stocks');
const { evaluateSignal } = require('../lib/signalEngine');
const { accountRisk, calculateNetPnl } = require('../lib/risk');
const realtime = require('../lib/realtimeStore');
const { mergeSettings } = require('../lib/settings');
const { dailyRowsFrom, calculateIndicators, computeSnapshotCompleteness, evaluateCloseDecision, closingFlowFromLive, marketPhase } = require('../lib/marketSnapshot');

assert.strictEqual(CORE_STOCKS.length, 4);
assert.strictEqual(MAX_FOCUS_USER_STOCKS, 8);
assert.strictEqual(MAX_LIGHT_USER_STOCKS, 18);
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'SOR' }), '005930_AL');
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'NXT' }), '005930_NX');


// Production must fail closed when app credentials are missing.
{
  const authPath = path.join(__dirname, '..', 'lib', 'auth.js');
  const missing = spawnSync(process.execPath, ['-e', `process.env.NODE_ENV='production'; delete process.env.APP_ACCESS_TOKEN; delete process.env.APP_SESSION_SECRET; require(${JSON.stringify(authPath)}).assertCredentials();`], { encoding: 'utf8' });
  assert.notStrictEqual(missing.status, 0, 'production boot must fail without app credentials');
  const valid = spawnSync(process.execPath, ['-e', `process.env.NODE_ENV='production'; process.env.APP_ACCESS_TOKEN='sample-access-token-123'; process.env.APP_SESSION_SECRET='0123456789abcdef0123456789abcdef0123456789abcdef'; require(${JSON.stringify(authPath)}).assertCredentials();`], { encoding: 'utf8' });
  assert.strictEqual(valid.status, 0, valid.stderr || 'valid production credentials rejected');
}

const list = mergeWatchlist([
  ...Array.from({ length: 10 }, (_, i) => ({ code: `1${String(i).padStart(5, '0')}`, name: `집중${i}`, tier: 'FOCUS', market: 'SOR' })),
  ...Array.from({ length: 24 }, (_, i) => ({ code: `2${String(i).padStart(5, '0')}`, name: `경량${i}`, tier: 'LIGHT', market: 'SOR' })),
]);
const split = splitWatchlist(list);
assert.strictEqual(split.focus.length, 12, '고정4+사용자집중8');
assert.strictEqual(split.light.length, 18, '사용자경량18');
assert.strictEqual(list.length, 30, '총 30종목 감시');

const activeTime = new Date('2026-07-31T05:10:00.000Z'); // KST 14:10
const strong = evaluateSignal({
  price: 100800, vwap: 100000, vwapDistancePct: 0.8,
  turnover1m: 500_000_000, turnover15s: 120_000_000,
  tradeStrength: 145, buyRatio: 66, rvol1m: 2.2,
  netBuyAmount5s: 90_000_000, netBuyAmount15s: 210_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 350_000_000, largeBuyCount1m: 4, largeSellCount1m: 0,
  spreadBps: 8, orderbookImbalance: 1.7, orderbookImbalanceEwma: 1.65, bidReplenishRatio: 0.18, bidReplenishEwma: 0.16, askWithdrawalRatio: 0.12, askWithdrawalEwma: 0.11, orderbookSupportStreak: 3, orderbookSampleCount: 3,
  programNetAmount: 500_000_000, programVelocity10s: 160_000_000, programTurnedPositive: 1,
  foreignNetDelta: 5000, breakout: true, vwapReclaim: true,
  momentum1mPct: 0.7, drawdownFromHighPct: -0.1,
  recentHigh: 100800, recentLow: 99500,
  smartMoneyState: 'EXPANSION', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 2,
  relativeStrengthPct: 1.2, marketBreadthPct: 58, marketAboveVwap: 1,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(strong.action, 'BUY', JSON.stringify(strong));
assert(strong.qualityScore >= 85);
assert.strictEqual(strong.qualityIsProbability, false);
const profitBlocked = evaluateSignal({
  price: 100800, vwap: 100000, vwapDistancePct: 0.8,
  turnover1m: 500_000_000, turnover15s: 120_000_000,
  tradeStrength: 145, buyRatio: 66, rvol1m: 2.2,
  netBuyAmount5s: 90_000_000, netBuyAmount15s: 210_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 350_000_000, largeBuyCount1m: 4, largeSellCount1m: 0,
  spreadBps: 8, orderbookImbalance: 1.7, orderbookImbalanceEwma: 1.65, bidReplenishRatio: 0.18, bidReplenishEwma: 0.16, askWithdrawalRatio: 0.12, askWithdrawalEwma: 0.11, orderbookSupportStreak: 3, orderbookSampleCount: 3,
  programNetAmount: 500_000_000, programVelocity10s: 160_000_000, programTurnedPositive: 1,
  foreignNetDelta: 5000, breakout: true, vwapReclaim: true,
  recentHigh: 100800, recentLow: 99500, smartMoneyState: 'EXPANSION',
  dataCompleteness: 100, activeTier: 'FOCUS', relativeStrengthPct: 1.2,
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 2,
  marketBreadthPct: 58, marketAboveVwap: 1, viActive: false, updatedAt: activeTime.getTime(),
}, { minProfitPriorityScore: 99 }, activeTime);
assert.strictEqual(profitBlocked.blockedByProfitPriority, true, JSON.stringify(profitBlocked));
assert(profitBlocked.profitPriorityScore < 99);

const light = evaluateSignal({ ...strong, activeTier: 'LIGHT' }, {}, activeTime);
assert.notStrictEqual(light.action, 'BUY', '경량 종목은 자동승격 전 확정매수 불가');

const vi = evaluateSignal({ price: 100000, vwap: 100000, spreadBps: 10, viActive: true, dataCompleteness: 100, activeTier: 'FOCUS', updatedAt: activeTime.getTime() }, {}, activeTime);
assert.strictEqual(vi.action, 'BLOCKED');
assert.strictEqual(vi.urgency, 'normal');

const earlySell = evaluateSignal({
  price: 99500, vwap: 100000, vwapDistancePct: -0.5,
  turnover1m: 450_000_000, tradeStrength: 82, buyRatio: 39, rvol1m: 2.1,
  netBuyAmount5s: -45_000_000, netBuyAmount15s: -120_000_000, buyAcceleration: -20_000_000,
  largeNetAmount1m: -150_000_000, largeBuyCount1m: 0, largeSellCount1m: 3,
  spreadBps: 10, orderbookImbalance: 0.68, bidReplenishRatio: -0.08, askWithdrawalRatio: -0.05,
  programNetAmount: -300_000_000, programVelocity10s: -90_000_000,
  foreignNetDelta: -4000, breakdown: false, vwapReclaim: false,
  momentum1mPct: -0.55, drawdownFromHighPct: -0.8,
  recentHigh: 100300, recentLow: 99300,
  smartMoneyState: 'DISTRIBUTION', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 3,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(earlySell.action, 'WAIT', JSON.stringify(earlySell));
assert(earlySell.sellPressureGroups >= 3, JSON.stringify(earlySell));
assert.strictEqual(earlySell.earlySellEligible, true);
assert.strictEqual(earlySell.negativePressureBlock, true);

const preDropEarlySell = evaluateSignal({
  price: 100000, vwap: 100100, vwapDistancePct: -0.1,
  turnover1m: 500_000_000, tradeStrength: 91, buyRatio: 42, rvol1m: 1.9,
  netBuyAmount5s: -35_000_000, netBuyAmount15s: -80_000_000, buyAcceleration: -18_000_000,
  largeNetAmount1m: -100_000_000, largeBuyCount1m: 0, largeSellCount1m: 2,
  spreadBps: 10, orderbookImbalance: 0.82,
  programNetAmount: -200_000_000, programVelocity10s: -70_000_000,
  foreignNetDelta: -2500, breakdown: false, momentum1mPct: -0.1, drawdownFromHighPct: -0.2,
  recentHigh: 100200, recentLow: 99800, smartMoneyState: 'DISTRIBUTION',
  dataCompleteness: 100, activeTier: 'FOCUS', orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0,
  tradeEventCount: 7, programSampleCount: 3, viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(preDropEarlySell.action, 'WAIT', `분배→매도 가속은 신규진입 안전필터로만 남아야 합니다: ${JSON.stringify(preDropEarlySell)}`);
assert.strictEqual(preDropEarlySell.sellPressure.price, false, '가격 하락확정 없이도 스마트머니·체결·프로그램·호가 압력으로 EARLY_SELL 가능해야 합니다.');
assert.strictEqual(preDropEarlySell.negativePressureBlock, true);

const riskWatch = evaluateSignal({
  price: 99800, vwap: 100000, vwapDistancePct: -0.2,
  turnover1m: 250_000_000, tradeStrength: 92, buyRatio: 45, rvol1m: 1.5,
  netBuyAmount5s: -30_000_000, netBuyAmount15s: -55_000_000, buyAcceleration: -8_000_000,
  largeNetAmount1m: -20_000_000, largeBuyCount1m: 0, largeSellCount1m: 1,
  spreadBps: 10, orderbookImbalance: 0.84,
  programNetAmount: 100_000_000, programVelocity10s: -20_000_000,
  foreignNetDelta: -1000, breakdown: false,
  momentum1mPct: -0.25, drawdownFromHighPct: -0.3,
  recentHigh: 100100, recentLow: 99600,
  smartMoneyState: 'NEUTRAL', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 6, programSampleCount: 2,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(riskWatch.action, 'WAIT', JSON.stringify(riskWatch));

const today = new Date();
const risk = accountRisk([
  { status: 'closed', realizedPnl: -600000, exitTime: new Date(today.getTime() - 60_000).toISOString() },
  { status: 'closed', realizedPnl: -500000, exitTime: new Date(today.getTime() - 120_000).toISOString() },
], { dayStartingEquity: 100000000, dailyMaxLossPct: -1, maxConsecutiveLosses: 3 });
assert.strictEqual(Number(risk.dailyPnlPct.toFixed(2)), -1.1);
assert.strictEqual(risk.halted, true);

const net = calculateNetPnl({ avgPrice: 100000, quantity: 10 }, 101000, { buyFeePct: 0.01, sellFeePct: 0.02, sellTaxPct: 0.15 });
assert.strictEqual(net.grossPnl, 10000);
assert(Math.abs(net.realizedPnl - 8183) < 1e-9);

const settings = mergeSettings({ signal: { minBuyScore: 40, confirmTicks: 9, confirmHoldMs: -1 } });
assert.strictEqual(settings.signal.minBuyScore, 65);
assert.strictEqual(settings.signal.confirmTicks, 6);
assert.strictEqual(settings.signal.confirmHoldMs, 0);
assert.strictEqual(settings.signal.maxSmartOrderbookAgeSeconds, 3.5);
assert.strictEqual(settings.signal.maxSmartProgramAgeSeconds, 20);
assert.strictEqual(settings.signal.maxSmartBrokerAgeSeconds, 120);
assert.strictEqual(settings.signal.minSmartTradeEvents, 5);
assert.strictEqual(settings.signal.minSmartProgramSamples, 2);
assert.strictEqual(settings.signal.preSurgeEarlyScore, 68);
assert.strictEqual(settings.signal.preSurgeMinGroups, 3);
assert.strictEqual(settings.signal.riskWatchScore, 45);
assert.strictEqual(settings.signal.earlySellScore, 58);
assert.strictEqual(settings.signal.earlySellMinGroups, 3);

const dailyRows = dailyRowsFrom({ stk_dt_pole_chart_qry: [
  { cur_prc: '70100', trde_qty: '9263135', trde_prica: '648525', dt: '20260731', open_pric: '69800', high_pric: '70500', low_pric: '69600' },
  { cur_prc: '69500', trde_qty: '11526724', trde_prica: '804642', dt: '20260730', open_pric: '70300', high_pric: '70400', low_pric: '69500' },
  ...Array.from({ length: 20 }, (_, index) => ({ cur_prc: String(69000 - index * 100), trde_qty: '7000000', trde_prica: '500000', dt: String(20260729 - index), open_pric: '69000', high_pric: '70000', low_pric: '68000' })),
] });
assert.strictEqual(dailyRows[0].close, 70100);
assert.strictEqual(dailyRows[0].tradeAmount, 648525000000);
const indicators = calculateIndicators(dailyRows);
assert(indicators.ma5 > 0 && indicators.ma20 > 0);
const closeLive = {
  updatedAt: activeTime.getTime(), tradeEventCount: 20, smartMoney: { state: 'TURN', score: 82 },
  program: { netAmount: 100000000, netQty: 1000, updatedAt: activeTime.getTime() },
  broker: { foreignNet: 5000, foreignNetDelta: 500, updatedAt: activeTime.getTime() },
};
const officialCloseFlow = { availability:{ program:true, foreign:true, institution:true }, normalized:{ programNetAmount:100000000, programNetQty:1000, foreignNet:5000, foreignNetDelta:500, institutionNet:8000 }, investor:{ investmentTrust:3000, pension:2500, financialInvestment:2500 }, fetchedAt:activeTime.toISOString() };
const closeFlow = closingFlowFromLive(closeLive, officialCloseFlow, null, activeTime.getTime());
const closeSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: true },
  krx: { close: 70100, open: 69800, high: 70500, low: 69600, volume: 9263135, tradeAmount: 648525000000, date: '20260731', changePct: 0.86 },
  nxt: { available: true, close: 70400, final: true, changePct: 1.2, changePctAvailable: true }, nxtGapPct: 0.43, indicators, closingFlow: closeFlow,
  closeSync: { targetDate: '20260731', krxOfficialConfirmed: true, krxStatus: 'CONFIRMED', nxtFinalConfirmed: true, officialFlowConfirmed: true },
};
const closeDecision = evaluateCloseDecision(closeSnapshot, closeLive, settings.perStock['005930'], 0, new Date('2026-07-31T07:00:00.000Z'));
assert(['CLOSE_BUY', 'HOLD'].includes(closeDecision.action), JSON.stringify(closeDecision));
assert.strictEqual(closeDecision.qualityIsProbability, false);
assert.strictEqual(closeDecision.basis.decisionPrice, 'KRX_OFFICIAL_CLOSE');
assert(closeDecision.breakdown.length >= 8, '종가점수 세부 산출근거');
assert.strictEqual(closeDecision.decisionProfile, 'DUAL_CLOSE_V4_SYNC_GUARD');
assert.strictEqual(closeDecision.engine, 'TREND');
assert.strictEqual(closeDecision.hardGates.structure, true);
assert.strictEqual(closeDecision.hardGates.volume, true);
assert.strictEqual(closeFlow.source, 'OFFICIAL_REST_PRIMARY');
assert.deepStrictEqual(closeFlow.availability, { smartMoney: true, program: true, foreign: true, institution: true });
assert.strictEqual(closeFlow.smartMoneyState, 'TURN');
assert.strictEqual(closeFlow.programNetAmount, 100000000);
const fullCompleteness = computeSnapshotCompleteness(closeSnapshot);
assert.strictEqual(fullCompleteness.score, 100);
const missingFlowCompleteness = computeSnapshotCompleteness({ ...closeSnapshot, closingFlow: closingFlowFromLive(null) });
assert.strictEqual(missingFlowCompleteness.score, 70, JSON.stringify(missingFlowCompleteness));
assert(missingFlowCompleteness.missing.includes('마감 스마트머니'));
assert.strictEqual(marketPhase(new Date('2026-07-31T13:30:00.000Z')).code, 'ALL_CLOSED'); // KST 22:30


// v3.1.12 inherits v3.1.11: 조기 급등/품절형 강세가 단순 미정배열·저거래량 때문에 과도하게 감점되지 않아야 한다.
const eventRows = [
  { cur_prc: '129800', trde_qty: '3000000', trde_prica: '500000', dt: '20260731', open_pric: '101000', high_pric: '130000', low_pric: '100500' },
  { cur_prc: '100000', trde_qty: '9000000', trde_prica: '900000', dt: '20260730', open_pric: '102000', high_pric: '103000', low_pric: '99000' },
  ...Array.from({ length: 24 }, (_, index) => ({ cur_prc: String(105000 - index * 300), trde_qty: '8000000', trde_prica: '700000', dt: String(20260729 - index), open_pric: '104000', high_pric: '106000', low_pric: '100000' })),
];
const eventDaily = dailyRowsFrom({ stk_dt_pole_chart_qry: eventRows });
const eventIndicators = calculateIndicators(eventDaily);
const eventSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: true },
  krx: { close: 129800, open: 101000, high: 130000, low: 100500, volume: 3000000, tradeAmount: 500000000000, date: '20260731', changePct: 29.8 },
  nxt: { available: true, close: 129900, final: true }, nxtGapPct: 0.08,
  indicators: { ...eventIndicators, ma5: 112000, ma20: 114000, prevMa5: 108000, ma5SlopePct: 3.704, volumeRatio20: 0.38, closeFromHighPct: -0.15 },
  closingFlow: { availability: { smartMoney: true, program: true, foreign: true, institution: true }, smartMoneyState: 'TURN', programNetAmount: 300000000, foreignNetDelta: 5000, institutionNet: 100000000, source: 'TEST' },
  completeness: 100,
  closeSync: { targetDate: '20260731', krxOfficialConfirmed: true, krxStatus: 'CONFIRMED', nxtFinalConfirmed: true, officialFlowConfirmed: true },
};
const eventDecision = evaluateCloseDecision(eventSnapshot, null, settings.perStock['005930'], 0, new Date('2026-07-31T07:00:00.000Z'));
assert(eventDecision.eventContext.strongPriceLockProxy, JSON.stringify(eventDecision.eventContext));
assert(eventDecision.hardGates.volume, JSON.stringify(eventDecision.hardGates));
assert(eventDecision.breakdown.find((x) => x.key === 'participation').points >= 5, JSON.stringify(eventDecision.breakdown));



// v3.2.2: 20일선에서 크게 이탈하고 거래량이 평균 미만이면 높은 가격점수만으로 종가매수 승격 금지.
const weakTurnSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: false },
  krx: { close: 525000, open: 515000, high: 526000, low: 510000, volume: 250000, tradeAmount: 130190000000, date: '20260804', changePct: 2.34 },
  nxt: { available: true, close: 529000, final: false }, nxtGapPct: 0.76,
  indicators: { ma5: 486800, ma20: 623100, ma5SlopePct: 0.45, volumeRatio20: 0.85, closeFromHighPct: -0.19 },
  closingFlow: { availability: { smartMoney: true, program: true, foreign: true, institution: true }, smartMoneyState: 'NEUTRAL', programNetAmount: 9109, foreignNetDelta: 0, institutionNet: -20000, source: 'TEST' },
  completeness: 100,
};
const weakTurnDecision = evaluateCloseDecision(weakTurnSnapshot, null, settings.perStock['005930']);
assert.notStrictEqual(weakTurnDecision.action, 'CLOSE_BUY', JSON.stringify(weakTurnDecision));
assert.strictEqual(weakTurnDecision.hardGates.volume, false, JSON.stringify(weakTurnDecision.hardGates));
assert(weakTurnDecision.failedGates.includes('volume'));
assert(weakTurnDecision.failedGates.includes('volume'));

// v3.2.3: MA20 아래 급락주라도 스마트머니 TURN + 거래량 + 프로그램/투신/연기금 확인 시 바닥반전 엔진이 살려야 한다.
const floorSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: false },
  krx: { close: 89000, open: 83500, high: 90000, low: 83000, volume: 2400000, tradeAmount: 180000000000, date: '20260804', changePct: 6.4 },
  nxt: { available: true, close: 89500, final: false }, nxtGapPct: 0.56,
  indicators: { ma5: 91000, ma20: 103000, ma5SlopePct: 0.8, volumeRatio20: 1.65, closeFromHighPct: -1.11, closeFromLowPct: 7.23, drawdown20Pct: -18.3, higherLow5: true },
  closingFlow: { availability: { smartMoney: true, program: true, foreign: true, institution: true }, smartMoneyState: 'TURN', smartMoneyScore: 88, programNetAmount: 300000000, foreignNetDelta: 1000, institutionNet: 50000, investmentTrustNet: 20000, pensionNet: 15000, source: 'TEST' }, completeness: 100,
  closeSync: { targetDate: '20260804', krxOfficialConfirmed: true, krxStatus: 'CONFIRMED', nxtFinalConfirmed: false, officialFlowConfirmed: true },
};
const floorDecision = evaluateCloseDecision(floorSnapshot, null, settings.perStock['005930'], 0, new Date('2026-08-04T07:00:00.000Z'));
assert.strictEqual(floorDecision.engine, 'FLOOR_REVERSAL', JSON.stringify(floorDecision));
assert(floorDecision.engineScores.floorReversalGatePassed, JSON.stringify(floorDecision.hardGates));
assert(['CLOSE_BUY','HOLD'].includes(floorDecision.action), JSON.stringify(floorDecision));
assert(floorDecision.breakdown.find(x=>x.key==='smartMoney').points >= 22);
assert(floorDecision.breakdown.find(x=>x.key==='longInstitution').points > 0);

// v3.2.7: 점수가 높아도 오늘 공식 KRX 종가 동기화가 미확정이면 CLOSE_BUY를 열지 않는다.
const unconfirmedFloor = { ...floorSnapshot, closeSync: { targetDate: '20260804', krxOfficialConfirmed: false, krxStatus: 'PRESERVED_OLD_CLOSE', nxtFinalConfirmed: false, officialFlowConfirmed: false } };
const unconfirmedDecision = evaluateCloseDecision(unconfirmedFloor, null, settings.perStock['005930'], 0, new Date('2026-08-04T07:00:00.000Z'));
assert.notStrictEqual(unconfirmedDecision.action, 'CLOSE_BUY', JSON.stringify(unconfirmedDecision));
assert.strictEqual(unconfirmedDecision.hardGates.officialClose, false, JSON.stringify(unconfirmedDecision.hardGates));
assert(unconfirmedDecision.failedGates.includes('officialClose'));
assert(unconfirmedDecision.warnings.some((x) => String(x).includes('CLOSE_BUY 차단')));

const preSurgeEarly = evaluateSignal({
  price: 100200, vwap: 100000, vwapDistancePct: 0.2, turnover1m: 180_000_000,
  tradeStrength: 122, buyRatio: 57, rvol1m: 1.55, netBuyAmount5s: 35_000_000,
  netBuyAmount15s: 65_000_000, buyAcceleration: 18_000_000, largeNetAmount1m: 20_000_000,
  largeBuyCount1m: 1, largeSellCount1m: 0, spreadBps: 9, orderbookImbalance: 1.35, orderbookImbalanceEwma: 1.31,
  bidReplenishRatio: 0.13, bidReplenishEwma: 0.11, askWithdrawalRatio: 0.08, askWithdrawalEwma: 0.07, orderbookSupportStreak: 2, orderbookSampleCount: 3, programNetAmount: 100_000_000,
  programVelocity10s: 70_000_000, foreignNetDelta: 1500, breakout: false, vwapReclaim: true,
  momentum1mPct: 0.2, drawdownFromHighPct: -0.1, recentHigh: 100300, recentLow: 99700,
  smartMoneyState: 'TURN', dataCompleteness: 100, activeTier: 'FOCUS', orderbookAgeMs: 0,
  programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 6, programSampleCount: 2,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert(preSurgeEarly.preSurgeScore >= 68, JSON.stringify(preSurgeEarly));
assert(preSurgeEarly.preSurgeGroups >= 3, JSON.stringify(preSurgeEarly));
assert(['EARLY', 'BUY'].includes(preSurgeEarly.action), JSON.stringify(preSurgeEarly));

realtime.state.stocks.clear();
realtime.processRealtimeEntry({ type: '0B', item: '005930_AL', values: { '10': '100000', '15': '1000', '27': '100100', '28': '100000', '228': '130', '620': '99500', '9081': 'NXT' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
realtime.processRealtimeEntry({ type: '1h', item: '', values: { '9001': '005930_AL', '302': '삼성전자', '9068': '1', '1224': '' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
const stock = realtime.getSnapshot([{ code: '005930', name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true }]).stocks[0];
assert.strictEqual(stock.market, 'NXT');
assert.strictEqual(stock.lastTradeVenue, 'NXT');
assert.strictEqual(stock.lastTradeVenueSource, 'REALTIME_FID');
assert.strictEqual(stock.signal.action, 'BLOCKED');
assert.strictEqual(stock.signal.confirmed, false);


realtime.state.stocks.clear();
realtime.processRealtimeEntry({ type: '0B', item: '005930_AL', values: { '10': '100000', '15': '1000', '27': '100100', '28': '100000', '228': '130', '620': '99500' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
const sorUnknown = realtime.getSnapshot([{ code: '005930', name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true }]).stocks[0];
assert.strictEqual(sorUnknown.market, 'SOR');
assert.strictEqual(sorUnknown.lastTradeVenue, 'UNKNOWN');
assert.strictEqual(sorUnknown.lastTradeVenueSource, 'SOR_ROUTE_ONLY');

console.log('CHECK OK: 고정4+집중8+경량18=30종목, 급등초입/BUY 중심, 매도잡신호 제거, 종가 합리화, 단순 손절관리');

// v3.1.0-HF1 regression: the live-list comparator must not reference an undefined `s`.
{
  const pageSource = fs.readFileSync(path.join(__dirname, '..', 'pages', 'index.js'), 'utf8');
  assert(!pageSource.includes('const useClose = s.dataSource'), 'undefined comparator variable regression');
  assert(pageSource.includes('const rankA = usesCloseSnapshot(a)'), 'close/live rankA comparator missing');
  assert(pageSource.includes('const rankB = usesCloseSnapshot(b)'), 'close/live rankB comparator missing');
  assert(pageSource.includes('휴장·미측정'), 'closed market zero-to-NA display missing');
  assert(pageSource.includes('계산기준 분리:'), 'KRX/NXT calculation basis label missing');
  assert(pageSource.includes('점수 산출근거 보기'), 'close score breakdown UI missing');
  assert(pageSource.includes('데이터 완전성 구성'), 'snapshot completeness breakdown UI missing');
  assert(pageSource.includes('급등 사전포착 · 매수후보'), 'profit-focus board missing');
  assert(pageSource.includes('아이폰 푸시 켜기·테스트'), 'iPhone push test UI missing');
  assert(pageSource.includes('실제체결'), 'actual venue display missing');
  assert(pageSource.includes('장전 사전점검'), 'preflight panel missing');
  assert(pageSource.includes('장전 사전점검'), 'preflight UI missing');
  assert(pageSource.includes('아이폰 푸시 켜기·테스트'), 'push test UI missing');
  assert(pageSource.includes('실제체결'), 'actual execution venue UI missing');
}
