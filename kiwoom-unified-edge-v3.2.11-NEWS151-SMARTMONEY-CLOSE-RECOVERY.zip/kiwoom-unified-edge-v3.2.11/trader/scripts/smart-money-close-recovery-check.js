const assert = require('assert');
const { closingFlowFromLive, evaluateCloseDecision } = require('../lib/marketSnapshot');
const target='20260804';
const closeWindowAt=Date.parse('2026-08-04T06:29:00.000Z'); // 15:29 KST
const late=Date.parse('2026-08-04T11:30:00.000Z'); // 20:30 KST
const live={
  updatedAt: closeWindowAt-60*60*1000,
  tradeEventCount:20,
  smartMoney:{state:'TURN',behaviorState:'TURN',confidence:88,shakeoutScore:62,score:84},
  smartMoneyCheckpoint:{sessionDate:target,at:closeWindowAt,state:'TURN',behaviorState:'TURN',confidence:88,shakeoutScore:62,score:84},
  program:{updatedAt:0,netQty:0,netAmount:0},broker:{updatedAt:0,foreignNet:0,foreignNetDelta:0}
};
const official={date:target,fetchedAt:new Date(late).toISOString(),availability:{program:true,foreign:true,institution:true},normalized:{programNetQty:1976,programNetAmount:123,foreignNet:11196,foreignNetDelta:11196,institutionNet:10000},investor:{investmentTrust:1200,pension:800},units:{investor:'SHARES',programQty:'SHARES',programAmount:'API_AMOUNT_RAW'}};
const flow=closingFlowFromLive(live,official,null,late,target);
assert.equal(flow.availability.smartMoney,true);
assert.equal(flow.smartMoneyStatus,'CHECKPOINT');
assert.equal(flow.smartMoneyState,'TURN');
assert.equal(flow.programNetQty,1976);
assert.equal(flow.foreignNet,11196);
assert.equal(flow.institutionNet,10000);
const missing=closingFlowFromLive({...live,smartMoneyCheckpoint:null},official,null,late,target);
assert.equal(missing.availability.smartMoney,false);
assert.equal(missing.smartMoneyStatus,'MISSING');
const snapshot={krx:{close:100000,changePct:3,tradeAmount:50000000000,date:target},indicators:{ma5:98000,ma20:97000,ma5SlopePct:1,volumeRatio20:1.5,closeFromHighPct:-1,closeFromLowPct:5,drawdown20Pct:-5,higherLow5:true},nxt:{available:true,close:100200},nxtGapPct:0.2,phase:{nxtFinal:true},closeSync:{targetDate:target,krxOfficialConfirmed:true,nxtFinalConfirmed:true},closingFlow:missing,completeness:90};
const d=evaluateCloseDecision(snapshot,null,{stopPct:-3,t1Pct:3,t2Pct:5,t3Pct:8},0,new Date(late));
assert.equal(d.trust.smartMoneyStatus,'MISSING');
assert(d.breakdown.some(x=>x.key==='smartMoneyData'&&x.points===-6));
assert.notEqual(d.stage,'PRE_BUY');
console.log('SMART_MONEY_CLOSE_RECOVERY_CHECK PASS', {status:flow.smartMoneyStatus, missingPenalty:-6, units:flow.units});
