const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { buildManagedSignalPortfolio } = require('../lib/signalPortfolio');

const now = new Date('2026-08-04T02:10:00Z').getTime(); // Tue 11:10 KST
function stock(i, { change = 0.3, action = 'EARLY', behavior = 'ACCUMULATION', quality = 72, pre = 70, profit = 75 } = {}) {
  const code = String(100000 + i);
  return {
    code, name: `TEST${i}`, activeTier: 'FOCUS', price: 10000 + i * 100, changePct: change, updatedAt: now,
    venues: { KRX: { price: 10000 + i * 100, updatedAt: now }, NXT: { price: 10010 + i * 100, updatedAt: now } },
    signal: {
      action, confirmed: action === 'BUY', qualityScore: quality, profitPriorityScore: profit, preSurgeScore: pre,
      preSurgeEligible: pre >= 68, dataCompleteness: 95, negativePressureBlock: false, crossVenueConflict: false,
      smartMoneyBehaviorState: behavior, smartMoneyConfidence: 76, dualVenueReady: true, venueAgreement: 0.5,
      evaluatedAt: new Date(now).toISOString(), vetoes: [], plan: { entry: 10000 + i * 100 },
      metrics: { tradeStrength: 122, smartMoneyBehaviorState: behavior, smartMoneyConfidence: 76 },
    },
  };
}

const normal = [
  stock(1, { change: 0.4, action: 'BUY', behavior: 'TURN', quality: 89, pre: 82, profit: 86 }),
  stock(2, { change: 0.5, action: 'EARLY', behavior: 'TURN', quality: 80, pre: 78, profit: 80 }),
  stock(3, { change: 0.2, action: 'EARLY', behavior: 'ACCUMULATION' }),
  stock(4, { change: -0.1, action: 'EARLY', behavior: 'SHAKEOUT' }),
  stock(5, { change: 0.1, action: 'WAIT', behavior: 'ACCUMULATION', quality: 68, pre: 66, profit: 70 }),
  stock(6, { change: -0.2, action: 'WAIT', behavior: 'TURN', quality: 67, pre: 65, profit: 69 }),
  stock(7, { change: 0.2, action: 'WAIT', behavior: 'DISTRIBUTION', quality: 90, pre: 90, profit: 90 }),
  stock(8, { change: -0.15, action: 'WAIT', behavior: 'NEUTRAL', quality: 55, pre: 55, profit: 55 }),
];
const p = buildManagedSignalPortfolio(normal, [], { now });
assert.strictEqual(p.regime.code, 'NORMAL');
assert.ok(p.rows.length >= 4 && p.rows.length <= 6, `normal signal count=${p.rows.length}`);
assert.ok(p.rows.some((r) => r.stage === 'BUY'));
assert.ok(!p.rows.some((r) => r.smartMoneyBehaviorState === 'DISTRIBUTION'));
assert.ok(p.rows.filter((r) => r.reserveOnly).every((r) => r.stage === 'RESERVE'));

const strong = normal.map((s, idx) => ({ ...s, changePct: 1.2 + idx * 0.05 }));
const ps = buildManagedSignalPortfolio(strong, [], { now });
assert.strictEqual(ps.regime.code, 'STRONG');
assert.ok(ps.rows.length <= 6);

const weak = normal.map((s, idx) => ({ ...s, changePct: -1.2 - idx * 0.05 }));
const pw = buildManagedSignalPortfolio(weak, [], { now });
assert.strictEqual(pw.regime.code, 'WEAK');
assert.ok(pw.rows.length <= 4);

const worker = fs.readFileSync(path.join(__dirname, '..', 'worker', 'kiwoomRealtime.js'), 'utf8');
assert.ok(!worker.includes("setInterval(() => this.refreshSnapshots('schedule')"), '15-minute full REST snapshot scheduler must be removed');
assert.ok(worker.includes("KRX_CLOSE: { start: 15 * 60 + 32"));
assert.ok(worker.includes("NXT_CLOSE: { start: 20 * 60 + 1"));
const ui = fs.readFileSync(path.join(__dirname, '..', 'pages', 'index.js'), 'utf8');
for (const label of ['실시간 신호 관리 테이블', '관리점수', '현재가', '진입/기준가', '수익률', '등락률', 'KRX', 'NXT']) assert.ok(ui.includes(label), `UI missing ${label}`);
console.log(JSON.stringify({ ok: true, normal: { regime: p.regime, rows: p.rows.length }, strong: { rows: ps.rows.length }, weak: { rows: pw.rows.length }, periodicSnapshotRemoved: true, tableFields: true }, null, 2));
