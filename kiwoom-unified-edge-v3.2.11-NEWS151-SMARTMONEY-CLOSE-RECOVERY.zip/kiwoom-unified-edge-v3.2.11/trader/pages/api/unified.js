const { requireAuth } = require('../../lib/auth');
const { getItem } = require('../../lib/store');
const { mergeWatchlist } = require('../../lib/stocks');
const { mergeSettings } = require('../../lib/settings');
const { getSnapshot, setSignalSettings } = require('../../lib/realtimeStore');
const { getNewsDiscoveryFeed } = require('../../lib/newsBridge');
const { buildUnifiedOpportunities } = require('../../lib/unifiedOpportunity');
const { observeGateStats, getGateStats } = require('../../lib/buyGateStats');
const { getCachedIntradayRecommendations, getIntradayAutoApplyStatus, getAdaptiveModel } = require('../../lib/recommendationEngine');

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  if (!['GET','POST'].includes(req.method)) return res.status(405).json({ error:'Method Not Allowed' });
  try {
    const force = req.method === 'POST' || ['1','true','yes'].includes(String(req.query?.force || '').toLowerCase());
    const [userStocks, savedSettings, newsFeed, intraday, intradayAutoApply, learningModel] = await Promise.all([
      getItem('watchlist:user'), getItem('settings'), getNewsDiscoveryFeed({ force }),
      getCachedIntradayRecommendations(), getIntradayAutoApplyStatus(), getAdaptiveModel(),
    ]);
    const watchlist = mergeWatchlist(userStocks || []);
    const settings = mergeSettings(savedSettings);
    setSignalSettings(settings.signal);
    const snapshot = getSnapshot(watchlist);
    const opportunities = buildUnifiedOpportunities(snapshot.stocks, settings, newsFeed);
    const gateStats = await observeGateStats(opportunities).catch(() => getGateStats());
    const watched = new Set(watchlist.map((x) => x.code));
    const reservoir = (newsFeed.items || []).map((row) => ({ ...row, watched: watched.has(row.code) })).slice(0, 100);
    const top = opportunities.filter((x) => x.stage !== 'NONE').slice(0, 12);
    return res.status(200).json({
      version: '3.2.8',
      news: {
        configured: newsFeed.configured, connected: newsFeed.connected, stale: newsFeed.stale || false,
        newsVersion: newsFeed.newsVersion || null, generatedAt: newsFeed.generatedAt || null,
        candidateCount: newsFeed.candidateCount || reservoir.length, reservoirCount: reservoir.length,
        error: newsFeed.error || null, universe: newsFeed.universe || null,
      },
      reservoir,
      opportunities: top,
      counts: {
        buy: opportunities.filter((x) => x.stage === 'BUY').length,
        preBuy: opportunities.filter((x) => x.stage === 'PRE_BUY').length,
        early: opportunities.filter((x) => x.stage === 'EARLY').length,
        watch: opportunities.filter((x) => x.stage === 'WATCH').length,
        watched: watchlist.length,
      },
      gateStats,
      intradayRecommendations: intraday,
      intradayAutoApply,
      learningModel,
      policy: {
        preBuy: 'PRE-BUY는 확정매수가 아니라 BUY 안전게이트 중 1~3개가 남은 진입준비 단계입니다.',
        news: '뉴스는 감시대상 발굴/우선순위에만 사용하며 확정 BUY 기준은 변경하지 않습니다.',
        rotation: '장중 자동적용 ON일 때 5분 주기로 AUTO 경량종목만 최대 2개 교체합니다. 수동/고정/집중종목은 보호합니다.',
      },
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
