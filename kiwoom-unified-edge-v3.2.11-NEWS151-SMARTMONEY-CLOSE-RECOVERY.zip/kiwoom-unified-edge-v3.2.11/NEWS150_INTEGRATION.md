# News Radar v1.5.0-unified integration

- Trader: 3.2.1 unchanged.
- News Radar: 1.5.0-unified.
- Internal bridge: `/api/discovery-feed` + `INTERNAL_BRIDGE_TOKEN` preserved.
- Storage: `/app/data` and `news-radar-data` volume preserved.
- Freshness: <=60m / <=180m / <=6h realtime tiers; >24h blocked from realtime ingestion.
- Low-value filter: primary-index marketplace/document/product pages without event evidence are rejected.
- Mapping: inferred Korean related stocks are stored in `relatedStocks`, capped at 3; direct mentions remain in `matched`.
- Deployment port: host 127.0.0.1:3100 -> news-radar:3000; trader continues on 127.0.0.1:3000.

## v1.5.1 HOTFIX
- `/api/discovery-feed` hot path no longer recomputes AUTO200/second-order/early-edge across the full news set on every 30s bridge poll.
- It consumes the already-ingested `matched` + `relatedStocks` TOP3 mapping, applies freshness and impact scoring, and returns the same candidate schema.
- This removes repeated O(news × universe) synchronous work that could block the endpoint for >5s on Lightsail.
