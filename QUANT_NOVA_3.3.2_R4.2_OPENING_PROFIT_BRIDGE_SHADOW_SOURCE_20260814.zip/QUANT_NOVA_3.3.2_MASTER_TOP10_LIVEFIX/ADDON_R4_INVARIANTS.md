# NOVA 3.3.2 R4 display-only decision panels

- Baseline runtime version remains `NOVA-3.3.2-MASTER-TOP10-LIVEFIX`.
- No Kiwoom REST endpoint, request cadence, WebSocket registration, ingest path, signal policy, journal, recovery, Guard, or Caddy logic is changed.
- `LARGE-CAP SWING DECISION TOP10` is a read-only ranking over candidates already present in RuntimeState and an operator-defined code universe. It does not claim to calculate live market capitalization.
- `PRE-IGNITION + 반복신호 가속 TOP10` is display/verification only. Repeat acceleration never mutates `valid_repeat_count`, entry lanes, lifecycle state, or official BUY state.
- The add-on calls only the local same-origin `/api/decision-panels` endpoint through NOVA's already-authenticated fetch helper. It makes zero broker REST calls and zero WebSocket subscriptions.
- Add-on failure is fail-open for the baseline dashboard: the original panels, live bridge, and BUY signal engine continue independently.
