# ADDON R4.1 INVARIANTS

R4.1 is a display/verification refinement of the R4 decision panels.

Hard invariants:
- No Kiwoom REST endpoint, websocket subscription, ingest path, BUY policy, journal, Guard, or Caddy change.
- LARGE-CAP SWING DECISION is decision/display only; it cannot publish or mutate official BUY state.
- PRE-IGNITION repeat acceleration is VERIFY/DISPLAY ONLY; it cannot mutate official signal state.
- During a live session, the engine keeps the last rendered live Top10 snapshot in memory.
- After session close, the last live snapshot is frozen when available.
- After a restart during the closed session, close values are reconstructed from the retained venue-close tick/metrics and signal history; current post-close freshness is never used to cap the close score.
- KRX close reconstruction reference: 15:30 KST. NXT close reconstruction reference: 20:00 KST.
- Close repeat windows mean the final 10/30 minutes before the applicable venue close.
- iPhone rows must render recommendation/risk fields without horizontal clipping.
