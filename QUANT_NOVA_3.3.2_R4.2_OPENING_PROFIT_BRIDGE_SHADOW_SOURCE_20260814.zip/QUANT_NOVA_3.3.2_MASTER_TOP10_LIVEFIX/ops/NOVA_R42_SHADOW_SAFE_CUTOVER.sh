#!/usr/bin/env bash
set -Eeuo pipefail

APP="quant-nova"
R42_IMAGE="quant-nova:3.3.2-r42-shadow"
R41_IMAGE="quant-nova:3.3.2-r41-standby"
SRC_DIR="${1:-$(pwd)}"
R41_ZIP="$SRC_DIR/rollback/QUANT_NOVA_3.3.2_LARGECAP_PREIGNITION_R4.1_BASELINE_SOURCE_20260814.zip"
R41_SHA="25aa65878d4f497564bace3ce17a16b774454cb7a2fe9948a8a5796a4c5e4895"
BACKUP="quant-nova-pre-r42-$(date +%Y%m%d-%H%M%S)"
FAILED="quant-nova-r42-failed-$(date +%Y%m%d-%H%M%S)"
TMP="/tmp/nova-r42-cutover-$$"
mkdir -p "$TMP"

say(){ echo; echo "===== $* ====="; }
inspect_json(){ docker exec "$1" python - "$2" <<'PY'
import json,sys,urllib.request
p=sys.argv[1]
try:
  with urllib.request.urlopen('http://127.0.0.1:8000'+p,timeout=5) as r: print(r.read().decode())
except Exception as e: print(json.dumps({'ok':False,'error':repr(e)}));sys.exit(2)
PY
}

say "0. PRECHECK"
test -f "$SRC_DIR/Dockerfile"; test -f "$R41_ZIP"
test "$(sha256sum "$R41_ZIP"|awk '{print $1}')" = "$R41_SHA"
docker inspect "$APP" >/dev/null
inspect_json "$APP" /api/live-dashboard > "$TMP/baseline-dashboard.json" || true
inspect_json "$APP" /api/livez > "$TMP/baseline-livez.json" || true

docker inspect "$APP" --format '{{range .Config.Env}}{{println .}}{{end}}' > "$TMP/env"
NETWORK="$(docker inspect "$APP" --format '{{.HostConfig.NetworkMode}}')"
RESTART="$(docker inspect "$APP" --format '{{.HostConfig.RestartPolicy.Name}}')"
[ -n "$RESTART" ] || RESTART="unless-stopped"
MOUNT_ARGS=()
while IFS='|' read -r TYPE SOURCE DEST RW NAME; do
  TYPE="$(echo "$TYPE"|xargs)"; SOURCE="$(echo "$SOURCE"|xargs)"; DEST="$(echo "$DEST"|xargs)"; RW="$(echo "$RW"|xargs)"; NAME="$(echo "$NAME"|xargs)"
  [ -z "$TYPE" ] && continue; MODE=""; [ "$RW" = "true" ] || MODE=":ro"
  if [ "$TYPE" = "bind" ]; then MOUNT_ARGS+=( -v "${SOURCE}:${DEST}${MODE}" ); elif [ "$TYPE" = "volume" ]; then MOUNT_ARGS+=( -v "${NAME}:${DEST}${MODE}" ); fi
done < <(docker inspect "$APP" --format '{{range .Mounts}}{{println .Type "|" .Source "|" .Destination "|" .RW "|" .Name}}{{end}}')

say "1. BUILD EXACT R4.1 STANDBY"
rm -rf "$TMP/r41"; mkdir -p "$TMP/r41"; python3 -m zipfile -e "$R41_ZIP" "$TMP/r41"
R41_SRC="$(find "$TMP/r41" -mindepth 1 -maxdepth 1 -type d | head -1)"; test -f "$R41_SRC/Dockerfile"
docker build --no-cache -t "$R41_IMAGE" "$R41_SRC"

say "2. BUILD R4.2 SHADOW"
docker build --no-cache -t "$R42_IMAGE" "$SRC_DIR"

run_like_baseline(){
  local image="$1"
  docker run -d --name "$APP" --restart "$RESTART" --network "$NETWORK" --env-file "$TMP/env" "${MOUNT_ARGS[@]}" "$image"
}
wait_health(){
  local i h
  for i in $(seq 1 36); do
    h="$(docker inspect "$APP" --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' 2>/dev/null || true)"
    [ "$h" = "healthy" ] && return 0
    sleep 5
  done
  return 1
}
restore_original(){
  docker rm -f "$APP" >/dev/null 2>&1 || true
  if docker inspect "$BACKUP" >/dev/null 2>&1; then docker rename "$BACKUP" "$APP"; docker start "$APP"; fi
}
rollback(){
  trap - ERR
  say "ROLLBACK LEVEL 1 -> R4.1 STANDBY"
  docker rm -f "$APP" >/dev/null 2>&1 || true
  if run_like_baseline "$R41_IMAGE" && wait_health; then
    if docker exec "$APP" python /app/scripts/r42_shadow_acceptance.py >/dev/null 2>&1; then :; fi
    echo "ROLLBACK_TARGET=R4.1_STANDBY HEALTH=healthy"
    echo "ORIGINAL_BACKUP=$BACKUP"
    exit 42
  fi
  say "ROLLBACK LEVEL 2 -> ORIGINAL RUNNING BASELINE"
  restore_original; sleep 15
  docker ps --filter "name=^/${APP}$" --format 'NAME={{.Names}} IMAGE={{.Image}} STATUS={{.Status}}'
  exit 43
}
trap rollback ERR

say "3. CUTOVER QUANT-NOVA ONLY"
docker stop "$APP"; docker rename "$APP" "$BACKUP"; run_like_baseline "$R42_IMAGE"; wait_health

say "4. R4.2 INTERNAL ACCEPTANCE"
docker exec "$APP" python /app/scripts/r42_shadow_acceptance.py | tee "$TMP/r42-acceptance.json"

say "5. BASELINE REGRESSION GUARDS"
python3 - "$TMP/baseline-dashboard.json" "$TMP/r42-acceptance.json" <<'PY'
import json,sys
try:b=json.load(open(sys.argv[1]))
except Exception:b={}
line=open(sys.argv[2]).read().strip().splitlines()[-1];a=json.loads(line)
assert a.get('ok') is True,a
bc=int(b.get('candidate_count') or 0);ac=int(a.get('candidate_count') or 0)
if bc>=20: assert ac>=max(5,int(bc*.40)),('candidate_collapse',bc,ac)
buy0=len((b.get('boards') or {}).get('live_buy') or []);buy1=int(a.get('live_buy_count') or 0)
if buy0>0: assert buy1>0,('official_buy_board_disappeared',buy0,buy1)
print('REGRESSION_GUARDS=PASS baseline_candidates=%d after=%d baseline_live_buy=%d after=%d'%(bc,ac,buy0,buy1))
PY

say "6. STATIC/UI CONTRACT"
docker exec "$APP" python - <<'PY'
from pathlib import Path
h=Path('/app/static/index.html').read_text();j=Path('/app/static/opening-bridge-shadow.js').read_text();
assert 'opening_bridge_panel' in h and 'largecap_swing' in h and 'preignition_accel' in h
assert 'BUY HANDOFF OFF' in j and "classList.remove('shadow-ready')" in j
print('STATIC_UI_FAIL_OPEN=PASS')
PY

say "7. GUARD READ-ONLY CHECK"
docker exec nova-http-guard python - <<'PY'
import json,urllib.request
for p in ['/api/livez','/api/readyz','/api/opening-bridge-shadow']:
  with urllib.request.urlopen('http://quant-nova:8000'+p,timeout=5) as r:
    b=r.read();print(p,r.status,len(b));assert r.status==200 and b
PY

say "8. FINAL"
trap - ERR
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'
echo "R42_SHADOW_SUCCESS"
echo "R41_STANDBY_IMAGE=$R41_IMAGE"
echo "ORIGINAL_BACKUP=$BACKUP"
echo "GUARD=NOT_TOUCHED"
echo "CADDY=NOT_TOUCHED"
echo "BUY_HANDOFF=OFF"
