(()=>{
const $=id=>document.getElementById(id);const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,d=0)=>v===null||v===undefined||v===''?'-':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d,minimumFractionDigits:d});
const cls=v=>Number(v)>0?'up':Number(v)<0?'down':'';let timer=null,busy=false,lastOk=0;
function empty(rank){return `<div class="drow empty"><div class="dtop"><div class="rank">${rank}</div><div class="dname"><b>-</b><small>대기</small></div><div></div><div></div><div></div></div></div>`}
function largeRow(r,rank){
  if(!r)return empty(rank);
  const dc=String(r.decision||'WAIT'),k=dc==='NOW'?'decision-now':dc==='WAIT'?'decision-wait':'decision-avoid';
  const prefix=r.decision_mode==='CLOSE'?'종가 ':'';
  const entry=r.entry_low?`${fmt(r.entry_low)}~${fmt(r.entry_high)}`:'대기';
  const reasons=esc((r.reasons||[]).slice(0,3).join(' · '));
  return `<div class="drow drow-large">
    <div class="dtop">
      <div class="rank">${rank}</div>
      <div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(r.entry_state)} · 반복 ${fmt(r.valid_repeat_count)}</small></div>
      <div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div>
      <div class="dscore">${fmt(r.score,1)}점</div>
      <div class="ddecision ${k}"><b>${prefix}${esc(dc)}</b></div>
    </div>
    <div class="dsub">
      <div class="dreasons">${reasons||'판정근거 대기'}</div>
      <div class="dplan"><b>추천진입 ${entry}</b><span>추격금지 ${r.chase_limit?`>${fmt(r.chase_limit)}`:'-'}</span><span>손절 ${fmt(r.stop)}</span><span>T1 ${fmt(r.t1)}</span><span>T2 ${fmt(r.t2)}</span></div>
    </div>
  </div>`
}
function preRow(r,rank){
  if(!r)return empty(rank);
  const st=String(r.state||'WATCH'),k=st==='CONFIRM'?'decision-confirm':st==='PRE'?'decision-pre':'decision-avoid';
  const close=r.window_mode==='CLOSE',prefix=close?'마감':'';
  const reasons=esc((r.reasons||[]).slice(0,3).join(' · '));
  return `<div class="drow drow-pre">
    <div class="dtop">
      <div class="rank">${rank}</div>
      <div class="dname"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue)} · ${esc(r.entry_state)} · 당일반복 ${fmt(r.repeat_total)}</small></div>
      <div class="dnum">${fmt(r.price)}<br><span class="${cls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div>
      <div class="dscore">${fmt(r.score,1)}점</div>
      <div class="ddecision ${k}"><b>${close?'마감 ':''}${esc(st)} ${esc(r.accel||'→')}</b></div>
    </div>
    <div class="dsub">
      <div class="dreasons">${reasons||'가속근거 대기'}</div>
      <div class="dplan preplan"><b>${prefix}10분 ${fmt(r.signal_10m)}회 · ${prefix}30분 ${fmt(r.signal_30m)}회</b><span>VWAP ${fmt(r.vwap_gap,2)}%</span><span>BP ${fmt(r.buy_pressure,0)}%</span><span>거래가속 ${fmt(r.volume_accel,2)}x</span><span>SM ${fmt(r.smart_money_score,1)}</span></div>
    </div>
  </div>`
}
function fill(id,rows,fn){const root=$(id);if(!root)return;const a=(rows||[]).slice(0,10);while(a.length<10)a.push(null);root.innerHTML=a.map((r,i)=>fn(r,i+1)).join('')}
function render(j){
  fill('largecap_swing',j.largecap,largeRow);fill('preignition_accel',j.preignition,preRow);
  const a=$('largecap_contract'),b=$('preignition_contract');
  if(a)a.textContent=j.market_active?'LIVE · 지정 대형주 universe · 추천진입/리스크 DISPLAY ONLY · 기존 BUY 로직 미반영':`SESSION CLOSED · 종가판정 FROZEN (${j.freeze_source||'CLOSE'}) · 기존 BUY 로직 미반영`;
  if(b)b.textContent=j.market_active?'LIVE · 최근 10/30분 반복신호 가속 · DISPLAY/VERIFY ONLY · 공식 BUY 미반영':`SESSION CLOSED · 마감 직전 10/30분 FROZEN (${j.freeze_source||'CLOSE'}) · 공식 BUY 미반영`;
  lastOk=Date.now()
}
async function tick(){if(busy)return;busy=true;try{const f=window.NOVA_FETCH_JSON;if(typeof f!=='function')return;const j=await f('/api/decision-panels',3000);if(j&&j.ok)render(j)}catch(_){if(Date.now()-lastOk>8000){const a=$('largecap_contract'),b=$('preignition_contract');if(a)a.textContent='보조 패널 재연결 중 · 기준 NOVA에는 영향 없음';if(b)b.textContent='보조 패널 재연결 중 · 기준 NOVA에는 영향 없음'}}finally{busy=false}}
function boot(){if(timer)return;tick();timer=setInterval(tick,1800)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
