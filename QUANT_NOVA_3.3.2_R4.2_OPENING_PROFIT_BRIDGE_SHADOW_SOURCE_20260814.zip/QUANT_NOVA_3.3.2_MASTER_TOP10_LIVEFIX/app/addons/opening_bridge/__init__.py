from .engine import OpeningProfitBridgeShadow

__all__ = ['OpeningProfitBridgeShadow']
