from __future__ import annotations
from datetime import datetime, timedelta
from app.runtime.clock import KST, is_trading_date, next_trading_day, trade_day


def phase_at(dt: datetime) -> str:
    dt = dt.astimezone(KST)
    s = dt.hour * 3600 + dt.minute * 60 + dt.second
    trading = is_trading_date(dt.date())
    if not trading:
        return 'PRIOR_CLOSE_FROZEN'
    if 15 * 3600 + 29 * 60 + 30 <= s < 15 * 3600 + 40 * 60:
        return 'KRX_CLOSE_CAPTURE'
    if 19 * 3600 + 30 * 60 <= s < 20 * 3600:
        return 'CLOSE_TRACK'
    if s >= 20 * 3600 or s < 8 * 3600:
        return 'PRIOR_CLOSE_FROZEN'
    if 8 * 3600 <= s < 8 * 3600 + 50 * 60:
        return 'PREMARKET_RECHECK'
    if 8 * 3600 + 50 * 60 <= s < 9 * 3600:
        return 'OPENING_HANDOFF'
    if 9 * 3600 <= s < 9 * 3600 + 30 * 60:
        return 'SHAKEOUT_WATCH'
    if 9 * 3600 + 30 * 60 <= s < 10 * 3600:
        return 'REVERSAL_EARLY'
    return 'NORMAL_INTRADAY'


def source_day(dt: datetime) -> str:
    dt = dt.astimezone(KST)
    if dt.hour < 8:
        d = dt.date() - timedelta(days=1)
        while not is_trading_date(d):
            d -= timedelta(days=1)
        return d.strftime('%Y%m%d')
    return dt.date().strftime('%Y%m%d') if is_trading_date(dt.date()) else trade_day()


def effective_day(source: str) -> str:
    return next_trading_day(source)


def visible_effective_day(dt: datetime, phase: str) -> str:
    s = dt.hour * 3600 + dt.minute * 60 + dt.second
    if phase in ('KRX_CLOSE_CAPTURE', 'CLOSE_TRACK') or s >= 20 * 3600:
        return effective_day(source_day(dt))
    if is_trading_date(dt.date()):
        return dt.strftime('%Y%m%d')
    return next_trading_day(source_day(dt))


def display_title(phase: str) -> str:
    return {
        'KRX_CLOSE_CAPTURE': 'KRX 종가후보 · CLOSE SNAPSHOT TOP10',
        'CLOSE_TRACK': 'NXT 종가후보 · CLOSE TRACK TOP10',
        'PRIOR_CLOSE_FROZEN': '전일 종가후보 · FROZEN TOP10',
        'PREMARKET_RECHECK': '전일후보 · PREMARKET RECHECK TOP10',
        'OPENING_HANDOFF': 'OPENING HANDOFF TOP10',
        'SHAKEOUT_WATCH': 'PRIOR + TODAY · SHAKEOUT WATCH TOP10',
        'REVERSAL_EARLY': 'PRIOR + TODAY · REVERSAL EARLY TOP10',
        'NORMAL_INTRADAY': 'OPENING PROFIT BRIDGE · NORMAL TRACK',
    }.get(phase, 'NOVA OPENING PROFIT BRIDGE TOP10')
