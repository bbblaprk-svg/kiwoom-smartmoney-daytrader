"""Read-only UI decision add-ons. Never participates in official signal generation."""
