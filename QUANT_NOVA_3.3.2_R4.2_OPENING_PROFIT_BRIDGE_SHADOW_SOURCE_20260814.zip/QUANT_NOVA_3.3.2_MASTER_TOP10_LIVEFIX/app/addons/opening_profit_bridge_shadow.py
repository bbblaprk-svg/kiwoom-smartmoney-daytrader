from app.addons.opening_bridge import OpeningProfitBridgeShadow

__all__ = ['OpeningProfitBridgeShadow']
