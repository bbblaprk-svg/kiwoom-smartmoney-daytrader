# NOVA R4.2 OPENING PROFIT BRIDGE — SHADOW SAFETY CONTRACT

R4.2-SHADOW extends R4.1 only. It is not an official BUY engine.

Hard invariants:
1. No new Kiwoom REST calls.
2. No new Kiwoom WebSocket subscriptions.
3. No modification of ENTRY_V18 / official BUY state.
4. `buy_handoff_enabled` is hard-coded false in R4.2-SHADOW.
5. PRIOR and TODAY compete in a read-only common rank after the opening handoff; PRIOR receives no origin bonus.
6. 08:00~08:50 PREMARKET_RECHECK uses fresh NXT PRE ticks only. KRX substitution is forbidden.
7. NXT MAIN is not treated active before MarketPhaseResolver says it is active (09:00:30 policy).
8. Candidates are never deleted by the addon. Shadow states/transitions are persisted separately.
9. Addon failure is fail-open: base NOVA, official BUY, WS, REST, Guard and Caddy continue.
10. UI failure removes `shadow-ready` and reveals the legacy Opening board automatically.
11. Protected R4.1 files must remain byte-identical unless explicitly listed in the R4.2 change manifest.
12. Deployment acceptance must roll back on base liveness/readiness failure, blank UI, WS regression, candidate collapse, official BUY count anomaly, duplicate bridge IDs, trade-day contamination, or stale promotion.
