# Lightsail v3.2.1 UNIFIED 업데이트

GitHub 저장소 최상위에 아래 2개 파일을 올린 뒤 업데이트 스크립트를 실행합니다.

- `kiwoom-unified-edge-v3.2.1-FINAL.zip`
- `update-lightsail-v3.2.1-UNIFIED-FINAL.sh`

업데이터는 기존 `.env`를 통합앱 경로에서 우선 읽고, 없으면 기존 키움앱 경로에서 읽습니다. Kiwoom 앱키/시크릿과 REST/WebSocket 설정은 덮어쓰지 않습니다.

AWS Docker build 단계에서 source manifest, 전체 회귀검사, 30종목 부하검사, Next production build를 모두 통과한 경우에만 `kiwoom-app`/`news-radar`를 교체합니다. 실패 시 기존 컨테이너로 롤백합니다.

v3.2.1 추가환경 기본값:
- `MARKET_PROFILE_TTL_MS=86400000`
- `MARKET_PROFILE_ENRICH_LIMIT=60`
- `MARKET_POOL_MAX=40`

시총 보강조회는 추천용 캐시이며 실시간 WebSocket 구독수와 BUY 판정엔진을 변경하지 않습니다.
