const path = require('path');
const os = require('os');
const fs = require('fs');
const assert = require('assert');

process.env.STORE_DIR = path.join(os.tmpdir(), `news-radar-check-${Date.now()}-${process.pid}`);
process.env.APP_ACCESS_TOKEN = 'test-access-token-123456789';
process.env.APP_SESSION_SECRET = 'test-session-secret-12345678901234567890';
process.env.SEC_USER_AGENT = 'KRMarketNewsRadar test@example.com';
process.env.NODE_ENV = 'test';
process.env.OFFICIAL_ONLY_FREE_MODE = 'true';
process.env.NAVER_PUBLIC_ENABLED = 'true';
process.env.MAX_INGEST_AGE_HOURS = '48';
process.env.NEWS_VIEW_HOURS = '48';
process.env.SMART_NEWS_WINDOW_HOURS = '48';
process.env.SEMIAI_NEWS_WINDOW_HOURS = '48';
process.env.IMPORTANT_NEWS_WINDOW_HOURS = '48';
process.env.WEEKEND_VIEW_HOURS = '48';

const { matchWatchlist, matchMacroTopics } = require('../lib/matcher');
const { tagSentiment } = require('../lib/sentiment');
const { parseRss, fetchFeed, rssCacheStats } = require('../lib/sources/rss');
const { parseNaverSearchHtml } = require('../lib/sources/naverPublic');
const store = require('../lib/store');
const newsStore = require('../lib/newsStore');
const macroTopicsLib = require('../lib/macroTopics');
const { mapFinnhubItem } = require('../lib/sources/finnhub');
const { setSessionCookie, isAuthenticated } = require('../lib/auth');
const {
  Poller, msToNextKoreaDay, msToNextKoreaWeekday, isKoreaWeekend, collectionMode, inKoreaWindow,
} = require('../worker/poller');
const { assessImportance, inferThemes, IMPORTANT_THRESHOLD } = require('../lib/importance');
const { analyzeMarketImpact, SMART_MONEY_THRESHOLD } = require('../lib/marketImpact');
const { getOfficialSources, weightedOfficialJobs } = require('../lib/officialSources');
const { matchThemes, buildThemeBriefs } = require('../lib/themeBrief');
const { matchChains, buildSemiconductorBriefs, CHAINS } = require('../lib/semiconductorBrief');
const { UNIVERSE, EXPANDED_UNIVERSE, matchUniverse, AUTO_UNIVERSE_MAX } = require('../lib/autoUniverse');
const { buildAffectedStocks } = require('../lib/affectedStocks');
const { buildSecondOrderBriefs, buildSecondOrderCandidates, buildExpandedDiscovery } = require('../lib/secondOrder');
const { analyze: analyzeMarketPulse } = require('../lib/marketPulse');
const { sessionSnapshot, newsThemes: usNewsThemes, buildDomesticCandidates: buildUsDomesticCandidates, buildNarrative: buildUsNarrative } = require('../lib/usMarketDesk');
const { targetInfo: nextTargetInfo, clusterNews: clusterNextUsNews, buildComponents: buildNextUsComponents, rawProbabilities: nextRawProbabilities, calibrateVector: calibrateNextUsVector, classifyReturn: classifyNextUsReturn, impactCandidates: nextUsImpactCandidates, buildNarrative: buildNextUsNarrative } = require('../lib/nextUsSession');
const { buildForeignLeadBriefs, storyCandidates, isForeign, isDomestic, MAX_CANDIDATES } = require('../lib/foreignLead');
const { buildEarlyEdges, hiddenDemandLinks, marketReactionScore } = require('../lib/earlyEdge');
const { buildActiveMonitor, MAX_ACTIVE } = require('../lib/activeMonitor');
const { normalizeRow: normalizeMarketRow } = require('../lib/marketSnapshot');
const { normalizeStock: normalizeV313Stock } = require('../lib/v313Bridge');
const { estimateUpsideProbability, rankByUpside } = require('../lib/upsideProbability');
const calibrationEngine = require('../lib/predictionCalibration');
const { MAX_ITEMS: WATCHLIST_MAX } = require('../lib/watchlist');

async function main() {
  const watchlist = [
    { id: 'a1', name: '삼성전자', aliases: ['삼전', 'Samsung Electronics'], code: '005930' },
    { id: 'a2', name: 'SK하이닉스', aliases: [], code: '000660' },
  ];
  assert.strictEqual(matchWatchlist({ title: '삼전, 역대 최대 실적', description: '' }, watchlist)[0].name, '삼성전자');
  assert.strictEqual(matchWatchlist({ title: '오늘의 날씨', description: '' }, watchlist).length, 0);
  assert.strictEqual(WATCHLIST_MAX, 200);
  assert.strictEqual(AUTO_UNIVERSE_MAX, 200);
  assert.strictEqual(UNIVERSE.length, 200);
  assert.ok(EXPANDED_UNIVERSE.length > 200);
  assert.ok(EXPANDED_UNIVERSE.some((row) => row.scope === 'EXPAND'));
  assert.ok(EXPANDED_UNIVERSE.some((row) => row.name === '인텍플러스' && row.scope === 'EXPAND'));
  assert.strictEqual(MAX_ACTIVE, 20);
  assert.strictEqual(fs.existsSync(path.join(__dirname, '../lib/kiwoomMarket.js')), false);
  const marketSnapshotSource = fs.readFileSync(path.join(__dirname, '../lib/marketSnapshot.js'), 'utf8');
  assert.ok(!/KIWOOM_APP_KEY|KIWOOM_SECRET_KEY|kiwoomMarket/.test(marketSnapshotSource));
  assert.ok(UNIVERSE.some((row) => row.name === '한미반도체'));
  assert.ok(UNIVERSE.some((row) => row.name === '현대차'));
  assert.ok(UNIVERSE.some((row) => row.name === 'HD현대일렉트릭'));
  assert.ok(UNIVERSE.some((row) => row.name === 'LG에너지솔루션'));
  assert.strictEqual(matchUniverse({ title: 'Global market rallies strongly', description: '' }).some((row) => row.name === 'KT'), false);
  assert.strictEqual(matchUniverse({ title: 'KT 데이터센터 투자 확대', description: '' }).some((row) => row.name === 'KT'), true);

  assert.strictEqual(tagSentiment('역대 최대 실적과 자사주 매입').label, 'positive');
  assert.strictEqual(tagSentiment('대규모 적자와 거래정지').label, 'negative');
  assert.strictEqual(tagSentiment('earnings beat after upgrade').label, 'positive');

  const officialMeta = {
    id: 'nvidia-press', label: 'NVIDIA 공식 보도자료', tier: 'primary', priority: 3,
    tags: ['AI', 'GPU', 'HBM'], official: true,
  };
  const rssXml = `<rss><channel><item><title>NVIDIA Announces Blackwell Expansion</title><description><![CDATA[AI infrastructure and HBM demand rise 35%]]></description><link>https://example.com/1</link><pubDate>${new Date().toUTCString()}</pubDate></item></channel></rss>`;
  const officialItems = parseRss(rssXml, 'https://example.com/rss', officialMeta);
  assert.strictEqual(officialItems.length, 1);
  assert.strictEqual(officialItems[0].source, 'official');
  assert.strictEqual(officialItems[0].officialDirect, true);
  assert.strictEqual(officialItems[0].sourceId, 'nvidia-press');

  const primaryIndexedMeta = { id: 'tsmc-primary-index', label: 'TSMC 공식발표 색인', tier: 'primary-index', priority: 3, primaryIndexed: true, official: false };
  const primaryIndexedItems = parseRss(rssXml.replace('NVIDIA Announces Blackwell Expansion', 'TSMC 2nm capacity and CoWoS expansion'), 'https://example.com/tsmc-index', primaryIndexedMeta);
  assert.strictEqual(primaryIndexedItems[0].primaryIndexed, true);
  assert.strictEqual(isForeign(primaryIndexedItems[0]), true);
  assert.strictEqual(isDomestic({ sourceTier: 'domestic-media' }), true);

  const mediaMeta = { id: 'mk-stock', label: '매일경제 증권', tier: 'domestic-media', priority: 3, official: false };
  const mediaItems = parseRss(rssXml.replace('NVIDIA Announces Blackwell Expansion', 'SK하이닉스 HBM 투자 확대'), 'https://www.mk.co.kr/rss/50200011/', mediaMeta);
  assert.strictEqual(mediaItems.length, 1);
  assert.strictEqual(mediaItems[0].source, 'media');
  assert.strictEqual(mediaItems[0].officialDirect, false);
  assert.strictEqual(mediaItems[0].sourceLabel, '매일경제 증권');

  const naverHtml = `<div class="news_wrap"><a class="news_tit" href="https://n.news.naver.com/mnews/article/001/0012345678">삼성전자 HBM 공급 확대 기대</a><span>25분 전</span></div>`;
  const naverRows = parseNaverSearchHtml(naverHtml, '반도체 AI', Date.UTC(2026, 7, 2, 6, 0, 0));
  assert.strictEqual(naverRows.length, 1);
  assert.strictEqual(naverRows[0].source, 'naver-public');
  assert.strictEqual(naverRows[0].sourceLabel, '네이버 뉴스');
  assert.strictEqual(naverRows[0].publishedTimeReliable, true);
  const naverUnknown = parseNaverSearchHtml(`<div class="news_wrap"><a class="news_tit" href="https://n.news.naver.com/mnews/article/001/0099999999">오래된 기사도 검색결과에 노출될 수 있음</a><span>언론사 제공</span></div>`, '반도체', Date.UTC(2026, 7, 2, 6, 0, 0));
  assert.strictEqual(naverUnknown.length, 1);
  assert.strictEqual(naverUnknown[0].publishedAt, null);
  assert.strictEqual(naverUnknown[0].publishedTimeReliable, false);

  const atomXml = `<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>SEC filing</title><summary>Form 8-K</summary><link rel="alternate" href="https://example.com/a?x=1&amp;y=2"/><updated>${new Date().toISOString()}</updated></entry></feed>`;
  const atom = parseRss(atomXml, 'https://example.com/atom', {
    id: 'sec-current-8k', label: 'SEC 최신 8-K', tier: 'primary', priority: 3, official: true,
  });
  assert.strictEqual(atom.length, 1);
  assert.strictEqual(atom[0].link, 'https://example.com/a?x=1&y=2');
  assert.strictEqual(atom[0].source, 'official');

  const originalFetch = global.fetch;
  let conditionalCalls = 0;
  let secondHeaders = null;
  global.fetch = async (_url, options = {}) => {
    conditionalCalls += 1;
    if (conditionalCalls === 1) {
      return new Response(rssXml, { status: 200, headers: { ETag: '"feed-v1"', 'Last-Modified': new Date().toUTCString() } });
    }
    secondHeaders = options.headers || {};
    return new Response(null, { status: 304 });
  };
  const conditionalUrl = 'https://conditional.example/feed.xml';
  assert.strictEqual((await fetchFeed(conditionalUrl, { sourceMeta: officialMeta })).length, 1);
  assert.strictEqual((await fetchFeed(conditionalUrl, { sourceMeta: officialMeta })).length, 0);
  assert.strictEqual(secondHeaders['If-None-Match'], '"feed-v1"');
  assert.ok(rssCacheStats().conditionalEntries >= 1);
  global.fetch = originalFetch;

  process.env.NAVER_CLIENT_ID = 'should-not-enable';
  process.env.NAVER_CLIENT_SECRET = 'should-not-enable';
  process.env.DART_API_KEY = 'should-not-enable';
  process.env.FINNHUB_API_KEY = 'should-not-enable';
  const freePoller = new Poller();
  const freeSnapshot = freePoller.getSnapshot();
  assert.strictEqual(freeSnapshot.officialOnlyFreeMode, true);
  assert.strictEqual(freeSnapshot.sources.official.configured, true);
  assert.strictEqual(freeSnapshot.sources.naverPublic.configured, true);
  assert.strictEqual(freeSnapshot.sources.naver.configured, false);
  assert.strictEqual(freeSnapshot.sources.dart.configured, false);
  assert.strictEqual(freeSnapshot.sources.rss.configured, false);
  assert.strictEqual(freeSnapshot.sources.finnhub.configured, false);

  const officialSources = getOfficialSources();
  assert.ok(officialSources.some((item) => item.id === 'nvidia-press'));
  assert.ok(officialSources.some((item) => item.id === 'sec-current-8k'));
  assert.ok(officialSources.some((item) => item.id === 'mk-stock' && item.official === false));
  assert.ok(officialSources.some((item) => item.id === 'cnbc-tech'));
  assert.ok(officialSources.some((item) => item.id === 'bbc-business'));
  assert.ok(officialSources.some((item) => item.id === 'guardian-business'));
  assert.ok(officialSources.some((item) => item.id === 'hankyung-finance'));
  assert.ok(officialSources.some((item) => item.id === 'etnews-ai'));
  assert.ok(officialSources.some((item) => item.id === 'moneytoday-index'));
  assert.ok(officialSources.some((item) => item.id === 'reuters-index'));
  assert.ok(officialSources.some((item) => item.id === 'techcrunch-robotics'));
  assert.ok(officialSources.some((item) => item.id === 'infineon-primary-index'));
  assert.ok(officialSources.some((item) => item.id === 'onsemi-primary-index'));
  assert.ok(officialSources.some((item) => item.id === 'rohm-primary-index'));
  assert.ok(weightedOfficialJobs(officialSources).length > officialSources.length);
  assert.ok(matchThemes({ title: '휴머노이드 로봇용 액추에이터 양산', description: '' }).includes('humanoid'));
  assert.ok(matchThemes({ title: '데이터센터 변압기 수요 급증', description: '' }).includes('power'));
  assert.ok(matchThemes({ title: '자율주행 SDV 플랫폼 확대', description: '' }).includes('autonomous'));

  assert.ok(CHAINS.length >= 17);
  assert.ok(matchChains({ title: 'AI 데이터센터 ESS용 전력반도체 SiC MOSFET 국산화', description: '800V power conversion and power module demand' }).some((x) => x.id === 'power-semiconductor'));
  assert.ok(UNIVERSE.some((row) => row.name === 'KEC'));
  assert.ok(UNIVERSE.some((row) => row.name === 'DB하이텍'));
  assert.ok(matchChains({ title: 'TSMC 2nm EUV 공정 투자 확대', description: 'High-NA lithography and photomask demand' }).some((x) => x.id === 'lithography-mask'));
  assert.ok(matchChains({ title: 'HBM4 TC bonder와 hybrid bonding 투자 확대', description: 'advanced packaging capacity' }).some((x) => x.id === 'advanced-packaging'));
  assert.ok(matchChains({ title: 'AI server MLCC 수요 급증', description: 'multilayer ceramic capacitor' }).some((x) => x.id === 'mlcc'));
  assert.ok(matchChains({ title: 'Glass core substrate TGV 양산', description: 'AI accelerator package glass substrate' }).some((x) => x.id === 'glass-substrate'));
  assert.ok(matchChains({ title: 'Custom ASIC tape-out at 2nm foundry', description: 'design service expansion' }).some((x) => x.id === 'design-house'));
  const semiBriefs = buildSemiconductorBriefs([
    { ...officialItems[0], id:'s1', title:'NVIDIA HBM4 advanced packaging TC bonder demand expands 35%', description:'CoWoS and hybrid bonding capacity expansion', marketImpact:{smartMoneyScore:88,direction:'positive'}, importance:{score:82,direction:'positive'} },
    { ...mediaItems[0], id:'s2', title:'HBM4 TC본더 수요 확대…첨단패키징 증설', description:'열압착·하이브리드 본딩 투자', marketImpact:{smartMoneyScore:74,direction:'positive'}, importance:{score:76,direction:'positive'} },
  ], { watchlist, perChain:4 });
  const packBrief = semiBriefs.find((x) => x.id === 'advanced-packaging');
  assert.ok(packBrief);
  assert.ok(packBrief.candidates.some((x) => x.name === '한미반도체' && ['S','A'].includes(x.grade)));
  assert.ok(packBrief.sources.length >= 2);
  const affected = buildAffectedStocks([
    { ...officialItems[0], id:'a200-1', title:'NVIDIA HBM4 demand surges, TC bonder and advanced packaging capacity expansion', description:'HBM test socket handler CoWoS', marketImpact:{smartMoneyScore:90,direction:'positive',koreaImpacts:[]}, importance:{score:86,direction:'positive'} },
  ], { limit: 30 });
  assert.ok(affected.some((row) => row.name === '한미반도체' && row.grade === 'S'));
  assert.ok(affected.some((row) => row.name === 'SK하이닉스'));
  // 게시시각 미확인 네이버 검색결과는 AUTO200 신규발굴의 '방금 전' 점수로 사용하지 않는다.
  const unknownFreshnessAffected = buildAffectedStocks([{
    id:'naver-unknown-time', source:'naver-public', sourceLabel:'네이버 뉴스', sourceTier:'aggregator',
    title:'SK하이닉스 HBM 투자 확대', description:'', link:'https://n.news.naver.com/mnews/article/001/0099999999',
    publishedAt:null, publishedTimeReliable:false, ingestedAt:new Date().toISOString(),
    marketImpact:{smartMoneyScore:95,direction:'positive',koreaImpacts:[{name:'SK하이닉스',code:'000660'}]}, importance:{score:90,direction:'positive'}
  }], {limit:30});
  assert.strictEqual(unknownFreshnessAffected.length, 0);
  // 같은 재료의 유사기사 3개는 세 번 합산하지 않고 대표 촉매 1개로 묶는다.
  const clusterBase = Date.now();
  const clustered = buildAffectedStocks([0,1,2].map((i) => ({
    id:`cluster-${i}`, source:i===0?'media':'naver-public', sourceLabel:i===0?'한국경제':'네이버 뉴스', sourceTier:i===0?'domestic-media':'aggregator',
    title:i===0?'한미반도체 HBM4 TC본더 증설 수혜':'HBM4 첨단패키징 TC본더 투자 확대 관련주',
    description:'advanced packaging TC bonder HBM4', link:`https://example.com/c${i}`, publishedAt:new Date(clusterBase-i*60000).toISOString(), publishedTimeReliable:true,
    marketImpact:{smartMoneyScore:90,direction:'positive',koreaImpacts:[{name:'한미반도체',code:'042700'}]}, importance:{score:86,direction:'positive'}
  })), {limit:30});
  const clusteredHanmi = clustered.find((row) => row.name === '한미반도체');
  assert.ok(clusteredHanmi);
  assert.ok(clusteredHanmi.duplicateSuppressed >= 1);
  // 오래 지속된 동일 공정 read-through는 새 기사 한 건이 추가돼도 신규발굴로 되살리지 않는다.
  const repeatNow = Date.now();
  const persistentRows = buildAffectedStocks([
    {id:'old-hbm',source:'media',sourceLabel:'국내매체',sourceTier:'domestic-media',title:'AI HBM4 수요 확대',description:'memory hbm4 demand',link:'https://example.com/old',publishedAt:new Date(repeatNow-26*3600000).toISOString(),marketImpact:{smartMoneyScore:80,direction:'positive',koreaImpacts:[]},importance:{score:75,direction:'positive'}},
    {id:'new-hbm',source:'media',sourceLabel:'국내매체2',sourceTier:'domestic-media',title:'AI HBM4 시장 성장 지속',description:'memory hbm4 demand continues',link:'https://example.com/new',publishedAt:new Date(repeatNow-30*60000).toISOString(),marketImpact:{smartMoneyScore:82,direction:'positive',koreaImpacts:[]},importance:{score:76,direction:'positive'}}
  ], {limit:30});
  assert.strictEqual(persistentRows.some((row) => row.name === 'SK하이닉스'), false);
  // 같은 공정이라도 새 종목 직접근거/다른 촉매가 나오면 재점화는 허용한다.
  const reignitedRows = buildAffectedStocks([
    {id:'old-hbm2',source:'media',sourceLabel:'국내매체',sourceTier:'domestic-media',title:'AI HBM4 수요 확대',description:'memory hbm4 demand',link:'https://example.com/old2',publishedAt:new Date(repeatNow-26*3600000).toISOString(),marketImpact:{smartMoneyScore:80,direction:'positive',koreaImpacts:[]},importance:{score:75,direction:'positive'}},
    {id:'new-direct',source:'official',sourceLabel:'기업 공시',sourceTier:'primary',officialDirect:true,title:'SK하이닉스 신규 HBM4 공급계약 및 증설 계획',description:'new supply contract capex expansion',link:'https://example.com/newdirect',publishedAt:new Date(repeatNow-20*60000).toISOString(),marketImpact:{smartMoneyScore:94,direction:'positive',koreaImpacts:[{name:'SK하이닉스',code:'000660'}]},importance:{score:92,direction:'positive'}}
  ], {limit:30});
  const reignitedHynix = reignitedRows.find((row) => row.name === 'SK하이닉스');
  assert.ok(reignitedHynix && reignitedHynix.discoveryState === 'REIGNITED');
  const marketRow = normalizeMarketRow({ code:'042700', name:'한미반도체', price:'121,500', changeRate:'3.25%', foreignNet:120, institutionNet:-20, programNet:35, volumeRatio:2.4, updatedAt:new Date().toISOString() });
  assert.strictEqual(marketRow.currentPrice, 121500);
  assert.strictEqual(Math.round(marketRow.volumeIncreasePct), 140);
  const nowBridge = Date.now();
  const v313Row = normalizeV313Stock({
    code:'042700', name:'한미반도체', price:121500, changePct:3.25, cumulativeVolume:1234567, updatedAt:nowBridge,
    broker:{ foreignNet:12000, updatedAt:nowBridge },
    program:{ netAmount:350000000, netQty:2500, updatedAt:nowBridge },
    signal:{ metrics:{ sameTimeRvol:2.2, rvol1m:2.4, tradeStrength:135, vwap:120300 } },
    marketSnapshot:{
      krx:{ date:'2026-08-01', close:121500, high:123000, low:119500, final:true },
      dailyRows:[
        {date:'20260801',close:121500,open:120000,high:123000,low:119500,volume:1000000},
        {date:'20260731',close:118000,open:117000,high:119000,low:116500,volume:900000}
      ],
      closingFlow:{ foreignNet:9000, institutionNet:-2000, programNetAmount:300000000, source:'KIWOOM_OFFICIAL', feedTimes:{ officialAt:new Date(nowBridge-60000).toISOString() } },
      indicators:{ volumeRatio20:1.8 },
    },
    activeTier:'FOCUS',
  });
  assert.strictEqual(v313Row.currentPrice, 121500);
  assert.strictEqual(v313Row.changePct, 3.25);
  assert.strictEqual(v313Row.foreignNet, 12000);
  assert.strictEqual(v313Row.institutionNet, -2000);
  assert.strictEqual(v313Row.programNet, 350000000);
  assert.strictEqual(Math.round(v313Row.volumeIncreasePct), 120);
  assert.strictEqual(v313Row.volumeBasis, '전일동시간 대비');
  assert.strictEqual(v313Row.executionStrength, 135);
  assert.ok(Array.isArray(v313Row.dailyRows));
  const strongProb = estimateUpsideProbability({prepositionScore:88,newsScore:90,pricedInScore:18}, v313Row);
  const crowdedProb = estimateUpsideProbability({prepositionScore:88,newsScore:90,pricedInScore:86}, {...v313Row,changePct:12.5,volumeIncreasePct:520,foreignNet:-1000,institutionNet:-500,programNet:-1000000});
  assert.ok(strongProb.upsideProbability >= 65);
  assert.ok(strongProb.probabilityConfidence >= 70);
  assert.ok(crowdedProb.upsideProbability < strongProb.upsideProbability);
  assert.ok(crowdedProb.upsideProbability <= 50);
  const rankedProb = rankByUpside([{name:'A',upsideProbability:61,probabilityConfidence:90},{name:'B',upsideProbability:72,probabilityConfidence:60}]);
  assert.strictEqual(rankedProb[0].name, 'B');
  const pred = calibrationEngine.sanitizeState({ predictions:[{
    id:'p1', code:'042700', name:'한미반도체', observedAt:'2026-07-31T01:00:00.000Z', predictionDate:'2026-07-31',
    entryPrice:118000, rawProbability:72, probabilityConfidence:80, outcomes:{}
  }] }).predictions[0];
  const evalChanged = calibrationEngine.evaluateOne(pred, { dailyRows:[
    {date:'2026-08-01',close:121500,high:123000,low:119500,finalized:true},
    {date:'2026-08-04',close:124000,high:125000,low:121000,finalized:true},
    {date:'2026-08-05',close:116000,high:126000,low:115000,finalized:true},
  ]});
  assert.strictEqual(evalChanged, true);
  assert.strictEqual(pred.outcomes[1].hit, true);
  assert.strictEqual(pred.outcomes[2].hit, true);
  assert.strictEqual(pred.outcomes[3].hit, false);
  const synthetic = [];
  for (let i=0;i<100;i+=1) synthetic.push({ rawProbability:72, outcomes:{3:{hit:i<55,returnPct:i<55?2:-2}} });
  const cal72 = calibrationEngine.calibrateProbability(72, synthetic);
  assert.ok(cal72.calibratedByHorizon.d3.samples === 100);
  assert.ok(cal72.calibratedByHorizon.d3.probability < 72);
  const calStats = calibrationEngine.statsFor(synthetic);
  assert.strictEqual(calStats.horizons[3].samples, 100);
  assert.strictEqual(calStats.horizons[3].hitRate, 55);
  const activeMonitor = buildActiveMonitor([
    { ...officialItems[0], id:'am-1', title:'한미반도체 HBM4 advanced packaging TC bonder capacity expansion', description:'NVIDIA HBM4 demand and advanced packaging capex', matched:[{name:'한미반도체',code:'042700'}], marketImpact:{smartMoneyScore:94,direction:'positive',koreaImpacts:[{name:'한미반도체',code:'042700'}]}, importance:{score:90,direction:'positive'} },
  ], { snapshots:{ '042700':marketRow, '한미반도체':marketRow }, limit:20 });
  assert.ok(activeMonitor.length <= 20);
  assert.ok(activeMonitor.some((row) => row.name === '한미반도체' && ['적극시세','적극관찰'].includes(row.status)));
  const activeHanmi = activeMonitor.find((row) => row.name === '한미반도체');
  assert.strictEqual(activeHanmi.currentPrice, 121500);
  assert.ok(activeHanmi.volumeIncreasePct >= 100);
  assert.ok(Number.isFinite(activeHanmi.upsideProbability));
  assert.strictEqual(activeHanmi.probabilityHorizon, '1~3거래일');
  assert.strictEqual(activeHanmi.probabilityType, 'MODEL_ESTIMATE');


  const foreignNow = Date.now();
  const foreignLeadItems = [
    {
      id:'foreign-nv-1', source:'official', sourceId:'nvidia-press', sourceLabel:'NVIDIA 공식 보도자료', sourceTier:'primary', officialDirect:true,
      title:'NVIDIA expands Rubin HBM4 and advanced packaging capacity', description:'Rubin AI GPU demand drives HBM4 capacity and TC bonder advanced packaging investment by 30%',
      link:'https://example.com/foreign-nv-1', publishedAt:new Date(foreignNow - 70*60000).toISOString(),
      marketImpact:{smartMoneyScore:94,direction:'positive'}, importance:{score:90,direction:'positive'}
    },
    {
      id:'domestic-nv-1', source:'media', sourceId:'hankyung-it', sourceLabel:'한국경제 IT', sourceTier:'domestic-media', officialDirect:false,
      title:'엔비디아 루빈 HBM4·첨단패키징 투자 확대', description:'HBM4와 TC본더 수요 확대',
      link:'https://example.com/domestic-nv-1', publishedAt:new Date(foreignNow - 25*60000).toISOString(),
      marketImpact:{smartMoneyScore:80,direction:'positive'}, importance:{score:80,direction:'positive'}
    }
  ];
  const foreignBriefs = buildForeignLeadBriefs(foreignLeadItems, { limit: 10 });
  assert.ok(foreignBriefs.length >= 1);
  assert.ok(foreignBriefs[0].leadMinutes >= 40);
  assert.ok(foreignBriefs[0].candidates.length <= MAX_CANDIDATES);
  assert.ok(foreignBriefs[0].candidates.some((row) => row.name === 'SK하이닉스'));
  assert.ok(foreignBriefs[0].candidates.some((row) => row.name === '한미반도체'));
  assert.ok(!foreignBriefs[0].candidates.some((row, idx, arr) => idx >= 3));
  const genericCandidates = storyCandidates({
    source:'media', sourceTier:'international-media', sourceLabel:'Global Tech', title:'AI market growth continues globally', description:'Artificial intelligence demand is strong',
    publishedAt:new Date().toISOString(), marketImpact:{smartMoneyScore:60,direction:'positive'}, importance:{score:55,direction:'positive'}
  });
  assert.strictEqual(genericCandidates.length, 0);

  const positiveImpact = analyzeMarketImpact(officialItems[0], { watchlist });
  assert.ok(positiveImpact.smartMoneyScore >= SMART_MONEY_THRESHOLD);
  assert.strictEqual(positiveImpact.isSmartMoney, true);
  assert.strictEqual(positiveImpact.isSemiconductorAI, true);
  assert.strictEqual(positiveImpact.direction, 'positive');
  assert.ok(positiveImpact.koreaImpacts.some((item) => item.name === 'SK하이닉스'));
  assert.ok(positiveImpact.koreaImpacts.some((item) => item.name === '삼성전자'));

  const restrictionImpact = analyzeMarketImpact({
    source: 'official', officialDirect: true, sourceId: 'sec-current-8k',
    title: 'United States Announces New AI Chip Export Controls',
    description: 'New export restrictions apply to advanced GPU shipments to China.',
    link: 'https://example.com/export-control', publishedAt: new Date().toISOString(),
  }, { watchlist });
  assert.strictEqual(restrictionImpact.direction, 'negative');
  assert.strictEqual(restrictionImpact.isSemiconductorAI, true);
  assert.ok(restrictionImpact.koreaImpactScore >= 70);

  const fedImpact = analyzeMarketImpact({
    source: 'official', officialDirect: true, sourceId: 'fed-monetary',
    title: 'Federal Reserve Announces Monetary Policy Decision',
    description: 'The FOMC holds the federal funds rate unchanged.',
    link: 'https://example.com/fed', publishedAt: new Date().toISOString(),
  }, { watchlist });
  assert.strictEqual(fedImpact.isSemiconductorAI, false);
  assert.ok(fedImpact.smartMoneyScore >= SMART_MONEY_THRESHOLD);

  const realNow = Date.now;
  Date.now = () => Date.UTC(2026, 7, 3, 0, 0, 0); // Monday 09:00 KST
  const mondayCatchup = analyzeMarketImpact({
    source: 'official', officialDirect: true, sourceId: 'nvidia-press',
    title: 'NVIDIA Announces New AI Accelerator and HBM Expansion',
    description: 'Official weekend release with confirmed 25% capacity growth.',
    link: 'https://example.com/weekend', publishedAt: new Date(Date.UTC(2026, 7, 1, 8, 0, 0)).toISOString(),
  }, { watchlist });
  Date.now = realNow;
  assert.strictEqual(mondayCatchup.mondayCatchup, true);
  assert.ok(mondayCatchup.reasons.includes('주말 발표 월요일 장전 재평가'));

  await store.setItem('check:a', { v: 1 });
  await store.setItem('check:a', { v: 2 });
  const jsonFile = fs.readdirSync(process.env.STORE_DIR).find((name) => name.endsWith('.json'));
  fs.writeFileSync(path.join(process.env.STORE_DIR, jsonFile), '{broken');
  assert.deepStrictEqual(await store.getItem('check:a'), { v: 1 });

  await Promise.all(Array.from({ length: 20 }, () => store.mutateItem('counter', (value) => Number(value || 0) + 1, 0)));
  assert.strictEqual(await store.getItem('counter'), 20);

  const raw = [{ source: 'naver', title: '삼성전자 신제품 공개', description: '', link: 'https://example.com/n1', publishedAt: new Date().toISOString() }];
  assert.strictEqual((await newsStore.ingest(raw, watchlist)).length, 1);
  assert.strictEqual((await newsStore.ingest(raw, watchlist)).length, 0);

  const officialAdded = await newsStore.ingest(officialItems, watchlist, []);
  assert.strictEqual(officialAdded.length, 1);
  const smartItems = await newsStore.list({ smart: true, limit: 20 });
  assert.ok(smartItems.some((item) => item.sourceId === 'nvidia-press'));
  const semiItems = await newsStore.list({ semiai: true, limit: 20 });
  assert.ok(semiItems.some((item) => item.sourceId === 'nvidia-press'));

  const portalRepost = [{
    source: 'naver', title: 'NVIDIA Announces Blackwell Expansion',
    description: 'AI infrastructure and HBM demand rise 35%',
    link: 'https://example.com/repost', publishedAt: new Date().toISOString(),
  }];
  const coverageAdded = await newsStore.ingest(portalRepost, watchlist, []);
  assert.strictEqual(coverageAdded.length, 1);
  assert.strictEqual(coverageAdded[0].coverageOnly, true);
  assert.strictEqual((await newsStore.list({ limit: 50 })).some((item) => item.coverageOnly), false);
  assert.strictEqual((await newsStore.list({ limit: 50, includeCoverage: true })).some((item) => item.coverageOnly), true);
  const stale = [{
    source: 'official', officialDirect: true, sourceId: 'nvidia-press', title: 'Old AI headline',
    description: 'HBM', link: 'https://example.com/stale',
    publishedAt: new Date(Date.now() - 60 * 3600000).toISOString(),
  }];
  assert.strictEqual((await newsStore.ingest(stale, watchlist, [])).length, 0);
  const within48 = [{
    source: 'media', sourceId: 'mk-stock', sourceLabel: '매일경제 증권', title: 'SK하이닉스 HBM 신규 수주 확대',
    description: 'AI 반도체 HBM 수요 증가', link: 'https://example.com/within48',
    publishedAt: new Date(Date.now() - 47 * 3600000).toISOString(),
  }];
  assert.strictEqual((await newsStore.ingest(within48, watchlist, [])).length, 1);

  const themeOnly = [{
    source: 'media', sourceId: 'etnews-mobility', sourceLabel: '전자신문 모빌리티', sourceTier: 'domestic-media',
    title: '완성차 업계 자율주행 SDV 플랫폼 투자 확대',
    description: 'ADAS와 라이다 기반 차세대 차량 플랫폼 투자 계획', link: 'https://example.com/autonomous-theme',
    publishedAt: new Date(Date.now() - 2 * 3600000).toISOString(),
  }, {
    source: 'media', sourceId: 'techcrunch-robotics', sourceLabel: 'TechCrunch Robotics', sourceTier: 'international-media',
    title: 'Humanoid robotics startup expands factory automation deployment',
    description: 'Industrial automation and robot actuator deployments expand', link: 'https://example.com/humanoid-theme',
    publishedAt: new Date(Date.now() - 1 * 3600000).toISOString(),
  }];
  const themeAdded = await newsStore.ingest(themeOnly, watchlist, []);
  assert.strictEqual(themeAdded.length, 2);
  assert.ok(themeAdded[0].themeIds?.includes('autonomous'));
  const themeBriefs = buildThemeBriefs(await newsStore.list({ limit: 500 }), { limit: 30, perTheme: 3 });
  assert.ok(themeBriefs.some((brief) => brief.id === 'autonomous'));
  assert.ok(themeBriefs.some((brief) => brief.id === 'humanoid'));
  assert.ok(themeBriefs.find((brief) => brief.id === 'autonomous').summary.includes('한국장'));

  const topics = await macroTopicsLib.listTopics();
  assert.ok(topics.length >= 10);
  assert.ok(matchMacroTopics({ title: 'Federal Reserve holds rates at FOMC', description: '' }, topics).length >= 1);

  const mapped = mapFinnhubItem({ headline: 'Fed signals pause', summary: 'Inflation data', url: 'https://example.com/f1', datetime: 1735689600 });
  assert.strictEqual(mapped.source, 'finnhub');

  const critical = assessImportance({
    source: 'dart', title: '[공시] 거래정지 및 감사의견 거절', description: '삼성전자',
    publishedAt: new Date().toISOString(),
  }, { matched: [{ id: 'a1', name: '삼성전자', code: '005930' }], sentiment: { label: 'negative' } });
  assert.strictEqual(critical.level, 'critical');
  assert.ok(critical.score >= 80);

  const macroImportant = assessImportance({
    source: 'naver', title: 'FOMC 기준금리 동결 확정', description: '파월 기자회견',
    publishedAt: new Date().toISOString(),
  }, { macroMatched: [{ label: '연준/FOMC', impactLevel: 'high' }], sentiment: { label: 'neutral' } });
  assert.ok(macroImportant.score >= IMPORTANT_THRESHOLD);
  assert.strictEqual(macroImportant.isImportant, true);

  const speculative = assessImportance({
    source: 'naver', title: '삼성전자 관련주 오를까…수혜주 기대감', description: '',
    publishedAt: new Date().toISOString(),
  }, { matched: [{ id: 'a1', name: '삼성전자', code: '005930' }], sentiment: { label: 'neutral' } });
  assert.strictEqual(speculative.isImportant, false);
  assert.ok(inferThemes('HBM과 AI 반도체 데이터센터 투자').includes('반도체·HBM/AI'));

  const response = { headers: {}, setHeader(name, value) { this.headers[name] = value; } };
  setSessionCookie(response);
  const cookie = response.headers['Set-Cookie'].split(';')[0];
  assert.strictEqual(isAuthenticated({ headers: { cookie }, query: {} }), true);

  const saturdayKst = Date.UTC(2026, 7, 1, 4, 0, 0); // 2026-08-01 13:00 KST
  assert.strictEqual(isKoreaWeekend(saturdayKst), true);
  assert.strictEqual(collectionMode(saturdayKst), 'weekend-48h-active');

  // 주말에도 예약수집을 유지하고, 접속 시에는 48시간 백필을 즉시 보강해야 합니다.
  const savedNowForAccess = Date.now;
  const savedFetchForAccess = global.fetch;
  Date.now = () => saturdayKst;
  global.fetch = async () => new Response(rssXml, { status: 200, headers: { 'Content-Type': 'application/rss+xml' } });
  const accessPoller = new Poller();
  const firstAccess = accessPoller.triggerAccessRefresh('check-weekend-access');
  assert.strictEqual(firstAccess.triggered, true);
  assert.strictEqual(firstAccess.weekend, true);
  assert.strictEqual(firstAccess.weekendViewHours, 48);
  await accessPoller.accessRefreshPromise;
  const accessDone = accessPoller.accessRefreshSnapshot();
  assert.ok(accessDone.lastCalls >= 1);
  assert.ok(accessDone.lastSuccessAt);
  const secondAccess = accessPoller.triggerAccessRefresh('check-throttle');
  assert.strictEqual(secondAccess.triggered, false);
  assert.strictEqual(secondAccess.skipped, 'throttled');
  await accessPoller.stop();
  global.fetch = savedFetchForAccess;
  Date.now = savedNowForAccess;
  assert.strictEqual(collectionMode(Date.UTC(2026, 7, 3, 0, 30, 0)), 'kr-premarket-open-fast'); // 09:30 KST
  assert.strictEqual(inKoreaWindow(5 * 60 + 50, 20 * 60 + 30, Date.UTC(2026, 7, 3, 0, 30, 0)), true);
  assert.strictEqual(inKoreaWindow(5 * 60 + 50, 20 * 60 + 30, Date.UTC(2026, 7, 3, 13, 0, 0)), false);
  assert.strictEqual(inKoreaWindow(20 * 60 + 30, 10 * 60, Date.UTC(2026, 7, 3, 15, 0, 0)), true);
  assert.ok(msToNextKoreaDay() > 0 && msToNextKoreaDay() <= 86405000);
  assert.ok(msToNextKoreaWeekday() > 0 && msToNextKoreaWeekday() <= 7 * 86400000);

  const secondNow = Date.now();
  const semiconFuture = {
    id:'semicon-future', title:'AI 시대 반도체 시장 2030년까지 성장…선단공정·검사·팹 투자 확대 전망',
    description:'반도체 미래 수요와 fab expansion, advanced node investment가 이어지지만 공급과잉 우려도 점검해야 한다.',
    link:'https://media.example/semicon-future', publishedAt:new Date(secondNow-20*60000).toISOString(), ingestedAt:new Date().toISOString(),
    source:'media', sourceLabel:'주요경제매체', sourceTier:'domestic-media', marketImpact:{direction:'positive'}, importance:{score:78,direction:'positive'},
  };
  const secondBriefs = buildSecondOrderBriefs([semiconFuture], {limit:10});
  assert.ok(secondBriefs.length >= 1);
  assert.ok(secondBriefs[0].future.futureArticle);
  assert.ok(secondBriefs[0].candidates.some((x) => ['오로스테크놀로지','넥스틴','원익QnC','엘오티베큠','유니셈'].includes(x.name)));
  assert.ok(secondBriefs[0].candidates.some((x) => x.relationType === 'SECOND_ORDER'));
  const secondCandidates = buildSecondOrderCandidates([semiconFuture], {limit:20});
  assert.ok(secondCandidates.length >= 3);
  const expanded = buildExpandedDiscovery([semiconFuture], {limit:20});
  assert.ok(expanded.length >= 3);
  assert.ok(expanded.some((x) => x.discoveryState === 'SECOND_ORDER'));
  const psychologyBriefs = buildSecondOrderBriefs([{
    id:'psy',title:'AI 반도체 열풍 속 FOMO와 고평가 버블 우려…투자자 심리 과열',description:'미래 성장 전망과 과잉투자·공급과잉 우려가 동시에 제기됐다.',
    link:'https://media.example/psy',publishedAt:new Date(secondNow-15*60000).toISOString(),source:'media',sourceLabel:'주요경제매체',sourceTier:'domestic-media'
  }],{limit:5});
  assert.ok(psychologyBriefs.length >= 1);
  assert.notStrictEqual(psychologyBriefs[0].psychology.regime, '중립');
  const pulseAnalysis = analyzeMarketPulse([
    {id:'nasdaq',label:'NASDAQ',changePct:1.4},{id:'sp500',label:'S&P 500',changePct:0.8},{id:'sox',label:'SOX',changePct:2.1},
    {id:'us10y',label:'美 10Y',changePct:-0.4},{id:'usdkrw',label:'USD/KRW',changePct:0.1},{id:'wti',label:'WTI',changePct:0.2},
  ], [semiconFuture]);
  assert.ok(['RISK-ON','MIXED','RISK-OFF'].includes(pulseAnalysis.regime));
  assert.ok(pulseAnalysis.domesticCandidates.some((x) => ['테크윙','ISC','넥스틴','오로스테크놀로지','원익QnC','인텍플러스'].includes(x.name)));
  const expandedActive = buildActiveMonitor([semiconFuture], { snapshots:{}, limit:20, externalCandidates:pulseAnalysis.domesticCandidates });
  assert.ok(expandedActive.length >= 5);
  assert.ok(expandedActive.some((x) => x.source === 'SECOND-ORDER' || x.source === 'US-MARKET'));

  const usAssets = [
    {id:'qqq',label:'QQQ',regularPct:1.0,prePct:0.5,postPct:0.2},{id:'spy',label:'SPY',regularPct:0.7,prePct:0.3,postPct:0.1},{id:'smh',label:'SMH',regularPct:2.2,prePct:1.1,postPct:0.4},
    {id:'nvda',label:'NVIDIA',regularPct:3.1,prePct:1.8,postPct:0.6},{id:'amd',label:'AMD',regularPct:2.4,prePct:1.2,postPct:0.3},{id:'avgo',label:'Broadcom',regularPct:1.8,prePct:0.8,postPct:0.2},
    {id:'mu',label:'Micron',regularPct:1.9,prePct:0.9,postPct:0.2},{id:'msft',label:'Microsoft',regularPct:1.2,prePct:0.6,postPct:0.1},{id:'googl',label:'Alphabet',regularPct:1.0,prePct:0.5,postPct:0.2},
    {id:'amzn',label:'Amazon',regularPct:0.9,prePct:0.4,postPct:0.1},{id:'meta',label:'Meta',regularPct:1.1,prePct:0.6,postPct:0.1},{id:'tsla',label:'Tesla',regularPct:1.4,prePct:0.7,postPct:0.3},
  ];
  const usSession = {id:'regular',label:'정규장',etDate:'2026-08-03',etTime:'11:00'};
  const usThemes = usNewsThemes([{...semiconFuture, sourceTier:'international-media', title:'NVIDIA AI semiconductor and data center capex expansion outlook'}]);
  const usPulse = {items:[
    {id:'nasdaq',changePct:1.4},{id:'sp500',changePct:0.8},{id:'sox',changePct:2.1},{id:'vix',changePct:-3.0},{id:'us10y',changePct:-0.4},{id:'usdkrw',changePct:0.1}
  ],analysis:pulseAnalysis};
  const usDomestic = buildUsDomesticCandidates(usPulse, usAssets, usThemes, usSession);
  assert.ok(usDomestic.firstOrder.length >= 3);
  assert.ok(usDomestic.secondOrder.length >= 5);
  assert.ok(usDomestic.secondOrder.some((x) => x.universeScope === 'EXPAND'));
  const usSessions = {pre:sessionSnapshot(usAssets,'pre'),regular:sessionSnapshot(usAssets,'regular'),after:sessionSnapshot(usAssets,'after')};
  const usNarrative = buildUsNarrative({pulse:usPulse,assets:usAssets,session:usSession,sessions:usSessions,themes:usThemes,firstOrder:usDomestic.firstOrder,secondOrder:usDomestic.secondOrder,signals:usDomestic.signals});
  assert.ok(usNarrative.length >= 1200 && usNarrative.length <= 2400);
  const usActive = buildActiveMonitor([semiconFuture], { snapshots:{}, limit:20, externalCandidates:[...usDomestic.firstOrder,...usDomestic.secondOrder] });
  assert.ok(usActive.some((x) => x.source === 'US-MARKET'));
  assert.ok(usActive.some((x) => x.universeScope === 'EXPAND'));

  // NEXT US SESSION: 여러 기사 중복을 억제하고 5축으로 다음 정규장 확률을 계산한다.
  const nextNews = [0,1,2].map((i) => ({
    ...semiconFuture, id:`next-us-${i}`, sourceTier:i === 0 ? 'primary' : 'international-media', officialDirect:i === 0,
    sourceLabel:i === 0 ? 'NVIDIA 공식' : `국제매체${i}`,
    title:'NVIDIA AI semiconductor data center capex expansion and strong HBM demand',
    description:'Strong demand, raised guidance, AI infrastructure expansion and cooling inflation outlook',
    publishedAt:new Date(Date.now()-i*60000).toISOString(),
    marketImpact:{direction:'positive',smartMoneyScore:88}, importance:{score:86,direction:'positive'}
  }));
  const nextClusters = clusterNextUsNews(nextNews);
  assert.ok(nextClusters.length >= 1 && nextClusters.length <= 2);
  assert.ok(nextClusters[0].duplicateSuppressed >= 1);
  const nextDesk = { status:'connected', session:usSession, assets:usAssets, firstOrder:usDomestic.firstOrder, secondOrder:usDomestic.secondOrder };
  const nextComp = buildNextUsComponents(nextNews, usPulse, nextDesk);
  assert.strictEqual(nextComp.components.length, 5);
  assert.ok(nextComp.rawScore > 0);
  const nextRaw = nextRawProbabilities(nextComp.rawScore, nextComp.confidence, nextComp.uncertainty);
  assert.ok(Math.abs(nextRaw.UP + nextRaw.NEUTRAL + nextRaw.DOWN - 100) < 0.2);
  assert.ok(nextRaw.UP > nextRaw.DOWN);
  const nextCal = calibrateNextUsVector(nextRaw, { forecasts:[] });
  assert.strictEqual(nextCal.samples, 0);
  assert.ok(Math.abs(nextCal.probabilities.UP - nextRaw.UP) < 0.01);
  assert.strictEqual(classifyNextUsReturn(0.5), 'UP');
  assert.strictEqual(classifyNextUsReturn(-0.5), 'DOWN');
  assert.strictEqual(classifyNextUsReturn(0.05), 'NEUTRAL');
  const nextImpacts = nextUsImpactCandidates(nextDesk, 'UP');
  assert.ok(nextImpacts.firstOrder.length >= 3);
  assert.ok(nextImpacts.secondOrder.some((x) => x.universeScope === 'EXPAND'));
  const targetPre = nextTargetInfo(new Date('2026-08-04T12:00:00Z'), {id:'pre',label:'프리마켓'});
  assert.strictEqual(targetPre.targetDate, '2026-08-04');
  assert.strictEqual(targetPre.stage, 'PREMARKET_FINAL');
  const nextNarrative = buildNextUsNarrative(targetPre, nextComp, nextRaw, nextCal.probabilities, nextImpacts, {evaluated:0,hitRate:null,label:'학습중 0/120'});
  assert.ok(nextNarrative.length >= 1600 && nextNarrative.length <= 2450);

  const earlyNow = Date.now();
  const powerForeign = {
    id:'pwr-foreign', title:'Infineon expands SiC MOSFET capacity for AI data centers and energy storage',
    description:'Power semiconductor capacity expansion targets 800V power conversion, UPS and ESS inverter demand with localization pressure.',
    link:'https://www.infineon.com/test', publishedAt:new Date(earlyNow-10*60000).toISOString(), ingestedAt:new Date().toISOString(),
    source:'official', sourceLabel:'Infineon 공식 전력반도체 발표', sourceTier:'primary-index', primaryIndexed:true,
    marketImpact:{direction:'positive',smartMoneyScore:82}, importance:{score:84,direction:'positive'}
  };
  const powerCandidateRows = storyCandidates(powerForeign);
  assert.ok(powerCandidateRows.length <= 3);
  assert.ok(powerCandidateRows.some((x) => ['KEC','DB하이텍','코스텍시스'].includes(x.name)));
  assert.ok(hiddenDemandLinks(powerForeign).some((x) => x.includes('SiC')));
  const earlyRows = buildEarlyEdges([powerForeign], {limit:5});
  assert.ok(earlyRows.length >= 1);
  assert.strictEqual(earlyRows[0].antiChase, false);
  assert.ok(earlyRows[0].candidates.length <= 3);
  assert.ok(earlyRows[0].prepositionScore >= 60);
  assert.ok(earlyRows[0].pricedInScore <= 35);
  assert.strictEqual(earlyRows[0].marketPricedInScore, null);
  assert.strictEqual(earlyRows[0].pricingBasis, '뉴스확산 추정');
  assert.ok(earlyRows[0].scoreGap > 20);
  assert.strictEqual(marketReactionScore(null), null);
  assert.ok(marketReactionScore({changeSinceNewsPct:8,rvol:2.2,executionStrength:145}) >= 60);

  const crowdedDomestic = [0,1,2,3].map((n) => ({
    id:`dom-${n}`, title:`AI 데이터센터 전력반도체 관련주 급등 수혜주 ${n}`,
    description:'SiC MOSFET power semiconductor capacity expansion and ESS inverter demand', link:`https://dom.example/${n}`,
    publishedAt:new Date(earlyNow+(20+n)*60000).toISOString(), source:'media', sourceLabel:`국내매체${n}`, sourceTier:'domestic-media', coverageOnly:true,
  }));
  const crowdedRows = buildEarlyEdges([powerForeign, ...crowdedDomestic], {limit:5});
  assert.ok(crowdedRows.length >= 1);
  assert.ok(crowdedRows[0].lifecycle.crowdingRisk >= 65);
  assert.ok(crowdedRows[0].pricedInScore >= 70);
  assert.strictEqual(crowdedRows[0].antiChase, true);
  assert.ok(crowdedRows[0].prepositionScore >= 50); // 재료의 질은 국내확산과 별개로 유지
  assert.ok(crowdedRows[0].pricedInScore > earlyRows[0].pricedInScore);

  await newsStore.flush();
  await store.flush();
  console.log('CHECK OK: NEXT US v1.4.0, 익일 미국장 상승/중립/하락 추론, 5축 뉴스+시세 종합, 프리/정규/애프터 LIVE DESK, 국내 1차/2차/EXPAND, 미국장+ACTIVE20 자동보정, V3.1.x read-only');
}

main().catch((error) => {
  console.error('CHECK FAILED:', error);
  process.exitCode = 1;
}).finally(() => fs.rmSync(process.env.STORE_DIR, { recursive: true, force: true }));
