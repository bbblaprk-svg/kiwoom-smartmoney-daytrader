# NEXT US v1.4.0 검증

- PASS: 전체 JavaScript `node --check`
- PASS: `npm run check`
- PASS: AUTO200 정확히 200 + EXPAND 200 초과
- PASS: NEXT US 5축 가중치 계산
- PASS: 상승/중립/하락 확률 합계 100%
- PASS: 동일 뉴스클러스터 중복가산 억제
- PASS: NEXT US 국내 1차/2차 영향후보 생성
- PASS: 2차 후보 중 EXPAND 편입 확인
- PASS: 약 2천자 NEXT US 종합전망 생성
- PASS: 미국장 실제결과 분류 UP/NEUTRAL/DOWN
- PASS: 미국장 예측 상태 저장/브라우저 미러 API
- PASS: ACTIVE20에 NEXT US 후보 병합
- PASS: Kiwoom 직접호출 모듈 없음 / V3.1.x read-only 유지
- PASS: production 서버 `/api/health` => version 1.4.0, ready=true
- PASS: production `/api/next-us-session` JSON shape 및 forecast state 저장 확인

주의: 공개 미국 시세 공급원이 차단/지연될 경우 모델은 수신 가능한 뉴스·거시 데이터만으로 신뢰도를 낮춰 표시하며 미수신 값을 임의로 만들지 않는다.
