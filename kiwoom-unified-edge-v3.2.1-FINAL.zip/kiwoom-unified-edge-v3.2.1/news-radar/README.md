# SMART-MONEY EDGE · NEXT US v1.4.0

미국 다음 정규장을 뉴스+시장데이터로 추론하고, 현재 프리/정규/애프터 흐름과 한국장 1차·2차·EXPAND 후보를 연결하는 뉴스/시장 인텔리전스 앱입니다.

핵심 기능
- 앱 최상단 NEXT US SESSION 클릭형 전망판
- 상승/중립/하락 확률과 약 2천자 종합전망
- 거시·정책 / 시장선행 / 기업·산업 / 크로스애셋 / 뉴스심리 5축
- 유사뉴스 클러스터링으로 중복기사 반복가산 억제
- 미국 프리/정규/애프터 LIVE DESK 유지
- 한국장 1차 영향주 + 2차적 사고 + AUTO200 밖 EXPAND
- NEXT US 후보를 ACTIVE20 후보 풀에 합류
- 미국장 예측 실제결과/방향 적중률/Brier score 자동 기록·보정
- ACTIVE20 D+1/D+2/D+3 보정엔진 유지
- V3.1.x 공유시세 read-only, Kiwoom 직접호출 없음

자세한 내용은 NEXT_US_SESSION_LOGIC.md를 참고하세요.
