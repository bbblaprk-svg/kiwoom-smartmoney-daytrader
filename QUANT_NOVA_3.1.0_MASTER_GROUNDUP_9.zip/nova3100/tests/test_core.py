from __future__ import annotations
import os,tempfile,time,unittest,threading,json,asyncio,sqlite3
from pathlib import Path
from app.domain import Candidate,Venue,Origin,TradeTick,SignalEvent,SignalTrack
from app.runtime.window import FixedMicroWindow
from app.runtime.integrity import TickIntegrity
from app.runtime.state import RuntimeState
from app.runtime.dispatcher import TradeDispatcher,Envelope,CoalescingLane
from app.runtime.ingest import Ingestor
from app.tracking.live import LiveTracker
from app.signal.policy import EntryPolicy,TickSource,BuyIntent,ENTRY_PRESSURE_SCORE,ENTRY_HOLD_SEC,ENTRY_PULLBACK_MIN,ENTRY_PULLBACK_MAX,ENTRY_REACCEL_SEC,ENTRY_COOLDOWN_SEC,ENTRY_MAX_DAILY,DIRECT_SCORE,DIRECT_HOLD_SEC,DIRECT_CONFIRM_SEC
from app.storage.wal import DurableJournal
from app.storage.recovery import tail_jsonl,read_committed_wal,read_committed_history,read_timeline_for_code,summarize_formal_day
from app.storage.runtime_store import RuntimeStore
from app.runtime.clock import trade_day,trading_day_for,sessions_at
from app.signal.smart_money import fast_proxy
from app.signal.coordinator import SignalCoordinator
from app.signal.metrics import ScoreDecision
from app.lifecycle.opening import OpeningBridge
from app.tracking.top5 import Top5Registry
from app.broker.kiwoom import venue_from_item,_token_expiry_epoch,TokenManager
from app.broker.discovery import stex_for_session
from app.storage.performance import PerformanceLedger
from app.config import effective_ws_code_budget
from app.runtime.display import DisplayState

class GroundupCoreTests(unittest.TestCase):
    def test_window_memory_rate_independent_and_5m(self):
        a=FixedMicroWindow();b=FixedMicroWindow();start=1_000_000.0
        for sec in range(330):
            a.add(start+sec+.1,100+sec*.01,10)
            for j in range(100):b.add(start+sec+j/100,100+sec*.01+j*.0001,1 if j%2==0 else -1)
        self.assertLessEqual(a.memory_slots(),955);self.assertLessEqual(b.memory_slots(),955)
        self.assertLessEqual(a.memory_slots(),b.memory_slots())
        r=b.aggregate(start+329.9,300);self.assertGreater(r['bucket_count'],290);self.assertGreater(r['count'],29000)

    def test_venue_truth_fail_closed(self):
        self.assertEqual(venue_from_item('005930_NX','NXT'),Venue.NXT)
        self.assertEqual(venue_from_item('005930','KRX'),Venue.KRX)
        self.assertEqual(venue_from_item('005930_NX','KRX'),Venue.UNKNOWN)
        self.assertEqual(venue_from_item('005930','NXT'),Venue.UNKNOWN)

    def test_integrity_is_venue_isolated(self):
        g=TickIntegrity();now=time.time()
        def t(v,seq,cum):return TradeTick('005930',v,70000,10,1,cum,1_000_000,'101010',now,1.0,seq,'005930_NX' if v==Venue.NXT else '005930',v.value,f'f{v}{seq}')
        self.assertTrue(g.validate('20260812',t(Venue.KRX,1,100)).accepted)
        self.assertTrue(g.validate('20260812',t(Venue.NXT,2,50)).accepted) # lower cumulative is valid in another venue

    def test_signal_performance_venue_locked(self):
        c=Candidate('005930');sig=SignalEvent('s','20260812','005930','',Venue.NXT,'BUY','X',1,100,0,1,'',1,[],{},1,Origin.TODAY_NEW);c.last_signal=sig;c.signal_tracks.append(SignalTrack('s',Venue.NXT,100,1,100,100,100,1));c.last_buy_price=100;c.last_buy_venue=Venue.NXT
        c.venue_state[Venue.NXT].last_price=110;c.venue_state[Venue.NXT].last_tick_at=time.time();c.venue_state[Venue.KRX].last_price=200;c.venue_state[Venue.KRX].last_tick_at=time.time()+1;c.current_venue=Venue.KRX
        p=c.public();self.assertEqual(p['signal_return'],10.0);self.assertEqual(p['buy_return'],10.0);self.assertEqual(p['price'],200)

    def test_queue_overflow_marks_signal_drop(self):
        st=RuntimeState();tr=LiveTracker();ing=Ingestor(st,tr);d=TradeDispatcher(lambda e:time.sleep(.1),ing.dropped,shards=1,maxsize=1)
        c=st.candidate('000001');c.live_track_pin=True;st.pinned_codes.add('000001')
        e=Envelope('TRADE','000001',None,time.monotonic(),True)
        # do not start worker: second enqueue must overflow deterministically
        self.assertTrue(d.submit(e));self.assertFalse(d.submit(e));self.assertEqual(st.telemetry['dropped_signal_tick_count'],1);self.assertEqual(c.venue_state[Venue.KRX].continuity_reason,'TRADE_QUEUE_OVERFLOW')

    def test_gap_does_not_auto_expire_and_requires_live_rewarm(self):
        st=RuntimeState();tr=LiveTracker();ing=Ingestor(st,tr);c=st.candidate('000001');st.mark_resync({'000001'},'TEST')
        base=time.time();
        for i in range(4):
            tick=TradeTick('000001',Venue.KRX,100+i,1,0,100+i,0,'10000'+str(i),base+i*.3,time.monotonic(),i+1)
            ing.trade(Envelope('TRADE','000001',tick,time.monotonic(),False))
        self.assertTrue(c.venue_state[Venue.KRX].continuity_reason)
        tick=TradeTick('000001',Venue.KRX,105,1,0,105,0,'100005',base+1.3,time.monotonic(),5);ing.trade(Envelope('TRADE','000001',tick,time.monotonic(),False))
        self.assertEqual(c.venue_state[Venue.KRX].continuity_reason,'')

    def test_wal_cancel_before_start_never_writes(self):
        with tempfile.TemporaryDirectory() as td:
            j=DurableJournal(Path(td))
            # writer not started: request cancels before start and returns False
            self.assertFalse(j.commit({'event':'BUY_CONFIRMED','id':1},.05));j.start();time.sleep(.2);j.stop();time.sleep(.05)
            rows=read_committed_wal(Path(td)/'signal_wal.sqlite3');self.assertFalse(any(r.get('event')=='BUY_CONFIRMED' for r in rows))

    def test_wal_fsync_before_buy_mutation(self):
        with tempfile.TemporaryDirectory() as td:
            st=RuntimeState();j=DurableJournal(Path(td));j.start();c=st.candidate('000001');p=EntryPolicy(st,j);src=TickSource(Venue.NXT,12345,2.2,77,'170000',time.time());intent=BuyIntent('DIRECT_IGNITION',['x'],src,{'fresh':True},time.time());rec=p.wal_record(c,intent)
            self.assertTrue(j.commit(rec,1));p.apply_committed(c,intent,rec);j.stop()
            self.assertEqual(c.last_buy_price,12345);self.assertEqual(c.last_buy_venue,Venue.NXT);self.assertIn(rec['signal_id'],{r.get('signal_id') for r in read_committed_wal(Path(td)/'signal_wal.sqlite3')})

    def test_opening_lifecycle(self):
        c=Candidate('000001',origin=Origin.PRIOR_CLOSE);c.current_venue=Venue.NXT;v=c.venue_state[Venue.NXT];v.last_price=100;v.last_rate=1;v.metrics={'fresh':True,'buy_pressure':45,'micro_vwap_gap':-.3,'volume_accel':1.0};b=OpeningBridge()
        b.update(c,'PREMARKET_RECHECK',1);self.assertEqual(c.lifecycle_state,'PREMARKET_RECHECK')
        b.update(c,'SHAKEOUT_WATCH',2);v.last_price=98;b.update(c,'SHAKEOUT_WATCH',3);self.assertTrue(c.shakeout_state)
        v.metrics.update({'buy_pressure':60,'micro_vwap_gap':0,'volume_accel':1.3});v.last_price=99;v.score=70;c.score=70;v.entry.state='REACCEL';b.update(c,'REVERSAL_WINDOW',4);self.assertEqual(c.lifecycle_state,'BUY_READY')

    def test_top5_reentry(self):
        a=Candidate('A');b=Candidate('B');allc={'A':a,'B':b};t=Top5Registry();t.apply('x',[a],allc);t.apply('x',[b],allc);t.apply('x',[a],allc);self.assertEqual(a.top5_reentry_count,1)

    def test_frozen_policy_contract(self):
        import json
        spec=json.loads((Path(__file__).resolve().parents[1]/'SIGNAL_POLICY_FROZEN.json').read_text())
        self.assertEqual((ENTRY_PRESSURE_SCORE,ENTRY_HOLD_SEC,ENTRY_PULLBACK_MIN,ENTRY_PULLBACK_MAX,ENTRY_REACCEL_SEC,ENTRY_COOLDOWN_SEC,ENTRY_MAX_DAILY),(spec['pressure_score'],spec['hold_sec'],spec['pullback_min_pct'],spec['pullback_max_pct'],spec['reaccel_sec'],spec['cooldown_sec'],spec['max_daily_buy']))
        self.assertEqual((DIRECT_SCORE,DIRECT_HOLD_SEC,DIRECT_CONFIRM_SEC),(spec['direct']['score'],spec['direct']['hold_sec'],spec['direct']['confirm_sec']))

    def test_candidate_prune_preserves_pinned(self):
        st=RuntimeState()
        for i in range(30):st.candidate(f'{i:06d}')
        st.candidates['000000'].live_track_pin=True;st.pinned_codes.add('000000')
        r=st.prune(10);self.assertLessEqual(len(st.candidates),10);self.assertIn('000000',st.candidates);self.assertGreater(r['removed_candidates'],0)


    def test_entry_lane_is_venue_isolated(self):
        st=RuntimeState();j=DurableJournal(Path(tempfile.mkdtemp()));p=EntryPolicy(st,j);c=st.candidate('000777')
        now=time.time()
        for venue,price in ((Venue.KRX,100.0),(Venue.NXT,101.0)):
            v=c.venue_state[venue];v.last_price=price;v.last_rate=1;v.last_recv_seq=1;v.last_tick_at=now;v.score=70
            v.metrics.update({'fresh':True,'continuity_ok':True,'buy_pressure':60,'algo_persistence':60,'volume_accel':1.5,'micro_vwap_gap':.1,'session_vwap_gap':.1,'impulse_60s':.5,'micro_breakout':.2,'program_fresh':True,'program_delta':1})
        p._set(c,Venue.KRX,'PRESSURE_BUILD','krx-only')
        self.assertEqual(c.venue_state[Venue.KRX].entry.state,'PRESSURE_BUILD')
        self.assertEqual(c.venue_state[Venue.NXT].entry.state,'DISCOVERY')
        self.assertEqual(p.source(c,Venue.KRX).price,100.0);self.assertEqual(p.source(c,Venue.NXT).price,101.0)

    def test_coalescing_lane_keeps_venues_separate(self):
        seen=[];lane=CoalescingLane(lambda kind,code,p: seen.append((kind,code,p.venue,p.net if hasattr(p,'net') else None)),interval=.01)
        now=time.time();from app.domain import ProgramTick
        lane.submit('PROGRAM','005930',ProgramTick('005930',Venue.KRX,1,0,1,1,now))
        lane.submit('PROGRAM','005930',ProgramTick('005930',Venue.NXT,2,0,2,2,now))
        self.assertEqual(lane.depth(),2);lane.start();time.sleep(.05);lane.stop()
        self.assertEqual({x[2] for x in seen},{Venue.KRX,Venue.NXT})

    def test_cumulative_fields_rebuild_session_vwap_state(self):
        st=RuntimeState();ing=Ingestor(st,LiveTracker());now=time.time()
        t=TradeTick('111111',Venue.NXT,105,10,1,1000,105000,'101010',now,time.monotonic(),1)
        ing.trade(Envelope('TRADE','111111',t,time.monotonic(),False));v=st.candidates['111111'].venue_state[Venue.NXT]
        self.assertEqual(v.session_v,1000);self.assertEqual(v.session_pv,105000);self.assertAlmostEqual(v.session_pv/v.session_v,105)

    def test_smart_money_single_50m_is_not_surge_but_accumulation_can_be(self):
        single={'smart50_buy_count':1,'smart70_buy_count':0,'smart100_buy_count':0,'smart200_buy_count':0,'smart50_sell_count':0,'smart50_buy_value':55_000_000,'smart50_sell_value':0,'pv':200_000_000}
        r=fast_proxy(single,{},single,65,.2);self.assertFalse(r['surge'])
        recent={'smart50_buy_value':140_000_000,'smart50_sell_value':0};prev={'smart50_buy_value':80_000_000,'smart50_sell_value':0}
        full={'smart50_buy_count':3,'smart70_buy_count':2,'smart100_buy_count':1,'smart200_buy_count':0,'smart50_sell_count':0,'smart50_buy_value':220_000_000,'smart50_sell_value':0,'pv':500_000_000}
        r2=fast_proxy(recent,prev,full,65,.2);self.assertTrue(r2['surge']);self.assertEqual(r2['label'],'REALTIME_PROXY_NOT_INVESTOR_IDENTITY')

    def test_mechanical_repeat_does_not_raise_valid_repeat(self):
        with tempfile.TemporaryDirectory() as td:
            st=RuntimeState();j=DurableJournal(Path(td));coord=SignalCoordinator(st,j);c=st.candidate('222222');now=time.time();v=c.venue_state[Venue.NXT]
            v.last_price=100;v.last_rate=1;v.last_recv_seq=1;v.last_tick_at=now
            src=TickSource(Venue.NXT,100,1,1,'101010',now);dec=ScoreDecision(70,80,'PRESSURE',['x'],{'fresh':True})
            rec=coord._stage_record(c,Venue.NXT,'PRESSURE',src,dec,False,'same')
            coord._apply_stage_committed(c,Venue.NXT,rec,dec,src,False,'same')
            self.assertEqual(v.entry.formal_raw_count,1);self.assertEqual(v.entry.valid_repeat_count,0);self.assertEqual(c.valid_repeat_count,0);self.assertEqual(len(c.signal_tracks),0)

    def test_integrity_day_reset_removes_previous_day_state(self):
        g=TickIntegrity();now=time.time();t=TradeTick('005930',Venue.KRX,70000,10,1,100,1000,'101010',now,time.monotonic(),1,'005930','KRX','fp')
        self.assertTrue(g.validate('20260812',t).accepted);self.assertTrue(g.last)
        g.reset_for_day('20260813');self.assertFalse(any(k[0]=='20260812' for k in g.last))

    def test_tail_jsonl_is_bounded_to_last_records(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'x.jsonl'
            with p.open('w') as f:
                for i in range(2000):f.write(json.dumps({'i':i})+'\n')
            rows=tail_jsonl(p,50,20_000);self.assertLessEqual(len(rows),50);self.assertEqual(rows[-1]['i'],1999);self.assertGreaterEqual(rows[0]['i'],1950)


    def test_wal_group_commit_concurrent_requests_are_all_durable(self):
        with tempfile.TemporaryDirectory() as td:
            j=DurableJournal(Path(td));j.start();results=[None]*32
            def worker(i):results[i]=j.commit({'event':'SIGNAL_CONFIRMED','i':i},2)
            threads=[threading.Thread(target=worker,args=(i,)) for i in range(32)]
            for t in threads:t.start()
            for t in threads:t.join()
            j.stop();self.assertTrue(all(results));rows=read_committed_wal(Path(td)/'signal_wal.sqlite3');self.assertEqual({r['i'] for r in rows},set(range(32)));self.assertGreaterEqual(j.stats['critical_group_commits'],1)


    def test_restart_recovery_wal_is_authoritative_no_double_repeat_count(self):
        import app.storage.runtime_store as rs
        day=trade_day();code='333333';s1={'event':'SIGNAL_CONFIRMED','signal_id':'s1','day':day,'code':code,'name':'X','venue':'NXT','stage':'PRESSURE','route':'SCORE_STAGE','signal_time':1,'signal_price':100,'signal_change_rate':1,'recv_seq':1,'exchange_time':'090001','server_receive_time':1,'reasons':[],'metrics':{},'origin':'TODAY_NEW','valid_repeat':True};b1={'event':'BUY_CONFIRMED','signal_id':'b1','day':day,'code':code,'name':'X','venue':'NXT','stage':'BUY','route':'DIRECT_IGNITION','signal_time':2,'decision_time':2,'signal_price':101,'signal_change_rate':1,'recv_seq':2,'exchange_time':'090002','server_receive_time':2,'reasons':[],'metrics':{},'origin':'TODAY_NEW'}
        seed={
            'runtime':{'day':day,'rows':[{'code':code,'name':'X','trade_day':day,'origin':'TODAY_NEW','live_track_pin':True,'last_buy_at':0,'last_buy_price':0,'last_buy_route':'','last_buy_venue':'UNKNOWN','venues':{'NXT':{'buy_count_today':5,'formal_raw_count':5,'valid_repeat_count':5,'last_formal_stage':'PRESSURE','last_formal_at':1}}}]},
            'prior_close':{'rows':[]},'history':[],'display_fallback':{},
            'formal_summary':{'row_count':2,'codes':{code:{'name':'X','origin':'TODAY_NEW','first':s1,'last':b1,'tracks':[s1,b1],'lanes':{'NXT':{'formal_raw_count':1,'valid_repeat_count':2,'buy_count_today':1,'last_formal_stage':'BUY','last_formal_at':2,'last_evidence_signature':'','last_buy':b1}}}}}}
        class D:
            def set_fallback(self,x):self.x=x
        old=rs.restore_seed;rs.restore_seed=lambda day=None:seed
        try:
            st=RuntimeState();store=RuntimeStore(st,D());asyncio.run(store.restore());lane=st.candidates[code].venue_state[Venue.NXT].entry
            self.assertEqual(lane.valid_repeat_count,2);self.assertEqual(lane.buy_count_today,1);self.assertEqual(st.candidates[code].last_buy_price,101)
        finally:rs.restore_seed=old

    def test_wal_stall_monitor_is_independent_of_event_loop(self):
        seen=[];j=DurableJournal(Path(tempfile.mkdtemp()),hard_stall_sec=.05,exit_fn=lambda code:seen.append(code));j.active_since=time.monotonic()-.2;j.active_kind='critical'
        t=threading.Thread(target=j._stall_monitor,daemon=True);t.start();time.sleep(.6);j.stop_evt.set();t.join(1);self.assertEqual(seen,[79])



    def test_discovery_exchange_selector_follows_current_active_venues(self):
        self.assertEqual(stex_for_session({'krx':True,'nxt':True}),'3')
        self.assertEqual(stex_for_session({'krx':True,'nxt':False}),'1')
        self.assertEqual(stex_for_session({'krx':False,'nxt':True}),'2')

    def test_exchange_session_boundaries_match_nxt_continuous_trade_windows(self):
        from datetime import date
        d=date(2026,8,12)
        def sec(h,m=0,s=0): return h*3600+m*60+s
        # NXT pre-market, then the KRX opening bridge while NXT is paused.
        self.assertTrue(sessions_at(d,sec(8,49,59))['nxt'])
        self.assertFalse(sessions_at(d,sec(8,50,0))['active'])
        self.assertEqual(sessions_at(d,sec(9,0,0))['phase'],'KRX')
        self.assertFalse(sessions_at(d,sec(9,0,29))['nxt'])
        self.assertTrue(sessions_at(d,sec(9,0,30))['nxt'])
        self.assertEqual(sessions_at(d,sec(9,0,30))['phase'],'DUAL')
        # NXT main closes at 15:20; KRX remains open to 15:30.
        self.assertTrue(sessions_at(d,sec(15,19,59))['nxt'])
        self.assertFalse(sessions_at(d,sec(15,20,0))['nxt'])
        self.assertEqual(sessions_at(d,sec(15,20,0))['phase'],'KRX')
        self.assertFalse(sessions_at(d,sec(15,30,0))['active'])
        # NXT after-market begins at 15:40 and ends at 20:00.
        self.assertFalse(sessions_at(d,sec(15,39,59))['nxt'])
        self.assertTrue(sessions_at(d,sec(15,40,0))['nxt'])
        self.assertEqual(sessions_at(d,sec(15,40,0))['nxt_phase'],'AFTER')
        self.assertTrue(sessions_at(d,sec(19,59,59))['nxt'])
        self.assertFalse(sessions_at(d,sec(20,0,0))['active'])

    def test_nontrading_calendar_day_keeps_last_trading_day_key(self):
        from datetime import date
        self.assertEqual(trading_day_for(date(2026,8,16)).strftime('%Y%m%d'),'20260814')
        # 2026-08-17 is present in the packaged KRX holiday calendar.
        self.assertEqual(trading_day_for(date(2026,8,17)).strftime('%Y%m%d'),'20260814')


    def test_resync_clears_stale_score_but_preserves_durable_buy_identity(self):
        st=RuntimeState();c=st.candidate('444444');v=c.venue_state[Venue.NXT];v.score=91;v.stage='IGNITION';v.entry.state='BUY';v.entry.last_buy_price=100;c.last_buy_venue=Venue.NXT;c.last_buy_price=100
        st.mark_resync({'444444'},'TEST_RECONNECT');self.assertEqual(v.score,0);self.assertEqual(v.stage,'SEED');self.assertEqual(v.entry.state,'BUY');self.assertFalse(v.metrics['fresh'])

    def test_restored_cumulative_rollback_fails_closed_without_overwrite(self):
        st=RuntimeState();ing=Ingestor(st,LiveTracker());c=st.candidate('555555');v=c.venue_state[Venue.NXT];v.last_cum_volume=1000;v.last_cum_turnover=100000
        now=time.time();t=TradeTick('555555',Venue.NXT,101,10,1,900,90900,'100000',now,time.monotonic(),1)
        ing.trade(Envelope('TRADE','555555',t,time.monotonic(),False));self.assertEqual(v.last_cum_volume,1000);self.assertEqual(v.continuity_reason,'CUMULATIVE_RESTORE_ROLLBACK');self.assertEqual(st.telemetry['cumulative_rollback_count'],1)


    def test_full_trade_queue_admits_pinned_by_evicting_noncritical(self):
        drops=[];d=TradeDispatcher(lambda e:None,lambda e,p,r:drops.append((e.code,p,r)),shards=1,maxsize=2)
        self.assertTrue(d.submit(Envelope('TRADE','A',None,time.monotonic(),False)));self.assertTrue(d.submit(Envelope('TRADE','B',None,time.monotonic(),False)))
        self.assertTrue(d.submit(Envelope('TRADE','S',None,time.monotonic(),True)));self.assertEqual(d.evicted_for_pinned,1);self.assertEqual(drops,[('A',False,'TRADE_QUEUE_EVICTED_FOR_PINNED')])
        # Queue is B,S; another pinned can evict B, still without a critical pinned drop.
        self.assertTrue(d.submit(Envelope('TRADE','S2',None,time.monotonic(),True)));self.assertEqual(drops[-1],('B',False,'TRADE_QUEUE_EVICTED_FOR_PINNED'))


    def test_buy_wal_uses_exact_source_tick_time_and_recv_seq_identity(self):
        st=RuntimeState();j=DurableJournal(Path(tempfile.mkdtemp()));c=st.candidate('666666');p=EntryPolicy(st,j);src=TickSource(Venue.NXT,12000,2.0,987,'101530',1234.567);intent=BuyIntent('DIRECT_IGNITION',['x'],src,{'fresh':True},1234.890)
        rec=p.wal_record(c,intent);self.assertEqual(rec['signal_time'],1234.567);self.assertEqual(rec['server_receive_time'],1234.567);self.assertEqual(rec['decision_time'],1234.890);self.assertTrue(rec['signal_id'].endswith(':BUY:987'))

    def test_wal_duplicate_signal_id_is_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            j=DurableJournal(Path(td));j.start();r={'event':'SIGNAL_CONFIRMED','signal_id':'same','day':trade_day(),'code':'1','venue':'NXT'}
            a=j.commit(r,1);b=j.commit(r,1);j.stop();self.assertTrue(a);self.assertTrue(a.inserted);self.assertTrue(b);self.assertFalse(b.inserted);self.assertEqual(len(read_committed_wal(Path(td)/'signal_wal.sqlite3')),1)


    def test_important_history_is_durable_and_recoverable(self):
        with tempfile.TemporaryDirectory() as td:
            j=DurableJournal(Path(td));j.start();self.assertTrue(j.append_important({'event':'HISTORY','event_key':'h1','day':'20260812','code':'005930','kind':'TOP5_ENTER','state':'HOT','at':1.0}));j.important.join();j.stop()
            rows=read_committed_history(Path(td)/'signal_wal.sqlite3');self.assertEqual(len(rows),1);self.assertEqual(rows[0]['event_key'],'h1')

    def test_important_history_queue_exhaustion_is_fail_hard(self):
        seen=[];j=DurableJournal(Path(tempfile.mkdtemp()),exit_fn=lambda code:seen.append(code))
        for i in range(j.important.maxsize):j.important.put_nowait({'i':i})
        self.assertFalse(j.append_important({'i':'overflow'}));self.assertEqual(seen,[80]);self.assertEqual(j.stats['important_enqueue_fail'],1)

    def test_important_stall_monitor_is_independent(self):
        seen=[];j=DurableJournal(Path(tempfile.mkdtemp()),event_stall_sec=.05,exit_fn=lambda code:seen.append(code));j.active_since=time.monotonic()-.2;j.active_kind='important'
        t=threading.Thread(target=j._stall_monitor,daemon=True);t.start();time.sleep(.4);j.stop_evt.set();t.join(1);self.assertEqual(seen,[80])

    def test_dispatcher_oldest_age_measures_waiting_queue_not_last_processed(self):
        d=TradeDispatcher(lambda e:None,lambda e,p,r:None,shards=1,maxsize=4);old=time.monotonic()-.25;self.assertTrue(d.submit(Envelope('TRADE','A',None,old,False)));a=d.oldest_age_ms();time.sleep(.06);b=d.oldest_age_ms();self.assertGreater(a,200);self.assertGreater(b,a+40)

    def test_dispatch_handler_exception_marks_exact_truth_gap(self):
        st=RuntimeState();ing=Ingestor(st,LiveTracker());c=st.candidate('565656');st.pinned_codes.add('565656');c.live_track_pin=True
        tick=TradeTick('565656',Venue.NXT,100,1,0,10,1000,'101010',time.time(),time.monotonic(),1)
        d=TradeDispatcher(lambda e: (_ for _ in ()).throw(RuntimeError('boom')),ing.dropped,shards=1,maxsize=4);d.start();self.assertTrue(d.submit(Envelope('TRADE','565656',tick,time.monotonic(),True)))
        end=time.time()+1
        while d.errors<1 and time.time()<end:time.sleep(.01)
        d.stop();self.assertEqual(d.errors,1);self.assertEqual(st.telemetry['dispatch_handler_error_count'],1);self.assertEqual(st.telemetry['dropped_signal_tick_count'],1);self.assertEqual(c.venue_state[Venue.NXT].continuity_reason,'DISPATCH_HANDLER_ERROR')

    def test_tracking_capacity_fail_closed_before_new_formal_signal(self):
        from app.config import SETTINGS
        st=RuntimeState();j=DurableJournal(Path(tempfile.mkdtemp()));coord=SignalCoordinator(st,j);budget=effective_ws_code_budget();st.pinned_codes={f'{i:06d}' for i in range(budget)};c=st.candidate('999999')
        ok,res=coord._reserve_tracking_capacity(c);self.assertFalse(ok);self.assertFalse(res);st.pinned_codes.add('999999');ok,res=coord._reserve_tracking_capacity(c);self.assertTrue(ok);self.assertFalse(res)

    def test_tracking_capacity_reservation_is_atomic_under_concurrency(self):
        from app.config import SETTINGS
        st=RuntimeState();budget=effective_ws_code_budget();st.pinned_codes={f'P{i:06d}' for i in range(budget-1)};bar=threading.Barrier(24);results=[];lock=threading.Lock()
        def worker(i):
            bar.wait();ok,res=st.reserve_tracking_slot(f'X{i:06d}',budget)
            with lock:results.append((i,ok,res))
        ts=[threading.Thread(target=worker,args=(i,)) for i in range(24)]
        for t in ts:t.start()
        for t in ts:t.join()
        winners=[x for x in results if x[1]];self.assertEqual(len(winners),1);self.assertEqual(len(st.tracking_reservations),1)
        st.release_tracking_slot(f'X{winners[0][0]:06d}');self.assertEqual(len(st.tracking_reservations),0)

    def test_coalescing_lane_handler_error_is_observable(self):
        lane=CoalescingLane(lambda *a: (_ for _ in ()).throw(RuntimeError('auxboom')),interval=.01);from app.domain import ProgramTick
        lane.submit('PROGRAM','005930',ProgramTick('005930',Venue.NXT,1,0,1,1,time.time()));lane.start();time.sleep(.05);lane.stop();self.assertGreaterEqual(lane.errors,1);self.assertIn('auxboom',lane.last_error)

    def test_followup_codes_are_in_ws_target_priority(self):
        from app.broker.websocket import KiwoomWebSocket
        st=RuntimeState();st.followup_codes={'F'};st.hot_codes={'H'};st.pinned_codes={'P'};ws=KiwoomWebSocket(st,None,None)
        from unittest.mock import patch
        with patch('app.broker.websocket.sessions',return_value={'krx':True,'nxt':True,'active':True,'phase':'DUAL'}):
            _sess,trade,_program,_ob=ws._targets()
        self.assertEqual(trade[:3],['P','F','H'])

    def test_registry_session_shape_change_removes_obsolete_group_exactly(self):
        from app.broker.websocket import KiwoomWebSocket
        from unittest.mock import patch
        st=RuntimeState();st.hot_codes={'005930'};ws=KiwoomWebSocket(st,None,None);ws.registered={'410':(('005930',),'0B')}
        class Dummy:
            def __init__(self):self.sent=[];self.acks=asyncio.Queue()
            async def send(self,raw):self.sent.append(json.loads(raw))
            async def recv(self):return json.dumps(await self.acks.get())
        async def run():
            d=Dummy();await d.acks.put({'trnm':'REMOVE','return_code':0});await d.acks.put({'trnm':'REG','return_code':0})
            with patch.object(ws,'_targets',return_value=({'krx':False,'nxt':True,'active':True,'phase':'NXT'},['005930'],[],[])):
                await ws._refresh_registry(d)
            self.assertEqual(d.sent[0],{'trnm':'REMOVE','grp_no':'410'})
            self.assertEqual(d.sent[1]['trnm'],'REG');self.assertEqual(d.sent[1]['grp_no'],'411');self.assertEqual(d.sent[1]['refresh'],'1');self.assertEqual(d.sent[1]['data'][0]['item'],['005930_NX'])
            self.assertNotIn('410',ws.registered);self.assertIn('411',ws.registered)
        asyncio.run(run())

    def test_registry_changed_group_is_remove_then_replace_not_accumulate(self):
        from app.broker.websocket import KiwoomWebSocket
        from unittest.mock import patch
        st=RuntimeState();ws=KiwoomWebSocket(st,None,None);ws.registered={'410':(('000001',),'0B')}
        class Dummy:
            def __init__(self):self.sent=[];self.acks=asyncio.Queue()
            async def send(self,raw):self.sent.append(json.loads(raw))
            async def recv(self):return json.dumps(await self.acks.get())
        async def run():
            d=Dummy();await d.acks.put({'trnm':'REMOVE','return_code':0});await d.acks.put({'trnm':'REG','return_code':0})
            with patch.object(ws,'_targets',return_value=({'krx':True,'nxt':False,'active':True,'phase':'KRX'},['000002'],[],[])):
                await ws._refresh_registry(d)
            self.assertEqual([x['trnm'] for x in d.sent],['REMOVE','REG']);self.assertEqual(d.sent[0]['data'][0],{'item':['000001'],'type':['0B']});self.assertEqual(d.sent[1]['data'][0]['item'],['000002']);self.assertEqual(ws.registered['410'],(('000002',),'0B'))
        asyncio.run(run())

    def test_registry_partial_diff_keeps_retained_symbol_live(self):
        from app.broker.websocket import KiwoomWebSocket
        from unittest.mock import patch
        st=RuntimeState();ws=KiwoomWebSocket(st,None,None);ws.registered={'410':(('000001','000002'),'0B')}
        class Dummy:
            def __init__(self):self.sent=[];self.acks=asyncio.Queue()
            async def send(self,raw):self.sent.append(json.loads(raw))
            async def recv(self):return json.dumps(await self.acks.get())
        async def run():
            d=Dummy();await d.acks.put({'trnm':'REMOVE','return_code':0});await d.acks.put({'trnm':'REG','return_code':0})
            with patch.object(ws,'_targets',return_value=({'krx':True,'nxt':False,'active':True,'phase':'KRX'},['000002','000003'],[],[])):
                await ws._refresh_registry(d)
            self.assertEqual([x['trnm'] for x in d.sent],['REMOVE','REG'])
            self.assertEqual(d.sent[0]['data'][0],{'item':['000001'],'type':['0B']})
            self.assertEqual(d.sent[1]['data'][0],{'item':['000003'],'type':['0B']})
            self.assertNotIn('000002',d.sent[0]['data'][0]['item'])
            self.assertNotIn('000002',d.sent[1]['data'][0]['item'])
            self.assertEqual(ws.registered['410'],(('000002','000003'),'0B'))
        asyncio.run(run())

    def test_ws_budget_is_safe_for_dual_venue_session_ceiling(self):
        from app.config import SETTINGS
        budget=effective_ws_code_budget();self.assertLessEqual(budget*2,SETTINGS.ws_session_item_cap);self.assertLessEqual(SETTINGS.ws_session_item_cap,200);self.assertGreaterEqual(budget,60)

    def test_token_expiry_uses_official_expires_dt_kst(self):
        from datetime import datetime
        from zoneinfo import ZoneInfo
        now=datetime(2026,8,12,10,0,0,tzinfo=ZoneInfo('Asia/Seoul')).timestamp();exp=_token_expiry_epoch({'expires_dt':'20260813100000'},now)
        self.assertEqual(exp,datetime(2026,8,13,10,0,0,tzinfo=ZoneInfo('Asia/Seoul')).timestamp())
        self.assertEqual(_token_expiry_epoch({},now),now+23*3600)
        with self.assertRaisesRegex(RuntimeError,'TOKEN_EXPIRY_NOT_FUTURE'):_token_expiry_epoch({'expires_dt':'20260812095900'},now)

    def test_token_invalidate_is_expected_token_safe(self):
        async def run():
            t=TokenManager();t.token='new';t.exp=time.time()+1000
            self.assertFalse(await t.invalidate('old'));self.assertEqual(t.token,'new')
            self.assertTrue(await t.invalidate('new'));self.assertEqual(t.token,'');self.assertEqual(t.exp,0)
        asyncio.run(run())

    def test_rest_auth_failure_invalidates_and_retries_once(self):
        from app.broker.kiwoom import RestPacer
        from app.config import SETTINGS
        from unittest.mock import AsyncMock,patch
        class Resp:
            def __init__(self,status,payload):self.status_code=status;self._payload=payload;self.text=json.dumps(payload)
            def json(self):return self._payload
        class Client:
            def __init__(self):self.calls=0
            async def post(self,*a,**k):
                self.calls+=1;return Resp(401,{'return_code':1}) if self.calls==1 else Resp(200,{'return_code':0,'ok':1})
        async def run():
            p=RestPacer();await p.client.aclose();p.client=Client()
            with patch('app.broker.kiwoom.TOKENS.get',new=AsyncMock(side_effect=['old','new'])) as get,patch('app.broker.kiwoom.TOKENS.invalidate',new=AsyncMock(return_value=True)) as inv:
                status,j=await p.post('/x','ka00000',{})
            self.assertEqual(status,200);self.assertEqual(j['ok'],1);self.assertEqual(get.await_count,2);inv.assert_awaited_once_with('old')
        asyncio.run(run())

    def test_position_manager_stable_order_is_not_score_ranked(self):
        st=RuntimeState();tr=LiveTracker();d=DisplayState(st,tr)
        a=st.candidate('A');b=st.candidate('B');a.last_buy_price=100;a.last_buy_at=1;a.last_buy_venue=Venue.KRX;a.venue_state[Venue.KRX].entry.state='BUY';b.last_buy_price=100;b.last_buy_at=2;b.last_buy_venue=Venue.KRX;b.venue_state[Venue.KRX].entry.state='BUY';a.score=10;b.score=99
        d.build();self.assertEqual([r['code'] for r in d.get()['boards']['position_manager']],['A','B'])
        a.score=100;b.score=1;d.build();self.assertEqual([r['code'] for r in d.get()['boards']['position_manager']],['A','B'])

    def test_groundup9_prebuy_uses_fresh_live_venue_not_stale_high_score_venue(self):
        st=RuntimeState();d=DisplayState(st,LiveTracker());c=st.candidate('119850','지엔씨에너지');now=time.time()
        k=c.venue_state[Venue.KRX];n=c.venue_state[Venue.NXT]
        k.last_price=55900;k.last_rate=15.98;k.last_tick_at=now-60;k.last_recv_seq=10;k.score=90
        n.last_price=54800;n.last_rate=13.69;n.last_tick_at=now;n.last_recv_seq=20;n.score=52
        c.current_venue=Venue.NXT;c.refresh_aggregate()
        self.assertEqual(c.best_signal_venue(),Venue.KRX)  # reproduce G8 stale-display precondition
        d.build();rows=d.get()['boards']['prebuy'];row=next(x for x in rows if x['code']=='119850')
        self.assertEqual(row['venue'],'NXT');self.assertEqual(row['price'],54800);self.assertEqual(row['change_rate'],13.69)
        self.assertEqual(row['display_price_source'],'LIVE_TRADE_TICK');self.assertFalse(row['display_stale'])

    def test_groundup9_position_manager_stale_buy_venue_fails_closed(self):
        st=RuntimeState();d=DisplayState(st,LiveTracker());c=st.candidate('119850','지엔씨에너지');now=time.time()
        k=c.venue_state[Venue.KRX];n=c.venue_state[Venue.NXT]
        k.last_price=55900;k.last_rate=15.98;k.last_tick_at=now-60;k.entry.state='BUY'
        n.last_price=54800;n.last_rate=13.69;n.last_tick_at=now;n.last_recv_seq=20
        c.last_buy_price=55000;c.last_buy_at=now-120;c.last_buy_venue=Venue.KRX;c.current_venue=Venue.NXT
        d.build();row=d.get()['boards']['position_manager'][0]
        self.assertEqual(row['display_venue'],'KRX');self.assertTrue(row['display_stale'])
        self.assertIsNone(row['price']);self.assertIsNone(row['change_rate']);self.assertIsNone(row['buy_return'])
        self.assertEqual(row['buy_return_status'],'STALE')

    def test_groundup9_signal_return_is_not_fabricated_from_stale_signal_venue(self):
        from app.runtime.projection import LiveDisplayProjection
        c=Candidate('119850','지엔씨에너지');now=time.time()
        c.venue_state[Venue.KRX].last_price=54800;c.venue_state[Venue.KRX].last_rate=13.69;c.venue_state[Venue.KRX].last_tick_at=now
        c.venue_state[Venue.NXT].last_price=55900;c.venue_state[Venue.NXT].last_rate=15.98;c.venue_state[Venue.NXT].last_tick_at=now-60
        c.last_signal=SignalEvent('s','20260813','119850','지엔씨에너지',Venue.NXT,'PRESSURE','SCORE_STAGE',now-90,55000,14.0,1,'140000',now-90,[],{},1,Origin.TODAY_NEW)
        row=LiveDisplayProjection(8000).row(c,now)
        self.assertEqual(row['price'],54800);self.assertEqual(row['venue'],'KRX')
        self.assertIsNone(row['signal_return']);self.assertEqual(row['signal_return_status'],'STALE')

    def test_groundup9_signal_logic_is_g8_byte_equivalent_except_runtime_identity(self):
        import hashlib
        root=Path(__file__).resolve().parents[1]
        expected={'policy.py':'960736bad317a286df03df031a0ea5c3d38c7a262c2611e36909ec2b6bb907c9','coordinator.py':'f1b6354797d00c48e919e0451975101a9848374f702fd0996ff297b8b68e430e'}
        for name,want in expected.items():
            text=(root/'app'/'signal'/name).read_text().replace('NOVA-3.1.0-MASTER-GROUNDUP-9','NOVA-3.0.0-MASTER-GROUNDUP-8')
            self.assertEqual(hashlib.sha256(text.encode()).hexdigest(),want,name)
        self.assertEqual(hashlib.sha256((root/'SIGNAL_POLICY_FROZEN.json').read_bytes()).hexdigest(),'7f1688843b83213332c054fc1c6ffba3d69ab48ed8c5518b3d37a8b19c0c8543')

    def test_performance_ledger_1_3_5_is_venue_locked_and_no_fabrication(self):
        from datetime import datetime
        from zoneinfo import ZoneInfo
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);j=DurableJournal(base);j.start();r={'event':'SIGNAL_CONFIRMED','signal_id':'sperf','day':'20260811','code':'005930','venue':'NXT','signal_price':100.0,'signal_time':1.0};self.assertTrue(j.commit(r,1));j.stop()
            st=RuntimeState();c=st.candidate('005930');n=c.venue_state[Venue.NXT];k=c.venue_state[Venue.KRX];n.last_price=110;n.last_tick_at=datetime(2026,8,12,19,59,tzinfo=ZoneInfo('Asia/Seoul')).timestamp();k.last_price=500;k.last_tick_at=n.last_tick_at
            led=PerformanceLedger(base);fake=datetime(2026,8,12,20,1,tzinfo=ZoneInfo('Asia/Seoul'))
            with patch('app.storage.performance.now_kst',return_value=fake):out=led.sync(st)
            rows=led.rows_for_code('005930');h1=[x for x in rows if x['horizon']==1][0];self.assertEqual(h1['status'],'FINAL');self.assertEqual(h1['close_price'],110);self.assertAlmostEqual(h1['return_pct'],10.0);self.assertEqual(h1['source'],'LIVE_NXT');self.assertEqual(out['finalized'],1)
            self.assertTrue(all(x['status']=='PENDING' for x in rows if x['horizon'] in (3,5)))


    def test_durable_timeline_survives_restart_and_contains_formal_signal(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);j=DurableJournal(base);j.start();self.assertTrue(j.commit({'event':'SIGNAL_CONFIRMED','signal_id':'timeline-s','day':'20260812','code':'777777','venue':'NXT','stage':'PRESSURE','signal_time':12.3,'signal_price':123.0,'reasons':['x']},1));self.assertTrue(j.append_important({'event':'HISTORY','event_key':'timeline-h','day':'20260812','code':'777777','kind':'TOP5','state':'TOP5_ENTER','price':123,'reason':'rank','venue':'NXT','at':12.4}));j.important.join();j.stop()
            rows=read_timeline_for_code(base/'signal_wal.sqlite3','777777');self.assertTrue(any(x.get('signal_id')=='timeline-s' for x in rows));self.assertTrue(any(x.get('state')=='TOP5_ENTER' for x in rows))

    def test_restart_restores_signal_mfe_mae_and_buy_cooldown(self):
        import app.storage.runtime_store as rs
        day=trade_day();code='339999';now=time.time();sig={'event':'BUY_CONFIRMED','signal_id':'bx','day':day,'code':code,'name':'X','venue':'NXT','stage':'BUY','route':'DIRECT_IGNITION','signal_time':now-10,'decision_time':now-10,'signal_price':100,'signal_change_rate':1,'recv_seq':9,'exchange_time':'101010','server_receive_time':now-10,'reasons':[],'metrics':{},'origin':'TODAY_NEW'}
        seed={'runtime':{'day':day,'rows':[{'code':code,'name':'X','trade_day':day,'origin':'TODAY_NEW','live_track_pin':True,'last_buy_at':now-10,'last_buy_price':100,'last_buy_route':'DIRECT_IGNITION','last_buy_venue':'NXT','signal_high':117,'signal_low':94,'buy_high':117,'buy_low':94,'signal_tracks':[{'signal_id':'bx','venue':'NXT','signal_price':100,'signal_time':now-10,'high':117,'low':94,'current':109,'last_tick_at':now-2}],'venues':{'NXT':{'last_cum_volume':1000,'last_cum_turnover':100000,'buy_count_today':1,'formal_raw_count':0,'valid_repeat_count':1,'last_formal_stage':'BUY','last_formal_at':now-10}}}]},'prior_close':{'rows':[]},'history':[],'display_fallback':{},'formal_summary':{'row_count':1,'codes':{code:{'name':'X','origin':'TODAY_NEW','first':sig,'last':sig,'tracks':[sig],'lanes':{'NXT':{'formal_raw_count':0,'valid_repeat_count':1,'buy_count_today':1,'last_formal_stage':'BUY','last_formal_at':now-10,'last_evidence_signature':'','last_buy':sig}}}}}}
        class D:
            def set_fallback(self,x):pass
        old=rs.restore_seed;rs.restore_seed=lambda day=None:seed
        try:
            st=RuntimeState();asyncio.run(RuntimeStore(st,D()).restore());c=st.candidates[code];lane=c.venue_state[Venue.NXT].entry;t=c.signal_tracks[-1]
            self.assertEqual((t.high,t.low,t.current),(117,94,109));self.assertGreater(lane.cooldown_until,time.time());self.assertEqual(lane.state,'BUY');self.assertEqual(c.buy_high,117);self.assertEqual(c.buy_low,94)
        finally:rs.restore_seed=old

    def test_formal_day_summary_is_complete_but_track_memory_bounded(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);j=DurableJournal(base);con=j._open_db();day='20260812'
            con.execute('BEGIN IMMEDIATE')
            for i in range(2005):
                r={'event':'SIGNAL_CONFIRMED','signal_id':f's{i}','day':day,'code':'008888','name':'X','venue':'NXT','stage':'PRESSURE','route':'SCORE_STAGE','signal_time':float(i+1),'signal_price':100+i*.01,'recv_seq':i+1,'valid_repeat':True,'origin':'TODAY_NEW'}
                con.execute('INSERT INTO formal_wal(signal_id,event,day,code,venue,created_at,payload) VALUES(?,?,?,?,?,?,?)',(r['signal_id'],r['event'],day,r['code'],r['venue'],r['signal_time'],json.dumps(r)))
            con.execute('COMMIT');con.close();x=summarize_formal_day(base/'signal_wal.sqlite3',day)
            lane=x['codes']['008888']['lanes']['NXT'];self.assertEqual(x['row_count'],2005);self.assertEqual(lane['formal_raw_count'],2005);self.assertEqual(lane['valid_repeat_count'],2005);self.assertEqual(len(x['codes']['008888']['tracks']),64)

    def test_performance_import_uses_durable_seq_watermark_not_latest_n(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);j=DurableJournal(base);src=j._open_db();day='20260811';src.execute('BEGIN IMMEDIATE')
            for i in range(5005):
                r={'event':'SIGNAL_CONFIRMED','signal_id':f'p{i}','day':day,'code':f'{i%900:06d}','venue':'NXT','signal_price':100.0,'signal_time':float(i+1)}
                src.execute('INSERT INTO formal_wal(signal_id,event,day,code,venue,created_at,payload) VALUES(?,?,?,?,?,?,?)',(r['signal_id'],r['event'],day,r['code'],r['venue'],r['signal_time'],json.dumps(r)))
            src.execute('COMMIT');src.close();led=PerformanceLedger(base);con=led._open();self.assertEqual(led._import_formal(con),5005);self.assertEqual(con.execute('SELECT COUNT(*) FROM signal_master').fetchone()[0],5005)
            src=sqlite3.connect(base/'signal_wal.sqlite3',isolation_level=None);src.execute('BEGIN IMMEDIATE')
            for i in range(5005,5008):
                r={'event':'BUY_CONFIRMED','signal_id':f'p{i}','day':day,'code':f'{i%900:06d}','venue':'NXT','signal_price':101.0,'signal_time':float(i+1)};src.execute('INSERT INTO formal_wal(signal_id,event,day,code,venue,created_at,payload) VALUES(?,?,?,?,?,?,?)',(r['signal_id'],r['event'],day,r['code'],r['venue'],r['signal_time'],json.dumps(r)))
            src.execute('COMMIT');src.close();self.assertEqual(led._import_formal(con),3);self.assertEqual(con.execute('SELECT COUNT(*) FROM signal_master').fetchone()[0],5008);con.close()

    def test_docker_runtime_contains_master_audit_dependencies(self):
        from pathlib import Path
        root=Path(__file__).resolve().parents[1]
        df=(root/'Dockerfile').read_text()
        self.assertIn('COPY Dockerfile /app/Dockerfile',df)
        self.assertIn('COPY SOURCE_MANIFEST.sha256 /app/SOURCE_MANIFEST.sha256',df)
        self.assertIn('COPY scripts /app/scripts',df)
        self.assertIn('COPY app /app/app',df)


    def test_groundup9_image_labels_and_pull_only_contract(self):
        root=Path(__file__).resolve().parents[1]
        df=(root/'Dockerfile').read_text()
        self.assertIn('io.quantnova.deploy_model=\"GHCR_PULL_ONLY\"',df)
        self.assertIn('io.quantnova.source_zip_sha256=\"${SOURCE_ZIP_SHA}\"',df)
        self.assertIn('org.opencontainers.image.version=\"NOVA-3.1.0-MASTER-GROUNDUP-9\"',df)
        self.assertNotIn('FROM quant-nova',df)
    def test_groundup9_clean_ui_and_guard_are_source_controlled(self):
        root=Path(__file__).resolve().parents[1]
        js=(root/'static/nova.js').read_text()
        sw=(root/'static/sw.js').read_text()
        guard=(root/'ops/http_guard_v2.py').read_text()
        self.assertIn("h['Authorization']='Bearer '+token",js)
        self.assertIn("setInterval(async()=>{try{render(await api('/api/live-dashboard'))",js)
        self.assertIn(',2000)',js)
        self.assertIn('nova31-g9-static-v1',sw)
        for bad in ('__NOVA_INLINE_AUTH_V3__','__NOVA_ALWAYS_ON_POLL_R7__','__NOVA_G8_R3__','NOVA_R6','NOVA_R7'):
            self.assertNotIn(bad,js)
            self.assertNotIn(bad,guard)
        self.assertIn('NOVA_HTTP_ISOLATION_V2',guard)
        self.assertIn('"Authorization"',guard)
        self.assertIn('LIVE_API_PATHS',guard)
        self.assertIn('LIVE_NO_CACHE',guard)


if __name__=='__main__':unittest.main()
