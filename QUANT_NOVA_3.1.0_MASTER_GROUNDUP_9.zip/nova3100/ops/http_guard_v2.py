#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib,json,mimetypes,os,threading,time
from concurrent.futures import ThreadPoolExecutor
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError

HOST=os.getenv("GUARD_HOST","0.0.0.0")
PORT=int(os.getenv("GUARD_PORT","8080"))
UPSTREAM=os.getenv("NOVA_UPSTREAM","http://quant-nova:8000").rstrip("/")
STATIC=Path(os.getenv("NOVA_STATIC_DIR","/srv/static"))
CACHE=Path(os.getenv("NOVA_CACHE_DIR","/srv/cache"))
GET_TIMEOUT=float(os.getenv("NOVA_GUARD_GET_TIMEOUT","0.55"))
WRITE_TIMEOUT=float(os.getenv("NOVA_GUARD_WRITE_TIMEOUT","6"))
MAX_BODY=int(os.getenv("NOVA_GUARD_MAX_BODY",str(20*1024*1024)))
MAX_UPSTREAM=int(os.getenv("NOVA_GUARD_MAX_UPSTREAM","6"))
CB_FAIL_THRESHOLD=int(os.getenv("NOVA_GUARD_CB_FAIL_THRESHOLD","3"))
CB_OPEN_SECONDS=float(os.getenv("NOVA_GUARD_CB_OPEN_SECONDS","1.8"))
FRESH_WINDOW=float(os.getenv("NOVA_GUARD_FRESH_WINDOW","0.8"))
CACHE.mkdir(parents=True,exist_ok=True)

_cache_lock=threading.RLock(); _mem_cache={}; _static_mem={}
_refresh_lock=threading.Lock(); _refreshing=set()
_slots=threading.BoundedSemaphore(MAX_UPSTREAM)
_bg=ThreadPoolExecutor(max_workers=MAX_UPSTREAM,thread_name_prefix="nova-guard")
_state_lock=threading.Lock()
_state={"started_at":time.time(),"requests":0,"static_served":0,"live_served":0,
       "fresh_cache_served":0,"stale_served":0,"unavailable":0,"upstream_ok":0,
       "upstream_fail":0,"upstream_busy_reject":0,"live_bypass_served":0,"consecutive_failures":0,
       "circuit_open_until":0.0,"last_upstream_ok_at":0.0,"last_upstream_error":""}
STATIC_MAP={"/":"index.html","/index.html":"index.html","/nova.js":"nova.js","/nova.css":"nova.css",
            "/sw.js":"sw.js","/manifest.webmanifest":"manifest.webmanifest",
            "/icon-192.png":"icon-192.png","/icon-512.png":"icon-512.png"}
LIVE_API_PATHS={"/api/live-dashboard","/api/prebuy-recommendations","/api/buy-signals","/api/nxt-alerts","/api/nxt-signal-table","/api/position-manager","/api/screen-state","/api/nova"}

def inc(k,n=1):
    with _state_lock:_state[k]=int(_state.get(k,0))+n

def snap():
    with _state_lock:return dict(_state)

def cb_open():
    with _state_lock:return time.time()<float(_state.get("circuit_open_until") or 0)

def mark_ok():
    with _state_lock:
        _state["upstream_ok"]+=1;_state["consecutive_failures"]=0
        _state["circuit_open_until"]=0.0;_state["last_upstream_ok_at"]=time.time();_state["last_upstream_error"]=""

def mark_fail(e):
    now=time.time()
    with _state_lock:
        _state["upstream_fail"]+=1;_state["consecutive_failures"]+=1;_state["last_upstream_error"]=str(e)[:200]
        if _state["consecutive_failures"]>=CB_FAIL_THRESHOLD:
            _state["circuit_open_until"]=max(float(_state["circuit_open_until"]),now+CB_OPEN_SECONDS)

def cpaths(path):
    k=hashlib.sha256(path.encode()).hexdigest()
    return CACHE/(k+".body"),CACHE/(k+".json")

def cput(path,ctype,body):
    rec={"content_type":ctype,"saved_at":time.time(),"sha256":hashlib.sha256(body).hexdigest()}
    with _cache_lock:_mem_cache[path]=(rec,body)
    bp,mp=cpaths(path)
    try:
        tb=Path(str(bp)+".tmp");tm=Path(str(mp)+".tmp")
        tb.write_bytes(body);tm.write_text(json.dumps(rec),encoding="utf-8");os.replace(tb,bp);os.replace(tm,mp)
    except Exception:pass

def cget(path):
    with _cache_lock:
        if path in _mem_cache:return _mem_cache[path]
    bp,mp=cpaths(path)
    try:
        rec=json.loads(mp.read_text(encoding="utf-8"));body=bp.read_bytes()
        if hashlib.sha256(body).hexdigest()!=rec.get("sha256"):return None
        with _cache_lock:_mem_cache[path]=(rec,body)
        return rec,body
    except Exception:return None

def ureq(method,path,headers,body=None,timeout=None):
    h={"User-Agent":"NOVA-HTTP-GUARD/2.0"}
    for k in ("Authorization","Content-Type","Accept"):
        v=headers.get(k)
        if v:h[k]=v
    with urlopen(Request(UPSTREAM+path,data=body,headers=h,method=method),timeout=timeout or GET_TIMEOUT) as r:
        data=r.read(MAX_BODY+1)
        if len(data)>MAX_BODY:raise RuntimeError("body_too_large")
        return int(r.status),r.headers.get("Content-Type","application/octet-stream"),data

def utry(method,path,headers,body=None,timeout=None):
    if method=="GET" and cb_open():raise RuntimeError("circuit_open")
    if not _slots.acquire(False):
        inc("upstream_busy_reject");raise RuntimeError("upstream_busy")
    try:
        out=ureq(method,path,headers,body,timeout);mark_ok();return out
    except Exception as e:
        mark_fail(e);raise
    finally:_slots.release()

def refresh(path,headers):
    with _refresh_lock:
        if path in _refreshing:return
        _refreshing.add(path)
    def job():
        try:
            st,ct,b=utry("GET",path,headers,timeout=GET_TIMEOUT)
            if st==200:cput(path,ct,b)
        except Exception:pass
        finally:
            with _refresh_lock:_refreshing.discard(path)
    _bg.submit(job)

def preload_static():
    for url,rel in STATIC_MAP.items():
        p=STATIC/rel
        if p.is_file():
            b=p.read_bytes();ct=mimetypes.guess_type(p.name)[0] or "application/octet-stream"
            if p.suffix in (".js",".css",".html",".webmanifest"):ct+="; charset=utf-8"
            _static_mem[url]=(ct,b);_static_mem["/static/"+rel]=(ct,b)

class Server(ThreadingHTTPServer):
    daemon_threads=True;allow_reuse_address=True;request_queue_size=128

class H(BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1";server_version="NOVAHTTPGuard/2.0"
    def log_message(self,*a):return
    def sendb(self,status,ct,b,extra=None):
        self.send_response(status);self.send_header("Content-Type",ct);self.send_header("Content-Length",str(len(b)))
        self.send_header("Connection","close");self.send_header("X-NOVA-HTTP-Guard","2")
        self.send_header("Cache-Control","no-store" if self.path.startswith(("/api/","/_guard/")) else "public,max-age=60")
        for k,v in (extra or {}).items():self.send_header(k,str(v))
        self.end_headers()
        if self.command!="HEAD":
            try:self.wfile.write(b)
            except (BrokenPipeError,ConnectionResetError):pass
    def sendj(self,status,o,extra=None):self.sendb(status,"application/json; charset=utf-8",json.dumps(o,separators=(",",":")).encode(),extra)
    def do_HEAD(self):return self.do_GET()
    def do_GET(self):
        inc("requests");clean=self.path.split("?",1)[0]
        if clean=="/_guard/health":
            st=snap();age=None if not st["last_upstream_ok_at"] else round(time.time()-st["last_upstream_ok_at"],3)
            return self.sendj(200,{"ok":True,"guard":"NOVA_HTTP_ISOLATION_V2",
                "selection_logic_modified":False,"candidate_selection_modified":False,
                "buy_thresholds_modified":False,"scoring_formula_modified":False,
                "ws_subscriptions_modified":False,"upstream_circuit_open":cb_open(),
                "upstream_last_ok_age_sec":age,"stats":st})
        if clean=="/_guard/upstream":
            t=time.time()
            try:
                st,ct,b=ureq("GET","/api/health",self.headers,timeout=.75)
                return self.sendj(200 if st==200 else 503,{"ok":st==200,"status":st,"elapsed_ms":round((time.time()-t)*1000,2)})
            except Exception as e:return self.sendj(503,{"ok":False,"error":str(e)[:160],"elapsed_ms":round((time.time()-t)*1000,2)})
        if clean in _static_mem:
            inc("static_served");ct,b=_static_mem[clean];return self.sendb(200,ct,b)
        if not clean.startswith("/api/"):return self.sendj(404,{"detail":"Not Found"})
        if clean=="/api/health":
            try:
                st,ct,b=utry("GET",self.path,self.headers,timeout=.7)
                if st==200:return self.sendb(200,ct,b,{"X-NOVA-Upstream":"LIVE"})
            except Exception as e:
                st=snap();return self.sendj(200,{"ok":False,"web_available":True,"upstream_live":False,
                    "guard":"NOVA_HTTP_ISOLATION_V2","error":str(e)[:100],
                    "consecutive_failures":st["consecutive_failures"],"circuit_open":cb_open()},
                    {"X-NOVA-Upstream":"DEGRADED"})
        if clean in LIVE_API_PATHS:
            try:
                st,ct,b=utry("GET",self.path,self.headers,timeout=GET_TIMEOUT)
                if st==200:inc("live_bypass_served")
                return self.sendb(st,ct,b,{"X-NOVA-Upstream":"LIVE_NO_CACHE"})
            except HTTPError as e:
                return self.sendb(e.code,e.headers.get("Content-Type","application/json"),e.read(MAX_BODY),{"X-NOVA-Upstream":"LIVE_NO_CACHE"})
            except Exception as e:
                inc("unavailable");return self.sendj(503,{"ok":False,"error":"UPSTREAM_LIVE_UNAVAILABLE","detail":str(e)[:100]},
                                                      {"Retry-After":"1","X-NOVA-Upstream":"UNAVAILABLE"})
        cached=cget(self.path)
        if cached:
            rec,b=cached;age=max(0,time.time()-float(rec["saved_at"]))
            inc("fresh_cache_served" if age<=FRESH_WINDOW else "stale_served");refresh(self.path,self.headers)
            return self.sendb(200,rec["content_type"],b,{"X-NOVA-Upstream":"CACHE_FRESH" if age<=FRESH_WINDOW else "STALE_WHILE_REVALIDATE",
                                                        "X-NOVA-Stale-Age":f"{age:.2f}"})
        try:
            st,ct,b=utry("GET",self.path,self.headers,timeout=GET_TIMEOUT)
            if st==200:cput(self.path,ct,b);inc("live_served")
            return self.sendb(st,ct,b,{"X-NOVA-Upstream":"LIVE"})
        except Exception as e:
            inc("unavailable");return self.sendj(503,{"ok":False,"error":"UPSTREAM_TEMPORARILY_UNAVAILABLE","detail":str(e)[:100]},
                                                  {"Retry-After":"1","X-NOVA-Upstream":"UNAVAILABLE"})
    def writeproxy(self):
        inc("requests");n=int(self.headers.get("Content-Length") or 0)
        if n>MAX_BODY:return self.sendj(413,{"detail":"Payload too large"})
        body=self.rfile.read(n) if n else b""
        try:
            st,ct,b=utry(self.command,self.path,self.headers,body,WRITE_TIMEOUT);return self.sendb(st,ct,b,{"X-NOVA-Upstream":"LIVE"})
        except HTTPError as e:return self.sendb(e.code,e.headers.get("Content-Type","application/json"),e.read(MAX_BODY))
        except Exception as e:return self.sendj(503,{"ok":False,"error":"UPSTREAM_WRITE_UNAVAILABLE","detail":str(e)[:120]})
    do_POST=writeproxy;do_PUT=writeproxy;do_PATCH=writeproxy;do_DELETE=writeproxy

if __name__=="__main__":
    preload_static()
    missing=[x for x in ("/","/static/nova.js") if x not in _static_mem]
    if missing:raise SystemExit("STATIC_PRELOAD_MISSING:"+",".join(missing))
    print(f"NOVA_HTTP_GUARD=START version=2 port={PORT} static={len(_static_mem)}",flush=True)
    Server((HOST,PORT),H).serve_forever()
