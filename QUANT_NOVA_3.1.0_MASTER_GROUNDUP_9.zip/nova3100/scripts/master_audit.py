from __future__ import annotations
import ast,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.runtime.state import RuntimeState
from app.signal import policy as p
from app.config import SETTINGS,effective_ws_code_budget

REQUIRED_TELEMETRY={
'dropped_signal_tick_count','dropped_candidate_tick_count','signal_price_mismatch_count','wrong_venue_price_count',
'stale_signal_count','signal_without_live_snapshot_count','duplicate_tick_reject_count','out_of_order_tick_count',
'stale_tick_reject_count','cumulative_rollback_count','journal_fail_closed_count','unrecovered_data_gap_count','ws_messages_per_sec','ws_receive_latency_ms',
'receiver_queue_depth','receiver_queue_oldest_age_ms','signal_queue_depth','signal_queue_oldest_age_ms','ui_clients',
'dispatch_handler_error_count','tracking_capacity_block_count','pinned_ws_overflow'
}

def policy_contract():
    j=json.loads((ROOT/'SIGNAL_POLICY_FROZEN.json').read_text())
    got={'pressure_score':p.ENTRY_PRESSURE_SCORE,'hold_sec':p.ENTRY_HOLD_SEC,'pullback_min_pct':p.ENTRY_PULLBACK_MIN,'pullback_max_pct':p.ENTRY_PULLBACK_MAX,'reaccel_sec':p.ENTRY_REACCEL_SEC,'cooldown_sec':p.ENTRY_COOLDOWN_SEC,'max_daily_buy':p.ENTRY_MAX_DAILY,'max_vwap_gap_pct':p.ENTRY_MAX_VWAP_GAP,'max_impulse_60s_pct':p.ENTRY_MAX_IMPULSE,'min_buy_pressure':p.ENTRY_MIN_BUY_PRESSURE,'min_algo_persistence':p.ENTRY_MIN_ALGO_PERSIST}
    for k,v in got.items():assert j[k]==v,(k,j[k],v)
    d=j['direct'];assert (d['score'],d['hold_sec'],d['confirm_sec'],d['buy_pressure'],d['algo_persistence'],d['volume_accel'],d['breakout_pct'],d['impulse_min_pct'],d['impulse_max_pct'],d['vwap_gap_max_pct'])==(p.DIRECT_SCORE,p.DIRECT_HOLD_SEC,p.DIRECT_CONFIRM_SEC,p.DIRECT_MIN_BUY_PRESSURE,p.DIRECT_MIN_ALGO_PERSIST,p.DIRECT_MIN_ACCEL,p.DIRECT_MIN_BREAKOUT,p.DIRECT_MIN_IMPULSE,p.DIRECT_MAX_IMPULSE,p.DIRECT_MAX_VWAP_GAP)
    q=j['pullback_confirm'];assert (q['score'],q['buy_pressure'],q['volume_accel'])==(p.PULLBACK_CONFIRM_SCORE,p.PULLBACK_CONFIRM_BUY_PRESSURE,p.PULLBACK_CONFIRM_ACCEL)
    print('MASTER_POLICY_PARITY=PASS')

def telemetry_contract():
    keys=set(RuntimeState().telemetry.keys());missing=REQUIRED_TELEMETRY-keys;assert not missing,missing
    health=(ROOT/'app/runtime/health.py').read_text()
    for needle in ('tick_to_signal_ms','tick_to_ui_ms','signal_queue_ms','receiver_to_state_ms','ui_push_ms','event_loop_lag_p95_ms','memory_growth_mb_sec','receiver_queue_oldest_age_ms'):assert needle in health,needle
    print(f'MASTER_TELEMETRY_CONTRACT=PASS base_keys={len(keys)}')

def architecture_contract():
    required=['app/runtime/window.py','app/runtime/dispatcher.py','app/runtime/integrity.py','app/storage/wal.py','app/storage/performance.py','app/runtime/watchdog.py','app/runtime/display.py','app/runtime/projection.py','ops/http_guard_v2.py','app/signal/coordinator.py','app/signal/policy.py','app/signal/smart_money.py','app/lifecycle/opening.py']
    for x in required:assert (ROOT/x).exists(),x
    wal=(ROOT/'app/storage/wal.py').read_text();assert 'ONE_WRITER_SQLITE_FULL_PRIORITY' in wal and 'important_history' in wal and '_stall_monitor' in wal and 'synchronous=FULL' in wal
    win=(ROOT/'app/runtime/window.py').read_text();assert '330' in win and 'maxlen=1500' not in win
    disp=(ROOT/'app/runtime/dispatcher.py').read_text();assert 'ProtectedTradeQueue' in disp and 'CoalescingLane' in disp and 'oldest_age_ms' in disp and 'evicted_for_pinned' in disp and 'DISPATCH_HANDLER_ERROR' in disp
    coord=(ROOT/'app/signal/coordinator.py').read_text();assert 'asyncio.gather' in coord and 'journal.commit' in coord and 'WS_TRACKING_CAPACITY' in coord
    perf=(ROOT/'app/storage/performance.py').read_text();assert 'HORIZONS=(1,3,5)' in perf and "'LIVE_'+venue" in perf and 'never substitute a later-day price' in perf
    for path in (ROOT/'app/signal').glob('*.py'):
        txt=path.read_text();assert not re.search(r'\bc\.entry\b',txt),(path,'shared candidate entry')
    assert SETTINGS.trade_queue_per_shard<=1024
    projection=(ROOT/'app/runtime/projection.py').read_text();display=(ROOT/'app/runtime/display.py').read_text()
    for needle in ('class LiveDisplayProjection','STALE_FAIL_CLOSED','display_venue_fallback','setInterval'):
        if needle=='setInterval': continue
        assert needle in projection,needle
    assert 'c.public(c.best_signal_venue())' not in display,'stale score-selected display venue survived'
    assert "'prebuy':[self.projection.row(c,now) for c in pre]" in display
    assert "'nxt_early':[self.projection.row(c,now,Venue.NXT,True) for c in nxt]" in display
    assert "'position_manager':[self.projection.row(c,now,c.last_buy_venue,True) for c in pos]" in display
    print('MASTER_LIVE_DISPLAY_TRUTH=PASS')
    print('MASTER_RUNTIME_ARCHITECTURE=PASS')

def broker_contract():
    ws=(ROOT/'app/broker/websocket.py').read_text();kw=(ROOT/'app/broker/kiwoom.py').read_text()
    # Dynamic registry must replace changed groups exactly, never keep stale HOT members forever.
    for needle in ("'trnm':'REMOVE'","await self._remove_group(ws,grp)","'refresh':'1'"):
        assert needle in ws,needle
    assert 'REGISTRY_SESSION_SHAPE_CHANGED' not in ws
    # Broker auth recovery follows the server-provided expiry and refreshes once on auth rejection.
    for needle in ('expires_dt','_token_expiry_epoch','async def invalidate','r.status_code in (401,403)','await TOKENS.invalidate(token)'):
        assert needle in kw,needle
    # Conservative safety margins against broker public limits.
    assert SETTINGS.rest_pace_sec>=0.2,SETTINGS.rest_pace_sec
    assert SETTINGS.ws_session_item_cap<=200,SETTINGS.ws_session_item_cap
    assert effective_ws_code_budget()*2<=SETTINGS.ws_session_item_cap,(effective_ws_code_budget(),SETTINGS.ws_session_item_cap)
    print(f'MASTER_BROKER_CONTRACT=PASS code_budget={effective_ws_code_budget()} session_item_cap={SETTINGS.ws_session_item_cap} rest_pace_sec={SETTINGS.rest_pace_sec}')

def ui_contract():
    js=(ROOT/'static/nova.js').read_text();css=(ROOT/'static/nova.css').read_text();html=(ROOT/'static/index.html').read_text();api=(ROOT/'app/api/app.py').read_text()
    assert js.count('new WebSocket(')==1
    assert '/api/live-dashboard' in js and '/ws/live' in js and '/api/performance/' in js
    assert "h['Authorization']='Bearer '+token" in js
    assert "setInterval(async()=>{try{render(await api('/api/live-dashboard'))" in js
    assert ',2000)' in js
    for forbidden in ('__NOVA_INLINE_AUTH_V3__','__NOVA_ALWAYS_ON_POLL_R7__','__NOVA_G8_R3__','NOVA_R6','NOVA_R7'):
        assert forbidden not in js,forbidden
    sw=(ROOT/'static/sw.js').read_text();assert 'nova31-g9-static-v1' in sw
    guard=(ROOT/'ops/http_guard_v2.py').read_text();
    for forbidden in ('__NOVA_G8_R3__','NOVA_R6','NOVA_R7'):
        assert forbidden not in guard,forbidden
    assert 'NOVA_HTTP_ISOLATION_V2' in guard and '"Authorization"' in guard
    assert 'LIVE_API_PATHS' in guard and 'LIVE_NO_CACHE' in guard and 'live_bypass_served' in guard
    for board in ('prebuy','opening','live_buy','nxt_early','nxt_management','position_manager'):assert board in html
    assert 'tabular-nums' in css and '/api/performance/{code}' in api
    print('MASTER_UI_SINGLE_WS_FIXED_SLOTS=PASS')

def no_async_storage_io():
    bad=[]
    for path in (ROOT/'app').rglob('*.py'):
        src=path.read_text();tree=ast.parse(src);lines=src.splitlines()
        for fn in [n for n in ast.walk(tree) if isinstance(n,ast.AsyncFunctionDef)]:
            for n in ast.walk(fn):
                if not isinstance(n,ast.Call):continue
                name=''
                if isinstance(n.func,ast.Name):name=n.func.id
                elif isinstance(n.func,ast.Attribute):
                    a=[];x=n.func
                    while isinstance(x,ast.Attribute):a.append(x.attr);x=x.value
                    if isinstance(x,ast.Name):a.append(x.id)
                    name='.'.join(reversed(a))
                if name.split('.')[-1] in {'open','read_text','write_text','fsync','connect'}:
                    line=lines[n.lineno-1] if n.lineno<=len(lines) else ''
                    if 'to_thread' in line or (path.name=='health.py' and '/proc/' in src):continue
                    if name.endswith('websockets.connect'):continue
                    bad.append((str(path.relative_to(ROOT)),fn.name,n.lineno,name,line.strip()))
    assert not bad,bad
    print('MASTER_ASYNC_STORAGE_BLOCKING_ZERO=PASS')

def build_contract():
    df=(ROOT/'Dockerfile').read_text();assert df.startswith('FROM python:3.12-slim-bookworm')
    for x in ('COPY Dockerfile /app/Dockerfile','COPY SOURCE_MANIFEST.sha256 /app/SOURCE_MANIFEST.sha256','COPY SIGNAL_POLICY_FROZEN.json','COPY app','COPY spec','COPY ops /app/ops','image_contract.py /app','master_audit.py','validate.py --quick','HEALTHCHECK','io.quantnova.deploy_model=\"GHCR_PULL_ONLY\"','io.quantnova.source_zip_sha256=\"${SOURCE_ZIP_SHA}\"'):assert x in df,x
    assert 'FROM quant-nova' not in df and 'docker commit' not in df
    for spec in ('QUANT_NOVA_최종_통합_마스터_설계안_재검토강화판_20260812.txt','QUANT_NOVA_최종_통합_마스터_설계안_SMART_MONEY_50M개정_20260812.txt'):assert (ROOT/'spec'/spec).exists(),spec
    print('MASTER_CLEAN_BUILD_CONTRACT=PASS')

def no_patch_lineage():
    bad=[];needles=('docker commit','main.py.bak','ROOT-MEMORY-LIVENESS','R6.','CLEAN-RUNTIME-R1.')
    for path in list((ROOT/'app').rglob('*'))+list((ROOT/'static').rglob('*'))+[ROOT/'Dockerfile']:
        if not path.is_file():continue
        text=path.read_text(errors='ignore')
        for n in needles:
            if n in text:bad.append((str(path.relative_to(ROOT)),n))
    assert not bad,bad
    print('NO_PATCH_LINEAGE=PASS')

def signal_source_freeze_contract():
    import hashlib
    expected={
        'app/signal/policy.py':'960736bad317a286df03df031a0ea5c3d38c7a262c2611e36909ec2b6bb907c9',
        'app/signal/coordinator.py':'f1b6354797d00c48e919e0451975101a9848374f702fd0996ff297b8b68e430e',
        'SIGNAL_POLICY_FROZEN.json':'7f1688843b83213332c054fc1c6ffba3d69ab48ed8c5518b3d37a8b19c0c8543',
    }
    for rel,want in expected.items():
        b=(ROOT/rel).read_bytes()
        if rel.endswith('.py'):
            b=b.replace(b'NOVA-3.1.0-MASTER-GROUNDUP-9',b'NOVA-3.0.0-MASTER-GROUNDUP-8')
        got=hashlib.sha256(b).hexdigest();assert got==want,(rel,got,want)
    print('MASTER_G8_SIGNAL_SOURCE_FREEZE=PASS')

def main():
    policy_contract();telemetry_contract();architecture_contract();broker_contract();ui_contract();no_async_storage_io();build_contract();no_patch_lineage();signal_source_freeze_contract();print('MASTER_SPEC_AUDIT=PASS')
if __name__=='__main__':main()
