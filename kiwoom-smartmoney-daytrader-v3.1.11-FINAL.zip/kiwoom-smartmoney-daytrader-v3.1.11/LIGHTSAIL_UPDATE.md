# Lightsail v3.1.11 FINAL 업데이트

GitHub 저장소 최상위에 `Dockerfile`, `kiwoom-smartmoney-daytrader-v3.1.11-FINAL.zip`, `update-lightsail-v3.1.11-FINAL.sh`를 올린 뒤 업데이트 스크립트를 실행합니다. 기존 `.env`와 `kiwoom-data` 볼륨을 그대로 사용합니다.

업데이트 스크립트는 기존 키움 인증/REST/WebSocket 설정을 보존하면서 감시 상한만 `집중 사용자 8 + 경량 사용자 8`로 맞춥니다. 소스 SHA256, 단위/통합/저장/수급/REST 회귀검사, **20종목 혼합 부하검사**, Next build가 모두 성공해야 새 컨테이너로 교체하고 실패하면 기존 컨테이너를 유지/복구합니다.

업데이트 후 `/api/health`에서 `status=connected`를 확인하고, 종가 동기화 후 `closeSnapshots` 및 장전 사전점검을 확인합니다. 장중에는 이벤트루프 p95, post-process pending/active, 메모리, 실시간 feedReady를 관찰하십시오.
