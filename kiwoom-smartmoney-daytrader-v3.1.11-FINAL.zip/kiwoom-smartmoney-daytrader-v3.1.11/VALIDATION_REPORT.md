# v3.1.11 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.11

## 목적과 변경범위

- 근본 목적: **급등/급락이 가격에 완전히 반영되기 전에 EARLY/RISK 신호를 포착**하면서 확정 BUY/SELL의 신뢰성 게이트는 유지.
- 데이터 수집 경로는 변경하지 않음. v3.1.10 대비 `worker/kiwoomRealtime.js`, `lib/kiwoomClient.js`, `lib/flowCollector.js`, `lib/realtimeStore.js` SHA256 동일 확인.
- 변경범위: 종가 배점(`marketSnapshot`), 실시간 사전포착 판정(`signalEngine`), 감시 상한(`stocks`), 표시/검사/설정.

## S491213 비교 반영

- S491213의 Pre-Surge 철학처럼 **미정배열 자체를 큰 음수로 보지 않고, 확인된 긍정 신호를 가점**하도록 조정.
- 기존 점수는 `legacyScore`로 보존하여 새 판정과 A/B 비교 가능.
- 현재 앱이 수집하지 않는 `상한가 최초 도달시각(10:30 이전 여부)`과 `상한가 풀림 횟수`는 새 수집 없이 추정/조작하지 않음. 대신 기존 EOD 사실만으로 보수적 `strongPriceLockProxy`를 사용.

## 종가 배점 합리화

- 미정배열: 기존 -10 고정 → 초기 회복 +3 / 종가 5일선 위 0 / 미정배열+5일선 아래 -3.
- 저거래량: 20일 거래량비 <0.7이라도 `당일 +25% 이상`, `고가대비 -0.7% 이내`, `거래대금 100억원 이상`이면 -7 감점 면제(+1).
- +10% 초과: 상승 자체 -4 폐지. 고가잠김형 +4, 고가근접+수급 2그룹 +2, 고가대비 -4% 이하 이탈 시 -6, 그 외 0.
- CLOSE_BUY의 추세 gate는 기존 정배열뿐 아니라 `5일선 상승전환`, `강한 가격잠김 추정`, `종가>20일선+당일 5% 이상`을 허용하되 기존 마감수급/완전성 게이트는 유지.

### 삼성전기형 합성 회귀사례

입력: +29.8%, 고가대비 -0.15%, 20일 거래량비 0.38, MA5<MA20이지만 MA5 상승, 거래대금 5,000억원, 수급 긍정.

- 기존점수: 65
- 새 점수: 94
- 차이: +29
- 거래량 부족 -7 미적용, 미정배열 -10 미적용.
- 단, 실제 과거일에 마감 스마트머니가 미수집이면 기존 마감수급 완전성 gate가 작동하므로 확정 종가매수로 가장하지 않음.

## 실시간 급등 사전포착

`preSurgeScore`는 **기존 수신 데이터만 재사용**해 0~100점으로 계산:

- 스마트머니 전환/흡수: 최대 20
- 공격매수·가속도·체결강도: 최대 25
- 프로그램/외국계 변화: 최대 20
- 호가 불균형·보충·매도철회: 최대 20
- RVOL·1분 거래대금·VWAP 재돌파/근접: 최대 15

기본 `preSurgeEarlyScore=68`, 최소 3개 독립그룹. `ABSORPTION/TURN/EXPANSION`, 스마트머니 feed ready, 집중감시, 충분한 데이터 완전성이 동반될 때 EARLY가 가능. **확정 BUY의 품질 85, 수익우선 78, 체결강도 118, 기대손익비 1.5R 등은 변경하지 않음.**

합성 회귀에서 품질점수 62/수익우선 56으로 아직 BUY가 아닌 상태에서도 preSurge 81점·5그룹으로 EARLY가 발생함을 확인.

## 20종목 구조 및 부하검증

기본 감시: `고정 집중 4 + 사용자 집중 8 + 경량 8 = 20`. 경량은 `0B`만 수신하고 기존 승격엔진이 기본 최대 2종목을 집중감시로 승격하므로 평상시 full-depth(`0B+0D+0F+0w`) 대상은 최대 14종목. 후처리 동시성 4와 종목별 latest-state 병합을 유지.

실행한 합성 부하검사(최종):

- 20종목, 100,000 가상 0B 틱 + 집중대상 주기적 0D/0F/0w 이벤트
- 처리율: 63,735 ticks/s
- 이벤트루프 p95: 24.71ms
- 이벤트루프 max: 26.57ms
- 최대 pending code: 20
- coalesced: 98,380
- processed: 1,620
- 오류: 0
- RSS: 114.9MB
- 종료 pending: 0 / active: 0

판정: **20종목 계층형 감시는 합성 부하에서 충분한 여유를 확인.** 다만 이 테스트는 Kiwoom 네트워크 지연, Lightsail CPU throttling/디스크, Redis/WebPush 지연을 재현하지 않으므로 장중 `/api/health` 지표의 실측 관찰이 최종 확인이다.

## 실행 검증

- `node --check` 주요 수정 JS: 통과
- `node scripts/check.js`: 통과
- `node scripts/integration-check.js`: 통과
- `node scripts/storage-check.js`: 통과
- `node scripts/flow-regression-check.js`: 통과
- `node scripts/rest-regression-check.js`: 통과
- `LOAD_TEST_TICKS=100000 LOAD_TEST_SYMBOLS=20 node scripts/load-check.js`: 통과

## Next.js 실제 빌드 확인

현재 제작환경의 내부 npm 프록시가 `autoprefixer@10.5.4` 요청에 404를 반환해 여기서는 `npm install`/`next build` 완료를 검증하지 못함. 배포용 Dockerfile/업데이트 스크립트는 `registry.npmjs.org`를 명시하고 **npm install → 전체 check → 20종목 load check → next build**가 전부 성공한 경우에만 새 컨테이너로 교체하도록 구성한다.
