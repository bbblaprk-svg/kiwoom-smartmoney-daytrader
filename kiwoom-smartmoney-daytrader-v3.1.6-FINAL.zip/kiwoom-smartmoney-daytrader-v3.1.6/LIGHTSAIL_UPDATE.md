# Lightsail v3.1.3 업데이트

GitHub 저장소 최상위에 다음 파일을 올립니다.

- `kiwoom-smartmoney-daytrader-v3.1.3.zip`
- `update-lightsail-v3.1.3.sh`
- 필요 시 `Dockerfile_v3.1.3`을 `Dockerfile` 이름으로 업로드

저장소가 Private이면 업데이트하는 동안만 Public으로 전환한 뒤, Lightsail SSH에서 다음 한 줄을 실행합니다.

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/bbblaprk-svg/kiwoom-smartmoney-daytrader/main/update-lightsail-v3.1.3.sh)
```

스크립트는 기존 `.env`와 `kiwoom-data` 볼륨을 그대로 사용합니다. 다음 기본값이 없을 때만 추가합니다.

```text
STORE_KEY_DIR=/app/data/store.json.d
ALERT_BATCH_MS=750
POSITION_BATCH_MS=750
LEDGER_BATCH_MS=5000
POST_PROCESS_CONCURRENCY=4
```

빌드 단계에서 소스 SHA256, 단위·통합·저장검사와 Next 빌드를 모두 통과해야 합니다. 새 컨테이너의 `/api/health` 응답이 정상일 때만 기존 컨테이너를 제거하며, 실패하면 자동으로 기존 버전으로 되돌립니다.

업데이트 후 Safari 탭을 완전히 닫았다가 다시 열고 다음을 확인합니다.

1. 상단 버전 `v3.1.3`
2. 실시간 탭의 `매수·매도 신호 한눈에`
3. `종합기록부` 탭의 현재가·진입가·매도가·수익률
4. 로그인 후 `/api/health`의 eventLoop·store·postProcess 부하지표
5. 기존 설정·포지션·종가 스냅샷 복구

확인 후 GitHub 저장소를 다시 Private으로 변경합니다.
