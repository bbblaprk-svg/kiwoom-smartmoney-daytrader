# Railway 최소비용 배포 가이드

## 권장 구성

- Railway 서비스 1개, Replica 1개
- Upstash Redis 무료 플랜 1개
- Railway 기본 도메인
- 키움 WebSocket 지속 연결
- SSE로 열린 앱에 즉시 전달
- Web Push는 앱 종료 시 보조경로

## 1. GitHub 업로드

ZIP을 PC에서 해제한 뒤 저장소 최상위에 다음 파일이 보이게 업로드합니다.

```text
Dockerfile
railway.json
package.json
server.js
pages/
lib/
worker/
public/
styles/
```

ZIP 파일 자체를 저장소에 올리는 방식이 아니라 압축을 푼 파일 전체를 올려야 합니다.

## 2. Railway 프로젝트 생성

1. Railway에서 `New Project`를 선택합니다.
2. `Deploy from GitHub repo`를 선택합니다.
3. 업로드한 저장소를 선택합니다.
4. Dockerfile 빌드가 자동 선택되는지 확인합니다.

## 3. 환경변수 입력

Railway 서비스의 Variables에 `.env.example` 값을 입력합니다.

필수:

- `KIWOOM_APP_KEY`
- `KIWOOM_APP_SECRET`
- `APP_ACCESS_TOKEN`
- `APP_SESSION_SECRET`

권장:

- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`
- `ALERT_BATCH_MS=750`
- `POSITION_BATCH_MS=750`
- `LEDGER_BATCH_MS=5000`
- `POST_PROCESS_CONCURRENCY=4`
- VAPID 3개 값

키움 Key와 Secret을 소스코드 또는 GitHub에 직접 적지 마십시오.

## 4. Replica 고정

`railway.json`은 Replica 1개로 구성되어 있습니다. 이를 늘리면 동일 키움 계정으로 WebSocket이 중복 연결되고 인메모리 신호 상태가 갈라질 수 있으므로 변경하지 않습니다.

## 5. 정상 확인

배포 후 다음을 확인합니다.

- `/api/health`의 `status`가 `connected`
- `focus`가 기본 4 이상
- `light`가 입력 종목 수와 일치
- 화면 상단 SSE 상태가 연결됨
- 실시간 가격과 실제 체결시장 KRX/NXT 표시
- 프로그램·거래원·호가 완전성 표시

## 6. Redis 비용 절약

- 틱과 롤링창은 서버 메모리에서만 처리
- 화면은 SSE 사용
- 관심종목·설정·포지션 전체 동기화 30초
- Redis에는 설정·일지·알림·실증성과만 저장
- 알림은 Redis List의 `LPUSH/LTRIM`으로 최대 1,000건 유지
- 캐시 TTL 기본 30초

이 구조는 매초 전체 대시보드를 Redis에서 읽는 기존 방식보다 명령량을 크게 줄입니다.

## 7. 실전 검증 순서

1. 주문 기능 없이 읽기 전용으로 배포
2. 영웅문과 실시간 데이터 비교
3. 신호 결과 200건 이상 축적
4. 장세·종목군별 승률과 기대값 분리 확인
5. 이상 없을 때만 소액 수동주문 보조단계 검토
