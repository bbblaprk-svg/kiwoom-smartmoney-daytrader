self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch (_) { payload = { body: event.data ? event.data.text() : '' }; }
  event.waitUntil(self.registration.showNotification(payload.title || '키움 단타 신호', {
    body: payload.body || '새로운 매매 신호가 발생했습니다.',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: `${payload.data && payload.data.code || 'signal'}-${payload.data && payload.data.action || 'alert'}`,
    renotify: true,
    data: payload.data || { url: '/' },
  }));
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windows) => {
    const target = event.notification.data && event.notification.data.url || '/';
    for (const client of windows) {
      if ('focus' in client) { client.navigate(target); return client.focus(); }
    }
    return clients.openWindow ? clients.openWindow(target) : null;
  }));
});
