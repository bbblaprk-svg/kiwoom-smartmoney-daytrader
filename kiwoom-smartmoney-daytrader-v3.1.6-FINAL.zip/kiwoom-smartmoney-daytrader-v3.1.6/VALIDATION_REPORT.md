# v3.1.4 VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.4  
검증 성격: 소스·기능·저장·합성부하 검증. 실제 키움 장중 데이터 및 Lightsail Docker 빌드는 별도 실서버 검증 필요.

## 핵심 수정

1. **종합 발생기록부**
   - SIGNAL/실제 POSITION 구분
   - 진입시점, 매도시점, 현재가, 진입가, 매도가, 실시간·확정 수익률
   - 매수·매도 확인중/확정/조기관찰/종료 상태
   - 품질점수, 수익우선점수, 매도점수
2. **수익우선 게이트**
   - 품질·유동성·기대손익비 가점
   - 스프레드·VWAP 추격위험 감점
   - 기존 품질 85점, 완전성 95%, 체결 3회·800ms, 독립그룹·수급 조건에 수익우선 78점 기준 추가
3. **저장 병목 개선**
   - 전체 메모리 맵 재직렬화 제거
   - 기존 `store.json` 읽기 호환 + 키별 `/app/data/store.json.d/*.json` 원자 저장
   - 알림 750ms 배치, 포지션 750ms, 기록부 현재가 5초 병합 저장
   - Redis 알림은 `LPUSH/LTRIM`으로 원자적 추가·길이 제한
4. **틱 후처리 백프레셔**
   - 종목별 최신상태 병합
   - 동일 종목 동시작업 1개
   - 전체 후처리 동시성 기본 4개
   - `.catch(() => null)`로 소멸하던 틱 후처리 오류를 카운트·로그화
5. **운영 지표**
   - 인증된 `/api/health`: 이벤트 루프 p50/p95/p99/max, 저장 큐, 알림 대기, 후처리 pending/active/coalesced/error, RSS/heap
   - 비인증 헬스체크에는 연결상태만 노출

## 실행 결과

### 단위검사

```bash
node scripts/check.js
```

결과: `CHECK OK`

확인:
- 4+4+4 구독 제한
- KRX/NXT 기준 분리와 종가 완전성
- 휴장 미측정 표시
- 보안 자격증명 강제검사
- 품질·스마트머니·VI·위험관리
- 수익우선점수 필드와 BUY 게이트

### 통합검사

```bash
node scripts/integration-check.js
```

결과: `INTEGRATION CHECK OK`

확인:
- 체결·호가·프로그램·거래원 순차 주입
- 집중종목 BUY 조건, 3회 확인, 800ms 유지
- 수익우선점수 통과
- 경량종목 BUY 차단·승격점수

### 저장·기록부 검사

```bash
node scripts/storage-check.js
```

결과: `STORAGE CHECK OK`

확인:
- 설정·포지션이 서로 다른 키 파일로 저장
- 40건 동시 알림 배치 저장 및 최신순 유지
- BUY 진입가 기록
- 현재가 70,700원/진입가 70,000원에서 +1.00% 계산
- SELL 71,400원에서 +2.00% 종료 수익률과 매도가 기록

### 합성 부하검사

```bash
node scripts/load-check.js
```

실행 결과:

- 종목: 12
- 가상 체결 틱: 12,000건
- 주입시간: 172ms
- 총 배출시간: 392ms
- 합성 주입 처리율: 69,767 ticks/s
- 이벤트 루프 p95: 22.18ms
- 이벤트 루프 최대: 23.13ms
- 최대 pending 종목: 12
- 병합된 후속작업: 11,796건
- 실제 후처리 실행: 204건
- 후처리 오류: 0건
- 종료 pending/active: 0/0
- RSS: 72.7MB

판정: 합성환경 통과. `LOAD_TEST_REPORT.json`에 결과를 저장했습니다.

> 이 결과는 네트워크가 없는 프로세스 내부 합성시험입니다. 실제 Lightsail의 CPU 제한, 디스크 지연, 키움 WebSocket 지연, Redis/Push 네트워크를 대신하지 않습니다.

### JavaScript·JSX 구문

- 모든 CommonJS JavaScript 파일 `node -c` 검사 대상
- `pages/index.js`는 TypeScript `transpileModule` JSX 파서로 구문 통과

### npm 설치·Next 빌드

현재 작업환경의 사내 npm 프록시에서 `autoprefixer@10.5.4` 조회가 404로 실패하여 여기서는 `npm install && npm run build`를 완료하지 못했습니다.

따라서 **실제 Lightsail Docker 빌드 성공 전에는 배포 빌드 검증 완료로 간주하지 않습니다.** Dockerfile은 빌드 중 소스 SHA256 확인, `npm run check`, `npm run check:load`, `npm run build`를 강제하고, 업데이트 스크립트는 새 컨테이너 건강검사 실패 시 기존 버전으로 롤백합니다.

## 실서버 필수 검증

최소 5거래일, 권장 10거래일:

1. 영웅문 대비 KRX/NXT 현재가·거래량·호가·VI·프로그램·거래원 대조
2. `/api/health` 이벤트 루프 p95, 저장 큐, post-process pending, RSS 시간별 기록
3. 동시 BUY/SELL 다발 구간에서 알림·기록 누락 확인
4. SIGNAL 발생가와 알림도착가·실제체결가의 슬리피지 기록
5. 200건 전 `미검증` 표시 유지와 quality85Plus 별도 성과 확인
6. 재시작 후 기록부·설정·포지션·종가 스냅샷 복구 확인

## 최종 판정

v3.1.4은 **읽기 전용 수익우선 검증판**입니다. 기록부 수익률 중 SIGNAL 행은 실제 체결수익이 아니라 신호 발생가 기준 가상 성과입니다. 실제 대조와 결정표본 200건이 완료되기 전에는 자동주문 또는 신호 단독 매매에 사용하지 않습니다.


## v3.1.4 FINAL 추가 검증

- `cfg.minProfitPriorityScore` 기본값 78: 변경 없음
- VWAP 이격 감점 공식: 변경 없음
- 신규 알림/UI: 없음
- `blockedByProfitPriority`: 매수의 나머지 필수조건과 품질점수를 통과했지만 수익우선점수만 기준 미달인 경우에만 true
- 숨김 shadow 기록: 별도 키 저장, 공개 종합기록부에서 제외
- 추적기간: 최초 차단 시점부터 15분, 이후 첫 체결가격으로 `return15mPct` 확정
- 로컬 검사: unit/integration/storage/load 통과
- 로컬 `npm install && next build`: 작업환경의 내부 npm 프록시가 공개 패키지에 404를 반환하여 완료하지 못함
- Lightsail 배포: Docker 빌드에서 공식 npm registry를 명시하고 모든 검사 및 `next build` 통과 전에는 기존 컨테이너를 교체하지 않음

## v3.1.4 official-flow reliability patch

- Added official REST fallback: ka10059 investor/institution flow, ka10008 foreign flow, ka90004 per-stock program flow.
- Real-time 0w program and 0F broker feeds remain first priority; REST is fallback/enrichment.
- Added global REST pacing (default 230 ms between requests) to stay below the official domestic-stock query ceiling of 5 requests/sec.
- Added institution closing flow to the closing snapshot.
- CLOSE_BUY is downgraded when completeness <85% or smart-money/program/foreign/institution flow is incomplete.
- Missing flow remains `missing`; it is not converted to a neutral zero.
- Unit, integration, storage and synthetic-load checks passed in the build source tree.
- Local `next build` could not be executed because the sandbox npm proxy returns 404 for public packages. The Dockerfile forces registry.npmjs.org and runs npm install + checks + load test + next build before deployment; failure prevents replacement of the running container.
