const { requireAuth } = require('../../../lib/auth');
module.exports = function handler(req, res) {
  if (!requireAuth(req, res)) return;
  res.status(200).json({ publicKey: process.env.VAPID_PUBLIC_KEY || null, enabled: Boolean(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) });
};
