const { getItem, setItem } = require('../../../lib/store');
const { PUSH_KEY } = require('../../../lib/notifications');
const { requireAuth } = require('../../../lib/auth');
module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'POST') {
      const subscription = req.body;
      if (!subscription || !subscription.endpoint) return res.status(400).json({ error: '유효한 푸시 구독정보가 필요합니다.' });
      const current = (await getItem(PUSH_KEY)) || [];
      const next = [subscription, ...current.filter((item) => item.endpoint !== subscription.endpoint)].slice(0, 20);
      await setItem(PUSH_KEY, next);
      return res.status(201).json({ ok: true, count: next.length });
    }
    if (req.method === 'DELETE') {
      const endpoint = req.body && req.body.endpoint;
      const current = (await getItem(PUSH_KEY)) || [];
      const next = current.filter((item) => item.endpoint !== endpoint);
      await setItem(PUSH_KEY, next);
      return res.status(200).json({ ok: true, count: next.length });
    }
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
