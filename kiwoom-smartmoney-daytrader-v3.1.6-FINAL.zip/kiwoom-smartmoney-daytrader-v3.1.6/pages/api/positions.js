const { getItem, setItem } = require('../../lib/store');
const { mergeSettings, defaultPerStock } = require('../../lib/settings');
const { mergeWatchlist, normalizeBaseCode } = require('../../lib/stocks');
const { accountRisk, calculateNetPnl } = require('../../lib/risk');
const { requireAuth } = require('../../lib/auth');

const KEY = 'positions';
async function loadPositions() { const data = await getItem(KEY); return Array.isArray(data) ? data : []; }

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') return res.status(200).json({ positions: await loadPositions() });

    if (req.method === 'POST') {
      const [positions, settings, userStocks] = await Promise.all([
        loadPositions(),
        getItem('settings').then(mergeSettings),
        getItem('watchlist:user'),
      ]);
      const risk = accountRisk(positions, settings);
      const accountWarnings = [];
      if (risk.halted) accountWarnings.push(`신규매수 차단 상태: ${risk.reasons.join(', ')}`);
      if (risk.openCount >= Number(settings.maxConcurrentPositions || 3)) accountWarnings.push('최대 동시 보유종목 수 도달');

      const body = req.body || {};
      const code = normalizeBaseCode(body.code);
      const watchlist = mergeWatchlist(userStocks || []);
      const stock = watchlist.find((item) => item.code === code);
      if (!stock) return res.status(400).json({ error: '실시간 감시목록에 등록된 종목만 기록할 수 있습니다.' });

      const avgPrice = Number(body.avgPrice);
      const quantity = Math.floor(Number(body.quantity || body.qty));
      if (!(avgPrice > 0) || !(quantity > 0)) return res.status(400).json({ error: '매수가와 수량은 0보다 커야 합니다.' });

      const cfg = settings.perStock[code] || defaultPerStock(code);
      const calculatedStop = avgPrice * (1 + Number(cfg.stopPct || -1.5) / 100);
      const initialStopPrice = body.initialStopPrice ? Number(body.initialStopPrice) : calculatedStop;
      if (!(initialStopPrice > 0) || initialStopPrice >= avgPrice) return res.status(400).json({ error: '최초 손절가는 0보다 크고 매수가보다 낮아야 합니다.' });

      const plannedRisk = (avgPrice - initialStopPrice) * quantity;
      const maxRiskBudget = Number(settings.accountEquity || 0) * Number(settings.maxRiskPerTradePct || 0) / 100;
      if (plannedRisk > maxRiskBudget) accountWarnings.push(`계획손실 ${Math.round(plannedRisk).toLocaleString()}원이 1회 위험예산 ${Math.round(maxRiskBudget).toLocaleString()}원을 초과`);
      const riskWarning = accountWarnings.length ? accountWarnings.join(' · ') : null;

      const createdAt = new Date().toISOString();
      const position = {
        id: body.id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        code,
        name: stock.name,
        market: stock.market,
        quantity,
        avgPrice,
        initialStopPrice: Math.round(initialStopPrice),
        currentStopPrice: Math.round(initialStopPrice),
        highestPrice: Number(body.highestPrice || avgPrice),
        memo: String(body.memo || '').slice(0, 500),
        plannedRisk: Math.round(plannedRisk),
        riskWarning,
        notifiedLevels: [],
        status: 'open',
        createdAt,
        updatedAt: createdAt,
      };
      positions.unshift(position);
      await setItem(KEY, positions);
      return res.status(201).json({ position, riskWarning });
    }

    if (req.method === 'PUT') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id가 필요합니다.' });
      const [positions, settings] = await Promise.all([loadPositions(), getItem('settings').then(mergeSettings)]);
      const idx = positions.findIndex((item) => item.id === id);
      if (idx < 0) return res.status(404).json({ error: '포지션을 찾을 수 없습니다.' });
      const current = positions[idx];

      // 손실한도에 걸려도 매도·청산 기록은 항상 허용합니다.
      if (req.body.status === 'closed') {
        const exitPrice = Number(req.body.exitPrice);
        if (!(exitPrice > 0)) return res.status(400).json({ error: '매도 체결가는 0보다 커야 합니다.' });
        const exitTime = req.body.exitTime || new Date().toISOString();
        const pnl = calculateNetPnl(current, exitPrice, settings);
        positions[idx] = {
          ...current,
          status: 'closed',
          exitPrice,
          exitTime,
          ...pnl,
          updatedAt: new Date().toISOString(),
        };
      } else {
        const updates = {};
        if (req.body.memo != null) updates.memo = String(req.body.memo).slice(0, 500);
        positions[idx] = { ...current, ...updates, updatedAt: new Date().toISOString() };
      }
      await setItem(KEY, positions);
      return res.status(200).json({ position: positions[idx] });
    }

    if (req.method === 'DELETE') {
      return res.status(403).json({ error: '일일 손실한도와 복기 기록의 무결성을 위해 매매일지는 삭제할 수 없습니다.' });
    }

    res.setHeader('Allow', ['GET', 'POST', 'PUT', 'DELETE']);
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
