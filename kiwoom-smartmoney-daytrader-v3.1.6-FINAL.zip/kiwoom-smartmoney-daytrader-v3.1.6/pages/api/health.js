const { state } = require('../../lib/realtimeStore');
const { getStoreMetrics } = require('../../lib/store');
const runtimeMetrics = require('../../lib/runtimeMetrics');
const { isAuthenticated } = require('../../lib/auth');

module.exports = function handler(req, res) {
  const connected = state.connection.status === 'connected';
  const stocks = [...state.stocks.values()];
  const focus = stocks.filter((stock) => stock.activeTier === 'FOCUS').length;
  const light = stocks.filter((stock) => stock.activeTier === 'LIGHT').length;
  const promoted = stocks.filter((stock) => Number(stock.promotedUntil || 0) > Date.now()).length;
  const closeSnapshots = stocks.filter((stock) => Number(stock.marketSnapshot && stock.marketSnapshot.krx && stock.marketSnapshot.krx.close || 0) > 0).length;
  const now = Date.now();
  const smartMoneyReady = stocks.filter((stock) => stock.activeTier === 'FOCUS'
    && stock.updatedAt && now - stock.updatedAt <= 1500
    && stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 3500
    && stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 20000
    && stock.broker && stock.broker.updatedAt && now - stock.broker.updatedAt <= 120000).length;
  const load = runtimeMetrics.snapshot();
  const store = getStoreMetrics();

  const payload = {
    ok: connected,
    status: state.connection.status,
    lastMessageAt: state.connection.lastMessageAt,
    subscribed: state.connection.subscribed.length,
    focus, light, promoted, closeSnapshots, smartMoneyReady,
    lastSnapshotAt: state.connection.lastSnapshotAt || null,
    snapshotStatus: state.connection.snapshotStatus || null,
    sseClients: state.sseClients || 0,
    serverTime: new Date().toISOString(),
  };
  // 외부 헬스체크에는 연결상태만 노출하고, 부하·메모리 상세는 로그인 세션/토큰에만 제공합니다.
  if (isAuthenticated(req)) {
    payload.load = {
      eventLoop: load.eventLoop,
      store: { ...load.store, backend: store.usingRedis ? 'redis' : store.usingLocalFile ? 'local-sharded' : 'memory', keyCount: store.keyCount, queueLength: store.queueLength, pendingKeys: store.pendingKeys },
      alerts: load.alerts,
      postProcess: load.postProcess,
      memory: load.memory,
    };
  }
  res.status(200).json(payload);
};
