# QUANT NOVA 3.3.1 MASTER TOP10 PERF — Final Acceptance Report

## Release identity
- Runtime version: `NOVA-3.3.1-MASTER-TOP10-PERF`
- Master specification: `spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt` + section 49 performance hardening contract
- Signal policy: `ENTRY_V18_TRUTH_GUARD_MAX_PROFIT` — numeric thresholds unchanged
- Visible boards: maximum 10 fixed slots

## P0 performance changes
- Metric windows: shared `metric_bundle` selection path; legacy aggregate-equivalence regression added.
- REST: Discovery pauses during `RESYNC/WARMING/RECONNECTING`; recovery owns REST budget.
- UI: compact Top10 DTO; snapshot/delta JSON pre-serialized once per display generation and shared across clients.
- WAL: critical/important enqueue immediately wakes writer; old 50ms important blocking wait removed.
- Disk: JSONL size rotation, SQLite retention, performance-final retention, disk-free telemetry and low-disk noncritical log guard.
- Memory: nonprotected realtime window idle TTL split from 900s candidate TTL; default fast-window TTL 180s.

## Validation results
- Python unit/regression: **80 / 80 PASS** (75 previous + 5 P0 regressions).
- Master Spec Audit: **PASS**.
- Quick integrated validation: **PASS**.
- Metric bundle numerical equivalence vs legacy aggregate windows: **PASS**.
- Bounded dispatcher: **40,000 / 40,000 processed, candidate drops 0, protected signal drops 0**, max depth 840.
- Durable Journal stress: **250 formal + 250 important PASS**, critical write p95 about **1.29ms**.
- Composite 3.3.1 performance test: **PASS** — 1,200 candidates, 90 live symbols, KRX+NXT dual venue, 18,000 burst events plus repeated 180-venue scoring, Top10 display builds, and WAL commits.
  - observed throughput: about **8,772 events/s** in this container test
  - score batch 24 p95: **11.22ms**
  - score all 180 p95: **81.72ms**
  - display build p95: **2.92ms**
  - shared wire snapshot: **21,567 bytes**; last delta: **18,339 bytes**
  - WAL queue wait p95: **0.12ms**; WAL write p95: **0.91ms** in composite test
  - RSS: **156.2 → 158.4MB** during composite test
- Offline runtime smoke: **10 concurrent WebSocket clients PASS**, RSS about **137.3MB**, swap **0MB**.

## Production boundary
Authenticated live Kiwoom KRX/NXT soak testing is still an external production acceptance step because live credentials and real exchange traffic are not available in this build environment. The source passes static, unit, regression, synthetic-load, durability, UI concurrency, and local runtime tests; production acceptance must additionally compare live broker price/change/timestamps and observe CPU, queue p95/p99, REST recovery, disk free space, and protected-tick invariants through an actual session.
