# QUANT NOVA 3.3.1 MASTER TOP10 PERF

Source of truth: `spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt`.

Main path: Broker WS -> lightweight receiver -> bounded protected queue -> venue-isolated state/window -> critical-event latch -> signal worker -> Atomic Snapshot -> durable WAL ACK -> live tracker -> instrument aggregator -> TOP10 ranking -> delta aggregator -> `/ws/live`.

Side paths: REST recovery, DB/performance, snapshots, discovery. Side paths never establish a formal signal price.

Hard invariants: wrong venue=0; signal price mismatch=0; official signal without WAL ACK=0; stale official signal=0; protected signal tick drop=0 inside the supported load envelope.

UI: fixed 10 slots per core board. Layout is fixed; price/rank/state are live. iPhone uses compact rows and bottom-sheet detail; iPad uses expanded rows.
