const fs=require('fs'); const assert=require('assert');
const w=fs.readFileSync('worker/kiwoomRealtime.js','utf8');
assert(w.includes("KIWOOM_OFFICIAL_DOMESTIC_BARE_REG_V4"));
assert(w.includes("[{ item: baseCodes, type: ['0B'] }]") );
assert(!w.includes('`${code}_NX`'));
assert(!/stex_tp\s*:/.test(w));
assert(!w.includes('NXT_SUFFIX'));
assert(!w.includes('CORE_TRADE_NXT'));
console.log('OFFICIAL_DOMESTIC_REG_V334_CHECK PASS');
