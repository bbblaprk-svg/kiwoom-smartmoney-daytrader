from __future__ import annotations
from collections import deque, defaultdict
import time, math, statistics

POLICY='MARKET_SECTOR_RS_SHADOW_V1_OBSERVE_ONLY_NO_LIVE_SCORE'
HORIZONS=(60,300,900)
_MARKET_HISTORY={'001':deque(maxlen=1600),'101':deque(maxlen=1600)}
_SECTOR_HISTORY=defaultdict(lambda:deque(maxlen=1600))


def _num(x,d=0.0):
    try:return float(x)
    except:return float(d)

def _clamp(x,a=-10.0,b=10.0):return max(a,min(b,float(x)))

def normalize_rate(x):
    """Kiwoom sector endpoints may return percent strings as 3.52 or scaled integer 352."""
    v=_num(str(x or '').replace(',','').replace('+',''))
    if abs(v)>50:v/=100.0
    return round(v,6)

def observe_market(market_code:str, *, ts:float|None=None, level:float|None=None, day_rate:float|None=None, source='ka20001'):
    code='001' if str(market_code)=='001' else '101' if str(market_code)=='101' else ''
    if not code:return False
    ts=float(ts or time.time());level=_num(level);rate=_num(day_rate)
    h=_MARKET_HISTORY[code]
    if h and ts-_num(h[-1].get('ts'))<1:return False
    h.append({'ts':ts,'level':level if level>0 else None,'day_rate':rate,'source':source})
    return True

def observe_sector(sector:str, day_rate:float, *, ts:float|None=None):
    sec=str(sector or '').strip()
    if not sec:return False
    ts=float(ts or time.time());h=_SECTOR_HISTORY[sec]
    if h and ts-_num(h[-1].get('ts'))<0.5:return False
    h.append({'ts':ts,'day_rate':_num(day_rate)})
    return True

def _nearest_past(rows, target:float, tolerance:float):
    best=None;bd=10**18
    for r in reversed(rows):
        t=_num(r.get('ts'))
        if t>target+5:continue
        d=abs(t-target)
        if d<bd:best=r;bd=d
        if t<target-tolerance:break
    return best if best is not None and bd<=tolerance else None

def _stock_return(ticks, now:float, horizon:int, current_price:float):
    if current_price<=0:return None
    rows=[t for t in ticks if _num(getattr(t,'price',0))>0 and _num(getattr(t,'ts',0))<=now]
    if not rows:return None
    target=now-horizon;best=None;bd=10**18
    tol=max(20.0,min(120.0,horizon*.25))
    for t in reversed(rows):
        tt=_num(getattr(t,'ts',0));d=abs(tt-target)
        if d<bd:best=t;bd=d
        if tt<target-tol:break
    if best is None or bd>tol:return None
    p0=_num(getattr(best,'price',0))
    return ((current_price/p0)-1.0)*100.0 if p0>0 else None

def _history_return(rows, now:float, horizon:int):
    if not rows:return None
    cur=rows[-1];prev=_nearest_past(rows,now-horizon,max(30.0,min(180.0,horizon*.30)))
    if not prev:return None
    l1=_num(cur.get('level'));l0=_num(prev.get('level'))
    if l1>0 and l0>0:return (l1/l0-1.0)*100.0
    # Difference of day-return observations is a bounded research fallback, not a live trading input.
    return _num(cur.get('day_rate'))-_num(prev.get('day_rate'))

def _stock_day_rate(rate):return _num(rate)

def build_relative_strength_observation(*, market_code:str, sector:str, ticks, current_price:float, stock_day_rate:float, sector_day_rate:float, now:float|None=None, load_mode='FULL'):
    """Research-only relative strength snapshot. Never returns a BUY score or mutation instruction."""
    now=float(now or time.time());market='001' if str(market_code)=='001' else '101' if str(market_code)=='101' else ''
    mh=_MARKET_HISTORY.get(market) or deque();sh=_SECTOR_HISTORY.get(str(sector or '')) or deque()
    market_day=_num(mh[-1].get('day_rate')) if mh else None
    out={'policy':POLICY,'auto_apply':False,'market_code':market or None,'market_name':'KOSPI' if market=='001' else 'KOSDAQ' if market=='101' else None,'sector':str(sector or '') or None,'load_mode':str(load_mode or 'FULL').upper(),'source_ready':bool(market and mh),'horizons':{},'day':{}}
    day_stock=_stock_day_rate(stock_day_rate);day_sector=_num(sector_day_rate)
    out['day']={'stock':round(day_stock,4),'market':round(market_day,4) if market_day is not None else None,'sector':round(day_sector,4) if sector else None,'market_rs':round(day_stock-market_day,4) if market_day is not None else None,'sector_rs':round(day_stock-day_sector,4) if sector else None}
    mode=out['load_mode'];hrs=(60,300,900) if mode=='FULL' else (300,900) if mode=='REDUCED' else (900,)
    for h in hrs:
        sr=_stock_return(ticks,now,h,current_price);mr=_history_return(mh,now,h) if mh else None;secr=_history_return(sh,now,h) if sh else None
        out['horizons'][str(h)]={'stock':round(sr,4) if sr is not None else None,'market':round(mr,4) if mr is not None else None,'sector':round(secr,4) if secr is not None else None,'market_rs':round(sr-mr,4) if sr is not None and mr is not None else None,'sector_rs':round(sr-secr,4) if sr is not None and secr is not None else None}
    # Research rank only. Capped and deliberately not connected to LIVE score/BUY.
    vals=[]
    for k,w in (('60',0.15),('300',0.35),('900',0.30)):
        r=out['horizons'].get(k) or {};a=r.get('market_rs');b=r.get('sector_rs')
        if a is not None:vals.append(w*_clamp(a,-5,5))
        if b is not None:vals.append(w*_clamp(b,-5,5))
    if out['day']['market_rs'] is not None:vals.append(0.10*_clamp(out['day']['market_rs'],-8,8))
    if out['day']['sector_rs'] is not None:vals.append(0.10*_clamp(out['day']['sector_rs'],-8,8))
    raw=sum(vals) if vals else None
    out['research_score']=round(max(-6.0,min(6.0,raw)),3) if raw is not None else None
    out['promotion_cap_if_ever_approved']=6.0
    out['promotion_gate']='HUMAN_APPROVAL_ONLY_AFTER_OOS; NEVER_AUTO_APPLY'
    return out

def status():
    return {'version':'MARKET_SECTOR_RS_SHADOW_V1','policy':POLICY,'auto_apply':False,'market_samples':{k:len(v) for k,v in _MARKET_HISTORY.items()},'sector_series':len(_SECTOR_HISTORY),'horizons_sec':list(HORIZONS),'live_score_effect':0,'buy_effect':False,'promotion_gate':'HUMAN_APPROVAL_ONLY_AFTER_OOS'}

def relative_strength_oos_audit(data_dir, horizon_sec=1800):
    """Replay-only test: does stronger market/sector-neutral RS predict better 30m outcomes?"""
    from pathlib import Path
    import json,gzip
    data_dir=Path(data_dir);rows=[]
    def readp(p):
        op=gzip.open if str(p).endswith('.gz') else open
        try:
            with op(p,'rt',encoding='utf-8') as f:
                for line in f:
                    try:
                        x=json.loads(line)
                        if x.get('rs_research_score') is not None and _num(x.get('price'))>0 and _num(x.get('ts'))>0:rows.append(x)
                    except:pass
        except:pass
    for p in data_dir.glob('replay_journal_*.jsonl'):readp(p)
    arch=data_dir/'archive'
    if arch.exists():
        for p in arch.glob('20??????/replay_journal.jsonl.gz'):readp(p)
    rows.sort(key=lambda x:_num(x.get('ts')));by=defaultdict(list)
    for x in rows:by[(str(x.get('day')),str(x.get('code')),str(x.get('venue'))) ].append(x)
    samples=[];last={}
    for x in rows:
        key=(str(x.get('day')),str(x.get('code')),str(x.get('venue')));t0=_num(x.get('ts'));p0=_num(x.get('price'))
        if t0-_num(last.get(key))<600:continue
        fut=[z for z in by[key] if horizon_sec-120<=_num(z.get('ts'))-t0<=horizon_sec+120 and _num(z.get('price'))>0]
        if not fut:continue
        z=min(fut,key=lambda q:abs((_num(q.get('ts'))-t0)-horizon_sec));ret=(_num(z.get('price'))/p0-1)*100
        samples.append({'rs':_num(x.get('rs_research_score')),'ret':ret});last[key]=t0
    n=len(samples);status_name='INSUFFICIENT_OOS' if n<100 else 'PRELIMINARY' if n<500 else 'EVALUABLE'
    if not samples:return {'version':'RS_SHADOW_OOS_V1','policy':POLICY,'auto_apply':False,'samples':0,'status':status_name,'min_samples':100,'strong_samples':500,'promotion_gate':'HUMAN_APPROVAL_ONLY; NEVER_AUTO_APPLY'}
    xs=sorted(samples,key=lambda r:r['rs'],reverse=True);k=max(1,math.ceil(n*.25));top=xs[:k];bottom=xs[-k:]
    def stats(a):
        rr=[z['ret'] for z in a]
        return {'n':len(rr),'avg_ret30':round(statistics.mean(rr),4),'median_ret30':round(statistics.median(rr),4),'positive_pct':round(sum(v>0 for v in rr)/len(rr)*100,2)}
    hi,lo=stats(top),stats(bottom)
    return {'version':'RS_SHADOW_OOS_V1','policy':POLICY,'auto_apply':False,'samples':n,'status':status_name,'min_samples':100,'strong_samples':500,'horizon_sec':horizon_sec,'top_quartile':hi,'bottom_quartile':lo,'top_minus_bottom_avg_ret30':round(hi['avg_ret30']-lo['avg_ret30'],4),'promotion_gate':'HUMAN_APPROVAL_ONLY_AFTER_EVALUABLE_OOS; NEVER_AUTO_APPLY'}
