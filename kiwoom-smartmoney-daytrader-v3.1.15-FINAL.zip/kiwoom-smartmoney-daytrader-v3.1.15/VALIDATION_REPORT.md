# v3.1.15 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.15

## 변경 범위
- 장중 강한종목 추천 캐시/점수/적용 로직
- 추천 API
- Dashboard 전달 필드
- 종목관리 UI
- 추천 회귀검사

## 안전 원칙
- 수동종목 MANUAL은 장중/일일 자동적용에서 삭제·교체하지 않음.
- 장중 자동적용은 기본 OFF.
- ON이어도 사용자가 장중 갱신 버튼을 눌렀을 때만 1회 적용.
- 60초 내 반복 갱신은 REST 재호출 없이 캐시 사용.
- 장중(평일 08:00~20:00 KST) 밖에서는 자동적용 차단.
- 추천은 감시대상 선정일 뿐 BUY 신호가 아님.
- 기존 확정 BUY/SELL 신뢰성 게이트 유지.

## 데이터 경로
v3.1.14 대비 `lib/kiwoomClient.js`, `lib/flowCollector.js`, `lib/realtimeStore.js`, `lib/marketSnapshot.js`는 수정하지 않았습니다.

## 장중 점수
시장 전체 신규후보는 기존 검증된 거래대금 상위 2회 + 외국인기관 순위 1회로 발굴합니다. 이미 감시 중인 후보는 기존 신호엔진이 계산한 PRE-SURGE/스마트머니/BUY·EARLY/완전성을 보너스로 합산합니다. 미감시 종목의 실시간 값을 추정하거나 조작하지 않습니다.

## 검증
배포 전 다음을 실행합니다.
- `node --check` 주요 JS
- `npm run check`
- `LOAD_TEST_SYMBOLS=20 LOAD_TEST_TICKS=100000 npm run check:load`
- SOURCE_MANIFEST SHA256 검증
- ZIP 무결성 검사

Next.js 전체 빌드는 배포 스크립트가 AWS에서 public npm registry를 사용해 성공한 경우에만 기존 컨테이너를 교체하도록 합니다.

## 20종목 합성부하 실제 실행
- 100,000 virtual ticks / 20 symbols
- 처리율: 60,423 ticks/s
- event-loop p95: 25.05 ms
- event-loop max: 28.44 ms
- errors: 0
- RSS: 116.5 MB
- final pending/active: 0/0
