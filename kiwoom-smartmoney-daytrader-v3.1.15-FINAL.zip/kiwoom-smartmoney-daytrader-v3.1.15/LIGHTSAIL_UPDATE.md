# Lightsail v3.1.15 FINAL 업데이트

GitHub 저장소 최상위에 `Dockerfile`, `kiwoom-smartmoney-daytrader-v3.1.15-FINAL.zip`, `update-lightsail-v3.1.15-FINAL.sh`를 올린 뒤 업데이트 스크립트를 실행합니다. 기존 `.env`와 `kiwoom-data` 볼륨은 유지합니다.
