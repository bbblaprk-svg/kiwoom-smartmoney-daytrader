from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent


def _i(name: str, default: int) -> int:
    try: return int(os.getenv(name, str(default)))
    except Exception: return default

def _f(name: str, default: float) -> float:
    try: return float(os.getenv(name, str(default)))
    except Exception: return default

def _b(name:str, default:bool=False)->bool:
    raw=os.getenv(name, '1' if default else '0').strip().lower()
    return raw in ('1','true','yes','y','on')

@dataclass(frozen=True, slots=True)
class Settings:
    version: str = 'NOVA-3.1.1-MASTER-GROUNDUP-9A'
    api_base: str = 'https://api.kiwoom.com'
    ws_url: str = 'wss://api.kiwoom.com:10000/api/dostk/websocket'
    app_key: str = os.getenv('KIWOOM_APP_KEY','').strip()
    secret: str = (os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
    access_token: str = os.getenv('APP_ACCESS_TOKEN','').strip()
    data_dir: Path = Path(os.getenv('NOVA_DATA_DIR', str(BASE/'data'/'nova30')))
    legacy_data_dir: Path = Path(os.getenv('NOVA_LEGACY_DATA_DIR', str(BASE/'data')))
    hot_target: int = _i('NOVA_HOT_TARGET', 50)
    hot_min: int = min(40,max(10,_i('NOVA_HOT_MIN', 20)))
    hot_max: int = min(90,max(20,_i('NOVA_HOT_MAX', 60)))
    max_candidates: int = min(1200,max(200,_i('NOVA_MAX_CANDIDATES', 1200)))
    fresh_ms: int = _i('NOVA_FRESH_MS', 3500)
    display_fresh_ms: int = _i('NOVA_DISPLAY_FRESH_MS', 8000)
    trade_queue_per_shard: int = min(1024,max(128,_i('NOVA_TRADE_QUEUE_PER_SHARD', 1024)))
    trade_shards: int = min(8,max(1,_i('NOVA_TRADE_SHARDS', 4)))
    score_interval_ms: int = _i('NOVA_SCORE_INTERVAL_MS', 100)
    ui_delta_ms: int = _i('NOVA_UI_DELTA_MS', 250)
    journal_noncritical_max: int = min(4096,max(256,_i('NOVA_JOURNAL_NONCRITICAL_MAX', 4096)))
    journal_important_max: int = min(1024,max(128,_i('NOVA_JOURNAL_IMPORTANT_MAX', 1024)))
    journal_critical_max: int = min(512,max(64,_i('NOVA_JOURNAL_CRITICAL_MAX', 256)))
    hard_stall_sec: float = _f('NOVA_HARD_STALL_SEC', 15.0)
    hard_stall_grace_sec: float = _f('NOVA_HARD_STALL_GRACE_SEC', 30.0)
    wal_hard_stall_sec: float = _f('NOVA_WAL_HARD_STALL_SEC', 8.0)
    event_wal_hard_stall_sec: float = _f('NOVA_EVENT_WAL_HARD_STALL_SEC', 8.0)
    rest_pace_sec: float = max(0.205,_f('NOVA_REST_PACE_SEC', 0.225))
    rest_max_inflight: int = min(4,max(1,_i('NOVA_REST_MAX_INFLIGHT', 4)))
    discovery_sec: int = _i('NOVA_DISCOVERY_SEC', 8)
    discovery_source_ttl_sec: int = _i('NOVA_DISCOVERY_SOURCE_TTL_SEC', 180)
    ws_reg_budget: int = _i('NOVA_WS_REG_BUDGET', 120)
    # Keep a safety margin below Kiwoom's 200-stock realtime session ceiling.
    # A code can be registered on both KRX and NXT during the dual venue window.
    ws_session_item_cap: int = min(180,max(2,_i('NOVA_WS_SESSION_ITEM_CAP', 180)))
    ws_trade_per_venue: int = _i('NOVA_WS_TRADE_PER_VENUE', 60)
    ws_program_cap: int = _i('NOVA_WS_PROGRAM_CAP', 15)
    ws_orderbook_cap: int = _i('NOVA_WS_ORDERBOOK_CAP', 10)
    rss_soft_mb: int = min(340,max(160,_i('NOVA_RSS_SOFT_MB', 320)))
    rss_hard_mb: int = min(400,max(220,_i('NOVA_RSS_HARD_MB', 400)))
    offline: bool = _b('NOVA_OFFLINE', False)
    candidate_mode: bool = _b('NOVA_CANDIDATE_MODE', False)
    warm_sec: int = _i('NOVA_WARM_SEC', 60)
    candidate_ttl_sec: int = _i('NOVA_CANDIDATE_TTL_SEC', 900)
    performance_watch_cap: int = _i('NOVA_PERFORMANCE_WATCH_CAP', 40)

SETTINGS = Settings()


def effective_ws_code_budget()->int:
    # Reserve against the worst-case dual-venue window so a later session transition cannot
    # strand more pinned signals than the socket can legally keep subscribed.
    return max(1,min(SETTINGS.ws_reg_budget,SETTINGS.ws_session_item_cap//2))
