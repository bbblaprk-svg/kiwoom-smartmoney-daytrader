from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from pulse_edge.core.models import RawEvent, TruthStatus
from pulse_edge.feed.continuity import ContinuityGuard
from pulse_edge.feed.normalize import normalize
from pulse_edge.feed.state import FeedState
from pulse_edge.feed.truth import FeedTruth
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.session.router import SessionRouter


class FeedService:
    def __init__(
        self,
        state: FeedState,
        truth: FeedTruth,
        features: FeatureEngine,
        session_router: SessionRouter,
        *,
        timestamp_regression_tolerance_sec: float = 1.0,
    ) -> None:
        self.state = state
        self.truth = truth
        self.features = features
        self.session_router = session_router
        self.continuity = ContinuityGuard(timestamp_regression_tolerance_sec)
        self.total_payloads = 0
        self.total_normalized = 0
        self.last_payload_at: datetime | None = None
        self.last_trusted_market_event_at: datetime | None = None
        self.continuity_reasons: list[str] = []
        self.session_rejects = 0
        self.session_reasons: list[str] = []

    async def ingest(self, payload: dict) -> None:
        raw = RawEvent(receive_time=datetime.now(timezone.utc), payload=payload)
        await self.ingest_raw(raw)

    async def ingest_raw(self, raw: RawEvent) -> None:
        self.state.add_raw(raw)
        self.total_payloads += 1
        self.last_payload_at = raw.receive_time
        for index, event in enumerate(normalize(raw)):
            if index and index % 64 == 0:
                await asyncio.sleep(0)
            self.total_normalized += 1
            result = self.truth.validate(event)
            if result.status != TruthStatus.LIVE:
                continue

            # Session eligibility is checked before continuity state is mutated.
            # An ineligible pre-open KRX trade therefore cannot poison later
            # cumulative-volume or timestamp continuity for the real session.
            if event.real_type == "0s":
                self.session_router.observe_market_time(event)
            elif not self.session_router.event_allowed(event):
                self.session_rejects += 1
                reason = f"session_block:{event.venue.value}:{event.real_type}:{self.session_router.phase_at(event.event_time or event.receive_time).value}"
                self.session_reasons = (self.session_reasons + [reason])[-20:]
                continue

            final_status, reasons = self.continuity.check(event, result.status)
            if reasons:
                self.continuity_reasons = reasons[-20:]
            if final_status != TruthStatus.LIVE:
                continue
            if self.state.apply(event, final_status):
                if event.real_type in {"0B", "0D"}:
                    self.last_trusted_market_event_at = event.receive_time
                self.features.ingest(event)
