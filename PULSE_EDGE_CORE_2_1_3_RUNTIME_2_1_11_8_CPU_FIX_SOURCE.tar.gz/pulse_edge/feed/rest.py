from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable
import httpx


@dataclass
class RestPage:
    body: dict[str, Any]
    cont_yn: str | None = None
    next_key: str | None = None
    response_api_id: str | None = None


class KiwoomRestClient:
    def __init__(self, base_url: str, token_getter: Callable[[], Awaitable[str]]) -> None:
        self.base_url = base_url.rstrip('/')
        self.token_getter = token_getter
        self._client: httpx.AsyncClient | None = None

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def post(self, api_id: str, path: str, body: dict[str, Any], cont_yn: str | None = None, next_key: str | None = None) -> RestPage:
        token = await self.token_getter()
        headers = {
            'authorization': f'Bearer {token}',
            'api-id': api_id,
            'Content-Type': 'application/json;charset=UTF-8',
        }
        if cont_yn:
            headers['cont-yn'] = cont_yn
        if next_key:
            headers['next-key'] = next_key
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=15.0, limits=httpx.Limits(
                max_connections=8, max_keepalive_connections=4, keepalive_expiry=30.0))
        resp = await self._client.post(f'{self.base_url}{path}', headers=headers, json=body)
        resp.raise_for_status()
        payload = resp.json()
        if int(payload.get('return_code', 0) or 0) not in (0, 20):
            raise RuntimeError(f"Kiwoom {api_id} error: {payload.get('return_msg', 'unknown')}")
        return RestPage(payload, resp.headers.get('cont-yn'), resp.headers.get('next-key'), resp.headers.get('api-id'))
