from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.patterns.engine import OrbRetestEngine, SqueezeReleaseEngine, VwapReclaimEngine
from pulse_edge.patterns.models import OrbFrame, OrbStage, SqueezeFrame, SqueezeStage, VwapReclaimFrame, VwapReclaimStage

KST = ZoneInfo('Asia/Seoul')


class PatternCompletionService:
    def __init__(self, features: FeatureEngine, max_rows: int = 100) -> None:
        self.features = features
        self.orb_engine = OrbRetestEngine()
        self.squeeze_engine = SqueezeReleaseEngine()
        self.reclaim_engine = VwapReclaimEngine()
        self.max_rows = max(10, int(max_rows))
        self.orb_frames: dict[tuple[Venue,str], OrbFrame] = {}
        self.squeeze_frames: dict[tuple[Venue,str], SqueezeFrame] = {}
        self.reclaim_frames: dict[tuple[Venue,str], VwapReclaimFrame] = {}
        self._opening_ranges: dict[tuple[str,Venue,str], tuple[float,float]] = {}
        self._orb_persist: dict[tuple[Venue,str], int] = {}
        self._squeeze_persist: dict[tuple[Venue,str], int] = {}
        self._reclaim_persist: dict[tuple[Venue,str], int] = {}
        self._session_day: str | None = None
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 80, asof: datetime | None = None) -> None:
        for _ in self._refresh_steps(limit, asof):
            pass

    async def refresh_async(self, limit: int = 80, asof: datetime | None = None) -> None:
        for _ in self._refresh_steps(limit, asof):
            # A symbol is one bounded work unit. Buffered market data and HTTP
            # requests must get a turn even while the pattern sweep is busy.
            await asyncio.sleep(0)

    @staticmethod
    def _persist_frame(frame, count, qualifies, watch, confirmed, threshold):
        # Persistence only changes the final stage and exposed counter. Early
        # DATA_WAIT/NO_PATTERN returns retain their original default counter.
        if 'persistence_count' in frame.model_fields_set:
            frame.persistence_count = count
        if qualifies:
            frame.stage = confirmed if count >= threshold else watch
        return frame

    def _refresh_steps(self, limit: int, asof: datetime | None):
        now = asof or datetime.now(timezone.utc)
        day = now.astimezone(KST).date().isoformat()
        same_day = self._session_day == day
        opening = dict(self._opening_ranges) if same_day else {}
        orb_counts = dict(self._orb_persist) if same_day else {}
        sq_counts = dict(self._squeeze_persist) if same_day else {}
        rc_counts = dict(self._reclaim_persist) if same_day else {}
        orb_frames = dict(self.orb_frames) if same_day else {}
        sq_frames = dict(self.squeeze_frames) if same_day else {}
        rc_frames = dict(self.reclaim_frames) if same_day else {}
        ranked_keys = sorted(self.features.frames, key=lambda k: self.features.frames[k].asof, reverse=True)
        # Capture the same input the former synchronous sweep saw. No await
        # occurs until frame references and retained point lists are captured.
        snapshots = []
        for key in ranked_keys[:max(20, min(int(limit), 200))]:
            feature = self.features.frames.get(key)
            points = self.features.trades.get(key, [])
            if feature is not None and points and (now - points[-1].ts).total_seconds() <= 7.0:
                snapshots.append((key, feature, list(points)))
        keep = set()
        for key, feature, points in snapshots:
            keep.add(key)
            if feature.venue == Venue.KRX:
                self._update_opening_range(day, key, points, store=opening)
            op = opening.get((day, key[0], key[1]))
            orb = self.orb_engine.evaluate(feature, points, opening_high=op[0] if op else None,
                opening_low=op[1] if op else None, persistence_count=orb_counts.get(key, 0), asof=now)
            qualifies = orb.stage in {OrbStage.ORB_RETEST_SHADOW, OrbStage.ORB_RETEST_CONFIRMED_SHADOW}
            orb_counts[key] = orb_counts.get(key, 0) + 1 if qualifies else 0
            orb = self._persist_frame(orb, orb_counts[key], qualifies, OrbStage.ORB_RETEST_SHADOW,
                OrbStage.ORB_RETEST_CONFIRMED_SHADOW, 2)
            if orb.stage != OrbStage.DATA_WAIT:
                orb_frames[key] = orb
            else:
                orb_frames.pop(key, None)

            sq = self.squeeze_engine.evaluate(feature, points, persistence_count=sq_counts.get(key, 0), asof=now)
            qualifies = sq.stage in {SqueezeStage.RELEASE_WATCH, SqueezeStage.SQUEEZE_RELEASE_SHADOW}
            sq_counts[key] = sq_counts.get(key, 0) + 1 if qualifies else 0
            sq = self._persist_frame(sq, sq_counts[key], qualifies, SqueezeStage.RELEASE_WATCH,
                SqueezeStage.SQUEEZE_RELEASE_SHADOW, 2)
            if sq.stage != SqueezeStage.DATA_WAIT:
                sq_frames[key] = sq
            else:
                sq_frames.pop(key, None)

            rc = self.reclaim_engine.evaluate(feature, points, persistence_count=rc_counts.get(key, 0), asof=now)
            qualifies = rc.stage in {VwapReclaimStage.RECLAIM_WATCH, VwapReclaimStage.VWAP_RECLAIM_SHADOW}
            rc_counts[key] = rc_counts.get(key, 0) + 1 if qualifies else 0
            rc = self._persist_frame(rc, rc_counts[key], qualifies, VwapReclaimStage.RECLAIM_WATCH,
                VwapReclaimStage.VWAP_RECLAIM_SHADOW, 3)
            if rc.stage != VwapReclaimStage.DATA_WAIT:
                rc_frames[key] = rc
            else:
                rc_frames.pop(key, None)
            yield None

        for store, persist in ((orb_frames, orb_counts), (sq_frames, sq_counts), (rc_frames, rc_counts)):
            for key in list(store):
                if key not in keep:
                    store.pop(key, None)
                    persist.pop(key, None)
        # Publish a complete generation together; cancellation or an exception
        # leaves the previous successful generation intact.
        self._session_day = day
        self._opening_ranges = opening
        self._orb_persist, self._squeeze_persist, self._reclaim_persist = orb_counts, sq_counts, rc_counts
        self.orb_frames, self.squeeze_frames, self.reclaim_frames = orb_frames, sq_frames, rc_frames
        self.last_refresh_at = now
        self.last_error = None

    def _update_opening_range(self, day: str, key: tuple[Venue,str], points, *, store=None) -> None:
        store = self._opening_ranges if store is None else store
        start=datetime.fromisoformat(day).replace(hour=9,tzinfo=KST)
        end=start.replace(minute=10)
        selected=[p for p in points if start<=p.ts<end]
        if not selected:
            return
        high=max(p.price for p in selected); low=min(p.price for p in selected)
        cache_key=(day,key[0],key[1])
        prev=store.get(cache_key)
        if prev:
            high=max(high,prev[0]); low=min(low,prev[1])
        store[cache_key]=(high,low)

    def top_orb(self, limit:int=10)->list[OrbFrame]:
        return self._sorted_orb(list(self.orb_frames.values()))[:max(1,min(int(limit),100))]
    def top_squeeze(self, limit:int=10)->list[SqueezeFrame]:
        return self._sorted_squeeze(list(self.squeeze_frames.values()))[:max(1,min(int(limit),100))]
    def top_reclaim(self, limit:int=10)->list[VwapReclaimFrame]:
        return self._sorted_reclaim(list(self.reclaim_frames.values()))[:max(1,min(int(limit),100))]

    @staticmethod
    def _sorted_orb(rows):
        order={OrbStage.ORB_RETEST_CONFIRMED_SHADOW:7,OrbStage.ORB_RETEST_SHADOW:6,OrbStage.ORB_BREAKOUT_WATCH:5,OrbStage.OPENING_RANGE_BUILDING:4,OrbStage.NO_PATTERN:3,OrbStage.ORB_FAIL_SHADOW:2,OrbStage.OVERHEAT_RISK_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.orb_score_100),reverse=True)
    @staticmethod
    def _sorted_squeeze(rows):
        order={SqueezeStage.SQUEEZE_RELEASE_SHADOW:6,SqueezeStage.RELEASE_WATCH:5,SqueezeStage.SQUEEZE_WATCH:4,SqueezeStage.NO_PATTERN:3,SqueezeStage.OVEREXTENDED_RISK_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.squeeze_score_100),reverse=True)
    @staticmethod
    def _sorted_reclaim(rows):
        order={VwapReclaimStage.VWAP_RECLAIM_SHADOW:6,VwapReclaimStage.RECLAIM_WATCH:5,VwapReclaimStage.BELOW_VWAP_WATCH:4,VwapReclaimStage.NO_PATTERN:3,VwapReclaimStage.RECLAIM_FAIL_SHADOW:1}
        return sorted(rows,key=lambda x:(order.get(x.stage,0),x.reclaim_score_100),reverse=True)
