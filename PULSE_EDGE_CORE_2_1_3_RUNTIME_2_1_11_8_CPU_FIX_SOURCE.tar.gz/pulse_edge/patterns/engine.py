from __future__ import annotations

from datetime import datetime, timedelta
from statistics import mean
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.features.models import FeatureFrame, TradePoint
from pulse_edge.patterns.models import (
    OrbFrame, OrbStage, SqueezeFrame, SqueezeStage, VwapReclaimFrame, VwapReclaimStage,
)

KST = ZoneInfo('Asia/Seoul')


def _pct(a: float, b: float) -> float:
    if b <= 0:
        return 0.0
    return (a / b - 1.0) * 100.0


def _range_pct(points: list[TradePoint]) -> float | None:
    if not points:
        return None
    lo = min(p.price for p in points)
    hi = max(p.price for p in points)
    if lo <= 0:
        return None
    return (hi / lo - 1.0) * 100.0


def _volume_rate(points: list[TradePoint]) -> float | None:
    if len(points) < 2:
        return None
    sec = max((points[-1].ts - points[0].ts).total_seconds(), 1.0)
    return sum(max(0.0, p.volume) for p in points) / sec


class OrbRetestEngine:
    def evaluate(
        self,
        feature: FeatureFrame,
        points: list[TradePoint],
        *,
        opening_high: float | None,
        opening_low: float | None,
        persistence_count: int,
        asof: datetime,
    ) -> OrbFrame:
        if feature.venue != Venue.KRX or feature.price is None:
            return OrbFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=OrbStage.DATA_WAIT)
        local = asof.astimezone(KST)
        minutes = local.hour * 60 + local.minute
        if minutes < 9 * 60 + 10:
            return OrbFrame(
                venue=feature.venue, symbol=feature.symbol, asof=asof, stage=OrbStage.OPENING_RANGE_BUILDING,
                price=feature.price, opening_high=opening_high, opening_low=opening_low,
            )
        if minutes >= 10 * 60 + 5 or opening_high is None or opening_low is None or opening_low <= 0:
            return OrbFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=OrbStage.DATA_WAIT, price=feature.price)

        range_pct = _pct(opening_high, opening_low)
        opening_end_time = datetime(2000,1,1,9,10).time()
        after_open = [p for p in points if p.ts.astimezone(KST).time() >= opening_end_time]
        if not after_open:
            return OrbFrame(
                venue=feature.venue, symbol=feature.symbol, asof=asof, stage=OrbStage.NO_PATTERN,
                price=feature.price, opening_high=opening_high, opening_low=opening_low, opening_range_pct=range_pct,
            )
        broke = any(p.price >= opening_high * 1.001 for p in after_open)
        current = feature.price
        breakout_pct = _pct(current, opening_high)
        recent_cutoff = asof - timedelta(minutes=4)
        recent = [p for p in after_open if p.ts >= recent_cutoff]
        recent_low = min((p.price for p in recent), default=current)
        retest_distance = _pct(recent_low, opening_high)
        touched_retest = -0.6 <= retest_distance <= 0.45
        holds_structure = recent_low >= opening_high * 0.994 and current >= opening_high
        vwap_ok = feature.session_vwap is not None and current >= feature.session_vwap
        activity_ok = feature.return_1m_pct is not None and feature.return_1m_pct > 0 and feature.money_acceleration is not None and feature.money_acceleration > 0
        rs_ok = feature.rs_acceleration is None or feature.rs_acceleration >= 0
        overheat = breakout_pct > 3.0 or (feature.vwap_distance_pct is not None and feature.vwap_distance_pct > 3.5)
        fail = broke and (recent_low < opening_high * 0.988 or current < opening_high * 0.992)

        score = 0.0
        score += 25.0 if broke else 0.0
        score += 25.0 if touched_retest and holds_structure else 0.0
        score += 15.0 if vwap_ok else 0.0
        score += 20.0 if activity_ok else 0.0
        score += 15.0 if rs_ok else 0.0

        if fail:
            stage = OrbStage.ORB_FAIL_SHADOW
        elif overheat:
            stage = OrbStage.OVERHEAT_RISK_SHADOW
        elif broke and touched_retest and holds_structure and vwap_ok and activity_ok:
            stage = OrbStage.ORB_RETEST_CONFIRMED_SHADOW if persistence_count >= 2 else OrbStage.ORB_RETEST_SHADOW
        elif broke:
            stage = OrbStage.ORB_BREAKOUT_WATCH
        else:
            stage = OrbStage.NO_PATTERN
        return OrbFrame(
            venue=feature.venue, symbol=feature.symbol, asof=asof, stage=stage, price=current,
            opening_high=opening_high, opening_low=opening_low, opening_range_pct=round(range_pct,4),
            breakout_pct=round(breakout_pct,4), retest_distance_pct=round(retest_distance,4),
            orb_score_100=score, persistence_count=persistence_count, official_signal_enabled=False,
        )


class SqueezeReleaseEngine:
    def evaluate(self, feature: FeatureFrame, points: list[TradePoint], *, persistence_count: int, asof: datetime) -> SqueezeFrame:
        if feature.price is None:
            return SqueezeFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=SqueezeStage.DATA_WAIT)
        cutoff = asof - timedelta(minutes=20)
        rows = [p for p in points if p.ts >= cutoff]
        if len(rows) < 8 or rows[-1].ts < asof - timedelta(seconds=20):
            return SqueezeFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=SqueezeStage.DATA_WAIT, price=feature.price)
        release_cut = asof - timedelta(minutes=2)
        compression = [p for p in rows if p.ts <= release_cut]
        release = [p for p in rows if p.ts > release_cut]
        if len(compression) < 6 or not release:
            return SqueezeFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=SqueezeStage.DATA_WAIT, price=feature.price)
        mid = len(compression) // 2
        older, newer = compression[:mid], compression[mid:]
        width = _range_pct(newer) or 0.0
        old_width = _range_pct(older)
        range_contraction = None if old_width is None or old_width <= 0 else max(-100.0, min(100.0, (1.0 - width / old_width) * 100.0))
        vr_old = _volume_rate(older)
        vr_new = _volume_rate(newer)
        vol_contraction = None if vr_old is None or vr_old <= 0 or vr_new is None else (1.0 - vr_new / vr_old) * 100.0
        high = max(p.price for p in newer)
        low = min(p.price for p in newer)
        breakout_pct = _pct(feature.price, high)
        compressed = width <= 1.8 and (range_contraction is None or range_contraction >= 10.0)
        volume_quiet = vol_contraction is not None and vol_contraction >= 15.0
        breakout = feature.price >= high * 1.001
        activity = feature.return_1m_pct is not None and feature.return_1m_pct > 0 and feature.money_acceleration is not None and feature.money_acceleration > 0
        vwap_ok = feature.session_vwap is None or feature.price >= feature.session_vwap
        overheat = breakout_pct > 2.5 or (feature.vwap_distance_pct is not None and feature.vwap_distance_pct > 3.5)

        score = 0.0
        score += 25.0 if compressed else 0.0
        score += 15.0 if volume_quiet else 0.0
        score += 25.0 if breakout else 0.0
        score += 20.0 if activity else 0.0
        score += 15.0 if vwap_ok else 0.0
        if overheat:
            stage = SqueezeStage.OVEREXTENDED_RISK_SHADOW
        elif compressed and volume_quiet and breakout and activity and vwap_ok:
            stage = SqueezeStage.SQUEEZE_RELEASE_SHADOW if persistence_count >= 2 else SqueezeStage.RELEASE_WATCH
        elif compressed and volume_quiet:
            stage = SqueezeStage.SQUEEZE_WATCH
        else:
            stage = SqueezeStage.NO_PATTERN
        return SqueezeFrame(
            venue=feature.venue, symbol=feature.symbol, asof=asof, stage=stage, price=feature.price,
            compression_high=high, compression_low=low, compression_width_pct=round(width,4),
            range_contraction_pct=None if range_contraction is None else round(range_contraction,4),
            volume_rate_contraction_pct=None if vol_contraction is None else round(vol_contraction,4),
            breakout_pct=round(breakout_pct,4), squeeze_score_100=score,
            persistence_count=persistence_count, official_signal_enabled=False,
        )


class VwapReclaimEngine:
    def evaluate(self, feature: FeatureFrame, points: list[TradePoint], *, persistence_count: int, asof: datetime) -> VwapReclaimFrame:
        vwap = feature.session_vwap
        if feature.price is None or vwap is None or vwap <= 0:
            return VwapReclaimFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=VwapReclaimStage.DATA_WAIT, price=feature.price)
        cutoff = asof - timedelta(minutes=10)
        rows = [p for p in points if p.ts >= cutoff]
        if len(rows) < 4:
            return VwapReclaimFrame(venue=feature.venue, symbol=feature.symbol, asof=asof, stage=VwapReclaimStage.DATA_WAIT, price=feature.price, session_vwap=vwap)
        below = [p for p in rows[:-1] if p.price < vwap * 0.9985]
        if not below:
            return VwapReclaimFrame(
                venue=feature.venue, symbol=feature.symbol, asof=asof, stage=VwapReclaimStage.NO_PATTERN,
                price=feature.price, session_vwap=vwap, current_above_vwap_pct=round(_pct(feature.price,vwap),4),
            )
        min_price = min(p.price for p in below)
        min_below = _pct(min_price, vwap)
        above = _pct(feature.price, vwap)
        failed_breakdown = -2.5 <= min_below <= -0.15
        reclaimed = feature.price >= vwap
        activity = feature.return_1m_pct is not None and feature.return_1m_pct > 0 and feature.money_acceleration is not None and feature.money_acceleration > 0
        not_chasing = above <= 2.0
        score = 0.0
        score += 25.0 if below else 0.0
        score += 20.0 if failed_breakdown else 0.0
        score += 25.0 if reclaimed else 0.0
        score += 20.0 if activity else 0.0
        score += 10.0 if not_chasing else 0.0
        if not failed_breakdown:
            stage = VwapReclaimStage.RECLAIM_FAIL_SHADOW
        elif reclaimed and activity and not_chasing:
            stage = VwapReclaimStage.VWAP_RECLAIM_SHADOW if persistence_count >= 3 else VwapReclaimStage.RECLAIM_WATCH
        elif feature.price < vwap:
            stage = VwapReclaimStage.BELOW_VWAP_WATCH
        else:
            stage = VwapReclaimStage.NO_PATTERN
        return VwapReclaimFrame(
            venue=feature.venue, symbol=feature.symbol, asof=asof, stage=stage, price=feature.price,
            session_vwap=vwap, min_below_vwap_pct=round(min_below,4), current_above_vwap_pct=round(above,4),
            reclaim_score_100=score, persistence_count=persistence_count, official_signal_enabled=False,
        )
