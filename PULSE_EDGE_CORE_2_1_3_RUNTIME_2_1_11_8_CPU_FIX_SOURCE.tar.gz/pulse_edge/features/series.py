"""Bounded arrival-order series with indexed additive time-window queries.

No event is sampled or combined. The deque-compatible surface is kept for
strategy readers. A timestamp regression uses the exact predicate fallback.
"""
from __future__ import annotations
from array import array
from bisect import bisect_left, bisect_right
from itertools import islice


def trade_values(p):
    return (p.price * p.volume, p.volume)


def trade_flow_values(p):
    return (max(0.0, p.buy_exec_volume or 0.0),
            max(0.0, p.sell_exec_volume or 0.0),
            p.net_buy_exec_volume or 0.0, abs(p.net_buy_exec_volume or 0.0))


def quote_flow_values(p):
    return (p.ofi_increment or 0.0, abs(p.ofi_increment or 0.0))


class IndexedSeries:
    def __init__(self, maxlen, values=None, width=0):
        self.maxlen = max(1, int(maxlen))
        self._values = values
        self._points = []
        self._times = []
        self._prefix = [array('d', [0.0]) for _ in range(width)]
        self._head = 0
        self._disorders = 0

    def __len__(self):
        return len(self._points) - self._head

    def __iter__(self):
        return islice(self._points, self._head, None)

    def __reversed__(self):
        return islice(reversed(self._points), len(self))

    def __getitem__(self, index):
        if isinstance(index, slice):
            return self._points[self._head:][index]
        n = len(self)
        if index < 0:
            index += n
        if not 0 <= index < n:
            raise IndexError('series index out of range')
        return self._points[self._head + index]

    def append(self, point):
        if self and point.ts < self._times[-1]:
            self._disorders += 1
        self._points.append(point)
        self._times.append(point.ts)
        if self._values:
            for prefix, value in zip(self._prefix, self._values(point)):
                prefix.append(prefix[-1] + value)
        if len(self) > self.maxlen:
            self.popleft()

    def popleft(self):
        if not self:
            raise IndexError('pop from an empty series')
        i = self._head
        point = self._points[i]
        if i + 1 < len(self._times) and self._times[i + 1] < self._times[i]:
            self._disorders -= 1
        self._points[i] = None  # release expired objects immediately
        self._head += 1
        if self._head >= 2048 and self._head * 2 >= len(self._points):
            self._compact()
        return point

    def _compact(self):
        head = self._head
        self._points = self._points[head:]
        self._times = self._times[head:]
        # Retain accumulated values; rebasing is unnecessary for bounded
        # differences and would introduce a Python loop through every row.
        self._prefix = [p[head:] for p in self._prefix]
        self._head = 0

    def bounds(self, older, newer):
        lo = bisect_right(self._times, older, self._head)
        hi = bisect_right(self._times, newer, lo)
        return lo, hi

    def window(self, older, newer):
        if self._disorders:
            return [p for p in self if older < p.ts <= newer]
        lo, hi = self.bounds(older, newer)
        return self._points[lo:hi]

    def since(self, cutoff, until=None):
        """Arrival-order selection: cutoff <= ts and (until is None or ts < until)."""
        if self._disorders:
            return [p for p in self if p.ts >= cutoff and (until is None or p.ts < until)]
        lo = bisect_left(self._times, cutoff, self._head)
        hi = len(self._times) if until is None else bisect_left(self._times, until, lo)
        return self._points[lo:hi]

    def totals(self, older, newer):
        if self._disorders:
            points = self.window(older, newer)
            values = [self._values(p) for p in points]
            return len(points), tuple(sum(v[i] for v in values) for i in range(len(self._prefix)))
        lo, hi = self.bounds(older, newer)
        return hi - lo, tuple(p[hi] - p[lo] for p in self._prefix)

    def at_or_before(self, cutoff):
        if self._disorders:
            return next((p for p in reversed(self) if p.ts <= cutoff), None)
        i = bisect_right(self._times, cutoff, self._head) - 1
        return self._points[i] if i >= self._head else None
