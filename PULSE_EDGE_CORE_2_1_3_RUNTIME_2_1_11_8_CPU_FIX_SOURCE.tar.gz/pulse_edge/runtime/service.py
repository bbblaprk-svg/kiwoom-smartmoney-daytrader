from __future__ import annotations

import os
import resource
import shutil
import time
from datetime import datetime, timezone
from typing import Any
from pathlib import Path

from pulse_edge.runtime.engine import RuntimeTruthEngine
from pulse_edge.runtime.models import RuntimeFrame, RuntimeMetrics


class SystemProbe:
    def __init__(self, disk_path: str = "/") -> None:
        self.disk_path = self._existing_path(disk_path)
        self._cpu_prev: tuple[float, float] | None = None

    @staticmethod
    def _existing_path(path: str) -> str:
        existing_path = os.path.abspath(path)
        while not os.path.exists(existing_path):
            parent = os.path.dirname(existing_path)
            if not parent or parent == existing_path:
                return "/"
            existing_path = parent
        return existing_path

    @staticmethod
    def _process_cpu_seconds() -> float:
        r = resource.getrusage(resource.RUSAGE_SELF)
        return float(r.ru_utime + r.ru_stime)

    def cpu_pct(self) -> float | None:
        try:
            now = time.monotonic()
            used = self._process_cpu_seconds()
            prev = self._cpu_prev
            self._cpu_prev = (now, used)
            if prev is None:
                return None
            wall = now - prev[0]
            if wall <= 0:
                return None
            return max(0.0, 100.0 * (used - prev[1]) / wall)
        except Exception:
            return None

    @staticmethod
    def process_rss_mb() -> float | None:
        try:
            # Linux: report current resident set, not ru_maxrss high-water mark.
            # This keeps the operator RUNTIME card truthful after a transient spike.
            if os.path.exists("/proc/self/statm"):
                parts = open("/proc/self/statm", "r", encoding="utf-8").read().split()
                if len(parts) >= 2:
                    resident_pages = int(parts[1])
                    return resident_pages * int(os.sysconf("SC_PAGE_SIZE")) / (1024.0 ** 2)
            rss = float(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            if os.uname().sysname == "Darwin":
                return rss / (1024.0 * 1024.0)
            return rss / 1024.0
        except Exception:
            return None

    @classmethod
    def memory_pct(cls) -> float | None:
        try:
            rss_mb = cls.process_rss_mb()
            pages = int(os.sysconf("SC_PHYS_PAGES"))
            page_size = int(os.sysconf("SC_PAGE_SIZE"))
            total_mb = pages * page_size / (1024.0 ** 2)
            # Docker may have a much smaller cgroup limit than its host RAM.
            for filename in ('/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory/memory.limit_in_bytes'):
                try:
                    value = Path(filename).read_text().strip()
                    if value != 'max' and int(value) > 0:
                        total_mb = min(total_mb, int(value) / (1024.0 ** 2))
                except (OSError, ValueError):
                    pass
            if rss_mb is None or total_mb <= 0:
                return None
            return max(0.0, min(100.0, 100.0 * rss_mb / total_mb))
        except Exception:
            return None

    def disk(self) -> tuple[float | None, float | None]:
        try:
            d = shutil.disk_usage(self.disk_path)
            pct = 100.0 * d.used / d.total if d.total else None
            free_gb = d.free / (1024.0 ** 3)
            return pct, free_gb
        except Exception:
            return None, None


class RuntimeTruthService:
    def __init__(
        self,
        *,
        feed_enabled: bool,
        ws: Any,
        feed_service: Any,
        truth: Any,
        state: Any,
        engine: RuntimeTruthEngine,
        disk_path: str = "/",
        probe: SystemProbe | None = None,
    ) -> None:
        self.feed_enabled = bool(feed_enabled)
        self.ws = ws
        self.feed_service = feed_service
        self.truth = truth
        self.state = state
        self.engine = engine
        self.probe = probe or SystemProbe(disk_path)
        self.frame: RuntimeFrame | None = None
        self.last_error: str | None = None
        self._loop_lag_sec = 0.0
        self._previous = {
            "LIVE": 0,
            "PARTIAL": 0,
            "STALE": 0,
            "INVALID": 0,
            "continuity": 0,
            "session": 0,
        }

    def observe_loop_lag(self, value: float) -> None:
        self._loop_lag_sec = max(0.0, float(value))

    def _delta(self, name: str, current: int) -> int:
        previous = int(self._previous.get(name, 0))
        self._previous[name] = int(current)
        return max(0, int(current) - previous)

    def refresh(self, now: datetime | None = None) -> RuntimeFrame:
        now = now or datetime.now(timezone.utc)
        disk_pct, disk_free = self.probe.disk()
        last_payload = getattr(self.feed_service, "last_payload_at", None)
        last_payload_age = None
        if last_payload is not None:
            last_payload_age = max(0.0, (now - last_payload).total_seconds())
        counters = getattr(self.truth, "counters", {}) or {}
        ws = self.ws
        metrics = RuntimeMetrics(
            asof=now,
            cpu_pct=self.probe.cpu_pct(),
            memory_pct=self.probe.memory_pct(),
            process_rss_mb=self.probe.process_rss_mb(),
            disk_pct=disk_pct,
            disk_free_gb=disk_free,
            event_loop_lag_sec=self._loop_lag_sec,
            feed_enabled=self.feed_enabled,
            ws_connected=bool(ws and getattr(ws, "connected", False)),
            ws_last_error=getattr(ws, "last_error", None) if ws else None,
            ws_connection_count=int(getattr(ws, "connection_count", 0) if ws else 0),
            ws_reconnect_count=int(getattr(ws, "reconnect_count", 0) if ws else 0),
            last_payload_age_sec=last_payload_age,
            truth_live_delta=self._delta("LIVE", int(counters.get("LIVE", 0))),
            truth_partial_delta=self._delta("PARTIAL", int(counters.get("PARTIAL", 0))),
            truth_stale_delta=self._delta("STALE", int(counters.get("STALE", 0))),
            truth_invalid_delta=self._delta("INVALID", int(counters.get("INVALID", 0))),
            continuity_reject_delta=self._delta("continuity", int(getattr(self.feed_service.continuity, "rejects", 0))),
            session_reject_delta=self._delta("session", int(getattr(self.feed_service, "session_rejects", 0))),
            total_payloads=int(getattr(self.feed_service, "total_payloads", 0)),
            dynamic_subscription_count=len(getattr(ws, "dynamic_stock_items", []) if ws else []),
            event_subscription_count=len(getattr(ws, "event_stock_items", []) if ws else []),
            background_subscription_count=len(getattr(ws, "background_stock_items", []) if ws else []),
            dynamic_refresh_count=int(getattr(ws, "dynamic_refresh_count", 0) if ws else 0),
            krx_symbol_count=len(getattr(self.state, "krx", {})),
            nxt_symbol_count=len(getattr(self.state, "nxt", {})),
        )
        self.frame = self.engine.evaluate(metrics)
        self.last_error = None
        return self.frame

    def allowed(self, component: str) -> bool:
        if self.frame is None:
            return True
        return component not in self.frame.policy.suppressed_components

    def interval(self, component: str, base_seconds: float) -> float:
        if self.frame is None:
            return float(base_seconds)
        multiplier = self.frame.policy.interval_multipliers.get(component, 1.0)
        return float(base_seconds) * max(1.0, float(multiplier))
