from __future__ import annotations

from datetime import date
from functools import lru_cache
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _csv(value: str) -> list[str]:
    return [x.strip() for x in value.split(",") if x.strip()]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PULSE_", env_file=".env", extra="ignore")

    env: str = "prod"
    feed_enabled: bool = False
    kiwoom_appkey: str = ""
    kiwoom_secretkey: str = ""
    kiwoom_rest_base: str = "https://api.kiwoom.com"
    kiwoom_ws_url: str = "wss://api.kiwoom.com:10000/api/dostk/websocket"
    ws_group: str = "1001"

    # Static stock realtime names. Dynamic discovery names are process-memory only.
    ws_items: str = ""
    ws_types: str = "0B,0C,0D,0H,0w"
    ws_global_types: str = "0s"
    ws_index_items: str = "001,101"
    ws_index_types: str = "0J,0U"
    ws_dynamic_group_base: int = 2000
    ws_dynamic_max_items: int = 34
    ws_background_reserve_items: int = 10

    receive_stale_after_sec: float = 5.0
    event_stale_after_sec: float = 7.0
    future_tolerance_sec: float = 2.0
    timestamp_regression_tolerance_sec: float = 1.0
    raw_ring_size: int = 1000

    # Comma-separated YYYY-MM-DD. Weekend closing is automatic.
    holiday_dates: str = ""

    # New PULSE-owned 20-day same-time baseline store only.
    baseline_db_path: str = "/app/data/pulse_edge/baseline.sqlite3"
    baseline_flush_interval_sec: float = 60.0

    # Optional static metadata: 005930:KOSPI,247540:KOSDAQ
    symbol_markets: str = ""

    # Current-event market discovery. No previous-session state is loaded.
    discovery_enabled: bool = False
    discovery_interval_sec: float = 20.0

    # Foreign/institution REST facts. Off until live API behavior is verified.
    investor_flow_enabled: bool = False
    investor_flow_interval_sec: float = 180.0

    # Full-universe metadata and fair background realtime rotation.
    universe_enabled: bool = False
    universe_refresh_sec: float = 21600.0
    background_coverage_enabled: bool = False
    background_coverage_interval_sec: float = 15.0
    background_batch_size: int = 10

    # Sector breadth uses ka20003 and expands leading sectors with ka20002.
    sector_enabled: bool = False
    sector_interval_sec: float = 60.0
    sector_component_limit: int = 12

    # Phase 3B SMART-MONEY shadow. Amount-scale defaults to 0 until live units are verified.
    smart_money_enabled: bool = False
    smart_money_interval_sec: float = 30.0
    smart_money_refresh_limit: int = 80
    daily_context_ttl_sec: float = 1800.0
    flow_amount_to_daily_value_scale: float = 0.0

    # Phase 3C derived ignition/veto shadow. No new broker calls and no official action.
    ignition_enabled: bool = False
    ignition_interval_sec: float = 5.0
    ignition_refresh_limit: int = 80

    # Phase 3D derived sector-spillover + pullback-second-wave shadows.
    # Both reuse current in-memory 3B/feature/sector facts and make no new broker calls.
    sector_spillover_enabled: bool = False
    sector_spillover_interval_sec: float = 5.0
    sector_spillover_refresh_limit: int = 80
    pullback_second_wave_enabled: bool = False
    pullback_second_wave_interval_sec: float = 5.0
    pullback_second_wave_refresh_limit: int = 80

    # Phase 3E derived market-regime + confluence + hard-gate shadow.
    # Reuses existing PULSE EDGE facts only; no new broker API/WebSocket type.
    market_regime_enabled: bool = False
    market_regime_interval_sec: float = 5.0
    market_regime_sector_max_age_sec: float = 180.0
    market_regime_feature_max_age_sec: float = 30.0
    confluence_enabled: bool = False
    confluence_interval_sec: float = 5.0
    confluence_refresh_limit: int = 80
    hard_gate_tick_max_age_sec: float = 3.5
    hard_gate_required_discovery_sources: int = 2
    hard_gate_required_persistence: int = 3
    hard_gate_krx_spread_max_pct: float = 0.6
    hard_gate_nxt_spread_max_pct: float = 0.8
    # Provisional shadow floor; live calibration can tighten this later.
    hard_gate_min_money_5m_krw: float = 100_000_000.0

    # Phase 3F pattern completion + same-day KRX→NXT bridge shadows.
    # Derived from existing PULSE EDGE in-memory facts only.
    pattern_completion_enabled: bool = False
    pattern_completion_interval_sec: float = 5.0
    pattern_completion_refresh_limit: int = 80
    krx_nxt_bridge_enabled: bool = False
    krx_nxt_bridge_interval_sec: float = 5.0
    krx_nxt_bridge_refresh_limit: int = 80

    # Phase 4A integrated PRE-BUY / READY / ENTRY-ELIGIBLE shadow board.
    # Reads existing PULSE EDGE evidence only and emits no official signal/order.
    prebuy_decision_enabled: bool = False
    prebuy_decision_interval_sec: float = 5.0
    prebuy_decision_refresh_limit: int = 80
    prebuy_decision_upstream_max_age_sec: float = 15.0

    # Phase 4D current-decision compression shadow.
    # Reads only immutable current PRE-BUY decision frames; no history or new score.
    current_decision_compression_enabled: bool = False
    current_decision_compression_interval_sec: float = 5.0
    current_decision_compression_refresh_limit: int = 80
    current_decision_compression_max_rows: int = 3
    current_decision_compression_source_max_age_sec: float = 7.5

    # Phase 4B historical signal ledger / performance foundation.
    # One-way persistence only: ledger rows never feed current-row supply.
    signal_ledger_enabled: bool = False
    signal_ledger_db_path: str = "/app/data/pulse_edge/signal_ledger.sqlite3"
    signal_ledger_interval_sec: float = 5.0
    signal_ledger_refresh_limit: int = 100
    signal_ledger_min_stage_dwell_sec: float = 30.0
    signal_ledger_sample_interval_sec: float = 10.0
    signal_ledger_episode_end_absence_sec: float = 120.0

    # Phase 4C trusted CLOSE/1D/3D/5D outcome completion.
    # Uses only existing ka10081 daily bars and never feeds current-row supply.
    signal_daily_outcomes_enabled: bool = False
    signal_daily_outcomes_interval_sec: float = 60.0
    signal_daily_outcomes_refresh_ttl_sec: float = 300.0
    signal_daily_outcomes_max_symbols_per_cycle: int = 20

    # Phase 4E operational truth / load protection.
    # Observability and scheduler protection only; never changes trading scores.
    runtime_truth_enabled: bool = False
    runtime_truth_interval_sec: float = 5.0

    # Phase 4E.1 presentation safety gate. Current-display only; no score changes.
    presentation_safety_enabled: bool = False
    presentation_safety_interval_sec: float = 2.0

    # Phase 5A fixed operations UI. Static client reads existing APIs only.
    ui_enabled: bool = True

    # Phase 6B KRX supply-absorption shadow. Reuses current PULSE facts only.
    # It is isolated from SMART-MONEY/Confluence/PRE-BUY/current rank.
    supply_absorption_enabled: bool = True
    supply_absorption_interval_sec: float = 30.0
    supply_absorption_refresh_limit: int = 100
    supply_absorption_investor_max_age_sec: float = 420.0
    supply_absorption_price_max_age_sec: float = 7.0
    supply_absorption_program_max_age_sec: float = 15.0
    supply_absorption_detail_ttl_sec: float = 75.0
    supply_absorption_detail_requests_per_cycle: int = 8

    # Phase 6C DUAL signal ledger / performance. One-way observer only.
    dual_performance_enabled: bool = True
    dual_performance_db_path: str = "/app/data/pulse_edge/dual_performance.sqlite3"
    dual_performance_interval_sec: float = 5.0
    dual_daily_outcomes_enabled: bool = True
    dual_daily_outcomes_interval_sec: float = 300.0
    dual_daily_outcomes_max_symbols_per_cycle: int = 20

    # Phase 6D transition alerts / KRX close classification. One-way operations observer only.
    transition_ops_enabled: bool = True
    transition_ops_db_path: str = "/app/data/pulse_edge/transition_ops.sqlite3"
    transition_ops_interval_sec: float = 5.0
    transition_ops_alert_cooldown_sec: float = 600.0
    transition_ops_close_hour_kst: int = 15
    transition_ops_close_minute_kst: int = 30

    # Phase 6E PULSE-native NXT engine. Uses NXT realtime microstructure only.
    # KRX contributes same-day close reference price only; investor flow reuse is forbidden.
    nxt_native_enabled: bool = True
    nxt_native_interval_sec: float = 5.0
    nxt_native_refresh_limit: int = 600
    nxt_native_spread_max_pct: float = 0.8
    nxt_native_min_money_5m_krw: float = 20_000_000.0
    nxt_native_close_strict_hour_kst: int = 19
    nxt_native_close_strict_minute_kst: int = 50

    # Phase 6E.1 fixed NXT operations board. Display-only stabilizer over Phase 6E.
    nxt_operations_board_enabled: bool = True
    nxt_operations_board_interval_sec: float = 5.0
    nxt_operations_board_fixed_rows: int = 10
    nxt_operations_board_qualification_dwell_sec: float = 12.0
    nxt_operations_board_membership_commit_sec: float = 30.0
    nxt_operations_board_missing_grace_sec: float = 15.0
    nxt_operations_board_overtake_min_score_gap: float = 5.0
    nxt_operations_board_overtake_required_checks: int = 2
    nxt_operations_board_overtake_max_wait_sec: float = 20.0

    # Phase 6F post-close missed-opportunity audit. One-way historical diagnostics only.
    missed_opportunity_enabled: bool = True
    missed_opportunity_db_path: str = "/app/data/pulse_edge/missed_opportunity.sqlite3"
    missed_opportunity_interval_sec: float = 30.0
    missed_opportunity_surge_threshold_pct: float = 5.0
    missed_opportunity_post_close_hour_kst: int = 15
    missed_opportunity_post_close_minute_kst: int = 40
    missed_opportunity_max_pages_per_market: int = 10
    # ka10027 post-close audit must scan the full ranked mover set; liquidity is judged later by universe eligibility.
    # 0 = all trade values.
    missed_opportunity_trade_value_condition: str = "0"

    # Phase 6G current-data completion. Read-only enrichment over current KRX facts.
    # Historical references are display/diagnostic fields and never feed scores or ranking.
    current_enrichment_enabled: bool = True
    current_enrichment_interval_sec: float = 30.0
    current_enrichment_max_rows: int = 200
    current_enrichment_daily_requests_per_cycle: int = 12

    # Phase 6G.1 fixed KRX DUAL operations board. Display-only stabilizer.
    krx_operations_board_enabled: bool = True
    krx_operations_board_interval_sec: float = 5.0
    krx_operations_board_fixed_rows: int = 10
    krx_operations_board_qualification_dwell_sec: float = 12.0
    krx_operations_board_membership_commit_sec: float = 30.0
    krx_operations_board_missing_grace_sec: float = 15.0
    krx_operations_board_overtake_min_score_gap: float = 5.0
    krx_operations_board_overtake_required_checks: int = 2
    krx_operations_board_overtake_max_wait_sec: float = 20.0

    # Phase 7A.1 19:00 KST one-way Daily Review.
    # Reads already-recorded evidence only; proposals never auto-apply or feed current ranking/score.
    daily_review_enabled: bool = True
    daily_review_db_path: str = "/app/data/pulse_edge/daily_review.sqlite3"
    daily_review_interval_sec: float = 60.0
    daily_review_hour_kst: int = 19
    daily_review_minute_kst: int = 0
    daily_review_min_evidence_for_proposal: int = 3

    # Phase 6A live shadow validation. When feed is enabled this one-way observer
    # can raise the already-existing shadow pipeline so a real session is not
    # wasted by a missing feature flag. It never enables official actions.
    live_shadow_validation_enabled: bool = True
    live_shadow_validation_interval_sec: float = 2.0
    live_shadow_validation_db_path: str = "/app/data/pulse_edge/live_shadow_validation.sqlite3"

    # 2.1.0 live-certification evidence gate. One-way recorder over frozen outputs.
    # No broker calls, rank/score feedback, signal enablement or order actions.
    live_certification_enabled: bool = True
    live_certification_interval_sec: float = 5.0
    live_certification_db_path: str = "/app/data/pulse_edge/live_certification.sqlite3"
    live_certification_max_symbols: int = 30
    live_certification_ws_heartbeat_sec: float = 30.0
    live_certification_first_gate_days: int = 3
    live_certification_final_review_days: int = 5
    runtime_busy_cpu_pct: float = 65.0
    runtime_high_cpu_pct: float = 80.0
    runtime_critical_cpu_pct: float = 90.0
    runtime_busy_memory_pct: float = 70.0
    runtime_high_memory_pct: float = 82.0
    runtime_critical_memory_pct: float = 92.0
    runtime_busy_disk_pct: float = 78.0
    runtime_high_disk_pct: float = 88.0
    runtime_critical_disk_pct: float = 94.0
    runtime_busy_loop_lag_sec: float = 0.35
    runtime_high_loop_lag_sec: float = 0.8
    runtime_critical_loop_lag_sec: float = 1.5

    @model_validator(mode='after')
    def runtime_capacity(self):
        # Apply the same installation guard even when an old .env is supplied
        # directly to Docker, bypassing prepare_env.py.
        available = 34 - len(set(self.item_list))
        if available < 8 or self.ws_dynamic_max_items < 8:
            raise ValueError('PULSE requires 8 dynamic slots inside the 34-stock capacity')
        self.ws_dynamic_max_items = min(self.ws_dynamic_max_items, available)
        self.ws_background_reserve_items = max(1, min(self.ws_background_reserve_items, 10, self.ws_dynamic_max_items // 3))
        self.background_batch_size = max(1, min(self.background_batch_size, self.ws_background_reserve_items))
        self.background_coverage_interval_sec = max(15.0, self.background_coverage_interval_sec)
        return self

    @property
    def item_list(self) -> list[str]:
        return _csv(self.ws_items)

    @property
    def type_list(self) -> list[str]:
        return _csv(self.ws_types)

    @property
    def global_type_list(self) -> list[str]:
        return _csv(self.ws_global_types)

    @property
    def index_item_list(self) -> list[str]:
        return _csv(self.ws_index_items)

    @property
    def index_type_list(self) -> list[str]:
        return _csv(self.ws_index_types)

    @property
    def holidays(self) -> set[date]:
        out: set[date] = set()
        for token in _csv(self.holiday_dates):
            try:
                out.add(date.fromisoformat(token))
            except ValueError:
                continue
        return out

    @property
    def market_map(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for token in _csv(self.symbol_markets):
            if ":" not in token:
                continue
            symbol, market = token.split(":", 1)
            symbol = symbol.strip()[:6]
            market = market.strip().upper()
            if symbol and market in {"KOSPI", "KOSDAQ"}:
                out[symbol] = market
        return out


@lru_cache
def get_settings() -> Settings:
    return Settings()
