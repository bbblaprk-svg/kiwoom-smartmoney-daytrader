"""Local synthetic CPU regression harness. Never live broker certification."""
import subprocess,sys,time,json,os,statistics,concurrent.futures,urllib.request
from pathlib import Path

root=Path(__file__).resolve().parent
log=(root/'synthetic-server.log').open('w')
proc=subprocess.Popen([sys.executable,str(root/'synthetic_app.py')],stdout=log,stderr=subprocess.STDOUT)

paths=['/health','/','/assets/pulse.js','/assets/pulse.css','/api/runtime-truth','/api/session','/api/feed-truth','/api/presentation/current-decision','/api/smart-money/top?limit=10','/api/operator/krx-prebuy-top?limit=10','/api/operator/krx-discovery-top?limit=10','/api/nxt-operations-board','/api/ledger/recent?limit=10','/api/performance/summary?limit=500','/api/diagnostics/pipeline']
def get(path):
 t=time.monotonic()
 with urllib.request.urlopen('http://127.0.0.1:18765'+path,timeout=3) as r:data=r.read()
 return path,(time.monotonic()-t)*1000,json.loads(data) if path.startswith('/api/') or path=='/health' else None
def safe(path):
 try:return get(path)
 except Exception as exc:return path+':'+str(exc)
startwait=time.monotonic()
try:
 while True:
  if proc.poll() is not None:raise RuntimeError('server stopped; inspect log')
  try:get('/health');break
  except Exception:
   if time.monotonic()-startwait>60:raise
   time.sleep(.25)
 started=time.monotonic();lat=[];cpu=[];rss=[];errors=[];maxpending=0;phases=set();checks=0;last={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
  while time.monotonic()-started<605:
   target=time.monotonic()+1
   for result in pool.map(lambda path: safe(path),paths):
    if isinstance(result,str):errors.append(result);continue
    path,ms,data=result;lat.append(ms)
    if path=='/health':maxpending=max(maxpending,data['runtime_feature_recalc']['oldest_pending_ms']);last['health']=data
    if path=='/api/session':phases.add(data['phase'])
    if path=='/api/runtime-truth':last['runtime']=data
    if path=='/api/diagnostics/pipeline':last['pipeline']=data
    if path=='/api/feed-truth':last['truth']=data
   metrics=last.get('runtime',{}).get('metrics',{});cpu.append(metrics.get('cpu_pct') or 0);rss.append(metrics.get('process_rss_mb') or 0);checks+=1
   checkpoint={'seconds':time.monotonic()-started,'requests':len(lat),'errors':errors,'cpu_mean_one_core_pct':statistics.mean(cpu),'cpu_max_sample_pct':max(cpu),'rss_max_mb':max(rss),'oldest_pending_max_ms':maxpending,'latency_max_ms':max(lat),'last':last}; (root/'soak-checkpoint.json').write_text(json.dumps(checkpoint,default=str))
   if checks%30==0:print(json.dumps({'seconds':round(time.monotonic()-started),'requests':len(lat),'errors':len(errors),'cpu_recent':cpu[-1],'rss_mb':rss[-1],'pending_age_max_ms':maxpending,'phases':sorted(phases)}),flush=True)
   time.sleep(max(0,target-time.monotonic()))
 result={'test':'SYNTHETIC_FULL_RUNTIME_NOT_BROKER_CERTIFICATION','seconds':time.monotonic()-started,'requests':len(lat),'errors':errors,'latency_max_ms':max(lat),'latency_p95_ms':sorted(lat)[int(len(lat)*.95)],'cpu_mean_one_core_pct':statistics.mean(cpu),'cpu_max_sample_pct':max(cpu),'rss_max_mb':max(rss),'oldest_pending_max_ms':maxpending,'phases':sorted(phases),'last':last}
 (root/'full-runtime-soak.json').write_text(json.dumps(result,indent=2,default=str))
 print(json.dumps({k:v for k,v in result.items() if k!='last'}),flush=True)
finally:
 proc.terminate()
 try:proc.wait(timeout=20)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close()
