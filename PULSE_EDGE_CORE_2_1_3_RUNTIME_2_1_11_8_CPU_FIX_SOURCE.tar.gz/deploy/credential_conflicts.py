"""Read Docker inspect JSON on stdin; report names only, never credentials."""
import json,sys
from pathlib import Path

def check(containers, env):
    key=env.get('PULSE_KIWOOM_APPKEY','').strip()
    if not key:raise ValueError('runtime appkey missing')
    conflicts=[]
    for c in containers:
        if not c.get('State',{}).get('Running'):continue
        name=c.get('Name','').lstrip('/')
        labels=c.get('Config',{}).get('Labels') or {}
        if name=='pulse-edge' or name.startswith('pulse-edge-') or labels.get('io.pulse-edge.project')=='PULSE_EDGE':continue
        values=dict(x.split('=',1) for x in c.get('Config',{}).get('Env',[]) if '=' in x)
        if values.get('PULSE_FEED_ENABLED','').strip().lower() in {'false','0','no','off'}:continue
        if any(v.strip().strip('"\'')==key for k,v in values.items() if k in {'PULSE_KIWOOM_APPKEY','KIWOOM_APPKEY','KIWOOM_APP_KEY'}):conflicts.append(name)
    return conflicts

if __name__=='__main__':
    env=dict(x.split('=',1) for x in Path(sys.argv[1]).read_text().splitlines() if '=' in x)
    names=check(json.load(sys.stdin),env)
    if names:raise SystemExit('SAME_BROKER_APPKEY_OTHER_RUNNING_CONTAINER: '+','.join(names))
    print('VISIBLE_CONTAINER_CREDENTIAL_CONFLICT_CHECK_PASS')
