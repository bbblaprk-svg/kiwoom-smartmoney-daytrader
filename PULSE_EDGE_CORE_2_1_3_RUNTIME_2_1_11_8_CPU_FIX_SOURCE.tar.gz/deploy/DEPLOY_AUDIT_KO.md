# PULSE EDGE 2.1.11.8 CPU_FIX — 수정·검증 기록

기준: 사용자가 첨부한 runtime 2.1.11.7 CPU_GUARD 파일 3개. 실제 대상 서버의 이번 CPU 로그·프로세스 목록·SSH 연결은 제공되지 않았다. 따라서 아래 원인은 첨부 코드와 로컬 재현에서 확인한 사항이며, 현재 Lightsail의 모든 과부하 원인을 확인했다는 뜻은 아니다.

## 확인한 결함과 수정

1. **0.5초 재계산 병합 후에도 남는 전체 기록 반복 탐색.** 5/10/15/30분 체결, 10/30/120/300초 호가·체결 흐름, RS 기준점을 매번 반복 순회했다. 원래 보존 개수(체결 50,000·체결 흐름/호가 흐름 각각 20,000)와 개별 이벤트를 유지하면서 시간 인덱스와 누적 합계를 사용한다. 시간 역전은 정확한 조건식으로 조회하며, 시간창 경계는 회귀 테스트한다. 부동소수점 합산 순서 차이는 상대 1e-10 / 절대 1e-8 범위로 검증했다.
2. **기록 객체의 과도한 메모리.** 내부 TradePoint/TradeFlowPoint/QuoteFlowPoint를 경량 slots dataclass로 변경했다. 입력 값은 기존 정규화 및 숫자 변환을 통과한다. 공개 FeatureFrame·신호·히스토리 모델은 유지한다. 초기 합성 부하에서 약 920MB였던 메모리를 약 234MB로 줄였다. 최종 10분 동안의 최대치는 아래 결과를 확인한다.
3. **동일 날짜·시간 계산의 반복.** 수급 분석의 동일 거래일 조회 및 개장 범위 조회에서 수백만 번 반복된 시간대 변환을 경계값 비교로 바꿨다. ORB/Squeeze/VWAP 패턴의 시간 경계 생성은 조회마다 한 번으로 옮겼다. 점수·문턱값·승격 조건은 그대로이며, 첨부 원본 패턴 엔진과 450개 결과를 비교한다. 패턴 분석은 같은 계산을 두 번 하지 않고 지속 횟수에 따른 기존 단계 승격만 적용한다. 시작 시 입력을 복사하고 종목 사이에 asyncio 실행을 양보하며, 계산이 모두 끝난 뒤 결과를 함께 반영한다. 취소되면 직전 완성 결과를 유지한다. 첨부 원본 서비스와 40회·2,520개 결과, 지속 횟수, 날짜 초기화, 실행 양보, 취소를 비교 검증했다. 원본 엔진과 서비스는 deploy/reference_patterns.py 및 reference_pattern_service.py에 검사용으로만 들어 있다.
4. **WebSocket 수신 작업의 실행 독점.** 버퍼에 메시지가 많고 ingest 내부 await가 실제로 중단하지 않으면 다른 작업이 실행되지 않을 수 있었다. 메시지 32개 또는 처리 5ms마다 실행을 양보하며, 한 payload의 정규화 이벤트 처리도 64개마다 양보한다. 이벤트를 표본 추출하거나 버리지 않는다.
5. **정상 종료 후 재접속 반복.** CLOSE에도 1→2→4→최대 30초 재시도 간격을 적용한다. 로그인은 최대 10초 안에 실제 LOGIN 성공 응답을 확인하고, 로그인 중 PING도 응답한다. 등록 오류도 연결 오류로 드러낸다.
6. **API 호출마다 연결 재생성.** REST 클라이언트를 프로세스 내에서 재사용하여 TLS/연결 생성 비용을 줄이며 종료 시 닫는다. 요청 API·본문·수급 값·판정 규칙은 유지한다.
7. **정상 병합 대기를 과부하로 오인.** 기존 34종목 운영에서 pending 8개 이상은 분석을 미루고 배포 검사는 24개 이상을 실패로 처리했다. 대기 개수 대신 실제 오래 기다린 시간을 사용한다. 기존 0.5초 병합 주기는 유지하고, 한 회 계산은 개수와 시간 예산으로 제한한다. /health에 계산 시간과 분석 작업별 실행 시간을 표시한다.
8. **배포 우회 시 큰 구독 설정 복귀.** 예전 .env의 600종목/배치120 설정을 직접 Docker에 넣어도 앱 설정에서 총 34개 한도를 적용한다. 배경 예비는 최대10, 실제 배치도 예비 한도 이내다.
9. **실행 자원·배포 검사 보강.** CPU·RAM·Swap·프로세스·로그 크기를 제한한다. 메모리 비율은 Docker cgroup 한도를 반영한다. 보이는 다른 컨테이너의 같은 앱키 충돌을 검사하되 키 값은 출력하지 않는다. 실제 소스 해시·압축 경로·필수 파일·Dockerfile 해시·환경·데이터 볼륨·중복 Feed·Caddy 경로·HTTPS·동작 버전을 검증하고 전환 실패 시 같은 PULSE의 스냅샷을 복원한다.

## 유지한 범위

- NOVA 런타임·데이터·후보·복귀 구조를 가져오지 않았다.
- PRICE HOLD, DUAL, PRE-BUY, NXT의 점수·문턱값·신호 정책을 변경하지 않았다.
- index.html / pulse.js / pulse.css는 첨부본과 바이트 동일하다. 테이블·표시 개수·히스토리 화면을 임의 수정하지 않았다.
- 수정하지 않은 앱 파일은 UNCHANGED_SHA256.json의 첨부 원본 해시로 검사한다.
- SOURCE 압축에 인증키, .env, 실제 투자 데이터, SQLite 운영 DB, 이전 pyc 파일을 포함하지 않는다.

## 검증 결과

측정 파일: deploy/CPU_FIX_TEST_RESULTS.json. 아래는 로컬 CPU 및 HTTP 재현이며 실제 키움 서버의 정상 운용 인증이 아니다.

| 검사 | 결과 |
|---|---|
| 전체 앱 실제 경과 시간 | 605.79초, background task 32개, HTTP 동시 작업자 6개 |
| 화면·핵심 API 15개 경로 반복 요청 | 8,925건, HTTP 오류 0건 |
| 응답 지연 | p95 343.50ms, 최대 1681.62ms |
| CPU | 코어 1개 기준 샘플 평균 33.30%, 최대 샘플 99.97% (초기화 포함) |
| 프로세스 메모리 | 최대 RSS 440.13MiB |
| feature 재계산 대기 | 관측 최대 1163ms |
| 모의 세션 | KRX 장중, NXT 시간대 전환 |
| 정규화 처리 | 612,306건, 연속성 거부 0건 |
| 최종 로드·Feed 상태 | NORMAL / LIVE (합성 입력) |
| 전체 기록 조회 계산 경로 | 동일한 816,000개 보존 기록의 sweep CPU 0.749795초 → 0.051413초, 93.14% 감소 |
| 독립 설치 | 고정된 런타임 의존성 22개 설치 및 pip check 통과 |
| HTTP 정적 경로 검사 | 실제 앱 TestClient GET 68개 모두 200 |
| 원본 보존 | UI 3개 바이트 동일, 수정하지 않은 원본 앱 파일 121개 SHA256 일치 |
| 계산 회귀 | 108,104개 이벤트·131개 FeatureFrame 비교, 시계 역전/경계/삭제/압축 11,000개 기록 |
| 패턴 회귀 | 원본 엔진 450개 결과, 원본 서비스 40회·2,520개 프레임 및 지속 횟수 일치 |
| WS | 버퍼 메시지 3,200개 전부 처리, heartbeat 100회; CLOSE 재접속 대기/로그인 PING 검사 |
| 배포·복원 상태 모사 | 정상 전환/수동 복원/새 Feed 실패/기존 Feed 정지 실패/canary 실패 경로 통과; 실제 파일 복원 순서 및 볼륨 경로 유지 |

첫 10분 검사에서는 8,775건 HTTP 오류가 없었지만 패턴 분석이 event loop를 독점하여 최대 응답 2853ms, 재계산 대기 3472ms를 기록했다. 이 남은 병목을 수정한 뒤 위의 최종 10분 검사를 다시 수행했다. 초기 순간 CPU 상승을 완전히 없앴다는 뜻은 아니며, 93%라는 수치는 지정된 feature 계산 경로에만 해당한다. CPU 평균은 앱이 보고한 프로세스 CPU 샘플의 산술 평균으로, 대상 Lightsail 호스트의 CPU 평균이 아니다. 비동기 패턴 refresh 시간에는 종목 사이 실행 양보 시간도 포함된다.

입력은 최초 34개 종목에 체결·흐름 816,000개 기록을 넣고, 68개 합성 종목을 회전하며 실제 normalization/truth/feature 및 후속 작업에 전달했다. REST/WS 공급자는 모사했다. NXT 시간대의 KRX 이벤트는 세션 정책에 따라 차단되며 이를 데이터 유실 오류로 계산하지 않는다. 투자자별 실수급 응답은 만들지 않아 수급 진단에 `InvestorSchemaError:ka10060 missing stk_invsr_orgn_chart`가 표시된다. 따라서 HTTP 오류 0건이 모든 전략에 실제 수급 데이터가 확보되었다는 의미는 아니다. 장 전체의 메모리 상한, 실제 신규 후보/신호 품질, 수익성은 이 테스트로 인증하지 않았다.

Docker 명령·Caddy·공용 HTTP를 대체한 배포 모사는 실제 Docker 빌드나 실제 HTTPS 검사가 아니다. 최종 압축은 Python AST, JavaScript 구문, Bash 구문, Dockerfile의 실제 추출 Python 명령, `(2)` 파일명 처리, 잘못된 해시 거부, 3개 파일의 해시 결합을 별도로 검사한다. ShellCheck는 설치되어 있지 않아 실행하지 않았다.

합성 검사를 재현하려면 압축을 별도 폴더에 풀고 고정 의존성을 설치한 뒤 `PYTHONPATH=. python -m deploy.run_synthetic_soak`를 실행한다. localhost:18765를 사용하며 605초 후 deploy/full-runtime-soak.json을 작성한다. 공급자와 시계는 합성이며 운영 서버의 인증 정보나 실제 주문을 사용하지 않는다.


## 실제 서버 확인 범위와 한계

이 작업 환경에는 Docker 실행 파일/daemon, Lightsail SSH 세션, 연결된 GitHub 계정이 없다. 공용 HTTPS 직접 요청도 네트워크 접근이 성립하지 않아 확인하지 못했다. **실제 Docker build, Lightsail 배포 완료, 공용 HTTPS 정상 응답, 키움 OAuth/WS 실인증, 장전·장중 실제 데이터 부하, 외부 앱과의 토큰 충돌은 미검증**이다. 로컬 합성 부하·대체 Docker 상태 모사는 이 인증을 대신하지 않는다.

수정본은 다음 서버 검사를 자동 실행한다: 실제 Docker build → 이미지 내부 회귀 테스트 → Feed-OFF canary 2분 → 기존 PULSE Feed 정지·동일 데이터 폴더 백업 → 새 Feed 1개 시작 → Caddy DNS/공용 HTTPS → 준비 2분 → 실제 응답·CPU·메모리·Feed 검사 10분 → 최종 버전 확인. 휴장 중 실행은 실데이터 검증 완료로 표시하지 않는다. 기본 이미지 python:3.12-slim의 digest는 고정하지 않았으며 Python 패키지 버전은 requirements-lock.txt로 고정했다.

## 서버에서 실행

Dockerfile, PULSE_EDGE_RUNTIME_2_1_11_8_ONE_SHOT_DEPLOY.sh, PULSE_EDGE_CORE_2_1_3_RUNTIME_2_1_11_8_CPU_FIX_SOURCE.tar.gz를 같은 폴더에 둔다. 압축을 직접 풀 필요는 없다.

```bash
sudo bash PULSE_EDGE_RUNTIME_2_1_11_8_ONE_SHOT_DEPLOY.sh --background
sudo tail -n 40 /opt/pulse-edge/deploy-latest.log
```

브라우저 터미널이 닫혀도 작업을 계속한다. 빌드/호출 시간을 포함해 통상 14분 이상 걸리며 마지막 DEPLOY_PASS를 확인해야 한다. RUN_DIR/deploy.log에는 동일 상세 로그가 남는다. 실패하면 해당 로그의 ERROR/FAILED/ROLLBACK 줄을 확인한다. 새로 배포된 버전 확인은 /health의 runtime_safety_release=2.1.11.8_CPU_FIX이다.

설정은 /opt/pulse-edge/.env, 데이터는 /opt/pulse-edge/data, 네트워크는 kiwoom-net, Caddy는 kiwoom-caddy, 주소는 https://3-38-25-20.nip.io를 사용한다. 다른 앱에서 키·볼륨을 자동으로 가져오지 않는다. Dockerfile만 GitHub에 올리는 것으로 배포가 완성되지 않으며 SOURCE도 같은 빌드 폴더에 필요하다. --preflight는 빌드/환경 검사이고 실제 Feed의 정상 운용 인증은 아니다.

수동 복원은 성공 로그에 표시된 해당 실행의 ROLLBACK 명령을 사용한다. 실행 중인 새 Feed를 정지할 수 없으면 이전 Feed를 중복으로 시작하지 않는다. 이전 앱 자체가 고장난 경우 복원은 이전 상태로 돌아가는 것이며, 정상 동작을 보장하지 않는다.

## 구현 참고

명시적인 실행 양보의 필요성은 [websockets asyncio 문서](https://websockets.readthedocs.io/en/stable/faq/asyncio.html)에 설명되어 있다. Docker의 CPU·메모리·Swap 제한 의미는 [Docker 자원 제한 문서](https://docs.docker.com/engine/containers/resource_constraints/)를 참고했다. 문서는 구현 방식의 근거이며 실제 대상 서버의 검증 결과가 아니다.
