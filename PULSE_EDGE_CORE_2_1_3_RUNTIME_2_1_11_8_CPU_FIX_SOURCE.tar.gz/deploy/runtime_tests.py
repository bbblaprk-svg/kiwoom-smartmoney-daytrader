"""CPU repair regressions. Synthetic events only; no broker I/O."""
from __future__ import annotations
import asyncio
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
import json
import math
import random
from types import SimpleNamespace
from unittest.mock import patch
from pulse_edge.features.series import IndexedSeries, trade_values
from pulse_edge.features.models import TradePoint
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.core.models import NormalizedEvent, Venue
from pulse_edge.feed.ws import KiwoomWebSocket
BASE=datetime(2026,9,8,0,tzinfo=timezone.utc)

def equivalent(a,b,path=''):
    if isinstance(a,dict):
        assert a.keys()==b.keys(),path
        for k in a:equivalent(a[k],b[k],path+'.'+k)
    elif isinstance(a,float):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-8),(path,a,b)
    else:assert a==b,(path,a,b)

def indexed_windows():
    rng=random.Random(431);s=IndexedSeries(2500,trade_values,2);q=deque(maxlen=2500)
    for i in range(11000):
        ts=BASE+timedelta(seconds=i//4-(3 if i%89==0 else 0))
        p=TradePoint(ts=ts,price=10000+rng.randrange(100),volume=rng.randrange(30))
        s.append(p);q.append(p)
        if i%61==0 and len(q)>1:assert s.popleft()==q.popleft()
        if i%101==0:
            assert list(s)==list(q) and list(reversed(s))==list(reversed(q))
            for seconds in [0,1,10,30,120,300,1800]:
                lo=ts-timedelta(seconds=seconds);expected=[p for p in q if lo<p.ts<=ts]
                assert s.window(lo,ts)==expected
                assert s.since(lo,ts)==[p for p in q if lo<=p.ts<ts]
                count,totals=s.totals(lo,ts)
                assert count==len(expected)
                assert totals==(sum(p.price*p.volume for p in expected),sum(p.volume for p in expected))
                assert s.at_or_before(lo)==next((p for p in reversed(q) if p.ts<=lo),None)
    print('INDEXED_WINDOWS_PASS points=11000 regression/boundary/eviction/compaction')

def frame_equivalence():
    ref=FeatureEngine();new=FeatureEngine()
    ref.trades=defaultdict(lambda:deque(maxlen=50000))
    ref.trade_flow=defaultdict(lambda:deque(maxlen=20000))
    ref.quote_flow=defaultdict(lambda:deque(maxlen=20000))
    ref.benchmarks=defaultdict(lambda:deque(maxlen=20000))
    checks=0;events=0
    for f in (ref,new):f.register_symbol_market('005930','KOSPI')
    for i in range(52050):
        ts=BASE+timedelta(seconds=i*.04)
        data=dict(price=str(10000+i%101),trade_volume=str(i%19),change_rate=str(i%13/10),cumulative_volume=str(i*19),cumulative_amount=str(i*190000),buy_exec_volume=None if i%7==0 else str(i%11),sell_exec_volume=None if i%5==0 else str(i%8),net_buy_exec_volume=str((i%9)-3),instant_amount=str(100000+(i%17)*1000))
        ev=NormalizedEvent(receive_time=ts,event_time=ts,source='test',real_type='0B',symbol='005930',venue=Venue.KRX,data=data)
        for f in (ref,new):f.ingest(ev)
        events+=1
        ev=ev.model_copy(update={'real_type':'0D','data':dict(ask1='10010',bid1='10000',ask1_qty=str(100+i%5),bid1_qty=str(100+i%7))})
        for f in (ref,new):f.ingest(ev)
        events+=1
        if i%13==0:
            ev=ev.model_copy(update={'real_type':'0J','symbol':'001','data':{'price':str(3000+i*.01)}})
            for f in (ref,new):f.ingest(ev)
            events+=1
        if i%401==0 or i==52049:
            for f in (ref,new):f.flush_due(force=True,max_batch=10000)
            equivalent(ref.frames[(Venue.KRX,'005930')].model_dump(),new.frames[(Venue.KRX,'005930')].model_dump())
            checks+=1
    print(f'FRAME_EQUIVALENCE_PASS checks={checks} events={events} all_fields=True tolerance=1e-10/1e-8')

async def socket_tests():
    async def token():return 'synthetic-token'
    received=0;heartbeat=0
    async def payload(p):
        nonlocal received
        received+=1
    class BufferedSocket:
        def __init__(self):self.i=0;self.login_reads=0;self.sent=[]
        async def send(self,p):self.sent.append(p)
        async def recv(self):
            self.login_reads+=1
            return json.dumps({'trnm':'PING'} if self.login_reads==1 else {'trnm':'LOGIN','return_code':0})
        async def close(self):pass
        def __aiter__(self):return self
        async def __anext__(self):
            self.i+=1
            if self.i>3200:raise StopAsyncIteration
            return '{"trnm":"REAL","data":[]}'
    ws=BufferedSocket()
    class Connect:
        async def __aenter__(self):return ws
        async def __aexit__(self,*args):pass
    client=KiwoomWebSocket('ws://test',token,[],payload)
    async def beat():
        nonlocal heartbeat
        while received<3200:heartbeat+=1;await asyncio.sleep(0)
    with patch('pulse_edge.feed.ws.websockets.connect',return_value=Connect()):await asyncio.gather(client._run_once(),beat())
    assert received==3200 and heartbeat>=50,(received,heartbeat)
    assert client.receive_yields>=100
    assert any(json.loads(x).get('trnm')=='PING' for x in ws.sent)
    calls=0
    async def normal_close():
        nonlocal calls
        calls+=1
    client._run_once=normal_close
    task=asyncio.create_task(client.run_forever());await asyncio.sleep(.05)
    assert calls==1,'normal close reconnect spin'
    await client.stop();await asyncio.wait_for(task,.2)
    print(f'WS_FAIRNESS_AND_RECONNECT_PASS messages={received} scheduler_turns={heartbeat}')

async def rest_pool_test():
    import httpx
    from pulse_edge.feed.rest import KiwoomRestClient
    calls=[]
    async def token():return 'test'
    def handler(request):
        calls.append(request.headers['api-id'])
        return httpx.Response(200,json={'return_code':0},headers={'cont-yn':'N'})
    client=KiwoomRestClient('https://test',token);real=httpx.AsyncClient;made=[]
    def factory(**kwargs):
        c=real(transport=httpx.MockTransport(handler),**kwargs);made.append(c);return c
    with patch('pulse_edge.feed.rest.httpx.AsyncClient',side_effect=factory):
        await client.post('one','/test',{});await client.post('two','/test',{})
        assert len(made)==1 and calls==['one','two']
        await client.close();assert made[0].is_closed
    print('REST_POOL_REUSE_AND_CLOSE_PASS')

def config_and_soak_test():
    from pulse_edge.config import Settings
    cfg=Settings(_env_file=None,ws_dynamic_max_items=600,ws_background_reserve_items=120,background_batch_size=120)
    assert (cfg.ws_dynamic_max_items,cfg.ws_background_reserve_items,cfg.background_batch_size)==(34,10,10)
    from pulse_edge import main as m
    original=m.features
    try:
        m.features=SimpleNamespace(recalc_runtime_stats=lambda:{'oldest_pending_ms':100,'pending':34})
        assert not m._feed_recalc_backlog_high()
        m.features=SimpleNamespace(recalc_runtime_stats=lambda:{'oldest_pending_ms':1001,'pending':1})
        assert m._feed_recalc_backlog_high()
    finally:m.features=original
    print('CAPACITY_AND_REAL_BACKLOG_PASS')


def pattern_equivalence():
    from pulse_edge.patterns.engine import OrbRetestEngine,SqueezeReleaseEngine,VwapReclaimEngine
    from pulse_edge.absorption.service import SupplyAbsorptionService
    from pulse_edge.features.models import FeatureFrame
    from deploy import reference_patterns as old
    rng=random.Random(122);checks=0
    for j in range(150):
     now=datetime(2026,9,8,0,35,tzinfo=timezone.utc)+timedelta(minutes=j%30)
     pts=[TradePoint(ts=now-timedelta(seconds=2100-i*5),price=10000+rng.randrange(-100,200),volume=rng.randrange(1000)) for i in range(420)]
     feature=FeatureFrame(venue=Venue.KRX,symbol='005930',asof=now,price=10000+rng.randrange(-100,200),session_vwap=10000,return_1m_pct=rng.uniform(-1,1),money_acceleration=rng.uniform(-100,100),rs_acceleration=rng.uniform(-1,1),vwap_distance_pct=rng.uniform(-1,4))
     for oldcls,newcls in [(old.OrbRetestEngine,OrbRetestEngine),(old.SqueezeReleaseEngine,SqueezeReleaseEngine),(old.VwapReclaimEngine,VwapReclaimEngine)]:
      kwargs=dict(asof=now,persistence_count=j%5)
      if newcls is OrbRetestEngine:kwargs.update(opening_high=10100,opening_low=9900)
      equivalent(oldcls().evaluate(feature,pts,**kwargs).model_dump(),newcls().evaluate(feature,pts,**kwargs).model_dump());checks+=1
    # Same-day selections include midnight, minute boundaries and regressions.
    from zoneinfo import ZoneInfo
    kst=ZoneInfo('Asia/Seoul');now=datetime(2026,9,8,0,2,tzinfo=kst)
    s=IndexedSeries(50000,trade_values,2)
    for i in range(1000):s.append(TradePoint(ts=now+timedelta(seconds=i-500),price=10000+i,volume=1))
    owner=SimpleNamespace(features=SimpleNamespace(trades={(Venue.KRX,'005930'):s}))
    for minutes in [None,0,1,3,10]:
     cutoff=now-timedelta(minutes=minutes) if minutes else datetime.combine(now.date(),datetime.min.time(),tzinfo=kst)
     expected=[p for p in s if p.ts>=cutoff and p.ts.astimezone(kst).date()==now.astimezone(kst).date()]
     assert SupplyAbsorptionService._trade_pts(owner,'005930',now,minutes)==expected
    print('ORIGINAL_PATTERN_ENGINE_EQUIVALENCE_PASS',checks)
    print('ABSORPTION_SAME_DAY_SELECTION_PASS')


async def pattern_service_test():
    from pulse_edge.patterns.service import PatternCompletionService
    from deploy.reference_pattern_service import PatternCompletionService as ReferenceService
    from pulse_edge.features.models import FeatureFrame
    from pulse_edge.patterns.models import OrbStage, SqueezeStage, VwapReclaimStage
    feature_store = SimpleNamespace(frames={}, trades={})
    old, new = ReferenceService(feature_store), PatternCompletionService(feature_store)
    rng = random.Random(781)
    checks = 0
    qualified = set()
    fields = ['_session_day', '_opening_ranges', '_orb_persist', '_squeeze_persist', '_reclaim_persist', 'last_refresh_at']
    stores = ['orb_frames', 'squeeze_frames', 'reclaim_frames']
    for cycle in range(40):
        now = BASE + timedelta(days=cycle//20, minutes=35 + cycle%4)
        feature_store.frames.clear(); feature_store.trades.clear()
        for i in range(24):
            key = (Venue.KRX if i%3 else Venue.NXT, str(i))
            points = []
            for j in range(420):
                price = 10000 + rng.randrange(-100, 200)
                if i%4 == 0:
                    price = (9900 if j%2 else 10100) if j < 230 else (9990 if j%2 else 10000)
                    if j >= 400: price = 10020
                points.append(TradePoint(ts=now-timedelta(seconds=(419-j)*5), price=price, volume=1000 if j<230 else 100))
            feature = FeatureFrame(venue=key[0], symbol=key[1], asof=now, price=10020 if i%4==0 else 10000+rng.randrange(-100,200), session_vwap=10000, return_1m_pct=.5, money_acceleration=100, rs_acceleration=.1, vwap_distance_pct=.2)
            feature_store.frames[key] = feature; feature_store.trades[key] = points
        if cycle%9 == 0:
            for key in list(feature_store.trades)[:3]: feature_store.trades[key] = []
        old.refresh(80, now)
        turns = 0
        done = False
        async def heartbeat():
            nonlocal turns
            while not done:
                turns += 1
                # Readers must see the previous complete generation while work
                # yields, until the final atomic publication.
                if new.last_refresh_at != now:
                    assert all(f.asof != now for f in new.orb_frames.values())
                await asyncio.sleep(0)
        beat = asyncio.create_task(heartbeat())
        await new.refresh_async(80, now)
        done = True; await beat
        assert turns >= 20, turns
        for field in fields: assert getattr(old,field) == getattr(new,field), field
        for name in stores:
            a,b=getattr(old,name),getattr(new,name)
            assert a.keys()==b.keys(),name
            for key in a:
                equivalent(a[key].model_dump(), b[key].model_dump());checks += 1
                qualified.add(b[key].stage)
    assert SqueezeStage.SQUEEZE_RELEASE_SHADOW in qualified
    assert VwapReclaimStage.VWAP_RECLAIM_SHADOW in qualified
    previous = (new.last_refresh_at, dict(new._squeeze_persist), dict(new.squeeze_frames))
    task = asyncio.create_task(new.refresh_async(80, now))
    await asyncio.sleep(0); task.cancel()
    try: await task
    except asyncio.CancelledError: pass
    assert previous == (new.last_refresh_at, new._squeeze_persist, new.squeeze_frames)
    print(f'ORIGINAL_PATTERN_SERVICE_EQUIVALENCE_AND_FAIRNESS_PASS frames={checks} cycles=40 atomic_cancel=True')


def credential_conflict_test():
    from deploy.credential_conflicts import check
    env={'PULSE_KIWOOM_APPKEY':'test-key'}
    def container(name, key, feed=True):
        return {'Name':name,'State':{'Running':True},'Config':{'Env':['KIWOOM_APPKEY='+key,'PULSE_FEED_ENABLED='+str(feed).lower()]}}
    assert check([container('/unrelated','test-key')],env)==['unrelated']
    assert check([container('/unrelated','different')],env)==[]
    assert check([container('/unrelated','test-key',False)],env)==[]
    assert check([container('/pulse-edge-old','test-key')],env)==[]
    print('CREDENTIAL_CONFLICT_NAMES_ONLY_PASS')

def run():
    indexed_windows();frame_equivalence();pattern_equivalence();asyncio.run(pattern_service_test());asyncio.run(socket_tests());asyncio.run(rest_pool_test());config_and_soak_test();credential_conflict_test()
if __name__=='__main__':run()
