"""Host resource telemetry for deployment evidence (no environment values)."""
import json,os,shutil
from pathlib import Path

def host_metrics():
    mem={l.split(':')[0]:int(l.split()[1]) for l in open('/proc/meminfo') if ':' in l}
    try:load=os.getloadavg()
    except OSError:load=None
    return {'cpus':os.cpu_count(),'load_average':load,'mem_total_kb':mem.get('MemTotal'),
            'mem_available_kb':mem.get('MemAvailable'),'swap_total_kb':mem.get('SwapTotal'),'swap_free_kb':mem.get('SwapFree')}
if __name__=='__main__':print(json.dumps(host_metrics()))
