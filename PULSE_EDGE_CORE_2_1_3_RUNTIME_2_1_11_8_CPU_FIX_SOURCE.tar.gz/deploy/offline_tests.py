"""Real application tests with broker I/O disabled; not live-market certification."""
from __future__ import annotations
import asyncio
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


def run():
    assert os.environ.get('PULSE_FEED_ENABLED','false').lower() in ('false','0','no','off'), 'must be Feed-OFF'
    from pulse_edge import main as m
    from pulse_edge.config import Settings
    from fastapi.testclient import TestClient
    manifest=json.loads(Path(__file__).with_name('UNCHANGED_SHA256.json').read_text())
    root=Path(__file__).resolve().parent.parent
    for name,sha in manifest.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha, 'unexpected change: '+name
    print(f'UNCHANGED_ORIGINAL_FILES_PASS files={len(manifest)}')
    # 2.1.11.7 operational CPU guard: strategy math is untouched; only cadence adapts.
    from pulse_edge.runtime.engine import RuntimeTruthEngine
    from pulse_edge.runtime.models import RuntimeMetrics
    from datetime import datetime, timezone
    base=dict(asof=datetime.now(timezone.utc), memory_pct=10.0, process_rss_mb=100.0, disk_pct=10.0, disk_free_gb=10.0, event_loop_lag_sec=0.0, feed_enabled=True, ws_connected=True, ws_last_error=None, ws_connection_count=1, ws_reconnect_count=0, last_payload_age_sec=0.1, truth_live_delta=1, truth_partial_delta=0, truth_stale_delta=0, truth_invalid_delta=0, continuity_reject_delta=0, session_reject_delta=0, total_payloads=1, dynamic_subscription_count=1, event_subscription_count=0, background_subscription_count=0, dynamic_refresh_count=0, krx_symbol_count=1, nxt_symbol_count=0)
    eng=RuntimeTruthEngine()
    busy=eng.evaluate(RuntimeMetrics(cpu_pct=70.0, **base)).policy.interval_multipliers
    high=eng.evaluate(RuntimeMetrics(cpu_pct=85.0, **base)).policy.interval_multipliers
    critical=eng.evaluate(RuntimeMetrics(cpu_pct=95.0, **base)).policy.interval_multipliers
    assert busy.get('ignition')==1.5 and high.get('ignition')==2.5 and critical.get('ignition')==4.0
    assert 'features' not in critical and 'websocket' not in critical
    print('CPU_ADAPTIVE_CADENCE_PASS')
    with TestClient(m.app) as client:
        count=0
        for route in m.app.routes:
            path=route.path
            if '{' not in path and 'GET' in (getattr(route,'methods',None) or []):
                response=client.get(path)
                assert response.status_code==200,(path,response.status_code)
                count+=1
        assert client.get('/health').json()['feed_enabled'] is False
    print(f'ALL_STATIC_GET_ENDPOINTS_PASS count={count}')
    cfg=Settings(_env_file=None).model_copy(update={'feed_enabled':True})
    assert all(m.effective_pipeline_flags(cfg).values()), 'default effective dependencies must be enabled'
    disabled=cfg.model_copy(update={k:False for k in type(cfg).model_fields if k.endswith('_enabled')})
    assert not any(m.effective_pipeline_flags(disabled).values())
    with tempfile.TemporaryDirectory() as temp:
        f=Path(temp)/'input.env'
        common='export PULSE_KIWOOM_APPKEY="test-key"\r\nPULSE_KIWOOM_SECRETKEY=\'test-secret\'\r\n'
        f.write_text(common)
        env={k:v for k,v in os.environ.items() if not k.startswith('PULSE_')}
        env['PULSE_FEED_ENABLED']='false'
        result=subprocess.run([sys.executable,'-m','deploy.prepare_env',str(f)],env=env,text=True,capture_output=True)
        assert result.returncode==0,result.stderr
        normalized=dict(x.split('=',1) for x in result.stdout.splitlines() if '=' in x)
        assert normalized['PULSE_KIWOOM_APPKEY']=='test-key'
        assert normalized['PULSE_WS_DYNAMIC_MAX_ITEMS']=='34'
        assert normalized['PULSE_WS_BACKGROUND_RESERVE_ITEMS']=='10'
        assert normalized['PULSE_BACKGROUND_BATCH_SIZE']=='10'
        for line in ['PULSE_BASELINE_DB_PATH=/legacy/baseline.db',
                     'PULSE_NXT_NATIVE_ENABLED=false',
                     'PULSE_KIWOOM_APPKEY=',
                     'PULSE_DISCOVERY_INTERVAL_SEC=invalid']:
            f.write_text(common+line+'\n')
            bad=subprocess.run([sys.executable,'-m','deploy.prepare_env',str(f)],env=env,text=True,capture_output=True)
            assert bad.returncode!=0,line
            assert 'test-secret' not in bad.stderr
            assert not bad.stdout
    print('ENV_NORMALIZATION_AND_REJECTION_PASS cases=5')
    asyncio.run(startup_test(m,Settings))


async def startup_test(m,Settings):
    with tempfile.TemporaryDirectory() as temp:
        cfg=Settings(_env_file=None)
        changes={'feed_enabled':True}
        for field in type(cfg).model_fields:
            if field.endswith('_db_path'):changes[field]=str(Path(temp)/(field+'.sqlite3'))
        m.settings=cfg.model_copy(update=changes)
        originals={}
        async def idle(*args,**kwargs):await asyncio.Event().wait()
        for name in list(vars(m)):
            if name.startswith('_') and name.endswith('_loop') and name!='_universe_loop':
                originals[name]=getattr(m,name);setattr(m,name,idle)
        old_ws=m.KiwoomWebSocket.run_forever
        old_refresh=m.UniverseService.refresh
        m.KiwoomWebSocket.run_forever=idle
        started=asyncio.Event()
        async def slow_metadata(self):
            started.set();await asyncio.Event().wait()
        m.UniverseService.refresh=slow_metadata
        cm=m.lifespan(m.app);ts=time.monotonic()
        try:
            await asyncio.wait_for(cm.__aenter__(),2)
            await asyncio.wait_for(started.wait(),2)
            names={task.get_name() for task in m.background_tasks}
            for name in ['pulse-universe','pulse-market-events','pulse-smart-money','pulse-background-coverage','pulse-prebuy-decision-shadow','pulse-nxt-native']:
                assert name in names,name
            assert (await m.health())['feed_enabled'] is True
            await cm.__aexit__(None,None,None)
            assert all(task.done() for task in m.background_tasks)
            print(f'SLOW_BROKER_STARTUP_AND_DB_SHUTDOWN_PASS seconds={time.monotonic()-ts:.3f} tasks={len(names)}')
        finally:
            m.KiwoomWebSocket.run_forever=old_ws
            m.UniverseService.refresh=old_refresh
            for name,fn in originals.items():setattr(m,name,fn)


if __name__=='__main__':run()
