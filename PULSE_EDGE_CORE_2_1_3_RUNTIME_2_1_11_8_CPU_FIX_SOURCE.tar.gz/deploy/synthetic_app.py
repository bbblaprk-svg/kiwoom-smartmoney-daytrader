"""Local synthetic CPU regression harness. Never live broker certification."""
import os,sys,time,asyncio,json
from pathlib import Path
from datetime import datetime as RealDateTime,timedelta,timezone
ROOT=Path(__file__).resolve().parent/'final-run'
os.environ['PULSE_FEED_ENABLED']='true'
os.environ['PULSE_KIWOOM_APPKEY']='synthetic-only'
os.environ['PULSE_KIWOOM_SECRETKEY']='synthetic-only'
from pulse_edge.config import Settings
for name in Settings.model_fields:
 if name.endswith('_db_path'):os.environ['PULSE_'+name.upper()]=str(ROOT/'soak-data'/f'{name}.sqlite3')
from pulse_edge import main as m
from pulse_edge.feed.rest import RestPage
from pulse_edge.core.models import Venue
from pulse_edge.features.models import TradePoint,TradeFlowPoint,QuoteFlowPoint
START=time.monotonic()
class Clock(RealDateTime):
 @classmethod
 def now(cls,tz=None):
  elapsed=time.monotonic()-START
  base=RealDateTime(2026,9,8,0,30,tzinfo=timezone.utc) if elapsed<480 else RealDateTime(2026,9,8,7,tzinfo=timezone.utc)
  val=base+timedelta(seconds=elapsed if elapsed<480 else elapsed-480)
  return val.astimezone(tz) if tz else val.replace(tzinfo=None)
for name,mod in list(sys.modules.items()):
 if name.startswith('pulse_edge') and getattr(mod,'datetime',None) is RealDateTime:mod.datetime=Clock
CODES=[f'{i:06d}' for i in range(1,69)]
async def fake_rest(api_id,path,body,*args,**kwargs):
 await asyncio.sleep(.001)
 if api_id=='ka10099':
  codes=CODES[:34] if body.get('mrkt_tp')=='0' else CODES[34:]
  return RestPage({'list':[dict(code=x,name='TEST'+x,listCount='100000000',state='정상',upName='TEST',upSizeName='LARGE',orderWarning='0',companyClassName='보통주',nxtEnable='Y') for x in codes]})
 keys={'ka10021':'bid_req_sdnin','ka10022':'req_rt_sdnin','ka10023':'trde_qty_sdnin'}
 if api_id in keys:
  codes=CODES[:34] if body.get('mrkt_tp')=='001' else CODES[34:]
  return RestPage({keys[api_id]:[dict(stk_cd=x,stk_nm='TEST'+x,sdnin_rt='100') for x in codes]})
 return RestPage({'return_code':0})
m.rest.post=fake_rest
# Seed retained historical input for the expensive hot-symbol path; all points
# are synthetic. Normalization/truth/continuity process every ongoing event.
now=Clock.now(timezone.utc)
for code in CODES[:34]:
 key=(Venue.KRX,code)
 for i in range(12000):
  ts=now-timedelta(seconds=(11999-i)*.15)
  m.features.trades[key].append(TradePoint(ts=ts,price=10000+i%17,volume=100+i%7,change_rate=.5))
 for i in range(6000):
  ts=now-timedelta(seconds=(5999-i)*.06)
  m.features.trade_flow[key].append(TradeFlowPoint(ts=ts,price=10000,buy_exec_volume=8,sell_exec_volume=5,net_buy_exec_volume=3,instant_amount=100000))
  m.features.quote_flow[key].append(QuoteFlowPoint(ts=ts,ask=10010,bid=10000,ask_qty=100,bid_qty=120,ofi_increment=(i%11)-4,microprice=10005,microprice_bias_pct=.01))
 m.features._recalc(key,now)
async def feed(self):
 self.connected=True;self.connection_count=1
 n=0
 while True:
  n+=1;now=Clock.now(timezone.utc);stamp=now.astimezone(m.session_router.last_operation_at.tzinfo).strftime('%H%M%S') if m.session_router.last_operation_at else now.astimezone(__import__('zoneinfo').ZoneInfo('Asia/Seoul')).strftime('%H%M%S')
  items=self.dynamic_stock_items
  rows=[]
  for code in items:
   price=10000+n%17
   rows.append({'type':'0B','item':code,'values':{'20':stamp,'10':str(price),'12':'0.5','15':'100','13':str(n*100),'14':str(n*1000000),'1030':'50','1031':'80','1314':'30','1313':'1000000'}})
   rows.append({'type':'0D','item':code,'values':{'21':stamp,'41':str(price+10),'51':str(price),'61':str(100+n%5),'71':str(120+n%7),'121':'1000','125':'1200'}})
  rows.append({'type':'0J','item':'001','values':{'20':stamp,'10':'3000'}})
  await self.on_payload({'trnm':'REAL','data':rows})
  self.last_message_at=time.time()
  await asyncio.sleep(.05)
m.KiwoomWebSocket.run_forever=feed
import uvicorn
uvicorn.run(m.app,host='127.0.0.1',port=18765,log_level='warning',access_log=False)
