from __future__ import annotations
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix='PULSE_', env_file='.env', extra='ignore')
    release: str = '3.9.1_HIDDEN_GEM_PUBLIC_READER'
    feed_enabled: bool = True
    kiwoom_appkey: str = ''
    kiwoom_secretkey: str = ''
    kiwoom_rest_base: str = 'https://api.kiwoom.com'
    kiwoom_ws_url: str = 'wss://api.kiwoom.com:10000/api/dostk/websocket'
    ws_dynamic_max_items: int = 34
    ws_background_reserve_items: int = 14
    ws_group_base: int = 3000
    ws_quote_focus_items: int = 4
    rank_commit_sec: float = 30.0
    market_index_stale_sec: float = 30.0
    program_stale_sec: float = 30.0
    sector_context_stale_sec: float = 45.0
    sector_min_sample: int = 3
    sector_full_confidence_sample: int = 12
    leader_chain_min_score: float = 45.0
    nxt_market_proxy_min_sample: int = 5
    nxt_market_proxy_stale_sec: float = 30.0
    supply_tight_min_conditions: int = 8
    supply_exhaustion_min_signals: int = 7
    ignition_trigger_min_count: int = 2
    probe_promote_items: int = 8
    probe_min_score: float = 60.0
    probe_ttl_sec: float = 600.0
    probe_window_sec: float = 20.0
    baseline_flush_sec: float = 30.0
    baseline_bootstrap_interval_sec: float = 60.0
    baseline_bootstrap_symbols_per_cycle: int = 2
    baseline_bootstrap_max_pages: int = 8
    baseline_bootstrap_target_days: int = 6
    cross_confirm_accept_pct: float = 0.001
    cross_conflict_pct: float = 0.003
    change_recheck_pp: float = 0.10
    change_conflict_pp: float = 0.30
    price_hold_vwap_gap_atr: float = 0.15
    price_hold_recovery_min: float = 0.60
    price_hold_extra_damage_atr: float = 0.50
    price_hold_market_rs_floor: float = -0.30
    tod_min_baseline_days: int = 5
    scan_interval_sec: float = 20.0
    universe_refresh_sec: float = 21600.0
    background_rotate_sec: float = 4.0
    evaluate_interval_sec: float = 1.0
    investor_refresh_sec: float = 20.0
    daily_context_refresh_sec: float = 120.0
    daily_context_symbols: int = 20
    coiled_enabled: bool = False
    coiled_refresh_sec: float = 60.0
    coiled_seed_limit: int = 30
    coiled_top_limit: int = 5
    coiled_min_daily_bars: int = 8
    impact_decay_min_score: float = 60.0
    flow_price_lag_min_score: float = 60.0
    release_distance_min_score: float = 65.0
    pressure_absorbed_min_axes: int = 1
    release_ready_min_axes: int = 2
    pressure_sell_value_floor: float = 20_000_000.0
    bid_absorption_min_score: float = 60.0
    bid_absorption_window_sec: float = 90.0
    # Short-window BID absorption adapts downward for illiquid/small names,
    # but never becomes stricter than the legacy 20m criterion.
    bid_absorption_abs_floor_krw: float = 5_000_000.0
    bid_absorption_sell_ratio_min: float = 0.20
    early_absorption_min_observed_sec: float = 180.0
    # Discovery-only layer. These thresholds never bypass PRE hard gates.
    early_hidden_gem_min_score: float = 60.0
    early_hidden_gem_change_min: float = -1.5
    early_hidden_gem_change_max: float = 2.5
    max_investor_symbols: int = 12
    stale_receive_sec: float = 5.0
    stale_event_sec: float = 7.0
    data_dir: str = '/app/data/pulse_edge'
    baseline_db: str = '/app/data/pulse_edge/tod_baseline.sqlite3'
    repeat_ttl_sec: float = 900.0
    history_db: str = '/app/data/pulse_edge/signal_history.sqlite3'
    history_limit: int = 400
    now_history_limit: int = 200
    coiled_history_limit: int = 200
    push_enabled: bool = True
    vapid_public_key: str = ''
    vapid_private_key: str = ''
    vapid_subject: str = 'https://localhost'
    state_ttl_sec: float = 1800.0
    max_state_symbols: int = 160
    minimum_turnover_10m: float = 50_000_000.0
    minimum_inst_sell_value: float = 100_000_000.0
    spread_limit_krx: float = 0.006
    spread_limit_nxt: float = 0.008
    hidden_gem_max_change: float = 12.0
    # Realtime hidden-gem policy. Leaders/mega-caps remain market sensors but cannot
    # receive fresh A/B pre-buy suitability. Small/mid caps are softly preferred.
    hidden_gem_preferred_market_cap_max_krw: float = 3_000_000_000_000.0
    hidden_gem_sensor_market_cap_krw: float = 5_000_000_000_000.0
    hidden_gem_leader_sensor_min_change: float = 3.0
    hidden_gem_leader_sensor_min_sample: int = 5
    # Broad-market RED is a fresh-entry hard gate only; discovery/1-2D monitoring continues.
    market_red_threshold_pct: float = -1.5
    # Sector-first discovery uses all available ranking buckets before stock-level priority.
    sector_discovery_min_sample: int = 2
    sector_discovery_laggard_max_change: float = 2.5
    news_stale_sec: float = 1800.0
    news_webhook_secret: str = ''
    vi_block_sec: float = 600.0
    preferred_change_max: float = 2.5
    # Hidden-gem objective guards.
    zero_trade_minute_coverage_samples: int = 45
    allowed_change_max: float = 3.0
    # Latent-energy extension. Above the ordinary +3% PRE ceiling a stock may remain
    # a candidate only when measurable stored energy is still high and the release
    # is not already exhausted. This is not a price-only relaxation.
    energy_extended_change_max: float = 7.0
    energy_extended_remaining_min: float = 50.0
    energy_extended_released_max: float = 60.0
    energy_loaded_stored_min: float = 68.0
    energy_loaded_remaining_min: float = 48.0
    energy_loaded_flow_min: float = 58.0
    energy_loaded_sell_failure_min: float = 55.0
    energy_loaded_supply_decay_min: float = 50.0
    release_window_imminence_min: float = 72.0
    too_late_released_min: float = 78.0
    too_late_remaining_max: float = 28.0
    # HIDDEN GEM PURE action gates. Final PRE/ENTRY decisions use only live
    # energy/supply structure; legacy MODEL A/B are not decision gates.
    hidden_gem_pre_stored_min: float = 80.0
    hidden_gem_pre_remaining_min: float = 75.0
    hidden_gem_pre_imminence_min: float = 82.0
    hidden_gem_pre_released_max: float = 45.0
    hidden_gem_pre_flow_min: float = 60.0
    hidden_gem_pre_sell_failure_min: float = 55.0
    hidden_gem_pre_supply_decay_min: float = 55.0
    hidden_gem_pre_exhaustion_score_min: float = 60.0
    hidden_gem_entry_imminence_min: float = 90.0
    # Pipeline-only guards; scoring thresholds/PRICE HOLD/DATA TRUTH remain unchanged.
    priority_idle_sec: float = 600.0
    discovery_new_sec: float = 180.0
    discovery_fresh_slots: int = 6
    latency_sample_size: int = 300
    event_loop_probe_sec: float = 0.5
    # Early-data promotion: bounded enrichment for fresh hidden-gem probes.
    probe_rest_confirm_min_score: float = 60.0
    probe_rest_confirm_cooldown_sec: float = 20.0
    urgent_baseline_min_score: float = 60.0
    urgent_baseline_cooldown_sec: float = 20.0
    quote_newcomer_slots: int = 2
    quote_rotation_sec: float = 12.0
    # Exchange-closure override. Built-in 2026 KRX closures are handled in runtime;
    # this comma-separated list is for future/extra KRX-declared or temporary closures.
    krx_closed_dates: str = ''
