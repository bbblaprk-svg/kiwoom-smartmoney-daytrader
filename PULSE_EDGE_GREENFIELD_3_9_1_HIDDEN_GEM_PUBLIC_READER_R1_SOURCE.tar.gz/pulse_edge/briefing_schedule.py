"""Korea-time hourly briefing clock for the ChatGPT public reader.

The clock is deliberately independent from the live venue clock.  A normal
trading day still has a 20:30 briefing even though NXT may already be closed;
the payload must then be marked CLOSED rather than treated as a live signal.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")
BRIEFING_MINUTES = tuple(range(8 * 60 + 30, 20 * 60 + 31, 60))
BRIEFING_LABELS = tuple(
    f"{minute // 60:02d}:{minute % 60:02d}" for minute in BRIEFING_MINUTES
)


def _closed_set(closed_dates: str | set[str] | tuple[str, ...] | None) -> set[str]:
    if not closed_dates:
        return set()
    if isinstance(closed_dates, str):
        return {x.strip() for x in closed_dates.split(",") if x.strip()}
    return {str(x).strip() for x in closed_dates if str(x).strip()}


def is_weekday_trading_day(day: date, closed_dates=None) -> bool:
    """Return the configurable calendar gate used by the public briefing.

    The runtime supplies its KRX holiday/closure decision separately.  This
    helper handles the deterministic weekday and extra-closure portion and is
    also safe to use by a scheduler before the feed has started.
    """
    return day.weekday() < 5 and day.isoformat() not in _closed_set(closed_dates)


def is_trading_day(day: date, closed_dates=None) -> bool:
    """Use the runtime's built-in KRX closure calendar when available."""
    if not is_weekday_trading_day(day, closed_dates):
        return False
    try:
        from pulse_edge.runtime import venue_for_kst

        probe = datetime.combine(day, time(9, 30), tzinfo=KST)
        return venue_for_kst(probe, closed_dates) is not None
    except Exception:
        # The standalone scheduler remains usable in tests or before the
        # runtime module is importable; configured weekday gates still apply.
        return True


def slot_start(day: date, minute_of_day: int) -> datetime:
    return datetime.combine(
        day, time(minute_of_day // 60, minute_of_day % 60), tzinfo=KST
    )


def active_slot(now: datetime | None = None, *, grace_seconds: int = 600,
                closed_dates=None) -> dict | None:
    """Return the current half-hour slot when a report is due.

    The ten-minute grace window tolerates scheduler/network jitter while
    preserving exactly one logical slot per hour.  The caller must still
    deduplicate by ``slot_id`` before delivering a message.
    """
    current = (now or datetime.now(KST)).astimezone(KST)
    if not is_trading_day(current.date(), closed_dates):
        return None
    for minute in BRIEFING_MINUTES:
        start = slot_start(current.date(), minute)
        age = (current - start).total_seconds()
        if 0 <= age <= grace_seconds:
            return {
                "slot_id": start.strftime("%Y%m%d-%H%M"),
                "scheduled_at": start.isoformat(),
                "label": start.strftime("%H:%M"),
                "age_sec": round(age, 3),
            }
    return None


def next_slot(now: datetime | None = None, *, closed_dates=None) -> datetime | None:
    current = (now or datetime.now(KST)).astimezone(KST)
    for offset in range(0, 370):
        day = current.date() + timedelta(days=offset)
        if not is_trading_day(day, closed_dates):
            continue
        for minute in BRIEFING_MINUTES:
            candidate = slot_start(day, minute)
            if candidate > current:
                return candidate
    return None


def schedule_metadata(*, closed_dates=None) -> dict:
    return {
        "timezone": "Asia/Seoul",
        "trading_day_only": True,
        "window": "08:30-20:30",
        "frequency": "HOURLY_AT_HALF_HOUR",
        "slots": list(BRIEFING_LABELS),
        "slot_count": len(BRIEFING_MINUTES),
        "extra_closed_dates": sorted(_closed_set(closed_dates)),
    }
