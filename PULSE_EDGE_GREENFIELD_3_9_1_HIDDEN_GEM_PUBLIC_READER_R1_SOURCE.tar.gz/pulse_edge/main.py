from __future__ import annotations
from contextlib import asynccontextmanager
from fastapi import FastAPI,Query,Request,HTTPException
from fastapi.responses import FileResponse,JSONResponse
from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime
from pulse_edge.presentation import eligible_now,enrich,diagnostics
from pulse_edge.briefing_schedule import active_slot,next_slot,schedule_metadata

S=Settings(); R=Runtime(S); WEB=Path(__file__).with_name('web')
@asynccontextmanager
async def lifespan(app):
    await R.start(); yield; await R.stop()
app=FastAPI(title='PULSE EDGE REALTIME HIDDEN GEM 3.9.1 PUBLIC READER',lifespan=lifespan)
@app.get('/health')
def health(): return R.health()
@app.get('/api/readiness')
def readiness():
    r=R.readiness(); return JSONResponse(r,status_code=200 if r['ready'] else 503)
def _latest_unique_now_snapshot(limit:int, *, live_fallback:bool=False):
    """Return a deduplicated last-valid NOW snapshot without creating a new signal.

    Closed session: keep the latest trade-day candidates through 07:30 KST next day.
    Live session: only bridge a short selector/feed wobble (10 minutes) and only when
    the corresponding state is still fresh on the active venue.
    """
    from datetime import datetime, time as dtime
    from zoneinfo import ZoneInfo
    import time
    KST=ZoneInfo('Asia/Seoul'); now=time.time(); local_now=datetime.fromtimestamp(now,KST)
    allowed={'EARLY PRESSURE ABSORBED','PRESSURE ABSORBED','ENERGY LOADED','RELEASE WINDOW','RELEASE READY','ABSORB','EARLY HIDDEN GEM','SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}
    out=[]; seen=set(); venue=R.active_venue()
    for r in R.signal_store.recent(S.now_history_limit,'NOW'):
        stage=str(r.get('stage') or '')
        if stage not in allowed: continue
        sym=str(r.get('symbol') or ''); rv=str(r.get('venue') or 'KRX'); ts=float(r.get('history_ts') or 0)
        key=(sym,rv)
        if not sym or key in seen or ts<=0: continue
        if live_fallback:
            if rv!=venue or now-ts>600: continue
            st=R.states.get(f'{sym}:{rv}')
            if st is None or R.scorer.data_status(st,now) not in {'LIVE','CONFIRMED'}: continue
        else:
            sig_dt=datetime.fromtimestamp(ts,KST)
            same_day=(sig_dt.date()==local_now.date())
            next_morning=(local_now.time()<dtime(7,30) and (local_now.date()-sig_dt.date()).days==1)
            if not (same_day or next_morning): continue
        seen.add(key); out.append(r)
        if len(out)>=limit: break
    return out

@app.get('/api/hidden-gem/top')
def top(limit:int=Query(20,ge=1,le=20)):
    # Preserve committed order, refresh values and remove invalidated candidates now.
    current={(x.symbol,x.venue):x for x in R.raw_results}
    ordered=[current[(x.symbol,x.venue)] for x in R.results if (x.symbol,x.venue) in current]
    known={(x.symbol,x.venue) for x in ordered}
    ordered += [x for x in R.raw_results if (x.symbol,x.venue) not in known]
    venue=R.active_venue()
    rows=[x for x in ordered if x.venue==venue and eligible_now(x)][:limit] if venue else []
    source='LIVE_CURRENT'; history_rows=None
    if not rows:
        history_rows=_latest_unique_now_snapshot(limit,live_fallback=bool(venue))
        source='RECENT_SIGNAL_SNAPSHOT' if venue and history_rows else ('HISTORY_SNAPSHOT' if history_rows else 'EMPTY')
    if rows:
        actionable=[x for x in rows if x.suitability in {'A','B'}][:7]
        a=[x.to_dict() for x in actionable if x.suitability=='A']
        b=[x.to_dict() for x in actionable if x.suitability=='B']
        watch=[x.to_dict() for x in rows if x.suitability=='WATCH'][:3]
        all_rows=enrich(R,[x.to_dict() for x in rows])
        message=None if a else '현재 A급 없음 · 관찰 후보 유지'
    else:
        a=[]; b=[]; watch=[]
        all_rows=enrich(R,history_rows or [],history=True)
        if source=='HISTORY_SNAPSHOT': message='장마감 · 오늘 마지막 유효 NOW 후보 보존'
        elif source=='RECENT_SIGNAL_SNAPSHOT': message='실시간 전환 구간 · 최근 유효 NOW 후보 임시 보존'
        else: message='현재 신규 숨은 진주 없음'
    return {'release':S.release,'message':message,'source':source,'a':a,'b':b,'watch':watch,'all':all_rows,'diagnostics':diagnostics(R)}
@app.get('/api/public/hidden-gem/top')
def public_hidden_gem_top(limit:int=Query(20,ge=1,le=20)):
    """Read-only public projection of the existing Hidden Gem engine.

    This endpoint never recalculates candidates, merges venues, places orders, exposes
    broker credentials, or mutates state.  It projects only already-computed rows and
    uses the engine's canonical field names so an external briefing client can consume
    price/change/energy/data-truth fields without schema guessing.
    """
    from datetime import datetime
    from zoneinfo import ZoneInfo
    payload=top(limit)
    health_now=R.health()
    venue=health_now.get('active_venue')
    now_kst=datetime.now(ZoneInfo('Asia/Seoul'))
    sec=now_kst.hour*3600+now_kst.minute*60+now_kst.second
    if venue=='KRX': session='KRX_REGULAR'
    elif venue=='NXT' and 8*3600 <= sec <= 8*3600+50*60: session='NXT_PRE'
    elif venue=='NXT' and 15*3600+40*60 <= sec <= 20*3600: session='NXT_AFTER'
    else: session='CLOSED'

    def clean(row):
        if not isinstance(row,dict): return {}
        live_price=row.get('live_price')
        live_change=row.get('live_change_rate')
        return {
            'symbol':row.get('symbol'),
            'name':row.get('name'),
            'venue':row.get('venue'),
            'session':session if row.get('venue')==venue else ('CLOSED' if venue is None else 'NON_ACTIVE_VENUE'),
            'current_price':live_price if live_price is not None else row.get('current_price'),
            'change_rate':live_change if live_change is not None else row.get('change_rate'),
            'stage':row.get('stage'),
            'precursor_stage':row.get('precursor_stage'),
            'energy_stage':row.get('energy_stage'),
            'suitability':row.get('suitability'),
            'signal_price':row.get('signal_price'),
            'signal_ts':row.get('signal_ts'),
            'energy_stored':row.get('energy_stored'),
            'energy_released':row.get('energy_released'),
            'remaining_energy':row.get('remaining_energy'),
            'release_imminence':row.get('release_imminence'),
            'flow_dislocation':row.get('flow_dislocation'),
            'sell_response_failure':row.get('sell_response_failure'),
            'price_hold':row.get('price_hold'),
            'supply_decay_score':row.get('supply_decay_score'),
            'supply_exhaustion_signals':row.get('supply_exhaustion_signals'),
            'data_status':row.get('data_status'),
            'data_timestamp':row.get('data_timestamp'),
            'price_status':row.get('price_status'),
            'price_timestamp':row.get('price_timestamp'),
            'trigger_10_30m':row.get('trigger_10_30m'),
            'reasons':row.get('reasons') or [],
            'invalidation':row.get('invalidation'),
            'too_late':bool(row.get('too_late')),
            'too_late_reason':row.get('too_late_reason') or '',
        }
    diag=payload.get('diagnostics') or {}
    diag_public={k:diag.get(k) for k in (
        'states','ranked','scope','energy_states','too_late_count','live_ranked_count',
        'display_eligible_count','latent_observe_count','sensor_only_count','subscribed',
        'subscription_status','subscription_stages','fresh_discovery_count','nxt_verified_count',
        'transport_venue','evaluated_at','no_score_reasons') if k in diag}
    out={
        'release':S.release,
        'read_only':True,
        'generated_at':now_kst.isoformat(),
        'active_venue':venue,
        'session':session,
        'ws_connected':health_now.get('ws_connected'),
        'channel_age_sec':health_now.get('channel_age_sec'),
        'source':payload.get('source'),
        'message':payload.get('message'),
        'rows':[clean(x) for x in payload.get('all',[])],
        'diagnostics':diag_public,
    }
    return JSONResponse(out,headers={'Cache-Control':'no-store, max-age=0','X-PULSE-READ-ONLY':'1'})

@app.get('/api/public/chatgpt/briefing')
def chatgpt_briefing(limit:int=Query(10,ge=1,le=10)):
    """Hourly ChatGPT handoff; read-only and schedule-gated.

    ChatGPT calls this endpoint at the half-hour.  The endpoint itself remains
    authoritative about the Korean trading-day calendar, so weekends, KRX
    holidays, and calls outside 08:30~20:30 never become fabricated reports.
    It reuses the public reader projection and never recalculates or mutates
    the Hidden Gem engine.
    """
    from datetime import datetime
    from zoneinfo import ZoneInfo

    now_kst=datetime.now(ZoneInfo('Asia/Seoul'))
    closed_dates=getattr(S,'krx_closed_dates','')
    meta=schedule_metadata(closed_dates=closed_dates)
    slot=active_slot(now_kst,closed_dates=closed_dates)
    nxt=next_slot(now_kst,closed_dates=closed_dates)
    base={
        'release':S.release,
        'read_only':True,
        'generated_at':now_kst.isoformat(),
        'schedule':meta,
        'slot':slot,
        'next_slot':nxt.isoformat() if nxt else None,
        'should_report':bool(slot),
        'report_reason':'READY' if slot else 'OUTSIDE_SCHEDULE_OR_NON_TRADING_DAY',
        'data_truth_policy':'NO_DELAYED_OR_CROSS_VENUE_DATA_FOR_BUY_DECISION',
        'venue_policy':'KRX_AND_NXT_SEPARATE',
        'rows':[],
        'actionable_rows':[],
    }
    if not slot:
        return JSONResponse(base,headers={'Cache-Control':'no-store, max-age=0','X-PULSE-READ-ONLY':'1'})

    public=public_hidden_gem_top(limit)
    health=R.health()
    active_venue=public.get('active_venue')
    ws_live=bool(public.get('ws_connected') and active_venue)
    channel_age=public.get('channel_age_sec')
    live_verified=bool(ws_live and channel_age is not None and float(channel_age)<=10.0)
    rows=public.get('rows') or []
    actionable=[]
    for row in rows:
        if row.get('venue')!=active_venue or row.get('session') in {'CLOSED','NON_ACTIVE_VENUE'}:
            continue
        if row.get('data_status') not in {'LIVE','CONFIRMED'}:
            continue
        if row.get('stage') in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'} or row.get('suitability') in {'A','B'}:
            actionable.append(row)
    base.update({
        'active_venue':active_venue,
        'session':public.get('session'),
        'ws_connected':public.get('ws_connected'),
        'channel_age_sec':channel_age,
        'live_market_verified':live_verified,
        'source':public.get('source'),
        'message':public.get('message'),
        'rows':rows,
        'actionable_rows':actionable if live_verified else [],
        'diagnostics':public.get('diagnostics') or {},
        'health':{
            'eval_seq':health.get('eval_seq'),
            'last_eval_ts':health.get('last_eval_ts'),
            'latest_trade_event_ts':health.get('latest_trade_event_ts'),
        },
        'report_rules':[
            'REPORT_ONLY_PRE_ENTRY_RELEASE_INVALIDATION_OR_MARKET_CHANGE',
            'NO_FABRICATED_CANDIDATES_OR_VALUES',
            'STALE_DELAYED_CONFLICT_DATA_IS_NOT_ACTIONABLE',
            'KRX_NXT_PRICE_FLOW_VWAP_VOLUME_NEVER_MIXED',
        ],
    })
    return JSONResponse(base,headers={'Cache-Control':'no-store, max-age=0','X-PULSE-READ-ONLY':'1'})

@app.get('/api/coiled-spring/top')
def coiled_top(limit:int=Query(5,ge=1,le=5)):
    if not S.coiled_enabled:
        return {'release':S.release,'message':'DISABLED_IN_HIDDEN_GEM_PURE','source':'DISABLED','rows':[]}
    rows=R.coiled_results[:limit]
    if rows:
        return {'release':S.release,'message':None,'source':'RECALCULATED','rows':enrich(R,[x.to_dict() for x in rows],horizon='1-2D')}
    # Closed-session startup can precede the first daily-context refresh. Preserve the
    # latest unique 1-2D candidates from the bounded history instead of flashing an empty table.
    if R.active_venue() is None:
        hist=R.signal_store.recent(S.coiled_history_limit,'1-2D'); out=[]; seen=set()
        for r in hist:
            sym=str(r.get('symbol') or '')
            if not sym or sym in seen: continue
            seen.add(sym); out.append(r)
            if len(out)>=limit: break
        if out:
            return {'release':S.release,'message':'휴장 · 최근 1~2D 후보 보존','source':'HISTORY_SNAPSHOT','rows':enrich(R,out,history=True,horizon='1-2D')}
    return {'release':S.release,'message':'현재 신규 1~2D 응축 후보 없음','source':'EMPTY','rows':[]}
@app.get('/api/signal-history')
def signal_history(limit:int=Query(100,ge=1,le=400),horizon:str|None=None):
    h='NOW' if horizon=='NOW' else ('1-2D' if horizon=='1-2D' else None)
    return {'limit':S.history_limit,'horizon':h,'rows':R.signal_store.recent(limit,h)}

@app.get('/api/history/now')
def history_now(limit:int=Query(200,ge=1,le=200)):
    return {'limit':S.now_history_limit,'rows':enrich(R,R.signal_store.recent(limit,'NOW'),history=True)}

@app.get('/api/history/coiled')
def history_coiled(limit:int=Query(200,ge=1,le=200)):
    if not S.coiled_enabled: return {'limit':0,'rows':[],'message':'DISABLED_IN_HIDDEN_GEM_PURE'}
    return {'limit':S.coiled_history_limit,'rows':enrich(R,R.signal_store.recent(limit,'1-2D'),history=True,horizon='1-2D')}

@app.get('/api/symbol-current')
def symbol_current(symbol:str,horizon:str='NOW'):
    symbol=''.join(c for c in str(symbol or '') if c.isdigit())[:6]
    if not symbol: raise HTTPException(400,'symbol required')
    if horizon=='1-2D':
        if not S.coiled_enabled: return {'found':False,'symbol':symbol,'horizon':'1-2D','message':'DISABLED_IN_HIDDEN_GEM_PURE'}
        from pulse_edge.engine.coiled import score_coiled
        st=next((x for x in R.states.values() if x.symbol==symbol and x.venue=='KRX'),None)
        if not st: return {'found':False,'symbol':symbol,'horizon':'1-2D'}
        c=score_coiled(st,{x.symbol for x in R.raw_results if x.stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}})
        return {'found':bool(c),'symbol':symbol,'horizon':'1-2D','row':c.to_dict() if c else None}
    c=next((x for x in R.raw_results if x.symbol==symbol),None) or next((x for x in R.results if x.symbol==symbol),None)
    return {'found':bool(c),'symbol':symbol,'horizon':'NOW','row':c.to_dict() if c else None}
@app.get('/api/push/public-key')
def push_key(): return {'enabled':bool(S.push_enabled and S.vapid_public_key and S.vapid_private_key),'public_key':S.vapid_public_key}
@app.post('/api/push/subscribe')
async def push_subscribe(req:Request):
    body=await req.json()
    try: R.signal_store.subscribe(body)
    except ValueError as e: raise HTTPException(400,str(e))
    return {'ok':True}
@app.post('/api/push/unsubscribe')
async def push_unsubscribe(req:Request):
    body=await req.json(); R.signal_store.unsubscribe(str(body.get('endpoint') or '')); return {'ok':True}
@app.post('/api/news-signal')
async def news_signal(req:Request):
    body=await req.json()
    if not S.news_webhook_secret:
        raise HTTPException(503,'news adapter not configured')
    if str(body.get('secret') or '')!=S.news_webhook_secret:
        raise HTTPException(403,'invalid news signal secret')
    symbol=''.join(c for c in str(body.get('symbol') or '') if c.isdigit())[:6]
    if not symbol: raise HTTPException(400,'symbol required')
    touched=R.ingest_news_signal(symbol,bool(body.get('hot')),bool(body.get('catalyst')),body.get('risk'))
    return {'ok':True,'symbol':symbol,'states_updated':touched}

@app.get('/api/runtime-truth')
def truth(): return R.health()
@app.get('/api/feed-truth')
def feed_truth():
    h=R.health()
    return {'ws_connected':R.ws.connected,'last_message':R.ws.last_message,'active_venue':R.active_venue(),'quote_focus':list(R.quote_focus_key),
            'market_index_age_sec':h.get('market_index_age_sec'),'nxt_market_proxy':h.get('nxt_market_proxy'),'channel_age_sec':h.get('channel_age_sec'),
            'probe_promoted':h.get('probe_promoted'),'data_truth_policy':'NO_DELAYED_OR_CROSS_VENUE_DATA_FOR_BUY_DECISION'}
@app.get('/api/session')
def session(): return {'release':S.release,'mode':'GREENFIELD','active_venue':R.active_venue(),'automatic_orders':False}
@app.get('/')
def root(): return FileResponse(WEB/'index.html',headers={'Cache-Control':'no-store'})
@app.get('/pulse.js')
def js(): return FileResponse(WEB/'pulse.js',media_type='application/javascript',headers={'Cache-Control':'no-store'})
@app.get('/pulse.css')
def css(): return FileResponse(WEB/'pulse.css',media_type='text/css',headers={'Cache-Control':'no-store'})
@app.get('/sw.js')
def sw(): return FileResponse(WEB/'sw.js',media_type='application/javascript',headers={'Service-Worker-Allowed':'/','Cache-Control':'no-cache'})
