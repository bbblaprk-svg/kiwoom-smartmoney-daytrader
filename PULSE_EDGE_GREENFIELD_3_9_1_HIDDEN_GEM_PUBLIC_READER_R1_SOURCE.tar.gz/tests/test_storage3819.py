import asyncio,sqlite3,time,threading
from pulse_edge.runtime import Runtime
from pulse_edge.config import Settings

def runtime(tmp_path):
    return Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))

def test_real_sqlite_lock_does_not_stop_event_loop(tmp_path):
    async def run():
        r=runtime(tmp_path)
        other=sqlite3.connect(r.baseline.path,check_same_thread=False)
        other.execute('BEGIN IMMEDIATE')
        gaps=[];last=time.perf_counter()
        async def monitor():
            nonlocal last
            for _ in range(150):
                await asyncio.sleep(.02);n=time.perf_counter();gaps.append(n-last);last=n
        def unlock():
            time.sleep(2.4);other.rollback();other.close()
        t=threading.Thread(target=unlock);t.start()
        await asyncio.gather(monitor(),r._db_call(r.baseline.record_many,[('123456','KRX',time.time(),100)]))
        t.join()
        assert max(gaps)<.2,max(gaps)
        assert r.baseline.history_days('123456','KRX')==1
        assert r.db_metrics['record_many']['last_ms']>=2000
        await r.stop()
    asyncio.run(run())

def test_db_calls_serialize_and_cancel_does_not_abandon_write(tmp_path):
    async def run():
        r=runtime(tmp_path);active=0;peak=0;done=[]
        def job(i):
            nonlocal active,peak
            active+=1;peak=max(active,peak);time.sleep(.1);done.append(i);active-=1
        a=asyncio.create_task(r._db_call(job,1));b=asyncio.create_task(r._db_call(job,2))
        await asyncio.sleep(.03);a.cancel()
        await asyncio.gather(a,b,return_exceptions=True)
        assert peak==1 and done==[1,2] and r.db_waiting==0
        await r.stop()
    asyncio.run(run())

def test_snapshot_has_no_database_access_and_expires(tmp_path):
    r=runtime(tmp_path);n=time.time()
    view=r._baseline_snapshot([('123456','KRX')],n)
    r.baseline.rvol=lambda *a: (_ for _ in ()).throw(AssertionError('DB accessed'))
    assert view.rvol('123456','KRX',n,100)==(None,0)
    assert view.rvol('123456','KRX',n+60,100)==(None,0)
    asyncio.run(r.stop())

def test_evaluate_uses_worker_for_storage_calls(tmp_path):
    from test_logic import build_states
    async def run():
        r=runtime(tmp_path);_,sc,states=build_states();r.scorer=sc;r.states=states
        r.active_venue=lambda:'KRX'  # isolate storage-thread behavior from wall-clock venue
        main=threading.get_ident();original_recent=r.signal_store.recent
        def recent(*args):
            assert threading.get_ident()!=main
            return original_recent(*args)
        def rvol(*args):
            assert threading.get_ident()!=main
            return .00000002,20
        r.signal_store.recent=recent;r.baseline.rvol=rvol
        await r.evaluate()
        assert r.eval_seq==1 and r.scorer.last_evaluated
        await r.stop()
    asyncio.run(run())

def test_failed_signal_save_can_be_retried(tmp_path):
    async def run():
        r=runtime(tmp_path);key=('123456','KRX')
        r.signal_last[key]={};r.precursor_last[key]={};r.coiled_last[key[0]]={}
        def fail(*args):raise sqlite3.OperationalError('database is locked')
        r.signal_store.add_payload=fail
        try:await r._record_signal(*key,'EARLY HIDDEN GEM',60,{'current_price':100})
        except sqlite3.OperationalError:pass
        else:raise AssertionError('failure hidden')
        assert key not in r.signal_last and key not in r.precursor_last and key[0] not in r.coiled_last
        await r.stop()
    asyncio.run(run())
