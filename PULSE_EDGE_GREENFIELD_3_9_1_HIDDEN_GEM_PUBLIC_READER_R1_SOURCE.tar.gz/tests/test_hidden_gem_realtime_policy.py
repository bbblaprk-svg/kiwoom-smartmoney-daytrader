from pathlib import Path
from pulse_edge.config import Settings

def test_market_red_blocks_entry_not_discovery_or_pre():
    s=Settings()
    assert s.market_red_threshold_pct==-1.5
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'market_red=bool(' in src
    absolute=src[src.index('absolute_gate='):src.index('pre_change_ok=')]
    assert 'market_red' not in absolute
    assert "ignition_event=bool(imminent and trigger_count>=self.s.ignition_trigger_min_count and not market_red)" in src

def test_marketcap_and_leader_are_diagnostics_not_hidden_gem_gates():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'effective_leader_sensor=bool(' in src and 'large_cap_sensor=bool(' in src
    block=src[src.index('absolute_gate='):src.index('ignition_event=')]
    assert 'sensor_only' not in block

def test_discovery_is_source_interleave_not_sector_first_priority():
    src=Path('pulse_edge/runtime.py').read_text()
    assert 'discovered=interleave_unique(buckets' in src
    assert 'discovered=self._sector_first_discovery(buckets' not in src

def test_fast_hold_is_watch_only_and_never_pre_bypass():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'def early_price_hold' in src
    block=src[src.index('pre_common='):src.index('ignition_event=')]
    assert 'early_hold' not in block
    assert 'pressure_absorbed' in block
    assert 'release_ready or release_window or exhaustion' in block

def test_program_direction_acceleration_is_energy_evidence():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    run=Path('pulse_edge/runtime.py').read_text()
    assert 'def program_metrics' in src
    assert 'program_delta_5m' in src and 'program_accel' in src
    assert 'st.program_hist.append((ev,pn))' in run
