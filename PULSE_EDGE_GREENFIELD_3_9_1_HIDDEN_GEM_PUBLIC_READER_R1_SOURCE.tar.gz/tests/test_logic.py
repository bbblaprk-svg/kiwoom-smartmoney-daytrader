import asyncio, tempfile, time
from datetime import datetime,timedelta
from pathlib import Path
from pulse_edge.feed.kiwoom import symbol_of,num,money_krw,FID
from pulse_edge.config import Settings
from pulse_edge.models import SymbolState,Trade,Quote,InvestorSnapshot
from pulse_edge.engine.scorer import Scorer
from pulse_edge.engine.features import rising_lows,sell_pulse_recovery
from pulse_edge.runtime import Runtime,venue_for_kst,interleave_unique

class DummyBaseline:
    def rvol(self,*args): return (2.0,20)

def build_states(spread=0.001,cross_div=0.0,target_change=1.5):
    s=Settings(_env_file=None,feed_enabled=False); sc=Scorer(s,DummyBaseline()); now=time.time()
    sc.market_change['KOSDAQ']=0.0; sc.market_ts['KOSDAQ']=now
    states={}
    specs=[('000001',target_change,0),('000002',1.0,50),('000003',1.2,80),('000004',3.8,120)]
    for sym,chg,off in specs:
        st=SymbolState(sym,'S'+sym,'KOSDAQ','반도체',False,100_000_000,venue='KRX',price=10020+off,change_rate=chg,last_event_ts=now,last_receive_ts=now,last_trade_event_ts=now,last_trade_receive_ts=now,last_quote_event_ts=now,last_quote_receive_ts=now,last_program_event_ts=now,last_program_receive_ts=now,program_net=500_000_000,first_seen_ts=now-2000)
        st.rest_price=st.price*(1+cross_div); st.rest_price_ts=now; st.rest_venue='KRX'; st.prev_close=st.price/(1+chg/100)
        for i in range(200):
            age=(200-i)*6
            if age>900: low,span=9700+off,200
            elif age>600: low,span=9800+off,150
            elif age>300: low,span=9900+off,100
            else: low,span=9970+off,18
            p=low+span*(0.25+0.75*((i%10)/9))
            if 510<age<=570: p=10000+off
            if 450<age<=510: p=9900+off+(510-age)/60*20
            if age<=30: p=10020+off
            vol=40000 if age<=300 else (6000 if age<=600 else 4000)
            signed=vol if i%6 else -vol*0.15
            st.trades.append(Trade(now-age,p,abs(signed),buy_exec=max(signed,0),sell_exec=max(-signed,0),strength=190))
        ask=st.price*(1+spread/2); bid=st.price*(1-spread/2)
        for i in range(100): st.quotes.append(Quote(now-(100-i)*2,ask,bid,max(30,2500-i*23),1400+i*18,3000,14000))
        st.investor_hist.extend([InvestorSnapshot(now-900,0,0,0,'CONFIRMED'),InvestorSnapshot(now-600,100e6,-600e6,0,'CONFIRMED'),InvestorSnapshot(now-300,400e6,-1_000e6,0,'CONFIRMED'),InvestorSnapshot(now,1_200e6,-1_100e6,0,'CONFIRMED')])
        K=__import__('zoneinfo').ZoneInfo('Asia/Seoul'); md=datetime.fromtimestamp(now,K).replace(second=0,microsecond=0)
        for j in range(1,11):
            x=md-timedelta(minutes=j); st.minute_amount[x.hour*100+x.minute]=100_000_000
        states[sym+':KRX']=st; sc.daily_changes[sym]=(1.0,3.0,5.0)
    return s,sc,states

def test_symbol_and_fid_contract():
    assert symbol_of('005930_NX')=='005930'
    assert symbol_of('001')==''
    assert num('+1,234.5')==1234.5
    assert FID['0B']['228']=='trade_strength'
    assert money_krw('483')==483_000_000

def test_default_pure_engine_reaches_supply_exhaustion_before_strict_pre():
    _,sc,states=build_states(); st=states['000001:KRX']
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert rising_lows(st)
    rec,extra,atr=sell_pulse_recovery(st); assert rec>=0.60 and extra<=0.50 and atr>0
    assert c.price_hold=='PASS'; assert c.stage=='SUPPLY EXHAUSTION'; assert c.detection_model=='HIDDEN_GEM_PURE'; assert c.total_score>=80

def test_pure_pre_gate_is_reachable_without_model_a_b():
    _,sc,states=build_states(); st=states['000001:KRX']
    sc.s.hidden_gem_pre_stored_min=75; sc.s.hidden_gem_pre_remaining_min=60; sc.s.hidden_gem_pre_imminence_min=65
    sc.s.hidden_gem_pre_released_max=50; sc.s.hidden_gem_pre_flow_min=60; sc.s.hidden_gem_pre_sell_failure_min=55
    sc.s.hidden_gem_pre_supply_decay_min=55; sc.s.hidden_gem_pre_exhaustion_score_min=60; sc.s.hidden_gem_entry_imminence_min=95
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert c.stage=='PRE-IGNITION' and c.suitability=='A' and c.detection_model=='HIDDEN_GEM_PURE'

def test_spread_gate_cannot_leave_A():
    _,sc,states=build_states(spread=0.010)
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.suitability!='A'; assert c.stage not in {'PRE-IGNITION','IGNITION IMMINENT'}
    assert any(x=='SPREAD_OK=False' for x in c.reasons)

def test_cross_source_recheck_and_conflict():
    _,sc,states=build_states(cross_div=0.002)
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.data_status=='ESTIMATED'; assert c.suitability=='WATCH'
    _,sc2,states2=build_states(cross_div=0.004)
    c2=sc2.score(states2['000001:KRX'],states2,sc2.sector_stats(states2))[1]
    assert c2.data_status=='CONFLICT'; assert c2.suitability=='WATCH'

def test_heat_penalty_precedes_stage():
    _,sc,states=build_states(target_change=3.5)
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.total_score<88
    assert c.stage not in {'PRE-IGNITION','IGNITION IMMINENT'}

def test_sector_stats_do_not_mix_venues():
    _,sc,states=build_states()
    base=states['000002:KRX']
    nx=SymbolState('999999','NX','KOSDAQ','반도체',False,100_000_000,venue='NXT',price=10000,change_rate=-4,last_event_ts=time.time(),last_receive_ts=time.time())
    states['999999:NXT']=nx
    sec=sc.sector_stats(states)
    assert ('KRX','KOSDAQ','반도체') in sec
    assert sec[('KRX','KOSDAQ','반도체')]['sample']==4




def test_discovery_priority_round_robin_prevents_market_source_monopoly():
    buckets=[['K21A','K21B','K21C'],['K22A','K22B'],['Q21A','Q21B','Q21C'],['Q23A','Q23B']]
    out=interleave_unique(buckets,8)
    assert out==['K21A','K22A','Q21A','Q23A','K21B','K22B','Q21B','Q23B']

def test_session_venue_schedule_has_nxt_gaps_and_krx_only_overlap():
    def d(h,m,s=0): return datetime(2026,9,10,h,m,s,tzinfo=__import__('zoneinfo').ZoneInfo('Asia/Seoul'))
    assert venue_for_kst(d(8,0))=='NXT'
    assert venue_for_kst(d(8,49,59))=='NXT'
    assert venue_for_kst(d(8,51)) is None
    assert venue_for_kst(d(9,0))=='KRX'
    assert venue_for_kst(d(12,0))=='KRX'  # overlapping NXT main market is deliberately ignored
    assert venue_for_kst(d(15,30,1)) is None
    assert venue_for_kst(d(15,39,59)) is None
    assert venue_for_kst(d(15,40))=='NXT'
    assert venue_for_kst(d(20,0))=='NXT'
    assert venue_for_kst(d(20,0,1)) is None

def test_nxt_never_reuses_krx_market_index():
    s=Settings(_env_file=None,feed_enabled=False); sc=Scorer(s,DummyBaseline()); now=time.time()
    sc.market_change['KOSDAQ']=1.25; sc.market_ts['KOSDAQ']=now
    assert sc.market_snapshot('KOSDAQ','KRX')==(1.25,True,1)
    assert sc.market_snapshot('KOSDAQ','NXT')==(None,False,0)

def test_runtime_index_and_signed_fid15():
    with tempfile.TemporaryDirectory() as td:
        s=Settings(_env_file=None,feed_enabled=False,data_dir=td,baseline_db=str(Path(td)/'b.sqlite3'),history_db=str(Path(td)/'h.sqlite3'))
        r=Runtime(s)
        now=time.time()
        tm=datetime.now(__import__('zoneinfo').ZoneInfo('Asia/Seoul')).strftime('%H%M%S')
        asyncio.run(r.on_event({'type':'0J','symbol':'001','venue':'KRX','data':{'change_rate':'-0.55','trade_time':tm},'receive_ts':now}))
        assert r.scorer.market_change['KOSPI']==-0.55 and abs(r.scorer.market_ts['KOSPI']-now)<2
        asyncio.run(r.on_event({'type':'0B','symbol':'123456','venue':'KRX','data':{'price':'10000','change_rate':'1.0','trade_volume':'+100','trade_strength':'135','trade_time':'101011'},'receive_ts':now}))
        t=r.state('123456','KRX').trades[-1]; assert t.buy_exec==100 and t.sell_exec==0 and t.strength==135
        asyncio.run(r.on_event({'type':'0B','symbol':'123456','venue':'KRX','data':{'price':'9990','change_rate':'0.9','trade_volume':'-70','trade_strength':'95','trade_time':'101012'},'receive_ts':now}))
        t=r.state('123456','KRX').trades[-1]; assert t.buy_exec==0 and t.sell_exec==70
        asyncio.run(r.on_event({'type':'0w','symbol':'123456','venue':'KRX','data':{'program_net_buy_amount':'483','trade_time':'101013'},'receive_ts':now}))
        assert r.state('123456','KRX').program_net==483_000_000

def test_ws_quote_focus_limits_depth_subscription():
    class DummyAuth: pass
    class FakeWS:
        def __init__(self): self.sent=[]
        async def send(self,x): self.sent.append(x)
    async def go():
        from pulse_edge.feed.kiwoom import WS
        w=WS('wss://x',DummyAuth(),lambda e:None,max_items=34,reserve=10,quote_focus_items=4)
        w.connected=True; w.ws=FakeWS(); w.priority=[f'{i:06d}' for i in range(24)]; w.background=[f'{100+i:06d}' for i in range(10)]
        w.quote_focus=w.priority[:8]
        await w.refresh()
        import json
        packets=[json.loads(x) for x in w.ws.sent]
        broad=next(p for p in packets if p['grp_no']==str(w.group_base))
        depth=next(p for p in packets if p['grp_no']==str(w.group_base+1))
        assert len(broad['data'][0]['item'])==34
        assert broad['data'][0]['type']==['0B','0w']
        assert len(depth['data'][0]['item'])==4 and depth['data'][0]['type']==['0D']
    asyncio.run(go())


def test_fresh_quote_or_program_cannot_mask_stale_trade():
    s=Settings(_env_file=None,feed_enabled=False); sc=Scorer(s,DummyBaseline()); now=time.time()
    st=SymbolState('123456','X','KOSDAQ','반도체',False,100_000_000,venue='KRX',price=10000,change_rate=1.0,
                   last_event_ts=now,last_receive_ts=now,last_trade_event_ts=now-180,last_trade_receive_ts=now-180,
                   last_quote_event_ts=now,last_quote_receive_ts=now,last_program_event_ts=now,last_program_receive_ts=now,program_net=1)
    assert sc.data_status(st,now)=='STALE'


def test_nxt_market_proxy_is_nxt_native_and_pure_engine_uses_it():
    s,_,krx=build_states(); sc=Scorer(s,DummyBaseline()); now=time.time(); states={}
    for i,(key,old) in enumerate(krx.items()):
        st=old; st.venue='NXT'; st.nxt_enabled=True; st.rest_venue='NXT'; st.last_trade_receive_ts=now; st.last_trade_event_ts=now
        st.last_quote_receive_ts=now; st.last_quote_event_ts=now; st.last_program_receive_ts=now; st.last_program_event_ts=now
        states[f'{st.symbol}:NXT']=st; sc.daily_changes[st.symbol]=(1.0,3.0,5.0)
    # fifth NXT-native observation makes the market proxy independently usable.
    extra=SymbolState('000005','S5','KOSDAQ','반도체',True,100_000_000,venue='NXT',price=10000,change_rate=0.9,
                      last_trade_event_ts=now,last_trade_receive_ts=now,last_event_ts=now,last_receive_ts=now,first_seen_ts=now)
    extra.trades.extend([Trade(now-2,9999,100,buy_exec=100,strength=130),Trade(now-1,10000,100,buy_exec=100,strength=130)])
    states['000005:NXT']=extra
    sc.update_venue_market_proxies(states,now)
    mv,fresh,sample=sc.market_snapshot('KOSDAQ','NXT',now)
    assert fresh and sample>=5 and mv is not None
    c=sc.score(states['000001:NXT'],states,sc.sector_stats(states,now),now)[1]
    assert c.detection_model=='HIDDEN_GEM_PURE' and c.data_status in {'LIVE','CONFIRMED'}


def test_readiness_feed_off_is_deterministic():
    with tempfile.TemporaryDirectory() as td:
        s=Settings(_env_file=None,feed_enabled=False,data_dir=td,baseline_db=str(Path(td)/'b.sqlite3'),history_db=str(Path(td)/'h.sqlite3'))
        r=Runtime(s); q=r.readiness()
        assert q['ready'] is True and q['checks']['ws_connected'] is True


def test_conflict_stops_hold_and_probability_computation():
    _,sc,states=build_states(cross_div=0.004)
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.data_status=='CONFLICT'
    assert c.stage=='DATA CHECK'
    assert c.price_hold=='UNCONFIRMED'
    assert c.ignition_probability==0
    assert c.total_score==0
    assert 'DATA_TRUTH_FAIL_STOPPED' in c.reasons


def test_investor_flow_unavailable_does_not_switch_to_legacy_model_b():
    _,sc,states=build_states(); st=states['000001:KRX']
    # Remove investor confirmation so A path is unavailable while B microstructure remains strong.
    st.investor_hist.clear()
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert c.detection_model=='HIDDEN_GEM_PURE'
    assert c.stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT','IGNITION','WATCH','ABSORB'}


def test_sector_leader_is_diagnostic_only():
    _,sc,states=build_states()
    c=sc.score(states['000004:KRX'],states,sc.sector_stats(states))[1]
    assert c.leader_sensor is True
    assert c.stage!='SENSOR'

def test_investor_metrics_require_three_improving_5m_windows():
    _,sc,states=build_states(); st=states['000001:KRX']
    vals=sc.investor_metrics(st)
    assert vals[7] is True   # absorption ratios accelerate across all three windows
    assert vals[8] is True   # institutional sell increments decelerate across all three
    assert vals[9] is True   # foreign buy increments accelerate


def test_tod_rvol_requires_all_ten_completed_minutes():
    from pulse_edge.engine.features import completed_10m_amount
    _,_,states=build_states(); st=states['000001:KRX']; now=time.time()
    total,present=completed_10m_amount(st,now); assert present==10 and total is not None
    st.minute_amount.pop(next(iter(st.minute_amount)))
    total,present=completed_10m_amount(st,now); assert present==9 and total is None


def test_large_trade_score_counts_only_aggressive_buys():
    from pulse_edge.engine.features import large_buy_trade_score
    now=time.time(); st=SymbolState('111111',price=10000,change_rate=1,first_seen_ts=now-1000)
    # ordinary prints establish threshold
    for i in range(10): st.trades.append(Trade(now-100+i,10000,100,buy_exec=100,sell_exec=0,strength=120))
    st.trades.append(Trade(now-10,10000,20000,buy_exec=0,sell_exec=20000,strength=80))
    assert large_buy_trade_score(st,now)==0
    st.trades.append(Trade(now-5,10000,20000,buy_exec=20000,sell_exec=0,strength=160))
    assert large_buy_trade_score(st,now)>0


def test_sector_breadth_has_four_axes_and_laggard_component():
    _,sc,states=build_states(); sec=sc.sector_stats(states)[('KRX','KOSDAQ','반도체')]
    for k in ('up_ratio','vwap_ratio','turnover_ratio','laggard_ratio'): assert sec[k] is not None
    assert 0 <= sec['breadth'] <= 100


def test_rank_tiebreak_contract_fields_present():
    _,sc,states=build_states(); rows=sc.rank(states)
    assert rows
    # Contract: rank can sort with HOLD/exhaustion/turnover/laggard/breadth tie-break without error.
    assert all(hasattr(x,'supply_exhaustion_signals') for x in rows)


def test_daily_context_accepts_15d_supplement_without_changing_final_1_5d_contract():
    _,sc,states=build_states(); sc.daily_changes['000001']=(1.0,3.0,5.0,8.0)
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    assert c.change_15d==8.0
    assert c.persistence_15d_score is not None
