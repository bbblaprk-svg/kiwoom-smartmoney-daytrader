import time
from datetime import datetime
from zoneinfo import ZoneInfo
from types import SimpleNamespace as NS
import pulse_edge.main as main

KST=ZoneInfo('Asia/Seoul')

class Store:
    def __init__(self,rows): self.rows=rows
    def recent(self,*a,**k): return list(self.rows)

class Scorer:
    def data_status(self,st,now): return getattr(st,'status','STALE')

def ts(y,m,d,hh,mm): return datetime(y,m,d,hh,mm,tzinfo=KST).timestamp()

def test_snapshot_dedupes_and_keeps_latest_symbol(monkeypatch):
    rows=[
      {'symbol':'000001','venue':'KRX','stage':'RELEASE READY','history_ts':ts(2026,9,15,15,20),'current_price':100},
      {'symbol':'000001','venue':'KRX','stage':'PRESSURE ABSORBED','history_ts':ts(2026,9,15,15,10),'current_price':99},
      {'symbol':'000002','venue':'KRX','stage':'EARLY HIDDEN GEM','history_ts':ts(2026,9,15,14,0),'current_price':200},
    ]
    fake=NS(signal_store=Store(rows),active_venue=lambda:None,states={},scorer=Scorer())
    monkeypatch.setattr(main,'R',fake)
    monkeypatch.setattr(main.time if hasattr(main,'time') else time,'time',lambda:ts(2026,9,15,23,30),raising=False)
    # main helper imports time locally, so patch module globally through time module.
    monkeypatch.setattr(time,'time',lambda:ts(2026,9,15,23,30))
    out=main._latest_unique_now_snapshot(10,live_fallback=False)
    assert [r['symbol'] for r in out]==['000001','000002']
    assert out[0]['stage']=='RELEASE READY'

def test_snapshot_survives_next_morning_until_0730(monkeypatch):
    rows=[{'symbol':'000001','venue':'KRX','stage':'RELEASE READY','history_ts':ts(2026,9,15,15,20),'current_price':100}]
    fake=NS(signal_store=Store(rows),active_venue=lambda:None,states={},scorer=Scorer())
    monkeypatch.setattr(main,'R',fake)
    monkeypatch.setattr(time,'time',lambda:ts(2026,9,16,7,29))
    assert len(main._latest_unique_now_snapshot(10,live_fallback=False))==1
    monkeypatch.setattr(time,'time',lambda:ts(2026,9,16,7,30))
    assert main._latest_unique_now_snapshot(10,live_fallback=False)==[]

def test_live_fallback_requires_recent_fresh_current_state(monkeypatch):
    rows=[{'symbol':'000001','venue':'KRX','stage':'PRESSURE ABSORBED','history_ts':ts(2026,9,15,11,0),'current_price':100}]
    fake=NS(signal_store=Store(rows),active_venue=lambda:'KRX',states={'000001:KRX':NS(status='LIVE')},scorer=Scorer())
    monkeypatch.setattr(main,'R',fake)
    monkeypatch.setattr(time,'time',lambda:ts(2026,9,15,11,9))
    assert len(main._latest_unique_now_snapshot(10,live_fallback=True))==1
    fake.states['000001:KRX'].status='STALE'
    assert main._latest_unique_now_snapshot(10,live_fallback=True)==[]
