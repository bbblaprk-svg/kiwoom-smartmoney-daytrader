from pathlib import Path

def test_pre_requires_pressure_absorption_and_release_structure():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('pre_common='):r.index('ignition_event=')]
    assert 'pre=bool(pre_common' in block
    assert 'pressure_absorbed' in block
    assert 'release_ready or release_window or exhaustion' in block
    assert 'model_a_ready' not in block and 'model_b_ready' not in block

def test_release_ready_itself_requires_pressure_absorbed():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'release_ready=bool(pressure_absorbed and' in r

def test_entry_trigger_excludes_sector_sync_and_market_red():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert "k not in {'TRADE_SPEED_ACCEL','SECTOR_LAGGARD_SYNC'}" in r
    assert 'and not market_red' in r[r.index('ignition_event='):r.index("if too_late: stage='TOO LATE'")]
