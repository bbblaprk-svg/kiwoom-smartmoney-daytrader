from pathlib import Path


def test_display_name_prefers_name_and_strips_nxt_suffix_only_on_fallback():
    js=Path('pulse_edge/web/pulse.js').read_text()
    assert "function displayName(r)" in js
    assert "if(n)return n" in js
    assert "return s.replace(/_NX$/,'')||'-'" in js


def test_all_visible_symbol_cells_use_display_name():
    js=Path('pulse_edge/web/pulse.js').read_text()
    # NOW, COILED, DETAIL and both histories must use the same display helper.
    assert "[i+1,displayName(r),...prices(r)" in js
    assert "displayName(r)" in js
    assert '`종목: ${displayName(r)}`' in js
    assert js.count('displayName(r)') >= 6


def test_current_lookup_keeps_raw_symbol_for_api_but_hides_nxt_suffix_in_message():
    js=Path('pulse_edge/web/pulse.js').read_text()
    assert 'const sym=selected.symbol' in js
    assert 'encodeURIComponent(sym)' in js
    assert '${displayName(selected)}\\n현재 해당 시간축 후보에서 이탈했습니다.' in js


def test_no_candidate_is_filtered_by_missing_name():
    js=Path('pulse_edge/web/pulse.js').read_text()
    # Candidate selection remains stage/precursor based; name is not a gate.
    filt=js[js.index('live=(q.all||[]).slice'):js.index("document.getElementById('nowcount')")]
    assert '.name' not in filt
    assert 'displayName' not in filt
