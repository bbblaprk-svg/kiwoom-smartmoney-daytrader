import importlib, json, sys

def test_public_reader_uses_canonical_candidate_fields(monkeypatch,tmp_path):
    monkeypatch.setenv('PULSE_FEED_ENABLED','false')
    monkeypatch.setenv('PULSE_RELEASE','3.9.1_HIDDEN_GEM_PUBLIC_READER')
    monkeypatch.setenv('PULSE_DATA_DIR',str(tmp_path))
    monkeypatch.setenv('PULSE_BASELINE_DB',str(tmp_path/'b.sqlite3'))
    monkeypatch.setenv('PULSE_HISTORY_DB',str(tmp_path/'h.sqlite3'))
    sys.modules.pop('pulse_edge.main',None)
    m=importlib.import_module('pulse_edge.main')
    row={
      'symbol':'123456','name':'테스트','venue':'NXT','current_price':10100,'change_rate':2.3,
      'live_price':10200,'live_change_rate':3.1,'stage':'FOCUS','precursor_stage':'ENERGY LOADED',
      'energy_stage':'ENERGY LOADED','suitability':'WATCH','signal_price':10000,'signal_ts':1,
      'energy_stored':81,'energy_released':33,'remaining_energy':76,'release_imminence':79,
      'flow_dislocation':66,'sell_response_failure':62,'price_hold':'PASS','supply_decay_score':70,
      'supply_exhaustion_signals':5,'data_status':'LIVE','data_timestamp':'x','price_status':'LIVE',
      'price_timestamp':2,'trigger_10_30m':'x','reasons':['r'],'invalidation':'below vwap',
      'too_late':False,'too_late_reason':''}
    monkeypatch.setattr(m,'top',lambda limit:{'source':'LIVE_CURRENT','message':None,'all':[row],'diagnostics':{'ranked':1}})
    monkeypatch.setattr(m.R,'health',lambda:{'active_venue':'NXT','ws_connected':True,'channel_age_sec':{'trade':1}})
    resp=m.public_hidden_gem_top(3)
    body=json.loads(resp.body)
    assert body['release']=='3.9.1_HIDDEN_GEM_PUBLIC_READER'
    assert body['read_only'] is True
    out=body['rows'][0]
    assert out['current_price']==10200 and out['change_rate']==3.1
    assert out['energy_stored']==81 and out['remaining_energy']==76
    assert out['invalidation']=='below vwap'
    assert 'appkey' not in json.dumps(body).lower() and 'secretkey' not in json.dumps(body).lower()
