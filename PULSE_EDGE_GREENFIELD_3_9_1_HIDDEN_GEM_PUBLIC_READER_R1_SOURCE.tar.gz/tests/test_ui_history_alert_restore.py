from pathlib import Path

def test_ui_hidden_gem_now_still_has_top10_detail_inline():
    js=Path('pulse_edge/web/pulse.js').read_text()
    html=Path('pulse_edge/web/index.html').read_text()
    assert "mk('now',10,10)" in js
    assert '① HIDDEN GEM · NOW TOP10' in html
    assert 'eligible_now' in Path('pulse_edge/main.py').read_text()

def test_early_hidden_gem_is_recordable():
    r=Path('pulse_edge/runtime.py').read_text()
    block=r[r.index('def _signal_changed'):r.index('def _coiled_source_trade_date')]
    assert "'EARLY HIDDEN GEM'" in block

def test_precursor_is_history_only_and_pre_entry_pushes():
    r=Path('pulse_edge/runtime.py').read_text()
    eval_block=r[r.index('for c in raw:'):r.index('if not self.results or',r.index('for c in raw:'))]
    assert '_push_precursor(c)' not in eval_block
    assert '_push(c)' in eval_block
    assert '_push_invalidation(c)' in eval_block

def test_pure_pre_sequence_replaces_legacy_model_lock():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('pre_common='):r.index('ignition_event=')]
    assert 'pressure_absorbed' in block
    assert 'model_a_ready' not in block and 'model_b_ready' not in block
