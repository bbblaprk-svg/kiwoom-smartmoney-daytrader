import asyncio,time
from types import SimpleNamespace as NS
from pulse_edge.presentation import eligible_now
from pulse_edge.runtime import Runtime
from pulse_edge.config import Settings


def c(**kw):
    d=dict(name='테스트',sensor_only=False,data_status='LIVE',stage='WATCH',precursor_stage='OBSERVE',
           energy_stage='BUILDING',energy_stored=60.0,remaining_energy=42.0,too_late=False)
    d.update(kw); return NS(**d)


def test_latent_building_is_visible_even_for_sensor_context_but_never_stale():
    assert eligible_now(c())
    assert not eligible_now(c(energy_stored=54.9))
    assert not eligible_now(c(remaining_energy=34.9))
    assert not eligible_now(c(too_late=True))
    assert eligible_now(c(sensor_only=True))
    assert not eligible_now(c(data_status='STALE'))


def test_active_venue_scope_prevents_cross_venue_rank_slot_pollution(tmp_path):
    r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))
    try:
        r.active_venue=lambda:'KRX'
        # Contract-level assertion: runtime source must scope scoring to active venue.
        import inspect
        src=inspect.getsource(Runtime.evaluate)
        assert "st.venue==active_venue" in src
    finally:
        r.signal_store.close(); r.baseline.close(); r.db_executor.shutdown(wait=True)


def test_quote_focus_uses_slow_rotation_without_capacity_growth(tmp_path):
    s=Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h'))
    assert s.ws_quote_focus_items==4 and s.quote_rotation_sec>=3
