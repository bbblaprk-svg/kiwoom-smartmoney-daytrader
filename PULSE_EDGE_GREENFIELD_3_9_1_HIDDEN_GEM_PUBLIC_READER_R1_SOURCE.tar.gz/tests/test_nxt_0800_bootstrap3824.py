import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo
from pulse_edge.runtime import Runtime, venue_for_kst
from pulse_edge.config import Settings

KST=ZoneInfo('Asia/Seoul')

def test_session_routing_keeps_nxt_pre_and_krx_regular():
    assert venue_for_kst(datetime(2026,9,16,8,0,tzinfo=KST))=='NXT'
    assert venue_for_kst(datetime(2026,9,16,8,50,tzinfo=KST))=='NXT'
    assert venue_for_kst(datetime(2026,9,16,9,0,tzinfo=KST))=='KRX'
    assert venue_for_kst(datetime(2026,9,16,15,30,tzinfo=KST))=='KRX'
    assert venue_for_kst(datetime(2026,9,16,15,40,tzinfo=KST))=='NXT'

def test_nxt_ranking_is_authoritative_eligibility_proof(tmp_path):
    async def run():
        r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))
        r.universe={'123456':{'symbol':'123456','name':'테스트','market':'KOSDAQ','sector':'TEST','nxt_enabled':False}}
        async def post(api,path,body,*args):
            return {'req_rt_sdnin':[{'stk_cd':'123456','cur_prc':'10000','flu_rt':'0.30'}]},{}
        r.rest.post=post
        bucket=await r._ranking_bucket('ka10022',{'stex_tp':'2'},'req_rt_sdnin','NXT','_NX')
        assert bucket==['123456_NX']
        assert '123456' in r.nxt_verified_symbols
        assert r.universe['123456']['nxt_enabled'] is True
        assert r.states['123456:NXT'].rest_venue=='NXT'
        await r.auth.close(); await r.rest.close(); r.signal_store.close(); r.baseline.close(); r.db_executor.shutdown(wait=True)
    asyncio.run(run())

def test_venue_transition_drops_previous_market_slots(tmp_path):
    async def run():
        r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))
        r.transport_venue='KRX'; r.discovery_pool=['005930']; r.discovery_meta={'005930':{'first_seen':1,'last_seen':1,'last_change':1}}
        r.rank_priority=['005930']; r.ws.priority=['005930']; r.ws.background=['000660']
        changed=await r._sync_transport_venue('NXT')
        assert changed is True
        assert r.discovery_pool==[] and r.rank_priority==[]
        assert r.ws.priority==[] and r.ws.background==[]
        assert r.transport_venue=='NXT'
        await r.auth.close(); await r.rest.close(); r.signal_store.close(); r.baseline.close(); r.db_executor.shutdown(wait=True)
    asyncio.run(run())
