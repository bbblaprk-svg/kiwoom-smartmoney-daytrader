import time
from types import SimpleNamespace as NS
from pulse_edge.presentation import eligible_now,enrich
from pulse_edge.feed.kiwoom import excluded_security
from pulse_edge.runtime import Runtime
from pulse_edge.config import Settings


def candidate(**kw):
    d=dict(name='테스트',sensor_only=False,data_status='LIVE',stage='WATCH',precursor_stage='EARLY PRESSURE ABSORBED');d.update(kw);return NS(**d)

def test_early_precursor_visible_but_stale_blocked():
    assert eligible_now(candidate())
    assert not eligible_now(candidate(data_status='STALE'))
    assert eligible_now(candidate(sensor_only=True))
    assert not eligible_now(candidate(name='TIGER 미국필라델피아반도체나스닥'))

def test_signal_immutable_current_venue_and_missing_quote():
    row=dict(symbol='123456',venue='NXT',current_price=100,change_rate=1,history_ts=10)
    st=NS(price=105,change_rate=2,last_trade_event_ts=time.time())
    r=NS(active_venue=lambda:'KRX',states={'123456:KRX':st},scorer=NS(data_status=lambda st,n:'LIVE'))
    out=enrich(r,[row],history=True)[0]
    assert out['signal_price']==100 and out['live_price']==105 and out['live_change_rate']==2
    assert row['current_price']==100 and 'live_price' not in row
    assert out['price_venue']=='KRX'
    r.scorer.data_status=lambda st,n:'STALE'
    assert enrich(r,[row],history=True)[0]['live_price'] is None
    r.states={'123456:NXT':st}
    assert enrich(r,[row],history=True)[0]['live_price'] is None

def test_daily_seed_survives_live_tick_ttl_without_extra_subscription(tmp_path):
    r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b.db'),history_db=str(tmp_path/'h.db')))
    try:
        r.coiled_seed_symbols=['123456']
        seed=r.state('123456');seed.first_seen_ts=time.time()-99999
        old=r.state('654321');old.first_seen_ts=time.time()-99999
        r.evict_states()
        assert '123456:KRX' in r.states and '654321:KRX' not in r.states
        assert not r.ws.items()
    finally:
        r.baseline.db.close();r.signal_store.db.close()

def test_fund_name_filter_without_etf_classification():
    for n in ['TIGER 미국필라델피아반도체나스닥','KODEX 200','RISE 반도체','ACE 미국S&P500','삼성전자우']:
        assert excluded_security(n,'')
    assert not excluded_security('비에이치','')


def test_missing_quote_and_crosscheck_are_watch_only_not_pre():
    from test_logic import build_states
    _,sc,states=build_states()
    st=states['000001:KRX']
    st.quotes.clear(); st.last_quote_event_ts=0;st.last_quote_receive_ts=0
    st.rest_price=None;st.rest_price_ts=0
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert c.stage=='EARLY HIDDEN GEM'
    assert c.suitability=='WATCH' and c.price_hold!='PASS'
    assert c.recommended_weight=='0% 관찰'
    st.last_trade_event_ts=time.time()-100
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert c.stage=='DATA CHECK'
