from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.models import SymbolState
from pulse_edge.engine.features import completed_10m_amount
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo

KST=ZoneInfo('Asia/Seoul')

def test_leader_sensor_is_sensor_only_not_deleted():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'leader_sensor=bool(leader_symbol==st.symbol)' in r
    assert 'effective_leader_sensor=bool(' in r
    assert 'sensor_only=bool(' in r

def test_investor_budget_reserves_newcomers():
    r=Path('pulse_edge/runtime.py').read_text()
    b=r[r.index('async def refresh_investors'):r.index('async def refresh_daily_context')]
    assert 'add_many(actionable,4)' in b
    assert 'add_many(newcomer,4)' in b
    assert 'self._probe_wires()' in b and 'self._fresh_discovery_wires(now)' in b

def test_real_zero_trade_vs_feed_gap():
    st=SymbolState(symbol='000001')
    now=datetime(2026,9,14,10,30,tzinfo=KST).timestamp()
    d=datetime.fromtimestamp(now,KST).replace(second=0,microsecond=0)
    keys=[]
    for i in range(1,11):
        x=d-timedelta(minutes=i); keys.append(x.hour*100+x.minute)
    for k in keys: st.minute_amount[k]=100.0
    missing=keys[4]; st.minute_amount.pop(missing)
    amt,present=completed_10m_amount(st,now,45)
    assert amt is None and present==9
    st.minute_feed_coverage[missing]=44
    amt,present=completed_10m_amount(st,now,45)
    assert amt is None and present==9
    st.minute_feed_coverage[missing]=45
    amt,present=completed_10m_amount(st,now,45)
    assert amt==900.0 and present==10

def test_rank_is_stage_proximity_first():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    b=r[r.index('def rank(self,states)'):]
    assert "'PRE-IGNITION':78" in b
    assert "c.precursor_stage=='RELEASE READY'" in b
    assert "c.precursor_stage=='RELEASE WINDOW'" in b
    assert 'remaining_energy' in b and 'release_imminence' in b
    assert "'IGNITION':10" in b
    assert 'x[1].ignition_probability' in b and 'x[1].purity_score' in b

def test_core_thresholds_unchanged():
    s=Settings()
    assert s.supply_tight_min_conditions==8
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.preferred_change_max==2.5
    assert s.allowed_change_max==3.0
