from datetime import datetime
from zoneinfo import ZoneInfo

from pulse_edge.briefing_schedule import active_slot, next_slot, schedule_metadata


KST = ZoneInfo('Asia/Seoul')


def test_half_hour_window_has_thirteen_slots():
    meta = schedule_metadata()
    assert meta['timezone'] == 'Asia/Seoul'
    assert meta['slot_count'] == 13
    assert meta['slots'][0] == '08:30'
    assert meta['slots'][-1] == '20:30'


def test_weekday_slots_and_grace_window():
    assert active_slot(datetime(2026, 9, 18, 8, 30, 0, tzinfo=KST))['label'] == '08:30'
    assert active_slot(datetime(2026, 9, 18, 20, 39, 59, tzinfo=KST))['label'] == '20:30'
    assert active_slot(datetime(2026, 9, 18, 8, 29, 59, tzinfo=KST)) is None


def test_weekend_and_extra_closed_date_are_suppressed():
    assert active_slot(datetime(2026, 9, 19, 9, 30, tzinfo=KST)) is None
    assert active_slot(datetime(2026, 9, 18, 9, 30, tzinfo=KST), closed_dates='2026-09-18') is None


def test_next_slot_rolls_to_next_trading_day():
    nxt = next_slot(datetime(2026, 9, 18, 20, 31, tzinfo=KST))
    assert nxt.strftime('%Y-%m-%d %H:%M') == '2026-09-21 08:30'
