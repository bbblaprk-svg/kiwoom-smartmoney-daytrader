from copy import deepcopy
from pulse_edge.config import Settings
from pulse_edge.presentation import eligible_now
from test_logic import build_states


def test_release_above_old_5pct_is_not_price_only_excluded():
    _,sc,states=build_states(target_change=5.5)
    r=sc.score(states['000001:KRX'],states,sc.sector_stats(states))
    assert r is not None
    c=r[1]
    assert c.energy_stored is not None and c.energy_released is not None and c.remaining_energy is not None
    # It may still be WATCH/ABSORB if too much energy has already been released;
    # the important change is that +5% alone no longer deletes the candidate.
    assert c.change_rate==5.5


def test_very_extended_name_is_still_hidden_gem_filtered():
    _,sc,states=build_states(target_change=12.5)
    assert sc.score(states['000001:KRX'],states,sc.sector_stats(states)) is None


def test_latent_energy_fields_are_bounded_and_semantic():
    _,sc,states=build_states()
    c=sc.score(states['000001:KRX'],states,sc.sector_stats(states))[1]
    for v in (c.flow_pressure_score,c.price_reaction_score,c.sell_response_failure,c.supply_decay_score,
              c.energy_stored,c.energy_released,c.remaining_energy,c.release_imminence):
        assert v is not None and 0 <= v <= 100
    assert c.remaining_energy <= c.energy_stored
    assert c.flow_dislocation == round(c.flow_pressure_score-c.price_reaction_score,1)


def test_same_venue_cross_section_turns_raw_gap_into_percentile_dislocation():
    _,sc,states=build_states()
    base=[]
    for st in states.values():
        base.append(sc.score(st,states,sc.sector_stats(states))[1])
    # five candidates are required before percentile language is used.
    extra=deepcopy(base[0]); extra.symbol='999999'; extra.flow_pressure_score=20; extra.price_reaction_score=90
    base.append(extra)
    sc._apply_energy_cross_section(base)
    assert all(c.flow_pressure_percentile is not None for c in base)
    assert all(c.price_reaction_percentile is not None for c in base)
    assert extra.flow_dislocation < 0


def test_energy_loaded_and_release_window_are_visible_precursors():
    class C:
        name='테스트'; sensor_only=False; data_status='LIVE'; stage='WATCH'
        precursor_stage='ENERGY LOADED'
    assert eligible_now(C())
    C.precursor_stage='RELEASE WINDOW'
    assert eligible_now(C())


def test_energy_extension_thresholds_are_not_price_only_relaxation():
    s=Settings(_env_file=None)
    assert s.allowed_change_max==3.0
    assert s.energy_extended_change_max==7.0
    assert s.energy_extended_remaining_min>0
    assert s.energy_extended_released_max<100
