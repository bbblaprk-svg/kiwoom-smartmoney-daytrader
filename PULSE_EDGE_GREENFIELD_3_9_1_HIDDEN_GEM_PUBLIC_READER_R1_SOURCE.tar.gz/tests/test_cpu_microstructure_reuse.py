from pathlib import Path

def test_scorer_calls_quote_microstructure_once_per_score_path():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    score_block=r[r.index('    def score('):r.index('    def rank(')]
    assert score_block.count('quote_microstructure(')==1
    assert score_block.count('ignition_trigger_metrics(')==1

def test_ignition_metrics_accepts_reused_qm_without_changing_fallback():
    r=Path('pulse_edge/engine/features.py').read_text()
    assert 'def ignition_trigger_metrics(state:SymbolState,vw:float|None,sector_expansion:float|None,now=None,qm:dict|None=None):' in r
    assert "qm=qm if qm is not None else quote_microstructure(state,n)" in r

def test_pre_gate_is_hidden_gem_pure_not_legacy_models():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('pre_common='):r.index('ignition_event=')]
    assert 'hidden_gem_pre_stored_min' in block and 'hidden_gem_pre_remaining_min' in block
    assert 'model_a_ready' not in block and 'model_b_ready' not in block

def test_alert_contract_is_pre_entry_and_invalidation_not_precursor_spam():
    runtime=Path('pulse_edge/runtime.py').read_text()
    eval_block=runtime[runtime.index('for c in raw:'):runtime.index('if not self.results or', runtime.index('for c in raw:'))]
    assert '_push_precursor(c)' not in eval_block
    assert "c.stage in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'}" in eval_block
    assert '_push_invalidation(c)' in eval_block
