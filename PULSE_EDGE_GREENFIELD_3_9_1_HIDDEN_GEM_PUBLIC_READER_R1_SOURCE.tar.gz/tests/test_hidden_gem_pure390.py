from tests.test_logic import build_states
from pathlib import Path

def _score(cur,peak):
    _,sc,states=build_states(target_change=cur)
    st=states['000001:KRX']; st.high=st.prev_close*(1+peak/100)
    return sc.score(st,states,sc.sector_stats(states))[1]

def test_current_5_peak_6_is_not_too_late():
    c=_score(5,6)
    assert not c.too_late and c.energy_released<60

def test_current_5_peak_12_is_first_release_reaccumulation_not_forced_too_late():
    c=_score(5,12)
    assert not c.too_late
    assert c.energy_released>60 and c.stage!='PRE-IGNITION'

def test_current_5_peak_20_is_too_late_after_large_prior_release():
    c=_score(5,20)
    assert c.too_late and c.stage=='TOO LATE'
    assert 'EARLIER_INTRADAY_RELEASE_GIVEN_BACK' in c.too_late_reason

def test_release_memory_and_model_purge_are_static_contracts():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'intraday_release_cycle_count' in src
    assert 'model_a_ready' not in src and 'model_b_ready' not in src
    assert "detection_model='HIDDEN_GEM_PURE'" in src
