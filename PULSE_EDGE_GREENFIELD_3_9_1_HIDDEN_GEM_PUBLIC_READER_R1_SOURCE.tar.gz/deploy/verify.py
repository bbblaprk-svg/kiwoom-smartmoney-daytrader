from __future__ import annotations
import json, os, sys, urllib.request

DEFAULT_RELEASE='3.9.1_HIDDEN_GEM_PUBLIC_READER'

def get_json(base:str,path:str):
    with urllib.request.urlopen(base.rstrip('/')+path,timeout=6) as r:
        return json.load(r)

def verify(base:str, release:str):
    h=get_json(base,'/health'); assert h.get('runtime_safety_release')==release,(h.get('runtime_safety_release'),release)
    q=get_json(base,'/api/hidden-gem/top?limit=3'); assert q.get('release')==release,(q.get('release'),release)
    pub=get_json(base,'/api/public/hidden-gem/top?limit=3')
    assert pub.get('release')==release and pub.get('read_only') is True,pub
    assert isinstance(pub.get('rows'),list),pub
    coiled=get_json(base,'/api/coiled-spring/top?limit=5')
    assert coiled.get('release')==release and coiled.get('source')=='DISABLED' and (coiled.get('rows') or [])==[],coiled
    hist=get_json(base,'/api/signal-history?limit=3'); assert isinstance(hist.get('rows'),list)
    push=get_json(base,'/api/push/public-key'); assert 'enabled' in push and 'public_key' in push
    truth=get_json(base,'/api/feed-truth'); assert truth.get('data_truth_policy')=='NO_DELAYED_OR_CROSS_VENUE_DATA_FOR_BUY_DECISION'
    sess=get_json(base,'/api/session'); assert sess.get('release')==release and sess.get('automatic_orders') is False,sess
    get_json(base,'/api/runtime-truth')
    rd=get_json(base,'/api/readiness'); assert rd.get('release')==release and rd.get('ready') is True,(rd.get('release'),release,rd)
    return True

def main(argv=None):
    argv=sys.argv if argv is None else argv
    if len(argv) not in (2,3):
        raise SystemExit('usage: python -m deploy.verify BASE_URL [EXPECTED_RELEASE]')
    release=(argv[2] if len(argv)==3 else os.getenv('PULSE_RELEASE_EXPECTED') or DEFAULT_RELEASE)
    verify(argv[1],release)
    print('HTTP_CONTRACT_PASS release='+release)

if __name__=='__main__': main()
