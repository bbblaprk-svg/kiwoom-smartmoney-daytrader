from __future__ import annotations
import argparse,ast,gc,json,os,subprocess,sys,tempfile,time,tracemalloc
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.domain import Venue,TradeTick,Candidate,Origin,SignalEvent
from app.runtime.window import FixedMicroWindow
from app.runtime.state import RuntimeState
from app.runtime.ingest import Ingestor
from app.runtime.dispatcher import Envelope,TradeDispatcher
from app.tracking.live import LiveTracker
from app.signal.metrics import MetricEngine
from app.runtime.watchdog import HardStallWatchdog
from app.config import SETTINGS
from app.storage.wal import DurableJournal
from app.storage.recovery import read_committed_wal,read_committed_history


def rss_mb():
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return float(line.split()[1])/1024
    except Exception:return 0
    return 0

def assert_no_old_runtime_refs():
    bad=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.suffix not in ('.py','.js','.sh'):continue
        if '/tests/' in str(p) or '/scripts/' in str(p):continue
        t=p.read_text(errors='ignore')
        for needle in ('nova2600','R1.2','docker commit','main.py.bak','sed -i'):
            if needle in t:bad.append((str(p.relative_to(ROOT)),needle))
    assert not bad,bad
    print('GROUNDUP_NO_PATCH_INHERITANCE=PASS')

def assert_no_async_disk_io():
    suspicious=[]
    calls={'open','read_text','write_text','os.open','os.write','os.fsync','atomic_json','read_json'}
    for p in (ROOT/'app').rglob('*.py'):
        src=p.read_text();tree=ast.parse(src);lines=src.splitlines()
        for node in ast.walk(tree):
            if not isinstance(node,ast.AsyncFunctionDef):continue
            for sub in ast.walk(node):
                if not isinstance(sub,ast.Call):continue
                name=''
                if isinstance(sub.func,ast.Name):name=sub.func.id
                elif isinstance(sub.func,ast.Attribute):
                    parts=[];x=sub.func
                    while isinstance(x,ast.Attribute):parts.append(x.attr);x=x.value
                    if isinstance(x,ast.Name):parts.append(x.id)
                    name='.'.join(reversed(parts))
                if name in calls or name.split('.')[-1] in {'open','read_text','write_text','fsync'}:
                    line=lines[sub.lineno-1] if 0<sub.lineno<=len(lines) else ''
                    # Allowed: explicit offload or /proc telemetry read (not storage I/O).
                    if 'to_thread' in line or (p.name=='health.py' and '/proc/' in src):continue
                    suspicious.append((str(p.relative_to(ROOT)),node.name,sub.lineno,name,line.strip()))
    assert not suspicious,suspicious
    print('ASYNC_DIRECT_STORAGE_IO=PASS')

def test_rate_independent_windows():
    low=FixedMicroWindow();high=FixedMicroWindow();start=10_000_000.0
    for sec in range(330):
        low.add(start+sec+.1,100,10)
        for j in range(120):high.add(start+sec+j/120,100+j*.0001,1 if j%3 else -1)
    assert low.memory_slots()<=955 and high.memory_slots()<=955
    r=high.aggregate(start+329.9,300);assert r['bucket_count']>=295 and r['count']>35000
    print(f'RATE_INDEPENDENT_WINDOW=PASS low_slots={low.memory_slots()} high_slots={high.memory_slots()} count5m={r["count"]}')

def synthetic_day(symbols=80,ticks_per_sec=8,seconds=330,total_candidates=1200):
    st=RuntimeState();tr=LiveTracker();ing=Ingestor(st,tr);base=time.time()-seconds
    all_codes=[f'{i:06d}' for i in range(1,total_candidates+1)]
    for c in all_codes:
        x=st.candidate(c,f'S{c}',Origin.TODAY_NEW,'20260812');x.rest_base=45
    codes=all_codes[:symbols]
    st.hot_codes.update(codes)
    before=rss_mb();t0=time.perf_counter();seq=0
    for sec in range(seconds):
        ts=base+sec
        for idx,code in enumerate(codes):
            # two venues are intentionally independent and differ in price/cumulative volume
            for venue,basep in ((Venue.KRX,10000),(Venue.NXT,10030)):
                for j in range(ticks_per_sec):
                    seq+=1;p=basep+sec*.3+(j%4);q=100+(j%5)*10
                    tick=TradeTick(code,venue,p,q if j%4 else -q,1.0,sec*ticks_per_sec+j+1,0,f'{90000+sec:06d}',ts+j/max(ticks_per_sec,1),time.monotonic(),seq)
                    ing.trade(Envelope('TRADE',code,tick,time.monotonic(),False))
    elapsed=time.perf_counter()-t0;after=rss_mb();m=MetricEngine(st);scores=[]
    for code in codes:
        c=st.candidates[code];c.current_venue=Venue.NXT;scores.append(m.score(c,Venue.NXT,True).score)
        assert st.window(code,Venue.KRX).memory_slots()<=955 and st.window(code,Venue.NXT).memory_slots()<=955
    total=symbols*2*ticks_per_sec*seconds
    print(f'ACCELERATED_DAY=PASS candidates={len(st.candidates)} active={len(codes)} events={total} eps={total/elapsed:.0f} rss_before={before:.1f} rss_after={after:.1f} windows={len(st.windows)} score_count={len(scores)}')
    return after

def dispatcher_stress(n=120000):
    st=RuntimeState();tr=LiveTracker();ing=Ingestor(st,tr);d=TradeDispatcher(ing.trade,ing.dropped,shards=4,maxsize=SETTINGS.trade_queue_per_shard);d.start();base=time.time();submitted=0
    t0=time.perf_counter()
    for i in range(n):
        code=f'{i%50+1:06d}';tick=TradeTick(code,Venue.NXT,10000+(i%20),100,1,1000+i,0,'170000',base,time.monotonic(),i+1)
        if d.submit(Envelope('TRADE',code,tick,time.monotonic(),False)):submitted+=1
        if i%500==0:time.sleep(.001)
    deadline=time.time()+10
    while d.depth() and time.time()<deadline:time.sleep(.01)
    elapsed=time.perf_counter()-t0;d.stop()
    # Candidate drops are allowed under synthetic producer overload; pinned drops must stay zero here.
    assert st.telemetry['dropped_signal_tick_count']==0
    print(f'BOUNDED_DISPATCHER=PASS submitted={submitted} processed={d.processed} candidate_drops={int(st.telemetry["dropped_candidate_tick_count"])} max_depth={d.max_depth} elapsed={elapsed:.2f}s')

def journal_stress(n=500):
    with tempfile.TemporaryDirectory() as td:
        j=DurableJournal(Path(td));j.start();t0=time.perf_counter()
        for i in range(n):
            r={'event':'SIGNAL_CONFIRMED','signal_id':f's{i}','day':'20260812','code':f'{i%80:06d}','venue':'NXT','signal_price':100+i%5,'signal_time':time.time()}
            assert j.commit(r,2),i
            assert j.append_important({'event':'HISTORY','event_key':f'h{i}','day':'20260812','code':f'{i%80:06d}','kind':'TOP5_ENTER','state':'HOT','at':time.time()})
        j.important.join();j.stop();elapsed=time.perf_counter()-t0
        fw=read_committed_wal(Path(td)/'signal_wal.sqlite3',n+10);fh=read_committed_history(Path(td)/'signal_wal.sqlite3',n+10)
        assert len(fw)==n and len(fh)==n,(len(fw),len(fh));assert j.stats['important_enqueue_fail']==0
        print(f'DURABLE_JOURNAL=PASS formal={len(fw)} important={len(fh)} sec={elapsed:.2f} critical_p95={j.health()["db_write_latency_p95_ms"]}')

def watchdog_subprocess():
    p=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--watchdog-child'],cwd=ROOT,timeout=5)
    assert p.returncode==78,p.returncode
    print('INDEPENDENT_HARD_STALL_WATCHDOG=PASS exit=78')

def child_watchdog():
    w=HardStallWatchdog(stall_sec=.25,grace_sec=.1,exit_code=78);w.start();time.sleep(2);raise SystemExit(99)

def package_shape():
    files=list((ROOT/'app').rglob('*.py'));line_counts={str(p.relative_to(ROOT)):len(p.read_text().splitlines()) for p in files};mx=max(line_counts.items(),key=lambda x:x[1])
    assert mx[1]<500,mx
    assert (ROOT/'app/runtime/window.py').exists() and (ROOT/'app/storage/wal.py').exists() and (ROOT/'app/api/app.py').exists()
    print(f'MODULARITY=PASS python_files={len(files)} max_module={mx[0]}:{mx[1]}lines')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--watchdog-child',action='store_true');ap.add_argument('--quick',action='store_true');a=ap.parse_args()
    if a.watchdog_child:child_watchdog();return
    package_shape();assert_no_old_runtime_refs();assert_no_async_disk_io();test_rate_independent_windows()
    if not a.quick:synthetic_day();dispatcher_stress();journal_stress();watchdog_subprocess()
    else:synthetic_day(symbols=20,ticks_per_sec=4,seconds=90);journal_stress(100);watchdog_subprocess()
    print('NOVA_3_2_1_GROUNDUP10R_VALIDATION=PASS')
if __name__=='__main__':main()
