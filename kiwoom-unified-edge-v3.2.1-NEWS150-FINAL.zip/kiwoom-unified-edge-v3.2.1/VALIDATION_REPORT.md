# Kiwoom Unified Edge v3.2.1 최종 검증보고서

## 회귀검사
- `npm run check`: 전체 통과
- 신규 `check:market-discovery`: 시총4구간, 상대거래량/가속, 시장풀 목표 8/14/10/8, 집중8 대형 최대2 검증 통과
- `check:recommendations`: 일일/장중 `ka10023`, 시총프로필, 8+18 추천, 실시간 PRE-SURGE, 수동보호 검증 통과
- 기존 통합/PRE-BUY/학습/진입가이드/REST/flow/storage 검사 모두 통과

## 30종목 합성 부하검사
2026-08-04 UTC, 100,000 ticks / 30 symbols:
- throughput: 66,800 ticks/sec
- event-loop p95: 24.69 ms
- event-loop max: 27.28 ms
- errors: 0
- RSS: 115.6 MB
- final pending/active: 0 / 0

합성검사는 실제 Kiwoom 네트워크 지연·장중 AWS CPU·외부 뉴스망을 완전히 재현하지 않으므로 실장에서는 `/api/health`를 계속 확인해야 합니다.

## Kiwoom 실시간 핵심경로 보존 확인
V3.2.0과 SHA256을 비교해 모두 동일:
- `lib/kiwoomClient.js` — `9a02d2cb0d4d95f978fd20cb42afdb0fe6744969a2f87742fe79f8e2f34a57b6`
- `lib/flowCollector.js` — `7a236c42f33950431b3f0f0acff3c7a5d88249e2437f9eb30e6d71e3718e6f1a`
- `lib/realtimeStore.js` — `06fa5d1c79e034a2dd5509bc730f6c794ce3192a16cc61065c71842c2fb6458b`
- `lib/signalEngine.js` — `f565e90a711c44c239d274642bf62b0ca161a911dc19c8c3fb5272de032a66ec`
- `worker/kiwoomRealtime.js` — `9179d7ec4c9afc0f6ad1a079fbfff7711c98ba72ced80b102aabdeca63e3b1af`
- `lib/marketSnapshot.js` — `dd62e9a7434b0e8e4c5b03d93b4a7acbbb302c40c4752a5273cb9c15112edb8b`

News Radar 디렉터리도 V3.2.0과 byte 차이가 없습니다.

## 시장발굴 변경점
- 절대 거래대금 추천가중치 최대 `48 -> 28`.
- `ka10023`: 장중 5분 거래량급증, 일일 전일대비 거래량급증.
- 스캔 간 거래대금 won/min 속도 및 직전 속도 대비 가속률 계산.
- `ka10001 mac`으로 시총4구간 보강, 24시간 캐시. 기본 보강대상 최대60후보.
- 시장풀40 목표쿼터: MICRO 8 / SMALL 14 / MID 10 / LARGE 8. 해당 구간 후보가 부족하면 고득점 후보로 빈 자리를 채움.
- UNKNOWN 시총은 단독 이유로 탈락시키지 않음.

## 트래픽 안전장치
- 실시간 심볼 최대30 및 full-depth 승격구조는 변경 없음.
- 추가 추천 TR은 `ka10023` 1회/추천 생성.
- 시총 `ka10001`은 후보별 24시간 캐시하며 기존 공통 REST rate limiter를 그대로 통과함.
- 장중 추천은 기존 최소 60초 재조회 제한 유지.

## BUY 안전게이트
변경 없음: 품질85, 수익우선78, 체결강도118, 데이터완전성95%, R/R1.5, SmartMoney TURN/EXPANSION 및 기존 안전조건.
시장발굴 개선은 더 좋은 종목을 감시30 안으로 넣는 변경이지 BUY 기준 완화가 아닙니다.

## production build
현재 작업환경에는 `node_modules`가 없어 로컬 Next production build는 실행하지 않았습니다. 배포 스크립트의 AWS Docker build가 `npm install -> SOURCE_MANIFEST 검증 -> npm run check -> 30종목 load check -> next build`를 모두 통과해야만 기존 컨테이너를 교체하며 실패하면 롤백합니다.

## News Radar 1.5.0-unified 결합 검증 (2026-08-04)
- News `node scripts/check.js`: PASS.
- 통합 전용 `/api/discovery-feed` 복원 및 내부토큰 인증: PASS (무토큰 401 / 내부토큰 200).
- `/api/health`: `version=1.5.0-unified`, `ready=true` 확인.
- Trader 디렉터리: 원본 v3.2.1과 byte-identical (뉴스 결합으로 Trader 핵심경로 변경 없음).
- News storage: `/app/data`, host port mapping `127.0.0.1:3100 -> 3000` 유지.
- 신선도 정책: 60분 / 180분 / 6시간, 24시간 hard age; `relatedStocks` TOP 3.
