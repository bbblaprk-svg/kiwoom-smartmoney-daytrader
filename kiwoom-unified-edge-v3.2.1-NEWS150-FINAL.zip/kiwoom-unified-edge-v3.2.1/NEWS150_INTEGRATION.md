# News Radar v1.5.0-unified integration

- Trader: 3.2.1 unchanged.
- News Radar: 1.5.0-unified.
- Internal bridge: `/api/discovery-feed` + `INTERNAL_BRIDGE_TOKEN` preserved.
- Storage: `/app/data` and `news-radar-data` volume preserved.
- Freshness: <=60m / <=180m / <=6h realtime tiers; >24h blocked from realtime ingestion.
- Low-value filter: primary-index marketplace/document/product pages without event evidence are rejected.
- Mapping: inferred Korean related stocks are stored in `relatedStocks`, capped at 3; direct mentions remain in `matched`.
- Deployment port: host 127.0.0.1:3100 -> news-radar:3000; trader continues on 127.0.0.1:3000.
