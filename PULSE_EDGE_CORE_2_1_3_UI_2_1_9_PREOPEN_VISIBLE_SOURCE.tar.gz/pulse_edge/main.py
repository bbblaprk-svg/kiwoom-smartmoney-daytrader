from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from dataclasses import asdict
from datetime import datetime, time as dt_time, timezone
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from pulse_edge import __version__
from pulse_edge.config import get_settings
from pulse_edge.context.daily import DailyContextService
from pulse_edge.context.business import BusinessContextService
from pulse_edge.core.models import Venue
from pulse_edge.discovery.market import MarketDiscoveryService
from pulse_edge.background.service import BackgroundCoverageService
from pulse_edge.feed.auth import KiwoomAuth
from pulse_edge.feed.rest import KiwoomRestClient
from pulse_edge.feed.service import FeedService
from pulse_edge.feed.state import FeedState
from pulse_edge.feed.truth import FeedTruth
from pulse_edge.feed.ws import KiwoomWebSocket, build_registrations
from pulse_edge.features.benchmark import BenchmarkMapper
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.flow.investor import InvestorFlowService
from pulse_edge.session.router import OperatorPhase, SessionRouter, SessionPhase
from pulse_edge.smart_money.engine import SmartMoneyEngine
from pulse_edge.smart_money.service import SmartMoneyService
from pulse_edge.ignition.engine import IgnitionEngine
from pulse_edge.ignition.service import IgnitionService
from pulse_edge.spillover.engine import SectorSpilloverEngine
from pulse_edge.spillover.service import SectorSpilloverService
from pulse_edge.pullback.engine import PullbackSecondWaveEngine
from pulse_edge.pullback.service import PullbackSecondWaveService
from pulse_edge.regime.engine import MarketRegimeEngine
from pulse_edge.regime.service import MarketRegimeService
from pulse_edge.confluence.engine import ConfluenceEngine
from pulse_edge.confluence.service import ConfluenceService
from pulse_edge.patterns.service import PatternCompletionService
from pulse_edge.bridge.engine import KrxNxtBridgeEngine
from pulse_edge.bridge.service import KrxNxtBridgeService
from pulse_edge.decision.engine import PreBuyDecisionEngine
from pulse_edge.decision.service import PreBuyDecisionService
from pulse_edge.compression.engine import CurrentDecisionCompressionEngine
from pulse_edge.compression.service import CurrentDecisionCompressionService
from pulse_edge.ledger.store import SignalLedgerStore
from pulse_edge.ledger.service import SignalLedgerService
from pulse_edge.ledger.outcomes import DailyOutcomeBarSource, DailyOutcomeCompletionService
from pulse_edge.runtime.engine import RuntimeTruthEngine
from pulse_edge.runtime.service import RuntimeTruthService
from pulse_edge.presentation.service import PresentationSafetyService
from pulse_edge.live_validation.service import LiveShadowValidationService
from pulse_edge.live_certification import LiveCertificationService, LiveCertificationStore
from pulse_edge.absorption.engine import SupplyAbsorptionEngine
from pulse_edge.absorption.service import SupplyAbsorptionService
from pulse_edge.dual_performance import DualPerformanceStore, DualPerformanceService, DualDailyOutcomeService
from pulse_edge.transition_ops import TransitionOpsStore, TransitionOpsService
from pulse_edge.nxt_native import NxtNativeEngine, NxtNativeService
from pulse_edge.nxt_board import NxtFixedOperationsBoardService
from pulse_edge.missed_opportunity import MissedOpportunityService, MissedOpportunityStore, OpportunityStatus
from pulse_edge.current_enrichment import CurrentEnrichmentService
from pulse_edge.krx_board import KrxDualOperationsBoardService
from pulse_edge.daily_review import DailyReviewService, DailyReviewStore
from pulse_edge.storage.validation import LiveValidationStore
from pulse_edge.sector.service import SectorBreadthService
from pulse_edge.universe.service import UniverseService
from pulse_edge.storage.baseline import SameTimeBaselineStore

settings = get_settings()
session_router = SessionRouter(settings.holidays)
benchmark_mapper = BenchmarkMapper()
for _symbol, _market in settings.market_map.items():
    benchmark_mapper.register(_symbol, _market)

baseline_store: SameTimeBaselineStore | None = None
if settings.feed_enabled:
    baseline_store = SameTimeBaselineStore(settings.baseline_db_path)

state = FeedState(settings.raw_ring_size)
truth = FeedTruth(
    settings.receive_stale_after_sec,
    settings.event_stale_after_sec,
    settings.future_tolerance_sec,
)
features = FeatureEngine(session_router, baseline_store, benchmark_mapper)
service = FeedService(
    state,
    truth,
    features,
    session_router,
    timestamp_regression_tolerance_sec=settings.timestamp_regression_tolerance_sec,
)
auth = KiwoomAuth(settings.kiwoom_rest_base, settings.kiwoom_appkey, settings.kiwoom_secretkey)
rest = KiwoomRestClient(settings.kiwoom_rest_base, auth.token)

ws_client: KiwoomWebSocket | None = None
discovery: MarketDiscoveryService | None = None
investor_flow: InvestorFlowService | None = None
daily_context: DailyContextService | None = None
smart_money: SmartMoneyService | None = None
universe: UniverseService | None = None
background_coverage: BackgroundCoverageService | None = None
sectors: SectorBreadthService | None = None
business_context: BusinessContextService | None = None
ignition: IgnitionService | None = None
sector_spillover: SectorSpilloverService | None = None
pullback_second_wave: PullbackSecondWaveService | None = None
market_regime: MarketRegimeService | None = None
confluence: ConfluenceService | None = None
pattern_completion: PatternCompletionService | None = None
krx_nxt_bridge: KrxNxtBridgeService | None = None
prebuy_decision: PreBuyDecisionService | None = None
current_decision_compression: CurrentDecisionCompressionService | None = None
signal_ledger_store: SignalLedgerStore | None = None
signal_ledger: SignalLedgerService | None = None
signal_daily_outcomes: DailyOutcomeCompletionService | None = None
runtime_truth_service: RuntimeTruthService | None = None
presentation_safety: PresentationSafetyService | None = None
live_validation_store: LiveValidationStore | None = None
live_shadow_validation: LiveShadowValidationService | None = None
live_certification_store: LiveCertificationStore | None = None
live_certification: LiveCertificationService | None = None
supply_absorption: SupplyAbsorptionService | None = None
dual_performance_store: DualPerformanceStore | None = None
dual_performance: DualPerformanceService | None = None
dual_daily_outcomes: DualDailyOutcomeService | None = None
transition_ops_store: TransitionOpsStore | None = None
transition_ops: TransitionOpsService | None = None
nxt_native: NxtNativeService | None = None
nxt_operations_board: NxtFixedOperationsBoardService | None = None
missed_opportunity_store: MissedOpportunityStore | None = None
missed_opportunity: MissedOpportunityService | None = None
current_enrichment: CurrentEnrichmentService | None = None
krx_operations_board: KrxDualOperationsBoardService | None = None
daily_review_store: DailyReviewStore | None = None
daily_review: DailyReviewService | None = None
background_tasks: list[asyncio.Task] = []


RUNTIME_SAFETY_RELEASE = "2.1.8_RUNTIME_SAFETY"

# Runtime-only scheduler protection. These guards do not alter any strategy
# score, threshold, ranking formula, DUAL/PRICE HOLD rule, or UI asset.
_LOOP_STAGGER_SEC = {
    "ignition": 0.35,
    "sector_spillover": 0.80,
    "pullback_second_wave": 1.25,
    "market_regime": 1.70,
    "confluence": 2.15,
    "pattern_completion": 2.60,
    "krx_nxt_bridge": 3.05,
    "prebuy_decision": 3.50,
    "current_decision_compression": 3.95,
    "signal_ledger": 4.40,
    "supply_absorption": 1.10,
    "transition_ops": 2.35,
    "krx_operations_board": 3.25,
    "nxt_native": 0.55,
    "nxt_operations_board": 2.75,
}
_refresh_inflight: set[str] = set()


async def _stagger(component: str) -> None:
    delay = float(_LOOP_STAGGER_SEC.get(component, 0.0))
    if delay > 0:
        await asyncio.sleep(delay)


def _phase_now() -> SessionPhase:
    return session_router.phase_at(datetime.now(timezone.utc))


def _krx_heavy_phase() -> bool:
    # KRX current-decision work is not useful after KRX close. Preserve the
    # latest snapshot while NXT-native/post-close layers continue separately.
    return _phase_now() in {
        SessionPhase.NXT_PRE,
        SessionPhase.OPENING_AUCTION,
        SessionPhase.MARKET_MAIN,
        SessionPhase.KRX_CLOSE_AUCTION,
    }


def _nxt_native_phase() -> bool:
    return _phase_now() in {
        SessionPhase.NXT_PRE,
        SessionPhase.MARKET_MAIN,
        SessionPhase.NXT_AFTER,
        SessionPhase.NXT_LATE_SESSION,
    }


def _singleflight_sync(component: str, fn, *args, **kwargs):
    # A loop is already sequential by construction; this explicit guard also
    # prevents accidental duplicate refresh entry from future callers.
    if component in _refresh_inflight:
        return None
    _refresh_inflight.add(component)
    try:
        return fn(*args, **kwargs)
    finally:
        _refresh_inflight.discard(component)


def _runtime_component_allowed(component: str) -> bool:
    return runtime_truth_service is None or runtime_truth_service.allowed(component)


def _runtime_interval(component: str, base_seconds: float) -> float:
    if runtime_truth_service is None:
        return float(base_seconds)
    return runtime_truth_service.interval(component, base_seconds)


def _live_certification_required(cfg) -> bool:
    return bool(getattr(cfg, "feed_enabled", False) and getattr(cfg, "live_certification_enabled", False))


def _live_shadow_validation_required(cfg) -> bool:
    return bool(
        getattr(cfg, "feed_enabled", False)
        and (getattr(cfg, "live_shadow_validation_enabled", False) or _live_certification_required(cfg))
    )


def _runtime_truth_required(cfg) -> bool:
    return bool(
        cfg.runtime_truth_enabled
        or cfg.prebuy_decision_enabled
        or cfg.current_decision_compression_enabled
        or cfg.signal_ledger_enabled
        or _live_shadow_validation_required(cfg)
        or getattr(cfg, "supply_absorption_enabled", False)
    )


def _presentation_safety_required(cfg) -> bool:
    return bool(
        cfg.presentation_safety_enabled
        or cfg.current_decision_compression_enabled
        or _live_shadow_validation_required(cfg)
    )


def _runtime_dependencies(cfg) -> tuple[bool, bool]:
    """Return (investor_flow_required, background_coverage_required).

    Any enabled current-decision layer that consumes SMART-MONEY must not run
    silently without investor-flow refresh or fair full-universe rotation.
    Explicit flags still work, but downstream enablement automatically raises
    these two factual dependencies.
    """
    smart_consumers = any((
        cfg.smart_money_enabled,
        cfg.ignition_enabled,
        cfg.sector_spillover_enabled,
        cfg.pullback_second_wave_enabled,
        cfg.confluence_enabled,
        cfg.krx_nxt_bridge_enabled,
        cfg.prebuy_decision_enabled,
        getattr(cfg, "current_decision_compression_enabled", False),
        cfg.signal_ledger_enabled,
        _live_shadow_validation_required(cfg),
        getattr(cfg, "supply_absorption_enabled", False),
    ))
    return (bool(cfg.investor_flow_enabled or smart_consumers),
            bool(cfg.background_coverage_enabled or smart_consumers))


async def _discovery_loop() -> None:
    assert discovery is not None
    while True:
        try:
            if _runtime_component_allowed("market_discovery"):
                await discovery.scan_current()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(5.0, _runtime_interval("market_discovery", settings.discovery_interval_sec)))


async def _investor_loop() -> None:
    assert investor_flow is not None
    while True:
        try:
            if _runtime_component_allowed("investor_flow"):
                # Keep KOSPI/KOSDAQ facts separate. This layer only collects facts.
                for market in ("001", "101"):
                    for period in (1, 3, 5):
                        await investor_flow.load_recent(period, market, "3")
                    await investor_flow.load_intraday_rank("FOREIGN", market)
                    await investor_flow.load_intraday_rank("INSTITUTION", market)
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(30.0, _runtime_interval("investor_flow", settings.investor_flow_interval_sec)))


async def _smart_money_loop() -> None:
    assert smart_money is not None
    while True:
        try:
            await smart_money.refresh(settings.smart_money_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            smart_money.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(10.0, settings.smart_money_interval_sec))


async def _supply_absorption_loop() -> None:
    assert supply_absorption is not None
    await _stagger("supply_absorption")
    while True:
        try:
            if _krx_heavy_phase():
                await supply_absorption.hydrate_breakdowns(settings.supply_absorption_refresh_limit)
            if _krx_heavy_phase():
                _singleflight_sync("supply_absorption", supply_absorption.refresh, settings.supply_absorption_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            supply_absorption.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(10.0, settings.supply_absorption_interval_sec))


async def _dual_performance_loop() -> None:
    assert dual_performance is not None
    while True:
        try:
            dual_performance.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            dual_performance.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.dual_performance_interval_sec))


async def _dual_daily_outcome_loop() -> None:
    assert dual_daily_outcomes is not None
    while True:
        try:
            await dual_daily_outcomes.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            dual_daily_outcomes.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(60.0, settings.dual_daily_outcomes_interval_sec))


async def _transition_ops_loop() -> None:
    assert transition_ops is not None
    await _stagger("transition_ops")
    while True:
        try:
            _singleflight_sync("transition_ops", transition_ops.refresh)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            transition_ops.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.transition_ops_interval_sec))


async def _nxt_native_loop() -> None:
    assert nxt_native is not None
    await _stagger("nxt_native")
    while True:
        try:
            if _nxt_native_phase():
                _singleflight_sync("nxt_native", nxt_native.refresh, settings.nxt_native_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            nxt_native.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.nxt_native_interval_sec))


async def _nxt_operations_board_loop() -> None:
    assert nxt_operations_board is not None
    await _stagger("nxt_operations_board")
    while True:
        try:
            if _nxt_native_phase():
                _singleflight_sync("nxt_operations_board", nxt_operations_board.refresh)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            nxt_operations_board.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.nxt_operations_board_interval_sec))


async def _missed_opportunity_loop() -> None:
    assert missed_opportunity is not None
    while True:
        try:
            await missed_opportunity.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            missed_opportunity.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(10.0, settings.missed_opportunity_interval_sec))


async def _current_enrichment_loop() -> None:
    assert current_enrichment is not None
    while True:
        try:
            await current_enrichment.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            current_enrichment.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(10.0, settings.current_enrichment_interval_sec))


async def _krx_operations_board_loop() -> None:
    assert krx_operations_board is not None
    await _stagger("krx_operations_board")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("krx_operations_board", krx_operations_board.refresh)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            krx_operations_board.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.krx_operations_board_interval_sec))


async def _daily_review_loop() -> None:
    assert daily_review is not None
    while True:
        try:
            daily_review.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            daily_review.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(30.0, settings.daily_review_interval_sec))


async def _ignition_loop() -> None:
    assert ignition is not None
    await _stagger("ignition")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("ignition", ignition.refresh, settings.ignition_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            ignition.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.ignition_interval_sec))


async def _sector_spillover_loop() -> None:
    assert sector_spillover is not None
    await _stagger("sector_spillover")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("sector_spillover", sector_spillover.refresh, settings.sector_spillover_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            sector_spillover.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.sector_spillover_interval_sec))


async def _pullback_second_wave_loop() -> None:
    assert pullback_second_wave is not None
    await _stagger("pullback_second_wave")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("pullback_second_wave", pullback_second_wave.refresh, settings.pullback_second_wave_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            pullback_second_wave.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.pullback_second_wave_interval_sec))


async def _market_regime_loop() -> None:
    assert market_regime is not None
    await _stagger("market_regime")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("market_regime", market_regime.refresh)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            market_regime.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.market_regime_interval_sec))


async def _confluence_loop() -> None:
    assert confluence is not None
    await _stagger("confluence")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("confluence", confluence.refresh, settings.confluence_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            confluence.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.confluence_interval_sec))


async def _pattern_completion_loop() -> None:
    assert pattern_completion is not None
    await _stagger("pattern_completion")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("pattern_completion", pattern_completion.refresh, settings.pattern_completion_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            pattern_completion.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.pattern_completion_interval_sec))


async def _krx_nxt_bridge_loop() -> None:
    assert krx_nxt_bridge is not None
    await _stagger("krx_nxt_bridge")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("krx_nxt_bridge", krx_nxt_bridge.refresh, settings.krx_nxt_bridge_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            krx_nxt_bridge.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.krx_nxt_bridge_interval_sec))




async def _prebuy_decision_loop() -> None:
    assert prebuy_decision is not None
    await _stagger("prebuy_decision")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("prebuy_decision", prebuy_decision.refresh, settings.prebuy_decision_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            prebuy_decision.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.prebuy_decision_interval_sec))


async def _current_decision_compression_loop() -> None:
    assert current_decision_compression is not None
    await _stagger("current_decision_compression")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("current_decision_compression", current_decision_compression.refresh, settings.current_decision_compression_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            current_decision_compression.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.current_decision_compression_interval_sec))


async def _signal_ledger_loop() -> None:
    assert signal_ledger is not None
    await _stagger("signal_ledger")
    while True:
        try:
            if _krx_heavy_phase():
                _singleflight_sync("signal_ledger", signal_ledger.refresh, settings.signal_ledger_refresh_limit)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            signal_ledger.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.signal_ledger_interval_sec))


async def _universe_loop() -> None:
    assert universe is not None
    while True:
        try:
            if _runtime_component_allowed("universe_refresh"):
                await universe.refresh()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(300.0, _runtime_interval("universe_refresh", settings.universe_refresh_sec)))


async def _background_coverage_loop() -> None:
    assert background_coverage is not None
    while True:
        try:
            if _runtime_component_allowed("background_coverage"):
                await background_coverage.rotate()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(15.0, _runtime_interval("background_coverage", settings.background_coverage_interval_sec)))


async def _sector_loop() -> None:
    assert sectors is not None
    while True:
        try:
            phase = session_router.phase_at(datetime.now(timezone.utc))
            if phase == SessionPhase.MARKET_MAIN and _runtime_component_allowed("sector_breadth"):
                await sectors.refresh()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(20.0, _runtime_interval("sector_breadth", settings.sector_interval_sec)))


async def _signal_daily_outcome_loop() -> None:
    assert signal_daily_outcomes is not None
    while True:
        try:
            if _runtime_component_allowed("daily_outcomes"):
                await signal_daily_outcomes.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            signal_daily_outcomes.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(10.0, _runtime_interval("daily_outcomes", settings.signal_daily_outcomes_interval_sec)))


async def _baseline_flush_loop() -> None:
    assert baseline_store is not None
    while True:
        await asyncio.sleep(max(10.0, _runtime_interval("baseline_flush", settings.baseline_flush_interval_sec)))
        baseline_store.flush()


async def _presentation_safety_loop() -> None:
    assert presentation_safety is not None
    while True:
        try:
            presentation_safety.refresh()
        except asyncio.CancelledError:
            raise
        except Exception:
            pass
        await asyncio.sleep(max(0.5, settings.presentation_safety_interval_sec))


async def _live_shadow_validation_loop() -> None:
    assert live_shadow_validation is not None
    while True:
        try:
            live_shadow_validation.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            live_shadow_validation.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(1.0, settings.live_shadow_validation_interval_sec))


async def _live_certification_loop() -> None:
    assert live_certification is not None
    while True:
        try:
            live_certification.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            live_certification.last_error = f"{type(exc).__name__}: {exc}"
        await asyncio.sleep(max(2.0, settings.live_certification_interval_sec))


async def _runtime_truth_loop() -> None:
    assert runtime_truth_service is not None
    interval = max(1.0, settings.runtime_truth_interval_sec)
    expected = time.monotonic()
    while True:
        now_mono = time.monotonic()
        runtime_truth_service.observe_loop_lag(max(0.0, now_mono - expected))
        try:
            runtime_truth_service.refresh()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            runtime_truth_service.last_error = f"{type(exc).__name__}: {exc}"
        expected = time.monotonic() + interval
        await asyncio.sleep(interval)


@asynccontextmanager
async def lifespan(_: FastAPI):
    global ws_client, discovery, investor_flow, daily_context, smart_money, universe, background_coverage, sectors, business_context, ignition, sector_spillover, pullback_second_wave, market_regime, confluence, pattern_completion, krx_nxt_bridge, prebuy_decision, current_decision_compression, signal_ledger_store, signal_ledger, signal_daily_outcomes, runtime_truth_service, presentation_safety, live_validation_store, live_shadow_validation, live_certification_store, live_certification, supply_absorption, dual_performance_store, dual_performance, dual_daily_outcomes, transition_ops_store, transition_ops, nxt_native, nxt_operations_board, missed_opportunity_store, missed_opportunity, current_enrichment, krx_operations_board, daily_review_store, daily_review, background_tasks
    background_tasks = []
    if settings.feed_enabled:
        investor_required, background_required = _runtime_dependencies(settings)
        background_required = bool(background_required or settings.nxt_native_enabled)
        validation_required = _live_shadow_validation_required(settings)
        registrations = build_registrations(
            settings.ws_group,
            settings.item_list,
            settings.type_list,
            settings.global_type_list,
            settings.index_item_list,
            settings.index_type_list,
        )
        ws_client = KiwoomWebSocket(
            settings.kiwoom_ws_url,
            auth.token,
            registrations,
            service.ingest,
            dynamic_group_base=settings.ws_dynamic_group_base,
            dynamic_stock_types=settings.type_list,
            max_dynamic_items=settings.ws_dynamic_max_items,
            background_reserve_items=settings.ws_background_reserve_items,
        )
        background_tasks.append(asyncio.create_task(ws_client.run_forever(), name="pulse-kiwoom-ws"))
        if _runtime_truth_required(settings):
            runtime_truth_service = RuntimeTruthService(
                feed_enabled=settings.feed_enabled,
                ws=ws_client,
                feed_service=service,
                truth=truth,
                state=state,
                engine=RuntimeTruthEngine(
                    busy_cpu_pct=settings.runtime_busy_cpu_pct,
                    high_cpu_pct=settings.runtime_high_cpu_pct,
                    critical_cpu_pct=settings.runtime_critical_cpu_pct,
                    busy_memory_pct=settings.runtime_busy_memory_pct,
                    high_memory_pct=settings.runtime_high_memory_pct,
                    critical_memory_pct=settings.runtime_critical_memory_pct,
                    busy_disk_pct=settings.runtime_busy_disk_pct,
                    high_disk_pct=settings.runtime_high_disk_pct,
                    critical_disk_pct=settings.runtime_critical_disk_pct,
                    busy_loop_lag_sec=settings.runtime_busy_loop_lag_sec,
                    high_loop_lag_sec=settings.runtime_high_loop_lag_sec,
                    critical_loop_lag_sec=settings.runtime_critical_loop_lag_sec,
                    feed_stale_sec=settings.event_stale_after_sec,
                ),
                disk_path=settings.baseline_db_path,
            )
            runtime_truth_service.refresh()
            background_tasks.append(asyncio.create_task(_runtime_truth_loop(), name="pulse-runtime-truth"))

        investor_flow = InvestorFlowService(rest)
        daily_context = DailyContextService(rest, settings.daily_context_ttl_sec)
        universe = UniverseService(rest, benchmark_mapper)
        sectors = SectorBreadthService(rest, settings.sector_component_limit)
        business_context = BusinessContextService()
        discovery = MarketDiscoveryService(
            rest,
            session_router,
            benchmark_mapper,
            subscribe_hook=ws_client.add_stock_items,
        )
        background_coverage = BackgroundCoverageService(
            universe, session_router, features, ws_client.set_background_items, settings.background_batch_size
        )
        smart_money = SmartMoneyService(
            features,
            investor_flow,
            daily_context,
            discovery,
            SmartMoneyEngine(settings.flow_amount_to_daily_value_scale),
            background=background_coverage,
            sectors=sectors,
            business=business_context,
        )
        ignition = IgnitionService(smart_money, IgnitionEngine())
        sector_spillover = SectorSpilloverService(smart_money, sectors, SectorSpilloverEngine())
        pullback_second_wave = PullbackSecondWaveService(features, smart_money, PullbackSecondWaveEngine())
        market_regime = MarketRegimeService(
            sectors, features, MarketRegimeEngine(),
            sector_max_age_sec=settings.market_regime_sector_max_age_sec,
            feature_max_age_sec=settings.market_regime_feature_max_age_sec,
        )
        supply_absorption = SupplyAbsorptionService(
            features=features,
            investor_flow=investor_flow,
            state=state,
            discovery=discovery,
            sectors=sectors,
            regime=market_regime,
            engine=SupplyAbsorptionEngine(),
            investor_max_age_sec=settings.supply_absorption_investor_max_age_sec,
            price_max_age_sec=settings.supply_absorption_price_max_age_sec,
            program_max_age_sec=settings.supply_absorption_program_max_age_sec,
            detail_ttl_sec=settings.supply_absorption_detail_ttl_sec,
            detail_requests_per_cycle=settings.supply_absorption_detail_requests_per_cycle,
        )
        if settings.dual_performance_enabled:
            dual_performance_store = DualPerformanceStore(settings.dual_performance_db_path)
            dual_performance = DualPerformanceService(store=dual_performance_store, absorption=supply_absorption, features=features)
            if settings.dual_daily_outcomes_enabled:
                dual_daily_outcomes = DualDailyOutcomeService(
                    store=dual_performance_store, source=DailyOutcomeBarSource(rest),
                    max_symbols_per_cycle=settings.dual_daily_outcomes_max_symbols_per_cycle,
                )
        if settings.transition_ops_enabled:
            transition_ops_store = TransitionOpsStore(settings.transition_ops_db_path)
            transition_ops = TransitionOpsService(
                store=transition_ops_store,
                absorption=supply_absorption,
                close_time=dt_time(settings.transition_ops_close_hour_kst, settings.transition_ops_close_minute_kst),
                alert_cooldown_sec=settings.transition_ops_alert_cooldown_sec,
            )
        if settings.nxt_native_enabled:
            nxt_native = NxtNativeService(
                features=features,
                universe=universe,
                engine=NxtNativeEngine(),
                spread_max_pct=settings.nxt_native_spread_max_pct,
                min_money_5m_krw=settings.nxt_native_min_money_5m_krw,
                close_strict_hour_kst=settings.nxt_native_close_strict_hour_kst,
                close_strict_minute_kst=settings.nxt_native_close_strict_minute_kst,
                max_rows=settings.nxt_native_refresh_limit,
            )
            if settings.nxt_operations_board_enabled:
                nxt_operations_board = NxtFixedOperationsBoardService(
                    source=nxt_native,
                    fixed_rows=settings.nxt_operations_board_fixed_rows,
                    qualification_dwell_sec=settings.nxt_operations_board_qualification_dwell_sec,
                    membership_commit_sec=settings.nxt_operations_board_membership_commit_sec,
                    missing_grace_sec=settings.nxt_operations_board_missing_grace_sec,
                    overtake_min_score_gap=settings.nxt_operations_board_overtake_min_score_gap,
                    overtake_required_checks=settings.nxt_operations_board_overtake_required_checks,
                    overtake_max_wait_sec=settings.nxt_operations_board_overtake_max_wait_sec,
                )
        pattern_completion = PatternCompletionService(features)
        confluence = ConfluenceService(
            features=features,
            smart_money=smart_money,
            discovery=discovery,
            ignition=ignition,
            spillover=sector_spillover,
            pullback=pullback_second_wave,
            regime=market_regime,
            universe=universe,
            engine=ConfluenceEngine(),
            patterns=pattern_completion,
            tick_max_age_sec=settings.hard_gate_tick_max_age_sec,
            required_discovery_sources=settings.hard_gate_required_discovery_sources,
            required_persistence=settings.hard_gate_required_persistence,
            krx_spread_max_pct=settings.hard_gate_krx_spread_max_pct,
            nxt_spread_max_pct=settings.hard_gate_nxt_spread_max_pct,
            min_money_5m_krw=settings.hard_gate_min_money_5m_krw,
        )
        krx_nxt_bridge = KrxNxtBridgeService(
            features, session_router, smart_money, confluence, sectors, KrxNxtBridgeEngine()
        )
        confluence.attach_bridge(krx_nxt_bridge)
        prebuy_decision = PreBuyDecisionService(
            features=features,
            smart_money=smart_money,
            confluence=confluence,
            ignition=ignition,
            spillover=sector_spillover,
            pullback=pullback_second_wave,
            patterns=pattern_completion,
            bridge=krx_nxt_bridge,
            engine=PreBuyDecisionEngine(),
            upstream_max_age_sec=settings.prebuy_decision_upstream_max_age_sec,
        )
        current_decision_compression = CurrentDecisionCompressionService(
            decisions=prebuy_decision,
            engine=CurrentDecisionCompressionEngine(),
            max_rows=settings.current_decision_compression_max_rows,
            source_max_age_sec=settings.current_decision_compression_source_max_age_sec,
        )
        if _presentation_safety_required(settings) and runtime_truth_service is not None:
            presentation_safety = PresentationSafetyService(
                runtime_truth=runtime_truth_service,
                feed_service=service,
                current_decisions=current_decision_compression,
            )
            presentation_safety.refresh()
        if settings.signal_ledger_enabled or validation_required:
            signal_ledger_store = SignalLedgerStore(settings.signal_ledger_db_path)
            signal_ledger = SignalLedgerService(
                store=signal_ledger_store,
                decisions=prebuy_decision,
                features=features,
                min_stage_dwell_sec=settings.signal_ledger_min_stage_dwell_sec,
                sample_interval_sec=settings.signal_ledger_sample_interval_sec,
                episode_end_absence_sec=settings.signal_ledger_episode_end_absence_sec,
            )
            if settings.signal_daily_outcomes_enabled:
                signal_daily_outcomes = DailyOutcomeCompletionService(
                    store=signal_ledger_store,
                    source=DailyOutcomeBarSource(rest),
                    refresh_ttl_sec=settings.signal_daily_outcomes_refresh_ttl_sec,
                    max_symbols_per_cycle=settings.signal_daily_outcomes_max_symbols_per_cycle,
                )
        if settings.missed_opportunity_enabled:
            missed_opportunity_store = MissedOpportunityStore(settings.missed_opportunity_db_path)
            missed_opportunity = MissedOpportunityService(
                store=missed_opportunity_store,
                rest=rest,
                universe=universe,
                discovery=discovery,
                absorption=supply_absorption,
                session_router=session_router,
                dual_store=dual_performance_store,
                signal_store=signal_ledger_store,
                surge_threshold_pct=settings.missed_opportunity_surge_threshold_pct,
                post_close_time=dt_time(settings.missed_opportunity_post_close_hour_kst, settings.missed_opportunity_post_close_minute_kst),
                max_pages_per_market=settings.missed_opportunity_max_pages_per_market,
                trade_value_condition=settings.missed_opportunity_trade_value_condition,
            )
        if validation_required:
            live_validation_store = LiveValidationStore(settings.live_shadow_validation_db_path)
            live_shadow_validation = LiveShadowValidationService(
                store=live_validation_store,
                app_version=__version__,
                environment=settings.env,
                session_router=session_router,
                state=state,
                features=features,
                feed_service=service,
                ws=ws_client,
                runtime_truth=runtime_truth_service,
                discovery=discovery,
                investor_flow=investor_flow,
                prebuy_decision=prebuy_decision,
                current_decisions=current_decision_compression,
                presentation_safety=presentation_safety,
                signal_ledger=signal_ledger,
            )
            live_shadow_validation.refresh()

        if (
            settings.live_certification_enabled
            and live_shadow_validation is not None
            and supply_absorption is not None
            and dual_performance_store is not None
            and nxt_native is not None
        ):
            live_certification_store = LiveCertificationStore(settings.live_certification_db_path)
            live_certification = LiveCertificationService(
                store=live_certification_store,
                state=state,
                features=features,
                investor_flow=investor_flow,
                absorption=supply_absorption,
                dual_store=dual_performance_store,
                nxt_native=nxt_native,
                ws=ws_client,
                feed_service=service,
                live_shadow_validation=live_shadow_validation,
                max_symbols=settings.live_certification_max_symbols,
                ws_heartbeat_sec=settings.live_certification_ws_heartbeat_sec,
                first_gate_days=settings.live_certification_first_gate_days,
                final_review_days=settings.live_certification_final_review_days,
            )
            live_certification.refresh()

        if settings.current_enrichment_enabled:
            current_enrichment = CurrentEnrichmentService(
                features=features,
                daily_context=daily_context,
                universe=universe,
                sectors=sectors,
                baseline_store=baseline_store,
                max_rows=settings.current_enrichment_max_rows,
                daily_requests_per_cycle=settings.current_enrichment_daily_requests_per_cycle,
            )

        if settings.krx_operations_board_enabled and supply_absorption is not None:
            krx_operations_board = KrxDualOperationsBoardService(
                source=supply_absorption,
                enrichment=current_enrichment,
                fixed_rows=settings.krx_operations_board_fixed_rows,
                qualification_dwell_sec=settings.krx_operations_board_qualification_dwell_sec,
                membership_commit_sec=settings.krx_operations_board_membership_commit_sec,
                missing_grace_sec=settings.krx_operations_board_missing_grace_sec,
                overtake_min_score_gap=settings.krx_operations_board_overtake_min_score_gap,
                overtake_required_checks=settings.krx_operations_board_overtake_required_checks,
                overtake_max_wait_sec=settings.krx_operations_board_overtake_max_wait_sec,
            )

        if settings.daily_review_enabled and dual_performance_store is not None and missed_opportunity_store is not None and transition_ops_store is not None:
            daily_review_store = DailyReviewStore(settings.daily_review_db_path)
            daily_review = DailyReviewService(
                store=daily_review_store,
                dual_store=dual_performance_store,
                missed_store=missed_opportunity_store,
                transition_store=transition_ops_store,
                enrichment=current_enrichment,
                review_time=dt_time(settings.daily_review_hour_kst, settings.daily_review_minute_kst),
                min_evidence_for_proposal=settings.daily_review_min_evidence_for_proposal,
            )

        if settings.universe_enabled or background_required or settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required or settings.supply_absorption_enabled or settings.nxt_native_enabled or settings.missed_opportunity_enabled or settings.current_enrichment_enabled:
            try:
                await universe.refresh()
            except Exception:
                pass
            background_tasks.append(asyncio.create_task(_universe_loop(), name="pulse-universe"))
        if background_required:
            background_tasks.append(asyncio.create_task(_background_coverage_loop(), name="pulse-background-coverage"))
        if settings.sector_enabled or settings.sector_spillover_enabled or settings.market_regime_enabled or settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required or settings.supply_absorption_enabled:
            background_tasks.append(asyncio.create_task(_sector_loop(), name="pulse-sector-breadth"))
        if settings.discovery_enabled or settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required or settings.supply_absorption_enabled or settings.nxt_native_enabled or settings.missed_opportunity_enabled or settings.current_enrichment_enabled:
            background_tasks.append(asyncio.create_task(_discovery_loop(), name="pulse-market-events"))
        if investor_required:
            background_tasks.append(asyncio.create_task(_investor_loop(), name="pulse-investor-flow"))
        if (settings.smart_money_enabled or settings.ignition_enabled or settings.sector_spillover_enabled
                or settings.pullback_second_wave_enabled or settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required):
            # All later shadows are derived from fresh SMART-MONEY frames.
            background_tasks.append(asyncio.create_task(_smart_money_loop(), name="pulse-smart-money"))
        if settings.supply_absorption_enabled and supply_absorption is not None:
            background_tasks.append(asyncio.create_task(_supply_absorption_loop(), name="pulse-supply-absorption-shadow"))
        if settings.dual_performance_enabled and dual_performance is not None:
            background_tasks.append(asyncio.create_task(_dual_performance_loop(), name="pulse-dual-performance"))
        if settings.dual_daily_outcomes_enabled and dual_daily_outcomes is not None:
            background_tasks.append(asyncio.create_task(_dual_daily_outcome_loop(), name="pulse-dual-daily-outcomes"))
        if settings.transition_ops_enabled and transition_ops is not None:
            background_tasks.append(asyncio.create_task(_transition_ops_loop(), name="pulse-transition-ops"))
        if settings.nxt_native_enabled and nxt_native is not None:
            background_tasks.append(asyncio.create_task(_nxt_native_loop(), name="pulse-nxt-native"))
        if settings.nxt_operations_board_enabled and nxt_operations_board is not None:
            background_tasks.append(asyncio.create_task(_nxt_operations_board_loop(), name="pulse-nxt-operations-board"))
        if settings.missed_opportunity_enabled and missed_opportunity is not None:
            background_tasks.append(asyncio.create_task(_missed_opportunity_loop(), name="pulse-missed-opportunity-audit"))
        if settings.current_enrichment_enabled and current_enrichment is not None:
            background_tasks.append(asyncio.create_task(_current_enrichment_loop(), name="pulse-current-enrichment"))
        if settings.krx_operations_board_enabled and krx_operations_board is not None:
            background_tasks.append(asyncio.create_task(_krx_operations_board_loop(), name="pulse-krx-operations-board"))
        if settings.daily_review_enabled and daily_review is not None:
            background_tasks.append(asyncio.create_task(_daily_review_loop(), name="pulse-daily-review-1900"))
        if settings.ignition_enabled or settings.confluence_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_ignition_loop(), name="pulse-ignition-shadow"))
        if settings.sector_spillover_enabled or settings.confluence_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_sector_spillover_loop(), name="pulse-sector-spillover-shadow"))
        if settings.pullback_second_wave_enabled or settings.confluence_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_pullback_second_wave_loop(), name="pulse-pullback-second-wave-shadow"))
        if settings.market_regime_enabled or settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required or settings.supply_absorption_enabled:
            background_tasks.append(asyncio.create_task(_market_regime_loop(), name="pulse-market-regime-shadow"))
        if settings.confluence_enabled or settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_confluence_loop(), name="pulse-confluence-hard-gate-shadow"))
        if settings.pattern_completion_enabled or settings.confluence_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_pattern_completion_loop(), name="pulse-pattern-completion-shadow"))
        if settings.krx_nxt_bridge_enabled or settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_krx_nxt_bridge_loop(), name="pulse-krx-nxt-bridge-shadow"))
        if settings.prebuy_decision_enabled or settings.current_decision_compression_enabled or settings.signal_ledger_enabled or validation_required:
            background_tasks.append(asyncio.create_task(_prebuy_decision_loop(), name="pulse-prebuy-decision-shadow"))
        if (settings.current_decision_compression_enabled or validation_required) and current_decision_compression is not None:
            background_tasks.append(asyncio.create_task(_current_decision_compression_loop(), name="pulse-current-decision-compression-shadow"))
        if presentation_safety is not None:
            background_tasks.append(asyncio.create_task(_presentation_safety_loop(), name="pulse-presentation-safety"))
        if (settings.signal_ledger_enabled or validation_required) and signal_ledger is not None:
            background_tasks.append(asyncio.create_task(_signal_ledger_loop(), name="pulse-signal-ledger"))
        if settings.signal_daily_outcomes_enabled and signal_daily_outcomes is not None:
            background_tasks.append(asyncio.create_task(_signal_daily_outcome_loop(), name="pulse-signal-daily-outcomes"))
        if live_shadow_validation is not None:
            background_tasks.append(asyncio.create_task(_live_shadow_validation_loop(), name="pulse-live-shadow-validation"))
        if live_certification is not None:
            background_tasks.append(asyncio.create_task(_live_certification_loop(), name="pulse-live-certification-evidence"))
        if baseline_store is not None:
            background_tasks.append(asyncio.create_task(_baseline_flush_loop(), name="pulse-baseline-flush"))

    yield

    if ws_client:
        await ws_client.stop()
    for task in background_tasks:
        task.cancel()
    for task in background_tasks:
        try:
            await task
        except asyncio.CancelledError:
            pass
    if baseline_store is not None:
        baseline_store.close()
    if signal_ledger_store is not None:
        signal_ledger_store.close()
    if live_validation_store is not None:
        live_validation_store.close()
    if live_certification_store is not None:
        live_certification_store.close()
    if dual_performance_store is not None:
        dual_performance_store.close()
    if transition_ops_store is not None:
        transition_ops_store.close()
    if missed_opportunity_store is not None:
        missed_opportunity_store.close()
    if daily_review_store is not None:
        daily_review_store.close()



_WEB_DIR = Path(__file__).resolve().parent / "web"
app = FastAPI(title="PULSE EDGE", version=__version__, lifespan=lifespan)
if settings.ui_enabled:
    app.mount("/assets", StaticFiles(directory=str(_WEB_DIR)), name="pulse-assets")


@app.get("/", include_in_schema=False)
def pulse_ui():
    if not settings.ui_enabled:
        raise HTTPException(status_code=404, detail="ui disabled")
    return FileResponse(_WEB_DIR / "index.html")


@app.get("/ui", include_in_schema=False)
def pulse_ui_alias():
    return pulse_ui()



@app.get("/api/diagnostics/pipeline")
def pipeline_diagnostics():
    def venue_count(mapping, venue):
        if not mapping:
            return 0
        return sum(1 for key in mapping if isinstance(key, tuple) and key and key[0] == venue)
    discovery_rows = discovery.recent(1000) if discovery is not None else []
    return {
        "display_only": True,
        "krx_nxt_isolation": True,
        "features": {"KRX": venue_count(features.frames, Venue.KRX), "NXT": venue_count(features.frames, Venue.NXT)},
        "smart_money": {"KRX": venue_count(getattr(smart_money, "frames", {}), Venue.KRX), "NXT": venue_count(getattr(smart_money, "frames", {}), Venue.NXT)},
        "confluence": {"KRX": venue_count(getattr(confluence, "frames", {}), Venue.KRX), "NXT": venue_count(getattr(confluence, "frames", {}), Venue.NXT)},
        "prebuy": {"KRX": venue_count(getattr(prebuy_decision, "frames", {}), Venue.KRX), "NXT": venue_count(getattr(prebuy_decision, "frames", {}), Venue.NXT)},
        "discovery_recent": {
            "KRX": sum(1 for row in discovery_rows if row.venue == Venue.KRX),
            "NXT": sum(1 for row in discovery_rows if row.venue == Venue.NXT),
        },
        "dual_absorption_rows": len(getattr(supply_absorption, "frames", {}) or {}),
        "krx_board_rows": len(getattr(krx_operations_board, "rows", {}) or {}),
        "nxt_native_rows": len(getattr(nxt_native, "frames", {}) or {}),
        "errors": {
            "discovery": getattr(discovery, "last_error", None),
            "smart_money": getattr(smart_money, "last_error", None),
            "confluence": getattr(confluence, "last_error", None),
            "prebuy": getattr(prebuy_decision, "last_error", None),
            "supply_absorption": getattr(supply_absorption, "last_error", None),
        },
    }


@app.get("/health")
async def health():
    return {
        "ok": True,
        "project": "PULSE EDGE",
        "version": __version__,
        "phase": "PHASE_6B_SUPPLY_ABSORPTION_SHADOW",
        "release_phase": "PHASE_6C_DUAL_SIGNAL_LEDGER_PERFORMANCE",
        "package_release": "2.1.3_KRX_NXT_ISOLATION_STABILITY",
        "runtime_safety_release": RUNTIME_SAFETY_RELEASE,
        "feed_enabled": settings.feed_enabled,
        "ws_connected": bool(ws_client and ws_client.connected),
        "ws_last_error": ws_client.last_error if ws_client else None,
        "runtime_truth_enabled": bool(runtime_truth_service is not None),
        "runtime_load_stage": runtime_truth_service.frame.load_stage.value if runtime_truth_service and runtime_truth_service.frame else None,
        "runtime_feed_health": runtime_truth_service.frame.feed_health.value if runtime_truth_service and runtime_truth_service.frame else None,
        "live_market_validation": live_shadow_validation.frame.live_market_validation if live_shadow_validation and live_shadow_validation.frame else "PENDING",
        "live_shadow_coverage": live_shadow_validation.frame.coverage_state if live_shadow_validation and live_shadow_validation.frame else None,
        "live_certification_state": live_certification.frame.certification_state.value if live_certification and live_certification.frame else "NOT_STARTED",
        "live_certification_qualifying_days": live_certification.frame.qualifying_days if live_certification and live_certification.frame else 0,
    }


@app.get("/api/live-shadow-validation")
def live_shadow_validation_status():
    if live_shadow_validation is None or live_shadow_validation.frame is None:
        return {
            "enabled": _live_shadow_validation_required(settings),
            "ready": False,
            "live_market_validation": "PENDING",
            "official_signal_enabled": False,
            "order_action_enabled": False,
            "feeds_current_decisions": False,
        }
    return {
        "enabled": True,
        "ready": True,
        "last_error": live_shadow_validation.last_error,
        **live_shadow_validation.frame.model_dump(mode="json"),
    }


@app.get("/api/live-shadow-validation/days")
def live_shadow_validation_days(limit: int = 10):
    if live_validation_store is None:
        return {"enabled": _live_shadow_validation_required(settings), "days": []}
    return {"enabled": True, "days": live_validation_store.recent_days(limit)}


@app.get("/api/live-certification")
def live_certification_status():
    if live_certification is None or live_certification.frame is None:
        return {
            "enabled": _live_certification_required(settings),
            "ready": False,
            "certification_state": "NOT_STARTED",
            "profitability_validation": "PENDING",
            "feeds_current_ranking": False,
            "feeds_current_score": False,
            "official_signal_enabled": False,
            "order_action_enabled": False,
            "broker_calls_added": 0,
        }
    return {
        "enabled": True,
        "ready": True,
        "last_error": live_certification.last_error,
        **live_certification.frame.model_dump(mode="json"),
    }


@app.get("/api/live-certification/days")
def live_certification_days(limit: int = 20):
    if live_certification_store is None:
        return {"enabled": _live_certification_required(settings), "days": []}
    return {"enabled": True, "days": live_certification_store.recent_days(limit)}


@app.get("/api/live-certification/evidence")
def live_certification_evidence(limit: int = 200, trading_day: str | None = None, kind: str | None = None):
    if live_certification_store is None:
        return {"enabled": _live_certification_required(settings), "items": []}
    return {
        "enabled": True,
        "feeds_current_ranking": False,
        "feeds_current_score": False,
        "items": live_certification_store.recent_events(limit, trading_day=trading_day, kind=kind),
    }


@app.get("/api/runtime-truth")
def runtime_truth_status():
    if runtime_truth_service is None or runtime_truth_service.frame is None:
        return {
            "enabled": _runtime_truth_required(settings),
            "ready": False,
            "official_signal_enabled": False,
            "order_action_enabled": False,
        }
    return {
        "enabled": True,
        "ready": True,
        "last_error": runtime_truth_service.last_error,
        **runtime_truth_service.frame.model_dump(mode="json"),
    }


@app.get("/api/session")
def session_status():
    now = datetime.now(timezone.utc)
    frame = session_router.frame_at(now)
    operator_phase = session_router.operator_phase_at(now)
    return {
        "asof": frame.asof.isoformat(),
        "trading_day": frame.trading_day,
        "phase": frame.phase.value,
        "operator_phase": operator_phase.value,
        "preopen_observation_active": session_router.preopen_observation_active(now),
        "action_gate_open": session_router.operator_action_gate_open(now),
        "action_gate_rule": "09:00_KST_MARKET_MAIN_ONLY",
        "nxt_late_session_active": frame.nxt_late_session_active,
        "official_operation_code": frame.official_operation_code,
        "official_operation_name": frame.official_operation_name,
    }


@app.get("/api/feed-truth")
def feed_truth():
    return {
        "counters": truth.counters,
        "last_reasons": truth.last_reasons,
        "continuity_rejects": service.continuity.rejects,
        "time_rejects": service.continuity.time_rejects,
        "volume_rejects": service.continuity.volume_rejects,
        "continuity_reasons": service.continuity_reasons,
        "session_rejects": service.session_rejects,
        "session_reasons": service.session_reasons,
        "total_payloads": service.total_payloads,
        "total_normalized": service.total_normalized,
        "last_payload_at": service.last_payload_at,
    }


def _serialize_book(book):
    out = {}
    for symbol, st in book.items():
        out[symbol] = {
            "events_by_type": {k: v.model_dump(mode="json") for k, v in st.events_by_type.items()},
        }
    return out


def _stock_name(symbol: str) -> str | None:
    """Resolve the current-session stock name from the PULSE universe.

    The numeric symbol remains the internal immutable key.  Presentation APIs
    receive a separate name field so the operator UI never needs to expose the
    code.  No ranking, scoring, gate or persistence behavior depends on name.
    """
    if universe is None:
        return None
    row = universe.stocks.get(str(symbol or "")[:6])
    if row is None:
        return None
    name = str(row.name or "").strip()
    return name or None


def _attach_stock_name(payload: dict) -> dict:
    payload = dict(payload)
    symbol = str(payload.get("symbol") or "")[:6]
    payload["name"] = _stock_name(symbol)
    return payload


def _current_data_payload(symbol: str):
    if current_enrichment is None:
        return None
    row = current_enrichment.get(symbol[:6])
    return row.model_dump(mode="json") if row is not None else None


def _dump_with_current_data(row, *, force_krx: bool = False):
    payload = _attach_stock_name(row.model_dump(mode="json"))
    venue = getattr(row, "venue", None)
    if force_krx or venue == Venue.KRX:
        payload["current_data"] = _current_data_payload(getattr(row, "symbol", ""))
    return payload


@app.get("/api/state/krx")
def state_krx():
    return {"count": len(state.krx), "items": _serialize_book(state.krx)}


@app.get("/api/state/nxt")
def state_nxt():
    return {"count": len(state.nxt), "items": _serialize_book(state.nxt)}


@app.get("/api/state/sor")
def state_sor():
    return {"count": len(state.sor), "items": _serialize_book(state.sor)}


@app.get("/api/features/{venue}/{symbol}")
def feature_frame(venue: str, symbol: str):
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = features.frames.get((v, symbol))
    if row is None:
        raise HTTPException(status_code=404, detail="feature frame not ready")
    payload = row.model_dump(mode="json")
    if v == Venue.KRX:
        payload["current_data"] = _current_data_payload(symbol)
    return payload


@app.get("/api/features/opening/{symbol}")
def opening_frame(symbol: str):
    row = features.opening_frames.get(symbol)
    if row is None:
        raise HTTPException(status_code=404, detail="opening frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/smart-flow/top")
def smart_flow_top(limit: int = 10):
    rows = [
        row for row in features.frames.values()
        if row.smart_flow_realtime_score_100 is not None and row.smart_flow_state != "DATA_WAIT"
    ]
    rows.sort(key=lambda r: (r.smart_flow_confirmed_windows, r.smart_flow_realtime_score_100 or 0.0), reverse=True)
    rows = rows[: max(1, min(int(limit), 100))]
    return {
        "enabled": settings.feed_enabled,
        "official_signal_enabled": False,
        "count": len(rows),
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/smart-flow/{venue}/{symbol}")
def smart_flow_symbol(venue: str, symbol: str):
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = features.frames.get((v, symbol[:6]))
    if row is None or row.smart_flow_realtime_score_100 is None:
        raise HTTPException(status_code=404, detail="smart-flow frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/discovery/recent")
def discovery_recent(limit: int = 100):
    if discovery is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = discovery.recent(limit)
    return {
        "enabled": bool(settings.discovery_enabled or _live_shadow_validation_required(settings) or settings.supply_absorption_enabled),
        "count": len(rows),
        "scan_count": discovery.scan_count,
        "last_scan_at": discovery.last_scan_at,
        "last_error": discovery.last_error,
        "api_call_count": discovery.api_call_count,
        "items": [_attach_stock_name(asdict(x)) for x in rows],
    }


@app.get("/api/flow")
def flow_status():
    if investor_flow is None:
        return {"enabled": False, "recent": [], "intraday": []}
    return {
        "enabled": bool(settings.investor_flow_enabled or _live_shadow_validation_required(settings) or settings.supply_absorption_enabled),
        "recent": [asdict(v) for v in investor_flow.recent.values()],
        "intraday": [asdict(v) for v in investor_flow.intraday.values()],
        "breakdown": [asdict(v) for v in investor_flow.breakdown.values()],
        "last_schema_error": investor_flow.last_schema_error,
    }


@app.get("/api/baseline")
def baseline_status():
    return {
        "enabled": baseline_store is not None,
        "rows": baseline_store.count_rows() if baseline_store is not None else 0,
    }


@app.get("/api/raw/recent")
def raw_recent(limit: int = 50):
    limit = max(1, min(limit, 200))
    rows = list(state.raw)[-limit:]
    return {"count": len(rows), "items": [x.model_dump(mode="json") for x in rows]}


@app.get("/api/supply-absorption/top")
def supply_absorption_top(limit: int = 10):
    if supply_absorption is None:
        return {
            "enabled": False,
            "shadow_only": True,
            "krx_only": True,
            "feeds_existing_ranking": False,
            "items": [],
        }
    rows = supply_absorption.top(limit)
    return {
        "enabled": bool(settings.supply_absorption_enabled),
        "shadow_only": True,
        "krx_only": True,
        "feeds_existing_ranking": False,
        "last_refresh_at": supply_absorption.last_refresh_at,
        "last_error": supply_absorption.last_error,
        "items": [_dump_with_current_data(row, force_krx=True) for row in rows],
    }


@app.get("/api/supply-absorption/{symbol}")
def supply_absorption_one(symbol: str):
    if supply_absorption is None:
        raise HTTPException(status_code=404, detail="supply absorption shadow not ready")
    row = supply_absorption.get(symbol[:6])
    if row is None:
        raise HTTPException(status_code=404, detail="symbol not in current KRX absorption set")
    return _dump_with_current_data(row, force_krx=True)


@app.get("/api/dual-absorption/top")
def dual_absorption_top(limit: int = 10):
    return supply_absorption_top(limit)


@app.get("/api/dual-absorption/{symbol}")
def dual_absorption_one(symbol: str):
    return supply_absorption_one(symbol)


@app.get("/api/dual-performance/signals")
def dual_performance_signals(limit: int = 100):
    if dual_performance_store is None:
        return {"enabled": False, "history_feeds_current_ranking": False, "items": []}
    rows = dual_performance_store.recent(max(1, min(limit, 1000)))
    return {"enabled": True, "history_feeds_current_ranking": False, "items": [dict(r) for r in rows]}


@app.get("/api/dual-performance/summary")
def dual_performance_summary(limit: int = 1000):
    if dual_performance is None:
        return {"enabled": False, "history_feeds_current_ranking": False, "items": []}
    return {"enabled": True, "history_feeds_current_ranking": False, "items": dual_performance.summary(max(1, min(limit, 5000)))}


@app.get("/api/dual-performance/transitions")
def dual_performance_transitions(limit: int = 5000):
    if dual_performance is None:
        return {"enabled": False, "history_feeds_current_ranking": False, "items": []}
    return {"enabled": True, "history_feeds_current_ranking": False, "items": dual_performance.transition_rates(max(1, min(limit, 10000)))}


@app.get("/api/transition-alerts")
def transition_alerts(limit: int = 100):
    if transition_ops_store is None:
        return {"enabled": False, "feeds_existing_ranking": False, "items": []}
    rows = transition_ops_store.recent_alerts(max(1, min(limit, 1000)))
    return {"enabled": True, "feeds_existing_ranking": False, "items": [_attach_stock_name(dict(r)) for r in rows]}


@app.get("/api/krx-close-classifications")
def krx_close_classifications(trading_day: str | None = None, limit: int = 100):
    if transition_ops_store is None:
        return {"enabled": False, "reference_only_next_session": True, "feeds_next_session_current_facts": False, "items": []}
    rows = transition_ops_store.close_rows(trading_day, max(1, min(limit, 1000)))
    return {
        "enabled": True,
        "reference_only_next_session": True,
        "feeds_next_session_current_facts": False,
        "feeds_existing_ranking": False,
        "items": [_attach_stock_name(dict(r)) for r in rows],
    }


@app.get("/api/phase6d/status")
def phase6d_status():
    return {
        "enabled": bool(settings.transition_ops_enabled and transition_ops is not None),
        "phase": "6D",
        "alert_source": "current_krx_absorption_frame_one_way",
        "close_classes": ["CLOSE_PRE_IGNITION", "SUPPLY_TIGHT_OVERNIGHT", "PRICE_HOLD_OVERNIGHT", "FAILED"],
        "history_feeds_current_ranking": False,
        "close_history_feeds_next_session_current_facts": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "last_refresh_at": transition_ops.last_refresh_at if transition_ops else None,
        "last_error": transition_ops.last_error if transition_ops else None,
    }


@app.get("/api/missed-opportunities")
def missed_opportunities(limit: int = 100, status: str | None = None):
    if missed_opportunity_store is None:
        return {"enabled": False, "history_feeds_current_ranking": False, "items": []}
    normalized = None
    if status:
        try:
            normalized = OpportunityStatus(status.upper()).value
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="invalid missed-opportunity status") from exc
    rows = missed_opportunity_store.recent(max(1, min(limit, 1000)), status=normalized)
    return {"enabled": True, "history_feeds_current_ranking": False, "items": [dict(r) for r in rows]}


@app.get("/api/missed-opportunities/summary")
def missed_opportunities_summary(trading_day: str | None = None):
    if missed_opportunity_store is None:
        return {"enabled": False, "history_feeds_current_ranking": False, "summary": {"count": 0}}
    return {"enabled": True, "history_feeds_current_ranking": False, "summary": missed_opportunity_store.summary(trading_day)}


@app.get("/api/missed-opportunities/scan-runs")
def missed_opportunity_scan_runs(limit: int = 30):
    if missed_opportunity_store is None:
        return {"enabled": False, "items": []}
    return {"enabled": True, "history_feeds_current_ranking": False, "items": [dict(r) for r in missed_opportunity_store.scan_runs(max(1, min(limit, 365)))]}


@app.get("/api/phase6f/status")
def phase6f_status():
    return {
        "enabled": bool(settings.missed_opportunity_enabled and missed_opportunity is not None),
        "phase": "6F",
        "post_close_only_full_market_rank_scan": True,
        "source_api": "ka10027",
        "source_schema_key": "pred_pre_flu_rt_upper",
        "api_mapping_publication_conflict_known": False,
        "runtime_fail_closed_on_provenance_or_schema_mismatch": True,
        "exchange": "KRX_ONLY",
        "markets": ["KOSPI", "KOSDAQ"],
        "surge_threshold_pct": settings.missed_opportunity_surge_threshold_pct,
        "trade_value_condition": settings.missed_opportunity_trade_value_condition,
        "max_rank_pages_per_market": settings.missed_opportunity_max_pages_per_market,
        "response_api_id_validation": True,
        "response_schema_validation": True,
        "full_trade_value_rank_scan": settings.missed_opportunity_trade_value_condition == "0",
        "intraday_evidence_archive_is_one_way": True,
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "nxt_input": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "last_refresh_at": missed_opportunity.last_refresh_at if missed_opportunity else None,
        "last_scan_at": missed_opportunity.last_scan_at if missed_opportunity else None,
        "last_scan_stats": missed_opportunity.last_scan_stats if missed_opportunity else {},
        "last_error": missed_opportunity.last_error if missed_opportunity else None,
        "phase7a1_1900_daily_review_exists": True,
        "phase7a1_review_time_kst": f"{settings.daily_review_hour_kst:02d}:{settings.daily_review_minute_kst:02d}",
        "phase7a1_sources": ["PHASE_6C_DUAL_PERFORMANCE", "PHASE_6D_TRANSITION_AND_CLOSE", "PHASE_6F_MISSED_OPPORTUNITY", "PHASE_6G_CURRENT_DATA"],
        "phase7a1_primary_intraday_outcome_priority": ["CLOSE", "30M", "10M"],
        "phase7a1_scores_models_stages_and_model_stage": True,
        "phase7a1_scores_transition_rates": True,
        "phase7a1_scores_preemptive_catch_rate": True,
        "phase7a1_scores_miss_reasons": True,
        "phase7a1_scores_data_completeness": True,
        "phase7a1_next_session_focus_is_reference_only": True,
        "phase7a1_krx_operations_board_is_input": False,
        "phase7a1_rule_proposals_are_proposal_only": True,
        "phase7a1_history_feeds_current_ranking": False,
        "phase7a1_history_feeds_current_score": False,
        "phase7a1_proposals_apply_automatically": False,
        "phase7a1_new_broker_calls": 0,
        "phase7a1_official_trading_signals": 0,
        "phase7a1_order_actions": 0,
        "phase7_07_briefing_exists": False,
    }


@app.get("/api/current-data/top")
def current_data_top(limit: int = 20):
    if current_enrichment is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = current_enrichment.top(limit)
    return {
        "enabled": bool(settings.current_enrichment_enabled),
        "count": len(rows),
        "last_refresh_at": current_enrichment.last_refresh_at,
        "last_error": current_enrichment.last_error,
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/current-data/{symbol}")
def current_data_symbol(symbol: str):
    if current_enrichment is None:
        raise HTTPException(status_code=404, detail="current-data service not ready")
    row = current_enrichment.get(symbol)
    if row is None:
        raise HTTPException(status_code=404, detail="symbol not present in current KRX enrichment")
    return row.model_dump(mode="json")


@app.get("/api/phase6g/status")
def phase6g_status():
    return {
        "enabled": bool(settings.current_enrichment_enabled and current_enrichment is not None),
        "krx_only": True,
        "daily_reference_api": "ka10081",
        "universe_metadata_api": "ka10099",
        "new_composite_score": False,
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "daily_requests_per_cycle": settings.current_enrichment_daily_requests_per_cycle,
        "last_daily_hydration_count": current_enrichment.last_daily_hydration_count if current_enrichment else 0,
        "last_refresh_at": current_enrichment.last_refresh_at if current_enrichment else None,
        "last_error": current_enrichment.last_error if current_enrichment else None,
        "phase7_07_briefing_exists": False,
    }


@app.get("/api/krx-operations-board")
def krx_operations_board_api():
    if krx_operations_board is None:
        return {
            "enabled": False,
            "fixed_rows": 10,
            "feeds_existing_ranking": False,
            "new_trading_score": False,
            "items": [],
        }
    view = krx_operations_board.view(datetime.now(timezone.utc))
    return {
        "enabled": bool(settings.krx_operations_board_enabled),
        "fixed_rows": krx_operations_board.fixed_rows,
        "feeds_existing_ranking": False,
        "new_trading_score": False,
        "last_refresh_at": krx_operations_board.last_refresh_at,
        "last_error": krx_operations_board.last_error,
        "qualification_dwell_sec": krx_operations_board.qualification_dwell_sec,
        "membership_commit_sec": krx_operations_board.membership_commit_sec,
        "overtake_min_score_gap": krx_operations_board.overtake_min_score_gap,
        "items": [_attach_stock_name(x.model_dump(mode="json")) for x in view.items],
    }


@app.get("/api/phase6g1/status")
def phase6g1_status():
    return {
        "enabled": bool(settings.krx_operations_board_enabled and krx_operations_board is not None),
        "phase": "6G.1",
        "krx_only": True,
        "fixed_rows": 10,
        "source": "CURRENT_DUAL_ABSORPTION_ONLY",
        "current_data_overlay": True,
        "transition_alerts_api": "/api/transition-alerts",
        "close_classification_api": "/api/krx-close-classifications",
        "missed_opportunity_api": "/api/missed-opportunities/summary",
        "feeds_existing_ranking": False,
        "new_trading_score": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "phase7_07_briefing_exists": False,
    }


@app.get("/api/smart-money/top")
def smart_money_top(limit: int = 10):
    if smart_money is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = smart_money.top(limit)
    return {
        "enabled": bool(settings.smart_money_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "count": len(rows),
        "last_refresh_at": smart_money.last_refresh_at,
        "last_error": smart_money.last_error,
        "items": [_attach_stock_name(row.model_dump(mode="json")) for row in rows],
    }


@app.get("/api/operator/krx-discovery-top")
def operator_krx_discovery_top(limit: int = 10):
    """Display-only KRX early-flow rows. Never feeds a score or selection."""
    if smart_money is None:
        return {"enabled": False, "count": 0, "venue": "KRX", "items": []}
    n = max(1, min(int(limit), 100))
    rows = [row for row in smart_money.top(max(40, n * 4)) if row.venue == Venue.KRX][:n]
    return {
        "enabled": bool(settings.smart_money_enabled or _live_shadow_validation_required(settings)),
        "display_only": True,
        "venue": "KRX",
        "count": len(rows),
        "last_refresh_at": smart_money.last_refresh_at,
        "last_error": smart_money.last_error,
        "items": [_attach_stock_name(row.model_dump(mode="json")) for row in rows],
    }


@app.get("/api/smart-money/{venue}/{symbol}")
def smart_money_symbol(venue: str, symbol: str):
    if smart_money is None:
        raise HTTPException(status_code=404, detail="smart-money service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = smart_money.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="smart-money frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/ignition/top")
def ignition_top(limit: int = 10):
    if ignition is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = ignition.top(limit)
    return {
        "enabled": bool(settings.ignition_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "count": len(rows),
        "last_refresh_at": ignition.last_refresh_at,
        "last_error": ignition.last_error,
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/ignition/{venue}/{symbol}")
def ignition_symbol(venue: str, symbol: str):
    if ignition is None:
        raise HTTPException(status_code=404, detail="ignition service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = ignition.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="ignition frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/sector-spillover/top")
def sector_spillover_top(limit: int = 10):
    if sector_spillover is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = sector_spillover.top(limit)
    return {
        "enabled": bool(settings.sector_spillover_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "count": len(rows),
        "last_refresh_at": sector_spillover.last_refresh_at,
        "last_error": sector_spillover.last_error,
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/sector-spillover/{venue}/{symbol}")
def sector_spillover_symbol(venue: str, symbol: str):
    if sector_spillover is None:
        raise HTTPException(status_code=404, detail="sector-spillover service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = sector_spillover.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="sector-spillover frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/pullback-second-wave/top")
def pullback_second_wave_top(limit: int = 10):
    if pullback_second_wave is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = pullback_second_wave.top(limit)
    return {
        "enabled": bool(settings.pullback_second_wave_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "count": len(rows),
        "last_refresh_at": pullback_second_wave.last_refresh_at,
        "last_error": pullback_second_wave.last_error,
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/pullback-second-wave/{venue}/{symbol}")
def pullback_second_wave_symbol(venue: str, symbol: str):
    if pullback_second_wave is None:
        raise HTTPException(status_code=404, detail="pullback-second-wave service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = pullback_second_wave.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="pullback-second-wave frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/market-regime")
def market_regime_status():
    if market_regime is None:
        return {"enabled": False, "state": "DATA_WAIT", "official_signal_enabled": False}
    row = market_regime.frame or market_regime.refresh()
    return {
        "enabled": bool(settings.market_regime_enabled or _live_shadow_validation_required(settings)),
        "last_refresh_at": market_regime.last_refresh_at,
        "last_error": market_regime.last_error,
        **row.model_dump(mode="json"),
    }


@app.get("/api/confluence/top")
def confluence_top(limit: int = 10):
    if confluence is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "items": []}
    rows = confluence.top(limit)
    return {
        "enabled": bool(settings.confluence_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "count": len(rows),
        "last_refresh_at": confluence.last_refresh_at,
        "last_error": confluence.last_error,
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/confluence/{venue}/{symbol}")
def confluence_symbol(venue: str, symbol: str):
    if confluence is None:
        raise HTTPException(status_code=404, detail="confluence service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = confluence.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="confluence frame not ready")
    return row.model_dump(mode="json")


@app.get("/api/orb-retest/top")
def orb_retest_top(limit: int = 10):
    if pattern_completion is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "items": []}
    rows = pattern_completion.top_orb(limit)
    return {"enabled": bool(settings.pattern_completion_enabled or _live_shadow_validation_required(settings)), "official_signal_enabled": False, "count": len(rows),
            "last_refresh_at": pattern_completion.last_refresh_at, "last_error": pattern_completion.last_error,
            "items": [row.model_dump(mode="json") for row in rows]}


@app.get("/api/squeeze-release/top")
def squeeze_release_top(limit: int = 10):
    if pattern_completion is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "items": []}
    rows = pattern_completion.top_squeeze(limit)
    return {"enabled": bool(settings.pattern_completion_enabled or _live_shadow_validation_required(settings)), "official_signal_enabled": False, "count": len(rows),
            "last_refresh_at": pattern_completion.last_refresh_at, "last_error": pattern_completion.last_error,
            "items": [row.model_dump(mode="json") for row in rows]}


@app.get("/api/vwap-reclaim/top")
def vwap_reclaim_top(limit: int = 10):
    if pattern_completion is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "items": []}
    rows = pattern_completion.top_reclaim(limit)
    return {"enabled": bool(settings.pattern_completion_enabled or _live_shadow_validation_required(settings)), "official_signal_enabled": False, "count": len(rows),
            "last_refresh_at": pattern_completion.last_refresh_at, "last_error": pattern_completion.last_error,
            "items": [row.model_dump(mode="json") for row in rows]}


@app.get("/api/nxt-native/top")
def nxt_native_top(limit: int = 10):
    if nxt_native is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "order_action_enabled": False, "items": []}
    rows = nxt_native.top(limit)
    return {
        "enabled": bool(settings.nxt_native_enabled),
        "count": len(rows),
        "last_refresh_at": nxt_native.last_refresh_at,
        "last_error": nxt_native.last_error,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "krx_investor_flow_used": False,
        "investor_flow_source": "UNAVAILABLE",
        "items": [row.model_dump(mode="json") for row in rows],
    }


@app.get("/api/nxt-native/{symbol}")
def nxt_native_symbol(symbol: str):
    if nxt_native is None:
        raise HTTPException(status_code=404, detail="nxt native service not ready")
    row = nxt_native.get(symbol)
    if row is None:
        raise HTTPException(status_code=404, detail="nxt native symbol not found")
    return row.model_dump(mode="json")


@app.get("/api/phase6e/status")
def phase6e_status():
    return {
        "enabled": bool(settings.nxt_native_enabled and nxt_native is not None),
        "phase_windows_kst": {
            "NXT_EARLY_FLOW": "15:40-18:30",
            "NXT_EARLY_BUY": "18:30-19:30",
            "NXT_CLOSE_BET": "19:30-19:55",
            "STRICT_CLOSE_GATE": "19:50-19:55",
        },
        "nxt_realtime_inputs": ["price", "trades", "orderbook", "money", "VWAP", "OFI", "aggressive_flow", "microprice"],
        "krx_input": "SAME_DAY_CLOSE_REFERENCE_PRICE_ONLY",
        "krx_investor_flow_used": False,
        "nxt_direct_investor_flow_available": False,
        "microstructure_flow_trust": "ESTIMATED",
        "history_feeds_current_ranking": False,
        "bridge_score_reuse": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "last_refresh_at": nxt_native.last_refresh_at if nxt_native else None,
        "last_error": nxt_native.last_error if nxt_native else None,
    }


@app.get("/api/nxt-operations-board")
def nxt_operations_board_api():
    if nxt_operations_board is None:
        return {
            "enabled": False, "fixed_rows": 10, "current_phase": "CLOSED",
            "official_signal_enabled": False, "order_action_enabled": False,
            "history_feeds_current_ranking": False, "krx_investor_flow_used": False,
            "boards": {},
        }
    now = datetime.now(timezone.utc)
    views = nxt_operations_board.views(now)
    return {
        "enabled": bool(settings.nxt_operations_board_enabled),
        "fixed_rows": nxt_operations_board.fixed_rows,
        "current_phase": nxt_native.engine.phase_at(now).value if nxt_native is not None else "CLOSED",
        "last_refresh_at": nxt_operations_board.last_refresh_at,
        "last_error": nxt_operations_board.last_error,
        "qualification_dwell_sec": nxt_operations_board.qualification_dwell_sec,
        "membership_commit_sec": nxt_operations_board.membership_commit_sec,
        "overtake_min_score_gap": nxt_operations_board.overtake_min_score_gap,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "history_feeds_current_ranking": False,
        "krx_investor_flow_used": False,
        "new_broker_calls": 0,
        "boards": {
            name: {
                **view.model_dump(mode="json"),
                "items": [_attach_stock_name(x.model_dump(mode="json")) for x in view.items],
            }
            for name, view in views.items()
        },
    }


@app.get("/api/phase6e1/status")
def phase6e1_status():
    return {
        "enabled": bool(settings.nxt_operations_board_enabled and nxt_operations_board is not None),
        "fixed_rows_each_board": 10,
        "boards": ["NXT_EARLY_FLOW", "NXT_EARLY_BUY", "NXT_CLOSE_BET"],
        "qualification_dwell_sec": settings.nxt_operations_board_qualification_dwell_sec,
        "membership_commit_sec": settings.nxt_operations_board_membership_commit_sec,
        "overtake_rule": {
            "min_score_gap": settings.nxt_operations_board_overtake_min_score_gap,
            "required_checks": settings.nxt_operations_board_overtake_required_checks,
            "max_wait_sec": settings.nxt_operations_board_overtake_max_wait_sec,
        },
        "hard_risk_removal": ["NXT_STALE", "NXT_WIDE_SPREAD", "NXT_LOW_LIQUIDITY", "NXT_OVERHEATED", "DATA_WAIT"],
        "source": "PHASE6E_NXT_NATIVE_FRAMES_ONLY",
        "new_trading_score": False,
        "krx_investor_flow_used": False,
        "history_feeds_current_ranking": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "new_broker_calls": 0,
        "phase7_07_briefing_exists": False,
    }


@app.get("/api/krx-nxt-bridge/top")
def krx_nxt_bridge_top(limit: int = 10):
    if krx_nxt_bridge is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "items": []}
    rows = krx_nxt_bridge.top(limit)
    return {"enabled": bool(settings.krx_nxt_bridge_enabled or _live_shadow_validation_required(settings)), "official_signal_enabled": False, "count": len(rows),
            "last_refresh_at": krx_nxt_bridge.last_refresh_at, "last_error": krx_nxt_bridge.last_error,
            "items": [row.model_dump(mode="json") for row in rows]}


@app.get("/api/prebuy/top")
def prebuy_top(limit: int = 10):
    if prebuy_decision is None:
        return {"enabled": False, "count": 0, "official_signal_enabled": False, "order_action_enabled": False, "items": []}
    rows = prebuy_decision.top(limit)
    return {
        "enabled": bool(settings.prebuy_decision_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "count": len(rows),
        "last_refresh_at": prebuy_decision.last_refresh_at,
        "last_error": prebuy_decision.last_error,
        "items": [_dump_with_current_data(row) for row in rows],
    }


@app.get("/api/operator/krx-prebuy-top")
def operator_krx_prebuy_top(limit: int = 10):
    """Operator KRX PRE-BUY view; NXT is intentionally excluded."""
    if prebuy_decision is None:
        return {"enabled": False, "count": 0, "venue": "KRX", "official_signal_enabled": False, "order_action_enabled": False, "items": []}
    n = max(1, min(int(limit), 100))
    rows = [row for row in prebuy_decision.top(max(40, n * 4)) if row.venue == Venue.KRX][:n]
    return {
        "enabled": bool(settings.prebuy_decision_enabled or _live_shadow_validation_required(settings)),
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "venue": "KRX",
        "count": len(rows),
        "last_refresh_at": prebuy_decision.last_refresh_at,
        "last_error": prebuy_decision.last_error,
        "items": [_dump_with_current_data(row, force_krx=True) for row in rows],
    }


@app.get("/api/prebuy/{venue}/{symbol}")
def prebuy_symbol(venue: str, symbol: str):
    if prebuy_decision is None:
        raise HTTPException(status_code=404, detail="prebuy decision service not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = prebuy_decision.frames.get((v, symbol[:6]))
    if row is None:
        raise HTTPException(status_code=404, detail="prebuy decision frame not ready")
    return _dump_with_current_data(row)


@app.get("/api/ledger/recent")
def ledger_recent(limit: int = 100):
    if signal_ledger is None:
        return {"enabled": False, "count": 0, "history_only": True, "items": []}
    rows = signal_ledger.recent(limit)
    return {
        "enabled": bool(settings.signal_ledger_enabled or _live_shadow_validation_required(settings)),
        "history_only": True,
        "feeds_current_rows": False,
        "count": len(rows),
        "items": [_attach_stock_name(row.model_dump(mode="json")) for row in rows],
    }


@app.get("/api/ledger/{episode_id}")
def ledger_detail(episode_id: str):
    if signal_ledger is None:
        raise HTTPException(status_code=404, detail="signal ledger not ready")
    row = signal_ledger.detail(episode_id)
    if row is None:
        raise HTTPException(status_code=404, detail="signal episode not found")
    row["history_only"] = True
    row["feeds_current_rows"] = False
    return row


@app.get("/api/performance/summary")
def performance_summary(limit: int = 500):
    if signal_ledger is None:
        return {"enabled": False, "sample_count": 0, "probability_calibrated": False, "by_primary_route": []}
    out = signal_ledger.performance(limit)
    out["enabled"] = bool(settings.signal_ledger_enabled or _live_shadow_validation_required(settings))
    out["history_only"] = True
    return out


@app.get("/api/daily-context/{symbol}")
def daily_context_symbol(symbol: str):
    if daily_context is None:
        raise HTTPException(status_code=404, detail="daily context service not ready")
    row = daily_context.frames.get(symbol[:6])
    if row is None:
        raise HTTPException(status_code=404, detail="daily context not ready")
    return {
        "symbol": row.symbol,
        "asof": row.asof.isoformat(),
        "return_5d_pct": row.return_5d_pct,
        "atr_compression_ratio": row.atr_compression_ratio,
        "range_compression_ratio": row.range_compression_ratio,
        "volume_ratio": row.volume_ratio,
        "rising_lows": row.rising_lows,
        "traded_value_5d_raw": row.traded_value_5d_raw,
        "flags": list(row.flags),
    }


@app.get("/api/universe")
def universe_status(limit: int = 50):
    if universe is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = universe.eligible()[: max(1, min(int(limit), 200))]
    return {
        "enabled": bool(settings.universe_enabled or _live_shadow_validation_required(settings)),
        "count": len(universe.stocks),
        "last_refresh_at": universe.last_refresh_at,
        "last_error": universe.last_error,
        "items": [asdict(x) for x in rows],
    }


@app.get("/api/background-coverage")
def background_coverage_status():
    if background_coverage is None:
        return {"enabled": False, "count": 0, "items": []}
    return {
        "enabled": bool(settings.background_coverage_enabled or _live_shadow_validation_required(settings)),
        "rotation_count": background_coverage.rotation_count,
        "cursor": background_coverage.cursor,
        "last_rotation_at": background_coverage.last_rotation_at,
        "count": len(background_coverage.current),
        "items": [{"venue": venue.value, "symbol": symbol} for venue, symbol in background_coverage.current],
    }


@app.get("/api/sectors")
def sector_status(limit: int = 30):
    if sectors is None:
        return {"enabled": False, "count": 0, "items": []}
    rows = sorted(sectors.frames.values(), key=lambda x: x.score_15, reverse=True)[: max(1, min(int(limit), 100))]
    return {
        "enabled": bool(settings.sector_enabled or _live_shadow_validation_required(settings)),
        "count": len(sectors.frames),
        "last_refresh_at": sectors.last_refresh_at,
        "last_error": sectors.last_error,
        "items": [asdict(x) for x in rows],
    }


@app.get("/api/business-context/{symbol}")
def business_context_status(symbol: str):
    if business_context is None:
        raise HTTPException(status_code=404, detail="business context service not ready")
    row = business_context.frame(symbol[:6])
    if row is None:
        return {"symbol": symbol[:6], "verified_context": False, "score_10": 0.0}
    return asdict(row)


@app.get("/api/presentation-safety")
def presentation_safety_status():
    if presentation_safety is None or presentation_safety.frame is None:
        return {
            "enabled": _presentation_safety_required(settings),
            "state": "LOCKED" if not settings.feed_enabled else "FROZEN",
            "reason_codes": ["feed_disabled" if not settings.feed_enabled else "presentation_safety_not_ready"],
            "new_action_presentation_allowed": False,
            "buy_like_language_allowed": False,
            "official_signal_enabled": False,
            "order_action_enabled": False,
            "historical_restore_used": False,
            "items": [],
        }
    frame = presentation_safety.frame
    data = frame.model_dump(mode="json")
    data["enabled"] = True
    # Operator current-decision board is KRX-only. NXT has independent native boards.
    rows = data.pop("rows")
    data["items"] = [
        _attach_stock_name(x) for x in rows
        if str(x.get("venue") or "").upper() == "KRX"
    ]

    # Phase 7B.0 operator gate: 08:00-09:00 is live observation only.
    # This never mutates current decisions, ranks, scores, DUAL, PRICE HOLD,
    # PRE-BUY or NXT; it only suppresses buy-like presentation before 09:00 KST.
    now = datetime.now(timezone.utc)
    operator_phase = session_router.operator_phase_at(now)
    data["operator_phase"] = operator_phase.value
    data["preopen_observation_active"] = session_router.preopen_observation_active(now)
    data["action_gate_open"] = session_router.operator_action_gate_open(now)
    if data["preopen_observation_active"]:
        data["new_action_presentation_allowed"] = False
        data["buy_like_language_allowed"] = False
        reasons = list(data.get("reason_codes") or [])
        if "preopen_observe_only" not in reasons:
            reasons.append("preopen_observe_only")
        data["reason_codes"] = reasons
    return data


@app.get("/api/presentation/current-decision")
def presentation_current_decision():
    return presentation_safety_status()


@app.get("/api/current-decision/top")
def current_decision_top(limit: int = 3):
    if current_decision_compression is None:
        return {
            "enabled": False, "shadow_only": True, "count": 0,
            "max_rows": min(3, settings.current_decision_compression_max_rows),
            "historical_performance_used_for_ranking": False,
            "new_composite_score_created": False,
            "official_signal_enabled": False, "order_action_enabled": False, "items": [],
        }
    rows = current_decision_compression.top(limit)
    return {
        "enabled": bool(settings.current_decision_compression_enabled or _live_shadow_validation_required(settings)),
        "shadow_only": True,
        "count": len(rows),
        "max_rows": current_decision_compression.max_rows,
        "last_refresh_at": current_decision_compression.last_refresh_at,
        "last_error": current_decision_compression.last_error,
        "historical_performance_used_for_ranking": False,
        "new_composite_score_created": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "items": [_dump_with_current_data(row) for row in rows],
    }


@app.get("/api/current-decision/{venue}/{symbol}")
def current_decision_symbol(venue: str, symbol: str):
    if current_decision_compression is None:
        raise HTTPException(status_code=404, detail="current-decision compression not ready")
    try:
        v = Venue(venue.upper())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="invalid venue") from exc
    row = current_decision_compression.get(v, symbol[:6])
    if row is None:
        raise HTTPException(status_code=404, detail="symbol is not in the current compressed set")
    return _dump_with_current_data(row)


@app.get("/api/daily-review/latest")
def daily_review_latest():
    if daily_review_store is None:
        return {"enabled": bool(settings.daily_review_enabled), "item": None}
    rows = daily_review_store.recent(1)
    return {
        "enabled": True,
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "proposals_apply_automatically": False,
        "item": rows[0].model_dump(mode="json") if rows else None,
    }


@app.get("/api/daily-review/{trading_day}")
def daily_review_by_day(trading_day: str):
    if daily_review_store is None:
        raise HTTPException(status_code=404, detail="daily review unavailable")
    row = daily_review_store.get(trading_day)
    if row is None:
        raise HTTPException(status_code=404, detail="daily review not found")
    return {
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "proposals_apply_automatically": False,
        "item": row.model_dump(mode="json"),
    }


@app.get("/api/phase7a/status")
def phase7a_status():
    return {
        "enabled": bool(settings.daily_review_enabled and daily_review is not None),
        "phase": "7A.1",
        "review_time_kst": f"{settings.daily_review_hour_kst:02d}:{settings.daily_review_minute_kst:02d}",
        "sources": ["PHASE_6C_DUAL_PERFORMANCE", "PHASE_6D_TRANSITION_AND_CLOSE", "PHASE_6F_MISSED_OPPORTUNITY", "PHASE_6G_CURRENT_DATA"],
        "krx_operations_board_is_input": False,
        "proposal_mode": "PROPOSAL_ONLY",
        "history_feeds_current_ranking": False,
        "history_feeds_current_score": False,
        "proposals_apply_automatically": False,
        "morning_briefing_exists": False,
        "official_signal_enabled": False,
        "order_action_enabled": False,
        "last_refresh_at": daily_review.last_refresh_at if daily_review else None,
        "last_error": daily_review.last_error if daily_review else None,
    }


@app.get("/api/contract")
def contract():
    return {
        "live_certification_evidence_exists": True,
        "live_certification_strategy_core_mutated": False,
        "live_certification_new_broker_calls": 0,
        "live_certification_history_feeds_current_ranking": False,
        "live_certification_history_feeds_current_score": False,
        "live_certification_automatic_final_certification": False,
        "smart_money_100_shadow_exists": True,
        "official_trading_signal_layer_exists": False,
        "smart_money_stage": "SHADOW_ONLY",
        "ignition_shadow_exists": True,
        "ignition_stage": "SHADOW_ONLY",
        "ignition_false_breakout_veto": True,
        "sell_the_news_confirmed_veto": False,
        "sell_the_news_risk_shadow": True,
        "ignition_uses_new_broker_calls": False,
        "event_freshness_expiry_sec": 1200,
        "expired_frames_removed_from_top": True,
        "full_universe_api_id": "ka10099",
        "background_rotation_is_process_memory": True,
        "background_rotation_has_no_incumbent_slots": True,
        "sector_catalog_api_id": "ka20003",
        "sector_component_api_id": "ka20002",
        "sector_breadth_velocity": True,
        "sector_breadth_acceleration": True,
        "flow_acceleration": True,
        "flow_price_divergence": True,
        "cross_section_rs_percentile": True,
        "cross_section_money_percentile": True,
        "business_context_requires_verified_input": True,
        "automatic_business_fact_ingestion": False,
        "official_real_values_flattened": True,
        "state_value_types_isolated": True,
        "receive_and_event_freshness": True,
        "timestamp_regression_block": True,
        "session_router": True,
        "session_vwap": True,
        "vwap_5m": True,
        "vwap_30m": True,
        "automatic_rs_benchmark_mapping": True,
        "same_time_20d_store": True,
        "program_0w_decode": True,
        "investor_flow_route": True,
        "current_event_discovery": True,
        "discovery_api_ids": ["ka10021", "ka10022", "ka10023"],
        "absolute_leader_discovery_calls": 0,
        "current_event_names_persisted": False,
        "krx_nxt_state_separate": True,
        "phase3b_official_trading_signals": 0,
        "phase3c_official_trading_signals": 0,
        "sector_spillover_shadow_exists": True,
        "sector_spillover_stage": "SHADOW_ONLY",
        "sector_spillover_uses_new_broker_calls": False,
        "pullback_second_wave_shadow_exists": True,
        "pullback_second_wave_stage": "SHADOW_ONLY",
        "pullback_second_wave_uses_new_broker_calls": False,
        "phase3d_official_trading_signals": 0,
        "market_regime_shadow_exists": True,
        "market_regime_stage": "SHADOW_ONLY",
        "confluence_shadow_exists": True,
        "confluence_independent_evidence_groups": 5,
        "hard_gate_shadow_exists": True,
        "hard_gate_tick_max_age_sec": settings.hard_gate_tick_max_age_sec,
        "hard_gate_required_discovery_sources": settings.hard_gate_required_discovery_sources,
        "hard_gate_required_persistence": settings.hard_gate_required_persistence,
        "hard_gate_krx_spread_max_pct": settings.hard_gate_krx_spread_max_pct,
        "hard_gate_nxt_spread_max_pct": settings.hard_gate_nxt_spread_max_pct,
        "hard_gate_min_money_5m_krw": settings.hard_gate_min_money_5m_krw,
        "phase3e_new_broker_api_ids": [],
        "phase3e_official_trading_signals": 0,
        "phase3e_entry_eligibility_is_shadow_only": True,
        "orb_retest_shadow_exists": True,
        "squeeze_release_shadow_exists": True,
        "vwap_reclaim_shadow_exists": True,
        "krx_nxt_bridge_shadow_exists": True,
        "phase3f_pattern_completion_uses_new_broker_calls": False,
        "phase3f_bridge_uses_same_day_krx_close_frame_only": True,
        "phase3f_previous_session_bridge_restore": False,
        "phase3f_official_trading_signals": 0,
        "phase4a_prebuy_decision_shadow_exists": True,
        "phase4a_prebuy_ready_entry_eligibility_shadow_only": True,
        "phase4a_official_prebuy_signals": 0,
        "phase4a_official_ready_signals": 0,
        "phase4a_official_entry_signals": 0,
        "phase4a_official_a_plus_signals": 0,
        "phase4a_order_actions": 0,
        "phase4a_uses_new_broker_calls": False,
        "phase4a_restores_previous_session_rows": False,
        "phase4a1_smart_flow_2_realtime_shadow": True,
        "phase4a1_smart_flow_windows": ["10s", "30s", "2m", "5m"],
        "phase4a1_ofi_from_existing_0d": True,
        "phase4a1_microprice_from_existing_0d": True,
        "phase4a1_aggressive_trade_pressure_from_existing_0b": True,
        "phase4a1_patterns_feed_existing_price_structure_vote": True,
        "phase4a1_realtime_flow_feeds_existing_flow_vote": True,
        "phase4a1_confluence_vote_count_still": 5,
        "phase4a1_uses_new_broker_calls": False,
        "phase4b_signal_ledger_exists": True,
        "phase4b_signal_ledger_history_only": True,
        "phase4b_ledger_feeds_current_rows": False,
        "phase4b_episode_min_dwell_sec": settings.signal_ledger_min_stage_dwell_sec,
        "phase4b_intraday_outcomes": ["10M", "30M"],
        "phase4b_daily_outcomes_wait_for_trusted_source": True,
        "phase4b_probability_calibrated": False,
        "phase4b_order_actions": 0,
        "phase4c_trusted_daily_outcomes": True,
        "phase4c_daily_outcome_source": "KIWOOM_KA10081",
        "phase4c_close_uses_signal_day_actual_close": True,
        "phase4c_d1_d3_d5_use_actual_subsequent_trading_days": True,
        "phase4c_daily_outcomes_feed_current_rows": False,
        "phase4c_probability_calibrated": False,
        "phase4c1_regime_structural_routes_aligned": True,
        "phase4c1_universe_eligibility_gate": True,
        "phase4c1_investor_flow_dependency_failsafe": True,
        "phase4c1_background_coverage_dependency_failsafe": True,
        "phase4c1_complete_current_decision_frame": True,
        "phase4c1_historical_performance_feeds_current_rows": False,
        "phase4d_current_decision_compression_shadow_exists": True,
        "phase4d_reads_current_prebuy_frame_only": True,
        "phase4d_eligible_source_stages": ["ENTRY_ELIGIBLE_SHADOW", "A_PLUS_ELIGIBLE_SHADOW"],
        "phase4d_max_rows": min(3, settings.current_decision_compression_max_rows),
        "phase4d_duplicate_symbol_rows_allowed": False,
        "phase4d_new_composite_score_created": False,
        "phase4d_historical_performance_used_for_ranking": False,
        "phase4d_previous_session_restore": False,
        "phase4d_uses_new_broker_calls": False,
        "phase4d_official_trading_signals": 0,
        "phase4d_order_actions": 0,
        "phase4e_runtime_truth_exists": True,
        "phase4e_runtime_truth_changes_trading_scores": False,
        "phase4e_observes_cpu_memory_disk_event_loop": True,
        "phase4e_observes_ws_feed_truth_reconnects": True,
        "phase4e_protects_feed_current_decision_ledger": True,
        "phase4e_runtime_truth_dependency_failsafe": True,
        "phase4e_load_shedding_components": ["daily_outcomes", "background_coverage", "sector_breadth", "market_discovery", "investor_flow", "universe_refresh", "baseline_flush"],
        "phase4e_official_trading_signals": 0,
        "phase4e_order_actions": 0,
        "phase4e1_presentation_safety_exists": True,
        "phase4e1_states": ["LIVE", "WARNING", "FROZEN", "LOCKED"],
        "phase4e1_frozen_locked_change_scores": False,
        "phase4e1_frozen_rows_process_memory_only": True,
        "phase4e1_historical_restore": False,
        "phase4e1_recovery_requires_new_trusted_market_event": True,
        "phase4e1_recovery_requires_current_decision_reassessment": True,
        "phase4e1_official_trading_signals": 0,
        "phase4e1_order_actions": 0,
        "phase5a_fixed_operations_ui_exists": True,
        "phase5a_ui_reads_existing_apis_only": True,
        "phase5a_ui_uses_presentation_safety_for_top_decisions": True,
        "phase6b2_dual_absorption_price_hold_shadow_exists": True,
        "phase6b2_krx_only": True,
        "phase6b2_models": ["A_FOREIGN_ABSORB", "B1_FUND_ABSORB", "B2_PENSION_ABSORB", "B3_FUND_PENSION_ABSORB", "DUAL_CONFIRMED", "CORPORATE_ABSORB"],
        "phase6b2_states": ["DATA_WAIT", "WATCH", "ABSORB", "PRICE_HOLD", "SUPPLY_TIGHT", "SUPPLY_EXHAUSTION_ESTIMATED", "PRE_IGNITION", "IGNITION"],
        "phase6b2_score_weights": {"price_hold": 25, "counterparty_absorption": 20, "selling_deceleration": 15, "flow_price_divergence": 10, "flow_acceleration": 10, "activity_acceleration": 8, "relative_strength": 7, "sector_expansion": 5},
        "phase6b2_price_hold_hard_gate": True,
        "phase6b2_investor_detail_api": "ka10060",
        "phase6b2_investor_rank_schema_validated": True,
        "phase6b2_response_api_id_validated_when_present": True,
        "phase6b2_sector_relative_strength_source": "symbol_change_minus_current_sector_member_median_change",
        "phase6b2_nxt_investor_flow_used": False,
        "phase6b2_direct_matching_claimed": False,
        "phase6b2_supply_exhaustion_is_estimated": True,
        "phase6b2_feeds_existing_ranking": False,
        "phase6b2_new_broker_calls": ["ka10060_bounded_krx_symbol_detail"],
        "phase6b2_official_trading_signals": 0,
        "phase6b2_order_actions": 0,
        "phase6c_dual_signal_ledger_performance_exists": True,
        "phase6c_history_feeds_current_ranking": False,
        "phase6d_transition_alert_exists": True,
        "phase6d_transition_alert_repeated_poll_spam": False,
        "phase6d_material_alerts": ["STAGE_PROMOTION", "STAGE_DOWNGRADE", "MODEL_CHANGE", "ABSORPTION_RATIO_CROSS_070", "SCORE_JUMP_8", "PROGRAM_BUY_TURN", "VWAP_RECLAIM", "HIGHER_LOW_CONFIRMED", "SECTOR_BREADTH_EXPANSION", "PRICE_HOLD_FAILED"],
        "phase6d_krx_close_classes": ["CLOSE_PRE_IGNITION", "SUPPLY_TIGHT_OVERNIGHT", "PRICE_HOLD_OVERNIGHT", "FAILED"],
        "phase6d_close_history_reference_only_next_session": True,
        "phase6d_close_history_feeds_next_session_current_facts": False,
        "phase6d_feeds_existing_ranking": False,
        "phase6d_nxt_input": False,
        "phase6d_new_broker_calls": 0,
        "phase6d_official_trading_signals": 0,
        "phase6d_order_actions": 0,
        "phase6e_nxt_native_engine_exists": True,
        "phase6e_nxt_native_states": ["NXT_EARLY_FLOW", "NXT_EARLY_BUY", "NXT_CLOSE_BET", "NXT_OVERHEATED", "NXT_WIDE_SPREAD", "NXT_LOW_LIQUIDITY", "NXT_STALE", "NXT_NO_SIGNAL"],
        "phase6e_time_windows_kst": {"early_flow": "15:40-18:30", "early_buy": "18:30-19:30", "close_bet": "19:30-19:55", "strict_close": "19:50-19:55"},
        "phase6e_uses_nxt_price_trade_orderbook_money_vwap": True,
        "phase6e_uses_nxt_microstructure_proxy": True,
        "phase6e_microstructure_proxy_trust": "ESTIMATED",
        "phase6e_direct_nxt_investor_flow": "UNAVAILABLE",
        "phase6e_krx_input": "SAME_DAY_CLOSE_REFERENCE_PRICE_ONLY",
        "phase6e_krx_investor_flow_used": False,
        "phase6e_bridge_score_reuse": False,
        "phase6e_previous_session_reference_used": False,
        "phase6e_new_broker_calls": 0,
        "phase6e_feeds_existing_ranking": False,
        "phase6e_official_trading_signals": 0,
        "phase6e_order_actions": 0,
        "phase6e1_nxt_fixed_operations_board_exists": True,
        "phase6e1_fixed_rows_each_board": 10,
        "phase6e1_boards": ["NXT_EARLY_FLOW", "NXT_EARLY_BUY", "NXT_CLOSE_BET"],
        "phase6e1_qualification_dwell_sec": settings.nxt_operations_board_qualification_dwell_sec,
        "phase6e1_membership_commit_sec": settings.nxt_operations_board_membership_commit_sec,
        "phase6e1_overtake_min_score_gap": settings.nxt_operations_board_overtake_min_score_gap,
        "phase6e1_overtake_required_checks": settings.nxt_operations_board_overtake_required_checks,
        "phase6e1_only_active_phase_has_current_rows": True,
        "phase6e1_hard_risk_removal_immediate": True,
        "phase6e1_uses_phase6e_frames_only": True,
        "phase6e1_new_trading_score": False,
        "phase6e1_new_broker_calls": 0,
        "phase6e1_krx_investor_flow_used": False,
        "phase6e1_history_feeds_current_ranking": False,
        "phase6e1_official_trading_signals": 0,
        "phase6e1_order_actions": 0,
        "phase6f_missed_opportunity_scanner_exists": True,
        "phase6f_post_close_rank_api": "ka10027",
        "phase6f_post_close_krx_only": True,
        "phase6f_markets": ["KOSPI", "KOSDAQ"],
        "phase6f_surge_threshold_pct": settings.missed_opportunity_surge_threshold_pct,
        "phase6f_failure_reasons": ["LATE_DETECTION", "DATA_COVERAGE_MISS", "DISCOVERY_EVIDENCE_ABSENT", "ABSORPTION_NOT_FORMED", "PRICE_HOLD_FAILED", "ABSORPTION_WEAK", "SELL_DECEL_INSUFFICIENT", "PROGRAM_DATA_UNAVAILABLE", "PROGRAM_TURN_NOT_SEEN", "SECTOR_BREADTH_WEAK", "SECTOR_BREADTH_UNAVAILABLE", "PREIGNITION_NOT_REACHED"],
        "phase6f_response_api_id_validation": True,
        "phase6f_response_schema_validation": True,
        "phase6f_api_mapping_publication_conflict_known": False,
        "phase6f_runtime_fail_closed_on_provenance_or_schema_mismatch": True,
        "phase6f_full_trade_value_rank_scan": settings.missed_opportunity_trade_value_condition == "0",
        "phase6f_intraday_evidence_archive_one_way": True,
        "phase6f_history_feeds_current_ranking": False,
        "phase6f_history_feeds_current_score": False,
        "phase6f_nxt_input": False,
        "phase6f_new_broker_calls": "KA10027_POST_CLOSE_ONLY_BOUNDED_FAIL_CLOSED",
        "phase6f_official_trading_signals": 0,
        "phase6f_order_actions": 0,
        "phase6g_current_data_completion_exists": True,
        "phase6g_krx_only": True,
        "phase6g_daily_reference_api": "ka10081",
        "phase6g_universe_metadata_api": "ka10099",
        "phase6g_fields": ["return_1d_pct", "return_3d_pct", "return_5d_pct", "previous_observed_same_time_money_5m", "same_time_avg20_money_5m", "avg20_daily_volume", "avg20_daily_traded_value_raw", "market_cap_est_krw", "sector_money_stage", "sector_top3"],
        "phase6g_sector_money_stages": ["NO_DATA", "LEADER_ONLY", "TWO_WAY", "THREE_WAY_PLUS"],
        "phase6g_historical_reference_feeds_current_ranking": False,
        "phase6g_historical_reference_feeds_current_score": False,
        "phase6g_new_composite_score": False,
        "phase6g_attached_to_current_feature_prebuy_dual_and_compressed_outputs": True,
        "phase6g_attachment_is_output_only": True,
        "phase6g_daily_requests_bounded": True,
        "phase6g_official_trading_signals": 0,
        "phase6g_order_actions": 0,
        "phase6g1_krx_operations_board_exists": True,
        "phase6g1_fixed_rows": 10,
        "phase6g1_source": "CURRENT_DUAL_ABSORPTION_ONLY",
        "phase6g1_current_data_overlay": True,
        "phase6g1_transition_close_missed_visible_via_ui": True,
        "phase6g1_feeds_existing_ranking": False,
        "phase6g1_new_trading_score": False,
        "phase6g1_official_trading_signals": 0,
        "phase6g1_order_actions": 0,
        "phase7_07_briefing_exists": False,
        "phase6a_live_shadow_validation_exists": True,
        "phase6a_live_shadow_validation_default_enabled_when_feed_runs": True,
        "phase6a_live_shadow_validation_new_broker_calls": 0,
        "phase6a_live_shadow_validation_feeds_current_decisions": False,
        "phase6a_synthetic_tests_can_certify_live_market": False,
        "phase5a_fixed_current_decision_slots": 3,
        "phase5a_fixed_prebuy_rows": 10,
        "phase5a_fixed_discovery_rows": 10,
        "phase5a_ui_creates_trading_scores": False,
        "nxt_strategy_specific_late_session_action_removed": True,
        "smart_money_full_weight": 100,
        "sector_weight": 15,
        "business_context_weight": 10,
        "flow_turnover_amount_scale": settings.flow_amount_to_daily_value_scale,
        "live_market_validation": live_shadow_validation.frame.live_market_validation if live_shadow_validation and live_shadow_validation.frame else "PENDING",
        "live_shadow_coverage": live_shadow_validation.frame.coverage_state if live_shadow_validation and live_shadow_validation.frame else None,
    }
