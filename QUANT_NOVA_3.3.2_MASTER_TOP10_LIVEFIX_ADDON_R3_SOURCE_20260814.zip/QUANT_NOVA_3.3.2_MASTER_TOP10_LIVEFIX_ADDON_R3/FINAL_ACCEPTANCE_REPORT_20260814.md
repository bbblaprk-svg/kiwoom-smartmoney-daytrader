# QUANT NOVA 3.3.2 MASTER TOP10 LIVEFIX — Final Acceptance Report

## Release identity
- Runtime version: `NOVA-3.3.2-MASTER-TOP10-LIVEFIX`
- Base: 3.3.1 performance-hardened source; ENTRY_V18 numeric policy unchanged.
- Purpose: remove the live-feed cold-start/recovery deadlock observed during the 2026-08-14 Lightsail cutover while preserving the 3.3.1 CPU/disk/UI performance work.

## Root cause confirmed by source differential
The 3.2.2 production source runs Discovery during recovery states. 3.3.1 changed this to pause Discovery for every `RESYNC/WARMING/RECONNECTING` state in order to reserve REST capacity for recovery. On a cold start with no restored HOT/PINNED targets this created a circular wait:

`no targets -> no useful WS REG -> feed remains RESYNC/RECONNECTING -> Discovery remains paused -> no targets`

Two secondary liveness hazards were also corrected:
1. Empty trade target lists could still produce empty broker `REG` groups. A broker reject could occur before bootstrap completed.
2. `subscription_reject_count` is cumulative telemetry. Treating any historical reject as a permanent current fault could hold the global feed in `DEGRADED` after a later successful reconnect.
3. 3.3.1 global `feed_state` required every active HOT venue-key to finish REST baseline + live rewarm. One quiet/recovering symbol could therefore keep the entire dashboard in `WARMING` even while the transport and other symbols were live.

## 3.3.2 corrections
- Explicit `BOOTSTRAP` Discovery exception when recovery is active **and live target set is empty**.
- Recovery still owns REST budget once any HOT/PINNED/FOLLOWUP target exists.
- Empty broker `REG` groups are forbidden.
- Cumulative `subscription_reject_count` is telemetry only; current fault uses `active_subscription_error` and clears after a successful registry refresh.
- Global feed transport liveness is separated from per-venue signal eligibility.
- Individual venue-keys remain fail-closed while `resync_required` / `continuity_reason` is active.
- Global feed may become `LIVE` when transport is healthy and at least one active venue-key is signal-ready; pending venue-keys remain blocked from formal signals.
- If all active keys are still pending, global state remains `RESYNC`/`WARMING`.

## Validation
- Python unit/regression tests: **85 / 85 PASS**.
- New 3.3.2 live-recovery regression tests: **5 / 5 PASS**.
- Master specification/source audit: **PASS**.
- Simulated runtime image audit: **PASS**.
- Quick integrated validation: **PASS**.
- ENTRY_V18 frozen-policy hash contract: **PASS**.
- Broker capacity contract: **PASS** (`code_budget=90`, item cap `180`).
- Composite 3.3.1 performance workload re-run on 3.3.2: **PASS** — 18,000 burst events, 180 venue-key scoring, Top10 display, WAL.
- Composite performance observed in this container: ~8.7k events/s; full 180-venue score p95 ~82ms; WAL wait p95 ~0.1ms; WAL write p95 <1ms.

## Production boundary
This release fixes the source-level circular wait reproduced by comparing 3.2.2 production behavior with the 3.3.1 recovery change. The final acceptance boundary remains an authenticated Lightsail cutover with the existing production Kiwoom environment. Deployment must preserve the current 3.2.2 container as rollback and require both `/api/livez` HTTP success and `feed_state=LIVE` before committing the cutover.
