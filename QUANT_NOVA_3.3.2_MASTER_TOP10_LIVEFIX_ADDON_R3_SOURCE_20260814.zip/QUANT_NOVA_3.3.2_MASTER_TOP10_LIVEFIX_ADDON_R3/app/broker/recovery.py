from __future__ import annotations
import asyncio,time
from app.broker.kiwoom import REST,row_price,row_rate,num
from app.config import SETTINGS
from app.domain import Venue
from app.runtime.clock import sessions,trade_day
from app.runtime.state import RuntimeState

def broker_code(code:str,venue:Venue)->str:
    return f'{code}_NX' if venue==Venue.NXT else code

def _field(j:dict,*names,default=0.0):
    for n in names:
        if n in j and str(j.get(n) or '').strip():return num(j.get(n),default)
    return default

def _quote_reference(j:dict)->float:
    """Non-signal REST reference price. Formal signal price always comes from a fresh WS trade."""
    price=row_price(j)
    if price>0:return price
    ask=abs(_field(j,'sel_fpr_bid','ask_prc','best_ask','sel_1th_pre_req'))
    bid=abs(_field(j,'buy_fpr_bid','bid_prc','best_bid','buy_1th_pre_req'))
    if ask>0 and bid>0:return (ask+bid)/2.0
    return ask or bid or 0.0

class RestRecoveryEngine:
    """Rate-limited recovery side-path. REST never creates a formal signal.

    Snapshot values only establish cumulative/session baselines; formal signals remain gated
    until fresh WS trade ticks rebuild the minimum live window.
    """
    def __init__(self,state:RuntimeState):self.state=state;self.last_run=0.0;self.running=False
    async def recover_one(self,code:str,venue:Venue)->bool:
        body={'stk_cd':broker_code(code,venue)}
        status,j=await REST.post(SETTINGS.resync_api_path,SETTINGS.resync_api_id,body)
        if status!=200 or int(j.get('return_code',0))!=0:return False
        price=_quote_reference(j);rate=row_rate(j);vol=abs(_field(j,'acc_trde_qty','trde_qty','acc_volume','cum_volume'));turn=abs(_field(j,'acc_trde_prica','trde_prica','acc_turnover','cum_turnover'))
        if price<=0:return False
        c=self.state.candidates.get(code)
        if not c:return False
        now=time.time()
        with self.state.code_lock(code):
            v=c.venue_state[venue]
            # REST is a baseline only. Never overwrite a newer live cumulative value backwards.
            if vol and v.last_cum_volume and vol<v.last_cum_volume*.98:return False
            v.resync_snapshot_at=now;v.resync_snapshot_price=price;v.resync_snapshot_volume=vol;v.resync_snapshot_turnover=turn;v.resync_required=True
            if vol:v.last_cum_volume=vol;v.session_v=vol
            if turn:v.last_cum_turnover=turn;v.session_pv=turn
            v.metrics['resync_snapshot_rate']=rate;v.metrics['resync_snapshot_price']=price;v.metrics['resync_snapshot_api_id']=SETTINGS.resync_api_id;v.metrics['resync_snapshot_source']='REST_BASELINE_ONLY';v.metrics['fresh']=False;v.metrics['continuity_ok']=False
            self.state.mark_dirty(code,venue,urgent=True)
        self.state.telemetry['rest_resync_success_count']+=1;return True
    async def cycle(self):
        if self.running or not SETTINGS.resync_enabled:return
        if time.time()-self.last_run<SETTINGS.resync_interval_sec:return
        self.running=True;self.last_run=time.time()
        try:
            sess=sessions();targets=[]
            with self.state.lock:
                codes=list(dict.fromkeys(list(self.state.pinned_codes)+list(self.state.hot_codes)))
                for code in codes:
                    c=self.state.candidates.get(code)
                    if not c:continue
                    for venue,active in ((Venue.KRX,sess['krx']),(Venue.NXT,sess['nxt'])):
                        if active and c.venue_state[venue].resync_required:targets.append((code,venue))
            for code,venue in targets[:SETTINGS.resync_batch_cap]:
                try:
                    ok=await self.recover_one(code,venue)
                    if not ok:self.state.telemetry['rest_resync_failure_count']+=1
                except Exception as e:
                    self.state.telemetry['rest_resync_failure_count']+=1;self.state.ws_status['resync_error']=str(e)[:160]
        finally:self.running=False
