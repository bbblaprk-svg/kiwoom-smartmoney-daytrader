from __future__ import annotations
import asyncio,time
from app.runtime.state import RuntimeState
from app.domain import Origin,Venue,SignalEvent,SignalTrack,HistoryEvent
from app.storage.snapshot import RUNTIME_SNAPSHOT,PRIOR_CLOSE_SNAPSHOT,DISPLAY_FALLBACK,read_json
from app.storage.recovery import restore_seed
from app.runtime.clock import trade_day,next_trading_day
from app.config import SETTINGS
from app.lifecycle.opening import OpeningBridge

class RuntimeStore:
    """Compact restart recovery.

    Durable formal truth comes from the complete current-day SQLite WAL stream summary. Rolling 100ms/
    1s signal windows are never restored as live; they must re-warm from fresh broker ticks. The compact
    runtime snapshot only preserves slow state and already-observed MFE/MAE so a restart cannot erase
    performance history or the BUY cooldown.
    """
    def __init__(self,state:RuntimeState,display):self.state=state;self.display=display;self.bridge=OpeningBridge()

    def build_runtime(self):
        rows=[]
        with self.state.lock:candidates=list(self.state.candidates.values())
        for c in candidates:
            if not (c.live_track_pin or c.origin==Origin.PRIOR_CLOSE or c.lifecycle_state=='CLOSE_TRACK' or c.entry_state in ('BUY','COOLDOWN')):continue
            venues={}
            for venue,v in c.venue_state.items():
                venues[venue.value]={'last_price':v.last_price,'last_rate':v.last_rate,'last_tick_at':v.last_tick_at,'last_exchange_time':v.last_exchange_time,'last_recv_seq':v.last_recv_seq,
                                      'last_cum_volume':v.last_cum_volume,'last_cum_turnover':v.last_cum_turnover,'score':v.score,'confidence':v.confidence,'stage':v.stage,'reasons':list(v.reasons),'metrics':dict(v.metrics),
                                      'buy_count_today':v.entry.buy_count_today,'last_buy_at':v.entry.last_buy_at,'last_buy_price':v.entry.last_buy_price,'last_buy_route':v.entry.last_buy_route,'cooldown_until':v.entry.cooldown_until,
                                      'formal_raw_count':v.entry.formal_raw_count,'valid_repeat_count':v.entry.valid_repeat_count,'last_formal_stage':v.entry.last_formal_stage,'last_formal_at':v.entry.last_formal_at,'last_evidence_signature':v.entry.last_evidence_signature}
            tracks=[{'signal_id':t.signal_id,'venue':t.venue.value,'signal_price':t.signal_price,'signal_time':t.signal_time,'high':t.high,'low':t.low,'current':t.current,'last_tick_at':t.last_tick_at} for t in c.signal_tracks]
            rows.append({'code':c.code,'name':c.name,'trade_day':c.trade_day,'origin':c.origin.value,'rest_base':c.rest_base,'live_track_pin':c.live_track_pin,'lifecycle_state':c.lifecycle_state,
                         'current_venue':c.current_venue.value,'score':c.score,'priority_score':c.priority_score,'confidence':c.confidence,'stage':c.stage,'reasons':list(c.reasons),
                         'top10_stats_by_board':{k:dict(v) for k,v in c.top10_stats_by_board.items()},'reentry_quality':c.reentry_quality,'last_seen_at':c.last_seen_at,
                         'last_buy_at':c.last_buy_at,'last_buy_price':c.last_buy_price,'last_buy_route':c.last_buy_route,'last_buy_venue':c.last_buy_venue.value,
                         'signal_high':c.signal_high,'signal_low':c.signal_low,'buy_high':c.buy_high,'buy_low':c.buy_low,'signal_tracks':tracks,
                         'close_signal_price':c.close_signal_price,'close_score':c.close_score,'close_rank':c.close_rank,'venues':venues})
        return {'version':SETTINGS.version,'day':trade_day(),'updated_at':time.time(),'rows':rows}

    def build_prior(self):
        with self.state.lock:candidates=list(self.state.candidates.values())
        rows=self.bridge.close_candidates(candidates,20);day=trade_day()
        return {'version':SETTINGS.version,'source_day':day,'effective_day':next_trading_day(day),'generated_at':time.time(),'rows':[{'code':c.code,'name':c.name,'close_signal_price':c.close_signal_price or c.current().last_price,'close_score':c.close_score or c.score,'close_rank':c.close_rank,'valid_repeat_count':c.valid_repeat_count} for c in rows]}

    @staticmethod
    def _sig(rec:dict,c,venue:Venue,repeat_no:int)->SignalEvent|None:
        try:return SignalEvent(str(rec.get('signal_id') or ''),str(rec.get('day') or rec.get('trade_day') or ''),c.code,c.name,venue,str(rec.get('stage') or 'WATCH'),str(rec.get('route') or 'RESTORE'),float(rec.get('signal_time') or 0),float(rec.get('signal_price') or 0),float(rec.get('signal_change_rate') or 0),int(rec.get('recv_seq') or 0),str(rec.get('exchange_time') or ''),float(rec.get('server_receive_time') or 0),list(rec.get('reasons') or []),dict(rec.get('metrics') or {}),max(1,repeat_no),c.origin)
        except Exception:return None

    async def restore(self):
        day=trade_day();data=await asyncio.to_thread(restore_seed,day);runtime=data.get('runtime') or {};prior=data.get('prior_close') or {};formal=data.get('formal_summary') or {};formal_codes=formal.get('codes') or {};self.display.set_fallback(data.get('display_fallback') or {})
        if formal.get('error'):self.state.telemetry['restore_wal_error_count']+=1;self.state.ws_status['restore_wal_error']=str(formal.get('error'))[:180]
        if not (prior.get('rows')):
            legacy=await asyncio.to_thread(read_json,self.legacy_path('nxt_next_day_close_picks.json'),{});legacy=legacy or {};prior={'source_day':legacy.get('source_day'),'effective_day':legacy.get('effective_day'),'rows':legacy.get('rows') or []}
        for r in prior.get('rows') or []:
            if prior.get('effective_day') and str(prior.get('effective_day'))!=day:continue
            code=str(r.get('code') or '')
            if not code:continue
            c=self.state.candidate(code,str(r.get('name') or ''),Origin.PRIOR_CLOSE,day);c.close_signal_price=float(r.get('close_signal_price') or r.get('price') or 0);c.close_score=float(r.get('close_score') or r.get('score') or 0);c.close_rank=int(r.get('close_rank') or r.get('rank') or 0);c.lifecycle_state='PRIOR_CLOSE_FROZEN';c.live_track_pin=True;self.state.pinned_codes.add(code)

        snapshot_tracks={}
        runtime_rows=(runtime.get('rows') or []) if str(runtime.get('day') or '')==day else []
        for r in runtime_rows:
            code=str(r.get('code') or '')
            if not code:continue
            try:origin=Origin(str(r.get('origin') or 'TODAY_NEW'))
            except Exception:origin=Origin.TODAY_NEW
            c=self.state.candidate(code,str(r.get('name') or ''),origin,str(r.get('trade_day') or day));c.rest_base=float(r.get('rest_base') or 0);c.live_track_pin=bool(r.get('live_track_pin'));c.lifecycle_state=str(r.get('lifecycle_state') or c.lifecycle_state);c.close_signal_price=float(r.get('close_signal_price') or 0);c.close_score=float(r.get('close_score') or 0);c.close_rank=int(r.get('close_rank') or 0)
            try:c.current_venue=Venue(str(r.get('current_venue') or 'UNKNOWN'))
            except Exception:c.current_venue=Venue.UNKNOWN
            c.score=float(r.get('score') or 0);c.priority_score=float(r.get('priority_score') or 0);c.confidence=float(r.get('confidence') or 0);c.stage=str(r.get('stage') or c.stage);c.reasons=list(r.get('reasons') or [])[:5]
            c.top10_stats_by_board={str(k):dict(v) for k,v in (r.get('top10_stats_by_board') or {}).items() if isinstance(v,dict)};c.reentry_quality=float(r.get('reentry_quality') or 0);c.last_seen_at=float(r.get('last_seen_at') or c.last_seen_at)
            c.signal_high=float(r.get('signal_high') or 0);c.signal_low=float(r.get('signal_low') or 0);c.buy_high=float(r.get('buy_high') or 0);c.buy_low=float(r.get('buy_low') or 0)
            snapshot_tracks[code]={str(x.get('signal_id') or ''):x for x in (r.get('signal_tracks') or []) if x.get('signal_id')}
            try:c.last_buy_venue=Venue(str(r.get('last_buy_venue') or 'UNKNOWN'))
            except Exception:c.last_buy_venue=Venue.UNKNOWN
            c.last_buy_at=float(r.get('last_buy_at') or 0);c.last_buy_price=float(r.get('last_buy_price') or 0);c.last_buy_route=str(r.get('last_buy_route') or '')
            for ven_s,x in (r.get('venues') or {}).items():
                try:venue=Venue(ven_s)
                except Exception:continue
                v=c.venue_state[venue];v.last_price=float(x.get('last_price') or 0);v.last_rate=float(x.get('last_rate') or 0);v.last_tick_at=float(x.get('last_tick_at') or 0);v.last_exchange_time=str(x.get('last_exchange_time') or '');v.last_recv_seq=int(x.get('last_recv_seq') or 0);v.last_cum_volume=float(x.get('last_cum_volume') or 0);v.last_cum_turnover=float(x.get('last_cum_turnover') or 0);v.score=float(x.get('score') or 0);v.confidence=float(x.get('confidence') or 0);v.stage=str(x.get('stage') or v.stage);v.reasons=list(x.get('reasons') or [])[:5];v.metrics.update(dict(x.get('metrics') or {}));lane=v.entry
                if code not in formal_codes:
                    lane.buy_count_today=int(x.get('buy_count_today') or 0);lane.last_buy_at=float(x.get('last_buy_at') or 0);lane.last_buy_price=float(x.get('last_buy_price') or 0);lane.last_buy_route=str(x.get('last_buy_route') or '');lane.cooldown_until=float(x.get('cooldown_until') or 0);lane.formal_raw_count=int(x.get('formal_raw_count') or 0);lane.valid_repeat_count=int(x.get('valid_repeat_count') or 0);lane.last_formal_stage=str(x.get('last_formal_stage') or 'SEED');lane.last_formal_at=float(x.get('last_formal_at') or 0);lane.last_evidence_signature=str(x.get('last_evidence_signature') or '')
                    lane.state='BUY' if c.last_buy_venue==venue and c.last_buy_price and time.time()-lane.last_buy_at<30 else 'COOLDOWN' if lane.cooldown_until>time.time() else 'DISCOVERY'
            c.refresh_aggregate()
            if c.live_track_pin:self.state.pinned_codes.add(code)

        # Rebuild exact all-day counts from the complete streamed WAL summary, but keep only the most
        # recent bounded signal tracks in RAM. Compact snapshot outcomes are overlaid by signal_id.
        latest_buy=None
        for code,fc in formal_codes.items():
            try:origin=Origin(str(fc.get('origin') or 'TODAY_NEW'))
            except Exception:origin=Origin.TODAY_NEW
            c=self.state.candidate(code,str(fc.get('name') or ''),origin,day);c.live_track_pin=True;self.state.pinned_codes.add(code)
            for ven_s,ls in (fc.get('lanes') or {}).items():
                try:venue=Venue(ven_s)
                except Exception:continue
                lane=c.venue_state[venue].entry;lane.formal_raw_count=int(ls.get('formal_raw_count') or 0);lane.valid_repeat_count=int(ls.get('valid_repeat_count') or 0);lane.buy_count_today=int(ls.get('buy_count_today') or 0);lane.last_formal_stage=str(ls.get('last_formal_stage') or 'SEED');lane.last_formal_at=float(ls.get('last_formal_at') or 0);lane.last_evidence_signature=str(ls.get('last_evidence_signature') or '')
                br=ls.get('last_buy') or {}
                if br:
                    bat=float(br.get('decision_time') or br.get('signal_time') or 0);sat=float(br.get('signal_time') or bat);lane.last_buy_at=bat;lane.last_buy_price=float(br.get('signal_price') or 0);lane.last_buy_route=str(br.get('route') or '');
                    from app.signal.policy import ENTRY_COOLDOWN_SEC
                    lane.cooldown_until=bat+ENTRY_COOLDOWN_SEC;lane.state='BUY' if time.time()-bat<30 else 'COOLDOWN' if lane.cooldown_until>time.time() else 'DISCOVERY'
                    if latest_buy is None or sat>latest_buy[0]:latest_buy=(sat,venue,br)
            first=fc.get('first');last=fc.get('last')
            if first:
                try:v=Venue(str(first.get('venue') or 'UNKNOWN'))
                except Exception:v=Venue.UNKNOWN
                if v!=Venue.UNKNOWN:c.first_signal=self._sig(first,c,v,1)
            c.signal_tracks.clear();over=snapshot_tracks.get(code,{})
            for idx,rec in enumerate(fc.get('tracks') or [],1):
                try:venue=Venue(str(rec.get('venue') or 'UNKNOWN'))
                except Exception:continue
                if venue==Venue.UNKNOWN:continue
                sig=self._sig(rec,c,venue,idx)
                if not sig:continue
                old=over.get(sig.signal_id) or {};p=sig.signal_price
                c.signal_tracks.append(SignalTrack(sig.signal_id,venue,p,sig.signal_time,float(old.get('high') or p),float(old.get('low') or p),float(old.get('current') or p),float(old.get('last_tick_at') or sig.signal_time)))
            if last:
                try:v=Venue(str(last.get('venue') or 'UNKNOWN'))
                except Exception:v=Venue.UNKNOWN
                if v!=Venue.UNKNOWN:c.last_signal=self._sig(last,c,v,max(1,c.venue_state[v].entry.valid_repeat_count))
            if c.last_signal:
                tr=next((t for t in reversed(c.signal_tracks) if t.signal_id==c.last_signal.signal_id),None)
                if tr:
                    c.signal_high=tr.high;c.signal_low=tr.low
                    # G10R2 restored formal signal tracks but accidentally dropped VenueState.last_price/rate.
                    # Recover the exact persisted track current price for that same venue.  When the
                    # signal-time change rate is available, derive the same-day reference close and
                    # reconstruct the frozen current rate without mixing venues or inventing a quote.
                    vv=c.venue_state[c.last_signal.venue]
                    if vv.last_price<=0 and tr.current>0:
                        vv.last_price=float(tr.current);vv.last_tick_at=max(float(vv.last_tick_at or 0),float(tr.last_tick_at or 0))
                        sr=float(c.last_signal.signal_change_rate or 0);sp=float(c.last_signal.signal_price or 0)
                        if vv.last_rate==0 and sp>0 and abs(1+sr/100)>1e-9:
                            ref=sp/(1+sr/100)
                            if ref>0:vv.last_rate=round((vv.last_price/ref-1)*100,6)
            # latest BUY for this code must be selected across venues, not by aggregate score
            local=[]
            for ven_s,ls in (fc.get('lanes') or {}).items():
                br=ls.get('last_buy') or {}
                if br:
                    try:vv=Venue(ven_s);local.append((float(br.get('signal_time') or 0),vv,br))
                    except Exception:pass
            if local:
                sat,venue,br=max(local,key=lambda x:x[0]);c.last_buy_at=sat;c.last_buy_venue=venue;c.last_buy_price=float(br.get('signal_price') or 0);c.last_buy_route=str(br.get('route') or '')
            c.refresh_aggregate()

        for rec in data.get('history') or []:
            code=str(rec.get('code') or '');c=self.state.candidates.get(code)
            if not c or rec.get('event')!='HISTORY':continue
            try:venue=Venue(str(rec.get('venue') or 'UNKNOWN'))
            except Exception:venue=Venue.UNKNOWN
            c.history.append(HistoryEvent(float(rec.get('at') or 0),str(rec.get('kind') or ''),str(rec.get('state') or ''),float(rec.get('price') or 0),str(rec.get('reason') or ''),venue))
        self.state.telemetry['restore_formal_rows']=int(formal.get('row_count') or 0);self.state.restore_done=True;self.state.warming_until=time.time()+60

    def legacy_path(self,name):
        from app.config import SETTINGS
        return SETTINGS.legacy_data_dir/name
