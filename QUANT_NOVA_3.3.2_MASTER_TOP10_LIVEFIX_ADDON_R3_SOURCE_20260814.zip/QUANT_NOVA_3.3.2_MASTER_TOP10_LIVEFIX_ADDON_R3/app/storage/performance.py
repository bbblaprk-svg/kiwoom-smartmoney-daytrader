from __future__ import annotations
import json,sqlite3,time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from app.config import SETTINGS
from app.domain import Venue
from app.runtime.clock import advance_trading_day,now_kst

KST=ZoneInfo('Asia/Seoul')
HORIZONS=(1,3,5)

class PerformanceLedger:
    """Slow-side, venue-locked 1/3/5 trading-day outcome ledger.

    It never fabricates a close from another venue or from a stale snapshot. On each target trading
    day it asks the live runtime to keep a bounded set of pending symbols subscribed. The final
    horizon result is written only after that venue's session close and only when the last verified
    live tick belongs to the exact target day. Missing verified close remains PENDING.
    """
    def __init__(self,data_dir:Path|None=None):
        self.data_dir=data_dir or SETTINGS.data_dir
        self.path=self.data_dir/'performance.sqlite3'
        self.signal_wal=self.data_dir/'signal_wal.sqlite3'
        self.last_status={'imported':0,'finalized':0,'pending_today':0,'at':0.0}

    def _open(self):
        self.data_dir.mkdir(parents=True,exist_ok=True)
        con=sqlite3.connect(self.path,timeout=5,isolation_level=None)
        con.execute('PRAGMA journal_mode=WAL');con.execute('PRAGMA synchronous=NORMAL');con.execute('PRAGMA busy_timeout=3000')
        con.execute('''CREATE TABLE IF NOT EXISTS signal_master(
            signal_id TEXT PRIMARY KEY, kind TEXT NOT NULL, signal_day TEXT NOT NULL, code TEXT NOT NULL,
            venue TEXT NOT NULL, signal_price REAL NOT NULL, signal_time REAL NOT NULL, payload TEXT NOT NULL)''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_perf_master_day_code ON signal_master(signal_day,code)')
        con.execute('''CREATE TABLE IF NOT EXISTS horizon_outcome(
            signal_id TEXT NOT NULL, horizon INTEGER NOT NULL, target_day TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING', close_price REAL, return_pct REAL,
            last_verified_price REAL, last_verified_tick_at REAL, finalized_at REAL, source TEXT,
            PRIMARY KEY(signal_id,horizon))''')
        con.execute('CREATE INDEX IF NOT EXISTS idx_perf_target ON horizon_outcome(target_day,status)')
        con.execute('CREATE TABLE IF NOT EXISTS import_state(key TEXT PRIMARY KEY,value INTEGER NOT NULL)')
        return con

    def _import_formal(self,con)->int:
        """Incrementally import every committed formal WAL row exactly once.

        No DESC LIMIT window is used: after a long outage the importer resumes from the durable
        SQLite seq watermark and drains forward in bounded batches, so older 1/3/5 outcomes cannot
        fall out of an arbitrary latest-N window. INSERT OR IGNORE makes crash replay idempotent.
        """
        if not self.signal_wal.exists():return 0
        try:src=sqlite3.connect(f'file:{self.signal_wal}?mode=ro',uri=True,timeout=3)
        except Exception:return 0
        imported=0
        try:
            row=con.execute("SELECT value FROM import_state WHERE key='formal_wal_seq'").fetchone();water=int(row[0]) if row else 0
            while True:
                rows=src.execute("SELECT seq,payload FROM formal_wal WHERE seq>? ORDER BY seq ASC LIMIT 1000",(water,)).fetchall()
                if not rows:break
                for seq,payload in rows:
                    water=max(water,int(seq))
                    try:r=json.loads(payload);sid=str(r.get('signal_id') or '');day=str(r.get('day') or r.get('trade_day') or '');code=str(r.get('code') or '');venue=str(r.get('venue') or '');price=float(r.get('signal_price') or 0);at=float(r.get('signal_time') or 0);kind=str(r.get('event') or '')
                    except Exception:continue
                    if kind not in ('SIGNAL_CONFIRMED','BUY_CONFIRMED') or not sid or len(day)!=8 or not code or venue not in ('KRX','NXT') or price<=0:continue
                    cur=con.execute('INSERT OR IGNORE INTO signal_master(signal_id,kind,signal_day,code,venue,signal_price,signal_time,payload) VALUES(?,?,?,?,?,?,?,?)',(sid,kind,day,code,venue,price,at,payload))
                    if cur.rowcount==1:
                        imported+=1
                        for h in HORIZONS:con.execute('INSERT OR IGNORE INTO horizon_outcome(signal_id,horizon,target_day,status) VALUES(?,?,?,?)',(sid,h,advance_trading_day(day,h),'PENDING'))
                con.execute("INSERT INTO import_state(key,value) VALUES('formal_wal_seq',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(water,))
                if len(rows)<1000:break
        finally:src.close()
        return imported

    @staticmethod
    def _tick_day(ts:float)->str:
        try:return datetime.fromtimestamp(float(ts),KST).strftime('%Y%m%d')
        except Exception:return ''

    @staticmethod
    def _venue_closed(venue:str,now)->bool:
        sec=now.hour*3600+now.minute*60+now.second
        return sec>=15*3600+30*60 if venue=='KRX' else sec>=20*3600

    def sync(self,state)->dict:
        con=self._open();imported=finalized=0
        try:
            imported=self._import_formal(con);today=now_kst().strftime('%Y%m%d');now=now_kst();now_ts=time.time()
            rows=con.execute('''SELECT h.signal_id,h.horizon,h.target_day,m.code,m.venue,m.signal_price
                                FROM horizon_outcome h JOIN signal_master m ON m.signal_id=h.signal_id
                                WHERE h.status!='FINAL' AND h.target_day<=? ORDER BY m.signal_time DESC LIMIT 1000''',(today,)).fetchall()
            for sid,h,target,code,venue,signal_price in rows:
                if target!=today:continue # never substitute a later-day price for a missed target close
                c=state.candidates.get(code)
                if not c:continue
                vv=c.venue_state.get(Venue(venue))
                if not vv or vv.last_price<=0 or self._tick_day(vv.last_tick_at)!=target:continue
                con.execute('UPDATE horizon_outcome SET last_verified_price=?,last_verified_tick_at=?,source=? WHERE signal_id=? AND horizon=?',(vv.last_price,vv.last_tick_at,'LIVE_'+venue,sid,h))
                if self._venue_closed(venue,now):
                    ret=(float(vv.last_price)/float(signal_price)-1)*100
                    con.execute("UPDATE horizon_outcome SET status='FINAL',close_price=?,return_pct=?,finalized_at=?,source=? WHERE signal_id=? AND horizon=?",(vv.last_price,round(ret,4),now_ts,'LIVE_'+venue,sid,h));finalized+=1
            pending=self.pending_codes(today,SETTINGS.performance_watch_cap,con)
            # Retain all pending 1/3/5-day outcomes; prune only fully-finalized old rows during this slow 30s side path.
            cutoff=now_ts-SETTINGS.formal_retention_days*86400
            con.execute("DELETE FROM horizon_outcome WHERE status='FINAL' AND finalized_at IS NOT NULL AND finalized_at<?",(cutoff,))
            con.execute('DELETE FROM signal_master WHERE signal_id NOT IN (SELECT DISTINCT signal_id FROM horizon_outcome)')
            self.last_status={'imported':imported,'finalized':finalized,'pending_today':len(pending),'at':now_ts}
            return {**self.last_status,'watch_codes':pending}
        finally:con.close()

    def pending_codes(self,day:str|None=None,limit:int|None=None,con=None)->list[str]:
        own=con is None
        if own:con=self._open()
        try:
            d=day or now_kst().strftime('%Y%m%d');n=max(1,int(limit or SETTINGS.performance_watch_cap))
            rows=con.execute('''SELECT m.code,MAX(m.signal_time) latest,MAX(CASE WHEN m.kind='BUY_CONFIRMED' THEN 1 ELSE 0 END) has_buy
                                FROM horizon_outcome h JOIN signal_master m ON m.signal_id=h.signal_id
                                WHERE h.target_day=? AND h.status!='FINAL'
                                GROUP BY m.code ORDER BY has_buy DESC,latest DESC LIMIT ?''',(d,n)).fetchall()
            return [str(r[0]) for r in rows]
        finally:
            if own:con.close()

    def rows_for_code(self,code:str,limit:int=100)->list[dict]:
        if not self.path.exists():return []
        con=sqlite3.connect(f'file:{self.path}?mode=ro',uri=True,timeout=3)
        try:
            rows=con.execute('''SELECT m.signal_id,m.kind,m.signal_day,m.code,m.venue,m.signal_price,m.signal_time,
                                       h.horizon,h.target_day,h.status,h.close_price,h.return_pct,h.last_verified_price,h.last_verified_tick_at,h.finalized_at,h.source
                                FROM signal_master m JOIN horizon_outcome h ON h.signal_id=m.signal_id
                                WHERE m.code=? ORDER BY m.signal_time DESC,h.horizon LIMIT ?''',(code,limit)).fetchall()
            keys=('signal_id','kind','signal_day','code','venue','signal_price','signal_time','horizon','target_day','status','close_price','return_pct','last_verified_price','last_verified_tick_at','finalized_at','source')
            return [dict(zip(keys,r)) for r in rows]
        finally:con.close()
