from __future__ import annotations

import os
import time
from statistics import median
from typing import Any

from app.config import SETTINGS
from app.domain import Venue

# Default blue-chip / large-cap universe. It is deliberately independent from
# Kiwoom discovery/subscription logic. Operators can replace/extend it without
# changing feed logic via NOVA_LARGECAP_CODES=005930,000660,...
_DEFAULT_LARGECAP_CODES = {
    '005930','000660','373220','207940','005380','000270','068270','005490',
    '035420','035720','105560','055550','086790','316140','138040','024110',
    '012330','009150','066570','051910','006400','028260','032830','000810',
    '003550','034730','015760','017670','030200','010130','096770','011200',
    '267260','329180','042660','012450','047810','010140','009540','034020',
    '454910','352820','259960','018260','003670','247540','086520','196170',
    '277810','078930','000720','004020','011170','000100','128940','326030',
    '302440','090430','161390','011070','036570','251270','271560','097950',
}

_CACHE: dict[str, Any] = {'at': 0.0, 'value': None}


def _largecap_codes() -> set[str]:
    raw = os.getenv('NOVA_LARGECAP_CODES', '').strip()
    if not raw:
        return set(_DEFAULT_LARGECAP_CODES)
    custom = {x.strip().zfill(6) for x in raw.replace(';', ',').split(',') if x.strip()}
    return custom or set(_DEFAULT_LARGECAP_CODES)


def _f(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if x == x else default
    except Exception:
        return default


def _round_price(v: float) -> int:
    """Display-only KRW rounding; this never becomes a broker order price."""
    v = max(0.0, float(v or 0))
    if v < 2_000:
        unit = 1
    elif v < 5_000:
        unit = 5
    elif v < 20_000:
        unit = 10
    elif v < 50_000:
        unit = 50
    elif v < 200_000:
        unit = 100
    elif v < 500_000:
        unit = 500
    else:
        unit = 1000
    return int(round(v / unit) * unit)


def _candidate_snapshot(c: Any, now: float) -> dict[str, Any]:
    v = c.current()
    m = dict(v.metrics or {})
    hist = list(c.history)
    return {
        'code': str(c.code),
        'name': c.name or c.code,
        'venue': v.venue.value,
        'price': _f(v.last_price),
        'change_rate': _f(v.last_rate),
        'last_tick_at': _f(v.last_tick_at),
        'score': _f(c.score),
        'priority_score': _f(c.priority_score),
        'confidence': _f(c.confidence),
        'stage': str(c.stage or 'SEED'),
        'entry_state': str(c.entry_state or 'DISCOVERY'),
        'lifecycle_state': str(c.lifecycle_state or 'TODAY_NEW'),
        'repeat': int(c.valid_repeat_count or 0),
        'source_hits': len(c.source_hits or {}),
        'metrics': m,
        'history': hist,
        'now': now,
    }


def _support_zone(x: dict[str, Any]) -> tuple[float, float, float, float, float, float]:
    p = x['price']; m = x['metrics']
    supports = [
        _f(m.get('session_vwap')),
        _f(m.get('micro_vwap')),
    ]
    supports = [s for s in supports if s > 0 and (not p or 0.94 * p <= s <= 1.04 * p)]
    center = median(supports) if supports else p
    if p > 0 and center > p * 1.01:
        center = p * 0.998
    low = center * 0.996
    high = center * 1.003
    chase = high * 1.012
    mid = (low + high) / 2
    day_low = _f(m.get('day_low'))
    structural = day_low * 0.997 if day_low > 0 and day_low < mid else mid * 0.972
    stop = max(mid * 0.96, min(mid * 0.985, structural))
    risk = max(mid - stop, mid * 0.008)
    t1 = mid + risk * 1.5
    t2 = mid + risk * 2.2
    return low, high, chase, stop, t1, t2


def _largecap_row(x: dict[str, Any]) -> dict[str, Any] | None:
    p = x['price']; m = x['metrics']; now = x['now']
    if p <= 0:
        return None
    age = now - x['last_tick_at'] if x['last_tick_at'] else 9999
    fresh = age <= max(SETTINGS.display_fresh_ms / 1000, 8.0)
    bp = _f(m.get('buy_pressure'), 50)
    accel = _f(m.get('volume_accel'), 1)
    vgap = _f(m.get('session_vwap_gap'))
    micro_gap = _f(m.get('micro_vwap_gap'))
    program_fresh = bool(m.get('program_fresh'))
    program_delta = _f(m.get('program_delta'))
    sm = _f(m.get('smart_money_realtime_proxy_score'))
    surge = bool(m.get('smart_money_realtime_proxy_surge'))
    sector = _f(m.get('sector_score'))
    breakout = _f(m.get('micro_breakout'))
    rate = x['change_rate']

    low, high, chase, stop, t1, t2 = _support_zone(x)
    mid = (low + high) / 2
    risk_pct = (mid / stop - 1) * 100 if stop > 0 else 99
    rr = (t1 - mid) / max(mid - stop, 1)

    setup = 'PULLBACK'
    if breakout >= 0.20 and micro_gap >= 0.05:
        setup = 'BREAKOUT-RETEST'
    elif -0.20 <= vgap <= 0.45 and bp >= 55:
        setup = 'VWAP-RECLAIM'

    quality = 0.34 * x['priority_score'] + 0.16 * x['score']
    quality += min(12, max(0, bp - 50) * 0.8)
    quality += min(10, max(0, accel - 1) * 8)
    quality += min(8, max(0, sm) * 1.5) + (5 if surge else 0)
    quality += min(6, max(0, sector)) + min(5, max(0, breakout) * 8)
    quality += min(5, x['source_hits'] * 1.2) + min(5, x['repeat'] * 1.2)
    if not fresh:
        quality -= 22
    if rate > 7.5 or vgap > 2.0:
        quality -= 14
    quality = round(max(0, min(100, quality)), 1)

    in_zone = low <= p <= high
    supply_ok = (not program_fresh or program_delta >= 0) and (bp >= 54 or surge or sm >= 1.5)
    trend_ok = -2.8 <= rate <= 6.0 and -0.7 <= vgap <= 1.4 and micro_gap <= 1.5
    risk_ok = risk_pct <= 4.05 and rr >= 1.5

    if fresh and in_zone and supply_ok and trend_ok and risk_ok and quality >= 68:
        decision = 'NOW'
    elif fresh and quality >= 48 and p <= chase and rate <= 8.5:
        decision = 'WAIT'
    else:
        decision = 'AVOID'

    if not fresh:
        reason = 'Fresh 체결 대기'
    elif p > chase:
        reason = '추천진입 상단 이탈 · 추격금지'
    elif not supply_ok:
        reason = '실시간 수급 확인 대기'
    elif not in_zone:
        reason = '추천진입 구간 대기'
    elif decision == 'NOW':
        reason = '가격·수급·VWAP 동시확인'
    else:
        reason = '조건 추가확인'

    return {
        'code': x['code'], 'name': x['name'], 'venue': x['venue'], 'price': _round_price(p),
        'change_rate': round(rate, 2), 'score': quality, 'decision': decision, 'setup': setup,
        'entry_low': _round_price(low), 'entry_high': _round_price(high), 'chase_limit': _round_price(chase),
        'stop': _round_price(stop), 'target1': _round_price(t1), 'target2': _round_price(t2),
        'risk_pct': round(risk_pct, 2), 'rr': round(rr, 2), 'fresh': fresh,
        'program_fresh': program_fresh, 'program_delta': round(program_delta, 0),
        'buy_pressure': round(bp, 1), 'smart_money_score': round(sm, 1), 'reason': reason,
    }


def _evidence_counts(x: dict[str, Any]) -> tuple[int, int]:
    now = x['now']; ev10 = 0; ev30 = 0
    accepted = {'SIGNAL', 'TOP10', 'ENTRY_STATE'}
    for e in x['history']:
        try:
            if e.kind not in accepted:
                continue
            # Mechanical raw repeats are not counted; ENTRY_STATE only contributes on meaningful states.
            if e.kind == 'ENTRY_STATE' and e.state not in ('PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM','BUY'):
                continue
            age = now - float(e.at)
            if 0 <= age <= 1800:
                ev30 += 1
                if age <= 600:
                    ev10 += 1
        except Exception:
            continue
    return ev10, ev30


def _pre_row(x: dict[str, Any]) -> dict[str, Any] | None:
    p = x['price']; m = x['metrics']; now = x['now']
    if p <= 0:
        return None
    age = now - x['last_tick_at'] if x['last_tick_at'] else 9999
    fresh = age <= max(SETTINGS.display_fresh_ms / 1000, 8.0)
    if not fresh:
        return None
    bp = _f(m.get('buy_pressure'), 50)
    accel = _f(m.get('volume_accel'), 1)
    vgap = _f(m.get('micro_vwap_gap'))
    breakout = _f(m.get('micro_breakout'))
    sm = _f(m.get('smart_money_realtime_proxy_score'))
    surge = bool(m.get('smart_money_realtime_proxy_surge'))
    sector = _f(m.get('sector_score'))
    imp = _f(m.get('impulse_60s'))
    ev10, ev30 = _evidence_counts(x)

    pre = 0.28 * x['priority_score'] + 0.18 * x['score']
    pre += min(14, max(0, bp - 50) * 0.9)
    pre += min(14, max(0, accel - 1) * 9)
    pre += min(9, max(0, sm) * 1.6) + (5 if surge else 0)
    pre += min(8, ev10 * 2.0) + min(6, ev30 * 0.7)
    pre += min(5, max(0, sector)) + min(5, max(0, breakout) * 8)
    if vgap < -0.8 or vgap > 2.2:
        pre -= 8
    if imp > 4.5 or x['change_rate'] > 12:
        pre -= 10
    pre = round(max(0, min(100, pre)), 1)

    if ev10 >= 3 and ev10 * 3 >= max(ev30, 1) * 1.4:
        acceleration = '↑↑'
    elif ev10 >= 2 and ev10 * 3 >= max(ev30, 1):
        acceleration = '↑'
    elif ev10 == 0 and ev30 >= 2:
        acceleration = '↓'
    else:
        acceleration = '→'

    if pre >= 80 and (ev10 >= 2 or surge) and bp >= 56:
        stage = 'CONFIRM'
    elif pre >= 66:
        stage = 'WATCH'
    else:
        stage = 'PRE'

    reasons = []
    if accel >= 1.5: reasons.append(f'체결가속 {accel:.1f}x')
    if bp >= 58: reasons.append(f'공격매수 {bp:.0f}%')
    if surge: reasons.append('SMART MONEY SURGE')
    if breakout >= .2: reasons.append(f'미세돌파 +{breakout:.2f}%')
    if ev10: reasons.append(f'10분 증거 {ev10}회')
    if not reasons: reasons.append('초기 조건 축적')

    return {
        'code': x['code'], 'name': x['name'], 'venue': x['venue'], 'price': _round_price(p),
        'change_rate': round(x['change_rate'], 2), 'score': pre, 'stage': stage,
        'events_10m': ev10, 'events_30m': ev30, 'acceleration': acceleration,
        'valid_repeat_count': x['repeat'], 'reason': ' · '.join(reasons[:3]),
    }


def build_decision_panels(state: Any, now: float | None = None) -> dict[str, Any]:
    now = float(now or time.time())
    # Cache is display-only and never feeds signal policy. It bounds CPU if multiple UI clients poll.
    cached = _CACHE.get('value')
    if cached is not None and now - float(_CACHE.get('at') or 0) < 1.5:
        return cached

    with state.lock:
        codes = set(state.hot_codes) | set(state.pinned_codes)
        candidates = [state.candidates[c] for c in codes if c in state.candidates]

    snapshots = [_candidate_snapshot(c, now) for c in candidates]
    large_codes = _largecap_codes()
    large = [r for r in (_largecap_row(x) for x in snapshots if x['code'] in large_codes) if r]
    order = {'NOW': 3, 'WAIT': 2, 'AVOID': 1}
    large.sort(key=lambda r: (order.get(r['decision'], 0), r['score'], r['buy_pressure']), reverse=True)
    # NOW is intentionally scarce: at most three. Remaining rows can still show WAIT/AVOID context.
    now_seen = 0
    limited = []
    for r in large:
        if r['decision'] == 'NOW':
            now_seen += 1
            if now_seen > 3:
                r = dict(r); r['decision'] = 'WAIT'; r['reason'] = 'NOW 상위 3종목 우선'
        limited.append(r)
    large = limited[:10]

    pre = [r for r in (_pre_row(x) for x in snapshots) if r]
    stage_order = {'CONFIRM': 3, 'WATCH': 2, 'PRE': 1}
    pre.sort(key=lambda r: (stage_order.get(r['stage'], 0), r['score'], r['events_10m'], r['events_30m']), reverse=True)
    pre = pre[:10]

    out = {
        'ok': True,
        'generated_at': now,
        'source': 'READ_ONLY_EXISTING_KIWOOM_MEMORY',
        'feed_mutation': False,
        'signal_policy_mutation': False,
        'largecap_note': '현재 수신 데이터 기반 실시간 스윙 Proxy · 일봉 MA/기관·외인 별도 REST 추가 없음',
        'largecap': large,
        'preignition': pre,
    }
    _CACHE['at'] = now; _CACHE['value'] = out
    return out
