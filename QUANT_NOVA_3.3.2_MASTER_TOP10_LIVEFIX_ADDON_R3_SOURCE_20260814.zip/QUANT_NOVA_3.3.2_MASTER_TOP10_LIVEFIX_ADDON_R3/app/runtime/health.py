from __future__ import annotations
import asyncio,time,os
from collections import deque
from pathlib import Path
from app.runtime.state import RuntimeState
from app.runtime.load_control import load_mode
from app.runtime.watchdog import HardStallWatchdog


def _mem_total_mb()->float:
    try:
        for line in Path('/proc/meminfo').read_text(errors='ignore').splitlines():
            if line.startswith('MemTotal:'):return float(line.split()[1])/1024
    except Exception:pass
    return 0.0


def process_memory()->dict:
    out={'rss_mb':0.0,'swap_mb':0.0,'vm_mb':0.0,'memory_percent':0.0}
    try:
        for line in Path('/proc/self/status').read_text(errors='ignore').splitlines():
            if line.startswith('VmRSS:'):out['rss_mb']=round(float(line.split()[1])/1024,1)
            elif line.startswith('VmSwap:'):out['swap_mb']=round(float(line.split()[1])/1024,1)
            elif line.startswith('VmSize:'):out['vm_mb']=round(float(line.split()[1])/1024,1)
    except Exception:pass
    total=_mem_total_mb();out['memory_percent']=round(out['rss_mb']/total*100,1) if total else 0.0;return out

class RuntimeHealth:
    def __init__(self,state:RuntimeState,watchdog:HardStallWatchdog,dispatcher,coalesce):
        self.state=state;self.watchdog=watchdog;self.dispatcher=dispatcher;self.coalesce=coalesce;self.last_beat=time.monotonic();self.lags=deque(maxlen=1200);self.task_started=0.0
        self._cpu_at=time.monotonic();t=os.times();self._cpu_used=t.user+t.system;self._rss_at=0.0;self._rss_time=self._cpu_at;self._cpu_pct=0.0;self._mem_growth=0.0
    async def heartbeat(self):
        self.task_started=time.monotonic();expected=time.monotonic()
        while True:
            expected+=.25;await asyncio.sleep(max(0,expected-time.monotonic()));now=time.monotonic();lag=max(0,(now-expected)*1000);self.lags.append(lag);self.last_beat=now;self.watchdog.beat()
    @staticmethod
    def _pct(xs,p):
        ys=sorted(xs);return round(ys[int(p*(len(ys)-1))],2) if ys else 0.0
    def _sample_resources(self,mem):
        now=time.monotonic();t=os.times();used=t.user+t.system;dt=max(.001,now-self._cpu_at);self._cpu_pct=max(0,(used-self._cpu_used)/dt*100);self._cpu_at=now;self._cpu_used=used
        rdt=max(.001,now-self._rss_time);self._mem_growth=(mem['rss_mb']-self._rss_at)/rdt if self._rss_at else 0.0;self._rss_at=mem['rss_mb'];self._rss_time=now
    def snapshot(self):
        mem=process_memory();self._sample_resources(mem);sig=self.state.latency_percentiles('tick_to_signal_ms');ui=self.state.latency_percentiles('tick_to_ui_ms');sq=self.state.latency_percentiles('signal_queue_ms');recv=self.state.latency_percentiles('receiver_to_state_ms');push=self.state.latency_percentiles('ui_push_ms')
        with self.state.lock:
            gaps=sum(1 for c in self.state.candidates.values() for v in c.venue_state.values() if v.continuity_reason);self.state.telemetry['unrecovered_data_gap_count']=gaps
        self.state.telemetry.update({'cpu_percent':round(self._cpu_pct,1),'memory_percent':mem['memory_percent'],'memory_growth_mb_sec':round(self._mem_growth,3),'ui_clients':self.state.ui_clients,'receiver_queue_depth':self.dispatcher.depth(),'receiver_queue_oldest_age_ms':round(self.dispatcher.oldest_age_ms(),2)})
        return {'ok':True,'event_loop_beat_age_ms':round((time.monotonic()-self.last_beat)*1000,1),'event_loop_lag_p50_ms':self._pct(self.lags,.50),'event_loop_lag_p95_ms':self._pct(self.lags,.95),'event_loop_lag_p99_ms':self._pct(self.lags,.99),
                'tick_to_signal_ms':sig,'tick_to_ui_ms':ui,'signal_queue_ms':sq,'receiver_to_state_ms':recv,'ui_push_ms':push,
                'trade_queue_depth':self.dispatcher.depth(),'trade_queue_oldest_age_ms':round(self.dispatcher.oldest_age_ms(),2),'trade_processed':self.dispatcher.processed,'trade_errors':self.dispatcher.errors,'coalesced_depth':self.coalesce.depth(),'coalesce_errors':self.coalesce.errors,'coalesce_last_error':self.coalesce.last_error,
                'memory':mem,'cpu_percent':round(self._cpu_pct,1),'memory_growth_mb_sec':round(self._mem_growth,3),'load_mode':self.state.load_mode,'telemetry':dict(self.state.telemetry),'ws':dict(self.state.ws_status)}
    async def load_loop(self):
        while True:
            s=self.snapshot();m=s['memory'];self.state.load_mode=load_mode(s['cpu_percent'],m['rss_mb'],s['trade_queue_oldest_age_ms'],s['trade_queue_depth'],float(self.state.telemetry.get('signal_queue_oldest_age_ms') or 0),s['event_loop_lag_p95_ms'],int(self.state.telemetry.get('db_queue_depth') or 0),s['tick_to_ui_ms']['p95']);self.state.telemetry['rss_mb']=m['rss_mb'];self.state.telemetry['swap_mb']=m['swap_mb'];self.state.telemetry['event_loop_lag_p95_ms']=s['event_loop_lag_p95_ms'];self.state.telemetry['trade_queue_depth']=s['trade_queue_depth'];self.state.telemetry['trade_queue_oldest_age_ms']=s['trade_queue_oldest_age_ms'];self.state.telemetry['tick_to_signal_p95_ms']=s['tick_to_signal_ms']['p95'];self.state.telemetry['tick_to_ui_p95_ms']=s['tick_to_ui_ms']['p95'];await asyncio.sleep(2)
