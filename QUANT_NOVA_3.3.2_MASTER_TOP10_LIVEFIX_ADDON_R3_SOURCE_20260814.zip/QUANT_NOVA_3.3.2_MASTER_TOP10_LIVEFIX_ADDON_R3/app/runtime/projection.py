from __future__ import annotations
from dataclasses import dataclass
from app.domain import Candidate, Venue, VenueState

@dataclass(frozen=True, slots=True)
class DisplayVenueChoice:
    venue: Venue
    fresh: bool
    age_ms: float | None
    preferred: Venue
    fallback: bool

class LiveDisplayProjection:
    """Display-only live-price projection.

    Signal/BUY state stays venue-locked in Candidate.  A board row must never qualify
    on a fresh venue and then render price/change from a different stale venue.
    """
    def __init__(self, fresh_ms:int):
        self.fresh_ms=max(1,int(fresh_ms))

    def is_fresh_state(self, v:VenueState, now:float)->bool:
        return bool(v.last_price>0 and v.last_tick_at>0 and (now-v.last_tick_at)*1000 <= self.fresh_ms+1000)

    def fresh_venues(self, c:Candidate, now:float)->list[Venue]:
        return [venue for venue in (Venue.KRX,Venue.NXT) if self.is_fresh_state(c.venue_state[venue],now)]

    def has_live(self,c:Candidate,now:float)->bool:
        return bool(self.fresh_venues(c,now))

    def choose(self,c:Candidate,now:float,preferred:Venue=Venue.UNKNOWN,strict_preferred:bool=False)->DisplayVenueChoice:
        pref=preferred if preferred in (Venue.KRX,Venue.NXT) else Venue.UNKNOWN
        fresh=self.fresh_venues(c,now)
        if pref!=Venue.UNKNOWN and pref in fresh:
            v=c.venue_state[pref]
            return DisplayVenueChoice(pref,True,max(0.0,(now-v.last_tick_at)*1000),pref,False)
        if pref!=Venue.UNKNOWN and strict_preferred:
            v=c.venue_state[pref]
            age=max(0.0,(now-v.last_tick_at)*1000) if v.last_tick_at else None
            return DisplayVenueChoice(pref,False,age,pref,False)
        if fresh:
            venue=max(fresh,key=lambda x:(c.venue_state[x].last_tick_at,c.venue_state[x].last_recv_seq))
            v=c.venue_state[venue]
            return DisplayVenueChoice(venue,True,max(0.0,(now-v.last_tick_at)*1000),pref,pref!=Venue.UNKNOWN and venue!=pref)
        venue=pref if pref!=Venue.UNKNOWN else c.current().venue
        if venue not in (Venue.KRX,Venue.NXT):venue=Venue.UNKNOWN
        if venue==Venue.UNKNOWN:return DisplayVenueChoice(Venue.UNKNOWN,False,None,pref,False)
        v=c.venue_state[venue]
        age=max(0.0,(now-v.last_tick_at)*1000) if v.last_tick_at else None
        return DisplayVenueChoice(venue,False,age,pref,False)

    def row(self,c:Candidate,now:float,preferred:Venue=Venue.UNKNOWN,strict_preferred:bool=False,allow_frozen:bool=False,compact:bool=False)->dict:
        choice=self.choose(c,now,preferred,strict_preferred)
        if choice.venue in (Venue.KRX,Venue.NXT):
            row=c.public_compact(choice.venue) if compact else c.public(choice.venue)
        else:
            row=c.public_compact() if compact else c.public()
        frozen=bool(allow_frozen and not choice.fresh and choice.venue in (Venue.KRX,Venue.NXT) and c.venue_state[choice.venue].last_price>0)
        if not choice.fresh and not frozen:
            # During an active market stale state must fail closed.  Outside all continuous
            # sessions the exact last committed tick is allowed as explicitly-frozen display truth.
            row['price']=None
            row['change_rate']=None
        sig=c.last_signal
        if sig and sig.venue in (Venue.KRX,Venue.NXT):
            sig_live=self.is_fresh_state(c.venue_state[sig.venue],now)
            row['signal_return_status']='LIVE' if sig_live else 'FROZEN' if frozen else 'STALE'
            if not sig_live and not frozen:row['signal_return']=None
        else:
            row['signal_return_status']='NONE'
        if c.last_buy_venue in (Venue.KRX,Venue.NXT) and c.last_buy_price>0:
            buy_live=self.is_fresh_state(c.venue_state[c.last_buy_venue],now)
            row['buy_return_status']='LIVE' if buy_live else 'FROZEN' if frozen else 'STALE'
            if not buy_live and not frozen:row['buy_return']=None
        else:
            row['buy_return_status']='NONE'
        if frozen and float(row.get('score') or 0)<=0:
            # Older G10R2 runtime snapshots did not persist score state. Do not fabricate 0.0 as
            # a real frozen score; the first live G10R3 session will persist exact score thereafter.
            row['score']=None;row['priority_score']=None
        row['display_price_source']='LIVE_TRADE_TICK' if choice.fresh else 'SESSION_CLOSE_FROZEN' if frozen else 'STALE_FAIL_CLOSED'
        row['display_age_ms']=round(choice.age_ms,1) if choice.age_ms is not None else None
        row['display_venue']=choice.venue.value
        row['display_preferred_venue']=choice.preferred.value if choice.preferred!=Venue.UNKNOWN else None
        row['display_venue_fallback']=choice.fallback
        row['display_stale']=not choice.fresh
        return row
