from __future__ import annotations
from app.config import SETTINGS

def load_mode(cpu_pct:float,rss_mb:float,queue_age_ms:float,queue_depth:int,signal_age_ms:float=0.0,event_loop_lag_ms:float=0.0,db_depth:int=0,ui_age_ms:float=0.0)->str:
    cap=SETTINGS.trade_queue_per_shard*SETTINGS.trade_shards
    critical=(rss_mb>=SETTINGS.rss_hard_mb or cpu_pct>=90 or queue_age_ms>500 or queue_depth>cap*.8 or signal_age_ms>500 or event_loop_lag_ms>200 or db_depth>SETTINGS.journal_critical_max*.8 or ui_age_ms>1000)
    high=(rss_mb>=SETTINGS.rss_soft_mb or cpu_pct>=80 or queue_age_ms>250 or queue_depth>cap*.55 or signal_age_ms>250 or event_loop_lag_ms>100 or db_depth>SETTINGS.journal_critical_max*.5 or ui_age_ms>500)
    busy=(cpu_pct>=70 or queue_age_ms>100 or queue_depth>cap*.30 or signal_age_ms>100 or event_loop_lag_ms>50 or db_depth>SETTINGS.journal_critical_max*.25)
    return 'CRITICAL' if critical else 'HIGH_LOAD' if high else 'BUSY' if busy else 'NORMAL'

def hot_capacity(mode:str)->int:
    return {'NORMAL':min(SETTINGS.hot_max,max(SETTINGS.hot_min,SETTINGS.hot_target)),'BUSY':40,'HIGH_LOAD':30,'CRITICAL':SETTINGS.hot_min}.get(mode,SETTINGS.hot_target)
