from __future__ import annotations
import time
from app.domain import TradeTick,ProgramTick,OrderbookTick,Venue
from app.runtime.state import RuntimeState
from app.runtime.dispatcher import Envelope
from app.tracking.live import LiveTracker
from app.runtime.clock import trade_day,sec_of_day
from app.config import SETTINGS

class Ingestor:
    def __init__(self,state:RuntimeState,tracker:LiveTracker):self.state=state;self.tracker=tracker

    def trade(self,e:Envelope):
        tick:TradeTick=e.payload;c=self.state.candidate(tick.code,trade_day=trade_day())
        with self.state.code_lock(tick.code):
            v=c.venue_state[tick.venue]
            # Process-restart guard: compact recovery may know the last cumulative broker value even
            # though TickIntegrity intentionally starts empty. A materially lower same-day cumulative
            # value is not allowed to overwrite that durable baseline.
            if v.last_cum_volume>0 and tick.cum_volume>0 and tick.cum_volume < v.last_cum_volume*.98:
                self.state.telemetry['cumulative_rollback_count']+=1;v.continuity_gap_until=float('inf');v.continuity_reason='CUMULATIVE_RESTORE_ROLLBACK';v.recovery_count=0;v.recovery_started_at=0.0;v.score=0.0;v.stage='SEED';v.metrics['fresh']=False;v.metrics['continuity_ok']=False
                self.state.windows.pop((tick.code,tick.venue),None);self.state.mark_dirty(tick.code,tick.venue);c.metrics['rt_continuity_ok']=False;c.refresh_aggregate();return
            prev_price=v.last_price;prev_high=v.day_high;prev_signed=float(v.metrics.get('last_signed_qty') or 0)
            v.last_price=tick.price;v.last_rate=tick.rate;v.last_tick_at=tick.receive_wall;v.last_exchange_time=tick.exchange_time;v.last_recv_seq=tick.recv_seq
            v.last_cum_volume=tick.cum_volume;v.last_cum_turnover=tick.cum_turnover
            # Cumulative broker fields rebuild session VWAP after WS reconnect/process restart without
            # pretending missing interval ticks existed. Fall back to incremental only if absent.
            if tick.cum_volume>0 and tick.cum_turnover>0:
                v.session_v=tick.cum_volume;v.session_pv=tick.cum_turnover
            else:
                a=abs(tick.qty)
                if a:v.session_pv+=tick.price*a;v.session_v+=a
            if v.continuity_reason:
                if not v.recovery_started_at:v.recovery_started_at=tick.receive_wall;v.warm_started_at=tick.receive_wall
                v.recovery_count+=1
                span=self.state.window(tick.code,tick.venue).aggregate(tick.receive_wall,60,micro=True).get('span_sec',0.0)
                # Formal signals remain fail-closed until a real post-resync trade window exists.
                if v.resync_snapshot_at and v.recovery_count>=5 and float(span)>=SETTINGS.warm_signal_min_sec:
                    v.continuity_gap_until=0.0;v.continuity_reason='';v.resync_required=False;v.warm_ready_at=tick.receive_wall;c.metrics['rt_continuity_ok']=True
            if not v.day_open:v.day_open=tick.price
            v.day_high=max(v.day_high or tick.price,tick.price);v.day_low=min(v.day_low or tick.price,tick.price)
            sod=sec_of_day()
            if 9*3600 <= sod < 9*3600+10*60:
                v.orb_high=max(v.orb_high or tick.price,tick.price);v.orb_low=min(v.orb_low or tick.price,tick.price)
            c.current_venue=tick.venue
            self.state.window(tick.code,tick.venue).add(tick.receive_wall,tick.price,tick.qty)
            notional=abs(tick.price*tick.qty);m=v.metrics
            # Critical event latch is derived only from the current accepted trade tick and
            # pre-tick state. It never depends on a later score-worker update.
            new_high=bool(prev_high and tick.price>prev_high)
            signed_flip=bool(prev_signed<0 and tick.qty>0)
            price_flip=bool(prev_price and prev_price>0 and tick.price>prev_price and tick.qty>0>=prev_signed)
            critical=bool(notional>=50_000_000 or new_high or signed_flip or price_flip)
            m['last_signed_qty']=tick.qty;m['critical_event']=critical;m['critical_event_recv_seq']=tick.recv_seq if critical else int(m.get('critical_event_recv_seq') or 0)
            self.tracker.on_tick(c,tick.venue);self.state.mark_dirty(tick.code,tick.venue,urgent=critical,recv_seq=tick.recv_seq);self.state.generated_at=tick.receive_wall
            c.refresh_aggregate()
        self.state.observe_latency('receiver_to_state_ms',(time.monotonic()-tick.receive_mono)*1000)

    def aux(self,kind:str,code:str,payload):
        venue=getattr(payload,'venue',Venue.UNKNOWN);c=self.state.candidate(code,trade_day=trade_day())
        if venue not in (Venue.KRX,Venue.NXT):return
        with self.state.code_lock(code):
            if kind=='PROGRAM':
                x:ProgramTick=payload;v=c.venue_state[x.venue];prev=v.program_net;v.program_net=x.net;v.program_delta=x.delta if x.delta else x.net-prev;v.program_at=x.receive_wall
            elif kind=='ORDERBOOK':
                x:OrderbookTick=payload;v=c.venue_state[x.venue];prev_bid=float(v.metrics.get('prev_bid_total') or 0);prev_ask=float(v.metrics.get('prev_ask_total') or 0);total=max(x.bid_total+x.ask_total,1);imb=(x.bid_total-x.ask_total)/total;ask_dep=(prev_ask-x.ask_total)/max(prev_ask,1) if prev_ask else 0;bid_build=(x.bid_total-prev_bid)/max(prev_bid,1) if prev_bid else 0;score=max(-3,min(3,imb*4+ask_dep*4+bid_build*3)) if prev_bid or prev_ask else 0
                v.orderbook_score=score;v.orderbook_at=x.receive_wall;v.metrics['prev_bid_total']=x.bid_total;v.metrics['prev_ask_total']=x.ask_total;v.metrics['best_bid']=x.best_bid;v.metrics['best_ask']=x.best_ask
            self.state.telemetry['slow_confirmation_update_count']+=1
            # PROGRAM/ORDERBOOK may strengthen confirmation, but never create a price-bearing
            # formal signal by themselves. The next accepted fresh TRADE tick schedules scoring.

    def dropped(self,e:Envelope,pinned:bool,reason:str='TRADE_QUEUE_OVERFLOW'):
        c=self.state.candidates.get(e.code)
        if pinned:self.state.telemetry['dropped_signal_tick_count']+=1
        elif getattr(e,'critical',False):self.state.telemetry['dropped_critical_tick_count']+=1
        else:self.state.telemetry['dropped_candidate_tick_count']+=1
        if reason=='DISPATCH_HANDLER_ERROR':self.state.telemetry['dispatch_handler_error_count']+=1
        if c:
            with self.state.code_lock(e.code):
                tick=getattr(e,'payload',None);venues=[getattr(tick,'venue',Venue.UNKNOWN)]
                if venues[0] not in (Venue.KRX,Venue.NXT):venues=[Venue.KRX,Venue.NXT]
                for venue in venues:
                    v=c.venue_state[venue];v.continuity_gap_until=float('inf');v.continuity_reason=reason;v.recovery_count=0;v.recovery_started_at=0.0
                    self.state.windows.pop((e.code,venue),None);self.state.mark_dirty(e.code,venue)
                c.metrics['rt_continuity_ok']=False
        self.state.ws_status['gap_count']=int(self.state.ws_status.get('gap_count') or 0)+1
