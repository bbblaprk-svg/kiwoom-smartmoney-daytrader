from __future__ import annotations
import threading,time,hashlib
from collections import deque
from dataclasses import dataclass
from typing import Callable,Any
from app.config import SETTINGS

@dataclass(slots=True)
class Envelope:
    kind:str; code:str; payload:Any; receive_mono:float; pinned:bool=False; critical:bool=False

class ProtectedTradeQueue:
    """Bounded FIFO that reserves admission for already-pinned signal symbols.

    It never reorders accepted events. If full, a pinned arrival may evict the oldest non-pinned
    event; that evicted symbol is immediately fail-closed/resynced by `on_drop`. If the queue is
    entirely pinned traffic, the incoming pinned event is rejected and counted as a critical gap.
    """
    def __init__(self,maxsize:int):self.maxsize=maxsize;self.items=deque();self.cv=threading.Condition()
    def put(self,e:Envelope)->tuple[bool,Envelope|None]:
        with self.cv:
            evicted=None
            if len(self.items)>=self.maxsize:
                protected=e.pinned or e.critical
                if not protected:return False,None
                idx=next((i for i,x in enumerate(self.items) if not (x.pinned or x.critical)),None)
                if idx is None:return False,None
                evicted=self.items[idx];del self.items[idx]
            self.items.append(e);self.cv.notify();return True,evicted
    def get(self,timeout:float=.2)->Envelope|None:
        end=time.monotonic()+timeout
        with self.cv:
            while not self.items:
                left=end-time.monotonic()
                if left<=0:return None
                self.cv.wait(left)
            return self.items.popleft()
    def qsize(self)->int:
        with self.cv:return len(self.items)
    def oldest_age_ms(self)->float:
        with self.cv:
            if not self.items:return 0.0
            return max(0.0,(time.monotonic()-self.items[0].receive_mono)*1000)

class TradeDispatcher:
    """Bounded sharded trade truth lanes with pinned-signal admission protection.

    A symbol always hashes to the same shard, preserving accepted per-symbol order. Candidate
    overload is fail-closed; already-pinned signal symbols may displace noncritical backlog instead
    of being silently lost. Program/orderbook/discovery never enter this queue.
    """
    def __init__(self,handler:Callable[[Envelope],None],on_drop:Callable[[Envelope,bool,str],None],shards:int|None=None,maxsize:int|None=None):
        self.shards=shards or SETTINGS.trade_shards;self.maxsize=maxsize or SETTINGS.trade_queue_per_shard
        self.handler=handler;self.on_drop=on_drop;self.queues=[ProtectedTradeQueue(self.maxsize) for _ in range(self.shards)]
        self.threads=[];self.stop_evt=threading.Event();self.processed=0;self.errors=0;self.max_depth=0;self.last_processed_age_ms=0.0;self.evicted_for_pinned=0

    def _idx(self,code:str)->int:return int.from_bytes(hashlib.blake2s(code.encode(),digest_size=2).digest(),'big')%self.shards

    def submit(self,e:Envelope)->bool:
        q=self.queues[self._idx(e.code)];ok,evicted=q.put(e)
        if evicted is not None:self.evicted_for_pinned+=1;self.on_drop(evicted,False,'TRADE_QUEUE_EVICTED_FOR_PROTECTED')
        if ok:self.max_depth=max(self.max_depth,q.qsize());return True
        self.on_drop(e,e.pinned,'CRITICAL_TRADE_QUEUE_OVERFLOW' if e.critical else 'TRADE_QUEUE_OVERFLOW');return False

    def _run(self,q:ProtectedTradeQueue):
        while not self.stop_evt.is_set():
            e=q.get(.2)
            if e is None:continue
            try:
                self.last_processed_age_ms=max(0.0,(time.monotonic()-e.receive_mono)*1000);self.handler(e);self.processed+=1
            except Exception:
                self.errors+=1;self.on_drop(e,e.pinned,'DISPATCH_HANDLER_ERROR')

    def start(self):
        for i,q in enumerate(self.queues):
            t=threading.Thread(target=self._run,args=(q,),name=f'nova-trade-{i}',daemon=True);t.start();self.threads.append(t)
    def stop(self):self.stop_evt.set()
    def depth(self)->int:return sum(q.qsize() for q in self.queues)
    def oldest_age_ms(self)->float:return max((q.oldest_age_ms() for q in self.queues),default=0.0)

class CoalescingLane:
    """Latest-value lane for program/orderbook/discovery; backlog is bounded by symbol+venue count."""
    def __init__(self,handler:Callable[[str,str,Any],None],interval=.02):
        self.handler=handler;self.interval=interval;self.lock=threading.Lock();self.latest:dict[tuple[str,str,str],Any]={};self.stop_evt=threading.Event();self.thread=None;self.errors=0;self.last_error=''
    def submit(self,kind:str,code:str,payload:Any):
        venue=getattr(getattr(payload,'venue',None),'value','UNKNOWN')
        with self.lock:self.latest[(kind,code,venue)]=payload
    def _run(self):
        while not self.stop_evt.wait(self.interval):
            with self.lock:batch=self.latest;self.latest={}
            for (kind,code,_venue),payload in batch.items():
                try:self.handler(kind,code,payload)
                except Exception as exc:self.errors+=1;self.last_error=str(exc)[:160]
    def start(self):
        self.thread=threading.Thread(target=self._run,name='nova-coalesce',daemon=True);self.thread.start()
    def stop(self):self.stop_evt.set()
    def depth(self)->int:
        with self.lock:return len(self.latest)
