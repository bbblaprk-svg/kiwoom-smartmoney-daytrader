from __future__ import annotations
import time
from app.domain import Candidate
from app.config import SETTINGS

class Top10Registry:
    """Board-local TOP10 membership/reentry accounting.

    One board's first appearance can never become another board's REENTER.
    """
    def __init__(self): self.members:dict[str,set[str]]={}
    @staticmethod
    def _quality(c:Candidate)->tuple[float,str]:
        v=c.current();m=v.metrics;q=0;why=[]
        if c.valid_repeat_count>=2:q+=2;why.append('유효반복')
        if c.entry_state in ('REACCEL','DIRECT_ARM','BUY'):q+=2;why.append('등급상승')
        if float(m.get('micro_vwap_gap') or -9)>=0:q+=1;why.append('VWAP회복')
        if float(m.get('buy_pressure') or 0)>=60:q+=1;why.append('공격매수회복')
        if float(m.get('volume_accel') or 1)>=1.5:q+=1;why.append('거래가속')
        if bool(m.get('smart_money_realtime_proxy_surge')):q+=2;why.append('SMART_MONEY_SURGE')
        return q,' + '.join(why[:4]) or '순위 재진입'
    @staticmethod
    def _stats(c:Candidate,board:str)->dict:
        return c.top10_stats_by_board.setdefault(board,{'enter_count':0,'reentry_count':0,'last_enter_at':0.0,'last_exit_at':0.0})
    def apply(self,board:str,rows:list[Candidate],all_candidates:dict[str,Candidate]):
        limit=SETTINGS.board_slots;now=time.time();new={c.code for c in rows[:limit]};old=self.members.get(board,set())
        for c in rows[:limit]:
            if c.code not in old:
                st=self._stats(c,board)
                if int(st.get('enter_count') or 0)>0:
                    st['reentry_count']=int(st.get('reentry_count') or 0)+1;q,reason=self._quality(c);c.reentry_quality=max(c.reentry_quality,q);c.append_history('TOP10','TOP10_REENTER',c.current().last_price,f'{board} · {reason}',c.current().venue,now)
                else:
                    c.append_history('TOP10','TOP10_ENTER',c.current().last_price,board,c.current().venue,now)
                st['enter_count']=int(st.get('enter_count') or 0)+1;st['last_enter_at']=now;c.refresh_aggregate()
        for code in old-new:
            c=all_candidates.get(code)
            if c:
                st=self._stats(c,board);st['last_exit_at']=now;c.append_history('TOP10','TOP10_EXIT',c.current().last_price,board,c.current().venue,now)
        self.members[board]=new
    def decorate(self,board:str,row:dict,c:Candidate)->dict:
        st=self._stats(c,board);row=dict(row);row['top10_enter_count']=int(st.get('enter_count') or 0);row['top10_reentry_count']=int(st.get('reentry_count') or 0);row['last_top10_enter_at']=float(st.get('last_enter_at') or 0);row['last_top10_exit_at']=float(st.get('last_exit_at') or 0);return row
