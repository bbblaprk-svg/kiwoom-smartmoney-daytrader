# QUANT NOVA 3.3.2 MASTER TOP10 LIVEFIX

Source of truth: `spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt`.

Main path: Broker WS -> lightweight receiver -> bounded protected queue -> venue-isolated state/window -> critical-event latch -> signal worker -> Atomic Snapshot -> durable WAL ACK -> live tracker -> instrument aggregator -> TOP10 ranking -> delta aggregator -> `/ws/live`.

Side paths: REST recovery, DB/performance, snapshots, discovery. Side paths never establish a formal signal price.

Hard invariants: wrong venue=0; signal price mismatch=0; official signal without WAL ACK=0; stale official signal=0; protected signal tick drop=0 inside the supported load envelope.

UI: fixed 10 slots per core board. Layout is fixed; price/rank/state are live. iPhone uses compact rows and bottom-sheet detail; iPad uses expanded rows.

## 3.3.2 Live bootstrap correction
- Cold-start bootstrap Discovery is allowed while recovery states are active only when no live targets exist.
- Empty broker REG groups are forbidden.
- Global feed liveness is separated from per-venue signal eligibility; venue signals remain fail-closed until re-warmed.
- Historical subscription reject counts are telemetry, not permanent current-fault latches.
