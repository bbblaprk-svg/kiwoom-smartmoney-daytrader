import time, unittest
from types import SimpleNamespace
from app.decision_panels import _largecap_row, _pre_row

class AddonDecisionTests(unittest.TestCase):
    def base(self):
        now=time.time()
        return {'code':'005930','name':'삼성전자','venue':'KRX','price':100000.0,'change_rate':1.2,'last_tick_at':now,
                'score':75.0,'priority_score':82.0,'confidence':80.0,'stage':'PRESSURE','entry_state':'PRESSURE_BUILD','lifecycle_state':'TODAY_NEW',
                'repeat':2,'source_hits':4,'now':now,'history':[],
                'metrics':{'buy_pressure':62,'volume_accel':1.8,'session_vwap':99800,'micro_vwap':99900,'session_vwap_gap':.2,'micro_vwap_gap':.1,
                           'program_fresh':True,'program_delta':1000000,'smart_money_realtime_proxy_score':2.5,'smart_money_realtime_proxy_surge':True,
                           'sector_score':3,'micro_breakout':.25,'impulse_60s':.6,'day_low':98000}}
    def test_largecap_has_price_plan(self):
        r=_largecap_row(self.base());self.assertIsNotNone(r);self.assertLess(r['stop'],r['entry_low']);self.assertGreater(r['target1'],r['entry_high']);self.assertGreaterEqual(r['rr'],1.5)
    def test_stale_never_now(self):
        x=self.base();x['last_tick_at']=x['now']-60;r=_largecap_row(x);self.assertNotEqual(r['decision'],'NOW')
    def test_pre_stage_is_valid(self):
        r=_pre_row(self.base());self.assertIn(r['stage'],('PRE','WATCH','CONFIRM'))

if __name__=='__main__':unittest.main()
