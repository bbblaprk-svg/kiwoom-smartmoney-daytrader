#!/usr/bin/env bash
set -euo pipefail
umask 077

REPO="${REPO:-https://github.com/bbblaprk-svg/kiwoom-smartmoney-daytrader.git}"
BASE="${BASE:-$HOME/quant-nova-332}"
ZIP_GLOB='QUANT_NOVA_3.3.2_MASTER_TOP10_LIVEFIX_SOURCE_*.zip'
IMAGE='quant-nova:3.3.2'
OLD='quant-nova'
BACKUP="quant-nova-322-backup-$(date +%Y%m%d-%H%M%S)"
ENVFILE="$(mktemp)"
DIAG="$HOME/nova332-cutover-$(date +%Y%m%d-%H%M%S).log"
NEW_STARTED=0
OLD_RENAMED=0

cleanup_secret(){ rm -f "$ENVFILE"; }
trap cleanup_secret EXIT

rollback(){
  echo "[ROLLBACK] 3.3.2 did not reach LIVE; restoring 3.2.2" | tee -a "$DIAG"
  if [ "$NEW_STARTED" -eq 1 ]; then
    sudo docker logs --tail 250 "$OLD" >>"$DIAG" 2>&1 || true
    sudo docker rm -f "$OLD" >/dev/null 2>&1 || true
  fi
  if [ "$OLD_RENAMED" -eq 1 ]; then
    sudo docker rename "$BACKUP" "$OLD" >/dev/null 2>&1 || true
    sudo docker start "$OLD" >/dev/null
    sleep 8
    curl -s --max-time 5 "http://127.0.0.1:${HOSTPORT}/api/livez" | tee -a "$DIAG" || true
  fi
  echo "ROLLBACK_COMPLETE log=$DIAG"
  exit 1
}

command -v git >/dev/null
command -v unzip >/dev/null
sudo docker version >/dev/null

if ! sudo docker inspect "$OLD" >/dev/null 2>&1; then
  echo "ERROR: current production container '$OLD' not found"
  exit 1
fi

# Capture current production settings without printing secrets.
sudo docker inspect "$OLD" --format '{{range .Config.Env}}{{println .}}{{end}}' > "$ENVFILE"
chmod 600 "$ENVFILE"
DATA_SRC="$(sudo docker inspect "$OLD" --format '{{range .Mounts}}{{if eq .Destination "/app/data/nova30"}}{{.Source}}{{end}}{{end}}')"
HOSTPORT="$(sudo docker inspect "$OLD" --format '{{with (index .NetworkSettings.Ports "8000/tcp")}}{{(index . 0).HostPort}}{{end}}')"
mapfile -t NETS < <(sudo docker inspect "$OLD" --format '{{range $name, $_ := .NetworkSettings.Networks}}{{println $name}}{{end}}')
if [ -z "${DATA_SRC:-}" ] || [ -z "${HOSTPORT:-}" ] || [ "${#NETS[@]}" -eq 0 ]; then
  echo "ERROR: could not capture production mount/port/network"
  exit 1
fi

echo "=== BUILD 3.3.2 FROM CLEAN GITHUB CLONE ==="
rm -rf "$BASE"
git clone "$REPO" "$BASE"
cd "$BASE"
ZIP="$(find . -maxdepth 1 -type f -name "$ZIP_GLOB" | head -1)"
if [ -z "${ZIP:-}" ]; then echo "ERROR: 3.3.2 ZIP not found in repository root"; exit 1; fi
rm -rf deploy332 && mkdir deploy332
unzip -q "$ZIP" -d deploy332
SRCROOT="$(find deploy332 -maxdepth 3 -type f -name requirements.txt -printf '%h\n' | head -1)"
if [ -z "${SRCROOT:-}" ]; then echo "ERROR: source root not found"; exit 1; fi
cd "$SRCROOT"
sudo docker build --no-cache -t "$IMAGE" .

echo "=== STOP 3.2.2 AND START 3.3.2 ==="
sudo docker stop "$OLD" >/dev/null
sudo docker rename "$OLD" "$BACKUP"
OLD_RENAMED=1

if ! sudo docker run -d \
  --name "$OLD" \
  --restart unless-stopped \
  --env-file "$ENVFILE" \
  --network "${NETS[0]}" \
  -p "${HOSTPORT}:8000" \
  -v "$DATA_SRC:/app/data/nova30" \
  "$IMAGE" >/dev/null; then
  rollback
fi
NEW_STARTED=1
for NET in "${NETS[@]:1}"; do sudo docker network connect "$NET" "$OLD" >/dev/null 2>&1 || true; done

echo "=== WAIT FOR 3.3.2 LIVE (max 180s) ==="
LIVE=0
for I in $(seq 1 60); do
  sleep 3
  J="$(curl -s --max-time 2 "http://127.0.0.1:${HOSTPORT}/api/livez" 2>/dev/null || true)"
  STATE="$(printf '%s' "$J" | sed -n 's/.*"feed_state":"\([^"]*\)".*/\1/p')"
  VERSION="$(printf '%s' "$J" | sed -n 's/.*"version":"\([^"]*\)".*/\1/p')"
  printf '[%02d/60] version=%s feed=%s\n' "$I" "${VERSION:-NO_HTTP}" "${STATE:-NO_HTTP}" | tee -a "$DIAG"
  if [ "$VERSION" = 'NOVA-3.3.2-MASTER-TOP10-LIVEFIX' ] && [ "$STATE" = 'LIVE' ]; then LIVE=1; break; fi
done

if [ "$LIVE" -ne 1 ]; then rollback; fi

# Final state and logs; preserve stopped 3.2.2 backup for manual rollback.
echo "=== CUTOVER SUCCESS ===" | tee -a "$DIAG"
curl -s "http://127.0.0.1:${HOSTPORT}/api/livez" | tee -a "$DIAG"; echo
sudo docker ps --filter "name=^/${OLD}$" --format 'table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.Ports}}'
sudo docker logs --tail 120 "$OLD" >>"$DIAG" 2>&1 || true
echo "VERSION=NOVA-3.3.2-MASTER-TOP10-LIVEFIX"
echo "FEED=LIVE"
echo "ROLLBACK_CONTAINER=$BACKUP"
echo "DIAGNOSTIC_LOG=$DIAG"
