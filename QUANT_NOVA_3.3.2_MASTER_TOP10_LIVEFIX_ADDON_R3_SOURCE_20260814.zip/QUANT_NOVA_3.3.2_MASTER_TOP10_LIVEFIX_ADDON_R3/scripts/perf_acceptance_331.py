from __future__ import annotations
import json,statistics,tempfile,time
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.runtime.state import RuntimeState
from app.runtime.ingest import Ingestor
from app.runtime.dispatcher import Envelope
from app.tracking.live import LiveTracker
from app.runtime.display import DisplayState
from app.signal.metrics import MetricEngine
from app.domain import Venue,TradeTick,FeedState
from app.storage.wal import DurableJournal
from app.config import SETTINGS


def pct(xs,p):
    xs=sorted(xs);return xs[int((len(xs)-1)*p)] if xs else 0.0

def rss_mb():
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return float(line.split()[1])/1024
    except Exception:return 0.0
    return 0.0

def main():
    st=RuntimeState();tracker=LiveTracker();ing=Ingestor(st,tracker);metrics=MetricEngine(st);display=DisplayState(st,tracker)
    now=time.time();codes=[f'{i+1:06d}' for i in range(90)]
    # 1,200 broad candidates; 90 live symbols, dual venue.
    for i in range(1200):st.candidate(f'{i+1:06d}',f'S{i+1}')
    st.hot_codes.update(codes);st.restore_done=True;st.feed_state=FeedState.LIVE
    # Prewarm exact fixed-memory windows using 1-second buckets.
    seq=0
    for code in codes:
        c=st.candidates[code]
        for venue,base in ((Venue.KRX,10000.0),(Venue.NXT,10030.0)):
            v=c.venue_state[venue]
            for sec in range(300):
                seq+=1;ts=now-300+sec;p=base+(sec%31)*.2;q=(100+(sec%17)*5)*(1 if sec%4 else -1)
                tick=TradeTick(code,venue,p,q,1.0,sec+1,(sec+1)*p*abs(q),f'{90000+sec:06d}',ts,time.monotonic(),seq)
                ing.trade(Envelope('TRADE',code,tick,time.monotonic(),False))
            v.metrics['fresh']=True;v.continuity_reason='';v.resync_required=False
    while st.urgent_dirty or st.dirty_keys:st.pop_dirty(4096)
    st.telemetry['dropped_critical_tick_count']=0;st.telemetry['dropped_signal_tick_count']=0
    # 5x burst: 20 rounds x 90 symbols x 2 venues x 5 ticks = 18,000 live events.
    score_lat=[];batch24_lat=[];display_lat=[];rss0=rss_mb();t0=time.perf_counter()
    with tempfile.TemporaryDirectory() as td:
        journal=DurableJournal(Path(td));journal.start();formal=0
        for round_no in range(20):
            wall=time.time()
            for code in codes:
                c=st.candidates[code]
                for venue,base in ((Venue.KRX,10000.0),(Venue.NXT,10030.0)):
                    for j in range(5):
                        seq+=1;p=base+round_no*.4+j*.05;q=(100+j*20)*(1 if j%3 else -1)
                        tick=TradeTick(code,venue,p,q,1.0,10000+seq,p*abs(q)*(10000+seq),f'{93000+round_no:06d}',wall+j*.001,time.monotonic(),seq)
                        ing.trade(Envelope('TRADE',code,tick,time.monotonic(),False))
            # Simulate coordinator draining critical/ordinary work before scoring.
            while st.urgent_dirty or st.dirty_keys:st.pop_dirty(4096)
            # Score all 180 venue-keys once per burst round; this is intentionally harsher than ordinary dirty coalescing.
            work=[(st.candidates[code],venue) for code in codes for venue in (Venue.KRX,Venue.NXT)]
            s0=time.perf_counter()
            for off in range(0,len(work),24):
                b0=time.perf_counter()
                for c,venue in work[off:off+24]:metrics.venue_metrics(c,venue,time.time())
                batch24_lat.append((time.perf_counter()-b0)*1000)
            score_lat.append((time.perf_counter()-s0)*1000)
            if round_no%5==0:
                d0=time.perf_counter();display.build(source='PERF_ACCEPTANCE');display_lat.append((time.perf_counter()-d0)*1000)
            if round_no%10==0:
                rec={'event':'SIGNAL_CONFIRMED','signal_id':f'perf-{round_no}','day':'20260814','code':codes[round_no%len(codes)],'venue':'NXT','signal_price':10000+round_no,'signal_time':time.time()}
                assert journal.commit(rec,2);formal+=1
        # Force a final display generation and capture shared-wire sizes.
        display.build(source='PERF_ACCEPTANCE_FINAL');snap=display.get();gen,text=display.wire_for(-1)
        h=journal.health();journal.stop()
        elapsed=time.perf_counter()-t0;rss1=rss_mb();events=20*90*2*5
        assert st.telemetry['dropped_signal_tick_count']==0
        assert st.telemetry['dropped_critical_tick_count']==0
        assert h['db_queue_wait_p95_ms'] < 20.0,(h['db_queue_wait_p95_ms'],h)
        assert h['db_write_latency_p95_ms'] < 25.0,(h['db_write_latency_p95_ms'],h)
        assert pct(batch24_lat,.95) < 50.0,batch24_lat
        assert pct(score_lat,.95) < 250.0,score_lat
        assert pct(display_lat,.95) < 500.0,display_lat
        assert len(text.encode('utf-8')) < 220_000,len(text.encode('utf-8'))
        assert snap['board_slots']==10
        print('COMPOSITE_PERF_331=PASS',json.dumps({
            'events':events,'elapsed_sec':round(elapsed,3),'ingest_plus_score_eps':round(events/elapsed,1),
            'score_batch24_p95_ms':round(pct(batch24_lat,.95),2),'score_all_180_p95_ms':round(pct(score_lat,.95),2),'display_build_p95_ms':round(pct(display_lat,.95),2),
            'wire_snapshot_bytes':len(text.encode('utf-8')),'wire_delta_bytes':int(st.telemetry.get('ui_wire_delta_bytes') or 0),
            'wal_wait_p95_ms':h['db_queue_wait_p95_ms'],'wal_write_p95_ms':h['db_write_latency_p95_ms'],
            'rss_before_mb':round(rss0,1),'rss_after_mb':round(rss1,1),
            'formal_commits':formal,'disk_free_mb':h['disk_free_mb']
        },ensure_ascii=False))

if __name__=='__main__':main()
