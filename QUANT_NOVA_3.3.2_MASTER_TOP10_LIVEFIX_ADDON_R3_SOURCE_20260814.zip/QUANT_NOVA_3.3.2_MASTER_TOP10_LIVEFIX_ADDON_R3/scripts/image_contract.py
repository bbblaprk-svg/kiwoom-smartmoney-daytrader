from __future__ import annotations
import shlex, shutil, subprocess, sys, tempfile
from pathlib import Path

args=[x for x in sys.argv[1:] if x!='--static-only']
STATIC_ONLY='--static-only' in sys.argv[1:]
ROOT = Path(args[0]).resolve() if args else Path(__file__).resolve().parents[1]
DF = ROOT / 'Dockerfile'

def copy_into_runtime(src: Path, dest: str, runtime: Path) -> None:
    if not dest.startswith('/app'):
        return
    rel = dest[len('/app'):].lstrip('/')
    target = runtime / rel
    if src.is_dir():
        # Docker COPY dir /app/dir copies directory contents into /app/dir.
        if dest.endswith('/'):
            target = target / src.name
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(src, target)
    else:
        if dest.endswith('/'):
            target = target / src.name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)

def main() -> None:
    text = DF.read_text()
    required_literals = (
        'COPY Dockerfile /app/Dockerfile',
        'COPY SOURCE_MANIFEST.sha256 /app/SOURCE_MANIFEST.sha256',
        'COPY app /app/app',
        'COPY scripts /app/scripts',
        'COPY tests /app/tests',
        'COPY spec /app/spec',
        'COPY static /app/static',
    )
    for literal in required_literals:
        assert literal in text, f'missing Docker COPY contract: {literal}'

    with tempfile.TemporaryDirectory(prefix='nova-image-contract-') as td:
        runtime = Path(td)
        for raw in text.splitlines():
            line = raw.strip()
            if not line.startswith('COPY '):
                continue
            parts = shlex.split(line)
            if any(x.startswith('--') for x in parts[1:-1]):
                raise AssertionError(f'unsupported COPY option in contract simulator: {line}')
            sources, dest = parts[1:-1], parts[-1]
            for s in sources:
                src = ROOT / s
                assert src.exists(), f'COPY source missing: {s}'
                # multi-source COPY always targets a directory
                d = dest if len(sources) == 1 else dest.rstrip('/') + '/'
                copy_into_runtime(src, d, runtime)

        must_exist = (
            'Dockerfile','SOURCE_MANIFEST.sha256','SIGNAL_POLICY_FROZEN.json','ARCHITECTURE.md','SPEC_TRACEABILITY.md',
            'app/config.py','app/runtime/state.py','app/signal/policy.py','scripts/master_audit.py','scripts/validate.py',
            'spec/QUANT_NOVA_MASTER_IMPLEMENTABLE_FINAL_TOP10_20260814.txt',
            'static/nova.js','tests/test_core.py',
        )
        missing=[x for x in must_exist if not (runtime/x).exists()]
        assert not missing, f'runtime image contract missing: {missing}'

        print('SIMULATED_RUNTIME_IMAGE_FILES=PASS')
        if STATIC_ONLY:
            return
        # This is the exact failure G6 missed: master_audit must be executable from the simulated /app tree.
        env={'PYTHONPATH':str(runtime), **__import__('os').environ}
        cp=subprocess.run([sys.executable, str(runtime/'scripts/master_audit.py')], cwd=runtime, env=env,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30)
        if cp.returncode:
            raise AssertionError('simulated runtime master_audit failed:\n'+cp.stdout)
        assert 'MASTER_SPEC_AUDIT=PASS' in cp.stdout, cp.stdout
        print('SIMULATED_RUNTIME_MASTER_AUDIT=PASS')
        print(cp.stdout.strip())

if __name__=='__main__':
    main()
