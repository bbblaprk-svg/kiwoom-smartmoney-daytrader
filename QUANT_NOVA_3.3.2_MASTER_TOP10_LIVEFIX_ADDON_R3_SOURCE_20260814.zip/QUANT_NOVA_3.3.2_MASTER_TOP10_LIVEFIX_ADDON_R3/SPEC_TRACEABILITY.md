# MASTER TOP10 traceability

- Venue isolation: `app/domain.py`, `app/runtime/state.py`, `app/runtime/projection.py`.
- Protected bounded queues and critical latch: `app/runtime/dispatcher.py`, `app/runtime/state.py`, `app/runtime/ingest.py`.
- RESYNC/WARMING + REST baseline recovery: `app/broker/recovery.py`, `app/runtime/ingest.py`, `app/signal/metrics.py`.
- Atomic signal + WAL ACK: `app/signal/coordinator.py`, `app/signal/policy.py`, `app/storage/wal.py`.
- Smart-money FAST layer: `app/signal/smart_money.py`, `app/signal/metrics.py`.
- Opening overlap windows: `app/runtime/clock.py`, `app/lifecycle/opening.py`.
- TOP10 board-local reentry: `app/tracking/top10.py`, `app/runtime/display.py`.
- WS delta primary UI / REST recovery only: `app/api/app.py`, `static/nova.js`.
- Downstream-aware load control: `app/runtime/load_control.py`, `app/runtime/health.py`.

- REST RESYNC baseline uses the currently documented Kiwoom `ka10004 /api/dostk/mrkcond`; it is reference-only and never becomes `signal_price`. NXT recovery uses the `_NX` broker code.
- Slow confirmation updates do not enqueue a formal signal evaluation; the next fresh trade tick is the only price-bearing trigger.

- LIVE_BOOTSTRAP: `NovaService._discovery_policy()` breaks zero-target RESYNC circular wait; WS never emits empty REG groups.
- GLOBAL_FEED_VS_SIGNAL_READY: global LIVE may coexist with pending venue-key rewarm; `MetricEngine.score()` remains fail-closed per venue.
