(()=>{
'use strict';
const $=id=>document.getElementById(id);
const fmt=(v,d=0)=>v===null||v===undefined||v===''?'-':Number(v).toLocaleString('ko-KR',{maximumFractionDigits:d,minimumFractionDigits:d});
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const rateCls=v=>Number(v)>0?'up':Number(v)<0?'down':'';
function emptyRow(rank){return `<div class="addon-row empty"><div class="rank">${rank}</div><div class="addon-name"><b>-</b><small>대기</small></div><div></div><div></div><div></div><div></div></div>`}
function largeRow(r,rank){
  const state=String(r.decision||'WAIT'),sc=state==='NOW'?'addon-now':state==='WAIT'?'addon-wait':'addon-avoid';
  return `<div class="addon-row"><div class="rank">${rank}</div><div class="addon-name"><b>${esc(r.name||r.code)}</b><small>${esc(r.setup||'-')} · ${esc(r.venue||'-')}</small></div><div class="addon-num">${fmt(r.price)}<br><span class="${rateCls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="addon-num">${fmt(r.score,1)}점</div><div class="addon-zone"><b>${fmt(r.entry_low)}~${fmt(r.entry_high)}</b><br><span class="addon-sub">추격 ${fmt(r.chase_limit)}</span></div><div class="addon-state ${sc}"><b>${esc(state)}</b><small>손절 ${fmt(r.stop)} · T1 ${fmt(r.target1)}</small></div></div>`;
}
function preRow(r,rank){
  const state=String(r.stage||'PRE'),sc=state==='CONFIRM'?'addon-confirm':state==='WATCH'?'addon-watch':'';
  return `<div class="addon-row"><div class="rank">${rank}</div><div class="addon-name"><b>${esc(r.name||r.code)}</b><small>${esc(r.venue||'-')} · ${esc(r.reason||'')}</small></div><div class="addon-num">${fmt(r.price)}<br><span class="${rateCls(r.change_rate)}">${fmt(r.change_rate,2)}%</span></div><div class="addon-num">${fmt(r.score,1)}점</div><div class="addon-zone"><b>10분 ${fmt(r.events_10m)} · 30분 ${fmt(r.events_30m)}</b><br><span class="addon-sub">유효반복 ${fmt(r.valid_repeat_count)}</span></div><div class="addon-state ${sc}"><b>${esc(state)} ${esc(r.acceleration||'→')}</b><small>반복가속 VERIFY ONLY</small></div></div>`;
}
function renderBoard(id,rows,renderer){const root=$(id);if(!root)return;const arr=(rows||[]).slice(0,10);let h='';for(let i=0;i<10;i++)h+=arr[i]?renderer(arr[i],i+1):emptyRow(i+1);root.innerHTML=h}
async function refresh(){
  try{
    const r=await fetch('/api/decision-panels?ui_ts='+Date.now(),{cache:'no-store',headers:{'Cache-Control':'no-cache, no-store, max-age=0','Pragma':'no-cache'}});
    if(!r.ok)throw new Error('HTTP_'+r.status);
    const j=await r.json();
    renderBoard('largecap_swing',j.largecap,largeRow);renderBoard('preignition_accel',j.preignition,preRow);
    const n=$('largecap_note');if(n)n.textContent=j.largecap_note||'';
    window.__NOVA_ADDON__={ok:true,at:Date.now(),source:j.source};
  }catch(e){
    window.__NOVA_ADDON__={ok:false,at:Date.now(),error:String(e)};
    // Fail-open: baseline NOVA stays untouched and visible even if this addon fails.
  }
}
refresh();setInterval(refresh,2500);
})();
