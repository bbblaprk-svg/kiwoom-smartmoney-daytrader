const fs=require('fs'); const assert=require('assert');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8'); const store=fs.readFileSync('lib/realtimeStore.js','utf8');
assert(worker.includes('VENUE_NAME_PRIMARY_NXT_NUMERIC_FALLBACK_FID9081_V2'));
assert(worker.includes('KRX_CORE_0B')); assert(worker.includes('NXT_CORE_0B'));
assert(worker.includes("type:['0B']")); assert(worker.includes("type:['0D','0u']")); assert(worker.includes("type:['0F']"));
assert(store.includes("case '0B':")); assert(store.includes("case '0D': processOrderbook")); assert(store.includes("case '0F': processBroker"));
console.log('REALTIME_ENGINE_V3218_COMPAT_CHECK PASS -> v3.2.21 venue-map core');
