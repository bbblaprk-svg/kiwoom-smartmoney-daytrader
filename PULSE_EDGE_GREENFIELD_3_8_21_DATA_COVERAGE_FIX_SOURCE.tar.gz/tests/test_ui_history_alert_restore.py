from pathlib import Path

def test_ui_no_longer_ab_only_and_has_top10_detail_inline():
    js=Path('pulse_edge/web/pulse.js').read_text()
    html=Path('pulse_edge/web/index.html').read_text()
    assert "x.suitability==='A'||x.suitability==='B'" not in js
    assert "mk('now',10,10)" in js
    assert 'RELEASE READY' in js
    assert 'eligible_now' in Path('pulse_edge/main.py').read_text()
    assert '① HIDDEN GEM · NOW TOP10' in html
    assert html.index('DETAIL · 선택 종목') < html.index('② COILED SPRING')

def test_early_hidden_gem_is_recordable():
    r=Path('pulse_edge/runtime.py').read_text()
    block=r[r.index('def _signal_changed'):r.index('def _coiled_changed')]
    assert "'EARLY HIDDEN GEM'" in block

def test_release_ready_push_is_wired_but_absorbed_is_history_only():
    r=Path('pulse_edge/runtime.py').read_text()
    assert "if c.precursor_stage=='RELEASE READY':" in r
    assert 'self._push_precursor(c)' in r
    helper=r[r.index('async def _push_precursor'):r.index('async def _push(', r.index('async def _push_precursor'))]
    assert "c.precursor_stage!='RELEASE READY'" in helper

def test_original_pre_sequence_lock_untouched():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'pre=bool(pre_common and (model_a_ready or model_b_ready) and pressure_absorbed and release_ready)' in r
