import asyncio,time
from types import SimpleNamespace as N
from pulse_edge.runtime import Runtime
from pulse_edge.config import Settings
from test_logic import build_states

def test_protection_is_real_capacity_bounded_and_expires(tmp_path):
    async def run():
        r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))
        r.active_venue=lambda:'KRX';n=time.time()
        r.discovery_pool=[f'{100000+i:06d}' for i in range(48)]
        r.discovery_meta={w:{'first_seen':n,'last_change':n} for w in r.discovery_pool}
        target='999999'
        r.raw_results=[N(symbol=target,venue='KRX',stage='PRE-IGNITION',precursor_stage='RELEASE READY',data_status='LIVE',sensor_only=False)]
        r.probe_until={f'{200000+i:06d}':n+600 for i in range(8)};r.probe_scores={k:80 for k in r.probe_until}
        await r._apply_priority()
        assert target in r.ws.items() and len(r.ws.priority)<=20 and len(r.ws.items())<=34
        r.raw_results=[]
        await r._apply_priority();assert target in r.ws.items()
        r.priority_leases[target]=(n-1,2)
        await r._apply_priority();assert target not in r.ws.items()
        await r.auth.close();await r.rest.close()
    asyncio.run(run())

def test_daily_failure_does_not_starve_tail_seeds(tmp_path):
    async def run():
        r=Runtime(Settings(feed_enabled=False,baseline_db=str(tmp_path/'b'),history_db=str(tmp_path/'h')))
        r.coiled_seed_symbols=[f'{300000+i:06d}' for i in range(30)]
        r.universe={k:{'name':'TEST'} for k in r.coiled_seed_symbols};calls=[]
        async def post(api,path,body,*args):
            if api=='ka10081':calls.append(body['stk_cd'])
            return {},{}
        r.rest.post=post
        await r.refresh_daily_context();assert len(calls)==20
        await r.refresh_daily_context();assert len(calls)==40 and len(set(calls))==30
        await r.auth.close();await r.rest.close()
    asyncio.run(run())

def test_old_rest_price_does_not_mark_current_trade_conflicting():
    _,sc,states=build_states();st=states['000001:KRX']
    st.rest_price=st.price/1.002;st.rest_price_ts=time.time()-60
    c=sc.score(st,states,sc.sector_stats(states))[1]
    assert c.data_status=='LIVE' and c.stage!='DATA CHECK'
    assert c.stage not in {'PRE-IGNITION','IGNITION IMMINENT'} # expired cross proof blocks PRE

def test_matching_snapshot_then_move_is_not_false_conflict():
    _,sc,states=build_states();st=states['000001:KRX'];n=time.time()
    trade=st.trades[-1];st.rest_price_ts=trade.ts;st.rest_price=trade.price
    assert n-trade.ts<30 and sc.cross_reference(st,n)==0
    st.rest_price=trade.price*.99
    assert sc.cross_reference(st,n)>.003
    st.rest_venue='NXT';assert sc.cross_reference(st,n) is None
