import time
from types import SimpleNamespace
from pulse_edge.presentation import eligible_now, diagnostics
from pulse_edge.models import Candidate, SymbolState
from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime


def _cand(stage='ABSORB'):
    c=SimpleNamespace(name='테스트',sensor_only=False,data_status='LIVE',stage=stage,precursor_stage=None)
    return c

def test_absorb_is_visible_as_observation_candidate():
    assert eligible_now(_cand('ABSORB'))

def test_diagnostics_no_score_reasons_are_subscription_scoped(tmp_path):
    s=Settings(feed_enabled=False, baseline_db=str(tmp_path/'b.db'), history_db=str(tmp_path/'h.db'))
    r=Runtime(s)
    r.active_venue=lambda:'KRX'
    r.ws.priority=['000001']; r.ws.background=[]
    live=r.state('000001','KRX'); live.name='A'
    stale=r.state('000002','KRX'); stale.name='B'
    r.scorer.last_skipped={('000001','KRX'):{'reason':'TRADE_SAMPLES_LT_4'},('000002','KRX'):{'reason':'PRICE_OR_CHANGE_MISSING'}}
    r.scorer.last_evaluated=[]; r.scorer.last_rank_ts=time.time()
    d=diagnostics(r)
    assert d['no_score_reasons']=={'TRADE_SAMPLES_LT_4':1}
    assert d['state_pool_total']==2 and d['active_subscription_states']==1
    r.signal_store.close(); r.baseline.close(); r.db_executor.shutdown(wait=True)
