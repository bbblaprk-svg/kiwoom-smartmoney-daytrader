import time
from types import SimpleNamespace as N
from test_logic import build_states
from pulse_edge.presentation import diagnostics

def test_skip_reasons_preserve_none_and_snapshot():
    _,sc,states=build_states(); st=states['000001:KRX']; sc.last_skipped={}; now=time.time()
    st.change_rate=None
    assert sc.score(st,states,{},now) is None
    snap=sc.last_skipped[(st.symbol,st.venue)]
    assert snap['reason']=='PRICE_OR_CHANGE_MISSING' and snap['change_rate'] is None
    st.change_rate=20
    assert snap['change_rate'] is None
    assert sc.score(st,states,{},now) is None
    assert sc.last_skipped[(st.symbol,st.venue)]['reason']=='CHANGE_OUTSIDE_HIDDEN_RANGE'
    st.change_rate=1.5; st.trades.clear()
    assert sc.score(st,states,{},now) is None
    assert sc.last_skipped[(st.symbol,st.venue)]['trade_count_10m']==0
    st.name='TIGER TEST'
    assert sc.score(st,states,{},now) is None
    assert sc.last_skipped[(st.symbol,st.venue)]['reason']=='EXCLUDED_SECURITY'

def test_diagnostic_reason_and_new_state_are_distinct():
    _,sc,states=build_states(); st=states['000001:KRX']; st.change_rate=None
    sc.rank(states)
    r=N(raw_results=[],states=states,scorer=sc,active_venue=lambda:'KRX',
        ws=N(items=lambda:['000001','000002']),_wire_state=lambda w:states[w+':KRX'],
        priority_leases={},coiled_seed_symbols=[],coiled_results=[])
    # A state received after this evaluation must not borrow another reason.
    sc.last_evaluated=[]
    d=diagnostics(r); a,b=d['subscription_details']
    assert a['stage']=='NOT_QUALIFIED' and a['blockers']==['PRICE_OR_CHANGE_MISSING']
    assert b['stage']=='AWAITING_EVALUATION' and b['evaluation']['evaluated_at'] is None
    sc.rank({})
    assert sc.last_skipped=={}
