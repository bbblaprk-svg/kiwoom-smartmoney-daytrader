from __future__ import annotations
import statistics
from pulse_edge.models import CoiledCandidate

def clamp(x, lo=0.0, hi=100.0):
    return max(lo, min(hi, float(x)))

def _sum(rows, key, n=3):
    vals=[r.get(key) for r in rows[:n] if r.get(key) is not None]
    return sum(vals) if vals else None


def _daily_impact_decay(bars):
    """Daily proxy for price-impact decay: negative price damage per turnover unit.
    This is explicitly a daily proxy, not intraday aggressive-sell tape.
    """
    vals=[]
    for b in bars[:3][::-1]:  # oldest -> newest
        o=float(b.get('open') or 0); c=float(b.get('close') or 0); turn=float(b.get('turnover') or 0)
        if o<=0 or c<=0 or turn<=0:
            vals.append(None); continue
        damage=max(0.0,(o-c)/o*100.0)
        vals.append(damage/max(turn/100_000_000.0,0.01))
    valid=[x for x in vals if x is not None]
    if len(valid)<2: return None,vals
    if len(vals)==3 and all(x is not None for x in vals):
        a,b,c=vals
        if a>=b>=c:
            return (95.0 if a>0 and c<=a*0.5 else 82.0),vals
        if c<a: return 65.0,vals
        return 25.0,vals
    return (70.0 if valid[-1]<valid[0] else 30.0),vals

def _daily_flow_lag(flows,actor,bars):
    rows=sorted(flows,key=lambda r:r.get('date',''),reverse=True)[:3]
    if len(rows)<3 or len(bars)<3: return None,[]
    if actor=='투신+연기금':
        arr=[None if r.get('investment_trust') is None and r.get('pension') is None else (r.get('investment_trust') or 0)+(r.get('pension') or 0) for r in rows]
    else:
        arr=[r.get('foreign') for r in rows]
    if any(x is None for x in arr): return None,arr
    newest,mid,old=[float(x) for x in arr]
    flow_trend=70.0 if newest>=mid>=old and newest>0 else (50.0 if newest>0 and newest>=mid else (25.0 if newest>0 else 0.0))
    oldpx=float(bars[2].get('close') or 0); newpx=float(bars[0].get('close') or 0)
    if oldpx<=0: return None,arr
    reaction=abs((newpx/oldpx-1)*100)
    return round(clamp(flow_trend+clamp((4.0-reaction)/4.0*30,0,30)),1),arr

def _daily_release_distance(dist,compression,supply_decay,tbuild):
    if dist is None: return None
    geometry=clamp((4.0-dist)/4.0*40,0,40)
    comp=clamp(compression/100*25,0,25)
    supply=clamp(supply_decay/100*20,0,20)
    turn=clamp((tbuild-0.8)/0.8*15,0,15)
    return round(clamp(geometry+comp+supply+turn),1)

def score_coiled(st, now_symbols:set[str]|None=None):
    from pulse_edge.feed.kiwoom import excluded_security
    if excluded_security(st.name): return None
    bars=list(st.daily_bars or [])
    flows=sorted(list(st.daily_flows or []),key=lambda x:x.get('date',''),reverse=True)
    if len(bars)<8:
        return None
    bars=sorted(bars,key=lambda x:x['date'],reverse=True)
    px=float(st.price or bars[0]['close'] or 0)
    if px<=0:
        return None
    ref=bars[min(4,len(bars)-1)]['close']
    ch5=(px/ref-1)*100 if ref else 0
    if ch5>=12:
        return None
    ranges=[(b['high']-b['low'])/b['close']*100 for b in bars if b.get('close') and b.get('high') and b.get('low')]
    if len(ranges)<8:
        return None
    r3=statistics.mean(ranges[:3]); rp=statistics.mean(ranges[3:8]) or 1e-9
    compression=clamp((1-r3/rp)*100+50)
    turns=[float(b.get('turnover') or 0) for b in bars]
    t3=statistics.mean(turns[:3])
    hist_turn=[x for x in turns[3:13] if x>0]
    base=statistics.median(hist_turn) if hist_turn else 0
    tbuild=t3/base if base>0 else 0
    turnover_score=clamp((tbuild-0.7)*100)
    highs=[b['high'] for b in bars[:10] if b.get('high')]
    breakout=max(highs[1:] or highs) if highs else None
    dist=((breakout/px)-1)*100 if breakout and breakout>=px else 0.0
    geometry=clamp(100-abs(dist-2.0)*22) if 0<=dist<=5 else max(0,45-abs(dist)*8)

    foreign=_sum(flows,'foreign',3)
    trust=_sum(flows,'investment_trust',3)
    pension=_sum(flows,'pension',3)
    core=(trust or 0)+(pension or 0) if trust is not None or pension is not None else None
    actor='투신+연기금' if (core or 0) >= (foreign or 0) else '외국인'

    def accel(key):
        vals=[r.get(key) for r in flows[:3]]
        if len(vals)<3 or any(v is None for v in vals): return 0.0
        newest,mid,old=vals[0],vals[1],vals[2]
        if newest>mid>old and newest>0: return 100.0
        if newest>0 and newest>=mid: return 70.0
        if newest>0: return 45.0
        return 0.0
    if actor=='투신+연기금':
        core_rows=[]
        for r in flows[:3]:
            a=r.get('investment_trust'); b=r.get('pension')
            core_rows.append(None if a is None and b is None else (a or 0)+(b or 0))
        if len(core_rows)>=3 and None not in core_rows and core_rows[0]>core_rows[1]>core_rows[2] and core_rows[0]>0:
            flow_acc=100.0
        elif core_rows and core_rows[0] is not None and core_rows[0]>0:
            flow_acc=70.0
        else:
            flow_acc=0.0
    else:
        flow_acc=accel('foreign')

    p2=bars[min(2,len(bars)-1)]['close']
    price_reaction=abs((bars[0]['close']/p2-1)*100) if p2 else 99
    latency=clamp(flow_acc-price_reaction*12+20)

    down=[]
    for b in bars[:5]:
        o,c,h,l=b.get('open'),b.get('close'),b.get('high'),b.get('low')
        if o and c and h and l and c<=o:
            down.append((h-l)/c*100)
    supply_decay=70.0 if len(down)>=2 and down[0]<=down[-1] else (50.0 if down else 40.0)
    if tbuild>=1.0:
        supply_decay=min(100,supply_decay+15)

    base_score=round(clamp(flow_acc)*.25 + latency*.20 + supply_decay*.20 + compression*.15 + turnover_score*.10 + geometry*.10,1)
    impact_decay,impact_windows=_daily_impact_decay(bars)
    flow_lag,actor_daily_flows=_daily_flow_lag(flows,actor,bars)
    release_score=_daily_release_distance(dist,compression,supply_decay,tbuild)
    precursor=[x for x in (impact_decay,flow_lag,release_score) if x is not None]
    pressure_release=round(sum(precursor)/len(precursor),1) if precursor else None
    axes=sum(1 for x in precursor if x>=60)
    # Preserve the original coiled score as the majority component, while requiring
    # the new pressure-release evidence for the strongest stages.
    score=round(base_score if pressure_release is None else clamp(base_score*.75+pressure_release*.25),1)
    hidden=(st.change_rate is None or -3<=st.change_rate<=6) and ch5<12 and dist<=5
    if not hidden:
        return None
    release_ready=bool(score>=82 and release_score is not None and release_score>=65 and axes>=2)
    pressure_absorbed=bool(score>=78 and axes>=1 and ((impact_decay or 0)>=60 or (flow_lag or 0)>=60))
    stage='RELEASE READY' if release_ready else ('PRESSURE ABSORBED' if pressure_absorbed else ('COILED' if score>=80 else ('BUILDING' if score>=70 else 'WATCH')))
    expected='1일' if release_ready and 0<=dist<=2.5 else '1~2일'
    promoted=bool(now_symbols and st.symbol in now_symbols)
    reasons=[f'FLOW={actor}',f'FLOW_ACCEL={flow_acc:.0f}',f'LATENCY={latency:.0f}',f'COMPRESSION={compression:.0f}',f'TURNOVER_BUILD={tbuild:.2f}',f'SUPPLY_DECAY={supply_decay:.0f}',f'BREAKOUT_DISTANCE={dist:.2f}%',f'DAILY_IMPACT_DECAY={impact_decay}',f'DAILY_IMPACT_WINDOWS={impact_windows}',f'DAILY_FLOW_PRICE_LAG={flow_lag}',f'ACTOR_DAILY_FLOWS={actor_daily_flows}',f'DAILY_RELEASE_DISTANCE={release_score}',f'PRESSURE_RELEASE_SCORE={pressure_release}',f'PRECURSOR_AXES={axes}']
    return CoiledCandidate(st.symbol,st.name,st.market,px,st.change_rate,score,actor,foreign,trust,pension,core,round(latency,1),round(compression,1),round(supply_decay,1),round(tbuild,2),round(dist,2),expected,stage,promoted,impact_decay,flow_lag,release_score,pressure_release,axes,reasons)

def rank_coiled(states, now_symbols:set[str]|None=None, limit=5):
    rows=[]
    seen=set()
    for st in states.values():
        if st.venue!='KRX' or st.symbol in seen:
            continue
        seen.add(st.symbol)
        c=score_coiled(st,now_symbols)
        if c and c.score>=60:
            rows.append(c)
    rows.sort(key=lambda x:(x.promoted_to_now,x.stage=='RELEASE READY',x.pressure_release_score or -1,x.score,x.energy_latency,x.compression_score),reverse=True)
    return rows[:limit]
