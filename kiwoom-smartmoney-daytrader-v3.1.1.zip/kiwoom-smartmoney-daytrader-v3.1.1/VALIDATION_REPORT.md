# v3.1.1 validation

핫픽스 대상: Safari client-side exception. 원인: LiveTab 정렬 비교식에서 정의되지 않은 `s` 변수 참조.

# v3.1.0 검증 보고서

검증 대상: 키움 스마트머니 실시간·종가 단타 앱

## 이번 수정 범위

- 키움 REST 일봉(`ka10081`) OHLCV 조회
- KRX 종가와 NXT 현재/최종가 분리
- 이동평균·거래량비·고가 대비 마감 위치 계산
- 종가매수·보유·관망·축소·청산 판단
- 마감 직전 실시간 스마트머니·프로그램·외국계 추정값 저장
- 앱 시작·주기·KRX/NXT 종료 시 자동 종가 동기화
- 수동 `/api/snapshots` 동기화
- 로컬 JSON 영속저장과 Docker named volume
- 체결 미수신 상태의 비정상 지연시간 표시 수정
- Lightsail 업데이트 건강검사와 자동 롤백

## 실행한 검사

### JavaScript·JSX 구문검사

- 일반 JavaScript 파일 전체 `node --check` 통과
- TypeScript 파서를 이용한 36개 JavaScript/JSX 파일 파싱 통과

### 단위검사

`STORE_DISABLE_LOCAL_FILE=true node scripts/check.js` 통과:

- 고정 4 + 사용자 집중 4 + 사용자 경량 4 제한
- KRX/NXT/SOR 코드 변환
- 실시간 BUY/SELL 위험 게이트
- 품질점수가 확률이 아님을 확인
- 일봉 응답 정규화와 거래대금 단위 변환
- 5일·20일 이동평균과 거래량비 계산
- 종가판단과 종가 매매계획 계산
- 마감 직전 수급 추적값 보존
- 체결 미수신 표시 처리

결과: `CHECK OK`

### 통합검사

`STORE_DISABLE_LOCAL_FILE=true node scripts/integration-check.js` 통과:

- 10호가·프로그램·거래원·체결 순차 주입
- 데이터 완전성 95% 이상
- 스마트머니 TURN/EXPANSION
- 체결 3회·조건 800ms 유지
- 집중 종목 BUY 확정
- 경량 종목 BUY 차단과 승격점수

결과: `INTEGRATION CHECK OK`

### 영속저장 검사

서로 다른 Node 프로세스에서 임시 JSON 파일을 이용해 종가 스냅샷을 기록하고 다시 읽었습니다.

결과: `WRITE_OK`, `READ_OK 70100`

### 배포 스크립트 검사

- `update-lightsail-v3.1.0.sh`의 `bash -n` 구문검사 통과
- 기존 `.env` 재사용
- `/app/data` named volume 연결
- 새 컨테이너 건강검사 후 교체
- 실패 시 기존 컨테이너 자동 롤백 구조 확인

## 검증환경 제한

이 작업환경에서는 npm 패키지 레지스트리 접속이 불안정해 전체 `npm install && next build`를 재현하지 못했습니다. 대신 모든 JS/JSX 구문검사와 단위·통합검사를 통과시켰습니다. 실제 Lightsail 업데이트에서는 Dockerfile이 `npm run check && npm run build`를 실행하며, 빌드 또는 건강검사가 실패하면 업데이트 스크립트가 기존 v3.0.0 컨테이너로 자동 복구합니다.

## 실서버에서 확인할 항목

1. `/api/health`의 `status: connected`
2. `closeSnapshots`가 감시 종목 수와 일치
3. 앱의 `종가 확보 4/4`
4. KRX 종가·OHLCV가 영웅문 일봉과 일치
5. NXT 최종가와 괴리율이 증권사 화면과 일치
6. 15:32 이후 KRX 종가판단 자동 생성
7. 20:01 이후 NXT 최종 반영 판단 자동 갱신
8. 서버 재부팅 뒤 종가 스냅샷 복구

## 실전 판정

v3.1.0은 **읽기 전용 데이터·신호 검증판**입니다. 종가점수와 품질점수는 적중확률이 아니며 수익을 보장하지 않습니다. 실제 자금 투입 전 최소 여러 거래일 동안 영웅문 데이터 일치와 종가판단 성과를 기록해 검증해야 합니다.
