## 2.4.15 — LIVE FREEZE + SHADOW VALIDATION

- 2.4.13 LIVE 점수/BUY/EXIT 임계값은 그대로 유지합니다.
- 별도 `app/shadow_engine.py`에서 De-duplicated Shadow Score를 관찰 전용으로 계산합니다. LIVE score/stage/entry/signals는 변경하지 않습니다.
- FLOW/VOLUME/MOMENTUM/POSITION/CONFIRM/DNA 그룹 기여도와 leave-one-feature-out 효과를 replay snapshot에 저장합니다.
- Shadow 호출 전후의 BUY 관련 Candidate 상태를 비교하는 mutation guard가 있으며 위반 시 Shadow 결과만 폐기합니다.
- Evidence report는 30분 replay OOS에서 LIVE 상위 25%와 Shadow 상위 25%의 평균/중앙 수익률·양(+) 비율을 비교합니다. `auto_apply=false`이며 EVALUABLE OOS 이후에도 사람 승인 전에는 LIVE 승격이 불가능합니다.
- selfcheck는 2.4.13의 핵심 BUY/Entry/Second-wave/Recovery 함수 및 주요 임계값 hash를 parity baseline과 비교합니다.


## 2.4.13 — KRX CLOSE BACKFILL + 2030 CALENDAR

- 19:15~19:25 확대유니버스에서 처음 발견된 종목도 KRX 종가 수급 근거가 비지 않도록 **KRX-only REST backfill**을 수행합니다.
- 프로그램은 `ka90004`의 KRX(`stex_tp=1`) 시장별 캐시, 기관/투신/연기금/외국인은 KRX 코드의 `ka10059`만 사용합니다.
- NXT가 거래 중인 19시대에 통합 현재가를 KRX 종가로 오인하지 않도록 **가격 backfill은 하지 않습니다**. KRX 가격 근거가 없으면 그대로 `None`이며, 수급 근거만 KRX로 보강합니다.
- backfill은 WATCH/Evidence 전용이며 `record_buy_signal`을 호출하지 않고 기존 BUY/FAST_JUMP/RECOVERY 임계값을 변경하지 않습니다.
- KRX 기본 휴장 캘린더를 **2026~2030**으로 확장했습니다. 2027~2030 설·추석·부처님오신날은 한국 음력 달력으로 미리 계산하고 현행 대체공휴일 규칙, 근로자의날, KRX 연말휴장일을 반영합니다.
- 향후 정부 임시공휴일, 긴급휴장, 선거일 변경 등 아직 공표되지 않은 가변 일정은 `data/krx_calendar_override.json`으로 즉시 덮어쓸 수 있습니다.
# QUANT NOVA 2.4.13 — SMART MONEY CLOSE TRUTH / DELTA-SLOPE HARDENING

AWS Lightsail Instance + Docker 배포용 QUANT NOVA 검증강화판입니다. 2.4.13는 2.4.11의 BUY 기준을 그대로 동결하고, 급등 조기포착이 실제로 얼마나 빨랐는지를 거짓 없이 검증하는 Evidence 계층을 보강합니다. FAST_JUMP/RECOVERY_EARLY의 추격매수 금지 정책은 그대로 유지합니다. 기존 2.4.6의 목적은 신호 수를 무작정 늘리는 것이 아니라 **실시간 원천 데이터의 거래소 의미를 고정하고, NXT 급등 초입·짧은 2차파동·장기 눌림 후 회복·19:30~19:50 종가배팅을 NXT-only 데이터로 판정**하는 것입니다.


## 2.4.10 Evidence Truth + Last Screen Hold

1. **Forced 5/15/30m Follow-up** — prospective 경보가 발생하면 해당 종목을 보호 목록과 제한된 FOLLOWUP WS 슬롯에 유지해 5·15·30분 verified tick을 별도 outcome 원장에 기록합니다. 장 종료/데이터 유실은 성공사례에서 조용히 제외하지 않고 `CENSORED`로 남기며 coverage를 공개합니다.
2. **Exact Horizon Labels** — 5/15/30분 결과는 각각 별도 horizon으로 저장하고 `actual_horizon_sec`를 함께 기록합니다. 4분 마지막 가격을 30분 수익률처럼 쓰지 않습니다.
3. **Market-wide TOP1 Recall** — 장 종료 후 공식 `ka10099`의 `nxtEnable=Y` 일반주를 모집단으로 잡고, NXT `ka10027` 상승률 상위 1%에 대해 NOVA의 당일 최초 사전알림 recall, +3/+5/+10% 이전 포착률, 고점까지 선행시간을 별도로 측정합니다. 관찰표본 내부의 TOP1 precision과 시장 전체 recall을 혼동하지 않습니다.
4. **Whole-Day Recovery Anchor** — 1차 고점/1분 압축바의 기본 보존을 12시간(당일 세션 범위)으로 늘려 오전 급등 후 오후·애프터 재회복도 같은 RECOVERY 문턱으로 평가합니다. 가격·수급 BUY 임계값은 낮추지 않습니다.
5. **Readiness-Sealed Archive** — 당일 gzip archive는 RALLY/EXIT review, replay queue flush, prospective follow-up, market TOP1 audit가 끝난 뒤에만 봉인합니다. prospective outcome과 market TOP1 audit도 archive에 포함됩니다.
6. **Event Context Guard** — `거래정지 해제`, `회생절차 종결`, `상장폐지 사유 해소`처럼 부정 키워드가 들어가도 의미가 반대인 문맥을 먼저 분리하고, DART 당일 목록은 최대 5페이지까지 순회합니다.

**중요:** 이 버전은 BUY 문턱을 변경하지 않습니다. 목적은 신호 수 증가가 아니라 기존 조기발견 능력의 실제 OOS 증명입니다.


## 2.4.8 Prospective Anti-Hindsight + Top-1% Target (기존 유지)

1. **FAST_JUMP_WATCH / READY** — 처음 발견될 때 이미 +8~15%인 고속 급등주는 놓치지 않되 두 단계 모두 `⛔ 매수금지`입니다. 직접 BUY 경로가 없고 기존 SECOND_WAVE/RECOVERY가 새로 확인될 때만 BUY가 가능합니다.
2. **RECOVERY_EARLY** — 과거 시점에서 확정 가능한 저점 안정시간을 통과하고 낙폭의 30% 이상을 회복한 시점에 관찰 Push를 냅니다. 역시 `⛔ 매수금지`이며 READY/BUY 기준을 낮추지 않습니다.
3. **Frozen Prospective Snapshot** — WATCH/READY가 발생한 순간의 가격·등락률·NXT 수급·VWAP·거래량가속·호가·공시·포착백분위를 append-only 원장에 기록합니다. 미래 수익률/라벨은 원본 줄에 쓰지 않습니다.
4. **Top-1% Catch Target** — 현재 관찰 유니버스 안에서 NXT catch score의 cross-sectional percentile을 계산해 99백분위 후보를 표시합니다. 이것은 상위 1% 달성을 보장하는 문구가 아니라 OOS로 검증해야 하는 목표 지표입니다.
5. **Evidence V3** — 별도 5·15·30분 outcome과 replay를 JOIN하여 FAST_JUMP/RECOVERY_EARLY의 MFE/MAE/수익률과 top1-target precision을 측정합니다. 시장 전체가 아닌 NOVA 관찰표본 범위라는 한계를 명시합니다.


### TOP1 표기 안전장치
- `TOP1 TARGET`은 동시 NXT 관찰표본이 **100개 이상**일 때만 99백분위 종목에 표시합니다. 표본이 100개 미만이면 FAST_JUMP READY가 발생해도 `TOP1 표본부족`으로 표시합니다.
- 실제 성과의 TOP1 precision은 prospective OOS 30분 결과가 **300개 미만이면 공개하지 않습니다**. 300~999개는 PRELIMINARY, 1,000개 이상부터 EVALUABLE로 표시합니다.
- 이는 시장 전체 상위 1% 달성을 보장하는 문구가 아니라, **상위 1% 포착을 목표로 사전등록된 성능검증 장치**입니다.

## 2.4.7 Evidence-First Hardening

1. **Evidence Engine** — BUY route별 주간/월간 표본수, 승률과 Wilson 95% CI, 기대값과 95% CI, MFE/MAE, Profit Factor, 거래수익 복리 MDD, trade Sharpe, +3/+5/+10% 도달률을 `/api/evidence`에 제공합니다. RALLY DNA ON/OFF 비교는 관찰 비교로 명시하며 인과효과로 과장하지 않습니다.
2. **Replay Journal + Offline Backtest** — 라이브 scoring/WS 경로에서는 디스크를 쓰지 않고 중요 종목 snapshot만 메모리 queue에 1~5초 간격으로 쌓은 뒤 별도 loop가 기록합니다. `scripts/replay_backtest.py`는 signal/micro 모드의 train→validation→OOS walk-forward를 수행하며 `auto_apply=false`입니다.
3. **Candidate 1,200 hard cap + structural lock** — 오픈 포지션, WS CORE/BURST, NXT memory, 종가후보, 당일 BUY는 보호하고 저품질·stale 후보만 퇴출합니다. 실시간 tick metric에는 글로벌 lock을 걸지 않고 candidate 생성/삭제·WS pool 재구성 같은 구조변경만 lock합니다. 늦게 도착한 orphan WS tick은 candidate를 lock 밖에서 재생성하지 않고 drop합니다.
4. **Lossless Daily Gzip Archive** — BUY/RALLY/EXIT/replay/events/push/manual 자료를 `data/archive/YYYYMMDD/`에 sealed gzip + SHA256 manifest로 보존합니다. 기존 hot-file compaction과 분리하여 백테스트 과거자료를 잃지 않습니다.
5. **Orderbook Wall V2** — 실시간 0D 10단계 호가에서 같은 가격대 매수벽 지속시간, 매도잔량 흡수, 매수벽 급소멸 위험을 계산합니다. 이는 조작을 단정하는 탐지가 아니라 `cancel-risk/spoof-like risk`이며 RECOVERY/CLOSE_BET의 soft confirm/감점에만 사용합니다.
6. **Event Polarity Guard** — DART/RSS를 POSITIVE/NEGATIVE/NEUTRAL/UNCERTAIN으로 결정론적으로 분류합니다. 상장폐지·횡령/배임·회생/파산·거래정지·감사의견거절 등 중대 악재는 신규 BUY를 차단하고, 유상증자/CB/BW/감자 등은 감점합니다. 호재는 soft prior일 뿐 단독 BUY를 만들 수 없습니다.

**중요:** Evidence/Backtest 결과는 라이브 파라미터를 자동 변경하지 않습니다. OOS 표본과 신뢰구간을 확인한 뒤 사람이 승인해야 합니다.

## 2.4.6 Recovery + Close-Window Finalization
- NXT 신호관리테이블의 점수/신뢰도/SMART/BP/OB/프로그램/기관/BUY 확인은 NXT venue 값만 사용합니다. 일반 NOVA 점수는 NXT 전용 열에 재사용하지 않습니다.
- 자동 EXIT-DNA는 진입 시장의 가격뿐 아니라 pressure/persistence/impulse/VWAP/breakout/호가/프로그램/기관/재가속을 끝까지 같은 venue로 고정합니다. KRX와 NXT의 microflow를 대칭 분리합니다.
- ELITE SWING/CLOSE_BET 보호곡선은 MFE +12/+22/+35%에서 각각 +4/+10/+18% 보호로 완화하고, 기존 +12/+22 부분익절 및 65% runner/9% trail 구조와 맞춥니다. NORMAL/STRONG 규칙은 유지합니다.

## 1. 실시간 데이터 계약

- 주식체결 WebSocket: **0B**
- 종목프로그램매매 WebSocket: **0w**
- 주식호가잔량 WebSocket: **0D**
- NXT 실시간 종목은 `_NX` qualified code를 별도 등록합니다.
- FID9081이 KRX/NXT로 확인되지 않으면 `UNKNOWN`으로 두고 fail-closed 합니다.
- KRX/NXT 체결가·등락률·최근 tick·호가 baseline·프로그램/기관 수급을 시장별로 분리 저장합니다.

## 2. 프로그램·기관 수급

- 프로그램 realtime은 0w를 KRX/NXT별로 저장합니다.
- realtime이 오래되면 `ka90004` 종목별프로그램매매현황을 KRX/NXT(`stex_tp=1/2`)와 KOSPI/KOSDAQ 시장별로 조회해 캐시하고 종목코드로 선택합니다.
- 투자자 수급 `ka10059`은 KRX 기본코드, NXT는 `종목코드_NX`를 사용합니다.
- 오래된 프로그램/기관 수급은 BUY 양성 근거로 쓰지 않습니다.

## 3. 급등주 조기발견

- REST 전체시장 discovery와 별도로 NXT fast rolling radar를 운용합니다.
- NXT 프리마켓 08:00~08:50, 동시시장 09:00:30~15:20, 애프터 15:40~20:00을 감시합니다.
- 신규 급등 후보는 BURST WATCH / BURST-HR로 승격해 실체결·호가·프로그램을 더 촘촘히 봅니다.
- 30초/60초 거래량 가속, NXT 매수압력, 호가잔량, micro breakout, 알고리즘 지속성, 단일체결 편중을 함께 확인합니다.
- **1억원 이상 NXT 공격매수 반복횟수**는 조기확인의 보조 가산점으로만 사용하며 기존 BUY 문턱을 낮추지 않습니다.

## 4. NXT 신호관리 / 2차파동

- EARLY_WATCH → PRE_IGNITION → EMERGENCY_IGNITION/IGNITION → SECOND_WAVE_BASE/READY/BUY 흐름을 거래일 원장에 보존합니다.
- NXT 관리테이블의 현재가·등락률·매수압력·호가·프로그램·기관 수급은 NXT venue 값만 사용합니다.
- 1차파동 기억은 순위에서 사라져도 유지하며, 3~10% 눌림·거래량 dry-up·저점방어·재가속·돌파를 추적합니다.
- SECOND WAVE는 애프터마켓뿐 아니라 **NXT 전체 활성 세션**에서 동작합니다.

## 4-1. NXT 장기눌림 회복 (RECOVERY_READY / RECOVERY_BUY)

- 1차 NXT 급등 고점과 1분 압축바를 최대 12시간(당일 세션 범위) 보존합니다.
- 1차 고점 이후 **4~15% 눌림**이 발생하고, 저점에서 다시 이전 고점 방향으로 **50% 이상 회복**하면 장기회복 후보를 평가합니다.
- `RECOVERY_READY`: 가격 회복이 명확하고 NXT-only 매수압력·지속성·VWAP·호가·거래량 중 복수 근거가 확인되면 즉시 Push합니다. 한 개 보조 feed가 잠시 중립이어도 명확한 회복패턴이 사라지지 않도록 support-count 방식을 사용합니다.
- `RECOVERY_BUY`: 회복률 68% 이상, 이전 고점과 거리 3.5% 이내, NXT buy pressure/persistence/VWAP/impulse/orderbook/활동성이 더 강하게 확인될 때만 BUY 경로로 승격합니다.
- 급등률이 이미 +12%를 넘었다는 이유만으로 회복 신호를 막지 않고, **검증된 깊은 눌림 후 회복**이면 별도의 과열가드 하에서 최대 +18.5% 구간까지 평가합니다.
- 이는 대화제약처럼 오후 급등 → 깊은 눌림 → 19시대 재회복하는 패턴을 짧은 6~20분 SECOND_WAVE와 별도로 포착하기 위한 경로입니다.

## 5. 19:30~19:50 종가배팅

- 19:30~19:50: 하루 NXT Strong Ledger와 최근 5~10분 NXT-only 체결·거래량·고가유지·호가·프로그램/기관·1억원 공격체결을 계속 재확인
- 강한 상태 45초 지속: `CLOSE_READY` 즉시 표시·Push
- 강한 상태 90초 지속 + BUY 점수/수급 확인: `CLOSE_BUY` 즉시 표시·Push
- 19:50은 신규 판정의 유일한 시각이 아니라 최종 요약 시점이며, 이전 READY/BUY는 그대로 보존
- actionable 후보는 최대 5종목입니다.
- `CLOSE_BET`은 별도 포지션 유형이라 SCALP의 19:50 강제청산 규칙을 적용받지 않으며, ELITE TP2 이후 65% runner에 9% trail이 실제 적용됩니다.
- 후보와 신호는 밤새 유지되어 다음 거래일 07:50에 다시 표시되고 08:00~08:50 NXT 프리마켓에서 `WATCH/CONFIRMED/SURGE/WEAK`로 재검증됩니다.
- 자동 주문은 하지 않습니다. 사용자가 실제 체결가·시장을 입력해 관리합니다.

## 6. 최대수익 Entry / Exit

Entry는 기존 검증 구조를 유지합니다.

- PULLBACK → REACCEL BUY
- DIRECT IGNITION BUY
- DNA EARLY TRIGGER
- NXT WS EMERGENCY IGNITION
- NXT SECOND WAVE BUY
- 과열 상승률, 1분 과속, VWAP 과이격, 단일체결 편중, 섹터 과열은 추격매수 방지 가드로 유지합니다.

Exit/매도관리는 진입한 시장을 고정합니다.

- NXT 진입이면 가격뿐 아니라 매수압력·호가·프로그램/기관 수급도 NXT만 사용합니다.
- NORMAL / STRONG / ELITE 모드에 따라 1차·2차 익절과 추세보유 비중을 조절합니다.
- SWING/CLOSE_BET 손절·수익보호·트레일링 구조를 유지합니다.
- EXIT DNA는 MFE 후 giveback, flow fade, VWAP break를 장 종료 후 복기합니다.

## 7. 알림 신뢰성

- EARLY는 원장 기록 중심, PRE/EMERGENCY/IGNITION/SECOND_WAVE_READY/BUY/RECOVERY_READY/BUY/PREMARKET_CONFIRM/CLOSE_BET_READY/BUY/최종요약은 Push 대상입니다.
- `push_scheduled`와 실제 전달 결과를 분리합니다.
- `push_attempted_count`, `push_delivered_count`, `push_failed_count`, `push_last_error`를 기록합니다.
- 전달 결과는 `push_delivery_events.jsonl`에 저장하고 재시작 후 당일 알림 원장에 다시 합칩니다.


## 7-1. 자동 EXIT-DNA ELITE 보호

- 자동 BUY도 진입시장(KRX/NXT)의 가격·pressure·persistence·impulse·VWAP·breakout·호가·프로그램/기관만 사용합니다.
- ELITE 자동 포지션은 기본 보호선을 MFE +12/+22/+35%에서 각각 **+4/+10/+18%**로 완화합니다.
- TP2 영역(+22% MFE 이상)에 들어온 ELITE runner는 별도로 **고점 대비 9% trail**을 적용합니다. 기본 floor와 runner trail을 구분해 기록합니다.

## 8. 학습 누수 방지

- adaptive entry, RALLY DNA, EXIT DNA 모두 **당일 결과는 당일 점수에 재사용하지 않습니다.**
- 당일 성과를 pending으로 수집한 뒤 다음 거래일부터 적용합니다.
- RALLY/EXIT는 날짜순 walk-forward 검증과 calibration 품질을 함께 확인합니다.

## 9. 야간 휴면 / 08:00 복귀

- 20:05~07:30에는 고빈도 WS/discovery/scoring을 휴면합니다.
- 07:30부터 wake guard가 동작합니다.
- 07:55에 WebSocket을 강제 재로그인하고 realtime group을 다시 등록합니다.
- iPhone/PWA가 백그라운드에서 복귀하면 `visibilitychange`, `pageshow`, `focus`에서 live init을 재검증합니다.

## 10. 배포 안전장치

Docker build 단계에서 다음 검사를 통과해야 합니다.

1. `python -m py_compile app/main.py`
2. `python scripts/selfcheck.py`
3. `node --check static/nova.js`는 Lightsail updater에서 추가 수행
4. `SOURCE_MANIFEST.sha256` 전체 파일 무결성 검사

Lightsail updater는 기존 `$HOME/quant-nova/.env`와 `$HOME/quant-nova/data`를 유지하고 새 컨테이너 health가 실패하면 이전 컨테이너로 자동 rollback합니다.

## 주의

이 패키지는 **자동 주문 시스템이 아닙니다.** BUY/CLOSE_BET/EXIT는 판단 및 관리 신호이며 실제 주문 체결은 사용자가 수행합니다. 정적·회귀 테스트는 실시간 데이터 계약과 코드 흐름을 검증하지만, 실제 장중 수신 성공 여부는 배포 후 `/api/nova` health와 NXT 관리테이블에서 최초 장중 확인이 필요합니다.


## 2.4.10 장종료 화면 보존
- 20:00~20:05 최종 화면을 `data/eod_screen_snapshot.json`에 읽기전용 저장합니다.
- 자정, 토·일요일, KRX 휴일에는 전 거래일 화면을 삭제/초기화하지 않습니다.
- 다음 **실제 거래일 07:30 KST**에만 거래일 상태를 rollover하고 LIVE 화면으로 전환합니다.
- 프런트엔드는 서버 캘린더 `/api/screen-state`를 5초 저빈도 probe하여 휴일에는 고빈도 polling을 시작하지 않습니다.
- BUY/FAST_JUMP/RECOVERY/EXIT 임계값은 2.4.9와 동일합니다.



## 2.4.13 — 19:30~19:50 SMART MONEY CLOSE TRUTH 강화

이번 버전은 BUY 임계값을 변경하지 않습니다. 스마트머니 종가창의 정확성과 운영 안전성만 보강합니다.

- **19:15~19:25 CLOSE 전용 확대유니버스**: NXT `stex_tp=2` 공식 순위소스를 KOSPI/KOSDAQ 전체에서 다시 훑어 19:30 직전 관찰 원장을 넓힙니다. 이 스캔 자체는 BUY를 만들지 않습니다.
- **누적 net보다 최근 Δ/slope 우선**: NXT 프로그램·기관의 1분/3분/5분 변화와 방향을 따로 저장합니다. 누적 순매수는 +인데 최근 변화가 -이면 `FLOW_REVERSAL`로 감점하고 `DUAL_CONVICTION`을 막습니다.
- **집중섹터 계산 순서 수정**: TOP10을 먼저 자른 뒤 섹터를 계산하지 않고, 전체 적격후보에서 sector breadth/DUAL/반전 비율을 계산한 뒤 종목 TOP10을 정합니다.
- **08:00 프리마켓 null guard**: 재부팅·재배포 뒤 전일 종가후보의 Candidate가 복원되지 않아도 `c is None`을 먼저 검사해 예외 없이 건너뜁니다.
- **APP_ACCESS_TOKEN 선택 보호**: 설정된 경우 모든 상태변경 `/api/*` POST를 토큰으로 보호합니다. 프런트엔드는 `/api/auth/check`의 `auth_required`를 확인한 경우에만 토큰을 묻습니다. 저장소 Private 전환과 공개 런타임 보호는 별개입니다.

GitHub 저장소를 Private으로 변경해도 이미 실행 중인 Docker 앱에는 영향이 없습니다. 다만 이후 업데이트 스크립트가 Private 저장소에서 ZIP을 받으려면 GitHub 인증(PAT/GITHUB_TOKEN 등)이 필요합니다.

## 2.4.11 — 19:30~19:50 SMART MONEY CROSS-VENUE
- KRX 종가 직전/직후 KRX-only 프로그램·기관 방향과 마지막 KRX 실체결을 동결합니다.
- 19:30~19:50에는 NXT-only 0B·0w·0D, 공격매수, 30/60초 가속, 최근10분 거래량, 고가권 유지와 교차검증합니다.
- 집중섹터 최대 5개와 종목 최대 10개를 표시합니다. 조건 미달이면 10개를 억지로 채우지 않습니다.
- KRX/NXT raw 금액을 직접 더하지 않고 시장별 방향·신선도만 비교합니다. KRX 근거가 없으면 NXT_ONLY로 표시합니다.
- 이 표는 WATCH ONLY이며 기존 BUY 신호/임계값/자동진입 경로를 변경하지 않습니다.
- 19:50 한 번만 요약 Push하며 EOD snapshot에 포함되어 주말·휴일까지 유지됩니다.


## 2.4.15 Adaptive Shadow Load Shed
실시간 점수 p95 또는 dirty queue가 악화되면 연구용 Leave-One-Feature-Out 계산만 FULL→REDUCED→MINIMAL로 축소합니다. 기본 Shadow Score는 계속 기록하며 LIVE 점수·BUY·EXIT·WS·알림은 어떤 모드에서도 변경하지 않습니다. p95 150ms 이하와 dirty queue 30 이하가 60초 지속되면 FULL로 복귀합니다.
