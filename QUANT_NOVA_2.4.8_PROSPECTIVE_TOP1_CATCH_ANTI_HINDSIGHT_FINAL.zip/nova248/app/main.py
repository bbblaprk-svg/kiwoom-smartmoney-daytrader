from __future__ import annotations
import asyncio, json, math, os, time, re, random, hashlib, base64, statistics
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from collections import defaultdict, deque
from bisect import bisect_right
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
import httpx, websockets
from app.evidence_engine import write_report as write_evidence_report
from app.archive_engine import archive_day as archive_data_day, discover_days as discover_archive_days
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_VERSION='NOVA-2.4.8'
KST=ZoneInfo('Asia/Seoul')
BASE=Path(__file__).resolve().parent.parent
DATA_DIR=Path(os.getenv('NOVA_DATA_DIR', str(BASE/'data')))
DATA_DIR.mkdir(parents=True, exist_ok=True)
EVENT_FILE=DATA_DIR/'signal_events.jsonl'
STATE_FILE=DATA_DIR/'performance_state.json'
LEARN_FILE=DATA_DIR/'adaptive_entry_model_v3.json'
TRAIN_FILE=DATA_DIR/'entry_training_events_v3.jsonl'
BUY_SIGNAL_FILE=DATA_DIR/'buy_entry_events_v3.jsonl'
BUY_SIGNAL_STATE=DATA_DIR/'buy_entry_state_v3.json'
WS_CONTRACT_FILE=DATA_DIR/'ws_contract_cache.json'
MARKET_EVENT_FILE=DATA_DIR/'market_events.jsonl'
NXT_ALERT_FILE=DATA_DIR/'nxt_after_alerts.jsonl'
NXT_SECOND_WAVE_FILE=DATA_DIR/'nxt_second_wave_events.jsonl'
NXT_NEXT_DAY_PICK_FILE=DATA_DIR/'nxt_next_day_close_picks.json'
NXT_FIRST_WAVE_MEMORY_FILE=DATA_DIR/'nxt_first_wave_memory.json'
NXT_DAILY_STRONG_LEDGER_FILE=DATA_DIR/'nxt_daily_strong_ledger.json'
MANUAL_POSITION_FILE=DATA_DIR/'manual_position_manager.json'
MANUAL_POSITION_EVENT_FILE=DATA_DIR/'manual_position_events.jsonl'
PUSH_SUB_FILE=DATA_DIR/'push_subscriptions.json'
PUSH_DELIVERY_FILE=DATA_DIR/'push_delivery_events.jsonl'
PROSPECTIVE_OBSERVATION_FILE=DATA_DIR/'prospective_observation_events.jsonl'
VAPID_PRIVATE_FILE=DATA_DIR/'vapid_private.pem'
VAPID_PUBLIC_FILE=DATA_DIR/'vapid_public.txt'
API='https://api.kiwoom.com'
WS='wss://api.kiwoom.com:10000/api/dostk/websocket'
APP_KEY=os.getenv('KIWOOM_APP_KEY','').strip()
SECRET=(os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
DISCOVERY_SECONDS=max(5,int(os.getenv('NOVA_DISCOVERY_SECONDS','8')))
WS_CORE_LIMIT=max(20,min(60,int(os.getenv('NOVA_WS_CORE_LIMIT','40'))))
WS_CHALLENGER_LIMIT=max(10,min(60,int(os.getenv('NOVA_WS_CHALLENGER_LIMIT','40'))))
WS_LIMIT=max(30,min(100,WS_CORE_LIMIT+WS_CHALLENGER_LIMIT))
SOURCE_TTL_SECONDS=max(DISCOVERY_SECONDS*2,int(os.getenv('NOVA_SOURCE_TTL_SECONDS','24')))
CANDIDATE_TTL_SECONDS=max(180,int(os.getenv('NOVA_CANDIDATE_TTL_SECONDS','600')))
MAX_CANDIDATES=max(400,min(5000,int(os.getenv('NOVA_MAX_CANDIDATES','1200'))))
REST_PACE_SECONDS=max(0.20,float(os.getenv('NOVA_REST_PACE_SECONDS','0.225')))
REST_MAX_INFLIGHT=max(2,min(6,int(os.getenv('NOVA_REST_MAX_INFLIGHT','4'))))
# CPU/DISK PERFORMANCE GUARD: coalesce realtime rescoring, throttle persistence, and cap operational logs.
SCORING_COALESCE_MS=max(20,min(250,int(os.getenv('NOVA_SCORING_COALESCE_MS','80'))))
SECTOR_CONTEXT_INTERVAL=max(0.25,float(os.getenv('NOVA_SECTOR_CONTEXT_INTERVAL','0.75')))
PERSIST_INTERVAL_SECONDS=max(30,int(os.getenv('NOVA_PERSIST_INTERVAL_SECONDS','60')))
PERF_GUARD_INTERVAL_SECONDS=max(10,int(os.getenv('NOVA_PERF_GUARD_INTERVAL_SECONDS','30')))
LOG_MAINTENANCE_SECONDS=max(120,int(os.getenv('NOVA_LOG_MAINTENANCE_SECONDS','600')))
OP_LOG_MAX_MB=max(8,int(os.getenv('NOVA_OP_LOG_MAX_MB','32')))
OP_LOG_KEEP_LINES=max(5000,int(os.getenv('NOVA_OP_LOG_KEEP_LINES','50000')))
EVIDENCE_REPORT_FILE=DATA_DIR/'evidence_report.json'
EVIDENCE_REFRESH_SECONDS=max(120,int(os.getenv('NOVA_EVIDENCE_REFRESH_SECONDS','300')))
REPLAY_INTERVAL_SECONDS=max(1.0,min(5.0,float(os.getenv('NOVA_REPLAY_INTERVAL_SECONDS','2.0'))))
REPLAY_QUEUE_MAX=max(1000,min(50000,int(os.getenv('NOVA_REPLAY_QUEUE_MAX','10000'))))
ARCHIVE_REFRESH_SECONDS=max(300,int(os.getenv('NOVA_ARCHIVE_REFRESH_SECONDS','1800')))
ARCHIVE_CLOSE_SECONDS=20*3600+10*60
PROGRAM_HARD_FRESH_SECONDS=max(10,int(os.getenv('NOVA_PROGRAM_HARD_FRESH_SECONDS','25')))
INVESTOR_FRESH_SECONDS=max(20,int(os.getenv('NOVA_INVESTOR_FRESH_SECONDS','45')))
INVESTOR_REFRESH_TARGET_SECONDS=max(10,min(INVESTOR_FRESH_SECONDS-5,int(os.getenv('NOVA_INVESTOR_REFRESH_TARGET_SECONDS','30'))))
PROGRAM_FALLBACK_REFRESH_SECONDS=max(10,min(PROGRAM_HARD_FRESH_SECONDS-3,int(os.getenv('NOVA_PROGRAM_FALLBACK_REFRESH_SECONDS','18'))))
SMART_PROGRAM_FALLBACK_BATCH=max(1,min(6,int(os.getenv('NOVA_SMART_PROGRAM_FALLBACK_BATCH','3'))))
WS_REG_ACK_TIMEOUT=max(2.0,float(os.getenv('NOVA_WS_REG_ACK_TIMEOUT','5')))
WS_REG_MAX_RETRY=max(1,min(4,int(os.getenv('NOVA_WS_REG_MAX_RETRY','2'))))
WS_RECONNECT_BASE=max(0.5,float(os.getenv('NOVA_WS_RECONNECT_BASE','1')))
WS_RECONNECT_MAX=max(5.0,float(os.getenv('NOVA_WS_RECONNECT_MAX','30')))
WS_RECONNECT_JITTER=max(0.0,min(0.5,float(os.getenv('NOVA_WS_RECONNECT_JITTER','0.20'))))
WS_WAKE_START_SECONDS=7*3600+30*60
WS_PREOPEN_RECONNECT_SECONDS=7*3600+55*60
WS_PREOPEN_RECONNECT_END_SECONDS=8*3600
WS_SLEEP_START_SECONDS=20*3600+5*60
WS_WAKE_GUARD_SECONDS=max(5,int(os.getenv('NOVA_WS_WAKE_GUARD_SECONDS','5')))
WS_WAKE_RETRY_END_SECONDS=8*3600+5*60
TICK_SIGNATURE_WINDOW=max(32,min(512,int(os.getenv('NOVA_TICK_SIGNATURE_WINDOW','160'))))
PRICE_JUMP_QUARANTINE_PCT=max(3.0,float(os.getenv('NOVA_PRICE_JUMP_QUARANTINE_PCT','6.0')))
PRICE_HARD_JUMP_PCT=max(8.0,float(os.getenv('NOVA_PRICE_HARD_JUMP_PCT','12.0')))
PRICE_CONFIRM_TOLERANCE_PCT=max(0.5,float(os.getenv('NOVA_PRICE_CONFIRM_TOLERANCE_PCT','1.5')))
PRICE_QUARANTINE_SECONDS=max(1.0,float(os.getenv('NOVA_PRICE_QUARANTINE_SECONDS','3.0')))
PRICE_RATE_MISMATCH_PCT=max(1.0,float(os.getenv('NOVA_PRICE_RATE_MISMATCH_PCT','2.0')))
KRX_CALENDAR_FILE=BASE/'config'/'krx_holidays.json'
KRX_CALENDAR_OVERRIDE=DATA_DIR/'krx_calendar_override.json'
MIN_SCORE=float(os.getenv('NOVA_MIN_SCORE','58'))
FRESH_MS=max(1500,int(os.getenv('NOVA_FRESH_MS','5000')))
DISPLAY_FRESH_MS=max(FRESH_MS,int(os.getenv('NOVA_DISPLAY_FRESH_MS','12000')))
SMART_POLL_SECONDS=max(3,int(os.getenv('NOVA_SMART_POLL_SECONDS','5')))
SMART_POLL_BATCH=max(4,min(16,int(os.getenv('NOVA_SMART_POLL_BATCH','10'))))
LEARN_MIN_SAMPLES=max(30,int(os.getenv('NOVA_LEARN_MIN_SAMPLES','60')))
LEARN_MAX_ADJUST=float(os.getenv('NOVA_LEARN_MAX_ADJUST','0.30'))
SECTOR_MAX_BONUS=max(0.0,min(10.0,float(os.getenv('NOVA_SECTOR_MAX_BONUS','8'))))
# Balanced dual-entry policy.  The goal is not a signal quota: preserve high-quality pullback entries
# while adding a tightly gated DIRECT_IGNITION route for strong names that never offer a clean pullback.
ENTRY_PRESSURE_SCORE=float(os.getenv('NOVA_ENTRY_PRESSURE_SCORE','62'))
ENTRY_HOLD_SEC=max(5,int(os.getenv('NOVA_ENTRY_HOLD_SEC','8')) )
ENTRY_PULLBACK_MIN=float(os.getenv('NOVA_ENTRY_PULLBACK_MIN','0.12'))
ENTRY_PULLBACK_MAX=float(os.getenv('NOVA_ENTRY_PULLBACK_MAX','2.00'))
ENTRY_REACCEL_SEC=max(2,int(os.getenv('NOVA_ENTRY_REACCEL_SEC','3')) )
ENTRY_COOLDOWN_SEC=max(300,int(os.getenv('NOVA_ENTRY_COOLDOWN_SEC','600')) )
ENTRY_REENTRY_MIN_SEC=max(240,int(os.getenv('NOVA_ENTRY_REENTRY_MIN_SEC','420')) )
ENTRY_REENTRY_GAIN_PCT=float(os.getenv('NOVA_ENTRY_REENTRY_GAIN_PCT','1.20'))
ENTRY_MAX_DAILY=max(1,min(2,int(os.getenv('NOVA_ENTRY_MAX_DAILY','2'))))
ENTRY_MAX_VWAP_GAP=float(os.getenv('NOVA_ENTRY_MAX_VWAP_GAP','1.50'))
ENTRY_MAX_IMPULSE=float(os.getenv('NOVA_ENTRY_MAX_IMPULSE','2.50'))
ENTRY_MIN_BUY_PRESSURE=float(os.getenv('NOVA_ENTRY_MIN_BUY_PRESSURE','56'))
ENTRY_MIN_ALGO_PERSIST=float(os.getenv('NOVA_ENTRY_MIN_ALGO_PERSIST','55'))
# Candidate discovery remains broad, but confirmed PULLBACK BUY uses a stricter final gate.
PULLBACK_CONFIRM_SCORE=float(os.getenv('NOVA_PULLBACK_CONFIRM_SCORE','58'))
PULLBACK_CONFIRM_BUY_PRESSURE=float(os.getenv('NOVA_PULLBACK_CONFIRM_BUY_PRESSURE','58'))
PULLBACK_CONFIRM_ACCEL=float(os.getenv('NOVA_PULLBACK_CONFIRM_ACCEL','1.20'))
DIRECT_SCORE=float(os.getenv('NOVA_DIRECT_SCORE','75'))
DIRECT_HOLD_SEC=max(3,int(os.getenv('NOVA_DIRECT_HOLD_SEC','6')) )
DIRECT_CONFIRM_SEC=max(2,int(os.getenv('NOVA_DIRECT_CONFIRM_SEC','3')) )
DIRECT_MIN_BUY_PRESSURE=float(os.getenv('NOVA_DIRECT_MIN_BUY_PRESSURE','61'))
DIRECT_MIN_ALGO_PERSIST=float(os.getenv('NOVA_DIRECT_MIN_ALGO_PERSIST','60'))
DIRECT_MIN_ACCEL=float(os.getenv('NOVA_DIRECT_MIN_ACCEL','1.65'))
DIRECT_MIN_BREAKOUT=float(os.getenv('NOVA_DIRECT_MIN_BREAKOUT','0.20'))
DIRECT_MIN_IMPULSE=float(os.getenv('NOVA_DIRECT_MIN_IMPULSE','0.25'))
DIRECT_MAX_IMPULSE=float(os.getenv('NOVA_DIRECT_MAX_IMPULSE','1.80'))
DIRECT_MAX_VWAP_GAP=float(os.getenv('NOVA_DIRECT_MAX_VWAP_GAP','1.10'))
SECTOR_MAP_FILE=DATA_DIR/'sector_map.json'
SECTOR_OFFICIAL_CACHE_FILE=DATA_DIR/'sector_official_cache.json'
CALIB_ALERT_FILE=DATA_DIR/'model_quality_alerts.jsonl'
CHALLENGER_SMART_LIMIT=max(1,min(20,int(os.getenv('NOVA_CHALLENGER_SMART_LIMIT','10'))))
CHALLENGER_INVESTOR_INTERVAL=max(20,int(os.getenv('NOVA_CHALLENGER_INVESTOR_INTERVAL','30')))
RALLY_EPISODE_GAP_SECONDS=max(600,int(os.getenv('NOVA_RALLY_EPISODE_GAP_SECONDS','1200')))
DNA_EARLY_TRIGGER_MIN_MATCH=max(80.0,float(os.getenv('NOVA_DNA_EARLY_TRIGGER_MIN_MATCH','88')))
DNA_EARLY_TRIGGER_MAX_RELAX=max(0.0,min(5.0,float(os.getenv('NOVA_DNA_EARLY_TRIGGER_MAX_RELAX','3.0'))))
ORDERBOOK_CORE_LIMIT=max(10,min(40,int(os.getenv('NOVA_ORDERBOOK_CORE_LIMIT','30'))))
ORDERBOOK_CHALLENGER_LIMIT=max(0,min(20,int(os.getenv('NOVA_ORDERBOOK_CHALLENGER_LIMIT','10'))))
ORDERBOOK_FRESH_SECONDS=max(1.0,float(os.getenv('NOVA_ORDERBOOK_FRESH_SECONDS','3.0')))
ORDERBOOK_MAX_BONUS=max(0.0,min(8.0,float(os.getenv('NOVA_ORDERBOOK_MAX_BONUS','6.0'))))
ORDERBOOK_WALL_RATIO=max(1.4,float(os.getenv('NOVA_ORDERBOOK_WALL_RATIO','2.2')))
ORDERBOOK_WALL_PERSIST_SECONDS=max(1.0,float(os.getenv('NOVA_ORDERBOOK_WALL_PERSIST_SECONDS','3.0')))
ORDERBOOK_WALL_V2_MAX_BONUS=max(0.5,min(4.0,float(os.getenv('NOVA_ORDERBOOK_WALL_V2_MAX_BONUS','2.5'))))
ORDERBOOK_WALL_CANCEL_DROP=max(0.4,min(0.9,float(os.getenv('NOVA_ORDERBOOK_WALL_CANCEL_DROP','0.65'))))
WS_CONTRACT_PROBE_SECONDS=max(1.5,min(8.0,float(os.getenv('NOVA_WS_CONTRACT_PROBE_SECONDS','3.0'))))
WS_CONTRACT_REPROBE_SECONDS=max(300,int(os.getenv('NOVA_WS_CONTRACT_REPROBE_SECONDS','3600')))
DART_API_KEY=os.getenv('DART_API_KEY','').strip()
NEWS_RSS_URLS=[x.strip() for x in re.split(r'[;,\n]+',os.getenv('NOVA_NEWS_RSS_URLS','')) if x.strip()]
MARKET_EVENT_POLL_SECONDS=max(30,int(os.getenv('NOVA_MARKET_EVENT_POLL_SECONDS','60')))
MARKET_EVENT_TTL_SECONDS=max(300,int(os.getenv('NOVA_MARKET_EVENT_TTL_SECONDS','1800')))
MARKET_EVENT_MAX_BONUS=max(0.0,min(6.0,float(os.getenv('NOVA_MARKET_EVENT_MAX_BONUS','4.0'))))
# NXT after-market early radar. 15:40-20:00 is treated as a separate discovery regime:
# use NXT-only ranking sources, preserve late rallies for audit, and alert before the move becomes chase-only.
NXT_AFTER_DISCOVERY_SECONDS=max(4,int(os.getenv('NOVA_NXT_AFTER_DISCOVERY_SECONDS','5')))
NXT_EARLY_MAX_RATE=float(os.getenv('NOVA_NXT_EARLY_MAX_RATE','5.0'))
NXT_PRE_MAX_RATE=float(os.getenv('NOVA_NXT_PRE_MAX_RATE','7.5'))
NXT_IGNITION_MAX_RATE=float(os.getenv('NOVA_NXT_IGNITION_MAX_RATE','9.5'))
NXT_LATE_RATE=float(os.getenv('NOVA_NXT_LATE_RATE','10.0'))
NXT_ALERT_COOLDOWN=max(30,int(os.getenv('NOVA_NXT_ALERT_COOLDOWN','180')))
NXT_RADAR_TOP=max(10,min(60,int(os.getenv('NOVA_NXT_RADAR_TOP','30'))))
# Record every stage in the in-app ledger, but push only actionable promotions.
NXT_RADAR_STAGE_RANK={'EARLY_WATCH':1,'PRE_IGNITION':2,'PREMARKET_CONFIRM':3,'EMERGENCY_IGNITION':4,'IGNITION':5,'LATE_RALLY':6}
NXT_FAST_STAGE_RANK={'FAST_JUMP_WATCH':1,'FAST_JUMP_READY':2}
NXT_SECOND_STAGE_RANK={'SECOND_WAVE_BASE':1,'SECOND_WAVE_READY':2,'SECOND_WAVE_BUY':3}
NXT_RECOVERY_STAGE_RANK={'RECOVERY_EARLY':1,'RECOVERY_READY':2,'RECOVERY_BUY':3}
NXT_PUSH_STAGES=frozenset({'PRE_IGNITION','PREMARKET_CONFIRM','EMERGENCY_IGNITION','IGNITION','FAST_JUMP_WATCH','FAST_JUMP_READY','SECOND_WAVE_READY','SECOND_WAVE_BUY','RECOVERY_EARLY','RECOVERY_READY','RECOVERY_BUY','CLOSE_BET_READY','CLOSE_BET_BUY','CLOSE_BET_SIGNAL','MORNING_CLOSE_PICKS'})
# NXT fast/second-wave/morning continuation policy.
NXT_FASTEST_DISCOVERY_SECONDS=max(2,int(os.getenv('NOVA_NXT_FASTEST_DISCOVERY_SECONDS','3')))
NXT_PREMARKET_DISCOVERY_SECONDS=max(3,int(os.getenv('NOVA_NXT_PREMARKET_DISCOVERY_SECONDS','4')))
# 09:00~15:20에도 통합순위와 별도로 NXT-only 핵심 레이더를 병행한다.
NXT_ALLDAY_DISCOVERY_SECONDS=max(4,int(os.getenv('NOVA_NXT_ALLDAY_DISCOVERY_SECONDS','5')))
NXT_ALLDAY_INTEGRATED_EVERY=max(2,min(5,int(os.getenv('NOVA_NXT_ALLDAY_INTEGRATED_EVERY','2'))))
NXT_FAST_REST_TIMEOUT=max(1.0,min(4.0,float(os.getenv('NOVA_NXT_FAST_REST_TIMEOUT','2.7'))))
NXT_SLOW_CONTEXT_SECONDS=max(8,int(os.getenv('NOVA_NXT_SLOW_CONTEXT_SECONDS','15')))
NXT_BURST_WATCH_LIMIT=max(5,min(25,int(os.getenv('NOVA_NXT_BURST_WATCH_LIMIT','20'))))
NXT_BURST_HIGHRES_LIMIT=max(3,min(12,int(os.getenv('NOVA_NXT_BURST_HIGHRES_LIMIT','8'))))
NXT_WS_EMERGENCY_ACCEL30=float(os.getenv('NOVA_NXT_WS_EMERGENCY_ACCEL30','2.20'))
NXT_WS_EMERGENCY_ACCEL60=float(os.getenv('NOVA_NXT_WS_EMERGENCY_ACCEL60','1.70'))
NXT_WS_EMERGENCY_BUY_PRESSURE=float(os.getenv('NOVA_NXT_WS_EMERGENCY_BUY_PRESSURE','62'))
NXT_WS_EMERGENCY_MAX_RATE=float(os.getenv('NOVA_NXT_WS_EMERGENCY_MAX_RATE','9.5'))
NXT_WS_EMERGENCY_COOLDOWN=max(30,int(os.getenv('NOVA_NXT_WS_EMERGENCY_COOLDOWN','90')))
# Prospective high-volatility observation layer. FAST_JUMP never becomes BUY directly.
NXT_FAST_JUMP_MIN_RATE=float(os.getenv('NOVA_NXT_FAST_JUMP_MIN_RATE','8.0'))
NXT_FAST_JUMP_MAX_RATE=float(os.getenv('NOVA_NXT_FAST_JUMP_MAX_RATE','15.0'))
NXT_FAST_JUMP_READY_HOLD_SECONDS=max(10,int(os.getenv('NOVA_NXT_FAST_JUMP_READY_HOLD_SECONDS','20')))
NXT_FAST_JUMP_MIN_BP=float(os.getenv('NOVA_NXT_FAST_JUMP_MIN_BP','60'))
NXT_FAST_JUMP_MIN_ALGO=float(os.getenv('NOVA_NXT_FAST_JUMP_MIN_ALGO','58'))
NXT_FAST_JUMP_MIN_ACCEL30=float(os.getenv('NOVA_NXT_FAST_JUMP_MIN_ACCEL30','1.70'))
NXT_FAST_JUMP_MIN_ACCEL60=float(os.getenv('NOVA_NXT_FAST_JUMP_MIN_ACCEL60','1.30'))
NXT_FAST_JUMP_WATCH_PERCENTILE=float(os.getenv('NOVA_NXT_FAST_JUMP_WATCH_PERCENTILE','95'))
NXT_FAST_JUMP_READY_PERCENTILE=float(os.getenv('NOVA_NXT_FAST_JUMP_READY_PERCENTILE','99'))
NXT_FAST_JUMP_READY_MIN_POPULATION=max(10,int(os.getenv('NOVA_NXT_FAST_JUMP_READY_MIN_POPULATION','20')))
# A genuine 1% cross-sectional label needs at least 100 simultaneous observations; smaller pools remain WATCH/READY but never claim TOP1.
NXT_TOP1_MIN_POPULATION=max(100,int(os.getenv('NOVA_NXT_TOP1_MIN_POPULATION','100')))
WS_LIMIT=max(WS_LIMIT,min(100,WS_CORE_LIMIT+WS_CHALLENGER_LIMIT+NXT_BURST_WATCH_LIMIT))
NXT_BURST_TTL_SECONDS=max(45,int(os.getenv('NOVA_NXT_BURST_TTL_SECONDS','90')))
NXT_SECOND_WAVE_MEMORY_SECONDS=max(3600,int(os.getenv('NOVA_NXT_SECOND_WAVE_MEMORY_SECONDS','18000')))
NXT_SECOND_WAVE_POOL_LIMIT=max(8,min(30,int(os.getenv('NOVA_NXT_SECOND_WAVE_POOL_LIMIT','20'))))
NXT_MEMORY_BAR_KEEP_MINUTES=max(240,min(360,int(os.getenv('NOVA_NXT_MEMORY_BAR_KEEP_MINUTES','300'))))
NXT_SECOND_WAVE_MIN_PEAK_RATE=float(os.getenv('NOVA_NXT_SECOND_WAVE_MIN_PEAK_RATE','5.0'))
NXT_SECOND_WAVE_MIN_PULLBACK=float(os.getenv('NOVA_NXT_SECOND_WAVE_MIN_PULLBACK','3.0'))
NXT_SECOND_WAVE_MAX_PULLBACK=float(os.getenv('NOVA_NXT_SECOND_WAVE_MAX_PULLBACK','10.0'))
NXT_SECOND_WAVE_BASE_MIN_SECONDS=max(240,int(os.getenv('NOVA_NXT_SECOND_WAVE_BASE_MIN_SECONDS','360')))
NXT_SECOND_WAVE_BASE_MAX_SECONDS=max(NXT_SECOND_WAVE_BASE_MIN_SECONDS+120,int(os.getenv('NOVA_NXT_SECOND_WAVE_BASE_MAX_SECONDS','1200')))
NXT_SECOND_WAVE_MAX_RANGE=float(os.getenv('NOVA_NXT_SECOND_WAVE_MAX_RANGE','1.35'))
NXT_SECOND_WAVE_MAX_DRYUP=float(os.getenv('NOVA_NXT_SECOND_WAVE_MAX_DRYUP','0.45'))
NXT_SECOND_WAVE_READY_ACCEL30=float(os.getenv('NOVA_NXT_SECOND_WAVE_READY_ACCEL30','1.45'))
NXT_SECOND_WAVE_READY_ACCEL60=float(os.getenv('NOVA_NXT_SECOND_WAVE_READY_ACCEL60','1.25'))
NXT_SECOND_WAVE_BUY_ACCEL30=float(os.getenv('NOVA_NXT_SECOND_WAVE_BUY_ACCEL30','1.70'))
NXT_SECOND_WAVE_BUY_ACCEL60=float(os.getenv('NOVA_NXT_SECOND_WAVE_BUY_ACCEL60','1.40'))
NXT_SECOND_WAVE_BREAKOUT=float(os.getenv('NOVA_NXT_SECOND_WAVE_BREAKOUT','0.18'))
NXT_SECOND_WAVE_MAX_ENTRY_RATE=float(os.getenv('NOVA_NXT_SECOND_WAVE_MAX_ENTRY_RATE','12.0'))
# Long-recovery route: catches a first-wave surge that pulls back for tens of minutes to ~5h and then
# rebuilds toward the prior NXT peak (e.g. a 16:00 surge -> 18:30~19:00 shakeout -> 19:30~19:50 recovery).
NXT_RECOVERY_MIN_PULLBACK=float(os.getenv('NOVA_NXT_RECOVERY_MIN_PULLBACK','4.0'))
NXT_RECOVERY_MAX_PULLBACK=float(os.getenv('NOVA_NXT_RECOVERY_MAX_PULLBACK','15.0'))
NXT_RECOVERY_MIN_PEAK_AGE_SECONDS=max(600,int(os.getenv('NOVA_NXT_RECOVERY_MIN_PEAK_AGE_SECONDS','900')))
NXT_RECOVERY_MAX_PEAK_AGE_SECONDS=max(NXT_RECOVERY_MIN_PEAK_AGE_SECONDS+600,int(os.getenv('NOVA_NXT_RECOVERY_MAX_PEAK_AGE_SECONDS','18000')))
NXT_RECOVERY_MIN_TROUGH_AGE_SECONDS=max(60,int(os.getenv('NOVA_NXT_RECOVERY_MIN_TROUGH_AGE_SECONDS','120')))
NXT_RECOVERY_EARLY_RATIO=float(os.getenv('NOVA_NXT_RECOVERY_EARLY_RATIO','0.30'))
NXT_RECOVERY_EARLY_TROUGH_AGE_SECONDS=max(45,int(os.getenv('NOVA_NXT_RECOVERY_EARLY_TROUGH_AGE_SECONDS','60')))
NXT_RECOVERY_READY_RATIO=float(os.getenv('NOVA_NXT_RECOVERY_READY_RATIO','0.50'))
NXT_RECOVERY_BUY_RATIO=float(os.getenv('NOVA_NXT_RECOVERY_BUY_RATIO','0.68'))
NXT_RECOVERY_READY_BP=float(os.getenv('NOVA_NXT_RECOVERY_READY_BP','55'))
NXT_RECOVERY_BUY_BP=float(os.getenv('NOVA_NXT_RECOVERY_BUY_BP','58'))
NXT_RECOVERY_READY_ALGO=float(os.getenv('NOVA_NXT_RECOVERY_READY_ALGO','54'))
NXT_RECOVERY_BUY_ALGO=float(os.getenv('NOVA_NXT_RECOVERY_BUY_ALGO','58'))
NXT_RECOVERY_READY_PEAK_GAP=float(os.getenv('NOVA_NXT_RECOVERY_READY_PEAK_GAP','5.0'))
NXT_RECOVERY_BUY_PEAK_GAP=float(os.getenv('NOVA_NXT_RECOVERY_BUY_PEAK_GAP','3.5'))
NXT_RECOVERY_MAX_ENTRY_RATE=float(os.getenv('NOVA_NXT_RECOVERY_MAX_ENTRY_RATE','18.5'))
NXT_CLOSE_PICK_LIMIT=max(5,min(20,int(os.getenv('NOVA_NXT_CLOSE_PICK_LIMIT','12'))))
NXT_CLOSE_PICK_MIN_SCORE=float(os.getenv('NOVA_NXT_CLOSE_PICK_MIN_SCORE','52'))
NXT_CLOSE_BET_READY_SCORE=float(os.getenv('NOVA_NXT_CLOSE_BET_READY_SCORE','64'))
NXT_CLOSE_BET_BUY_SCORE=float(os.getenv('NOVA_NXT_CLOSE_BET_BUY_SCORE','74'))
NXT_CLOSE_BET_LIMIT=max(1,min(5,int(os.getenv('NOVA_NXT_CLOSE_BET_LIMIT','5'))))
# Close-bet is a sustained-strength window, not a single 19:50 snapshot.
NXT_CLOSE_BET_WINDOW_START_SECONDS=19*3600+30*60
NXT_CLOSE_BET_WINDOW_END_SECONDS=19*3600+50*60
NXT_CLOSE_BET_READY_HOLD_SECONDS=max(30,int(os.getenv('NOVA_NXT_CLOSE_BET_READY_HOLD_SECONDS','45')))
NXT_CLOSE_BET_BUY_HOLD_SECONDS=max(NXT_CLOSE_BET_READY_HOLD_SECONDS,int(os.getenv('NOVA_NXT_CLOSE_BET_BUY_HOLD_SECONDS','90')))
NXT_BIG_BUY_NOTIONAL=max(10_000_000,float(os.getenv('NOVA_NXT_BIG_BUY_NOTIONAL','100000000')))
NXT_MORNING_LIST_SECONDS=7*3600+50*60
NXT_MORNING_PUSH_END_SECONDS=9*3600

# Rally DNA: only completed sessions teach the next session. Intraday traces are compact
# snapshots of the information that was available at that moment; labels are assigned after close.
RALLY_MODEL_FILE=DATA_DIR/'rally_dna_model.json'
RALLY_SAMPLE_FILE=DATA_DIR/'rally_dna_samples.jsonl'
RALLY_REVIEW_FILE=DATA_DIR/'rally_daily_review.json'
RALLY_TEACHER_AUDIT_FILE=DATA_DIR/'rally_teacher_universe_audit.json'
RALLY_TRACE_INTERVAL=max(30,int(os.getenv('NOVA_RALLY_TRACE_INTERVAL','60')))
RALLY_TRACE_TOP=max(80,min(300,int(os.getenv('NOVA_RALLY_TRACE_TOP','220'))))
RALLY_MIN_SAMPLES=max(12,int(os.getenv('NOVA_RALLY_MIN_SAMPLES','30')))
RALLY_MAX_BONUS=max(0.0,min(10.0,float(os.getenv('NOVA_RALLY_MAX_BONUS','8'))))
RALLY_MAX_PENALTY=max(0.0,min(8.0,float(os.getenv('NOVA_RALLY_MAX_PENALTY','6'))))
RALLY_TRIGGER_RATE=float(os.getenv('NOVA_RALLY_TRIGGER_RATE','5.0'))
RALLY_TARGET_RATE=float(os.getenv('NOVA_RALLY_TARGET_RATE','10.0'))
RALLY_TRACE_KEEP_DAYS=max(5,int(os.getenv('NOVA_RALLY_TRACE_KEEP_DAYS','20')))
RALLY_SAMPLE_KEEP=max(1000,int(os.getenv('NOVA_RALLY_SAMPLE_KEEP','5000')))
RALLY_SAMPLE_COMPACT_TRIGGER=max(RALLY_SAMPLE_KEEP+500,int(os.getenv('NOVA_RALLY_SAMPLE_COMPACT_TRIGGER','6500')))
RALLY_CAL_MIN_OOS=max(20,int(os.getenv('NOVA_RALLY_CAL_MIN_OOS','40')))
RALLY_FEATURES=['volume_accel','buy_pressure','algo_persistence','impulse','vwap_gap','micro_breakout','compression','dual_venue','program_delta','trust_delta','pension_delta','institution_delta','sector','overlap','orderbook','event_signal']

# Exit DNA: virtual position-management intelligence. It never sends broker orders; it emits
# HOLD / ADD_ON_CANDIDATE / PROTECT / PARTIAL_EXIT / FULL_EXIT recommendations and learns
# MFE giveback / flow-reversal patterns only after the session, effective from the next day.
EXIT_MODEL_FILE=DATA_DIR/'exit_dna_model.json'
EXIT_SAMPLE_FILE=DATA_DIR/'exit_dna_samples.jsonl'
EXIT_REVIEW_FILE=DATA_DIR/'exit_daily_review.json'
EXIT_POSITION_FILE=DATA_DIR/'exit_position_state.json'
EXIT_ACTION_FILE=DATA_DIR/'exit_actions.jsonl'
EXIT_TRACE_KEEP_DAYS=max(5,int(os.getenv('NOVA_EXIT_TRACE_KEEP_DAYS','20')))
EXIT_SAMPLE_KEEP=max(1000,int(os.getenv('NOVA_EXIT_SAMPLE_KEEP','5000')))
EXIT_SAMPLE_COMPACT_TRIGGER=max(EXIT_SAMPLE_KEEP+500,int(os.getenv('NOVA_EXIT_SAMPLE_COMPACT_TRIGGER','6500')))
EXIT_MIN_SAMPLES=max(20,int(os.getenv('NOVA_EXIT_MIN_SAMPLES','40')))
EXIT_CAL_MIN_OOS=max(20,int(os.getenv('NOVA_EXIT_CAL_MIN_OOS','40')))
EXIT_TRACE_INTERVAL=max(30,int(os.getenv('NOVA_EXIT_TRACE_INTERVAL','60')))
EXIT_FEATURES=['giveback','mfe','current_return','score_drop','buy_pressure_fade','algo_fade','vwap_break','program_reversal','sector_weak','breakout_fade','impulse_fade']
EXIT_STOP_MIN=float(os.getenv('NOVA_EXIT_STOP_MIN','1.8'))
EXIT_STOP_MAX=float(os.getenv('NOVA_EXIT_STOP_MAX','3.5'))
EXIT_PROTECT_MFE2=float(os.getenv('NOVA_EXIT_PROTECT_MFE2','0.5'))
EXIT_PROTECT_MFE4=float(os.getenv('NOVA_EXIT_PROTECT_MFE4','1.5'))
EXIT_PROTECT_MFE7=float(os.getenv('NOVA_EXIT_PROTECT_MFE7','3.0'))
EXIT_ADD_MIN_RETURN=float(os.getenv('NOVA_EXIT_ADD_MIN_RETURN','0.5'))
EXIT_ADD_MAX_RETURN=float(os.getenv('NOVA_EXIT_ADD_MAX_RETURN','2.5'))

# Manual position manager: a user-confirmed buy is tracked separately from NOVA's virtual BUY.
# It never submits broker orders. It turns live KRX/NXT ticks into staged sell guidance and waits
# for the user to confirm actual partial/full executions so remaining-position math stays truthful.
MANUAL_SCALP_TP1=float(os.getenv('NOVA_MANUAL_SCALP_TP1','3.0'))
MANUAL_SCALP_TP1_PCT=float(os.getenv('NOVA_MANUAL_SCALP_TP1_PCT','30'))
MANUAL_SCALP_TP2=float(os.getenv('NOVA_MANUAL_SCALP_TP2','5.5'))
MANUAL_SCALP_TP2_PCT=float(os.getenv('NOVA_MANUAL_SCALP_TP2_PCT','30'))
MANUAL_SCALP_STOP_MIN=float(os.getenv('NOVA_MANUAL_SCALP_STOP_MIN','2.2'))
MANUAL_SCALP_STOP_MAX=float(os.getenv('NOVA_MANUAL_SCALP_STOP_MAX','3.5'))
MANUAL_SCALP_FADE_CONFIRM=max(4,int(os.getenv('NOVA_MANUAL_SCALP_FADE_CONFIRM','8')))
MANUAL_SWING_TP1=float(os.getenv('NOVA_MANUAL_SWING_TP1','8.0'))
MANUAL_SWING_TP1_PCT=float(os.getenv('NOVA_MANUAL_SWING_TP1_PCT','25'))
MANUAL_SWING_TP2=float(os.getenv('NOVA_MANUAL_SWING_TP2','15.0'))
MANUAL_SWING_TP2_PCT=float(os.getenv('NOVA_MANUAL_SWING_TP2_PCT','25'))
MANUAL_SWING_STOP=float(os.getenv('NOVA_MANUAL_SWING_STOP','6.0'))
MANUAL_SWING_FADE_CONFIRM=max(15,int(os.getenv('NOVA_MANUAL_SWING_FADE_CONFIRM','30')))
MANUAL_SIGNAL_PUSH_COOLDOWN=max(60,int(os.getenv('NOVA_MANUAL_SIGNAL_PUSH_COOLDOWN','300')))

# Sector membership may be overridden by data/sector_map.json {"005930":"반도체",...}.
# The score itself is NEVER static: breadth/momentum/leader-follow diffusion are recomputed from live candidates.
SECTOR_RULES=[
 ('반도체',('반도체','삼성전자','하이닉스','DB하이텍','HPSP','원익IPS','테스','피에스케이','유진테크','하나마이크론','테크윙','이오테크닉스','주성엔지니어링','한미반도체','ISC','리노공업','가온칩스','에이디테크놀로지','오픈엣지')),
 ('로봇·자동화',('로보','로봇','레인보우','뉴로메카','두산로보틱스','에스피지','에스비비','유일로보틱스','티로보틱스','클로봇','하이젠알앤엠')),
 ('전력·전선·그리드',('전기','전선','일진전기','제룡','효성중공업','HD현대일렉트릭','LS ELECTRIC','LS에코','가온전선','대원전선','산일전기')),
 ('2차전지·ESS',('에코프로','포스코퓨처엠','엘앤에프','천보','대주전자재료','나노신소재','솔브레인','엔켐','동화기업','후성','2차전지','배터리','전고체','ESS')),
 ('방산·항공우주',('한화에어로','현대로템','LIG넥스원','한국항공우주','풍산','퍼스텍','SNT다이내믹스','우주','항공','방산')),
 ('조선·해양',('HD현대중공업','한화오션','삼성중공업','HD한국조선해양','HD현대미포','세진중공업','성광벤드','태광','조선','해양')),
 ('바이오·의료',('바이오','제약','헬스','셀트리온','유한양행','리가켐','알테오젠','에이비엘','펩트론','루닛','뷰노','메디','덴티','클래시스')),
 ('AI·소프트웨어',('AI','인공지능','소프트','더존','한글과컴퓨터','폴라리스','마음AI','솔트룩스','코난테크','플리토','엠로','NAVER','카카오')),
 ('자동차·자율주행',('현대차','기아','현대모비스','HL만도','에스엘','화신','성우하이텍','자동차','자율주행','모트렉스','스마트레이더','퓨런티어')),
 ('화학·소재',('케미칼','화학','소재','금양','코스모','롯데케미칼','금호석유','효성첨단소재','OCI','한솔케미칼','PI첨단소재')),
 ('원전·에너지',('두산에너빌리티','한전기술','한전KPS','우진','우리기술','비에이치아이','원전','원자력','태양광','풍력','에너지')),
 ('건설·인프라',('건설','건설기계','대우건설','현대건설','GS건설','DL이앤씨','HDC현대산업','두산밥캣','HD현대인프라코어')),
 ('금융·증권',('증권','금융','은행','보험','미래에셋','키움증권','한국금융','삼성증권','NH투자','KB금융','신한지주','하나금융')),
 ('소비·뷰티',('화장품','뷰티','아모레','LG생활건강','에이피알','실리콘투','브이티','클리오','코스맥스','한국콜마')),
]
ETF_PREFIX=('KODEX','TIGER','ACE ','RISE ','SOL ','HANARO','KOSEF','KBSTAR','PLUS ','TIMEFOLIO')

def is_fund_like_name(name:str)->bool:
    n=str(name or '').upper().replace('㈜','').strip()
    if not n:return False
    return any(n.startswith(x) for x in ETF_PREFIX) or bool(re.search(r'(^|\s)(ETF|ETN)(\s|$)',n))

def num(x, d=0.0):
    try:
        s=str(x).strip().replace(',','')
        if not s:return d
        return float(s)
    except Exception:return d

def code6(x):
    s=str(x or '').strip().upper().replace('_NX','').replace('_AL','')
    m=re.search(r'(\d{6})',s)
    return m.group(1) if m else ''

def clamp(x,a=0,b=100): return max(a,min(b,x))
def now_kst(): return datetime.now(KST).strftime('%Y-%m-%d %H:%M:%S')
def hmss(): return datetime.now(KST).strftime('%H:%M:%S')
def today_kst(): return datetime.now(KST).strftime('%Y%m%d')
def fmt_kst(ts, fmt='%Y-%m-%d %H:%M:%S'):
    return datetime.fromtimestamp(float(ts), KST).strftime(fmt) if ts else None
def kst_seconds():
    t=datetime.now(KST); return t.hour*3600+t.minute*60+t.second

def between(sec, a, b): return a <= sec < b

def realtime_runtime_awake():
    """High-frequency runtime window: wake before NXT premarket, sleep after final persistence window."""
    return bool(is_krx_trading_day() and between(kst_seconds(),WS_WAKE_START_SECONDS,WS_SLEEP_START_SECONDS))

def ws_wake_guard_active():
    return bool(is_krx_trading_day() and between(kst_seconds(),WS_WAKE_START_SECONDS,WS_WAKE_RETRY_END_SECONDS))

_CALENDAR_CACHE={'mtime':None,'holidays':set(),'special_sessions':{},'source':'weekend-only fallback','error':''}
def _load_krx_calendar():
    """Load packaged KRX holiday truth plus an optional persistent override.

    The override is deliberately data-driven so an extraordinary/temporary KRX closure can be
    added without rebuilding the image.  Format: {"holidays":["YYYYMMDD"],
    "open_days":[...], "special_sessions":{"YYYYMMDD":{"krx_open":"10:00",...}}}.
    """
    files=[x for x in (KRX_CALENDAR_FILE,KRX_CALENDAR_OVERRIDE) if x.exists()]
    stamp=tuple((str(x),x.stat().st_mtime_ns) for x in files)
    if _CALENDAR_CACHE.get('mtime')==stamp:return _CALENDAR_CACHE
    holidays=set();open_days=set();special={};sources=[];errors=[];covered_years=set()
    for path in files:
        try:
            d=json.loads(path.read_text(encoding='utf-8'))
            raw=d.get('holidays') or []
            if isinstance(raw,dict):
                covered_years.update(str(y) for y in raw.keys())
                for arr in raw.values():
                    if isinstance(arr,list):holidays.update(str(x).replace('-','') for x in arr)
            elif isinstance(raw,list):holidays.update(str(x).replace('-','') for x in raw)
            open_days.update(str(x).replace('-','') for x in (d.get('open_days') or []))
            for day,row in (d.get('special_sessions') or {}).items():
                if isinstance(row,dict):special[str(day).replace('-','')]=row
            sources.append(str(path))
        except Exception as e:errors.append(f'{path.name}:{e}')
    holidays.difference_update(open_days)
    current_year=datetime.now(KST).strftime('%Y'); calendar_stale=current_year not in covered_years
    _CALENDAR_CACHE.update({'mtime':stamp,'holidays':holidays,'open_days':open_days,'special_sessions':special,'covered_years':sorted(covered_years),'calendar_stale':calendar_stale,'source':'+'.join(sources) if sources else 'weekend-only fallback','error':'; '.join(errors)[:240]})
    return _CALENDAR_CACHE

def is_krx_trading_day(day:str|None=None):
    ds=str(day or today_kst()).replace('-','')
    try:d=datetime.strptime(ds,'%Y%m%d')
    except Exception:return False
    cal=_load_krx_calendar()
    if ds in cal.get('open_days',set()):return True
    return d.weekday()<5 and ds not in cal.get('holidays',set())

def _hm_to_sec(x:str, default:int):
    try:
        hh,mm=[int(v) for v in str(x).split(':')[:2]];return hh*3600+mm*60
    except Exception:return default

def market_session():
    """Calendar-aware KRX/NXT operational session truth.

    Weekends, public/KRX holidays and persistent emergency overrides fail closed.  A special
    session override can change open/close times without a new image build.
    """
    s=kst_seconds();day=today_kst();cal=_load_krx_calendar();trading_day=is_krx_trading_day(day)
    if not trading_day:
        return {'krx':False,'nxt':False,'active':False,'phase':'MARKET CLOSED · HOLIDAY/WEEKEND','kst':hmss(),'trading_day':False,'calendar_source':cal.get('source'),'calendar_error':cal.get('error'),'calendar_stale':bool(cal.get('calendar_stale')),'calendar_years':cal.get('covered_years',[])}
    sp=(cal.get('special_sessions') or {}).get(day) or {}
    krx_open=_hm_to_sec(sp.get('krx_open','09:00'),9*3600);krx_close=_hm_to_sec(sp.get('krx_close','15:30'),15*3600+30*60)
    krx=between(s,krx_open,krx_close)
    # NXT windows retain the production-validated schedule unless an override explicitly closes NXT.
    nxt_enabled=not bool(sp.get('nxt_closed',False))
    nxt=nxt_enabled and (between(s,8*3600,8*3600+50*60) or between(s,9*3600+30,15*3600+20*60) or between(s,15*3600+40*60,20*3600))
    if krx and nxt: phase='KRX+NXT LIVE'
    elif krx: phase='KRX LIVE'
    elif nxt: phase='NXT LIVE'
    elif s < 8*3600: phase='PRE-MARKET'
    elif s >= 20*3600: phase='MARKET CLOSED'
    else: phase='SESSION GAP'
    return {'krx':krx,'nxt':nxt,'active':krx or nxt,'phase':phase,'kst':hmss(),'trading_day':True,'calendar_source':cal.get('source'),'calendar_error':cal.get('error'),'calendar_stale':bool(cal.get('calendar_stale')),'calendar_years':cal.get('covered_years',[]),'special_session':sp or None}

def discovery_window_active():
    if not is_krx_trading_day():return False
    s=kst_seconds();return between(s,7*3600+50*60,20*3600+5*60)

def nxt_after_session_active():
    if not is_krx_trading_day():return False
    s=kst_seconds();sess=market_session()
    return bool(sess.get('nxt') and not sess.get('krx') and between(s,15*3600+40*60,20*3600))

def nxt_premarket_session_active():
    if not is_krx_trading_day():return False
    s=kst_seconds();sess=market_session()
    return bool(sess.get('nxt') and not sess.get('krx') and between(s,8*3600,8*3600+50*60))

def nxt_fastest_window_active():
    if not is_krx_trading_day():return False
    s=kst_seconds()
    return bool(between(s,15*3600+40*60,16*3600+30*60))

def nxt_regular_session_active():
    """NXT와 KRX가 함께 열려 있는 09:00:30~15:20 동시거래 구간."""
    if not is_krx_trading_day():return False
    s=kst_seconds();sess=market_session()
    return bool(sess.get('nxt') and sess.get('krx') and between(s,9*3600+30,15*3600+20*60))

def nxt_radar_session_active():
    # NXT가 실제 거래 중이면 프리/정규동시/애프터를 모두 조기탐지 대상으로 본다.
    return nxt_after_session_active() or nxt_premarket_session_active() or nxt_regular_session_active()

STAGE_RANK={'SEED':0,'WATCH':1,'PRESSURE':2,'IGNITION':3,'BUY':4}
ENTRY_STATES=('DISCOVERY','PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM','BUY','COOLDOWN','REJECTED')

@dataclass
class Tick:
    ts: float; price: float; qty: float; rate: float; venue: str; cumvol: float=0; turnover: float=0

@dataclass
class Capture:
    stage: str
    at: float
    price: float
    score: float
    venue: str
    current_price: float=0
    current_return: float=0
    max_price: float=0
    max_return: float=0
    min_price: float=0
    min_return: float=0
    features: dict[str,float]=field(default_factory=dict)

@dataclass
class Candidate:
    code: str
    name: str=''
    sector: str=''
    sector_source: str=''
    source_hits: dict[str,float]=field(default_factory=dict)
    source_last_seen: dict[str,float]=field(default_factory=dict)
    source_scan_id: int=0
    source_prev_base: float=0
    source_velocity: float=0
    ws_tier: str=''
    ticks: deque=field(default_factory=lambda:deque(maxlen=1500))
    last_price: float=0
    rate: float=0
    venue: str=''
    last_fid9081: str=''
    last_tick_at: float=0
    last_price_source: str=''
    last_price_by_venue: dict[str,float]=field(default_factory=dict)
    last_rate_by_venue: dict[str,float]=field(default_factory=dict)
    last_tick_at_by_venue: dict[str,float]=field(default_factory=dict)
    last_fid9081_by_venue: dict[str,str]=field(default_factory=dict)
    first_seen: float=field(default_factory=time.time)
    score: float=0
    confidence: float=0
    stage: str='SEED'
    reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict)
    captures: dict[str,Capture]=field(default_factory=dict)
    highest_stage: str='SEED'
    smart: dict[str,Any]=field(default_factory=dict)
    smart_by_venue: dict[str,dict[str,Any]]=field(default_factory=dict)
    smart_updated_at: float=0
    investor_updated_at: float=0
    investor_updated_at_by_venue: dict[str,float]=field(default_factory=dict)
    program_updated_at: float=0
    program_updated_at_by_venue: dict[str,float]=field(default_factory=dict)
    program_rt_at: float=0
    program_rt_at_by_venue: dict[str,float]=field(default_factory=dict)
    program_rt_samples: int=0
    program_rt_raw: dict[str,Any]=field(default_factory=dict)
    session_day: str=''
    session_pv: float=0
    session_vv: float=0
    previous_stage: str='SEED'
    signal_count: int=0
    signal_count_today: int=0
    first_signal_at: float=0
    last_signal_at: float=0
    last_signal_price: float=0
    last_signal_score: float=0
    last_signal_stage: str=''
    last_signal_venue: str=''
    last_signal_reasons: list[str]=field(default_factory=list)
    signal_max_price: float=0
    signal_min_price: float=0
    entry_state: str='DISCOVERY'
    entry_state_since: float=0
    pressure_started_at: float=0
    pressure_peak: float=0
    pullback_low: float=0
    reaccel_started_at: float=0
    reaccel_start_price: float=0
    cooldown_until: float=0
    last_buy_at: float=0
    last_buy_entry_id: str=''
    last_buy_route: str=''
    direct_started_at: float=0
    direct_start_price: float=0
    reentry_unlocked: bool=False
    reject_reason: str=''
    tick_signatures: deque=field(default_factory=lambda:deque(maxlen=TICK_SIGNATURE_WINDOW))
    last_trade_time_by_venue: dict[str,str]=field(default_factory=dict)
    last_cumvol_by_venue: dict[str,float]=field(default_factory=dict)
    last_turnover_by_venue: dict[str,float]=field(default_factory=dict)
    duplicate_ticks: int=0
    reorder_ticks: int=0
    gap_anomalies: int=0
    price_anomalies: int=0
    quarantined_ticks: int=0
    quarantine_price: float=0
    quarantine_at: float=0
    quarantine_cumvol: float=0
    orderbook_at: float=0
    orderbook_samples: int=0
    orderbook_prev: dict[str,float]=field(default_factory=dict)
    orderbook_history: deque=field(default_factory=lambda:deque(maxlen=30))
    orderbook_prev_by_venue: dict[str,dict[str,float]]=field(default_factory=dict)
    orderbook_samples_by_venue: dict[str,int]=field(default_factory=dict)
    orderbook_history_by_venue: dict[str,deque]=field(default_factory=dict)
    nxt_alert_stage: str=''
    nxt_alert_at: float=0
    nxt_first_radar_at: float=0
    nxt_first_radar_rate: float=0
    nxt_second_wave_alert_stage: str=''
    nxt_second_wave_alert_at: float=0
    nxt_fast_jump_alert_stage: str=''
    nxt_fast_jump_alert_at: float=0

class TokenManager:
    def __init__(self): self.token=''; self.exp=0; self.lock=asyncio.Lock()
    async def get(self):
        if self.token and time.time()<self.exp-120:return self.token
        async with self.lock:
            if self.token and time.time()<self.exp-120:return self.token
            if not APP_KEY or not SECRET: raise RuntimeError('KIWOOM_APP_KEY / KIWOOM_SECRET_KEY 환경변수 필요')
            async with httpx.AsyncClient(timeout=12) as c:
                r=await c.post(API+'/oauth2/token',json={'grant_type':'client_credentials','appkey':APP_KEY,'secretkey':SECRET})
                r.raise_for_status(); j=r.json()
                if int(j.get('return_code',0))!=0: raise RuntimeError(j.get('return_msg') or 'token error')
                self.token=j['token']; self.exp=time.time()+23*3600
                return self.token
TOK=TokenManager()

class NovaState:
    def __init__(self):
        self.candidates: dict[str,Candidate]={}
        self.rest_status={}
        self.ws_status={'connected':False,'ack':0,'last_error':'','last_message_at':0,'last_trade_at':0,'last_trade_code':'','last_trade_venue':'','last_fid9081':'','reconnects':0,'reg_retries':0,'reg_failed':0,'registered_groups':0,'program_rt_at':0,'program_rt_code':'','registry_mode':'STABLE_GROUP_DIFF_REMOVE','trade_registered':0,'program_registered':0,'duplicate_drops':0,'reorder_drops':0,'gap_anomalies':0,'price_quarantines':0,'price_quarantine_confirmed':0,'reconnect_backoff_sec':0,'ws_emergency_alerts':0,'burst_highres':0}
        self.generated_at=0; self.lock=asyncio.Lock(); self.ws_codes=[]; self.core_codes=[]; self.challenger_codes=[]; self.rotation=0; self.sector_cursor=0
        self.teacher_audit={}; self.ws_contract={}; self.ws_contract_generation=0; self.market_events=deque(maxlen=1000); self.market_event_ids=set(); self.market_event_status={'dart':'NOT_CONFIGURED' if not DART_API_KEY else 'WAITING','rss':'NOT_CONFIGURED' if not NEWS_RSS_URLS else 'WAITING','last_poll':0,'events':0}
        self.nxt_alerts=deque(maxlen=500); self.nxt_alert_ids=set(); self.push_subscriptions=[]; self.push_status={'enabled':False,'subscriptions':0,'sent':0,'failed':0,'last_error':'','vapid_public':''}
        self.burst_watch={}; self.burst_codes=[]; self.burst_highres_codes=[]; self.emergency_highres_watch={}; self.nxt_memory_codes=[]; self.nxt_first_wave_memory={}; self.nxt_daily_ledger={'day':today_kst(),'rows':{}}; self.next_day_picks={'source_day':None,'effective_day':None,'rows':[]}; self.morning_push_day=''; self.close_bet_signal_day=''
        self.program_rest_cache={'KRX':{},'NXT':{}}; self.program_rest_cache_at={'KRX':0.0,'NXT':0.0}; self.program_rest_cache_lock=asyncio.Lock()
        self.scan_cycles=0; self.slow_scan_cycles=0; self.nxt_fast_scan_cycles=0; self.active_day=today_kst(); self.last_rollover_at=0.0; self.raw_rest_samples={}; self.event_count=0; self.last_persist=0
        self.score_dirty_codes=set(); self.score_dirty_event=asyncio.Event(); self.last_sector_context=0.0; self.score_durations=deque(maxlen=240); self.score_stats={'mode':'DIRTY_COALESCED','runs':0,'full_runs':0,'dirty_runs':0,'last_ms':0.0,'p95_ms':0.0,'dirty_queue':0,'last_at':0.0}
        self.persist_requested=True; self.persist_force=False; self.nxt_memory_dirty=False; self.nxt_ledger_dirty=False; self.last_nxt_flush=0.0
        self.performance_guard={'event_loop_lag_ms':0.0,'event_loop_lag_max_ms':0.0,'data_dir_mb':0.0,'disk_free_gb':None,'disk_total_gb':None,'largest_files':[],'last_scan_at':0.0,'log_compactions':0,'last_log_maintenance':0.0}
        self.candidate_cap_status={'limit':MAX_CANDIDATES,'evicted_total':0,'last_evicted':0,'last_at':0.0,'overprotected':0}
        self.lock_policy={'mode':'STRUCTURAL_ONLY','protected':['candidate create/delete','WS pool rebuild','discovery bulk mutation'],'lock_free':['verified tick metric update','dirty-score computation'],'orphan_ws_tick':'DROP_NOT_RECREATE'}
        self.evidence_status={'version':'EVIDENCE_ENGINE_V2_PROSPECTIVE','last_at':0.0,'last_error':'','report':str(EVIDENCE_REPORT_FILE)}
        self.replay_queue=deque(maxlen=REPLAY_QUEUE_MAX);self.replay_last={};self.replay_status={'version':'REPLAY_JOURNAL_V1','queued':0,'written':0,'dropped':0,'last_flush_at':0.0,'interval_sec':REPLAY_INTERVAL_SECONDS}
        self.archive_status={'version':'DAILY_GZIP_ARCHIVE_V1','last_at':0.0,'last_day':'','last_error':'','archived_days':0}
        self.smart_cursor=0; self.smart_status={}; self.sector_status={}; self.learn={'samples':0,'positive':0,'weights':{},'last_update':None,'active':False}; self.buy_signal_events=0
        self.rally_model={}; self.rally_review={'reviewed_days':[]}; self.rally_status={'samples':0,'positive':0,'negative':0,'active':False,'effective_from_day':None,'last_review_day':None,'last_review_at':None,'types':{},'trace_rows_today':0,'calibration':{}}; self.last_rally_trace=0
        self.exit_model={}; self.exit_review={'reviewed_days':[]}; self.exit_status={'samples':0,'exit':0,'hold':0,'active':False,'effective_from_day':None,'last_review_day':None,'last_review_at':None,'calibration':{}}; self.exit_positions={}; self.manual_positions={}; self.last_exit_trace=0
    def get(self,code,name=''):
        if code not in self.candidates:self.candidates[code]=Candidate(code,name)
        elif name and not self.candidates[code].name:self.candidates[code].name=name
        return self.candidates[code]
STATE=NovaState()

def _reset_candidate_daily_state(c:Candidate, day:str, now:float):
    """Reset only trading-day state. Lifetime counters and explicit manual positions survive."""
    c.source_hits.clear();c.source_last_seen.clear();c.source_prev_base=0;c.source_velocity=0;c.source_scan_id=0
    c.ticks.clear();c.tick_signatures.clear();c.last_trade_time_by_venue.clear();c.last_cumvol_by_venue.clear();c.last_turnover_by_venue.clear()
    c.last_tick_at=0;c.last_fid9081='';c.venue='';c.last_price_source='';c.last_price_by_venue.clear();c.last_rate_by_venue.clear();c.last_tick_at_by_venue.clear();c.last_fid9081_by_venue.clear()
    c.session_day=day;c.session_pv=0;c.session_vv=0;c.orderbook_at=0;c.orderbook_samples=0;c.orderbook_prev.clear();c.orderbook_history.clear();c.orderbook_prev_by_venue.clear();c.orderbook_samples_by_venue.clear();c.orderbook_history_by_venue.clear()
    c.smart={};c.smart_by_venue={};c.smart_updated_at=0;c.investor_updated_at=0;c.investor_updated_at_by_venue={};c.program_updated_at=0;c.program_updated_at_by_venue={};c.program_rt_at=0;c.program_rt_at_by_venue={};c.program_rt_samples=0;c.program_rt_raw={}
    c.signal_count_today=0;c.first_signal_at=0;c.last_signal_at=0;c.last_signal_price=0;c.last_signal_score=0;c.last_signal_stage='';c.last_signal_venue='';c.last_signal_reasons=[];c.signal_max_price=0;c.signal_min_price=0
    c.entry_state='DISCOVERY';c.entry_state_since=now;c.pressure_started_at=0;c.pressure_peak=0;c.pullback_low=0;c.reaccel_started_at=0;c.reaccel_start_price=0;c.cooldown_until=0;c.last_buy_at=0;c.last_buy_entry_id='';c.last_buy_route='';c.direct_started_at=0;c.direct_start_price=0;c.reentry_unlocked=False;c.reject_reason=''
    c.nxt_alert_stage='';c.nxt_alert_at=0;c.nxt_first_radar_at=0;c.nxt_first_radar_rate=0;c.nxt_second_wave_alert_stage='';c.nxt_second_wave_alert_at=0;c.nxt_fast_jump_alert_stage='';c.nxt_fast_jump_alert_at=0
    c.stage='SEED';c.previous_stage='SEED';c.highest_stage='SEED';c.captures={};c.reasons=[];c.metrics={}
    c.duplicate_ticks=0;c.reorder_ticks=0;c.gap_anomalies=0;c.price_anomalies=0;c.quarantined_ticks=0;c.quarantine_price=0;c.quarantine_at=0;c.quarantine_cumvol=0

def ensure_daily_rollover(force:bool=False):
    """Hard trading-day boundary so yesterday's BUY/NXT stages can never block today's signal."""
    day=today_kst();now=time.time()
    if not force and STATE.active_day==day:return False
    old=STATE.active_day;STATE.active_day=day;STATE.last_rollover_at=now
    for c in STATE.candidates.values():_reset_candidate_daily_state(c,day,now)
    STATE.burst_watch.clear();STATE.burst_codes=[];STATE.burst_highres_codes=[];STATE.emergency_highres_watch.clear();STATE.nxt_memory_codes=[];STATE.nxt_first_wave_memory={};STATE.nxt_daily_ledger={'day':day,'rows':{}};STATE.nxt_alerts.clear();STATE.nxt_alert_ids.clear();STATE.morning_push_day=''
    STATE.nxt_memory_dirty=True;STATE.nxt_ledger_dirty=True;STATE.score_dirty_codes.clear();STATE.scan_cycles=0;STATE.slow_scan_cycles=0;STATE.nxt_fast_scan_cycles=0
    for pos in STATE.exit_positions.values():
        if pos.get('status') in ('OPEN','EXIT_SIGNALED') and str(pos.get('day') or '')!=day:
            pos.update({'status':'ROLLED_OVER','last_action':'DAY_ROLLOVER','last_action_reason':'전 거래일 가상 BUY 관리 종료'})
    try:persist_exit_positions()
    except Exception:pass
    try:persist_buy_signal_state()
    except Exception:pass
    STATE.rest_status['_day_rollover']={'ok':True,'from':old,'to':day,'at':now,'candidates':len(STATE.candidates)}
    return True

async def daily_rollover_loop():
    while True:
        try:ensure_daily_rollover()
        except Exception as e:STATE.rest_status['_day_rollover']={'ok':False,'msg':str(e)[:160],'at':time.time()}
        await asyncio.sleep(2 if realtime_runtime_awake() else WS_WAKE_GUARD_SECONDS)

DEFAULT_WS_CONTRACT={
    'trade_type':'0B','program_type':'0w','orderbook_type':'0D',
    'source':'OFFICIAL_FIXED_CONTRACT','probe_day':None,'confirmed':False,'health_ok':False,
    'note':'Official Kiwoom realtime mapping is fixed: 0B stock trade / 0w stock program trading / 0D orderbook depth. Probe is health-check only and can never change scoring contract.'
}

def load_ws_contract():
    c=dict(DEFAULT_WS_CONTRACT)
    try:
        if WS_CONTRACT_FILE.exists():
            x=json.loads(WS_CONTRACT_FILE.read_text(encoding='utf-8'))
            if isinstance(x,dict):c.update({k:v for k,v in x.items() if k in ('probe_day','probe_at','confirmed','health_ok','probe','updated_at')})
    except Exception as e:c['load_error']=str(e)[:160]
    # Never trust stale cache semantics. Official Kiwoom realtime types are immutable here.
    c.update({'trade_type':'0B','program_type':'0w','orderbook_type':'0D','source':'OFFICIAL_FIXED_CONTRACT'})
    STATE.ws_contract=c
    return c

def persist_ws_contract(c:dict):
    tmp=WS_CONTRACT_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(WS_CONTRACT_FILE)

def ws_contract_status():
    c=STATE.ws_contract or load_ws_contract()
    return {**c,'generation':STATE.ws_contract_generation,'file':str(WS_CONTRACT_FILE)}



def _atomic_json(path:Path, payload:dict):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(path)

def _clone_nxt_memory_payloads():
    # Snapshot mutable minute bars on the event-loop thread; disk serialization/writes happen off-loop.
    mem_rows={}
    active_mem=set(STATE.nxt_memory_codes)|set(STATE.burst_codes)|set(STATE.core_codes)
    for code,row in STATE.nxt_first_wave_memory.items():
        if not isinstance(row,dict):continue
        # Persist only meaningful first-wave/active NXT memory. Seed-only rows may stay in RAM but never bloat disk.
        if not num(row.get('first_wave_at')) and num(row.get('peak_rate'),-999)<NXT_SECOND_WAVE_MIN_PEAK_RATE and str(code) not in active_mem:continue
        x={k:v for k,v in row.items() if k!='bars'};x['bars']=[dict(b) for b in (row.get('bars') or []) if isinstance(b,dict)];mem_rows[str(code)]=x
    led_rows={str(code):dict(row) for code,row in ((STATE.nxt_daily_ledger or {}).get('rows') or {}).items() if isinstance(row,dict)}
    mem={'version':APP_VERSION,'updated_at':now_kst(),'rows':mem_rows}
    led={'version':APP_VERSION,'updated_at':now_kst(),'day':str((STATE.nxt_daily_ledger or {}).get('day') or today_kst()),'rows':led_rows}
    return mem,led

def _write_nxt_memory_ledger(mem_payload:dict|None, ledger_payload:dict|None):
    if mem_payload is not None:_atomic_json(NXT_FIRST_WAVE_MEMORY_FILE,mem_payload)
    if ledger_payload is not None:_atomic_json(NXT_DAILY_STRONG_LEDGER_FILE,ledger_payload)

def _persist_nxt_memory_ledger(force=False):
    # Compatibility helper for shutdown/tests. Normal runtime uses persistence_loop + asyncio.to_thread.
    now=time.time()
    if not force and now-STATE.last_nxt_flush<PERSIST_INTERVAL_SECONDS:return False
    mem,led=_clone_nxt_memory_payloads();_write_nxt_memory_ledger(mem if (force or STATE.nxt_memory_dirty) else None,led if (force or STATE.nxt_ledger_dirty) else None)
    STATE.nxt_memory_dirty=False;STATE.nxt_ledger_dirty=False;STATE.last_nxt_flush=now
    return True

def load_nxt_memory_ledger():
    now=time.time();day=today_kst()
    try:
        if NXT_FIRST_WAVE_MEMORY_FILE.exists():
            d=json.loads(NXT_FIRST_WAVE_MEMORY_FILE.read_text(encoding='utf-8'));rows=d.get('rows') or {}
            if isinstance(rows,dict):
                STATE.nxt_first_wave_memory={str(k):v for k,v in rows.items() if isinstance(v,dict) and str(v.get('day') or day)==day and float(v.get('expires_at') or 0)>now}
                for code,row in STATE.nxt_first_wave_memory.items():
                    c=STATE.get(code,str(row.get('name') or ''))
                    if num(row.get('last_price'))>0 and not c.last_price:
                        c.last_price=num(row.get('last_price'));c.rate=num(row.get('last_rate'));c.last_price_source='NXT_MEMORY_RESTORE'
    except Exception:STATE.nxt_first_wave_memory={}
    try:
        if NXT_DAILY_STRONG_LEDGER_FILE.exists():
            d=json.loads(NXT_DAILY_STRONG_LEDGER_FILE.read_text(encoding='utf-8'))
            if str(d.get('day') or '')==day and isinstance(d.get('rows'),dict):STATE.nxt_daily_ledger={'day':day,'rows':d.get('rows') or {}}
            else:STATE.nxt_daily_ledger={'day':day,'rows':{}}
    except Exception:STATE.nxt_daily_ledger={'day':day,'rows':{}}
    # Upgrade path: seed first-alert references from the existing persisted alert log.
    for rec in list(STATE.nxt_alerts):
        if str(rec.get('day') or '')==day:note_nxt_alert_in_ledger(rec)

def _nxt_memory_row(c:Candidate, now:float|None=None):
    now=float(now or time.time());day=today_kst();row=STATE.nxt_first_wave_memory.get(c.code)
    if not isinstance(row,dict) or str(row.get('day') or '')!=day:
        row={'day':day,'code':c.code,'name':c.name or c.code,'first_wave_at':0.0,'peak_at':0.0,'peak_price':0.0,'peak_rate':0.0,'last_price':0.0,'last_rate':0.0,'last_tick_at':0.0,'expires_at':0.0,'bars':[]}
        STATE.nxt_first_wave_memory[c.code]=row;STATE.nxt_memory_dirty=True
    if c.name:row['name']=c.name
    return row

def _nxt_ledger_row(c:Candidate, now:float|None=None):
    now=float(now or time.time());day=today_kst()
    if str((STATE.nxt_daily_ledger or {}).get('day') or '')!=day:STATE.nxt_daily_ledger={'day':day,'rows':{}}
    rows=STATE.nxt_daily_ledger.setdefault('rows',{});row=rows.get(c.code)
    if not isinstance(row,dict):
        row={'day':day,'code':c.code,'name':c.name or c.code,'first_seen_at':now,'first_radar_at':0.0,'first_radar_rate':0.0,'peak_price':0.0,'peak_rate':-999.0,'peak_at':0.0,'last_price':0.0,'last_rate':0.0,'last_tick_at':0.0,'max_radar':0.0,'max_takeover':0.0,'max_accel30':1.0,'max_accel60':1.0,'max_buy_pressure':50.0,'max_orderbook':0.0,'first_alert_at':0.0,'first_alert_price':0.0,'first_alert_rate':0.0,'max_price_since_alert':0.0,'min_price_since_alert':0.0,'stages':[],'highest_radar_alert_rank':0,'highest_radar_alert_stage':'','highest_second_alert_rank':0,'highest_second_alert_stage':'','highest_alert_stage_today':'','highest_alert_priority_today':0,'last_push_stage':'','last_push_at':0.0}
        rows[c.code]=row;STATE.nxt_ledger_dirty=True
    if c.name:row['name']=c.name
    if c.sector:row['sector']=c.sector
    return row

def update_nxt_memory_tick(c:Candidate, now:float, price:float, rate:float, qty:float, cumvol:float=0.0, turnover:float=0.0):
    """Compact 1-minute NXT memory independent of the 1,500 raw-tick deque.

    It preserves the first-wave peak across the full NXT after-session recovery horizon while keeping memory bounded.
    """
    row=_nxt_memory_row(c,now);row.update({'last_price':price,'last_rate':rate,'last_tick_at':now})
    minute=int(now//60);bars=row.setdefault('bars',[])
    if bars and int(bars[-1].get('minute') or -1)==minute:
        b=bars[-1];b['high']=max(num(b.get('high')),price);b['low']=min(num(b.get('low'),price),price);b['close']=price;b['volume']=num(b.get('volume'))+abs(qty);b['ticks']=int(b.get('ticks') or 0)+1;b['rate']=rate
    else:
        bars.append({'minute':minute,'open':price,'high':price,'low':price,'close':price,'volume':abs(qty),'ticks':1,'rate':rate})
    cutoff=minute-NXT_MEMORY_BAR_KEEP_MINUTES
    if len(bars)>NXT_MEMORY_BAR_KEEP_MINUTES+15:row['bars']=[b for b in bars if int(b.get('minute') or 0)>=cutoff][-NXT_MEMORY_BAR_KEEP_MINUTES:]
    if rate>=NXT_SECOND_WAVE_MIN_PEAK_RATE and not num(row.get('first_wave_at')):
        row['first_wave_at']=now;row['expires_at']=now+NXT_SECOND_WAVE_MEMORY_SECONDS
    new_peak=bool(rate>num(row.get('peak_rate'),-999) or price>num(row.get('peak_price')))
    if new_peak:
        row['peak_rate']=max(rate,num(row.get('peak_rate'),-999));row['peak_price']=max(price,num(row.get('peak_price')));row['peak_at']=now
        if num(row.get('first_wave_at')):row['expires_at']=max(num(row.get('expires_at')),now+NXT_SECOND_WAVE_MEMORY_SECONDS)
    led=_nxt_ledger_row(c,now);led.update({'last_price':price,'last_rate':rate,'last_tick_at':now})
    if rate>num(led.get('peak_rate'),-999) or price>num(led.get('peak_price')):
        led['peak_rate']=max(rate,num(led.get('peak_rate'),-999));led['peak_price']=max(price,num(led.get('peak_price')));led['peak_at']=now
    if num(led.get('first_alert_at')):
        led['max_price_since_alert']=max(num(led.get('max_price_since_alert')),price)
        mn=num(led.get('min_price_since_alert'));led['min_price_since_alert']=price if mn<=0 else min(mn,price)
    STATE.nxt_memory_dirty=True;STATE.nxt_ledger_dirty=True

def update_nxt_ledger_metrics(c:Candidate, now:float|None=None):
    now=float(now or time.time());led=_nxt_ledger_row(c,now);m=c.metrics or {}
    nxt_price=num(c.last_price_by_venue.get('NXT'));nxt_rate=num(c.last_rate_by_venue.get('NXT'));nxt_at=num(c.last_tick_at_by_venue.get('NXT'))
    if nxt_price>0:
        led['last_observed_price']=nxt_price;led['last_observed_rate']=nxt_rate;led['last_observed_at']=nxt_at or now
        led['last_price']=nxt_price;led['last_rate']=nxt_rate;led['last_tick_at']=nxt_at or now
    if c.nxt_first_radar_at and not num(led.get('first_radar_at')):
        led['first_radar_at']=c.nxt_first_radar_at;led['first_radar_rate']=c.nxt_first_radar_rate
    led['max_radar']=max(num(led.get('max_radar')),num(m.get('nxt_radar_score')))
    led['max_takeover']=max(num(led.get('max_takeover')),num(m.get('nxt_takeover_score')))
    led['max_accel30']=max(num(led.get('max_accel30'),1),num(m.get('nxt_volume_accel_30s'),1))
    led['max_accel60']=max(num(led.get('max_accel60'),1),num(m.get('nxt_volume_accel_60s'),1))
    led['max_buy_pressure']=max(num(led.get('max_buy_pressure'),50),num(m.get('nxt_buy_pressure'),50))
    led['max_orderbook']=max(num(led.get('max_orderbook')),num(m.get('nxt_orderbook_presignal')))
    led['max_big_buy_count60']=max(int(led.get('max_big_buy_count60') or 0),int(m.get('nxt_big_buy_count_60s') or 0))
    led['max_big_buy_notional60']=max(num(led.get('max_big_buy_notional60')),num(m.get('nxt_big_buy_notional_60s')))
    led['nxt_program_delta']=m.get('nxt_program_delta');led['nxt_institution_delta']=m.get('nxt_institution_delta')
    sw=str(m.get('nxt_second_wave_state') or '')
    if sw:led['second_wave_state']=sw
    recovery=str(m.get('nxt_recovery_state') or '')
    if recovery:
        led['recovery_state']=recovery;led['recovery_drawdown_pct']=m.get('nxt_recovery_drawdown_pct');led['recovery_ratio']=m.get('nxt_recovery_ratio');led['recovery_peak_gap_pct']=m.get('nxt_recovery_peak_gap_pct')
    STATE.nxt_ledger_dirty=True

def note_nxt_alert_in_ledger(rec:dict):
    code=str(rec.get('code') or '')
    if not code or code=='NXT':return
    c=STATE.candidates.get(code) or Candidate(code,str(rec.get('name') or ''))
    led=_nxt_ledger_row(c,num(rec.get('at')) or time.time());stage=str(rec.get('stage') or '')
    stages=led.setdefault('stages',[])
    if stage and stage not in stages:stages.append(stage)
    p=num(rec.get('price'));r=num(rec.get('change_rate'));at=num(rec.get('at'))
    if stage in NXT_RADAR_STAGE_RANK:
        rr=NXT_RADAR_STAGE_RANK[stage]
        if rr>int(led.get('highest_radar_alert_rank') or 0):led['highest_radar_alert_rank']=rr;led['highest_radar_alert_stage']=stage
        global_priority=rr
    elif stage in NXT_SECOND_STAGE_RANK:
        rr=NXT_SECOND_STAGE_RANK[stage]
        if rr>int(led.get('highest_second_alert_rank') or 0):led['highest_second_alert_rank']=rr;led['highest_second_alert_stage']=stage
        global_priority=10+rr
    else:global_priority=int(rec.get('priority') or 0)
    if global_priority>int(led.get('highest_alert_priority_today') or 0):
        led['highest_alert_priority_today']=global_priority;led['highest_alert_stage_today']=stage
    if bool(rec.get('push_sent')):
        led['last_push_stage']=stage;led['last_push_at']=at
    if not num(led.get('first_alert_at')) and p>0:
        led.update({'first_alert_at':at,'first_alert_price':p,'first_alert_rate':r,'max_price_since_alert':p,'min_price_since_alert':p})
    if p>0:
        led['max_price_since_alert']=max(num(led.get('max_price_since_alert')),p);mn=num(led.get('min_price_since_alert'));led['min_price_since_alert']=p if mn<=0 else min(mn,p)
    STATE.nxt_ledger_dirty=True

def nxt_second_wave_memory_codes(now:float|None=None):
    now=float(now or time.time());day=today_kst();rows=[]
    for code,row in list(STATE.nxt_first_wave_memory.items()):
        if str(row.get('day') or '')!=day or num(row.get('expires_at'))<=now:
            STATE.nxt_first_wave_memory.pop(code,None);STATE.nxt_memory_dirty=True;continue
        if num(row.get('first_wave_at')) and num(row.get('peak_rate'))>=NXT_SECOND_WAVE_MIN_PEAK_RATE:
            rows.append((num(row.get('peak_at')),num(row.get('peak_rate')),code))
    rows.sort(reverse=True)
    return [code for _,__,code in rows[:NXT_SECOND_WAVE_POOL_LIMIT]]

def ensure_vapid_keys():
    """Create a persistent VAPID keypair inside the bind-mounted data directory.

    Web push remains opt-in at the browser. iOS requires the site to be installed as a Home Screen web app
    before notification permission/subscription is available.
    """
    try:
        if VAPID_PRIVATE_FILE.exists() and VAPID_PUBLIC_FILE.exists():
            pub=VAPID_PUBLIC_FILE.read_text(encoding='utf-8').strip()
        else:
            from cryptography.hazmat.primitives.asymmetric import ec
            from cryptography.hazmat.primitives import serialization
            key=ec.generate_private_key(ec.SECP256R1())
            pem=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
            nums=key.public_key().public_numbers();raw=b'\x04'+nums.x.to_bytes(32,'big')+nums.y.to_bytes(32,'big')
            pub=base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')
            VAPID_PRIVATE_FILE.write_bytes(pem);VAPID_PUBLIC_FILE.write_text(pub,encoding='utf-8')
            os.chmod(VAPID_PRIVATE_FILE,0o600)
        STATE.push_status.update({'enabled':True,'vapid_public':pub})
        return pub
    except Exception as e:
        STATE.push_status.update({'enabled':False,'last_error':f'VAPID:{e}'[:180]});return ''

def load_push_subscriptions():
    try:
        rows=json.loads(PUSH_SUB_FILE.read_text(encoding='utf-8')) if PUSH_SUB_FILE.exists() else []
        STATE.push_subscriptions=[x for x in rows if isinstance(x,dict) and x.get('endpoint')]
    except Exception:STATE.push_subscriptions=[]
    STATE.push_status['subscriptions']=len(STATE.push_subscriptions)

def persist_push_subscriptions():
    tmp=PUSH_SUB_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(STATE.push_subscriptions,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(PUSH_SUB_FILE)
    STATE.push_status['subscriptions']=len(STATE.push_subscriptions)

def load_nxt_alerts():
    if not NXT_ALERT_FILE.exists():return
    delivery={}
    try:
        if PUSH_DELIVERY_FILE.exists():
            for line in PUSH_DELIVERY_FILE.read_text(encoding='utf-8',errors='ignore').splitlines()[-1000:]:
                try:
                    d=json.loads(line);eid=str(d.get('id') or '')
                    if eid and str(d.get('day') or '')==today_kst():delivery[eid]=d
                except Exception:pass
    except Exception:pass
    try:
        for line in NXT_ALERT_FILE.read_text(encoding='utf-8',errors='ignore').splitlines()[-500:]:
            try:
                x=json.loads(line);eid=str(x.get('id') or '')
                if str(x.get('day') or '')!=today_kst():continue
                d=delivery.get(eid) or {}
                if d:x.update({'push_completed_at':d.get('at'),'push_attempted_count':int(d.get('attempted') or 0),'push_delivered_count':int(d.get('delivered') or 0),'push_failed_count':int(d.get('failed') or 0),'push_sent':int(d.get('delivered') or 0)>0,'push_last_error':str(d.get('last_error') or '')})
                if eid and eid not in STATE.nxt_alert_ids:STATE.nxt_alert_ids.add(eid);STATE.nxt_alerts.append(x)
            except Exception:pass
    except Exception:pass

def _push_sync(rec:dict):
    result={'attempted':0,'delivered':0,'failed':0,'last_error':''}
    if not STATE.push_subscriptions or not STATE.push_status.get('enabled'):return result
    try:from pywebpush import webpush, WebPushException
    except Exception as e:
        result['last_error']=f'pywebpush:{e}'[:180];STATE.push_status['last_error']=result['last_error'];return result
    payload=json.dumps({'title':rec.get('title'),'body':rec.get('body'),'url':'/?nxt_alert='+str(rec.get('id') or ''),'tag':'nxt-'+str(rec.get('code') or ''),'data':rec},ensure_ascii=False)
    keep=[]
    for sub in list(STATE.push_subscriptions):
        result['attempted']+=1
        try:
            webpush(subscription_info=sub,data=payload,vapid_private_key=str(VAPID_PRIVATE_FILE),vapid_claims={'sub':'mailto:nova@3-38-25-20.nip.io'})
            result['delivered']+=1;STATE.push_status['sent']=int(STATE.push_status.get('sent') or 0)+1;keep.append(sub)
        except Exception as e:
            code=getattr(getattr(e,'response',None),'status_code',None)
            if code not in (404,410):keep.append(sub)
            result['failed']+=1;result['last_error']=str(e)[:180];STATE.push_status['failed']=int(STATE.push_status.get('failed') or 0)+1;STATE.push_status['last_error']=result['last_error']
    if len(keep)!=len(STATE.push_subscriptions):STATE.push_subscriptions=keep;persist_push_subscriptions()
    return result

async def send_push(rec:dict):
    result=await asyncio.to_thread(_push_sync,rec)
    rec['push_completed_at']=time.time();rec['push_attempted_count']=int(result.get('attempted') or 0);rec['push_delivered_count']=int(result.get('delivered') or 0);rec['push_failed_count']=int(result.get('failed') or 0);rec['push_sent']=rec['push_delivered_count']>0;rec['push_last_error']=str(result.get('last_error') or '')[:180]
    STATE.push_status['last_delivery']={'id':rec.get('id'),'stage':rec.get('stage'),'attempted':rec['push_attempted_count'],'delivered':rec['push_delivered_count'],'failed':rec['push_failed_count'],'at':rec['push_completed_at']}
    try:
        with PUSH_DELIVERY_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps({'event':'PUSH_DELIVERY','version':APP_VERSION,'day':today_kst(),'id':rec.get('id'),'code':rec.get('code'),'stage':rec.get('stage'),'at':rec['push_completed_at'],'at_kst':now_kst(),'attempted':rec['push_attempted_count'],'delivered':rec['push_delivered_count'],'failed':rec['push_failed_count'],'last_error':rec['push_last_error']},ensure_ascii=False,separators=(',',':'))+'\n')
    except Exception:pass
    if str(rec.get('event') or '').startswith('NXT_') or str(rec.get('stage') or '') in NXT_PUSH_STAGES:note_nxt_alert_in_ledger(rec)
    return result

def _persist_nxt_alert_record(rec:dict):
    eid=str(rec.get('id') or '')
    if not eid or eid in STATE.nxt_alert_ids:return False
    stage=str(rec.get('stage') or '')
    push_eligible=stage in NXT_PUSH_STAGES
    rec['push_eligible']=push_eligible;rec['push_scheduled']=False;rec['push_sent']=False;rec['push_attempted_count']=0;rec['push_delivered_count']=0;rec['push_failed_count']=0
    STATE.nxt_alert_ids.add(eid);STATE.nxt_alerts.append(rec);note_nxt_alert_in_ledger(rec)
    with NXT_ALERT_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    if push_eligible:
        try:
            loop=asyncio.get_running_loop();rec['push_scheduled']=True;loop.create_task(send_push(rec),name='nova-nxt-push')
        except RuntimeError:pass
    return True

def _prospective_observation_snapshot(c:Candidate, stage:str, mode:str, reasons:list[str], *, buy_prohibited:bool=True):
    """Append-only point-in-time observation. No future price/outcome is written here.

    This file is the anti-hindsight audit trail: later replay/evidence jobs may JOIN outcomes by id,
    but the original line is never edited or relabelled in place.
    """
    now=time.time();m=c.metrics or {};venue='NXT';price=num(c.last_price_by_venue.get(venue));rate=num(c.last_rate_by_venue.get(venue));at=num(c.last_tick_at_by_venue.get(venue))
    if price<=0 or not at or now-at>5:return None
    flow=venue_flow_snapshot(c,venue)
    oid=hashlib.sha1(f"{today_kst()}|{c.code}|{stage}|{int(now*1000)}".encode()).hexdigest()[:20]
    rec={'id':oid,'event':'PROSPECTIVE_OBSERVATION','version':APP_VERSION,'day':today_kst(),'ts':round(now,3),'at_kst':now_kst(),'code':c.code,'name':c.name or c.code,'venue':venue,'stage':stage,'mode':mode,'decision':'WATCH_ONLY' if buy_prohibited else 'OBSERVE','buy_prohibited':bool(buy_prohibited),'frozen_at_emit':True,'future_label':None,'future_return':None,'price':round(price,4),'rate':round(rate,4),'score':round(num(c.score),2),'nxt_radar_score':round(num(m.get('nxt_radar_score')),2),'nxt_takeover_score':round(num(m.get('nxt_takeover_score')),2),'nxt_catch_score':round(num(m.get('nxt_catch_score')),2),'nxt_catch_percentile':round(num(m.get('nxt_catch_percentile')),3),'nxt_catch_population':int(m.get('nxt_catch_population') or 0),'nxt_top1_target':bool(m.get('nxt_top1_target')),'buy_pressure':round(num(flow.get('buy_pressure'),50),2),'algo_persistence':round(num(flow.get('algo'),50),2),'volume_accel_30s':round(num(m.get('nxt_volume_accel_30s'),1),3),'volume_accel_60s':round(num(m.get('nxt_volume_accel_60s'),1),3),'impulse_60s':round(num(flow.get('impulse')),3),'micro_vwap_gap':round(num(flow.get('vwap_gap')),3),'micro_breakout':round(num(flow.get('breakout')),3),'orderbook':round(num(flow.get('orderbook')),3),'wall_v2':round(num(m.get('nxt_orderbook_wall_v2_score')),3),'wall_cancel_risk':round(num(m.get('nxt_orderbook_wall_cancel_risk')),3),'program_delta':round(num(flow.get('program_delta')),2),'institution_delta':round(num(flow.get('institution_delta')),2),'event_signal':round(num(m.get('event_signal')),2),'event_polarity':m.get('event_polarity'),'recovery_ratio':round(num(m.get('nxt_recovery_ratio')),4),'recovery_drawdown_pct':round(num(m.get('nxt_recovery_drawdown_pct')),3),'recovery_trough_age_min':round(num(m.get('nxt_recovery_trough_age_min')),3),'reasons':list(reasons[:8])}
    try:
        with PROSPECTIVE_OBSERVATION_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    except Exception:pass
    return rec

def _nxt_catch_raw_score(c:Candidate):
    """Point-in-time catch score used only for prioritisation/percentile audit, never as a BUY route."""
    m=c.metrics or {};rad=num(m.get('nxt_radar_score'));take=num(m.get('nxt_takeover_score'));bp=num(m.get('nxt_buy_pressure'),50);algo=num(m.get('nxt_algo_persistence'),50);a30=num(m.get('nxt_volume_accel_30s'),1);a60=num(m.get('nxt_volume_accel_60s'),1);bo=num(m.get('nxt_micro_breakout'));ob=num(m.get('nxt_orderbook_presignal')) if m.get('nxt_orderbook_verified') else 0;wall=num(m.get('nxt_orderbook_wall_v2_score'));cancel=num(m.get('nxt_orderbook_wall_cancel_risk'))
    return clamp(rad*.30+take*.12+clamp((bp-50)*1.0,0,20)+clamp((algo-50)*.7,0,14)+clamp((a30-1)*8,0,12)+clamp((a60-1)*8,0,8)+clamp(bo*5,0,5)+clamp(ob,0,3)+clamp(wall,0,2)-clamp(cancel*4,0,4),0,100)

def emit_nxt_fast_jump_alert(c:Candidate, stage:str, reasons:list[str]):
    """High-speed discovery warning only. It has no direct BUY recorder path."""
    rank=NXT_FAST_STAGE_RANK;new=rank.get(stage,0)
    if new<=0:return False
    old=rank.get(c.nxt_fast_jump_alert_stage,0)
    if new<=old:return False
    now=time.time();price=num(c.last_price_by_venue.get('NXT'));rate=num(c.last_rate_by_venue.get('NXT'));at=num(c.last_tick_at_by_venue.get('NXT'))
    if price<=0 or not at or now-at>5:return False
    c.nxt_fast_jump_alert_stage=stage;c.nxt_fast_jump_alert_at=now
    title='⛔ FAST JUMP 감지 · 매수금지' if stage=='FAST_JUMP_WATCH' else '⛔ FAST JUMP 강세지속 · 아직 매수금지'
    body=f"{c.name or c.code} {rate:+.2f}% · 추격매수 금지 · 눌림 후 SECOND_WAVE/RECOVERY 대기"
    eid=hashlib.sha1(f'{today_kst()}|{c.code}|{stage}'.encode()).hexdigest()[:18]
    rec={'id':eid,'event':'NXT_FAST_JUMP_ALERT','version':APP_VERSION,'day':today_kst(),'stage':stage,'priority':12 if stage=='FAST_JUMP_WATCH' else 13,'code':c.code,'name':c.name or c.code,'price':price,'change_rate':rate,'score':c.score,'nxt_radar_score':c.metrics.get('nxt_radar_score'),'nxt_takeover_score':c.metrics.get('nxt_takeover_score'),'nxt_catch_score':c.metrics.get('nxt_catch_score'),'nxt_catch_percentile':c.metrics.get('nxt_catch_percentile'),'nxt_top1_target':bool(c.metrics.get('nxt_top1_target')),'at':now,'at_kst':now_kst(),'title':title,'body':body,'reasons':(['⛔ 신규 추격매수 금지']+reasons)[:8],'buy_prohibited':True,'decision':'WATCH_ONLY'}
    _prospective_observation_snapshot(c,stage,'FAST_JUMP',rec['reasons'],buy_prohibited=True)
    return _persist_nxt_alert_record(rec)

def emit_nxt_alert(c:Candidate, stage:str, reasons:list[str]):
    now=time.time();rank=NXT_RADAR_STAGE_RANK
    new=rank.get(stage,0)
    if new<=0:return False
    led=_nxt_ledger_row(c,now)
    old=max(rank.get(c.nxt_alert_stage,0),int(led.get('highest_radar_alert_rank') or 0))
    # Same/lower stage is suppressed for the whole trading day, even after Candidate recreation.
    # A genuine upgrade (EARLY -> PRE -> EMERGENCY/IGNITION) is never held back by the old 180s cooldown.
    if new<=old:return False
    c.nxt_alert_stage=stage;c.nxt_alert_at=now
    led['highest_radar_alert_rank']=new;led['highest_radar_alert_stage']=stage;STATE.nxt_ledger_dirty=True
    title={'EARLY_WATCH':'NXT 조기관찰','PRE_IGNITION':'NXT 점화직전','EMERGENCY_IGNITION':'NXT WS 긴급점화','IGNITION':'NXT 점화','LATE_RALLY':'NXT 급등 추적','PREMARKET_CONFIRM':'NXT 프리마켓 확인'}[stage]
    nxt_price=num(c.last_price_by_venue.get('NXT'));nxt_rate=num(c.last_rate_by_venue.get('NXT'));nxt_at=num(c.last_tick_at_by_venue.get('NXT'))
    if nxt_price<=0 or not nxt_at:return False
    body=f"{c.name or c.code} {nxt_rate:+.2f}% · "+' · '.join(reasons[:3])
    eid=hashlib.sha1(f'{today_kst()}|{c.code}|{stage}'.encode()).hexdigest()[:18]
    rec={'id':eid,'event':'NXT_WS_EMERGENCY_ALERT' if stage=='EMERGENCY_IGNITION' else 'NXT_RADAR_ALERT','version':APP_VERSION,'day':today_kst(),'stage':stage,'priority':new,'code':c.code,'name':c.name or c.code,'price':nxt_price,'change_rate':nxt_rate,'score':c.score,'nxt_radar_score':c.metrics.get('nxt_radar_score'),'nxt_radar_hits':c.metrics.get('nxt_radar_hits'),'nxt_takeover_score':c.metrics.get('nxt_takeover_score'),'at':now,'at_kst':now_kst(),'title':title,'body':body,'reasons':reasons[:6]}
    return _persist_nxt_alert_record(rec)

def emit_nxt_second_wave_alert(c:Candidate, stage:str, reasons:list[str]):
    now=time.time();rank=NXT_SECOND_STAGE_RANK
    new=rank.get(stage,0)
    if new<=0:return False
    led=_nxt_ledger_row(c,now)
    old=max(rank.get(c.nxt_second_wave_alert_stage,0),int(led.get('highest_second_alert_rank') or 0))
    if new<=old:return False
    c.nxt_second_wave_alert_stage=stage;c.nxt_second_wave_alert_at=now
    led['highest_second_alert_rank']=new;led['highest_second_alert_stage']=stage;STATE.nxt_ledger_dirty=True
    title={'SECOND_WAVE_BASE':'NXT 2차파동 눌림목','SECOND_WAVE_READY':'NXT 눌림목 진입준비','SECOND_WAVE_BUY':'NXT 2차점화 BUY'}[stage]
    nxt_price=num(c.last_price_by_venue.get('NXT'));nxt_rate=num(c.last_rate_by_venue.get('NXT'));nxt_at=num(c.last_tick_at_by_venue.get('NXT'))
    if nxt_price<=0 or not nxt_at:return False
    body=f"{c.name or c.code} {nxt_rate:+.2f}% · "+' · '.join(reasons[:3])
    eid=hashlib.sha1(f'{today_kst()}|{c.code}|{stage}'.encode()).hexdigest()[:18]
    rec={'id':eid,'event':'NXT_SECOND_WAVE_ALERT','version':APP_VERSION,'day':today_kst(),'stage':stage,'priority':new+2,'code':c.code,'name':c.name or c.code,'price':nxt_price,'change_rate':nxt_rate,'score':c.score,'nxt_radar_score':c.metrics.get('nxt_radar_score'),'nxt_takeover_score':c.metrics.get('nxt_takeover_score'),'at':now,'at_kst':now_kst(),'title':title,'body':body,'reasons':reasons[:6],'second_wave':{k:c.metrics.get(k) for k in ('nxt_second_wave_pullback_pct','nxt_second_wave_base_minutes','nxt_dryup_ratio_10m','nxt_volume_accel_30s','nxt_volume_accel_60s','nxt_second_wave_breakout')}}
    ok=_persist_nxt_alert_record(rec)
    if ok:
        try:
            with NXT_SECOND_WAVE_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
        except Exception:pass
    return ok

def emit_nxt_recovery_alert(c:Candidate, stage:str, reasons:list[str]):
    """Push the long-recovery transition once per code/stage/day.

    This is deliberately independent of the compact 6-20 minute SECOND_WAVE base so a strong NXT
    name can be rediscovered after a longer shakeout and late-session recovery.
    """
    if stage not in NXT_RECOVERY_STAGE_RANK:return False
    now=time.time();nxt_price=num(c.last_price_by_venue.get('NXT'));nxt_rate=num(c.last_rate_by_venue.get('NXT'));nxt_at=num(c.last_tick_at_by_venue.get('NXT'))
    if nxt_price<=0 or not nxt_at or now-nxt_at>5:return False
    title=('NXT 회복초기 관찰 · ⛔ 매수금지' if stage=='RECOVERY_EARLY' else ('NXT 장기눌림 회복준비' if stage=='RECOVERY_READY' else 'NXT 장기눌림 회복 BUY'))
    body=(f"{c.name or c.code} {nxt_rate:+.2f}% · ⛔ 아직 매수금지 · " if stage=='RECOVERY_EARLY' else f"{c.name or c.code} {nxt_rate:+.2f}% · ")+' · '.join(reasons[:3])
    eid=hashlib.sha1(f'{today_kst()}|{c.code}|{stage}'.encode()).hexdigest()[:18]
    rec={'id':eid,'event':'NXT_RECOVERY_ALERT','version':APP_VERSION,'day':today_kst(),'stage':stage,'priority':13 if stage=='RECOVERY_EARLY' else 14 if stage=='RECOVERY_READY' else 15,'code':c.code,'name':c.name or c.code,'price':nxt_price,'change_rate':nxt_rate,'score':c.score,'nxt_radar_score':c.metrics.get('nxt_radar_score'),'nxt_takeover_score':c.metrics.get('nxt_takeover_score'),'at':now,'at_kst':now_kst(),'title':title,'body':body,'reasons':reasons[:7],'recovery':{k:c.metrics.get(k) for k in ('nxt_recovery_drawdown_pct','nxt_recovery_from_low_pct','nxt_recovery_ratio','nxt_recovery_peak_gap_pct','nxt_recovery_peak_age_min','nxt_recovery_trough_age_min','nxt_volume_accel_30s','nxt_volume_accel_60s','nxt_buy_pressure','nxt_algo_persistence','nxt_micro_vwap_gap')}}
    if stage=='RECOVERY_EARLY':
        rec.update({'buy_prohibited':True,'decision':'WATCH_ONLY'});_prospective_observation_snapshot(c,stage,'RECOVERY_EARLY',reasons,buy_prohibited=True)
    return _persist_nxt_alert_record(rec)

def update_nxt_second_wave_features(c:Candidate, now:float|None=None):
    now=float(now or time.time())
    # KRX-only candidates never enter the NXT memory/ledger path. This avoids useless 210-minute bars and disk churn.
    nxt_hint=bool(c.metrics.get('nxt_seen') or int(c.metrics.get('nxt_radar_count') or 0)>0 or c.code in STATE.nxt_first_wave_memory or c.code in ((STATE.nxt_daily_ledger or {}).get('rows') or {}))
    if not nxt_hint:
        c.metrics.update({'nxt_volume_accel_30s':1.0,'nxt_volume_accel_60s':1.0,'nxt_dryup_ratio_10m':None,'nxt_second_wave_state':'','nxt_recovery_state':''});return
    row=_nxt_memory_row(c,now);bars=list(row.get('bars') or [])
    nt=[t for t in c.ticks if t.venue=='NXT' and now-t.ts<=300]
    if len(nt)<4:
        c.metrics.update({'nxt_volume_accel_30s':1.0,'nxt_volume_accel_60s':1.0,'nxt_dryup_ratio_10m':None,'nxt_second_wave_state':'','nxt_recovery_state':''});update_nxt_ledger_metrics(c,now);return
    last=nt[-1];peak_price=num(row.get('peak_price'));peak_rate=num(row.get('peak_rate'));peak_at=num(row.get('peak_at'));first_at=num(row.get('first_wave_at'))
    first_wave=bool(first_at and peak_rate>=NXT_SECOND_WAVE_MIN_PEAK_RATE and peak_at<now-180)
    pullback=max(0.0,(peak_price-last.price)/peak_price*100) if peak_price else 0.0
    now_min=int(now//60)
    recent10=[b for b in bars if now_min-int(b.get('minute') or 0)<=9]
    prior20=[b for b in bars if 10<=now_min-int(b.get('minute') or 0)<=29]
    vol10=sum(num(b.get('volume')) for b in recent10);vol20=sum(num(b.get('volume')) for b in prior20)
    dry=(vol10/max(len(recent10),1))/(vol20/max(len(prior20),1)) if prior20 and recent10 and vol20>0 else None
    highs=[num(b.get('high')) for b in recent10 if num(b.get('high'))>0];lows=[num(b.get('low')) for b in recent10 if num(b.get('low'))>0]
    rng=((max(highs)-min(lows))/max(last.price,1)*100) if highs and lows else 99.0
    r30=[t for t in nt if now-t.ts<=30];b30=[t for t in nt if 30<now-t.ts<=150]
    r60=[t for t in nt if now-t.ts<=60];b60=[t for t in nt if 60<now-t.ts<=300]
    v30=sum(abs(t.qty) for t in r30);bv30=sum(abs(t.qty) for t in b30)/4 if len(b30)>=3 else 0
    v60=sum(abs(t.qty) for t in r60);bv60=sum(abs(t.qty) for t in b60)/4 if len(b60)>=3 else 0
    a30=v30/max(bv30,1) if bv30>0 else 1.0;a60=v60/max(bv60,1) if bv60>0 else 1.0
    old=[t.price for t in nt if 30<now-t.ts<=300 and t.price>0];old_high=max(old) if old else 0
    breakout=max(0.0,(last.price/old_high-1)*100) if old_high else 0.0
    # Find the earliest 6-20 minute compact base using minute bars, independent of the raw tick cap.
    base_sec=0.0
    eligible=[b for b in bars if 0<=now_min-int(b.get('minute') or 0)<=20 and int(b.get('minute') or 0)*60>peak_at]
    for b in eligible:
        age=(now_min-int(b.get('minute') or 0))*60
        if age<NXT_SECOND_WAVE_BASE_MIN_SECONDS or age>NXT_SECOND_WAVE_BASE_MAX_SECONDS:continue
        seg=[x for x in eligible if int(x.get('minute') or 0)>=int(b.get('minute') or 0)]
        sh=[num(x.get('high')) for x in seg if num(x.get('high'))>0];sl=[num(x.get('low')) for x in seg if num(x.get('low'))>0]
        if sh and sl and (max(sh)-min(sl))/max(last.price,1)*100<=NXT_SECOND_WAVE_MAX_RANGE:
            base_sec=max(base_sec,age)
    last5=[b for b in recent10 if now_min-int(b.get('minute') or 0)<=4];prev5=[b for b in recent10 if 5<=now_min-int(b.get('minute') or 0)<=9]
    higher_low=bool(last5 and prev5 and min(num(b.get('low')) for b in last5)>=min(num(b.get('low')) for b in prev5)*0.995)
    base_ok=bool(first_wave and NXT_SECOND_WAVE_MIN_PULLBACK<=pullback<=NXT_SECOND_WAVE_MAX_PULLBACK and NXT_SECOND_WAVE_BASE_MIN_SECONDS<=base_sec<=NXT_SECOND_WAVE_BASE_MAX_SECONDS and rng<=NXT_SECOND_WAVE_MAX_RANGE and dry is not None and dry<=NXT_SECOND_WAVE_MAX_DRYUP and higher_low)
    # SECOND WAVE is NXT-pure: KRX ticks/orderbook must never influence readiness or ignition.
    bp=num(c.metrics.get('nxt_buy_pressure'));ob=num(c.metrics.get('nxt_orderbook_presignal'));nxt_tick_at=num(c.last_tick_at_by_venue.get('NXT'));fresh=bool(nxt_tick_at and now-nxt_tick_at<=5)
    vf=venue_smart_freshness(c,'NXT');nsm=_venue_smart(c,'NXT');prog_delta=num(nsm.get('program_delta'));big_count=int(c.metrics.get('nxt_big_buy_count_60s') or 0);program_ok=bool(not vf.get('program_fresh') or prog_delta>=0 or big_count>=2)
    ready=bool(base_ok and (a30>=NXT_SECOND_WAVE_READY_ACCEL30 or a60>=NXT_SECOND_WAVE_READY_ACCEL60) and bp>=54 and (ob>=0 or breakout>=0.08))
    ignition=bool(base_ok and fresh and program_ok and a30>=NXT_SECOND_WAVE_BUY_ACCEL30 and a60>=NXT_SECOND_WAVE_BUY_ACCEL60 and bp>=56 and breakout>=NXT_SECOND_WAVE_BREAKOUT and ob>=-0.5)
    state='SECOND_WAVE_BUY' if ignition else 'SECOND_WAVE_READY' if ready else 'SECOND_WAVE_BASE' if base_ok else ''

    # Long recovery: unlike SECOND_WAVE, this deliberately accepts a 15-180 minute shakeout.
    # It requires a meaningful first-wave drawdown and then a sustained reclaim toward the old NXT peak.
    peak_age=max(0.0,now-peak_at) if peak_at else 0.0
    since_peak=[b for b in bars if peak_at and int(b.get('minute') or 0)*60>=peak_at-60 and 0<=now_min-int(b.get('minute') or 0)<=NXT_MEMORY_BAR_KEEP_MINUTES]
    trough_bar=min(since_peak,key=lambda b:num(b.get('low'),10**30)) if since_peak else None
    trough_price=num((trough_bar or {}).get('low'));trough_at=(int((trough_bar or {}).get('minute') or 0)*60) if trough_bar else 0.0
    trough_age=max(0.0,now-trough_at) if trough_at else 0.0
    recovery_drawdown=max(0.0,(peak_price-trough_price)/peak_price*100) if peak_price>0 and trough_price>0 else 0.0
    recovery_from_low=max(0.0,(last.price/trough_price-1)*100) if trough_price>0 else 0.0
    recovery_ratio=clamp((last.price-trough_price)/max(peak_price-trough_price,1e-9),0,1.5) if peak_price>trough_price>0 else 0.0
    recovery_peak_gap=max(0.0,(peak_price-last.price)/peak_price*100) if peak_price>0 else 99.0
    algo=num(c.metrics.get('nxt_algo_persistence'),50);vgap=num(c.metrics.get('nxt_micro_vwap_gap'));imp=num(c.metrics.get('nxt_impulse_60s'));nxt_rate=num(c.last_rate_by_venue.get('NXT'))
    recovery_shape_early=bool(first_wave and NXT_RECOVERY_MIN_PULLBACK<=recovery_drawdown<=NXT_RECOVERY_MAX_PULLBACK and NXT_RECOVERY_MIN_PEAK_AGE_SECONDS<=peak_age<=NXT_RECOVERY_MAX_PEAK_AGE_SECONDS and trough_age>=NXT_RECOVERY_EARLY_TROUGH_AGE_SECONDS)
    recovery_shape=bool(recovery_shape_early and trough_age>=NXT_RECOVERY_MIN_TROUGH_AGE_SECONDS)
    # A clear deep-shakeout -> reclaim must at least surface as RECOVERY_READY even when one auxiliary
    # feed (program/orderbook) is temporarily unavailable. BUY remains strict. This prevents late
    # recoveries like a ~9% shakeout followed by a >65% reclaim from disappearing merely because a
    # single micro-flow field is neutral for a few seconds.
    wall_v2=num(c.metrics.get('nxt_orderbook_wall_v2_score'));wall_cancel=num(c.metrics.get('nxt_orderbook_wall_cancel_risk'));recovery_support=sum((bp>=54,algo>=52,vgap>=-0.35,imp>=0,ob>=-1.0,(a30>=1.08 or a60>=1.04),big_count>=1,wall_v2>=0.8));recovery_support=max(0,recovery_support-(1 if wall_cancel>=0.8 else 0))
    recovery_early=bool(recovery_shape_early and fresh and recovery_ratio>=NXT_RECOVERY_EARLY_RATIO and recovery_support>=3 and (bp>=52 or algo>=52 or a30>=1.08 or a60>=1.04 or big_count>=1))
    recovery_ready=bool(recovery_shape and fresh and recovery_ratio>=NXT_RECOVERY_READY_RATIO and recovery_peak_gap<=NXT_RECOVERY_READY_PEAK_GAP and recovery_support>=4 and (bp>=NXT_RECOVERY_READY_BP or algo>=NXT_RECOVERY_READY_ALGO or a30>=1.15 or a60>=1.10 or big_count>=1))
    recovery_buy=bool(recovery_ready and recovery_ratio>=NXT_RECOVERY_BUY_RATIO and recovery_peak_gap<=NXT_RECOVERY_BUY_PEAK_GAP and recovery_support>=5 and bp>=NXT_RECOVERY_BUY_BP and algo>=NXT_RECOVERY_BUY_ALGO and vgap>=-0.10 and imp>=0.15 and program_ok and ob>=-0.5 and (a30>=1.20 or a60>=1.12 or big_count>=2) and nxt_rate<=NXT_RECOVERY_MAX_ENTRY_RATE)
    recovery_state='RECOVERY_BUY' if recovery_buy else 'RECOVERY_READY' if recovery_ready else 'RECOVERY_EARLY' if recovery_early else ''
    c.metrics.update({'nxt_peak_price_3h':round(peak_price,2),'nxt_peak_rate_3h':round(peak_rate,2),'nxt_peak_price_5h':round(peak_price,2),'nxt_peak_rate_5h':round(peak_rate,2),'nxt_first_wave_at_kst':fmt_kst(first_at,'%H:%M:%S') if first_at else None,'nxt_second_wave_pullback_pct':round(pullback,2),'nxt_second_wave_base_minutes':round(base_sec/60,1),'nxt_second_wave_range_10m':round(rng,2),'nxt_dryup_ratio_10m':round(dry,3) if dry is not None else None,'nxt_volume_accel_30s':round(a30,2),'nxt_volume_accel_60s':round(a60,2),'nxt_second_wave_breakout':round(breakout,2),'nxt_second_wave_higher_low':higher_low,'nxt_second_wave_state':state,'nxt_second_wave_first_wave':first_wave,'nxt_memory_active':bool(first_at and num(row.get('expires_at'))>now),'nxt_memory_expires_at':row.get('expires_at'),'nxt_program_delta':round(prog_delta,2),'nxt_program_fresh':bool(vf.get('program_fresh')),'nxt_recovery_state':recovery_state,'nxt_recovery_drawdown_pct':round(recovery_drawdown,2),'nxt_recovery_from_low_pct':round(recovery_from_low,2),'nxt_recovery_ratio':round(recovery_ratio,3),'nxt_recovery_peak_gap_pct':round(recovery_peak_gap,2),'nxt_recovery_peak_age_min':round(peak_age/60,1),'nxt_recovery_trough_age_min':round(trough_age/60,1),'nxt_recovery_trough_price':round(trough_price,2) if trough_price else None,'nxt_recovery_trough_at_kst':fmt_kst(trough_at,'%H:%M') if trough_at else None,'nxt_recovery_support':int(recovery_support),'nxt_recovery_wall_v2':round(wall_v2,2),'nxt_recovery_wall_cancel_risk':round(wall_cancel,3)})
    update_nxt_ledger_metrics(c,now)

def advance_nxt_second_wave(c:Candidate, sess:dict, age_ms:float):
    nxt_at=num(c.last_tick_at_by_venue.get('NXT'));nxt_age_ms=(time.time()-nxt_at)*1000 if nxt_at else 10**12
    if not nxt_radar_session_active() or nxt_age_ms>FRESH_MS:return
    st=str(c.metrics.get('nxt_second_wave_state') or '')
    if not st:return
    pb=num(c.metrics.get('nxt_second_wave_pullback_pct'));mins=num(c.metrics.get('nxt_second_wave_base_minutes'));dry=c.metrics.get('nxt_dryup_ratio_10m');a30=num(c.metrics.get('nxt_volume_accel_30s'),1);a60=num(c.metrics.get('nxt_volume_accel_60s'),1);bo=num(c.metrics.get('nxt_second_wave_breakout'));bp=num(c.metrics.get('nxt_buy_pressure'),50)
    reasons=[f'1차고점 대비 -{pb:.1f}% 눌림',f'{mins:.0f}분 저거래량 압축',f'Dry-up {num(dry):.2f}'];vf=venue_smart_freshness(c,'NXT');pd=num(_venue_smart(c,'NXT').get('program_delta'));reasons+=( [f'NXT 프로그램 Δ {pd:+,.0f}'] if vf.get('program_fresh') else [] )
    if st=='SECOND_WAVE_BASE':emit_nxt_second_wave_alert(c,st,reasons+['저점 방어 · 2차파동 관찰'])
    elif st=='SECOND_WAVE_READY':emit_nxt_second_wave_alert(c,st,reasons+[f'NXT 30초 {a30:.1f}x · 60초 {a60:.1f}x'])
    elif st=='SECOND_WAVE_BUY':
        hard=entry_hard_reject(c,'NXT')
        nxt_rate=num(c.last_rate_by_venue.get('NXT'))
        if nxt_rate>NXT_SECOND_WAVE_MAX_ENTRY_RATE or hard:
            emit_nxt_second_wave_alert(c,'SECOND_WAVE_READY',reasons+['재점화 확인 · 과열/추격 게이트로 BUY 보류'])
            return
        emit_nxt_second_wave_alert(c,st,reasons+[f'박스상단 +{bo:.2f}% · 공격매수 {bp:.0f}%'])
        # Independent route, but the common cooldown/max-daily guard still applies.
        c.reasons=(['NXT 2차파동 BUY · 거래량 고갈 후 재점화',f'30초 {a30:.1f}x · 60초 {a60:.1f}x · 돌파 +{bo:.2f}%']+list(c.reasons))[:5]
        record_buy_signal(c,'BUY','NXT_SECOND_WAVE_BASE')

def recovery_entry_hard_reject(c:Candidate):
    """Recovery-specific chase guard. A prior +12% day is not itself a reject after a verified deep shakeout."""
    m=c.metrics or {};reasons=[];rate=num(c.last_rate_by_venue.get('NXT'));imp=num(m.get('nxt_impulse_60s'));vgap=num(m.get('nxt_micro_vwap_gap'));one=num(m.get('nxt_one_tick_ratio'))
    if rate>NXT_RECOVERY_MAX_ENTRY_RATE:reasons.append('회복구간 상승률 과열')
    if imp>max(ENTRY_MAX_IMPULSE,2.8):reasons.append('회복 1분 급등 과열')
    if vgap>3.0:reasons.append('회복 Micro VWAP 과이격')
    if one>0.45:reasons.append('단일체결 편중')
    if bool(m.get('sector_overheat')):reasons.append('섹터 과열')
    if num(m.get('event_signal'))<=-5.0:reasons.append('중대 악재 공시/뉴스')
    return reasons

def advance_nxt_recovery(c:Candidate, sess:dict, age_ms:float):
    """Detect and alert long shakeout -> recovery patterns that the compact second-wave base intentionally misses."""
    nxt_at=num(c.last_tick_at_by_venue.get('NXT'));nxt_age_ms=(time.time()-nxt_at)*1000 if nxt_at else 10**12
    if not nxt_radar_session_active() or nxt_age_ms>FRESH_MS:return
    st=str(c.metrics.get('nxt_recovery_state') or '')
    if not st:return
    dd=num(c.metrics.get('nxt_recovery_drawdown_pct'));rec=num(c.metrics.get('nxt_recovery_from_low_pct'));ratio=num(c.metrics.get('nxt_recovery_ratio'));gap=num(c.metrics.get('nxt_recovery_peak_gap_pct'));peak_age=num(c.metrics.get('nxt_recovery_peak_age_min'));trough_age=num(c.metrics.get('nxt_recovery_trough_age_min'));bp=num(c.metrics.get('nxt_buy_pressure'),50);algo=num(c.metrics.get('nxt_algo_persistence'),50);vgap=num(c.metrics.get('nxt_micro_vwap_gap'));a30=num(c.metrics.get('nxt_volume_accel_30s'),1);a60=num(c.metrics.get('nxt_volume_accel_60s'),1);big_count=int(c.metrics.get('nxt_big_buy_count_60s') or 0)
    reasons=[f'고점대비 -{dd:.1f}% 흔들기 후 +{rec:.1f}% 회복',f'낙폭 {ratio*100:.0f}% 회복 · 고점까지 {gap:.1f}%',f'NXT BP {bp:.0f}% · 지속 {algo:.0f}%']
    if big_count:reasons.append(f'1억+ 공격체결 {big_count}회')
    wv=num(c.metrics.get('nxt_orderbook_wall_v2_score'));wr=num(c.metrics.get('nxt_orderbook_wall_cancel_risk'))
    if wv>=0.8:reasons.append(f'매수벽 지속/흡수 +{wv:.1f}')
    elif wr>=0.8:reasons.append('매수벽 급소멸 위험')
    reasons.append(f'30초 {a30:.1f}x / 60초 {a60:.1f}x · VWAP {vgap:+.2f}%')
    if st=='RECOVERY_EARLY':
        emit_nxt_recovery_alert(c,'RECOVERY_EARLY',reasons+[f'저점 확정대기 통과 {trough_age:.0f}분 · 관찰전용'])
        return
    if st=='RECOVERY_READY':
        emit_nxt_recovery_alert(c,'RECOVERY_READY',reasons+[f'고점후 {peak_age:.0f}분 · 저점후 {trough_age:.0f}분'])
        return
    if st=='RECOVERY_BUY':
        hard=recovery_entry_hard_reject(c)
        if hard:
            emit_nxt_recovery_alert(c,'RECOVERY_READY',reasons+['회복 확인 · '+hard[0]+'로 BUY 보류'])
            return
        emit_nxt_recovery_alert(c,'RECOVERY_BUY',reasons+['장기눌림 회복 재점화 확인'])
        c.reasons=(['NXT RECOVERY BUY · 급등 후 깊은 흔들기에서 재회복',f'낙폭 {dd:.1f}% · 회복률 {ratio*100:.0f}% · 고점거리 {gap:.1f}%']+list(c.reasons))[:5]
        record_buy_signal(c,'BUY','NXT_RECOVERY_RECLAIM')

def evaluate_nxt_radar_alerts(rows:list[Candidate]):
    if not nxt_radar_session_active():return
    # Do not gate NXT alerts by the generic NOVA Top40. Radar leaders, BURST entrants, CORE and 3h memory names are all evaluated.
    by={c.code:c for c in STATE.candidates.values()}
    for c in rows:by.setdefault(c.code,c)
    radar=sorted(by.values(),key=lambda x:(num(x.metrics.get('nxt_radar_score')),num(x.metrics.get('nxt_takeover_score')),x.source_velocity),reverse=True)[:NXT_RADAR_TOP]
    now=time.time();catch_pool=[]
    for x in by.values():
        at=num(x.last_tick_at_by_venue.get('NXT'))
        if (at and now-at<=12) or int(x.metrics.get('nxt_radar_count') or 0)>0:
            raw=_nxt_catch_raw_score(x);x.metrics['nxt_catch_score']=round(raw,2);catch_pool.append((raw,x.code))
    catch_scores=sorted(v for v,_ in catch_pool);pop=len(catch_scores)
    for raw,code in catch_pool:
        pct=(bisect_right(catch_scores,raw)/pop*100) if pop else 0.0
        x=by.get(code)
        if x is not None:x.metrics.update({'nxt_catch_percentile':round(pct,3),'nxt_catch_population':pop,'nxt_top1_target':bool(pop>=NXT_TOP1_MIN_POPULATION and pct>=99.0)})
    codes=[]
    for x in radar+[by[c] for c in STATE.burst_codes if c in by]+[by[c] for c in STATE.core_codes if c in by]+[by[c] for c in nxt_second_wave_memory_codes() if c in by]+list(rows[:NXT_RADAR_TOP]):
        if x.code not in codes:codes.append(x.code)
    for c in [by[x] for x in codes if x in by]:
        m=c.metrics;hits=list(m.get('nxt_radar_hits') or []);cnt=int(m.get('nxt_radar_count') or 0);rate=num(c.last_rate_by_venue.get('NXT'));radar=num(m.get('nxt_radar_score'));take=num(m.get('nxt_takeover_score'));ob=num(m.get('nxt_orderbook_presignal')) if m.get('nxt_orderbook_verified') else 0.0;bp=num(m.get('nxt_buy_pressure'),50);br=num(m.get('nxt_micro_breakout'));a30=num(m.get('nxt_volume_accel_30s'),1);a60=num(m.get('nxt_volume_accel_60s'),1);vf=venue_smart_freshness(c,'NXT');pd=num(_venue_smart(c,'NXT').get('program_delta'));big_count=int(m.get('nxt_big_buy_count_60s') or 0);algo=num(m.get('nxt_algo_persistence'),50);ticks=int(m.get('nxt_tick_count_60s') or 0);one=num(m.get('nxt_one_tick_ratio'));vgap=num(m.get('nxt_micro_vwap_gap'));catch_pct=num(m.get('nxt_catch_percentile'));catch_pop=int(m.get('nxt_catch_population') or 0);program_ok=bool(not vf.get('program_fresh') or pd>=0 or big_count>=2)
        if cnt<1:continue
        has_volume=any(x in h for h in hits for x in ('volume_surge','volume_top','turnover_top'))
        has_book=any(x in h for h in hits for x in ('bid_surge','residual_ratio_surge','orderbook_buy')) or ob>=1.5
        live_accel=(a30>=1.45 or a60>=1.25)
        reasons=[]
        if has_volume:reasons.append('NXT 거래량/거래대금 급증')
        if live_accel:reasons.append(f'NXT 체결가속 30초 {a30:.1f}x / 60초 {a60:.1f}x')
        if has_book:reasons.append('NXT 호가 선행압력')
        if cnt>=3:reasons.append(f'NXT 독립순위 {cnt}중첩')
        if take>=55:reasons.append(f'Volume Takeover {take:.0f}')
        if vf.get('program_fresh'):reasons.append(f'NXT 프로그램 Δ {pd:+,.0f}')
        if 0<=rate<=NXT_EARLY_MAX_RATE and (cnt>=2 or (has_volume and has_book) or (has_volume and live_accel)) and (radar>=35 or live_accel):
            emit_nxt_alert(c,'EARLY_WATCH',reasons or ['NXT 초기 체제변화'])
        if 0.5<=rate<=NXT_PRE_MAX_RATE and cnt>=1 and has_volume and (radar>=48 or a30>=1.50 or a60>=1.30):
            emit_nxt_alert(c,'PRE_IGNITION',reasons+([f'공격매수 {bp:.0f}%' ] if bp else []))
        nxt_at=num(c.last_tick_at_by_venue.get('NXT'));live_confirm=bool(nxt_at and time.time()-nxt_at<=5)
        if 1.0<=rate<=NXT_IGNITION_MAX_RATE and cnt>=1 and has_volume and (radar>=60 or (a30>=1.70 and a60>=1.35)) and program_ok and (live_confirm or has_book or (bp>=56 and br>=0.10)):
            emit_nxt_alert(c,'IGNITION',reasons+(['NXT 실체결 확인'] if live_confirm else []))
        fast_watch=bool(NXT_FAST_JUMP_MIN_RATE<=rate<=NXT_FAST_JUMP_MAX_RATE and has_volume and (live_accel or bp>=NXT_FAST_JUMP_MIN_BP) and (cnt>=2 or radar>=58) and (catch_pct>=NXT_FAST_JUMP_WATCH_PERCENTILE or (catch_pop<NXT_FAST_JUMP_READY_MIN_POPULATION and radar>=65)))
        if fast_watch:
            start=num(m.get('nxt_fast_jump_started_at'))
            if not start:start=time.time();m['nxt_fast_jump_started_at']=start
            hold=max(0.0,time.time()-start);m['nxt_fast_jump_hold_sec']=round(hold,1)
            fj_reasons=reasons+[f'실시간 포착백분위 {catch_pct:.1f}% / n={catch_pop}',f'BP {bp:.0f}% · 지속 {algo:.0f}% · VWAP {vgap:+.2f}%']
            emit_nxt_fast_jump_alert(c,'FAST_JUMP_WATCH',fj_reasons)
            ready=bool(hold>=NXT_FAST_JUMP_READY_HOLD_SECONDS and catch_pct>=NXT_FAST_JUMP_READY_PERCENTILE and catch_pop>=NXT_FAST_JUMP_READY_MIN_POPULATION and live_confirm and a30>=NXT_FAST_JUMP_MIN_ACCEL30 and a60>=NXT_FAST_JUMP_MIN_ACCEL60 and bp>=NXT_FAST_JUMP_MIN_BP and algo>=NXT_FAST_JUMP_MIN_ALGO and ticks>=6 and one<=0.45 and program_ok and (ob>=0 or br>=0.10))
            if ready:emit_nxt_fast_jump_alert(c,'FAST_JUMP_READY',fj_reasons+([f'TOP1 TARGET · 동시표본 {catch_pop} · BUY 아님'] if m.get('nxt_top1_target') else ['99백분위 고속관찰 · TOP1 표본부족 · BUY 아님']))
        else:
            m['nxt_fast_jump_started_at']=0;m['nxt_fast_jump_hold_sec']=0
        if rate>=NXT_LATE_RATE and not fast_watch and (cnt>=2 or radar>=60):
            emit_nxt_alert(c,'LATE_RALLY',reasons+['신규추격 금지 · FAST_JUMP/눌림 재진입 대기'])

def evaluate_ws_emergency_ignition(c:Candidate):
    """REST 순위와 무관한 NXT 실체결 긴급점화.

    단, 현재 WebSocket 감시 풀에 이미 들어온 종목만 대상으로 한다. 단일 대량체결 오탐을 막기 위해
    30/60초 거래량 가속 + 공격매수 지속 + 가격/호가 확인을 동시에 요구한다.
    """
    nxt_at=num(c.last_tick_at_by_venue.get('NXT'))
    if not nxt_radar_session_active() or not nxt_at:return False
    now=time.time()
    if now-nxt_at>max(2.0,FRESH_MS/1000):return False
    m=c.metrics;a30=num(m.get('nxt_volume_accel_30s'),1);a60=num(m.get('nxt_volume_accel_60s'),1);bp=num(m.get('nxt_buy_pressure'),50);algo=num(m.get('nxt_algo_persistence'),50);ob=num(m.get('nxt_orderbook_presignal')) if m.get('nxt_orderbook_verified') else 0.0;bo=num(m.get('nxt_micro_breakout'));imp=num(m.get('nxt_impulse_60s'));one=num(m.get('nxt_one_tick_ratio'));ticks=int(m.get('nxt_tick_count_60s') or 0);rate=num(c.last_rate_by_venue.get('NXT'));vf=venue_smart_freshness(c,'NXT');pd=num(_venue_smart(c,'NXT').get('program_delta'));big_count=int(m.get('nxt_big_buy_count_60s') or 0)
    if rate<-0.5 or rate>NXT_WS_EMERGENCY_MAX_RATE:return False
    if a30<NXT_WS_EMERGENCY_ACCEL30 or a60<NXT_WS_EMERGENCY_ACCEL60:return False
    if bp<NXT_WS_EMERGENCY_BUY_PRESSURE or algo<58 or ticks<6 or one>0.45:return False
    if vf.get('program_fresh') and pd<0 and big_count<3:return False
    confirmation=(ob>=0.5 or bo>=0.12 or imp>=0.30)
    if not confirmation:return False
    if c.nxt_alert_stage=='EMERGENCY_IGNITION' and c.nxt_alert_at and now-c.nxt_alert_at<NXT_WS_EMERGENCY_COOLDOWN:return False
    STATE.burst_watch[c.code]=max(num(STATE.burst_watch.get(c.code)),now+NXT_BURST_TTL_SECONDS)
    STATE.emergency_highres_watch[c.code]=now+NXT_BURST_TTL_SECONDS
    reasons=[f'REST 무관 WS 체결가속 30초 {a30:.1f}x / 60초 {a60:.1f}x',f'공격매수 {bp:.0f}% · 지속 {algo:.0f}%']
    if ob>=0.5:reasons.append(f'실시간 호가 +{ob:.1f}')
    elif bo>=0.12:reasons.append(f'미세돌파 +{bo:.2f}%')
    else:reasons.append(f'60초 가격가속 +{imp:.2f}%')
    ok=emit_nxt_alert(c,'EMERGENCY_IGNITION',reasons)
    if ok:STATE.ws_status['ws_emergency_alerts']=int(STATE.ws_status.get('ws_emergency_alerts') or 0)+1
    return ok

def _event_id(source:str, key:str)->str:
    return hashlib.sha1(f'{source}|{key}'.encode('utf-8','ignore')).hexdigest()[:20]

def load_market_events():
    if not MARKET_EVENT_FILE.exists():return
    try:
        lines=MARKET_EVENT_FILE.read_text(encoding='utf-8',errors='ignore').splitlines()[-1000:]
        for line in lines:
            try:
                x=json.loads(line);eid=str(x.get('id') or '')
                if eid and eid not in STATE.market_event_ids:
                    STATE.market_event_ids.add(eid);STATE.market_events.append(x)
            except Exception:pass
        STATE.market_event_status['events']=len(STATE.market_events)
    except Exception:pass

def add_market_event(x:dict):
    eid=str(x.get('id') or '')
    if not eid or eid in STATE.market_event_ids:return False
    cls=classify_market_event(x);x={**x,**cls}
    STATE.market_event_ids.add(eid);STATE.market_events.append(x)
    try:
        with MARKET_EVENT_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    except Exception:pass
    STATE.market_event_status['events']=len(STATE.market_events)
    return True

def classify_market_event(event:dict):
    """Deterministic polarity guard. It is a soft prior except severe negatives, which block new BUY routes."""
    text=(str(event.get('title') or '')+' '+str(event.get('summary') or '')).upper()
    severe=['상장폐지','횡령','배임','회생절차','파산','거래정지','감사의견 거절','감사의견거절','채무불이행','부도']
    financing=['유상증자','주주배정','일반공모','전환사채','CB 발행','CB발행','신주인수권부사채','BW 발행','BW발행','교환사채','감자']
    negative=['불성실공시','적자전환','영업정지','공급계약 해지','계약해지','소송 제기','손해배상 청구']
    positive=['단일판매','공급계약체결','공급계약 체결','수주','품목허가','허가 승인','FDA 승인','식약처 승인','특허 취득','특허취득','자기주식취득','자사주 취득','자기주식 소각','자사주 소각','무상증자','흑자전환','영업이익 증가']
    negated=any(k in text for k in ('철회','취소','해소','혐의없음','무혐의'))
    reasons=[];score=0.0;pol='NEUTRAL'
    severe_hit=[k for k in severe if k in text]
    if severe_hit and not negated:score=-6.0;pol='NEGATIVE';reasons+=severe_hit[:2]
    else:
        hit=[k for k in financing if k in text]
        if hit and not negated:score=min(score,-3.5);pol='NEGATIVE';reasons+=hit[:2]
        hit2=[k for k in negative if k in text]
        if hit2 and not negated:score=min(score,-3.0);pol='NEGATIVE';reasons+=hit2[:2]
        pos=[k for k in positive if k in text]
        if pos and score>=0:score=4.0 if event.get('source')=='DART' else 2.5;pol='POSITIVE';reasons+=pos[:2]
        elif negated and (severe_hit or hit or hit2):score=0.0;pol='NEUTRAL';reasons.append('부정이벤트 철회/취소 문맥')
        elif not reasons:pol='UNCERTAIN';score=0.0
    return {'polarity':pol,'polarity_score':score,'polarity_reasons':reasons[:3]}

def market_event_signal(c:Candidate, now:float|None=None):
    now=float(now or time.time());pos=0.0;neg=0.0;best_event=None;best_abs=-1.0
    name=(c.name or '').strip().upper()
    for e in reversed(STATE.market_events):
        ts=float(e.get('detected_at') or 0);age=now-ts
        if age<0 or age>MARKET_EVENT_TTL_SECONDS:continue
        match=bool(c.code and str(e.get('code') or '')==c.code)
        if not match and name and len(name)>=2:
            text=(str(e.get('title') or '')+' '+str(e.get('summary') or '')).upper();match=name in text
        if not match:continue
        cls=classify_market_event(e);raw=num(cls.get('polarity_score'));decay=max(0.0,1-age/MARKET_EVENT_TTL_SECONDS)
        score=raw*decay
        if score>0:pos=max(pos,score)
        elif score<0:neg=min(neg,score)
        if abs(score)>best_abs:best_abs=abs(score);best_event={**e,**cls,'effective_score':round(score,2),'age_sec':round(age,1)}
    total=clamp(pos+neg,-6.0,MARKET_EVENT_MAX_BONUS)
    return round(total,2),best_event

def _rss_text(root, tag):
    node=root.find(tag)
    return (node.text or '').strip() if node is not None and node.text else ''

async def market_event_loop():
    client=httpx.AsyncClient(timeout=httpx.Timeout(8.0,connect=4.0),follow_redirects=True)
    try:
        while True:
            try:
                if is_krx_trading_day() and 7*3600<=kst_seconds()<=20*3600+30*60:
                    day=today_kst();now=time.time()
                    if DART_API_KEY:
                        try:
                            r=await client.get('https://opendart.fss.or.kr/api/list.json',params={'crtfc_key':DART_API_KEY,'bgn_de':day,'end_de':day,'page_count':100})
                            j=r.json();rows=j.get('list') or []
                            for row in rows:
                                code=code6(row.get('stock_code'));receipt=str(row.get('rcept_no') or '')
                                if not code or not receipt:continue
                                add_market_event({'id':_event_id('DART',receipt),'source':'DART','code':code,'title':str(row.get('report_nm') or ''),'summary':str(row.get('corp_name') or ''),'receipt_no':receipt,'receipt_date':str(row.get('rcept_dt') or ''),'detected_at':now,'detected_at_kst':fmt_kst(now),'timestamp_quality':'POLL_DETECTED'})
                            STATE.market_event_status['dart']='OK';STATE.market_event_status['dart_rows']=len(rows)
                        except Exception as e:STATE.market_event_status['dart']='ERROR';STATE.market_event_status['dart_error']=str(e)[:160]
                    for url in NEWS_RSS_URLS:
                        try:
                            r=await client.get(url);root=ET.fromstring(r.text)
                            items=root.findall('.//item')[:50]
                            for it in items:
                                title=_rss_text(it,'title');link=_rss_text(it,'link');desc=_rss_text(it,'description');pub=_rss_text(it,'pubDate')
                                key=link or f'{title}|{pub}'
                                if not key:continue
                                add_market_event({'id':_event_id('RSS',key),'source':'RSS','code':'','title':title,'summary':re.sub('<[^>]+>',' ',desc)[:500],'link':link,'published':pub,'detected_at':now,'detected_at_kst':fmt_kst(now),'timestamp_quality':'POLL_DETECTED'})
                            STATE.market_event_status['rss']='OK'
                        except Exception as e:STATE.market_event_status['rss']='ERROR';STATE.market_event_status['rss_error']=str(e)[:160]
                    STATE.market_event_status['last_poll']=now;STATE.market_event_status['events']=len(STATE.market_events)
            except Exception as e:STATE.market_event_status['loop_error']=str(e)[:160]
            await asyncio.sleep(MARKET_EVENT_POLL_SECONDS)
    finally:
        await client.aclose()

def load_performance():
    try:
        if STATE_FILE.exists():
            saved=json.loads(STATE_FILE.read_text(encoding='utf-8'))
            if str(saved.get('day') or '')!=today_kst():saved={'rows':{}}
            for code,row in (saved.get('rows') or {}).items():
                c=STATE.get(code6(code) or code,str(row.get('name') or ''))
                for st,d in (row.get('captures') or {}).items():
                    try:
                        c.captures[st]=Capture(stage=str(d.get('stage') or str(st).split('@',1)[0]),at=float(d.get('at') or time.time()),price=float(d.get('price') or 0),score=float(d.get('score') or 0),venue=str(d.get('venue') or ''),current_price=float(d.get('current_price') or 0),current_return=float(d.get('current_return') or 0),max_price=float(d.get('max_price') or 0),max_return=float(d.get('max_return') or 0),min_price=float(d.get('min_price') or 0),min_return=float(d.get('min_return') or 0),features={k:float(v) for k,v in (d.get('features') or {}).items()})
                    except Exception:
                        pass
                if c.captures:
                    c.highest_stage=max((cap.stage for cap in c.captures.values()),key=lambda x:STAGE_RANK.get(x,0))
        if EVENT_FILE.exists():
            with EVENT_FILE.open('r',encoding='utf-8',errors='ignore') as f: STATE.event_count=sum(1 for _ in f)
    except Exception:
        pass

load_performance()

def load_buy_signal_state():
    try:
        if BUY_SIGNAL_STATE.exists():
            d=json.loads(BUY_SIGNAL_STATE.read_text(encoding='utf-8'))
            saved_day=str(d.get('day') or '')
            today=today_kst()
            for code,row in (d.get('rows') or {}).items():
                c=STATE.get(code6(code) or code,str(row.get('name') or ''))
                c.signal_count=int(row.get('signal_count') or 0)
                if saved_day!=today:
                    _reset_candidate_daily_state(c,today,time.time());c.signal_count=int(row.get('signal_count') or 0);continue
                c.signal_count_today=int(row.get('signal_count_today') or 0)
                c.first_signal_at=float(row.get('first_signal_at') or 0)
                c.last_signal_at=float(row.get('last_signal_at') or 0)
                c.last_signal_price=float(row.get('last_signal_price') or 0)
                c.last_signal_score=float(row.get('last_signal_score') or 0)
                c.last_signal_stage=str(row.get('last_signal_stage') or '')
                c.last_signal_venue=str(row.get('last_signal_venue') or '')
                c.last_signal_reasons=list(row.get('last_signal_reasons') or [])[:5]
                c.signal_max_price=float(row.get('signal_max_price') or c.last_signal_price or 0)
                c.signal_min_price=float(row.get('signal_min_price') or c.last_signal_price or 0)
                c.entry_state=str(row.get('entry_state') or 'DISCOVERY')
                c.entry_state_since=float(row.get('entry_state_since') or 0)
                c.pressure_started_at=float(row.get('pressure_started_at') or 0)
                c.pressure_peak=float(row.get('pressure_peak') or 0)
                c.pullback_low=float(row.get('pullback_low') or 0)
                c.reaccel_started_at=float(row.get('reaccel_started_at') or 0)
                c.reaccel_start_price=float(row.get('reaccel_start_price') or 0)
                c.cooldown_until=float(row.get('cooldown_until') or 0)
                c.last_buy_at=float(row.get('last_buy_at') or c.last_signal_at or 0)
                c.last_buy_entry_id=str(row.get('last_buy_entry_id') or '')
                c.last_buy_route=str(row.get('last_buy_route') or '')
                c.direct_started_at=float(row.get('direct_started_at') or 0)
                c.direct_start_price=float(row.get('direct_start_price') or 0)
                c.reentry_unlocked=bool(row.get('reentry_unlocked') or False)
                c.reject_reason=str(row.get('reject_reason') or '')
        if BUY_SIGNAL_FILE.exists():
            with BUY_SIGNAL_FILE.open('r',encoding='utf-8',errors='ignore') as f: STATE.buy_signal_events=sum(1 for _ in f)
    except Exception:
        pass

load_buy_signal_state()

FEATURE_KEYS=['rest','volume_accel','buy_pressure','impulse','vwap_gap','micro_breakout','dual_venue','program','trust','pension','institution','foreign','sector']
BASE_FEATURE_WEIGHTS={'rest':1.0,'volume_accel':1.0,'buy_pressure':1.0,'impulse':1.0,'vwap_gap':1.0,'micro_breakout':1.0,'dual_venue':1.0,'program':1.0,'trust':1.0,'pension':1.0,'institution':1.0,'foreign':0.7,'sector':1.0}

def _next_effective_day(day:str|None=None):
    d=datetime.strptime(day or today_kst(),'%Y%m%d')+timedelta(days=1)
    for _ in range(14):
        ds=d.strftime('%Y%m%d')
        if is_krx_trading_day(ds):return ds
        d+=timedelta(days=1)
    return d.strftime('%Y%m%d')

def persist_learning():
    tmp=LEARN_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(STATE.learn,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(LEARN_FILE)

def _activate_pending_learning_if_due():
    """Apply matured-entry learning only on/after its effective day.

    This closes the old intraday feedback leak: a BUY maturing at 10:30 may be labelled today,
    but its weight update is staged and cannot affect another stock at 10:31.  The staged model
    becomes eligible from the next KRX trading day; weekends/holidays are skipped by the same calendar used for session truth.
    """
    pnd=STATE.learn.get('pending') or {}
    eff=str(pnd.get('effective_from_day') or '')
    if not pnd or not eff or today_kst()<eff or not is_krx_trading_day():return False
    weights={k:float((pnd.get('weights') or {}).get(k,(STATE.learn.get('weights') or BASE_FEATURE_WEIGHTS).get(k,1.0))) for k in FEATURE_KEYS}
    STATE.learn['weights']=weights
    STATE.learn['applied_samples']=int(STATE.learn.get('applied_samples') or 0)+int(pnd.get('samples_delta') or 0)
    STATE.learn['applied_positive']=int(STATE.learn.get('applied_positive') or 0)+int(pnd.get('positive_delta') or 0)
    STATE.learn['applied_at']=now_kst();STATE.learn['last_effective_from_day']=eff;STATE.learn['pending']=None
    STATE.learn['active']=int(STATE.learn.get('applied_samples') or 0)>=LEARN_MIN_SAMPLES
    persist_learning();return True

def load_learning():
    try:
        if LEARN_FILE.exists():
            d=json.loads(LEARN_FILE.read_text(encoding='utf-8'))
            # Backward-compatible migration from adaptive_entry_model_v3 without a leak guard.
            old_weights=d.get('weights') or BASE_FEATURE_WEIGHTS
            w={k:float(old_weights.get(k,BASE_FEATURE_WEIGHTS.get(k,1.0))) for k in FEATURE_KEYS}
            total=int(d.get('samples') or 0);positive=int(d.get('positive') or 0)
            STATE.learn={
              'version':'ADAPTIVE_ENTRY_V4_NEXT_DAY','samples':total,'positive':positive,'weights':w,
              'applied_samples':int(d.get('applied_samples') if d.get('applied_samples') is not None else total),
              'applied_positive':int(d.get('applied_positive') if d.get('applied_positive') is not None else positive),
              'last_update':d.get('last_update'),'applied_at':d.get('applied_at'),'last_effective_from_day':d.get('last_effective_from_day'),
              'pending':d.get('pending'),'active':False,'leakage_guard':'MATURE_CAPTURE_NEXT_DAY_ONLY'
            }
        else:
            STATE.learn={'version':'ADAPTIVE_ENTRY_V4_NEXT_DAY','samples':0,'positive':0,'weights':dict(BASE_FEATURE_WEIGHTS),'applied_samples':0,'applied_positive':0,'last_update':None,'applied_at':None,'last_effective_from_day':None,'pending':None,'active':False,'leakage_guard':'MATURE_CAPTURE_NEXT_DAY_ONLY'}
    except Exception:
        STATE.learn={'version':'ADAPTIVE_ENTRY_V4_NEXT_DAY','samples':0,'positive':0,'weights':dict(BASE_FEATURE_WEIGHTS),'applied_samples':0,'applied_positive':0,'last_update':None,'applied_at':None,'last_effective_from_day':None,'pending':None,'active':False,'leakage_guard':'MATURE_CAPTURE_NEXT_DAY_ONLY'}
    _activate_pending_learning_if_due()
    STATE.learn['active']=int(STATE.learn.get('applied_samples') or 0)>=LEARN_MIN_SAMPLES
    persist_learning()
load_learning()
try:
    STATE.trained_ids=set()
    if TRAIN_FILE.exists():
        for line in TRAIN_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line); STATE.trained_ids.add(str(x.get('id') or ''))
            except Exception: pass
except Exception: STATE.trained_ids=set()

def learner_weight(k):
    _activate_pending_learning_if_due()
    if not STATE.learn.get('active'): return 1.0
    return clamp(float((STATE.learn.get('weights') or {}).get(k,1.0)),1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST)

def norm_signed(v, scale): return clamp(num(v)/max(scale,1),-1,1)

def feature_vector(c:Candidate):
    m=c.metrics;sm=c.smart or {};fresh=smart_freshness(c) if 'smart_freshness' in globals() else {'program_fresh':False,'investor_fresh':False}
    inst_scale=max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000)
    return {
      'rest': clamp(num(m.get('rest_base'))/80,0,1),
      'volume_accel': clamp((num(m.get('volume_accel'))-1)/2.5,0,1),
      'buy_pressure': clamp((num(m.get('buy_pressure'))-50)/30,0,1),
      'impulse': clamp(num(m.get('impulse_60s'))/3,0,1),
      'vwap_gap': clamp(num(m.get('vwap_gap'))/2,0,1),
      'micro_breakout': clamp(num(m.get('micro_breakout'))/2,0,1),
      'dual_venue': 1.0 if m.get('dual_venue') else 0.0,
      'program': norm_signed(sm.get('program_net'), max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),1)) if fresh.get('program_fresh') else 0.0,
      'trust': norm_signed(sm.get('trust_net'), max(abs(num(sm.get('institution_net'))),1000)) if fresh.get('investor_fresh') else 0.0,
      'pension': norm_signed(sm.get('pension_net'), max(abs(num(sm.get('institution_net'))),1000)) if fresh.get('investor_fresh') else 0.0,
      'institution': norm_signed(sm.get('institution_net'), inst_scale) if fresh.get('investor_fresh') else 0.0,
      'foreign': norm_signed(sm.get('foreign_net'), inst_scale) if fresh.get('investor_fresh') else 0.0,
      'sector': clamp(num(m.get('sector_score'))/max(SECTOR_MAX_BONUS,1),-1,1),
    }

def rally_trace_file(day:str|None=None):
    return DATA_DIR/f"rally_trace_{day or today_kst()}.jsonl"

def _mean_vectors(rows, features=None):
    features=features or RALLY_FEATURES
    if not rows:return {k:0.0 for k in features}
    return {k:round(sum(float((r or {}).get(k) or 0) for r in rows)/len(rows),6) for k in features}

def _variance(rows, k, mean):
    if len(rows)<2:return 0.0
    return sum((float((r or {}).get(k) or 0)-mean)**2 for r in rows)/(len(rows)-1)

def _distance_weights(samples, features):
    """Learn per-feature distance weights from positive/negative separation.

    Features that cleanly separate successful RALLY/EXIT examples from failures receive more
    influence; noisy dimensions are down-weighted.  Weights are normalized around 1.0 and tightly
    clipped so a small sample cannot let one feature dominate the geometry.
    """
    pos=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==1]
    neg=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==0]
    if len(pos)<3 or len(neg)<3:return {k:1.0 for k in features}
    raw={}
    balance=min(len(pos),len(neg))/max(len(pos),len(neg),1)
    support=min(1.0,min(len(pos),len(neg))/30.0)
    for k in features:
        mp=sum(float(x.get(k) or 0) for x in pos)/len(pos); mn=sum(float(x.get(k) or 0) for x in neg)/len(neg)
        vp=_variance(pos,k,mp); vn=_variance(neg,k,mn); pooled=math.sqrt(max((vp+vn)/2,1e-4))
        smd=abs(mp-mn)/pooled
        # 0.45 baseline avoids deleting a dimension; signal grows with standardized separation.
        raw[k]=0.45+min(2.4,smd)*(0.55+0.45*support)*(0.75+0.25*balance)
    avg=sum(raw.values())/max(len(raw),1)
    return {k:round(clamp(v/max(avg,1e-6),0.35,2.50),4) for k,v in raw.items()}

def _dist(a,b,features=None,weights=None):
    features=features or RALLY_FEATURES; weights=weights or {}
    if not a or not b:return 1.0
    sw=0.0;ss=0.0
    for k in features:
        w=max(0.05,float(weights.get(k,1.0)));d=float(a.get(k,0))-float(b.get(k,0));ss+=w*d*d;sw+=w
    return math.sqrt(ss/max(sw,1e-9))

def _fit_geometry(samples, features):
    pos=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==1]
    neg=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==0]
    w=_distance_weights(samples,features)
    return _mean_vectors(pos,features),_mean_vectors(neg,features),w

def _raw_match(v,pos,neg,features,weights):
    dp=_dist(v,pos,features,weights); dn=_dist(v,neg,features,weights) if neg else 1.0
    raw=clamp(50+(dn-dp)*72,0,100) if neg else clamp((1-dp)*100,0,100)
    trap=clamp((1-dn)*100,0,100) if neg else 0
    return raw,trap,dp,dn

def _pava(points):
    """Tiny isotonic regression for probability calibration, no external dependency."""
    blocks=[]
    for x,y,w in points:
        blocks.append([float(x),float(y),float(w),1])
        while len(blocks)>=2 and blocks[-2][1]>blocks[-1][1]:
            a=blocks.pop();b=blocks.pop();tw=b[2]+a[2]
            blocks.append([(b[0]*b[2]+a[0]*a[2])/tw,(b[1]*b[2]+a[1]*a[2])/tw,tw,b[3]+a[3]])
    return [{'x':round(x,4),'p':round(clamp(y,0.02,0.98),4),'n':int(round(w))} for x,y,w,_ in blocks]

def _build_calibration(points, min_oos=None):
    """Build a monotone calibration curve from strictly out-of-sample raw scores."""
    min_oos=RALLY_CAL_MIN_OOS if min_oos is None else int(min_oos)
    if len(points)<min_oos:return {'active':False,'count':len(points),'curve':[]}
    bins=[]
    for lo in range(0,100,10):
        ys=[y for raw,y in points if lo<=raw<(lo+10 if lo<90 else 101)]
        if ys:
            # Beta(2,2) smoothing prevents tiny bins from returning 0%/100% certainty.
            p=(sum(ys)+2)/(len(ys)+4);bins.append((lo+5,p,len(ys)))
    curve=_pava(bins)
    return {'active':len(curve)>=2,'count':len(points),'curve':curve}

def _apply_calibration(raw, calibration):
    curve=(calibration or {}).get('curve') or []
    if not (calibration or {}).get('active') or not curve:return clamp(raw/100,0.02,0.98)
    if raw<=curve[0]['x']:return curve[0]['p']
    if raw>=curve[-1]['x']:return curve[-1]['p']
    for a,b in zip(curve,curve[1:]):
        if a['x']<=raw<=b['x']:
            t=(raw-a['x'])/max(b['x']-a['x'],1e-9);return clamp(a['p']+(b['p']-a['p'])*t,0.02,0.98)
    return clamp(raw/100,0.02,0.98)

def _calibration_metrics(preds):
    if not preds:return {'count':0,'brier':None,'ece':None,'accuracy_60':None,'base_rate':None,'baseline_brier':None,'brier_skill':None,'precision_top20':None,'recall_top20':None,'lift_top20':None}
    n=len(preds);base=sum(y for _,y in preds)/n
    brier=sum((p-y)**2 for p,y in preds)/n
    baseline=sum((base-y)**2 for _,y in preds)/n
    bss=(1-brier/baseline) if baseline>1e-12 else None
    ece=0.0
    for lo in [i/10 for i in range(10)]:
        g=[(p,y) for p,y in preds if lo<=p<(lo+0.1 if lo<0.9 else 1.01)]
        if g:
            conf=sum(p for p,_ in g)/len(g);acc=sum(y for _,y in g)/len(g);ece+=len(g)/n*abs(conf-acc)
    selected=[y for p,y in preds if p>=0.60]
    acc60=(sum(selected)/len(selected)) if selected else None
    topn=max(1,math.ceil(n*0.20)); top=sorted(preds,key=lambda x:x[0],reverse=True)[:topn]
    precision=sum(y for _,y in top)/len(top) if top else None
    positives=sum(y for _,y in preds); recall=(sum(y for _,y in top)/positives) if positives else None
    lift=(precision/base) if precision is not None and base>0 else None
    return {'count':n,'brier':round(brier,4),'ece':round(ece,4),'accuracy_60':round(acc60,4) if acc60 is not None else None,'selected_60':len(selected),'base_rate':round(base,4),'baseline_brier':round(baseline,4),'brier_skill':round(bss,4) if bss is not None else None,'precision_top20':round(precision,4) if precision is not None else None,'recall_top20':round(recall,4) if recall is not None else None,'lift_top20':round(lift,3) if lift is not None else None}

def _validation_pass(calibration, min_count=20):
    m=(calibration or {}).get('metrics') or {}
    lift=m.get('lift_top20'); skill=m.get('brier_skill')
    return bool((calibration or {}).get('active') and int(m.get('count') or 0)>=min_count and m.get('brier') is not None and float(m.get('brier'))<=0.28 and m.get('ece') is not None and float(m.get('ece'))<=0.15 and skill is not None and float(skill)>0.02 and (lift is None or float(lift)>=1.10))

def _walk_forward_calibration(samples, features, min_train=20, min_oos=None):
    """Time-causal walk-forward validation and calibration.

    Each day's prediction is made from PRIOR days only.  Calibration used for that prediction is
    also built only from earlier out-of-sample predictions.  This provides a meaningful guard
    against the apparent-accuracy trap of measuring a centroid model on the same rows that built it.
    """
    rows=sorted(samples,key=lambda x:(str(x.get('day') or ''),float(x.get('event_ts') or 0)))
    days=sorted({str(x.get('day') or '') for x in rows if x.get('day')})
    prior=[];oos=[];seq_metrics=[]
    for day in days:
        test=[x for x in rows if str(x.get('day') or '')==day]
        if len(prior)>=min_train and any(int(x.get('label') or 0)==1 for x in prior) and any(int(x.get('label') or 0)==0 for x in prior):
            pos,neg,w=_fit_geometry(prior,features)
            prior_cal=_build_calibration([(r,y) for r,y in oos],min_oos)
            for x in test:
                raw,_,_,_=_raw_match(x.get('vector') or {},pos,neg,features,w)
                y=int(x.get('label') or 0)
                prob=_apply_calibration(raw,prior_cal)
                # Only evaluate calibrated probability once there was enough prior OOS data.
                if prior_cal.get('active'):seq_metrics.append((prob,y))
                oos.append((raw,y))
        prior.extend(test)
    final_cal=_build_calibration(oos,min_oos)
    metrics=_calibration_metrics(seq_metrics)
    metrics['oos_raw_count']=len(oos);metrics['calibration_active']=bool(final_cal.get('active'))
    return final_cal,metrics

def compact_jsonl(path:Path, keep:int, trigger:int):
    """Atomically compact append-only training ledgers to the newest unique rows."""
    if not path.exists():return {'compacted':False,'rows':0}
    try:
        lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()
        if len(lines)<=trigger:return {'compacted':False,'rows':len(lines)}
        seen=set();kept=[]
        for line in reversed(lines):
            try:
                x=json.loads(line);key=str(x.get('id') or line)
            except Exception:key=line
            if key in seen:continue
            seen.add(key);kept.append(line)
            if len(kept)>=keep:break
        kept.reverse();tmp=path.with_suffix(path.suffix+'.tmp')
        tmp.write_text(('\n'.join(kept)+'\n') if kept else '',encoding='utf-8');tmp.replace(path)
        return {'compacted':True,'rows':len(kept),'before':len(lines)}
    except Exception as e:return {'compacted':False,'error':str(e)[:120]}


def rally_vector(c:Candidate, override:dict|None=None):
    m=dict(c.metrics or {});m.update(override or {});sm=c.smart or {};fresh=smart_freshness(c) if 'smart_freshness' in globals() else {'program_fresh':False,'investor_fresh':False}
    inst_scale=max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1_000_000);prog_scale=max(abs(num(sm.get('program_net'))),100_000)
    return {
      'volume_accel':clamp((num(m.get('volume_accel'),1)-1)/2.5,0,1),
      'buy_pressure':clamp((num(m.get('buy_pressure'),50)-50)/30,-1,1),
      'algo_persistence':clamp((num(m.get('algo_persistence'),50)-50)/35,-1,1),
      'impulse':clamp(num(m.get('impulse_60s'))/2.5,-1,1),
      'vwap_gap':clamp(num(m.get('vwap_gap'))/1.5,-1,1),
      'micro_breakout':clamp(num(m.get('micro_breakout'))/1.5,0,1),
      'compression':clamp(num(m.get('compression')),0,1),
      'dual_venue':1.0 if m.get('dual_venue') else 0.0,
      'program_delta':clamp(num(sm.get('program_delta'))/prog_scale,-1,1) if fresh.get('program_fresh') else 0.0,
      'trust_delta':clamp(num(sm.get('trust_delta'))/inst_scale,-1,1) if fresh.get('investor_fresh') else 0.0,
      'pension_delta':clamp(num(sm.get('pension_delta'))/inst_scale,-1,1) if fresh.get('investor_fresh') else 0.0,
      'institution_delta':clamp(num(sm.get('institution_delta'))/inst_scale,-1,1) if fresh.get('investor_fresh') else 0.0,
      'sector':clamp(num(m.get('sector_score'))/max(SECTOR_MAX_BONUS,1),-1,1),
      'overlap':clamp(num(m.get('discovery_overlap'))/5,0,1),
      'orderbook':clamp(num(m.get('orderbook_presignal'))/max(ORDERBOOK_MAX_BONUS,1),-1,1),
      'event_signal':clamp(num(m.get('event_signal'))/max(MARKET_EVENT_MAX_BONUS,1),0,1),
    }

def rally_dna_type(v:dict, c:Candidate|None=None):
    scores={
      'ACCUMULATION':max(0,v.get('program_delta',0))+max(0,v.get('trust_delta',0))+max(0,v.get('pension_delta',0))+0.5*max(0,v.get('institution_delta',0))+0.5*max(0,v.get('buy_pressure',0)),
      'VOLUME_IGNITION':1.5*v.get('volume_accel',0)+v.get('buy_pressure',0)+0.8*v.get('algo_persistence',0)+0.5*v.get('impulse',0),
      'SECTOR_ROTATION':1.8*max(0,v.get('sector',0))+0.7*v.get('overlap',0)+0.5*v.get('volume_accel',0),
      'SQUEEZE_BREAKOUT':1.4*v.get('compression',0)+1.2*v.get('micro_breakout',0)+0.7*v.get('buy_pressure',0),
      'NEWS_SHOCK':2.0*max(0,v.get('event_signal',0))+1.2*max(0,v.get('impulse',0))+0.8*v.get('volume_accel',0)-0.4*v.get('compression',0),
      'ORDERBOOK_IGNITION':1.8*max(0,v.get('orderbook',0))+0.8*max(0,v.get('buy_pressure',0))+0.6*v.get('micro_breakout',0),
    }
    return max(scores,key=scores.get) if scores else 'UNCLASSIFIED'

def load_rally_state():
    try:
        if RALLY_MODEL_FILE.exists(): STATE.rally_model=json.loads(RALLY_MODEL_FILE.read_text(encoding='utf-8'))
    except Exception: STATE.rally_model={}
    try:
        if RALLY_REVIEW_FILE.exists(): STATE.rally_review=json.loads(RALLY_REVIEW_FILE.read_text(encoding='utf-8'))
    except Exception: STATE.rally_review={'reviewed_days':[]}
    try:
        if RALLY_TEACHER_AUDIT_FILE.exists(): STATE.teacher_audit=json.loads(RALLY_TEACHER_AUDIT_FILE.read_text(encoding='utf-8'))
    except Exception: STATE.teacher_audit={}
    if not isinstance(STATE.rally_review.get('reviewed_days'),list):STATE.rally_review['reviewed_days']=[]
    m=STATE.rally_model or {}; samples=int(m.get('samples') or 0); pos=int(m.get('positive') or 0)
    effective=m.get('effective_from_day'); cal=m.get('calibration') or {};teacher=STATE.teacher_audit or {}; teacher_recall=teacher.get('teacher_recall'); early5=teacher.get('early_recall_5pct'); teacher_gate=bool(int(teacher.get('movers') or 0)<5 or (teacher_recall is not None and float(teacher_recall)>=0.65 and early5 is not None and float(early5)>=0.50)); active=bool(samples>=RALLY_MIN_SAMPLES and effective and today_kst()>=str(effective) and is_krx_trading_day() and _validation_pass(cal,max(20,RALLY_CAL_MIN_OOS//2)) and teacher_gate)
    STATE.rally_status.update({'samples':samples,'positive':pos,'negative':max(0,samples-pos),'active':active,'effective_from_day':effective,'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'types':m.get('types') or {},'calibration':(m.get('calibration') or {}).get('metrics') or {},'distance_weights':m.get('distance_weights') or {},'validation_pass':_validation_pass(m.get('calibration') or {},max(20,RALLY_CAL_MIN_OOS//2)),'teacher_recall':teacher_recall,'early_recall_3pct':teacher.get('early_recall_3pct'),'early_recall_5pct':early5,'avg_first_trace_rate':teacher.get('avg_first_trace_rate'),'teacher_gate_pass':teacher_gate})

load_rally_state()

def _quality_transition(name:str, active:bool, metrics:dict):
    key=f'_quality_prev_{name}';prev=STATE.rally_status.get(key) if name=='RALLY' else STATE.exit_status.get(key)
    if prev is not None and bool(prev)!=bool(active):
        rec={'at':now_kst(),'model':name,'from':bool(prev),'to':bool(active),'metrics':metrics}
        try:
            with CALIB_ALERT_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
        except Exception:pass
        print('MODEL_QUALITY_TRANSITION',json.dumps(rec,ensure_ascii=False))
    if name=='RALLY':STATE.rally_status[key]=bool(active)
    else:STATE.exit_status[key]=bool(active)

def rally_model_status():
    m=STATE.rally_model or {}; samples=int(m.get('samples') or 0); effective=m.get('effective_from_day')
    cal=m.get('calibration') or {};teacher=STATE.teacher_audit or {}; teacher_recall=teacher.get('teacher_recall'); early5=teacher.get('early_recall_5pct'); teacher_gate=bool(int(teacher.get('movers') or 0)<5 or (teacher_recall is not None and float(teacher_recall)>=0.65 and early5 is not None and float(early5)>=0.50)); active=bool(samples>=RALLY_MIN_SAMPLES and effective and today_kst()>=str(effective) and is_krx_trading_day() and _validation_pass(cal,max(20,RALLY_CAL_MIN_OOS//2)) and teacher_gate)
    _quality_transition('RALLY',active,(m.get('calibration') or {}).get('metrics') or {})
    STATE.rally_status.update({'samples':samples,'positive':int(m.get('positive') or 0),'negative':int(m.get('negative') or 0),'active':active,'effective_from_day':effective,'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'types':m.get('types') or {},'calibration':(m.get('calibration') or {}).get('metrics') or {},'distance_weights':m.get('distance_weights') or {},'validation_pass':_validation_pass(m.get('calibration') or {},max(20,RALLY_CAL_MIN_OOS//2)),'teacher_recall':teacher_recall,'early_recall_3pct':teacher.get('early_recall_3pct'),'early_recall_5pct':early5,'avg_first_trace_rate':teacher.get('avg_first_trace_rate'),'teacher_gate_pass':teacher_gate})
    return STATE.rally_status

def rally_live_match(c:Candidate, override:dict|None=None):
    v=rally_vector(c,override); dna=rally_dna_type(v,c); st=rally_model_status(); m=STATE.rally_model or {}
    out={'active':False,'match':None,'raw_match':None,'trap':None,'bonus':0.0,'type':dna,'samples':int(st.get('samples') or 0),'effective_from_day':st.get('effective_from_day'),'calibration':(m.get('calibration') or {}).get('metrics') or {}}
    if not st.get('active'):return out
    pos=m.get('positive_centroid') or {}; neg=m.get('negative_centroid') or {};dw=m.get('distance_weights') or {}
    type_centroids=(m.get('type_centroids') or {})
    type_best=dna; type_sim=-1
    for typ,rec in type_centroids.items():
        if int(rec.get('count') or 0)<3:continue
        sim=1-_dist(v,rec.get('centroid') or {},RALLY_FEATURES,dw)
        if sim>type_sim:type_sim=sim;type_best=typ
    raw,trap,dp,dn=_raw_match(v,pos,neg,RALLY_FEATURES,dw)
    cal=m.get('calibration') or {};prob=_apply_calibration(raw,cal)*100
    # If calibration is not mature, keep the geometric score but clearly mark it uncalibrated.
    match=prob if cal.get('active') else raw
    confidence=min(1.0,int(m.get('samples') or 0)/120.0)
    bonus=0.0
    if match>=58:bonus+=(match-58)/42*RALLY_MAX_BONUS*confidence
    if trap>=62 and trap>match:bonus-=(trap-62)/38*RALLY_MAX_PENALTY*confidence
    if num(c.rate)>=10:bonus=min(bonus,0.0)
    out.update({'active':True,'match':round(match,1),'raw_match':round(raw,1),'trap':round(trap,1),'bonus':round(clamp(bonus,-RALLY_MAX_PENALTY,RALLY_MAX_BONUS),1),'type':type_best,'vector':v,'distance_to_rally':round(dp,4),'distance_to_trap':round(dn,4),'calibrated':bool(cal.get('active'))})
    return out

def _trace_record(c:Candidate):
    return {'ts':round(time.time(),3),'c':c.code,'n':c.name,'p':c.last_price,'ps':c.last_price_source or ('WS_0B' if c.last_tick_at else 'REST_RANK'),'r':c.rate,'s':c.score,'st':c.stage,'tier':c.ws_tier,'sec':c.sector,'v':rally_vector(c)}

def append_rally_trace():
    sess=market_session()
    if not sess.get('active'):return 0
    # Teacher trace intentionally covers far beyond the WS core.  Any candidate with a recent real tick
    # or a fresh discovery source is eligible, so the learner is less likely to study only its own winners.
    now=time.time();picks=[];seen=set()
    for c in ranked():
        if c.code in seen:continue
        if len(picks)>=RALLY_TRACE_TOP:break
        source_fresh=any(now-ts<=SOURCE_TTL_SECONDS for ts in (c.source_last_seen or {}).values())
        tick_fresh=bool(c.last_tick_at and now-c.last_tick_at<=DISPLAY_FRESH_MS)
        if c.last_price>0 and (tick_fresh or source_fresh):
            picks.append(c);seen.add(c.code)
    if not picks:return 0
    path=rally_trace_file()
    with path.open('a',encoding='utf-8') as f:
        for c in picks:f.write(json.dumps(_trace_record(c),ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.rally_status['trace_rows_today']=int(STATE.rally_status.get('trace_rows_today') or 0)+len(picks)
    return len(picks)

async def teacher_universe_audit(day:str):
    """Post-close broad-market teacher audit with explicit early-discovery recall.

    Ranking snapshots are independent of the live NOVA score. We measure not just whether a final
    +10% mover was ever traced, but whether it entered the causal trace while still below +3/+5%.
    Missed names are audit-only; incomplete historical order-flow features are never fabricated.
    """
    trace_by=defaultdict(list);path=rally_trace_file(day)
    if path.exists():
        for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line);code=code6(x.get('c'))
                if code:trace_by[code].append((float(x.get('ts') or 0),num(x.get('r')),str(x.get('ps') or '')))
            except Exception:pass
    for code in trace_by:trace_by[code].sort()
    movers={};errors=[]
    for market in ('001','101'):
        for source,api_id,tpl in [x for x in RANK_SPECS if x[0] in ('change_leaders','volume_top','turnover_top')]:
            body={k:(market if v=='{market}' else v) for k,v in tpl.items()}
            try:
                status,j=await kiwoom_post('/api/dostk/rkinfo',api_id,body,priority=20)
                if status!=200 or int(j.get('return_code',0))!=0:continue
                for row in extract_rows(j)[:100]:
                    code,name=row_identity(row);rate=row_rate(row)
                    if code and rate>=RALLY_TARGET_RATE:
                        prev=movers.get(code) or {'code':code,'name':name,'rate':rate,'sources':[]}
                        prev['rate']=max(num(prev.get('rate')),rate);prev['name']=name or prev.get('name');prev['sources']=sorted(set((prev.get('sources') or [])+[source]));movers[code]=prev
            except Exception as e:errors.append(str(e)[:100])
    traced=[code for code in movers if trace_by.get(code)]
    missed=[code for code in movers if not trace_by.get(code)]
    before3=[];before5=[];first_rates=[]
    for code in traced:
        first=min(trace_by[code],key=lambda z:z[0]);first_rates.append(first[1])
        if first[1] < 3.0:before3.append(code)
        if first[1] < 5.0:before5.append(code)
    total=len(movers)
    recall=len(traced)/total if total else None
    r3=len(before3)/total if total else None;r5=len(before5)/total if total else None
    details=[]
    for code in missed[:80]:
        x=movers[code];details.append({'code':code,'name':x.get('name'),'rate':x.get('rate'),'sources':x.get('sources')})
    audit={'day':day,'at':now_kst(),'movers':total,'traced_movers':len(traced),'missed_movers':len(missed),'teacher_recall':round(recall,4) if recall is not None else None,'traced_before_3pct':len(before3),'traced_before_5pct':len(before5),'early_recall_3pct':round(r3,4) if r3 is not None else None,'early_recall_5pct':round(r5,4) if r5 is not None else None,'avg_first_trace_rate':round(sum(first_rates)/len(first_rates),3) if first_rates else None,'missed':missed[:80],'missed_details':details,'errors':errors[:10],'note':'Missed movers remain audit-only; historical order-flow is not fabricated.'}
    STATE.teacher_audit=audit
    tmp=RALLY_TEACHER_AUDIT_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(audit,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(RALLY_TEACHER_AUDIT_FILE)
    return audit

def _weighted_pre_vector(rows,event_ts):
    targets=[(3600,0.10),(1800,0.20),(900,0.30),(300,0.40)]; picked=[]; total=0.0; timeline={}
    for sec,w in targets:
        before=[x for x in rows if x['ts']<=event_ts-sec]
        if not before:continue
        x=max(before,key=lambda z:z['ts']); age=event_ts-x['ts']
        if age>sec+600:continue
        picked.append((x.get('v') or {},w));total+=w;timeline[f'T-{sec//60}m']={'ts':x['ts'],'rate':x.get('r'),'score':x.get('s'),'vector':x.get('v') or {}}
    if not picked:return None,timeline
    return {k:round(sum(v.get(k,0)*w for v,w in picked)/total,6) for k in RALLY_FEATURES},timeline

def _forward_stats(rows,idx,seconds=1800):
    base=num(rows[idx].get('p')); end_ts=rows[idx]['ts']+seconds; fw=[x for x in rows[idx:] if x['ts']<=end_ts and num(x.get('p'))>0]
    if not base or not fw:return {'mfe':0.0,'mae':0.0,'end':0.0}
    rets=[(num(x.get('p'))/base-1)*100 for x in fw]
    return {'mfe':round(max(rets),2),'mae':round(min(rets),2),'end':round(rets[-1],2)}

def rebuild_rally_model(review_day:str):
    samples=[];seen=set()
    if RALLY_SAMPLE_FILE.exists():
        for line in RALLY_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line); sid=str(x.get('id') or '')
                if sid and sid not in seen:seen.add(sid);samples.append(x)
            except Exception:pass
    samples=samples[-RALLY_SAMPLE_KEEP:]
    pos_rows=[x for x in samples if int(x.get('label') or 0)==1];neg_rows=[x for x in samples if int(x.get('label') or 0)==0]
    pos=[x.get('vector') or {} for x in pos_rows];neg=[x.get('vector') or {} for x in neg_rows]
    distance_weights=_distance_weights(samples,RALLY_FEATURES)
    types={}; type_centroids={}
    for x in pos_rows:
        typ=str(x.get('dna_type') or 'UNCLASSIFIED');types[typ]=types.get(typ,0)+1
    for typ,count in types.items():
        vs=[x.get('vector') or {} for x in pos_rows if str(x.get('dna_type') or 'UNCLASSIFIED')==typ]
        type_centroids[typ]={'count':len(vs),'centroid':_mean_vectors(vs,RALLY_FEATURES)}
    calibration,cal_metrics=_walk_forward_calibration(samples,RALLY_FEATURES,min_train=max(20,RALLY_MIN_SAMPLES//2))
    calibration['metrics']=cal_metrics
    eff=_next_effective_day(review_day)
    model={'version':'RALLY_DNA_V3_TRUTH_ORDERBOOK_EVENTS','samples':len(samples),'positive':len(pos),'negative':len(neg),'positive_centroid':_mean_vectors(pos,RALLY_FEATURES),'negative_centroid':_mean_vectors(neg,RALLY_FEATURES),'distance_weights':distance_weights,'types':types,'type_centroids':type_centroids,'calibration':calibration,'last_review_day':review_day,'last_review_at':now_kst(),'effective_from_day':eff,'min_samples':RALLY_MIN_SAMPLES,'leakage_guard':'EOD_REVIEW_NEXT_DAY_ONLY','validation':'DAY_BLOCKED_WALK_FORWARD'}
    tmp=RALLY_MODEL_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(RALLY_MODEL_FILE);STATE.rally_model=model;rally_model_status();return model

def review_rally_day(day:str):
    path=rally_trace_file(day)
    if not path.exists():return {'day':day,'samples_added':0,'reason':'trace_missing'}
    groups=defaultdict(list)
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        try:
            x=json.loads(line); code=code6(x.get('c')); ts=float(x.get('ts') or 0)
            if code and ts:groups[code].append(x)
        except Exception:pass
    # Existing IDs prevent duplicate review after restart.
    existing=set()
    if RALLY_SAMPLE_FILE.exists():
        for line in RALLY_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:existing.add(str(json.loads(line).get('id') or ''))
            except Exception:pass
    added=[]
    for code,rows in groups.items():
        rows.sort(key=lambda x:x['ts'])
        if len(rows)<6:continue
        peak_rate=max(num(x.get('r')) for x in rows)
        # Positive: learn the state BEFORE the first +5% area only if the next 30m truly expands.
        if peak_rate>=RALLY_TARGET_RATE:
            last_event_ts=-10**18
            for i,x in enumerate(rows):
                if num(x.get('r'))<RALLY_TRIGGER_RATE or float(x['ts'])-last_event_ts<RALLY_EPISODE_GAP_SECONDS:continue
                f=_forward_stats(rows,i,1800)
                if f['mfe']<3.0:continue
                vec,timeline=_weighted_pre_vector(rows,rows[i]['ts'])
                if not vec:continue
                stats=f; grade='A' if stats['mfe']>=7 or max(num(z.get('r')) for z in rows[i:])>=20 else 'B' if stats['mfe']>=4 else 'C'
                typ=rally_dna_type(vec);sid=f'{day}:{code}:RALLY:{int(rows[i]["ts"])}'
                if sid not in existing:
                    added.append({'id':sid,'day':day,'code':code,'name':rows[i].get('n'),'label':1,'kind':'RALLY','grade':grade,'dna_type':typ,'event_ts':rows[i]['ts'],'event_rate':rows[i].get('r'),'peak_rate':peak_rate,'mfe_30m':stats['mfe'],'mae_30m':stats['mae'],'end_30m':stats['end'],'vector':vec,'timeline':timeline,'episode_gap_sec':RALLY_EPISODE_GAP_SECONDS})
                    existing.add(sid);last_event_ts=float(rows[i]['ts'])
        # Negative teacher: strong-looking pressure that fails to expand and suffers adverse movement.
        cand=[(i,x) for i,x in enumerate(rows) if num(x.get('s'))>=65 and 0<=num(x.get('r'))<=8]
        last_trap_ts=-10**18
        for i,x in sorted(cand,key=lambda z:float(z[1].get('ts') or 0)):
            if float(x['ts'])-last_trap_ts<RALLY_EPISODE_GAP_SECONDS:continue
            stats=_forward_stats(rows,i,1800)
            if stats['mfe']<1.8 and (stats['mae']<=-1.2 or stats['end']<=-0.5):
                vec=x.get('v') or {};sid=f'{day}:{code}:TRAP:{int(x["ts"])}'
                if sid not in existing and vec:
                    added.append({'id':sid,'day':day,'code':code,'name':x.get('n'),'label':0,'kind':'TRAP','grade':'TRAP','dna_type':rally_dna_type(vec),'event_ts':x['ts'],'event_rate':x.get('r'),'peak_rate':peak_rate,'mfe_30m':stats['mfe'],'mae_30m':stats['mae'],'end_30m':stats['end'],'vector':vec,'episode_gap_sec':RALLY_EPISODE_GAP_SECONDS})
                    existing.add(sid);last_trap_ts=float(x['ts'])
    if added:
        with RALLY_SAMPLE_FILE.open('a',encoding='utf-8') as f:
            for x in added:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    reviewed=set(STATE.rally_review.get('reviewed_days') or []);reviewed.add(day)
    STATE.rally_review={'reviewed_days':sorted(reviewed)[-120:],'last_review_day':day,'last_review_at':now_kst(),'last_added':len(added)}
    comp=compact_jsonl(RALLY_SAMPLE_FILE,RALLY_SAMPLE_KEEP,RALLY_SAMPLE_COMPACT_TRIGGER)
    STATE.rally_review['sample_compaction']=comp
    tmp=RALLY_REVIEW_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(STATE.rally_review,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(RALLY_REVIEW_FILE)
    model=rebuild_rally_model(day)
    return {'day':day,'samples_added':len(added),'model_samples':model.get('samples'),'positive':model.get('positive'),'negative':model.get('negative'),'effective_from_day':model.get('effective_from_day')}

def prune_rally_traces():
    cutoff=(datetime.now(KST)-timedelta(days=RALLY_TRACE_KEEP_DAYS)).strftime('%Y%m%d')
    for p in DATA_DIR.glob('rally_trace_*.jsonl'):
        m=re.search(r'(\d{8})',p.name)
        if m and m.group(1)<cutoff:
            try:p.unlink()
            except Exception:pass

async def rally_trace_loop():
    while True:
        try:
            if market_session().get('active') and time.time()-STATE.last_rally_trace>=RALLY_TRACE_INTERVAL:
                append_rally_trace();STATE.last_rally_trace=time.time()
        except Exception as e:STATE.rally_status['trace_error']=str(e)[:120]
        await asyncio.sleep(5)

async def rally_review_loop():
    await asyncio.sleep(8)
    while True:
        try:
            reviewed=set(STATE.rally_review.get('reviewed_days') or []); today=today_kst(); sec=kst_seconds()
            # Recover missed reviews first, then review today's trace after all NXT trading has ended.
            days=[]
            for p in sorted(DATA_DIR.glob('rally_trace_*.jsonl')):
                m=re.search(r'(\d{8})',p.name)
                if m and m.group(1)<today and m.group(1) not in reviewed:days.append(m.group(1))
            if sec>=20*3600+5*60 and rally_trace_file(today).exists() and today not in reviewed:days.append(today)
            for d in days[-3:]:
                # Broad ranking APIs are current-session snapshots. Never attach today's rank to an older trace day.
                if d==today:
                    STATE.rally_status['teacher_audit']=await teacher_universe_audit(d)
                STATE.rally_status['last_review_result']=review_rally_day(d)
            prune_rally_traces();rally_model_status()
        except Exception as e:STATE.rally_status['review_error']=str(e)[:160]
        await asyncio.sleep(60)


def exit_trace_file(day:str|None=None):
    return DATA_DIR/f"exit_trace_{day or today_kst()}.jsonl"

def persist_exit_positions():
    try:
        tmp=EXIT_POSITION_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps({'version':APP_VERSION,'updated_at':now_kst(),'positions':STATE.exit_positions},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        tmp.replace(EXIT_POSITION_FILE)
    except Exception:pass

def load_exit_state():
    try:
        if EXIT_MODEL_FILE.exists():STATE.exit_model=json.loads(EXIT_MODEL_FILE.read_text(encoding='utf-8'))
    except Exception:STATE.exit_model={}
    try:
        if EXIT_REVIEW_FILE.exists():STATE.exit_review=json.loads(EXIT_REVIEW_FILE.read_text(encoding='utf-8'))
    except Exception:STATE.exit_review={'reviewed_days':[]}
    if not isinstance(STATE.exit_review.get('reviewed_days'),list):STATE.exit_review['reviewed_days']=[]
    try:
        if EXIT_POSITION_FILE.exists():
            d=json.loads(EXIT_POSITION_FILE.read_text(encoding='utf-8'))
            STATE.exit_positions=dict(d.get('positions') or {})
    except Exception:STATE.exit_positions={}
    # Backfill today's BUY captures after an upgrade/restart, so exit management does not silently
    # ignore positions confirmed by the previous build earlier in the same session.
    for c in STATE.candidates.values():
        for key,cap in c.captures.items():
            if cap.stage!='BUY':continue
            entry_id=str(key).split('BUY@',1)[-1] if 'BUY@' in str(key) else f'{c.code}:{int(cap.at)}'
            if entry_id in STATE.exit_positions:continue
            if fmt_kst(cap.at,'%Y%m%d')!=today_kst():continue
            STATE.exit_positions[entry_id]={
              'entry_id':entry_id,'day':today_kst(),'code':c.code,'name':c.name,'entry_at':cap.at,'entry_price':cap.price,'entry_score':cap.score,
              'route':'LEGACY_BUY','entry_venue':(cap.venue if cap.venue in ('KRX','NXT') else 'AUTO'),'entry_venue_strength':None,'range5_at_entry':num(c.metrics.get('range5_pct')),'status':'OPEN','current_return':cap.current_return,
              'mfe':cap.max_return,'mae':cap.min_return,'last_action':'HOLD','last_action_at':0,'add_on_count':0,'entry_features':cap.features or {}
            }
    persist_exit_positions();exit_model_status()

def exit_model_status():
    m=STATE.exit_model or {};samples=int(m.get('samples') or 0);eff=m.get('effective_from_day')
    cal=m.get('calibration') or {};active=bool(samples>=EXIT_MIN_SAMPLES and eff and today_kst()>=str(eff) and is_krx_trading_day() and _validation_pass(cal,max(20,EXIT_CAL_MIN_OOS//2)))
    STATE.exit_status.update({'samples':samples,'exit':int(m.get('positive') or 0),'hold':int(m.get('negative') or 0),'active':active,'effective_from_day':eff,'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'calibration':(m.get('calibration') or {}).get('metrics') or {},'distance_weights':m.get('distance_weights') or {},'validation_pass':_validation_pass(m.get('calibration') or {},max(20,EXIT_CAL_MIN_OOS//2))})
    return STATE.exit_status

def exit_vector(c:Candidate,pos:dict):
    venue=str(pos.get('entry_venue') or pos.get('venue') or c.venue or 'AUTO').upper();flow=venue_flow_snapshot(c,venue)
    m=c.metrics or {};sm=flow.get('smart') or {};fresh=flow.get('fresh') or {};mfe=num(pos.get('mfe'));ret=num(pos.get('current_return'));giveback=max(0,mfe-ret);prog=num(flow.get('program_delta')) if fresh.get('program_fresh') else 0.0;prog_scale=max(abs(num(sm.get('program_net'))),100000)
    current_strength=venue_exit_strength(c,venue) if venue in ('KRX','NXT') else num(c.score);entry_strength=num(pos.get('entry_venue_strength')) or current_strength
    return {'giveback':clamp(giveback/4.0,0,1),'mfe':clamp(mfe/8.0,0,1),'current_return':clamp(ret/5.0,-1,1),'score_drop':clamp((entry_strength-current_strength)/35.0,-1,1),'buy_pressure_fade':clamp((60-num(flow.get('buy_pressure'),50))/25.0,-1,1),'algo_fade':clamp((60-num(flow.get('algo'),50))/25.0,-1,1),'vwap_break':clamp(-num(flow.get('vwap_gap'))/1.5,0,1),'program_reversal':clamp(-prog/prog_scale,-1,1),'sector_weak':clamp(-num(m.get('sector_score'))/3.0,0,1),'breakout_fade':clamp((0.20-num(flow.get('breakout')))/0.60,0,1),'impulse_fade':clamp(-num(flow.get('impulse'))/2.0,0,1)}

def exit_dna_type(v:dict):
    scores={
      'MFE_GIVEBACK':1.8*v.get('giveback',0)+0.7*v.get('mfe',0),
      'FLOW_REVERSAL':1.3*max(0,v.get('program_reversal',0))+v.get('buy_pressure_fade',0)+v.get('algo_fade',0),
      'VWAP_BREAK':1.7*v.get('vwap_break',0)+0.8*v.get('score_drop',0),
      'MOMENTUM_FADE':v.get('score_drop',0)+v.get('breakout_fade',0)+v.get('impulse_fade',0),
      'SECTOR_FADE':1.6*v.get('sector_weak',0)+0.6*v.get('score_drop',0),
    }
    return max(scores,key=scores.get) if scores else 'UNCLASSIFIED'

def exit_live_match(c:Candidate,pos:dict):
    st=exit_model_status();m=STATE.exit_model or {};v=exit_vector(c,pos)
    out={'active':False,'probability':None,'raw_probability':None,'type':exit_dna_type(v),'samples':int(st.get('samples') or 0),'effective_from_day':st.get('effective_from_day'),'calibrated':False}
    if not st.get('active'):return out
    raw,_,dp,dn=_raw_match(v,m.get('positive_centroid') or {},m.get('negative_centroid') or {},EXIT_FEATURES,m.get('distance_weights') or {})
    cal=m.get('calibration') or {};prob=_apply_calibration(raw,cal)*100
    out.update({'active':True,'probability':round(prob if cal.get('active') else raw,1),'raw_probability':round(raw,1),'type':exit_dna_type(v),'calibrated':bool(cal.get('active')),'distance_to_exit':round(dp,4),'distance_to_hold':round(dn,4),'vector':v})
    return out

def _exit_action_event(pos:dict,c:Candidate,action:str,reason:str,dna:dict):
    venue=str(pos.get('entry_venue') or pos.get('venue') or c.venue or 'AUTO').upper()
    flow=venue_flow_snapshot(c,venue) if venue in ('KRX','NXT') else {'smart':c.smart or {},'buy_pressure':num(c.metrics.get('buy_pressure')),'orderbook':num(c.metrics.get('orderbook_presignal')),'vwap_gap':num(c.metrics.get('vwap_gap'))}
    sm=flow.get('smart') or {}
    rec={'event':'EXIT_MANAGEMENT_SIGNAL','version':APP_VERSION,'day':today_kst(),'entry_id':pos.get('entry_id'),'code':c.code,'name':c.name,'at':time.time(),'at_kst':now_kst(),'action':action,'reason':reason,'price':num(pos.get('current_price')),'current_return':pos.get('current_return'),'mfe':pos.get('mfe'),'mae':pos.get('mae'),'giveback':pos.get('giveback'),'protect_floor':pos.get('protect_floor'),'dynamic_stop':pos.get('dynamic_stop'),'exit_dna':dna,'metrics':{'score':(venue_exit_strength(c,venue) if venue in ('KRX','NXT') else c.score),'venue':venue,'buy_pressure':flow.get('buy_pressure'),'orderbook_presignal':flow.get('orderbook'),'vwap_gap':flow.get('vwap_gap'),'program_delta':sm.get('program_delta'),'institution_delta':sm.get('institution_delta'),'sector_score':c.metrics.get('sector_score')}}
    with EXIT_ACTION_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')

def _auto_exit_protect_floor(mfe:float, mode:str='NORMAL'):
    """Base automatic EXIT-DNA profit floor. ELITE deliberately gives winners more room early."""
    mode=str(mode or 'NORMAL').upper()
    if mode=='ELITE':
        if mfe>=35:return 18.0
        if mfe>=22:return 10.0
        if mfe>=12:return 4.0
        return None
    if mfe>=7:return EXIT_PROTECT_MFE7
    if mfe>=4:return EXIT_PROTECT_MFE4
    if mfe>=2:return EXIT_PROTECT_MFE2
    return None

def _auto_exit_runner_trail_floor(mfe:float, mode:str='NORMAL'):
    """ELITE automatic runner trail: after TP2 territory, allow a 9% pullback from MFE."""
    if str(mode or 'NORMAL').upper()=='ELITE' and mfe>=22:return mfe-9.0
    return None

def update_exit_positions_for_candidate(c:Candidate):
    now=time.time();changed=False
    for entry_id,pos in list(STATE.exit_positions.items()):
        if str(pos.get('code'))!=c.code or pos.get('status') not in ('OPEN','EXIT_SIGNALED'):continue
        entry=num(pos.get('entry_price'))
        if entry<=0:continue
        venue=str(pos.get('entry_venue') or pos.get('venue') or c.venue or 'AUTO').upper();market_price=num(c.last_price_by_venue.get(venue)) if venue in ('KRX','NXT') else num(c.last_price);market_at=num(c.last_tick_at_by_venue.get(venue)) if venue in ('KRX','NXT') else num(c.last_tick_at)
        if market_price<=0:continue
        ret=(market_price/entry-1)*100;mfe=max(num(pos.get('mfe')),ret);mae=min(num(pos.get('mae')),ret)
        giveback=max(0,mfe-ret);pos.update({'current_price':market_price,'market_venue':venue,'market_tick_at':market_at,'current_return':round(ret,2),'mfe':round(mfe,2),'mae':round(mae,2),'giveback':round(giveback,2),'updated_at':now_kst()})
        if pos.get('status')=='EXIT_SIGNALED':
            # Continue counterfactual tracking for 15 minutes so EOD EXIT-DNA can verify whether
            # the exit signal truly avoided a giveback or prematurely cut a continuing rally.
            if now-num(pos.get('exit_at'))>=900:pos['status']='CLOSED_TRACKED';changed=True
            c.metrics.update({'exit_action':'FULL_EXIT','exit_reason':pos.get('exit_reason'),'exit_mfe':round(mfe,2),'exit_mae':round(mae,2),'exit_giveback':round(giveback,2),'exit_dynamic_stop':pos.get('dynamic_stop'),'exit_protect_floor':pos.get('effective_protect_floor',pos.get('protect_floor')),'add_on_count':int(pos.get('add_on_count') or 0)})
            continue
        if venue in ('KRX','NXT') and num(pos.get('entry_venue_strength'))<=0:
            # Upgrade/restart compatibility: establish a venue-locked baseline once, never from the opposite market.
            pos['entry_venue_strength']=venue_exit_strength(c,venue);changed=True
        range5=max(0,num(pos.get('range5_at_entry')));dynamic_stop=-round(clamp(EXIT_STOP_MIN+0.45*range5,EXIT_STOP_MIN,EXIT_STOP_MAX),2)
        mode=str(pos.get('profit_mode') or 'NORMAL').upper();protect_floor=_auto_exit_protect_floor(mfe,mode);runner_trail_floor=_auto_exit_runner_trail_floor(mfe,mode)
        effective_protect=max([x for x in (protect_floor,runner_trail_floor) if x is not None],default=None)
        pos['dynamic_stop']=dynamic_stop;pos['protect_floor']=protect_floor;pos['runner_trail_floor']=round(runner_trail_floor,2) if runner_trail_floor is not None else None;pos['effective_protect_floor']=round(effective_protect,2) if effective_protect is not None else None;pos['profit_mode']=mode
        dna=exit_live_match(c,pos);pos['exit_dna_probability']=dna.get('probability');pos['exit_dna_type']=dna.get('type');pos['exit_dna_active']=dna.get('active');pos['exit_dna_calibrated']=dna.get('calibrated')
        action='HOLD';reason='추세 유지'
        # Hard risk controls are deterministic and do not wait for a learned model.
        if ret<=dynamic_stop:
            action='FULL_EXIT';reason=f'동적 손절 {dynamic_stop:.2f}% 이탈'
        elif effective_protect is not None and ret<=effective_protect and mfe>=2.0:
            if runner_trail_floor is not None and runner_trail_floor>=num(protect_floor,-999):
                action='FULL_EXIT';reason=f'ELITE runner 고점추적선 +{runner_trail_floor:.1f}% 이탈 · MFE {mfe:.1f}%'
            else:
                action='FULL_EXIT';reason=f'MFE {mfe:.1f}% 후 보호수익 {protect_floor:.1f}% 이탈'
        else:
            p=num(dna.get('probability'),0)
            if mode=='ELITE':
                if mfe>=8 and giveback>=max(2.5,mfe*0.45):
                    action='PARTIAL_EXIT';reason=f'ELITE MFE {mfe:.1f}% 대비 {giveback:.1f}% 큰 되돌림'
                elif dna.get('active') and p>=82 and mfe>=6 and giveback>=1.8:
                    action='PARTIAL_EXIT';reason=f'ELITE EXIT DNA {p:.0f}% · {dna.get("type")}'
                elif (dna.get('active') and p>=70 and mfe>=4 and giveback>=1.2):
                    action='PROTECT';reason=f'ELITE 수익보호 관찰 · 되돌림 {giveback:.1f}%'
            else:
                if mfe>=2.5 and giveback>=max(1.0,mfe*0.32):
                    action='PARTIAL_EXIT';reason=f'MFE {mfe:.1f}% 대비 {giveback:.1f}% 되돌림'
                elif dna.get('active') and p>=78 and mfe>=1.2 and giveback>=0.6:
                    action='PARTIAL_EXIT';reason=f'EXIT DNA {p:.0f}% · {dna.get("type")}'
                elif (dna.get('active') and p>=62 and mfe>=1.0) or (mfe>=2 and giveback>=0.7):
                    action='PROTECT';reason=f'수익보호 강화 · 되돌림 {giveback:.1f}%'
            if action=='HOLD':
                flow=venue_flow_snapshot(c,venue);smart_ok,_=venue_smart_direction_ok(c,venue) if venue in ('KRX','NXT') else smart_direction_ok(c);venue_strength=venue_exit_strength(c,venue) if venue in ('KRX','NXT') else num(c.score)
                elapsed=now-num(pos.get('entry_at'))
                add_ok=(int(pos.get('add_on_count') or 0)<1 and elapsed>=180 and EXIT_ADD_MIN_RETURN<=ret<=EXIT_ADD_MAX_RETURN and venue_strength>=68 and num(flow.get('buy_pressure'))>=60 and num(flow.get('algo'))>=60 and bool(flow.get('volume_accel_ready')) and num(flow.get('volume_accel'),1)>=1.30 and num(flow.get('breakout'))>=0.15 and smart_ok and not c.metrics.get('sector_overheat') and giveback<0.6)
                if add_ok:
                    action='ADD_ON_CANDIDATE';reason='수익권 새 고점·거래량·수급 재가속'
        prev=str(pos.get('last_action') or 'HOLD')
        if action!=prev:
            pos['last_action']=action;pos['last_action_at']=now;pos['last_action_reason']=reason;changed=True
            if action=='ADD_ON_CANDIDATE':pos['add_on_count']=int(pos.get('add_on_count') or 0)+1
            _exit_action_event(pos,c,action,reason,dna)
        if action=='FULL_EXIT':
            pos.update({'status':'EXIT_SIGNALED','exit_at':now,'exit_price':market_price,'exit_return':round(ret,2),'exit_reason':reason});changed=True
        c.metrics.update({'exit_action':action,'exit_reason':reason,'exit_dna_probability':dna.get('probability'),'exit_dna_type':dna.get('type'),'exit_dna_active':dna.get('active'),'exit_dna_calibrated':dna.get('calibrated'),'exit_mfe':round(mfe,2),'exit_mae':round(mae,2),'exit_giveback':round(giveback,2),'exit_dynamic_stop':dynamic_stop,'exit_protect_floor':protect_floor,'exit_profit_mode':mode,'add_on_count':int(pos.get('add_on_count') or 0)})
    if changed:persist_exit_positions()

def _manual_profit_mode(c:Candidate|None, style:str='SCALP', source_stage:str=''):
    if c is None:return 'NORMAL'
    m=c.metrics or {};score=num(c.score);dna=num(m.get('rally_dna_match'));rad=num(m.get('nxt_radar_score'));nxtish=bool(str(source_stage).startswith('CLOSE_') or str(source_stage).startswith('SECOND_') or str(source_stage).startswith('NXT') or c.venue=='NXT');bp=num(m.get('nxt_buy_pressure') if nxtish else m.get('buy_pressure'));acc=max(num(m.get('volume_accel'),1),num(m.get('nxt_volume_accel_30s'),1));ob=num(m.get('nxt_orderbook_presignal') if nxtish else m.get('orderbook_presignal'));stage=str(source_stage or c.nxt_alert_stage or c.stage)
    elite=(score>=82 and bp>=64 and acc>=1.55 and (dna>=90 or rad>=72 or stage=='EMERGENCY_IGNITION') and ob>=-0.5)
    strong=(score>=74 and bp>=60 and acc>=1.30 and (dna>=82 or rad>=55 or stage in ('IGNITION','EMERGENCY_IGNITION','SECOND_WAVE_BUY')))
    return 'ELITE' if elite else ('STRONG' if strong else 'NORMAL')

def _manual_plan(style:str, profit_mode:str='NORMAL'):
    style=str(style or '').upper();mode=str(profit_mode or 'NORMAL').upper()
    if style=='SCALP':
        if mode=='ELITE': tp1,tp1p,tp2,tp2p,trail=4.0,20.0,7.5,20.0,3.2
        elif mode=='STRONG': tp1,tp1p,tp2,tp2p,trail=3.5,25.0,6.5,25.0,2.7
        else: tp1,tp1p,tp2,tp2p,trail=MANUAL_SCALP_TP1,MANUAL_SCALP_TP1_PCT,MANUAL_SCALP_TP2,MANUAL_SCALP_TP2_PCT,2.3
        return {'style':'SCALP','profit_mode':mode,'tp1':tp1,'tp1_pct':tp1p,'tp2':tp2,'tp2_pct':tp2p,'runner_pct':max(0,100-tp1p-tp2p),'runner_trail_pct':trail,'hard_stop':None,'fade_confirm_sec':MANUAL_SCALP_FADE_CONFIRM}
    close_bet=(style=='CLOSE_BET')
    if mode=='ELITE': tp1,tp1p,tp2,tp2p,trail=12.0,15.0,22.0,20.0,9.0
    elif mode=='STRONG': tp1,tp1p,tp2,tp2p,trail=10.0,20.0,18.0,20.0,8.0
    else: tp1,tp1p,tp2,tp2p,trail=MANUAL_SWING_TP1,MANUAL_SWING_TP1_PCT,MANUAL_SWING_TP2,MANUAL_SWING_TP2_PCT,7.0
    return {'style':('CLOSE_BET' if close_bet else 'SWING'),'profit_mode':mode,'tp1':tp1,'tp1_pct':tp1p,'tp2':tp2,'tp2_pct':tp2p,'runner_pct':max(0,100-tp1p-tp2p),'runner_trail_pct':trail,'hard_stop':-MANUAL_SWING_STOP,'fade_confirm_sec':MANUAL_SWING_FADE_CONFIRM}

def _manual_market_snapshot(c:Candidate|None,pos:dict):
    if c is None:return num(pos.get('current_price')),0.0,str(pos.get('entry_venue') or 'AUTO'),None
    venue=str(pos.get('entry_venue') or 'AUTO').upper()
    if venue in ('KRX','NXT'):
        price=num(c.last_price_by_venue.get(venue));ts=num(c.last_tick_at_by_venue.get(venue));rate=num(c.last_rate_by_venue.get(venue))
        if price>0:return price,rate,venue,(time.time()-ts if ts else None)
        # Strict venue lock: never value an NXT position with KRX (or vice versa).
        return 0.0,0.0,venue,None
    return num(c.last_price),num(c.rate),str(c.venue or venue or 'AUTO'),(time.time()-c.last_tick_at if c.last_tick_at else None)

def persist_manual_positions():
    try:
        tmp=MANUAL_POSITION_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps({'version':APP_VERSION,'updated_at':now_kst(),'positions':STATE.manual_positions},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        tmp.replace(MANUAL_POSITION_FILE)
    except Exception:pass

def load_manual_positions():
    try:
        if MANUAL_POSITION_FILE.exists():
            d=json.loads(MANUAL_POSITION_FILE.read_text(encoding='utf-8'));STATE.manual_positions=dict(d.get('positions') or {})
    except Exception:STATE.manual_positions={}
    # Manual positions are explicit user state and must survive candidate TTL / application restarts.
    for pos in STATE.manual_positions.values():
        if pos.get('status')=='OPEN' and pos.get('code'):
            STATE.get(str(pos.get('code')),str(pos.get('name') or ''))

def _manual_event(pos:dict,event:str,reason:str='',price:float|None=None,extra:dict|None=None):
    rec={'event':event,'version':APP_VERSION,'day':today_kst(),'position_id':pos.get('position_id'),'code':pos.get('code'),'name':pos.get('name'),'style':pos.get('style'),'at':time.time(),'at_kst':now_kst(),'price':price,'reason':reason,'remaining_pct':pos.get('remaining_pct'),'signal':pos.get('signal'),'suggested_sell_pct':pos.get('suggested_sell_pct')}
    if extra:rec.update(extra)
    try:
        with MANUAL_POSITION_EVENT_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    except Exception:pass
    return rec

def _manual_push_signal(pos:dict,c:Candidate,signal:str,reason:str,sell_pct:float):
    if signal in ('HOLD','PROTECT','') or sell_pct<=0:return
    notified=list(pos.get('notified_signals') or [])
    key=signal
    if key in notified:return
    notified.append(key);pos['notified_signals']=notified[-20:]
    style_name='단타' if pos.get('style')=='SCALP' else ('종가배팅' if pos.get('style')=='CLOSE_BET' else '스윙');title=f"{c.name or c.code} · {style_name} 매도관리"
    body=f"{signal} · {sell_pct:.0f}% 권고 · {reason} · 현재 {num(pos.get('current_return')):+.1f}%"
    rec={'id':f"manual:{pos.get('position_id')}:{signal}",'code':c.code,'title':title,'body':body,'stage':'MANUAL_SELL','position_id':pos.get('position_id'),'signal':signal,'price':num(pos.get('current_price')),'current_return':pos.get('current_return')}
    try:
        loop=asyncio.get_running_loop();loop.create_task(send_push(rec),name='nova-manual-sell-push')
    except RuntimeError:pass

def _manual_flow_fade(c:Candidate,pos:dict):
    venue=str(pos.get('entry_venue') or 'AUTO').upper();m=c.metrics or {};flow=venue_flow_snapshot(c,venue) if venue in ('KRX','NXT') else {'buy_pressure':num(m.get('buy_pressure'),50),'algo':num(m.get('algo_persistence'),50),'orderbook':num(m.get('orderbook_presignal')),'program_delta':num(c.smart.get('program_delta')),'fresh':smart_freshness(c)};flags=[]
    if num(flow.get('buy_pressure'),50)<48:flags.append('공격매수 약화')
    if num(flow.get('algo'),50)<48:flags.append('매수틱 지속 약화')
    if num(flow.get('orderbook'))<=-1.2:flags.append(f'{venue} 호가 매도우위')
    vgap=num(m.get('nxt_micro_vwap_gap') if venue=='NXT' else m.get('micro_vwap_gap'));
    if vgap<=-0.25:flags.append(f'{venue} Micro VWAP 이탈')
    if num(flow.get('impulse'))<=-0.35:flags.append('1분 모멘텀 반전')
    if (flow.get('fresh') or {}).get('program_fresh') and num(flow.get('program_delta'))<0:flags.append(f'{venue} 프로그램 매도전환')
    dna=exit_live_match(c,pos);p=num(dna.get('probability'))
    if dna.get('active') and p>=78:flags.append(f"EXIT DNA {p:.0f}%")
    return flags,dna

def _manual_protect_floor(style:str,mfe:float,mode:str='NORMAL'):
    mode=str(mode or 'NORMAL').upper()
    if style=='SCALP' and mode=='ELITE':
        # ELITE winners get room before TP1; protection tightens only after real extension.
        if mfe>=12:return 7.0
        if mfe>=7.5:return 3.5
        if mfe>=4.0:return 1.0
        return None
    if style=='SCALP':
        if mfe>=7:return 4.0
        if mfe>=4.5:return 2.0
        if mfe>=2.5:return 0.5
        return None
    if style in ('SWING','CLOSE_BET') and mode=='ELITE':
        # ELITE swing winners get more room: TP1/TP2 are +12/+22 and the 65% runner uses a 9% trail.
        # Protection rises later/lower than NORMAL so a strong trend is not clipped by ordinary pullbacks.
        if mfe>=35:return 18.0
        if mfe>=22:return 10.0
        if mfe>=12:return 4.0
        return None
    if mfe>=35:return 20.0
    if mfe>=20:return 12.0
    if mfe>=10:return 5.0
    return None

def update_manual_positions_for_candidate(c:Candidate):
    if c.last_price<=0:return
    now=time.time();changed=False
    for pid,pos in list(STATE.manual_positions.items()):
        if str(pos.get('code'))!=c.code or pos.get('status')!='OPEN':continue
        entry=num(pos.get('entry_price'))
        if entry<=0:continue
        style=str(pos.get('style') or 'SCALP').upper();mode=str(pos.get('profit_mode') or 'NORMAL').upper();plan=_manual_plan(style,mode)
        market_price,market_rate,market_venue,market_age=_manual_market_snapshot(c,pos)
        if market_price<=0:continue
        ret=(market_price/entry-1)*100;mfe=max(num(pos.get('mfe')),ret);mae=min(num(pos.get('mae')),ret);giveback=max(0,mfe-ret)
        pos.update({'current_price':market_price,'current_return':round(ret,2),'mfe':round(mfe,2),'mae':round(mae,2),'giveback':round(giveback,2),'updated_at':now_kst(),'last_tick_at':(time.time()-market_age if market_age is not None else 0),'market_venue':market_venue,'market_rate':market_rate,'market_age_sec':round(market_age,2) if market_age is not None else None})
        if market_age is not None and market_age>max(8.0,DISPLAY_FRESH_MS/1000):
            pos.update({'signal':'HOLD','signal_reason':f'{market_venue} 실체결 갱신대기 · {market_age:.1f}초','suggested_sell_pct':0.0,'plan':plan});continue
        if style=='SCALP':
            r5=max(0,num(pos.get('range5_at_entry')));hard=-round(clamp(MANUAL_SCALP_STOP_MIN+0.35*r5,MANUAL_SCALP_STOP_MIN,MANUAL_SCALP_STOP_MAX),2)
        else:hard=-MANUAL_SWING_STOP
        floor=_manual_protect_floor(style,mfe,mode);flags,dna=_manual_flow_fade(c,pos);threshold=2 if style=='SCALP' else 3
        if len(flags)>=threshold:
            if not num(pos.get('fade_since')):pos['fade_since']=now
        else:pos['fade_since']=0
        fade_confirm=bool(pos.get('fade_since') and now-num(pos.get('fade_since'))>=plan['fade_confirm_sec'])
        tp1_done=bool(pos.get('tp1_done'));tp2_done=bool(pos.get('tp2_done'));remaining=max(0,num(pos.get('remaining_pct'),100));prev=str(pos.get('signal') or 'HOLD')
        signal='HOLD';reason='추세 유지';sell_pct=0.0;urgent=False;trail_floor=None
        if style=='SCALP' and 19*3600+50*60<=kst_seconds()<20*3600+5*60:
            signal='SESSION_EXIT';reason='단타 익일 오버나이트 방지 · NXT 세션 종료 임박';sell_pct=remaining;urgent=True
        elif ret<=hard:
            signal='STOP_EXIT';reason=f'초기 손절선 {hard:.1f}% 이탈';sell_pct=remaining;urgent=True
        elif floor is not None and ret<=floor and mfe>floor+0.8:
            signal='PROFIT_LOCK_EXIT';reason=f'MFE {mfe:.1f}% 후 보호수익 +{floor:.1f}% 이탈';sell_pct=remaining;urgent=True
        elif prev in ('SESSION_EXIT','STOP_EXIT','PROFIT_LOCK_EXIT','RUNNER_TRAIL_EXIT','RUNNER_SIGNAL_EXIT','SELL_1','SELL_2','SELL_2_SHORT') and num(pos.get('suggested_sell_pct'))>0:
            signal=prev;reason=str(pos.get('signal_reason') or '미체결 매도권고 유지');sell_pct=min(remaining,num(pos.get('suggested_sell_pct')));urgent=prev in ('SESSION_EXIT','STOP_EXIT','PROFIT_LOCK_EXIT','RUNNER_TRAIL_EXIT')
        elif not tp1_done and ret>=plan['tp1']:
            signal='SELL_1';reason=f"1차 목표 +{plan['tp1']:.1f}% 도달";sell_pct=min(remaining,plan['tp1_pct'])
        elif tp1_done and not tp2_done and ret>=plan['tp2']:
            signal='SELL_2';reason=f"2차 목표 +{plan['tp2']:.1f}% 도달";sell_pct=min(remaining,plan['tp2_pct'])
        elif tp1_done and not tp2_done and fade_confirm and ret>=(1.0 if style=='SCALP' else 4.0):
            signal='SELL_2_SHORT';reason='단기 매도시그널 확인 · '+' · '.join(flags[:3]);sell_pct=min(remaining,plan['tp2_pct'])
        elif tp2_done:
            if style=='SCALP' and mfe>=plan['tp2']:
                trail_floor=max(floor if floor is not None else -999,mfe-num(plan.get('runner_trail_pct'),2.3))
            elif style in ('SWING','CLOSE_BET') and mfe>=15:
                trail_floor=max(floor if floor is not None else -999,mfe-num(plan.get('runner_trail_pct'),7.0))
            if trail_floor is not None and ret<=trail_floor:
                signal='RUNNER_TRAIL_EXIT';reason=f'추세물량 고점추적선 +{trail_floor:.1f}% 이탈';sell_pct=remaining;urgent=True
            elif fade_confirm and (giveback>=1.0 if style=='SCALP' else giveback>=2.5):
                signal='RUNNER_SIGNAL_EXIT';reason='추세물량 단기매도시그널 · '+' · '.join(flags[:3]);sell_pct=remaining
        elif fade_confirm:
            signal='PROTECT';reason='단기 약화 감지 · 목표도달 전 추세 확인 필요 · '+' · '.join(flags[:3])
        pos.update({'signal':signal,'signal_reason':reason,'suggested_sell_pct':round(sell_pct,1),'hard_stop_pct':hard,'protect_floor_pct':floor,'trail_floor_pct':round(trail_floor,2) if trail_floor is not None else None,'fade_flags':flags,'fade_score':len(flags),'fade_confirmed':fade_confirm,'exit_dna_probability':dna.get('probability'),'exit_dna_type':dna.get('type'),'urgent':urgent,'tp1_price':round(entry*(1+plan['tp1']/100),2),'tp2_price':round(entry*(1+plan['tp2']/100),2),'plan':plan})
        if signal!=prev:
            pos['signal_at']=now;changed=True;_manual_event(pos,'MANUAL_SELL_SIGNAL',reason,market_price,{'signal':signal,'sell_pct':sell_pct,'fade_flags':flags,'mfe':mfe,'giveback':giveback});_manual_push_signal(pos,c,signal,reason,sell_pct)
    if changed:persist_manual_positions()

def _manual_position_row(pos:dict):
    c=STATE.candidates.get(str(pos.get('code') or ''));entry=num(pos.get('entry_price'));cur,rate,venue,age=_manual_market_snapshot(c,pos)
    ret=((cur/entry-1)*100) if entry>0 and cur>0 else num(pos.get('current_return'))
    qty=num(pos.get('initial_qty'));remaining_pct=max(0,num(pos.get('remaining_pct'),100));remaining_qty=round(qty*remaining_pct/100,4) if qty>0 else None
    flow=venue_flow_snapshot(c,venue) if c and venue in ('KRX','NXT') else None
    return {**pos,'current_price':cur,'current_return':round(ret,2),'remaining_qty':remaining_qty,'last_tick_age_ms':round(age*1000) if age is not None else None,'venue':venue,'market_rate':rate,'fid9081':(c.last_fid9081_by_venue.get(venue) if c and venue in ('KRX','NXT') else c.last_fid9081 if c else None),'score':(venue_exit_strength(c,venue) if c and venue in ('KRX','NXT') else c.score if c else None),'buy_pressure':flow.get('buy_pressure') if flow else c.metrics.get('buy_pressure') if c else None,'volume_accel':flow.get('volume_accel') if flow else c.metrics.get('volume_accel') if c else None,'orderbook_presignal':flow.get('orderbook') if flow else c.metrics.get('orderbook_presignal') if c else None}

def manual_position_payload():
    rows=[_manual_position_row(x) for x in STATE.manual_positions.values()]
    rows.sort(key=lambda x:(x.get('status')=='OPEN',num(x.get('entry_at'))),reverse=True)
    return {'ok':True,'version':APP_VERSION,'generated_at':now_kst(),'count':len(rows),'open_count':sum(1 for x in rows if x.get('status')=='OPEN'),'plans':{'SCALP':{m:_manual_plan('SCALP',m) for m in ('NORMAL','STRONG','ELITE')},'SWING':{m:_manual_plan('SWING',m) for m in ('NORMAL','STRONG','ELITE')}},'rows':rows[:100],'note':'자동주문 아님. 실제 매수가·시장(KRX/NXT)과 실제 매도가를 사용자가 입력/수정하며, 선택한 시장 실체결만으로 손익·매도선을 계산합니다.'}

async def manual_position_loop():
    while True:
        try:
            if not realtime_runtime_awake():
                await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
            codes={str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN'}
            for code in codes:
                c=STATE.candidates.get(code)
                if c and c.last_price>0:update_manual_positions_for_candidate(c)
        except Exception as e:STATE.exit_status['manual_position_error']=str(e)[:160]
        await asyncio.sleep(2)

def append_exit_trace():
    sess=market_session()
    if not sess.get('active'):return 0
    rows=[]
    by_code={c.code:c for c in STATE.candidates.values()}
    for entry_id,pos in STATE.exit_positions.items():
        if pos.get('status') not in ('OPEN','EXIT_SIGNALED') or str(pos.get('day') or '')!=today_kst():continue
        c=by_code.get(str(pos.get('code') or ''));venue=str(pos.get('entry_venue') or pos.get('venue') or 'AUTO').upper()
        if not c:continue
        px=num(c.last_price_by_venue.get(venue)) if venue in ('KRX','NXT') else num(c.last_price)
        if px<=0:continue
        rows.append({'id':entry_id,'ts':round(time.time(),3),'day':today_kst(),'code':c.code,'name':c.name,'entry_price':pos.get('entry_price'),'entry_at':pos.get('entry_at'),'route':pos.get('route'),'venue':venue,'ret':pos.get('current_return'),'mfe':pos.get('mfe'),'mae':pos.get('mae'),'giveback':pos.get('giveback'),'score':venue_exit_strength(c,venue) if venue in ('KRX','NXT') else c.score,'action':pos.get('last_action'),'v':exit_vector(c,pos)})
    if rows:
        with exit_trace_file().open('a',encoding='utf-8') as f:
            for x in rows:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    return len(rows)

def _exit_forward_stats(rows,idx,seconds=600):
    base_ret=num(rows[idx].get('ret'));end=rows[idx]['ts']+seconds;fw=[x for x in rows[idx:] if x['ts']<=end]
    if not fw:return {'best_delta':0.0,'worst_delta':0.0,'end_delta':0.0}
    vals=[num(x.get('ret'))-base_ret for x in fw]
    return {'best_delta':round(max(vals),2),'worst_delta':round(min(vals),2),'end_delta':round(vals[-1],2)}

def rebuild_exit_model(review_day:str):
    samples=[];seen=set()
    if EXIT_SAMPLE_FILE.exists():
        for line in EXIT_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:
                x=json.loads(line);sid=str(x.get('id') or '')
                if sid and sid not in seen:seen.add(sid);samples.append(x)
            except Exception:pass
    samples=samples[-EXIT_SAMPLE_KEEP:]
    pos=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==1];neg=[x.get('vector') or {} for x in samples if int(x.get('label') or 0)==0]
    dw=_distance_weights(samples,EXIT_FEATURES);cal,metrics=_walk_forward_calibration(samples,EXIT_FEATURES,min_train=max(20,EXIT_MIN_SAMPLES//2),min_oos=EXIT_CAL_MIN_OOS);cal['metrics']=metrics
    eff=_next_effective_day(review_day)
    model={'version':'EXIT_DNA_V1_WEIGHTED_CALIBRATED','samples':len(samples),'positive':len(pos),'negative':len(neg),'positive_centroid':_mean_vectors(pos,EXIT_FEATURES),'negative_centroid':_mean_vectors(neg,EXIT_FEATURES),'distance_weights':dw,'calibration':cal,'last_review_day':review_day,'last_review_at':now_kst(),'effective_from_day':eff,'min_samples':EXIT_MIN_SAMPLES,'leakage_guard':'EOD_REVIEW_NEXT_DAY_ONLY','validation':'DAY_BLOCKED_WALK_FORWARD'}
    tmp=EXIT_MODEL_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(model,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(EXIT_MODEL_FILE);STATE.exit_model=model;exit_model_status();return model

def review_exit_day(day:str):
    path=exit_trace_file(day)
    if not path.exists():return {'day':day,'samples_added':0,'reason':'trace_missing'}
    groups=defaultdict(list)
    for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
        try:
            x=json.loads(line);eid=str(x.get('id') or '')
            if eid and x.get('ts'):groups[eid].append(x)
        except Exception:pass
    existing=set()
    if EXIT_SAMPLE_FILE.exists():
        for line in EXIT_SAMPLE_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
            try:existing.add(str(json.loads(line).get('id') or ''))
            except Exception:pass
    added=[]
    for eid,rows in groups.items():
        rows.sort(key=lambda x:x['ts'])
        if len(rows)<4:continue
        # EXIT teacher: meaningful MFE followed by a material giveback with no prompt recovery.
        exit_idx=None
        for i,x in enumerate(rows):
            mfe=num(x.get('mfe'));gb=num(x.get('giveback'))
            if mfe>=1.5 and gb>=max(0.8,mfe*0.28):
                fw=_exit_forward_stats(rows,i,600)
                if fw['best_delta']<0.9 and (fw['end_delta']<=-0.5 or fw['worst_delta']<=-0.8):exit_idx=i;break
        if exit_idx is not None:
            x=rows[exit_idx];sid=f'{day}:{eid}:EXIT:{int(x["ts"])}'
            if sid not in existing and x.get('v'):
                fw=_exit_forward_stats(rows,exit_idx,600);added.append({'id':sid,'day':day,'entry_id':eid,'code':x.get('code'),'name':x.get('name'),'label':1,'kind':'EXIT','dna_type':exit_dna_type(x.get('v') or {}),'event_ts':x['ts'],'ret':x.get('ret'),'mfe':x.get('mfe'),'giveback':x.get('giveback'),'forward_10m':fw,'vector':x.get('v') or {}});existing.add(sid)
        # HOLD teacher: at this point selling would have missed a clean subsequent extension.
        hold_candidates=[]
        for i,x in enumerate(rows[:-1]):
            if num(x.get('mfe'))<0.5:continue
            fw=_exit_forward_stats(rows,i,600)
            if fw['best_delta']>=1.5 and fw['worst_delta']>-0.9:hold_candidates.append((i,fw))
        if hold_candidates:
            i,fw=max(hold_candidates,key=lambda z:z[1]['best_delta']);x=rows[i];sid=f'{day}:{eid}:HOLD:{int(x["ts"])}'
            if sid not in existing and x.get('v'):
                added.append({'id':sid,'day':day,'entry_id':eid,'code':x.get('code'),'name':x.get('name'),'label':0,'kind':'HOLD','dna_type':'HOLD_CONTINUATION','event_ts':x['ts'],'ret':x.get('ret'),'mfe':x.get('mfe'),'giveback':x.get('giveback'),'forward_10m':fw,'vector':x.get('v') or {}});existing.add(sid)
    if added:
        with EXIT_SAMPLE_FILE.open('a',encoding='utf-8') as f:
            for x in added:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
    reviewed=set(STATE.exit_review.get('reviewed_days') or []);reviewed.add(day)
    STATE.exit_review={'reviewed_days':sorted(reviewed)[-120:],'last_review_day':day,'last_review_at':now_kst(),'last_added':len(added)}
    STATE.exit_review['sample_compaction']=compact_jsonl(EXIT_SAMPLE_FILE,EXIT_SAMPLE_KEEP,EXIT_SAMPLE_COMPACT_TRIGGER)
    tmp=EXIT_REVIEW_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(STATE.exit_review,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(EXIT_REVIEW_FILE)
    model=rebuild_exit_model(day)
    return {'day':day,'samples_added':len(added),'model_samples':model.get('samples'),'exit':model.get('positive'),'hold':model.get('negative'),'effective_from_day':model.get('effective_from_day')}

def prune_exit_traces():
    cutoff=(datetime.now(KST)-timedelta(days=EXIT_TRACE_KEEP_DAYS)).strftime('%Y%m%d')
    for p in DATA_DIR.glob('exit_trace_*.jsonl'):
        m=re.search(r'(\d{8})',p.name)
        if m and m.group(1)<cutoff:
            try:p.unlink()
            except Exception:pass

async def exit_trace_loop():
    while True:
        try:
            if market_session().get('active') and time.time()-STATE.last_exit_trace>=EXIT_TRACE_INTERVAL:
                append_exit_trace();STATE.last_exit_trace=time.time()
        except Exception as e:STATE.exit_status['trace_error']=str(e)[:120]
        await asyncio.sleep(5)

async def exit_review_loop():
    await asyncio.sleep(12)
    while True:
        try:
            reviewed=set(STATE.exit_review.get('reviewed_days') or []);today=today_kst();sec=kst_seconds();days=[]
            for p in sorted(DATA_DIR.glob('exit_trace_*.jsonl')):
                m=re.search(r'(\d{8})',p.name)
                if m and m.group(1)<today and m.group(1) not in reviewed:days.append(m.group(1))
            if sec>=20*3600+5*60 and exit_trace_file(today).exists() and today not in reviewed:days.append(today)
            for d in days[-3:]:STATE.exit_status['last_review_result']=review_exit_day(d)
            prune_exit_traces();exit_model_status()
        except Exception as e:STATE.exit_status['review_error']=str(e)[:160]
        await asyncio.sleep(60)

load_exit_state()
load_manual_positions()

def load_sector_overrides():
    try:
        if SECTOR_MAP_FILE.exists():
            d=json.loads(SECTOR_MAP_FILE.read_text(encoding='utf-8'))
            return {code6(k):str(v).strip() for k,v in d.items() if code6(k) and str(v).strip()}
    except Exception:
        pass
    return {}

SECTOR_OVERRIDES=load_sector_overrides()
try:
    SECTOR_OFFICIAL=json.loads(SECTOR_OFFICIAL_CACHE_FILE.read_text(encoding='utf-8')) if SECTOR_OFFICIAL_CACHE_FILE.exists() else {}
except Exception: SECTOR_OFFICIAL={}

def classify_sector(c:Candidate):
    if c.code in SECTOR_OVERRIDES:return SECTOR_OVERRIDES[c.code],'MAP'
    off=SECTOR_OFFICIAL.get(c.code) or {}
    if str(off.get('sector') or '').strip():return str(off['sector']).strip(),'KIWOOM_OFFICIAL'
    n=(c.name or '').upper().replace('㈜','').strip()
    if not n:return '미분류','NONE'
    if is_fund_like_name(n):return 'ETF·지수','ETF'
    for sector,keys in SECTOR_RULES:
        for k in keys:
            if str(k).upper() in n:return sector,'NAME'
    return '미분류','NONE'

def update_sector_context():
    """Refresh sector context and return only candidates whose sector-derived inputs changed.

    This keeps sector breadth accurate without forcing every realtime tick to rescore the whole universe.
    """
    before={c.code:(c.sector,c.sector_source,num(c.metrics.get('sector_score')),int(c.metrics.get('sector_breadth') or 0),str(c.metrics.get('sector_leader_code') or ''),num(c.metrics.get('sector_avg_rate')),bool(c.metrics.get('sector_follower')),bool(c.metrics.get('sector_overheat'))) for c in STATE.candidates.values()}
    now=time.time(); groups=defaultdict(list)
    for c in STATE.candidates.values():
        sector,src=classify_sector(c); c.sector=sector; c.sector_source=src
        c.metrics.update({'sector':sector,'sector_score':0.0,'sector_breadth':0,'sector_members':0,'sector_leader':'','sector_leader_code':'','sector_avg_rate':0.0,'sector_diffusion':0,'sector_follower':False,'sector_overheat':False})
        if sector in ('미분류','ETF·지수'): continue
        recent=(c.last_tick_at and now-c.last_tick_at<=90) or bool(c.source_hits)
        if recent: groups[sector].append(c)
    status={}
    for sector,members in groups.items():
        if len(members)<3:
            for c in members:c.metrics.update({'sector':sector,'sector_score':0.0,'sector_breadth':len(members),'sector_members':len(members),'sector_leader':'','sector_leader_code':'','sector_avg_rate':0.0,'sector_diffusion':0})
            continue
        rates=[num(c.rate) for c in members]
        avg=sum(rates)/len(rates)
        positive=sum(1 for c in members if c.rate>=0.7)
        active=sum(1 for c in members if num(c.metrics.get('volume_accel'),1)>=1.25 or num(c.metrics.get('buy_pressure'))>=54 or STAGE_RANK.get(c.stage,0)>=1)
        leader=max(members,key=lambda x:(x.rate,num(x.metrics.get('volume_accel'),1),num(x.metrics.get('buy_pressure')),len(x.source_hits)))
        breadth_ratio=positive/len(members); diffusion=active/len(members)
        base=0.0
        base+=clamp((positive-1)*1.15,0,3.5)
        base+=clamp((active-1)*0.8,0,2.4)
        base+=clamp((avg-0.3)*0.75,0,1.8)
        if num(leader.metrics.get('volume_accel'),1)>=1.25 and num(leader.metrics.get('buy_pressure'))>=55 and 0.8<=leader.rate<=10:base+=1.3
        if breadth_ratio>=0.60 and diffusion>=0.45:base+=1.0
        overheat=avg>6 or sum(1 for x in members if x.rate>10)>=max(2,len(members)//2)
        if avg>4.5:base-=1.5
        if overheat:base-=3.0
        base=clamp(base,-3,SECTOR_MAX_BONUS)
        for c in members:
            bonus=base
            follower=(c.code!=leader.code and 0<=c.rate<leader.rate and c.rate<8 and (num(c.metrics.get('volume_accel'),1)>=1.2 or num(c.metrics.get('buy_pressure'))>=53))
            if follower and 1.2<=leader.rate<=10:bonus+=1.2
            if c.code==leader.code and positive>=3:bonus+=0.5
            bonus=round(clamp(bonus,-3,SECTOR_MAX_BONUS),1)
            c.metrics.update({'sector':sector,'sector_score':bonus,'sector_breadth':positive,'sector_members':len(members),'sector_leader':leader.name or leader.code,'sector_leader_code':leader.code,'sector_avg_rate':round(avg,2),'sector_diffusion':active,'sector_follower':bool(follower),'sector_overheat':bool(overheat)})
        status[sector]={'score':round(base,1),'members':len(members),'breadth':positive,'diffusion':active,'avg_rate':round(avg,2),'leader':leader.name or leader.code,'leader_code':leader.code,'overheat':overheat}
    STATE.sector_status=dict(sorted(status.items(),key=lambda kv:(kv[1]['score'],kv[1]['breadth'],kv[1]['avg_rate']),reverse=True))
    changed=set()
    for c in STATE.candidates.values():
        after=(c.sector,c.sector_source,num(c.metrics.get('sector_score')),int(c.metrics.get('sector_breadth') or 0),str(c.metrics.get('sector_leader_code') or ''),num(c.metrics.get('sector_avg_rate')),bool(c.metrics.get('sector_follower')),bool(c.metrics.get('sector_overheat')))
        if before.get(c.code)!=after:changed.add(c.code)
    return changed


def train_from_mature_captures():
    """Label 30-minute BUY outcomes intraday, but stage weight changes for the next day only."""
    _activate_pending_learning_if_due()
    now=time.time(); changed=False; source_day=today_kst()
    # If a same-day pending model already exists, continue from its staged weights. Otherwise start
    # from the currently applied model. This lets all of today's labels contribute without letting
    # any of them affect today's rankings.
    pnd=STATE.learn.get('pending') or {}
    if pnd and str(pnd.get('source_day') or '')!=source_day:
        # A stale pending model should normally have been activated. Preserve safety rather than
        # blending days if the clock/data was unusual.
        if str(pnd.get('effective_from_day') or '')<=source_day:
            _activate_pending_learning_if_due(); pnd=STATE.learn.get('pending') or {}
    if not pnd:
        pnd={'source_day':source_day,'effective_from_day':_next_effective_day(source_day),'weights':dict(STATE.learn.get('weights') or BASE_FEATURE_WEIGHTS),'samples_delta':0,'positive_delta':0,'last_update':None}
    for c in STATE.candidates.values():
        for cap_key,cap in c.captures.items():
            if cap.stage!='BUY' or now-cap.at<1800: continue
            key=f'{c.code}:{cap_key}:{int(cap.at)}'
            if key in STATE.trained_ids: continue
            fv=cap.features or {}
            if not fv: fv=(c.metrics.get('capture_features') or {}).get(cap_key) or {}
            if not fv: continue
            y=1 if cap.current_return>=0.5 and cap.max_return>=2.0 and cap.min_return>-1.5 else 0
            STATE.trained_ids.add(key)
            STATE.learn['samples']=int(STATE.learn.get('samples') or 0)+1
            STATE.learn['positive']=int(STATE.learn.get('positive') or 0)+y
            pnd['samples_delta']=int(pnd.get('samples_delta') or 0)+1
            pnd['positive_delta']=int(pnd.get('positive_delta') or 0)+y
            w=pnd.setdefault('weights',dict(STATE.learn.get('weights') or BASE_FEATURE_WEIGHTS))
            effective_n=max(1,int(STATE.learn.get('applied_samples') or 0)+int(pnd.get('samples_delta') or 0))
            lr=0.035/max(1,(effective_n/80)**0.5)
            for k in FEATURE_KEYS:
                x=float(fv.get(k) or 0); direction=(1 if y else -1)
                w[k]=round(clamp(float(w.get(k,1.0))+direction*lr*x,1-LEARN_MAX_ADJUST,1+LEARN_MAX_ADJUST),4)
            pnd['last_update']=now_kst();STATE.learn['last_update']=now_kst();changed=True
            with TRAIN_FILE.open('a',encoding='utf-8') as f:
                f.write(json.dumps({'id':key,'label':y,'max_return':cap.max_return,'min_return':cap.min_return,'current_return':cap.current_return,'features':fv,'at':now_kst(),'source_day':source_day,'effective_from_day':pnd['effective_from_day'],'leakage_guard':'NEXT_DAY_ONLY'},ensure_ascii=False,separators=(',',':'))+'\n')
    if changed:
        STATE.learn['pending']=pnd
        # active reflects APPLIED weights only; pending labels never activate today's learner.
        STATE.learn['active']=int(STATE.learn.get('applied_samples') or 0)>=LEARN_MIN_SAMPLES
        persist_learning()


RANK_SPECS=[
 ('orderbook_buy','ka10020',{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]
WEIGHTS={'orderbook_buy':10,'bid_surge':17,'residual_ratio_surge':14,'volume_surge':20,'change_leaders':9,'volume_top':10,'turnover_top':15}
NXT_AFTER_RANK_SPECS=[('nxt_'+source,api_id,{**tpl,'stex_tp':'2'}) for source,api_id,tpl in RANK_SPECS]
NXT_FAST_RANK_SPECS=[x for x in NXT_AFTER_RANK_SPECS if x[0] in ('nxt_bid_surge','nxt_residual_ratio_surge','nxt_volume_surge','nxt_turnover_top')]
for _source,_api,_tpl in RANK_SPECS:WEIGHTS['nxt_'+_source]=round(WEIGHTS[_source]*1.25,2)
class RestPacer:
    """Priority start-rate limiter: request starts are spaced, network waits overlap.

    Kiwoom domestic query TRs are limited per token. NXT FAST discovery uses priority -10,
    SMART flow requests use 0, normal discovery uses 10, post-close teacher audits use 20.  This avoids the old mistake of holding
    the pacing lock for the full HTTP round trip.
    """
    def __init__(self, interval:float):
        self.interval=interval;self.q=asyncio.PriorityQueue();self.seq=0;self.task=None;self.last=0.0
    async def wait(self, priority:int=10):
        loop=asyncio.get_running_loop();fut=loop.create_future();self.seq+=1
        await self.q.put((int(priority),self.seq,fut))
        if self.task is None or self.task.done():self.task=asyncio.create_task(self._worker(),name='nova-rest-pacer')
        await fut
    async def _worker(self):
        while True:
            _,_,fut=await self.q.get()
            # A timed-out NXT FAST request may cancel while still queued. Ghost entries must
            # consume zero pacing budget or they delay the next real discovery request.
            if fut.cancelled():
                self.q.task_done();continue
            delay=self.interval-(time.monotonic()-self.last)
            if delay>0:await asyncio.sleep(delay)
            if fut.cancelled():
                self.q.task_done();continue
            self.last=time.monotonic();fut.set_result(True);self.q.task_done()
    def status(self):return {'queued':self.q.qsize(),'interval_ms':round(self.interval*1000),'max_inflight':REST_MAX_INFLIGHT,'priority':'nxt_radar(-10)>smart(0)>discovery(10)>teacher(20)'}

REST_PACER=RestPacer(REST_PACE_SECONDS)
_REST_CLIENT=None
_REST_CLIENT_LOCK=asyncio.Lock()
_REST_HTTP_SEM=asyncio.Semaphore(REST_MAX_INFLIGHT)

async def _rest_client():
    global _REST_CLIENT
    if _REST_CLIENT is not None:return _REST_CLIENT
    async with _REST_CLIENT_LOCK:
        if _REST_CLIENT is None:
            _REST_CLIENT=httpx.AsyncClient(timeout=httpx.Timeout(10.0,connect=5.0),limits=httpx.Limits(max_connections=REST_MAX_INFLIGHT,max_keepalive_connections=REST_MAX_INFLIGHT))
    return _REST_CLIENT

async def kiwoom_post(path, api_id, body, priority:int=10):
    token=await TOK.get();await REST_PACER.wait(priority)
    started=time.monotonic()
    async with _REST_HTTP_SEM:
        c=await _rest_client()
        try:
            r=await c.post(API+path,headers={'authorization':'Bearer '+token,'api-id':api_id,'Content-Type':'application/json;charset=UTF-8'},json=body)
            try:j=r.json()
            except Exception:j={'return_code':-999,'return_msg':r.text[:180]}
            STATE.rest_status['_pipeline']={**REST_PACER.status(),'last_latency_ms':round((time.monotonic()-started)*1000,1),'last_api_id':api_id,'at':time.time()}
            return r.status_code,j
        except Exception:
            STATE.rest_status['_pipeline']={**REST_PACER.status(),'last_latency_ms':round((time.monotonic()-started)*1000,1),'last_api_id':api_id,'at':time.time(),'last_error':True}
            raise

def extract_rows(obj):
    if isinstance(obj,list):
        if obj and isinstance(obj[0],dict): return obj
        out=[]
        for x in obj: out+=extract_rows(x)
        return out
    if isinstance(obj,dict):
        best=[]
        for _,v in obj.items():
            if isinstance(v,list) and v and isinstance(v[0],dict) and len(v)>len(best): best=v
        return best
    return []

def row_identity(row):
    c=''; n=''
    for k in ['stk_cd','stk_code','code','item','종목코드']:
        if row.get(k): c=code6(row.get(k))
        if c:break
    for k in ['stk_nm','stk_name','name','종목명']:
        if row.get(k): n=str(row.get(k)); break
    return c,n

def row_rate(row):
    for k in ('chg_rt','pre_rt','flu_rt','rate','change_rate','updown_rate','pred_pre_rt','diff_rate_for_gjga'):
        if k in row and str(row.get(k) or '').strip(): return num(row.get(k))
    return 0.0

def row_price(row):
    for k in ('cur_prc','curr_pric','now_prc','cur_pric','stck_prpr','price','현재가'):
        if k in row and str(row.get(k) or '').strip():
            v=abs(num(row.get(k)))
            if v>0:return v
    return 0.0

def capture_json(cap:Capture):
    d=asdict(cap); d['at_kst']=fmt_kst(cap.at); return d

def append_event(c:Candidate, cap:Capture):
    rec={'event':'STAGE_CAPTURE','version':APP_VERSION,'code':c.code,'name':c.name,'stage':cap.stage,'at':cap.at,'at_kst':fmt_kst(cap.at),'price':cap.price,'score':cap.score,'venue':cap.venue,'reasons':c.reasons,'metrics':c.metrics}
    with EVENT_FILE.open('a',encoding='utf-8') as f: f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.event_count+=1

def update_capture_performance(c:Candidate):
    for cap in c.captures.values():
        if cap.price<=0:continue
        px=num(c.last_price_by_venue.get(cap.venue)) if cap.venue in ('KRX','NXT') else num(c.last_price)
        if px<=0:continue
        cap.current_price=px; cap.current_return=round((px/cap.price-1)*100,2)
        if cap.max_price<=0 or px>cap.max_price:cap.max_price=px
        if cap.min_price<=0 or px<cap.min_price:cap.min_price=px
        cap.max_return=round((cap.max_price/cap.price-1)*100,2)
        cap.min_return=round((cap.min_price/cap.price-1)*100,2)

def maybe_capture(c:Candidate, new_stage:str, price:float|None=None, venue:str|None=None):
    cap_price=num(price) or num(c.last_price);cap_venue=str(venue or c.venue or c.last_fid9081 or '').upper()
    if cap_price<=0 or STAGE_RANK.get(new_stage,0)<1:return
    key=new_stage
    if new_stage=='BUY' and c.last_buy_entry_id:key=f'BUY@{c.last_buy_entry_id}'
    if key not in c.captures:
        fv=feature_vector(c); cap=Capture(new_stage,time.time(),cap_price,c.score,cap_venue,max_price=cap_price,min_price=cap_price,current_price=cap_price,features=fv)
        c.captures[key]=cap;c.metrics.setdefault('capture_features',{})[key]=fv;append_event(c,cap)
    if STAGE_RANK[new_stage]>STAGE_RANK.get(c.highest_stage,0):c.highest_stage=new_stage
    update_capture_performance(c)

def persist_buy_signal_state():
    rows={}
    for c in STATE.candidates.values():
        if c.signal_count:
            rows[c.code]={
                'name':c.name,'signal_count':c.signal_count,'signal_count_today':c.signal_count_today,
                'first_signal_at':c.first_signal_at,'last_signal_at':c.last_signal_at,
                'last_signal_price':c.last_signal_price,'last_signal_score':c.last_signal_score,
                'last_signal_stage':c.last_signal_stage,'last_signal_venue':c.last_signal_venue,'last_signal_reasons':c.last_signal_reasons,
                'signal_max_price':c.signal_max_price,'signal_min_price':c.signal_min_price,
                'entry_state':c.entry_state,'entry_state_since':c.entry_state_since,
                'pressure_started_at':c.pressure_started_at,'pressure_peak':c.pressure_peak,
                'pullback_low':c.pullback_low,'reaccel_started_at':c.reaccel_started_at,
                'reaccel_start_price':c.reaccel_start_price,'cooldown_until':c.cooldown_until,
                'last_buy_at':c.last_buy_at,'last_buy_entry_id':c.last_buy_entry_id,'last_buy_route':c.last_buy_route,
                'direct_started_at':c.direct_started_at,'direct_start_price':c.direct_start_price,'reentry_unlocked':c.reentry_unlocked,
                'reject_reason':c.reject_reason
            }
    tmp=BUY_SIGNAL_STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'version':APP_VERSION,'day':today_kst(),'updated_at':now_kst(),'rows':rows},ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    tmp.replace(BUY_SIGNAL_STATE)

def record_buy_signal(c:Candidate, stage:str='BUY', route:str='PULLBACK_REACCEL'):
    """Record only a confirmed BUY from one of the two independent entry routes.
    Raw PRESSURE/IGNITION remains discovery evidence and never increments buy counts.
    A dynamic-regime re-entry may unlock the base cooldown only after a new high + renewed flow.
    """
    signal_venue='NXT' if route.startswith('NXT_') else (c.venue if c.venue in ('KRX','NXT') else 'AUTO');signal_price=num(c.last_price_by_venue.get(signal_venue)) if signal_venue in ('KRX','NXT') else num(c.last_price)
    if stage!='BUY' or signal_price<=0:return False
    ensure_daily_rollover();now=time.time(); today=today_kst()
    if c.signal_count_today>=ENTRY_MAX_DAILY:return False
    if c.last_buy_at and now-c.last_buy_at<ENTRY_COOLDOWN_SEC and not c.reentry_unlocked:return False
    c.signal_count+=1; c.signal_count_today+=1
    if not c.first_signal_at:c.first_signal_at=now
    c.last_signal_at=now;c.last_signal_price=signal_price;c.last_signal_score=c.score;c.last_signal_stage='BUY';c.last_signal_venue=signal_venue
    c.last_signal_reasons=list(c.reasons)[:5];c.signal_max_price=signal_price;c.signal_min_price=signal_price
    c.last_buy_at=now;c.last_buy_entry_id=f'{c.code}:{int(now)}';c.last_buy_route=route;c.cooldown_until=now+ENTRY_COOLDOWN_SEC;c.reentry_unlocked=False
    c.entry_state='BUY';c.entry_state_since=now;c.reject_reason=''
    maybe_capture(c,'BUY',signal_price,signal_venue)
    auto_profit_mode=_manual_profit_mode(c,'SWING',route)
    STATE.exit_positions[c.last_buy_entry_id]={
      'entry_id':c.last_buy_entry_id,'day':today,'code':c.code,'name':c.name,'entry_at':now,'entry_price':signal_price,'entry_score':c.score,
      'route':route,'entry_venue':signal_venue,'entry_venue_strength':(venue_exit_strength(c,signal_venue) if signal_venue in ('KRX','NXT') else c.score),'profit_mode':auto_profit_mode,'range5_at_entry':num(c.metrics.get('nxt_range5_pct') if signal_venue=='NXT' else c.metrics.get('krx_range5_pct') if signal_venue=='KRX' else c.metrics.get('range5_pct')),'status':'OPEN','current_price':signal_price,'current_return':0.0,
      'mfe':0.0,'mae':0.0,'giveback':0.0,'last_action':'HOLD','last_action_at':now,'last_action_reason':'BUY 직후 관찰',
      'add_on_count':0,'entry_features':feature_vector(c),'rally_dna':{'match':c.metrics.get('rally_dna_match'),'type':c.metrics.get('rally_dna_type')}
    }
    persist_exit_positions()
    path='NXT>FIRST_WAVE>DEEP_SHAKEOUT>RECOVERY>BUY' if route=='NXT_RECOVERY_RECLAIM' else ('NXT>FIRST_WAVE>DRYUP_BASE>REIGNITION>BUY' if route=='NXT_SECOND_WAVE_BASE' else ('DISCOVERY>PRESSURE_BUILD>PULLBACK>REACCEL>BUY' if route=='PULLBACK_REACCEL' else 'DISCOVERY>PRESSURE_BUILD>DIRECT_ARM>BUY'))
    rec={'event':'BUY_CONFIRMED','policy':'ENTRY_V18_TRUTH_GUARD_MAX_PROFIT','version':APP_VERSION,'day':today,'id':c.last_buy_entry_id,'code':c.code,'name':c.name,'stage':'BUY','route':route,'at':now,'at_kst':now_kst(),'price':signal_price,'change_rate':(num(c.last_rate_by_venue.get(signal_venue)) if signal_venue in ('KRX','NXT') else c.rate),'score':c.score,'confidence':c.confidence,'venue':signal_venue,'fid9081':(c.last_fid9081_by_venue.get(signal_venue) if signal_venue in ('KRX','NXT') else c.last_fid9081),'reasons':c.last_signal_reasons,'smart':c.smart,'metrics':c.metrics,'entry_state_path':path,'signal_count':c.signal_count,'signal_count_today':c.signal_count_today}
    with BUY_SIGNAL_FILE.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n')
    STATE.buy_signal_events+=1; persist_buy_signal_state(); return True

def update_buy_signal_performance(c:Candidate):
    price=num(c.last_price_by_venue.get(c.last_signal_venue)) if c.last_signal_venue in ('KRX','NXT') else num(c.last_price)
    if price<=0 or c.last_signal_price<=0:return
    if c.signal_max_price<=0 or price>c.signal_max_price:c.signal_max_price=price
    if c.signal_min_price<=0 or price<c.signal_min_price:c.signal_min_price=price

def persist_performance(force=False):
    # Realtime paths only request a flush. JSON serialization and disk writes are performed by persistence_loop off the WS path.
    STATE.persist_requested=True
    if force:STATE.persist_force=True

def _build_persist_snapshot():
    rows={}
    for c in list(STATE.candidates.values()):
        if c.captures:rows[c.code]={'name':c.name,'last_price':c.last_price,'stage':c.stage,'captures':{k:capture_json(v) for k,v in c.captures.items()}}
    perf={'version':APP_VERSION,'updated_at':now_kst(),'rows':rows}
    mem,led=_clone_nxt_memory_payloads()
    return perf,mem,led

def _build_buy_state_payload():
    rows={}
    for c in list(STATE.candidates.values()):
        if not c.signal_count:continue
        rows[c.code]={'name':c.name,'signal_count':c.signal_count,'signal_count_today':c.signal_count_today,'first_signal_at':c.first_signal_at,'last_signal_at':c.last_signal_at,'last_signal_price':c.last_signal_price,'last_signal_score':c.last_signal_score,'last_signal_stage':c.last_signal_stage,'last_signal_venue':c.last_signal_venue,'last_signal_reasons':list(c.last_signal_reasons),'signal_max_price':c.signal_max_price,'signal_min_price':c.signal_min_price,'entry_state':c.entry_state,'entry_state_since':c.entry_state_since,'pressure_started_at':c.pressure_started_at,'pressure_peak':c.pressure_peak,'pullback_low':c.pullback_low,'reaccel_started_at':c.reaccel_started_at,'reaccel_start_price':c.reaccel_start_price,'cooldown_until':c.cooldown_until,'last_buy_at':c.last_buy_at,'last_buy_entry_id':c.last_buy_entry_id,'last_buy_route':c.last_buy_route,'direct_started_at':c.direct_started_at,'direct_start_price':c.direct_start_price,'reentry_unlocked':c.reentry_unlocked,'reject_reason':c.reject_reason}
    return {'version':APP_VERSION,'day':today_kst(),'updated_at':now_kst(),'rows':rows}

def _write_persist_snapshot(perf:dict, mem:dict|None, led:dict|None, buy_state:dict|None=None):
    _atomic_json(STATE_FILE,perf)
    if mem is not None:_atomic_json(NXT_FIRST_WAVE_MEMORY_FILE,mem)
    if led is not None:_atomic_json(NXT_DAILY_STRONG_LEDGER_FILE,led)
    if buy_state is not None:_atomic_json(BUY_SIGNAL_STATE,buy_state)

def _compact_tail_file(path:Path):
    try:
        if not path.exists() or path.stat().st_size<=OP_LOG_MAX_MB*1024*1024:return False
        lines=path.read_text(encoding='utf-8',errors='ignore').splitlines()[-OP_LOG_KEEP_LINES:]
        tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(('\n'.join(lines)+'\n') if lines else '',encoding='utf-8');tmp.replace(path);return True
    except Exception:return False

OPERATIONAL_LOG_FILES=(EVENT_FILE,MARKET_EVENT_FILE,NXT_ALERT_FILE,NXT_SECOND_WAVE_FILE,CALIB_ALERT_FILE,EXIT_ACTION_FILE,MANUAL_POSITION_EVENT_FILE,PUSH_DELIVERY_FILE)

def _disk_guard_scan(do_compact=False):
    compacted=0
    if do_compact:
        for path in OPERATIONAL_LOG_FILES:
            if _compact_tail_file(path):compacted+=1
    total=0;largest=[]
    try:
        for path in DATA_DIR.glob('**/*'):
            if not path.is_file():continue
            size=path.stat().st_size;total+=size;largest.append((size,path.name))
    except Exception:pass
    largest=sorted(largest,reverse=True)[:8]
    try:
        st=os.statvfs(DATA_DIR);free=st.f_bavail*st.f_frsize;disk_total=st.f_blocks*st.f_frsize
    except Exception:free=0;disk_total=0
    return {'data_dir_mb':round(total/1024/1024,2),'disk_free_gb':round(free/1024/1024/1024,2) if free else None,'disk_total_gb':round(disk_total/1024/1024/1024,2) if disk_total else None,'largest_files':[{'name':n,'mb':round(sz/1024/1024,2)} for sz,n in largest],'compacted':compacted}

async def persistence_loop():
    while True:
        await asyncio.sleep(1)
        now=time.time()
        if not STATE.persist_requested and now-STATE.last_persist<PERSIST_INTERVAL_SECONDS:continue
        if not STATE.persist_force and now-STATE.last_persist<PERSIST_INTERVAL_SECONDS:continue
        try:
            perf,mem,led=_build_persist_snapshot();buy_state=_build_buy_state_payload();write_mem=mem if (STATE.persist_force or STATE.nxt_memory_dirty) else None;write_led=led if (STATE.persist_force or STATE.nxt_ledger_dirty) else None
            await asyncio.to_thread(_write_persist_snapshot,perf,write_mem,write_led,buy_state)
            STATE.last_persist=now;STATE.last_nxt_flush=now;STATE.persist_requested=False;STATE.persist_force=False
            if write_mem is not None:STATE.nxt_memory_dirty=False
            if write_led is not None:STATE.nxt_ledger_dirty=False
        except Exception as e:STATE.performance_guard['persist_error']=str(e)[:160]

async def performance_guard_loop():
    expected=time.monotonic()+1.0;last_scan=0.0;last_log=0.0
    while True:
        await asyncio.sleep(1.0);actual=time.monotonic();lag=max(0.0,(actual-expected)*1000);expected=actual+1.0
        STATE.performance_guard['event_loop_lag_ms']=round(lag,2);STATE.performance_guard['event_loop_lag_max_ms']=round(max(num(STATE.performance_guard.get('event_loop_lag_max_ms')),lag),2)
        now=time.time()
        if now-last_scan>=PERF_GUARD_INTERVAL_SECONDS:
            do_compact=now-last_log>=LOG_MAINTENANCE_SECONDS
            info=await asyncio.to_thread(_disk_guard_scan,do_compact);STATE.performance_guard.update({k:v for k,v in info.items() if k!='compacted'});STATE.performance_guard['last_scan_at']=now;last_scan=now
            if do_compact:
                STATE.performance_guard['log_compactions']=int(STATE.performance_guard.get('log_compactions') or 0)+int(info.get('compacted') or 0);STATE.performance_guard['last_log_maintenance']=now;last_log=now


def first_row(j, keys=()):
    for k in keys:
        v=j.get(k) if isinstance(j,dict) else None
        if isinstance(v,list) and v and isinstance(v[0],dict): return v[0]
    rows=extract_rows(j); return rows[0] if rows else {}

def first_num(row, keys):
    for k in keys:
        if k in row and str(row.get(k) or '').strip()!='': return num(row.get(k))
    return 0.0

def _venue_smart(c:Candidate, venue:str)->dict:
    venue=str(venue or '').upper()
    if venue not in ('KRX','NXT'):venue='KRX'
    return c.smart_by_venue.setdefault(venue,{})

def _mirror_venue_smart(c:Candidate, venue:str):
    # Mixed-market score follows the venue of the latest verified trade; NXT-specific engines read smart_by_venue directly.
    if not c.smart or str(c.venue or '').upper()==venue:
        c.smart.update(_venue_smart(c,venue));c.smart_updated_at=max(c.smart_updated_at,time.time())

def venue_smart_freshness(c:Candidate, venue:str):
    venue=str(venue or '').upper();now=time.time()
    pa=num(c.program_updated_at_by_venue.get(venue));pra=num(c.program_rt_at_by_venue.get(venue));ia=num(c.investor_updated_at_by_venue.get(venue))
    return {'program_age':now-pa if pa else 10**9,'program_rt_age':now-pra if pra else 10**9,'program_fresh':min(now-pa if pa else 10**9,now-pra if pra else 10**9)<=PROGRAM_HARD_FRESH_SECONDS,'investor_age':now-ia if ia else 10**9,'investor_fresh':bool(ia and now-ia<=INVESTOR_FRESH_SECONDS)}

def _apply_investor_row(c:Candidate, venue:str, r:dict):
    sm=_venue_smart(c,venue);inst=first_num(r,['orgn']);trust=first_num(r,['invtrt']);pension=first_num(r,['penfnd_etc']);foreign=first_num(r,['frgnr_invsr'])
    prev_inst=num(sm.get('institution_net'));prev_trust=num(sm.get('trust_net'));prev_pension=num(sm.get('pension_net'));prev_foreign=num(sm.get('foreign_net'))
    sm.update({'institution_prev':prev_inst,'trust_prev':prev_trust,'pension_prev':prev_pension,'foreign_prev':prev_foreign,'institution_net':inst,'trust_net':trust,'pension_net':pension,'foreign_net':foreign,'institution_delta':inst-prev_inst,'trust_delta':trust-prev_trust,'pension_delta':pension-prev_pension,'foreign_delta':foreign-prev_foreign,'financial_net':first_num(r,['fnnc_invt']),'insurance_net':first_num(r,['insrnc']),'source':'ka10059','venue':venue})
    now=time.time();c.investor_updated_at_by_venue[venue]=now;c.investor_updated_at=max(c.investor_updated_at,now)
    if venue=='NXT':c.metrics.update({'nxt_institution_delta':sm.get('institution_delta'),'nxt_trust_delta':sm.get('trust_delta'),'nxt_pension_delta':sm.get('pension_delta'),'nxt_foreign_delta':sm.get('foreign_delta')})
    _mirror_venue_smart(c,venue)

def _apply_program_values(c:Candidate, venue:str, buy:float, sell:float, net:float, *, realtime:bool, raw:dict|None=None, source:str=''):
    sm=_venue_smart(c,venue);prev=num(sm.get('program_net'));delta=(net-prev)
    sm.update({'program_buy':buy,'program_sell':sell,'program_prev':prev,'program_net':net,'program_delta':delta,'program_source':source,'venue':venue})
    now=time.time()
    if realtime:
        c.program_rt_at_by_venue[venue]=now;c.program_rt_at=max(c.program_rt_at,now);c.program_rt_samples+=1;c.program_rt_raw={'venue':venue,**(raw or {})}
    else:
        c.program_updated_at_by_venue[venue]=now;c.program_updated_at=max(c.program_updated_at,now)
    if venue=='NXT':c.metrics.update({'nxt_program_net':net,'nxt_program_delta':delta,'nxt_program_fresh':True})
    else:c.metrics.update({'krx_program_net':net,'krx_program_delta':delta})
    _mirror_venue_smart(c,venue)

async def poll_investor(c:Candidate):
    # ka10059 explicitly supports exchange-qualified codes: KRX 039490 / NXT 039490_NX.
    venues=[]
    nxt_needed=bool(nxt_radar_session_active() and (c.metrics.get('nxt_seen') or c.code in STATE.burst_codes or c.code in STATE.nxt_memory_codes or c.code in STATE.core_codes))
    if nxt_needed:venues.append('NXT')
    krx_recent=bool(num(c.last_tick_at_by_venue.get('KRX')) and time.time()-num(c.last_tick_at_by_venue.get('KRX'))<180)
    if krx_recent or not venues:venues.append('KRX')
    for venue in venues[:2]:
        stk=c.code+'_NX' if venue=='NXT' else c.code
        body={'dt':today_kst(),'stk_cd':stk,'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1'}
        status,j=await kiwoom_post('/api/dostk/stkinfo','ka10059',body,priority=0)
        ok=status==200 and int(j.get('return_code',0))==0;STATE.smart_status[f'ka10059_{venue}']={'ok':ok,'msg':j.get('return_msg','')}
        if not ok:continue
        r=first_row(j,('stk_invsr_orgn','stk_invsr_orgn_chart'))
        if r:_apply_investor_row(c,venue,r)

async def _refresh_program_rest_cache(venue:str, force:bool=False):
    venue=str(venue or '').upper();now=time.time()
    if venue not in ('KRX','NXT'):return {}
    if not force and now-num(STATE.program_rest_cache_at.get(venue))<PROGRAM_FALLBACK_REFRESH_SECONDS:return STATE.program_rest_cache.get(venue) or {}
    async with STATE.program_rest_cache_lock:
        now=time.time()
        if not force and now-num(STATE.program_rest_cache_at.get(venue))<PROGRAM_FALLBACK_REFRESH_SECONDS:return STATE.program_rest_cache.get(venue) or {}
        stex='2' if venue=='NXT' else '1';merged={};oks=0;msgs=[]
        for mrkt in ('P00101','P10102'):
            status,j=await kiwoom_post('/api/dostk/stkinfo','ka90004',{'dt':today_kst(),'mrkt_tp':mrkt,'stex_tp':stex},priority=0)
            ok=status==200 and int(j.get('return_code',0))==0;oks+=1 if ok else 0;msgs.append(str(j.get('return_msg') or ''))
            if not ok:continue
            for r in (j.get('stk_prm_trde_prst') or []):
                code=code6(r.get('stk_cd'))
                if code:merged[code]=r
        if oks:
            STATE.program_rest_cache[venue]=merged;STATE.program_rest_cache_at[venue]=time.time()
        STATE.smart_status[f'ka90004_{venue}']={'ok':oks>0,'markets_ok':oks,'rows':len(merged),'msg':' / '.join(x for x in msgs if x)[:160],'at':time.time()}
        return STATE.program_rest_cache.get(venue) or {}

async def poll_program(c:Candidate):
    # Official ka90004 returns a market list; cache each KRX/NXT market snapshot, then select this code.
    venues=[]
    nxt_needed=bool(nxt_radar_session_active() and (c.metrics.get('nxt_seen') or c.code in STATE.burst_codes or c.code in STATE.nxt_memory_codes or c.code in STATE.core_codes))
    if nxt_needed:venues.append('NXT')
    if bool(num(c.last_tick_at_by_venue.get('KRX')) and time.time()-num(c.last_tick_at_by_venue.get('KRX'))<180) or not venues:venues.append('KRX')
    for venue in venues[:2]:
        cache=await _refresh_program_rest_cache(venue);r=cache.get(c.code)
        if not r:continue
        # ka90004 program money fields are million KRW. Keep the API unit consistently; direction/delta are the decision inputs.
        buy=first_num(r,['buy_cntr_amt']);sell=first_num(r,['sel_cntr_amt']);net=first_num(r,['netprps_prica'])
        if not net and (buy or sell):net=buy-sell
        _apply_program_values(c,venue,buy,sell,net,realtime=False,source='ka90004')

async def poll_sector_metadata(c:Candidate):
    rec=SECTOR_OFFICIAL.get(c.code) or {}
    if rec and time.time()-float(rec.get('at') or 0)<7*86400:return
    try:
        status,j=await kiwoom_post('/api/dostk/stkinfo','ka10001',{'stk_cd':c.code},priority=20)
        if status!=200 or int(j.get('return_code',0))!=0:return
        r=first_row(j,('stk_bsc_info','stock_basic_info')) or j
        sector=''
        for k in ('inds_nm','industry_name','upjong_nm','업종명','sector_name'):
            if str(r.get(k) or '').strip():sector=str(r.get(k)).strip();break
        if sector:
            SECTOR_OFFICIAL[c.code]={'sector':sector,'at':time.time(),'source':'ka10001'}
            tmp=SECTOR_OFFICIAL_CACHE_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(SECTOR_OFFICIAL,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(SECTOR_OFFICIAL_CACHE_FILE)
    except Exception:pass

async def smart_money_loop():
    while True:
        try:
            if not APP_KEY or not SECRET or not discovery_window_active():
                await asyncio.sleep(5);continue
            by={c.code:c for c in ranked()};core=[by[x] for x in STATE.core_codes if x in by];top=core or ranked()[:WS_CORE_LIMIT]
            challengers=[by[x] for x in STATE.challenger_codes[:CHALLENGER_SMART_LIMIT] if x in by and x not in STATE.core_codes]
            if top or challengers:
                now=time.time()
                def hot_key(c):
                    urgent=1 if c.entry_state in ('PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM') or c.stage in ('PRESSURE','IGNITION') else 0
                    age=(now-c.investor_updated_at) if c.investor_updated_at else 10**9
                    return (urgent,c.score,min(age,9999))
                def nxt_relevant(c):return bool(nxt_radar_session_active() and (c.metrics.get('nxt_seen') or c.code in STATE.burst_codes or c.code in STATE.nxt_memory_codes or c.code in STATE.core_codes))
                def investor_due(c,interval):
                    if nxt_relevant(c) and now-num(c.investor_updated_at_by_venue.get('NXT'))>=interval:return True
                    krx_recent=bool(num(c.last_tick_at_by_venue.get('KRX')) and now-num(c.last_tick_at_by_venue.get('KRX'))<180)
                    return bool((krx_recent or not nxt_relevant(c)) and now-num(c.investor_updated_at_by_venue.get('KRX'))>=interval)
                def program_due(c):
                    if nxt_relevant(c):
                        nrt=num(c.program_rt_at_by_venue.get('NXT'));nrest=num(c.program_updated_at_by_venue.get('NXT'))
                        if now-max(nrt,nrest)>=PROGRAM_FALLBACK_REFRESH_SECONDS:return True
                    krx_recent=bool(num(c.last_tick_at_by_venue.get('KRX')) and now-num(c.last_tick_at_by_venue.get('KRX'))<180)
                    if krx_recent or not nxt_relevant(c):
                        krt=num(c.program_rt_at_by_venue.get('KRX'));krest=num(c.program_updated_at_by_venue.get('KRX'))
                        if now-max(krt,krest)>=PROGRAM_FALLBACK_REFRESH_SECONDS:return True
                    return False
                stale_inv=[c for c in top if investor_due(c,INVESTOR_REFRESH_TARGET_SECONDS)]
                stale_inv += [c for c in challengers if investor_due(c,CHALLENGER_INVESTOR_INTERVAL)]
                fastest_budget=nxt_fastest_window_active() or nxt_regular_session_active();inv_limit=min(SMART_POLL_BATCH,4) if fastest_budget else SMART_POLL_BATCH
                stale_inv.sort(key=hot_key,reverse=True);inv_batch=stale_inv[:inv_limit]
                # Program REST is a venue-aware bounded fallback only when that venue's 0w realtime is stale.
                stale_prog=[c for c in top if program_due(c)]
                prog_limit=min(SMART_PROGRAM_FALLBACK_BATCH,1) if fastest_budget else SMART_PROGRAM_FALLBACK_BATCH
                stale_prog.sort(key=hot_key,reverse=True);prog_batch=stale_prog[:prog_limit]
                jobs=[]
                for c in inv_batch:jobs.append(asyncio.create_task(poll_investor(c)))
                for c in prog_batch:jobs.append(asyncio.create_task(poll_program(c)))
                sector_pool=[];seen_sector=set()
                for c in (top+challengers):
                    if c.code in seen_sector:continue
                    seen_sector.add(c.code);rec=SECTOR_OFFICIAL.get(c.code) or {}
                    if not rec or now-float(rec.get('at') or 0)>=7*86400:sector_pool.append(c)
                sector_batch=[]
                if sector_pool:
                    off=STATE.sector_cursor%len(sector_pool);rot=sector_pool[off:]+sector_pool[:off];sector_limit=1 if fastest_budget else 4;sector_batch=rot[:sector_limit];STATE.sector_cursor=(off+len(sector_batch))%len(sector_pool)
                for c in sector_batch:jobs.append(asyncio.create_task(poll_sector_metadata(c)))
                if jobs:
                    results=await asyncio.gather(*jobs,return_exceptions=True)
                    errs=[x for x in results if isinstance(x,Exception)]
                    if errs:STATE.smart_status['batch_error']={'ok':False,'count':len(errs),'msg':str(errs[0])[:100]}
                STATE.smart_status['scheduler']={'mode':'NXT_FAST_BUDGET' if fastest_budget else 'NORMAL','core':len(top),'challenger_smart':len(challengers),'challenger_interval_sec':CHALLENGER_INVESTOR_INTERVAL,'investor_due':len(stale_inv),'investor_polled':len(inv_batch),'program_fallback_due':len(stale_prog),'program_fallback_polled':len(prog_batch),'investor_refresh_target_sec':INVESTOR_REFRESH_TARGET_SECONDS,'program_fallback_target_sec':PROGRAM_FALLBACK_REFRESH_SECONDS,'sector_due':len(sector_pool) if 'sector_pool' in locals() else 0,'sector_polled':len(sector_batch) if 'sector_batch' in locals() else 0,'sector_cursor':STATE.sector_cursor,'at':time.time()}
                mark_scores_dirty([c.code for c in inv_batch+prog_batch+sector_batch])
            train_from_mature_captures();persist_performance()
        except Exception as e:STATE.smart_status['loop_error']={'ok':False,'msg':str(e)[:120]}
        await asyncio.sleep(SMART_POLL_SECONDS)

async def _fetch_rank_source(market:str, source:str, api_id:str, tpl:dict, priority:int=10):
    body={k:(market if v=='{market}' else v) for k,v in tpl.items()}
    key=f'{source}:{market}'
    try:
        status,j=await kiwoom_post('/api/dostk/rkinfo',api_id,body,priority=priority)
        rows=extract_rows(j);ok=status==200 and int(j.get('return_code',0))==0
        STATE.rest_status[key]={'ok':ok,'rows':len(rows),'msg':j.get('return_msg',''),'at':time.time()}
        return key,source,market,ok,rows,j,None
    except Exception as e:
        STATE.rest_status[key]={'ok':False,'rows':0,'msg':str(e)[:120],'at':time.time()}
        return key,source,market,False,[],{},e

def protected_candidate_codes(now:float|None=None):
    now=float(now or time.time());active={'PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM','BUY'}
    out={str(x.get('code')) for x in STATE.exit_positions.values() if x.get('status') in ('OPEN','EXIT_SIGNALED')}|{str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN'}
    out|=set(nxt_second_wave_memory_codes(now))|set(STATE.core_codes)|set(STATE.burst_codes)|set(STATE.burst_highres_codes)|set(STATE.ws_codes)
    out|={str(x.get('code')) for x in (STATE.next_day_picks.get('rows') or [])}
    out|={c.code for c in STATE.candidates.values() if c.signal_count_today>0 or c.entry_state in active}
    return out

def enforce_candidate_cap_locked(now:float|None=None):
    """Hard safety cap. Call only while STATE.lock is held; protected/live positions are never evicted."""
    now=float(now or time.time());n=len(STATE.candidates)
    if n<=MAX_CANDIDATES:
        STATE.candidate_cap_status.update({'limit':MAX_CANDIDATES,'last_evicted':0,'last_at':now,'overprotected':0,'current':n});return 0
    protected=protected_candidate_codes(now);eligible=[]
    for code,c in STATE.candidates.items():
        if code in protected:continue
        last=max([num(c.last_tick_at),num(c.first_seen)]+[num(x) for x in c.source_last_seen.values()])
        active_source=bool(c.source_hits and now-max(c.source_last_seen.values(),default=0)<=SOURCE_TTL_SECONDS)
        recent=bool(c.last_tick_at and now-c.last_tick_at<=60)
        quality=max(num(c.score),num(c.metrics.get('nxt_radar_score')),num(c.metrics.get('nxt_takeover_score')))
        eligible.append((1 if active_source else 0,1 if recent else 0,quality,last,code))
    need=n-MAX_CANDIDATES;eligible.sort();victims=[x[-1] for x in eligible[:need]]
    for code in victims:
        STATE.candidates.pop(code,None);STATE.score_dirty_codes.discard(code);STATE.burst_watch.pop(code,None);STATE.emergency_highres_watch.pop(code,None)
    remain=len(STATE.candidates);over=max(0,remain-MAX_CANDIDATES)
    STATE.candidate_cap_status.update({'limit':MAX_CANDIDATES,'last_evicted':len(victims),'evicted_total':int(STATE.candidate_cap_status.get('evicted_total') or 0)+len(victims),'last_at':now,'overprotected':over,'current':remain})
    return len(victims)

async def _apply_streamed_rank_result(result, scan_id:int):
    """Apply one completed ranking source immediately.

    This is intentionally source-local: a fast volume/bid source can create a candidate, update its
    NXT radar score, promote it into BURST, and expose it to the WS registry without waiting for a slow
    peer REST call in the same discovery cycle.
    """
    source_key,source,market,ok,rows,j,err=result
    if not ok:return False,source_key,set()
    now=time.time();changed=set();new_burst=False
    async with STATE.lock:
        for idx,row in enumerate(rows[:100]):
            code,name=row_identity(row)
            if not code or is_fund_like_name(name):continue
            cand=STATE.get(code,name or '')
            if name:cand.name=name
            weight=WEIGHTS[source]*(1-0.55*idx/max(1,min(len(rows),100)))
            old_base=sum(cand.source_hits.values())
            cand.source_hits[source_key]=max(num(cand.source_hits.get(source_key)),weight);cand.source_last_seen[source_key]=now;cand.source_scan_id=scan_id
            rp=row_price(row);rr=row_rate(row)
            if rp>0 and (not cand.last_tick_at or now-cand.last_tick_at>DISPLAY_FRESH_MS/1000):
                cand.last_price=rp;cand.rate=rr;cand.last_price_source='REST_NXT_STREAM' if source.startswith('nxt_') else 'REST_RANK_STREAM'
            elif abs(rr)>abs(num(cand.rate)) and (not cand.last_tick_at or now-cand.last_tick_at>DISPLAY_FRESH_MS/1000):cand.rate=rr
            base=sum(cand.source_hits.values());cand.source_velocity=max(num(cand.source_velocity),base-num(cand.source_prev_base))
            nxt_hits=[src for src in cand.source_hits if str(src).split(':',1)[0].startswith('nxt_')];nxt_base=sum(cand.source_hits.get(src,0) for src in nxt_hits);nxt_count=len(nxt_hits);nxt_rate=num(cand.last_rate_by_venue.get('NXT'))
            takeover=clamp(nxt_base*0.55+nxt_count*8+max(0,min(nxt_rate,8))*2.0,0,100) if nxt_count else 0.0
            radar=clamp(nxt_base*0.50+nxt_count*10+max(0,min(nxt_rate,10))*2.5+max(0,cand.source_velocity)*0.6,0,100) if nxt_count else 0.0
            cand.metrics.update({'rest_base':base,'discovery_overlap':len(cand.source_hits),'nxt_radar_hits':nxt_hits,'nxt_radar_count':nxt_count,'nxt_radar_score':round(radar,1),'nxt_takeover_score':round(takeover,1),'nxt_radar_at':now if nxt_count else cand.metrics.get('nxt_radar_at')})
            if source.startswith('nxt_'):
                if not cand.nxt_first_radar_at:cand.nxt_first_radar_at=now;cand.nxt_first_radar_rate=num(cand.rate)
                cand.metrics.update({'nxt_first_radar_at':cand.nxt_first_radar_at,'nxt_first_radar_rate':round(cand.nxt_first_radar_rate,2)})
                update_nxt_ledger_metrics(cand,now)
                high_value=any(x in source for x in ('volume_surge','turnover_top','bid_surge','residual_ratio_surge'))
                # New entrant bypass: top rows in a high-value NXT source do not wait for generic NOVA score.
                if high_value and (idx<25 or nxt_count>=2 or radar>=38):
                    prev=num(STATE.burst_watch.get(code));STATE.burst_watch[code]=max(prev,now+NXT_BURST_TTL_SECONDS);new_burst=new_burst or prev<=now
            changed.add(code)
        for code,exp in list(STATE.burst_watch.items()):
            if exp<=now:STATE.burst_watch.pop(code,None)
        for code,exp in list(STATE.emergency_highres_watch.items()):
            if exp<=now:STATE.emergency_highres_watch.pop(code,None)
        enforce_candidate_cap_locked(now);mark_scores_dirty(changed)
        if new_burst:_refresh_ws_pools_locked(now,quick=True)
    return True,source_key,changed

def _unique_codes(seq):
    out=[];seen=set()
    for x in seq:
        if x and x not in seen:seen.add(x);out.append(x)
    return out

def _refresh_ws_pools_locked(now:float|None=None, quick:bool=False):
    now=float(now or time.time());rr=ranked();active_states={'PRESSURE_BUILD','PULLBACK','REACCEL','DIRECT_ARM','BUY'}
    protected={str(x.get('code')) for x in STATE.exit_positions.values() if x.get('status') in ('OPEN','EXIT_SIGNALED')}|{str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN'}
    memory_codes=set(nxt_second_wave_memory_codes(now));protected|=memory_codes
    ws_rr=[x for x in rr if x.source_hits or x.code in protected or x.code in STATE.burst_watch or (x.entry_state in active_states and x.last_tick_at and now-x.last_tick_at<=30)]
    manual_priority=[str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN' and str(x.get('code')) in STATE.candidates]
    core_order=_unique_codes(manual_priority)[:WS_CORE_LIMIT]
    for x in ws_rr:
        if len(core_order)>=WS_CORE_LIMIT:break
        event_boost=(x.source_velocity>=8 or len(x.source_hits)>=4 or x.rate>=2.0 or num(x.metrics.get('nxt_radar_score'))>=45 or x.stage in ('PRESSURE','IGNITION') or x.entry_state not in ('DISCOVERY','COOLDOWN'))
        if event_boost or x.code in STATE.core_codes:core_order.append(x.code)
    for x in ws_rr:
        if len(core_order)>=WS_CORE_LIMIT:break
        if x.code not in core_order:core_order.append(x.code)
    core_set=set(core_order);pool=[x.code for x in ws_rr if x.code not in core_set][:max(WS_CHALLENGER_LIMIT*3,WS_CHALLENGER_LIMIT)]
    if pool:
        off=STATE.rotation%len(pool);rot=pool[off:]+pool[:off];chall=rot[:WS_CHALLENGER_LIMIT]
        if not quick:STATE.rotation=(STATE.rotation+max(5,WS_CHALLENGER_LIMIT//4))%len(pool)
    else:chall=[]
    STATE.core_codes=core_order[:WS_CORE_LIMIT]
    memory_order=[x for x in nxt_second_wave_memory_codes(now) if x in STATE.candidates and x not in STATE.core_codes][:NXT_SECOND_WAVE_POOL_LIMIT];STATE.nxt_memory_codes=memory_order
    occupied=set(STATE.core_codes)|set(memory_order)
    burst_all_ranked=sorted((STATE.candidates[x] for x,exp in STATE.burst_watch.items() if exp>now and x in STATE.candidates),key=lambda z:(num(z.metrics.get('nxt_radar_score')),z.source_velocity,z.rate),reverse=True)
    burst_ranked=[x for x in burst_all_ranked if x.code not in occupied]
    STATE.burst_codes=[x.code for x in burst_ranked[:NXT_BURST_WATCH_LIMIT]]
    # High-resolution burst names receive program + orderbook immediately, even if the same symbol was promoted into CORE.
    emergency=[x for x,exp in STATE.emergency_highres_watch.items() if exp>now and x in STATE.candidates]
    STATE.burst_highres_codes=_unique_codes(emergency+[x.code for x in burst_all_ranked])[:NXT_BURST_HIGHRES_LIMIT]
    occupied|=set(STATE.burst_codes)
    remain=max(0,WS_LIMIT-len(STATE.core_codes)-len(memory_order)-len(STATE.burst_codes));STATE.challenger_codes=[x for x in chall if x not in occupied][:min(WS_CHALLENGER_LIMIT,remain)]
    core_set=set(STATE.core_codes);mem_set=set(memory_order);burst_set=set(STATE.burst_codes);chall_set=set(STATE.challenger_codes);hi=set(STATE.burst_highres_codes)
    for x in STATE.candidates.values():
        x.ws_tier='BURST-HR' if x.code in hi else ('CORE' if x.code in core_set else ('MEMORY' if x.code in mem_set else ('BURST' if x.code in burst_set else ('CHALLENGER' if x.code in chall_set else ''))))
    STATE.ws_codes=_unique_codes(STATE.core_codes+memory_order+STATE.burst_codes+STATE.challenger_codes)[:WS_LIMIT]
    STATE.ws_status['burst_highres']=len(STATE.burst_highres_codes);STATE.generated_at=now
    return rr

async def _finalize_discovery_cycle(started:float,successful_sources:set[str],failed_sources:set[str],changed:set[str],scan_id:int,mode:str,status_key:str):
    async with STATE.lock:
        now=time.time()
        for cand in STATE.candidates.values():
            for src in list(cand.source_hits):
                if src in successful_sources and num(cand.source_last_seen.get(src))<started:cand.source_hits.pop(src,None)
                elif now-num(cand.source_last_seen.get(src))>SOURCE_TTL_SECONDS:cand.source_hits.pop(src,None)
            base=sum(cand.source_hits.values());cand.source_velocity=max(num(cand.source_velocity),base-num(cand.source_prev_base))
            nxt_hits=[src for src in cand.source_hits if str(src).split(':',1)[0].startswith('nxt_')];nxt_base=sum(cand.source_hits.get(src,0) for src in nxt_hits);nxt_count=len(nxt_hits);nxt_rate=num(cand.last_rate_by_venue.get('NXT'))
            takeover=clamp(nxt_base*0.55+nxt_count*8+max(0,min(nxt_rate,8))*2.0,0,100) if nxt_count else 0.0
            radar=clamp(nxt_base*0.50+nxt_count*10+max(0,min(nxt_rate,10))*2.5+max(0,cand.source_velocity)*0.6,0,100) if nxt_count else 0.0
            cand.metrics.update({'discovery_overlap':len(cand.source_hits),'rest_base':base,'source_velocity':round(cand.source_velocity,2),'source_age_sec':round(max(0,now-max(cand.source_last_seen.values(),default=cand.first_seen)),1),'nxt_after_mode':nxt_after_session_active(),'nxt_premarket_mode':nxt_premarket_session_active(),'nxt_regular_parallel_mode':nxt_regular_session_active(),'nxt_radar_hits':nxt_hits,'nxt_radar_count':nxt_count,'nxt_radar_score':round(radar,1),'nxt_takeover_score':round(takeover,1),'nxt_first_radar_at':cand.nxt_first_radar_at or None,'nxt_first_radar_rate':round(cand.nxt_first_radar_rate,2) if cand.nxt_first_radar_at else None})
            if nxt_count:update_nxt_ledger_metrics(cand,now)
        for code,exp in list(STATE.burst_watch.items()):
            if exp<=now:STATE.burst_watch.pop(code,None)
        for code,exp in list(STATE.emergency_highres_watch.items()):
            if exp<=now:STATE.emergency_highres_watch.pop(code,None)
        protected={str(x.get('code')) for x in STATE.exit_positions.values() if x.get('status') in ('OPEN','EXIT_SIGNALED')}|{str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN'}|set(nxt_second_wave_memory_codes(now))
        for code in list(STATE.candidates):
            x=STATE.candidates[code];last_src=max(x.source_last_seen.values(),default=x.first_seen);x.metrics['source_age_sec']=round(max(0,now-last_src),1)
            if not x.source_hits and now-last_src>CANDIDATE_TTL_SECONDS and code not in protected and x.signal_count_today<=0:STATE.candidates.pop(code,None)
        enforce_candidate_cap_locked(now)
        # Discovery must not synchronously rescore the full universe. Stream-applied/changed
        # symbols plus sector-context deltas are handed to the coalesced scoring worker.
        sector_changed=update_sector_context() or set();STATE.last_sector_context=now
        mark_scores_dirty(set(changed)|set(sector_changed))
        rr=_refresh_ws_pools_locked(now,quick=False);STATE.scan_cycles+=1
        if nxt_radar_session_active():evaluate_nxt_radar_alerts(rr)
        if nxt_premarket_session_active():evaluate_premarket_picks()
        STATE.rest_status[status_key]={'ok':True,'mode':mode,'streaming_apply':True,'duration_ms':round((time.time()-started)*1000,1),'sources_ok':len(successful_sources),'sources_failed':len(failed_sources),'changed_codes':len(changed),'ws_target':len(STATE.ws_codes),'burst_watch':len(STATE.burst_codes),'burst_highres':len(STATE.burst_highres_codes),'second_wave_memory':len(STATE.nxt_memory_codes),'nxt_alerts':len(STATE.nxt_alerts),'at':time.time()}

async def discovery_loop():
    """Slow context scanner. NXT high-signal radar runs independently in nxt_fast_radar_loop."""
    while True:
        ensure_daily_rollover()
        if not realtime_runtime_awake():
            STATE.rest_status['_discovery_cycle']={'ok':True,'skipped':'OVERNIGHT_FROZEN','wake_guard_sec':WS_WAKE_GUARD_SECONDS,'at':time.time()}
            await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
        started=time.time();live=market_session().get('active');successful_sources=set();failed_sources=set();changed=set();STATE.slow_scan_cycles+=1;scan_id=int(time.time()*1000)
        if APP_KEY and SECRET and discovery_window_active() and live:
            async with STATE.lock:
                for cand in STATE.candidates.values():cand.source_prev_base=sum(cand.source_hits.values());cand.source_velocity=0.0
            if nxt_after_session_active() or nxt_premarket_session_active():
                specs=NXT_AFTER_RANK_SPECS;mode='NXT_SLOW_FULL_CONTEXT';priority=5
            else:
                specs=RANK_SPECS;mode='INTEGRATED_SLOW_CONTEXT';priority=10
            tasks=[asyncio.create_task(_fetch_rank_source(market,source,api_id,tpl,priority)) for market in ('001','101') for source,api_id,tpl in specs]
            for fut in asyncio.as_completed(tasks):
                try:result=await fut
                except Exception as e:failed_sources.add('TASK:'+str(e)[:60]);continue
                ok,key,codes=await _apply_streamed_rank_result(result,scan_id);(successful_sources if ok else failed_sources).add(key);changed.update(codes)
            await _finalize_discovery_cycle(started,successful_sources,failed_sources,changed,scan_id,mode,'_discovery_cycle')
        else:
            STATE.rest_status['_discovery_cycle']={'ok':True,'skipped':'NON_TRADING_WINDOW','duration_ms':round((time.time()-started)*1000,1),'at':time.time()}
        persist_performance();interval=DISCOVERY_SECONDS if market_session().get('krx') else (NXT_SLOW_CONTEXT_SECONDS if nxt_radar_session_active() else DISCOVERY_SECONDS)
        await asyncio.sleep(max(1,interval-(time.time()-started)))

async def nxt_fast_radar_loop():
    """Independent rolling NXT radar. Slow/blocked REST calls are cancelled at the cycle deadline."""
    next_run=time.monotonic()
    while True:
        ensure_daily_rollover()
        if not (APP_KEY and SECRET and discovery_window_active() and nxt_radar_session_active()):
            sleep_sec=2 if realtime_runtime_awake() else WS_WAKE_GUARD_SECONDS
            STATE.rest_status['_nxt_fast_cycle']={'ok':True,'skipped':'NXT_SESSION_INACTIVE' if realtime_runtime_awake() else 'OVERNIGHT_FROZEN','wake_guard_sec':sleep_sec,'at':time.time()};next_run=time.monotonic()+sleep_sec;await asyncio.sleep(sleep_sec);continue
        interval=NXT_FASTEST_DISCOVERY_SECONDS if nxt_fastest_window_active() else NXT_PREMARKET_DISCOVERY_SECONDS if nxt_premarket_session_active() else NXT_ALLDAY_DISCOVERY_SECONDS
        nowm=time.monotonic()
        if next_run<nowm-interval:next_run=nowm
        if nowm<next_run:await asyncio.sleep(next_run-nowm)
        started=time.time();STATE.nxt_fast_scan_cycles+=1;scan_id=int(started*1000)+1;successful_sources=set();failed_sources=set();changed=set();tasks=[]
        async with STATE.lock:
            for cand in STATE.candidates.values():cand.source_prev_base=sum(cand.source_hits.values())
        for market in ('001','101'):
            for source,api_id,tpl in NXT_FAST_RANK_SPECS:tasks.append(asyncio.create_task(_fetch_rank_source(market,source,api_id,tpl,-10)))
        pending=set(tasks)
        try:
            deadline=time.monotonic()+min(NXT_FAST_REST_TIMEOUT,max(1.0,interval-0.25))
            while pending and time.monotonic()<deadline:
                timeout=max(0.01,deadline-time.monotonic());done,pending=await asyncio.wait(pending,timeout=timeout,return_when=asyncio.FIRST_COMPLETED)
                if not done:break
                for fut in done:
                    try:result=fut.result()
                    except Exception as e:failed_sources.add('TASK:'+str(e)[:60]);continue
                    ok,key,codes=await _apply_streamed_rank_result(result,scan_id);(successful_sources if ok else failed_sources).add(key);changed.update(codes)
            for fut in pending:fut.cancel()
            if pending:failed_sources.add(f'TIMEOUT_CANCEL:{len(pending)}')
            if tasks:await asyncio.gather(*tasks,return_exceptions=True)
            await _finalize_discovery_cycle(started,successful_sources,failed_sources,changed,scan_id,'NXT_FAST_ROLLING','_nxt_fast_cycle')
        except Exception as e:
            for fut in pending:fut.cancel()
            STATE.rest_status['_nxt_fast_cycle']={'ok':False,'msg':str(e)[:160],'at':time.time()}
        persist_performance();next_run+=interval
        await asyncio.sleep(max(0.05,next_run-time.monotonic()))

def _persist_next_day_picks():
    try:
        tmp=NXT_NEXT_DAY_PICK_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(STATE.next_day_picks,ensure_ascii=False,separators=(',',':')),encoding='utf-8');tmp.replace(NXT_NEXT_DAY_PICK_FILE)
    except Exception:pass

def load_next_day_picks():
    try:
        if NXT_NEXT_DAY_PICK_FILE.exists():
            x=json.loads(NXT_NEXT_DAY_PICK_FILE.read_text(encoding='utf-8'));STATE.next_day_picks=x if isinstance(x,dict) else {'rows':[]};STATE.morning_push_day=str(STATE.next_day_picks.get('morning_push_sent_day') or '');STATE.close_bet_signal_day=str(STATE.next_day_picks.get('close_bet_signal_day') or '')
    except Exception:STATE.next_day_picks={'rows':[]}

def build_next_day_close_picks(final:bool=False, close_signal:bool=False):
    """NXT whole-day memory + sustained close strength.

    CLOSE_READY/CLOSE_BUY can emerge any time in the 19:30-19:50 window after the live state has
    remained strong for 45/90 seconds. It is no longer a one-shot 19:50 snapshot.
    """
    now=time.time();rows=[];source_day=today_kst();effective=_next_effective_day(source_day);same_source=str(STATE.next_day_picks.get('source_day') or '')==source_day;prev_by={str(x.get('code')):x for x in (STATE.next_day_picks.get('rows') or [])} if same_source else {}
    ledger=(STATE.nxt_daily_ledger or {}).get('rows') or {}
    for code,led in ledger.items():
        if not isinstance(led,dict):continue
        c=STATE.candidates.get(code);m=(c.metrics if c else {}) or {};nsm=(_venue_smart(c,'NXT') if c else {})
        last_price=num(c.last_price_by_venue.get('NXT')) if c else 0.0;last_price=last_price or num(led.get('last_price'));rate=num(c.last_rate_by_venue.get('NXT')) if c else num(led.get('last_rate'));last_at=num(c.last_tick_at_by_venue.get('NXT')) if c else num(led.get('last_tick_at'));last_at=last_at or num(led.get('last_tick_at'));age=now-last_at if last_at else 10**9
        peak_rate=num(led.get('peak_rate'));rad=max(num(led.get('max_radar')),num(m.get('nxt_radar_score')));take=max(num(led.get('max_takeover')),num(m.get('nxt_takeover_score')))
        a30=num(m.get('nxt_volume_accel_30s'),1) if c else num(led.get('max_accel30'),1);a60=num(m.get('nxt_volume_accel_60s'),1) if c else num(led.get('max_accel60'),1);bp=num(m.get('nxt_buy_pressure'),50) if c else num(led.get('max_buy_pressure'),50);ob=num(m.get('nxt_orderbook_presignal')) if c else num(led.get('max_orderbook'));sw=str(m.get('nxt_second_wave_state') or led.get('second_wave_state') or '');recovery=str(m.get('nxt_recovery_state') or led.get('recovery_state') or '')
        if peak_rate<2.0 and rad<35 and not led.get('stages'):continue
        mem=STATE.nxt_first_wave_memory.get(code) or {};bars=list(mem.get('bars') or []);now_min=int(now//60)
        recent10=[b for b in bars if 0<=now_min-int(b.get('minute') or 0)<=9];prior30=[b for b in bars if 10<=now_min-int(b.get('minute') or 0)<=39]
        v10=sum(num(b.get('volume')) for b in recent10);vp=(sum(num(b.get('volume')) for b in prior30)/3) if prior30 else 0;late_vol=v10/max(vp,1) if vp>0 else (1.0 if recent10 else 0.0)
        hi10=max([num(b.get('high')) for b in recent10 if num(b.get('high'))>0] or [last_price or num(led.get('peak_price')) or 1]);close_loc=(last_price/max(hi10,1)) if last_price>0 else 0
        prog_delta=num(nsm.get('program_delta'));inst_delta=num(nsm.get('institution_delta'));vf=venue_smart_freshness(c,'NXT') if c else {'program_fresh':False,'investor_fresh':False};big_count=int(m.get('nxt_big_buy_count_60s') or 0);big_notional=num(m.get('nxt_big_buy_notional_60s'))
        recovery_ratio=num(m.get('nxt_recovery_ratio'),num(led.get('recovery_ratio')));recovery_gap=num(m.get('nxt_recovery_peak_gap_pct'),num(led.get('recovery_peak_gap_pct')));recovery_dd=num(m.get('nxt_recovery_drawdown_pct'),num(led.get('recovery_drawdown_pct')));wall_v2=num(m.get('nxt_orderbook_wall_v2_score'));wall_cancel=num(m.get('nxt_orderbook_wall_cancel_risk'));event_score,event_row=(market_event_signal(c,now) if c else (0.0,None))
        history=12+clamp((peak_rate-2.0)*1.1,0,16)+rad*0.15+take*0.08+(4 if sw in ('SECOND_WAVE_READY','SECOND_WAVE_BUY') else 1 if sw=='SECOND_WAVE_BASE' else 0)+(6 if recovery=='RECOVERY_BUY' else 4 if recovery=='RECOVERY_READY' else 0)
        live=clamp((a30-1)*6,0,9)+clamp((a60-1)*5,0,8)+clamp((bp-50)*0.38,0,9)+clamp((close_loc-.94)*100,0,9)+clamp((late_vol-1)*5,0,9)+clamp(ob,0,5)+min(3,big_count*1.2)
        flow=(3 if vf.get('program_fresh') and prog_delta>0 else -2 if vf.get('program_fresh') and prog_delta<0 else 0)+(2 if vf.get('investor_fresh') and inst_delta>0 else -1 if vf.get('investor_fresh') and inst_delta<0 else 0)
        fresh_bonus=8 if age<=8 else 4 if age<=30 else 0;stale_penalty=0 if age<=60 else min(18,(age-60)/60*3)
        pick=history+live+flow+fresh_bonus-stale_penalty+clamp(wall_v2,-2.5,2.5)*1.2+clamp(event_score,-6,4)
        # A verified deep-shakeout recovery may legitimately still be +12~18%; do not punish it like a raw chase.
        if rate>15 and not recovery:pick-=min(14,(rate-15)*1.7)
        elif rate>NXT_RECOVERY_MAX_ENTRY_RATE:pick-=min(18,(rate-NXT_RECOVERY_MAX_ENTRY_RATE)*2.0)
        if rate<0:pick-=min(8,abs(rate)*2)
        max_live_rate=NXT_RECOVERY_MAX_ENTRY_RATE if recovery in ('RECOVERY_READY','RECOVERY_BUY') else 12.0
        hard_live=bool(age<=8 and 0.5<=rate<=max_live_rate and bp>=56 and close_loc>=.965 and ob>=-1.0)
        confirm_flow=bool((vf.get('program_fresh') and prog_delta>0) or big_count>=2 or sw=='SECOND_WAVE_BUY' or recovery=='RECOVERY_BUY' or wall_v2>=1.2 or (bp>=62 and ob>=0.5))
        activity_ok=bool(a30>=1.25 or a60>=1.15 or late_vol>=1.20 or recovery=='RECOVERY_BUY')
        strong_now=bool(close_signal and pick>=NXT_CLOSE_BET_READY_SCORE and hard_live and (activity_ok or confirm_flow) and event_score>-5.0 and wall_cancel<0.9)
        old=prev_by.get(code) or {};old_since=num(old.get('close_strong_since'));old_samples=int(old.get('close_strong_samples') or 0)
        if strong_now:
            strong_since=old_since or now;strong_samples=old_samples+1;strong_hold=max(0.0,now-strong_since)
        else:
            strong_since=0.0;strong_samples=0;strong_hold=0.0
        ready_live=bool(strong_now and strong_hold>=NXT_CLOSE_BET_READY_HOLD_SECONDS)
        buy_live=bool(ready_live and strong_hold>=NXT_CLOSE_BET_BUY_HOLD_SECONDS and pick>=NXT_CLOSE_BET_BUY_SCORE and confirm_flow and activity_ok)
        if close_signal:
            signal='CLOSE_BUY' if buy_live else 'CLOSE_READY' if ready_live else 'WATCH'
        else:
            signal=old.get('close_bet_signal') if old.get('close_bet_signal') in ('CLOSE_BUY','CLOSE_READY') else 'WATCH'
            strong_since=old_since;strong_samples=old_samples;strong_hold=num(old.get('close_strong_hold_sec'))
        signal_at=now_kst() if close_signal and signal in ('CLOSE_BUY','CLOSE_READY') and signal!=old.get('close_bet_signal') else old.get('close_bet_at')
        reasons=[]
        if peak_rate>=5:reasons.append(f'당일 NXT 최고 +{peak_rate:.1f}%')
        if late_vol>=1.25:reasons.append(f'최근10분 거래량 {late_vol:.1f}x')
        if close_loc>=.97:reasons.append('NXT 10분 고가권 유지')
        if a30>=1.35 or a60>=1.2:reasons.append(f'NXT 가속 30초 {a30:.1f}x / 60초 {a60:.1f}x')
        if big_count>=2:reasons.append(f'1억+ 공격체결 {big_count}회')
        if vf.get('program_fresh'):reasons.append(f'NXT 프로그램 Δ {prog_delta:+,.0f}')
        if wall_v2>=0.8:reasons.append(f'매수벽 지속/흡수 +{wall_v2:.1f}')
        elif wall_cancel>=0.8:reasons.append('매수벽 급소멸 위험')
        if event_score<0:reasons.append(f'공시/뉴스 악재 {event_score:.1f}')
        elif event_score>0:reasons.append(f'공시/뉴스 호재 +{event_score:.1f}')
        if recovery:reasons.append(f'{recovery} · 낙폭 {recovery_dd:.1f}% / 회복 {recovery_ratio*100:.0f}% / 고점거리 {recovery_gap:.1f}%')
        elif sw:reasons.append(sw.replace('_',' '))
        if strong_hold>0:reasons.append(f'종가강도 {strong_hold:.0f}초 지속')
        rows.append({'code':code,'name':str(led.get('name') or (c.name if c else code)),'sector':str(led.get('sector') or (c.sector if c else '')),'score':round(pick,1),'grade':'A' if pick>=74 else 'B' if pick>=64 else 'WATCH','close_bet_signal':signal,'close_bet_at':signal_at,'close_strong_since':strong_since,'close_strong_samples':strong_samples,'close_strong_hold_sec':round(strong_hold,1),'nxt_close_price':round(last_price,2) if last_price else None,'nxt_close_rate':round(rate,2),'nxt_peak_rate':round(peak_rate,2),'nxt_peak_price':round(num(led.get('peak_price')),2),'nxt_radar_score':round(rad,1),'nxt_takeover_score':round(take,1),'nxt_late_volume_ratio':round(late_vol,2),'close_location_10m':round(close_loc,3),'nxt_volume_accel_30s':round(a30,2),'nxt_volume_accel_60s':round(a60,2),'nxt_buy_pressure':round(bp,1),'nxt_orderbook_presignal':round(ob,1),'nxt_orderbook_wall_v2':round(wall_v2,2),'nxt_orderbook_wall_cancel_risk':round(wall_cancel,3),'event_signal':round(event_score,2),'event_polarity':(event_row or {}).get('polarity'),'nxt_program_delta':round(prog_delta,2),'nxt_institution_delta':round(inst_delta,2),'nxt_program_fresh':bool(vf.get('program_fresh')),'nxt_investor_fresh':bool(vf.get('investor_fresh')),'nxt_big_buy_count_60s':big_count,'nxt_big_buy_notional_60s':round(big_notional,0),'second_wave_state':sw,'recovery_state':recovery,'recovery_ratio':round(recovery_ratio,3),'recovery_drawdown_pct':round(recovery_dd,2),'recovery_peak_gap_pct':round(recovery_gap,2),'last_activity_age_sec':round(age),'first_alert_rate':led.get('first_alert_rate'),'stages':led.get('stages') or [],'reasons':reasons[:8],'snapshot_at':now_kst(),'premarket_status':old.get('premarket_status','WAITING'),'premarket_move_pct':old.get('premarket_move_pct'),'premarket_price':old.get('premarket_price')})
    rows.sort(key=lambda x:(1 if x.get('close_bet_signal')=='CLOSE_BUY' else .5 if x.get('close_bet_signal')=='CLOSE_READY' else 0,x['score']),reverse=True);rows=[x for x in rows if x['score']>=NXT_CLOSE_PICK_MIN_SCORE][:NXT_CLOSE_PICK_LIMIT]
    STATE.next_day_picks={'version':APP_VERSION,'source_day':source_day,'effective_day':effective,'generated_at':now_kst(),'final':bool(final),'source':'NXT_DATA_TRUTH_CLOSE_BET_19_30_19_50','rows':rows,'close_bet_signal_day':STATE.close_bet_signal_day,'morning_push_sent_day':STATE.morning_push_day}
    _persist_next_day_picks();_persist_nxt_memory_ledger();return rows

def emit_close_bet_candidate_alert(row:dict):
    signal=str(row.get('close_bet_signal') or '')
    if signal not in ('CLOSE_READY','CLOSE_BUY'):return False
    code=str(row.get('code') or '');stage='CLOSE_BET_BUY' if signal=='CLOSE_BUY' else 'CLOSE_BET_READY';hold=num(row.get('close_strong_hold_sec'))
    eid=hashlib.sha1(f'{today_kst()}|{code}|{stage}'.encode()).hexdigest()[:18]
    title=f"NXT 종가배팅 {'BUY' if signal=='CLOSE_BUY' else 'READY'} · {row.get('name') or code}"
    body=f"{num(row.get('nxt_close_rate')):+.2f}% · 강도 {hold:.0f}초 지속 · 점수 {num(row.get('score')):.0f} · "+' · '.join((row.get('reasons') or [])[:2])
    rec={'id':eid,'event':'NXT_CLOSE_BET_CANDIDATE','version':APP_VERSION,'day':today_kst(),'stage':stage,'priority':16 if signal=='CLOSE_BUY' else 13,'code':code,'name':row.get('name') or code,'price':num(row.get('nxt_close_price')),'change_rate':num(row.get('nxt_close_rate')),'score':num(row.get('score')),'at':time.time(),'at_kst':now_kst(),'title':title,'body':body,'reasons':list(row.get('reasons') or [])[:8],'close_bet':row}
    return _persist_nxt_alert_record(rec)

def emit_close_bet_signal(rows:list[dict]):
    """19:50 final summary. Candidate READY/BUY pushes may already have fired from 19:30 onward."""
    actionable=[r for r in rows if r.get('close_bet_signal') in ('CLOSE_BUY','CLOSE_READY')][:NXT_CLOSE_BET_LIMIT]
    if not actionable:return False
    buys=[r for r in actionable if r.get('close_bet_signal')=='CLOSE_BUY'];names=', '.join(f"{r.get('name')} {r.get('close_bet_signal')}" for r in actionable)
    rec={'id':hashlib.sha1(f'{today_kst()}|CLOSE_BET_SIGNAL'.encode()).hexdigest()[:18],'event':'NXT_CLOSE_BET_SIGNAL','version':APP_VERSION,'day':today_kst(),'stage':'CLOSE_BET_SIGNAL','priority':6,'code':'NXT','name':'19:30~19:50 종가배팅','price':0,'change_rate':0,'score':max(num(r.get('score')) for r in actionable),'at':time.time(),'at_kst':now_kst(),'title':f'NXT 종가배팅 최종 · BUY {len(buys)} / READY {len(actionable)-len(buys)}','body':names,'reasons':['19:30~19:50 NXT-only 강도 지속 확인','NXT 공격매수·호가·프로그램·회복패턴 재확인','익일 07:50 유지 · 08:00 프리마켓 재검증'],'picks':actionable}
    return _persist_nxt_alert_record(rec)

def evaluate_premarket_picks():
    d=STATE.next_day_picks or {};rows=d.get('rows') or []
    if str(d.get('effective_day') or '')!=today_kst() or not nxt_premarket_session_active():return
    changed=False
    for r in rows:
        c=STATE.candidates.get(str(r.get('code') or ''))
        nxt_at=num(c.last_tick_at_by_venue.get('NXT'));nxt_price=num(c.last_price_by_venue.get('NXT'))
        if not c or not nxt_at or time.time()-nxt_at>8 or nxt_price<=0:continue
        base=num(r.get('nxt_close_price'));move=(nxt_price/base-1)*100 if base>0 else 0;rad=num(c.metrics.get('nxt_radar_score'));hits=int(c.metrics.get('nxt_radar_count') or 0);a=max(num(c.metrics.get('nxt_volume_accel_30s'),1),num(c.metrics.get('nxt_volume_accel_60s'),1));ready=bool(int(c.metrics.get('nxt_tick_count_60s') or 0)>=4)
        status='SURGE' if move>=2 and ((ready and a>=1.4) or hits>=2 or rad>=55) else 'CONFIRMED' if move>=0.5 and (hits>=1 or rad>=40) else 'WEAK' if move<=-1.5 else 'WATCH'
        prev=r.get('premarket_status');r.update({'premarket_status':status,'premarket_move_pct':round(move,2),'premarket_price':nxt_price,'premarket_radar':round(rad,1),'premarket_volume_accel':round(a,2) if ready else None,'premarket_updated_at':now_kst()});changed=True
        if status in ('CONFIRMED','SURGE') and prev not in ('CONFIRMED','SURGE'):
            emit_nxt_alert(c,'PREMARKET_CONFIRM',[f'전일 NXT 종가후보 {r.get("grade")}',f'전일 NXT 종가대비 {move:+.2f}%',f'프리마켓 Radar {rad:.0f}'])
    if changed:_persist_next_day_picks()

async def close_pick_loop():
    await asyncio.sleep(5)
    while True:
        try:
            sec=kst_seconds();day=today_kst()
            if is_krx_trading_day() and between(sec,NXT_CLOSE_BET_WINDOW_START_SECONDS,20*3600+3*60):
                close_window=between(sec,NXT_CLOSE_BET_WINDOW_START_SECONDS,NXT_CLOSE_BET_WINDOW_END_SECONDS)
                rows=build_next_day_close_picks(final=sec>=20*3600,close_signal=close_window)
                if close_window:
                    # Per-candidate alerts are deduped by day/code/stage, so READY can upgrade to BUY without spam.
                    for row in rows[:NXT_CLOSE_BET_LIMIT]:emit_close_bet_candidate_alert(row)
                # 19:50 is only the final summary/freeze point; actionable alerts may have fired earlier.
                if sec>=NXT_CLOSE_BET_WINDOW_END_SECONDS and STATE.close_bet_signal_day!=day:
                    emit_close_bet_signal(rows);STATE.close_bet_signal_day=day;STATE.next_day_picks['close_bet_signal_day']=day;_persist_next_day_picks()
            # 07:50 onward the prior close list is visible and a single summary push is sent.
            d=STATE.next_day_picks or {}
            if is_krx_trading_day() and NXT_MORNING_LIST_SECONDS<=sec<NXT_MORNING_PUSH_END_SECONDS and str(d.get('effective_day') or '')==day and d.get('rows') and STATE.morning_push_day!=day:
                names=', '.join(str(x.get('name') or x.get('code')) for x in (d.get('rows') or [])[:5]);rows=d.get('rows') or []
                rec={'id':hashlib.sha1(f'{day}|MORNING_CLOSE_PICKS'.encode()).hexdigest()[:18],'event':'NXT_MORNING_CLOSE_PICKS','version':APP_VERSION,'day':day,'stage':'MORNING_CLOSE_PICKS','priority':2,'code':'NXT','name':'종가추천','price':0,'change_rate':0,'score':0,'at':time.time(),'at_kst':now_kst(),'title':'07:50 NXT 종가추천 리스트','body':f'{len(rows)}종목 · {names}','reasons':['전일 19:30~19:50 NXT CLOSE_BET 지속강도 기반','08:00 프리마켓에서 NXT-only 재확인 필요']}
                _persist_nxt_alert_record(rec);STATE.morning_push_day=day;d['morning_push_sent_day']=day;_persist_next_day_picks()
            if nxt_premarket_session_active():evaluate_premarket_picks()
        except Exception as e:STATE.smart_status['close_pick_error']={'ok':False,'msg':str(e)[:140]}
        await asyncio.sleep(15)

def set_entry_state(c:Candidate, state:str, reason:str=''):
    now=time.time(); c.entry_state=state; c.entry_state_since=now; c.reject_reason=reason
    if state=='DISCOVERY':
        c.pressure_started_at=0;c.pressure_peak=0;c.pullback_low=0;c.reaccel_started_at=0;c.reaccel_start_price=0;c.direct_started_at=0;c.direct_start_price=0
    elif state=='PRESSURE_BUILD':
        c.pressure_started_at=now;c.pressure_peak=c.last_price;c.pullback_low=0;c.reaccel_started_at=0;c.reaccel_start_price=0;c.direct_started_at=0;c.direct_start_price=0
    elif state=='PULLBACK':
        c.pullback_low=c.last_price
    elif state=='REACCEL':
        c.reaccel_started_at=now;c.reaccel_start_price=c.last_price
    elif state=='DIRECT_ARM':
        c.direct_started_at=now;c.direct_start_price=c.last_price


def entry_hard_reject(c:Candidate, venue:str|None=None):
    m=c.metrics;venue=str(venue or '').upper();reasons=[]
    if venue=='NXT':
        rate=num(c.last_rate_by_venue.get('NXT'));imp=num(m.get('nxt_impulse_60s'));vgap=num(m.get('nxt_micro_vwap_gap'));one=num(m.get('nxt_one_tick_ratio'))
    else:
        rate=num(c.rate);imp=num(m.get('impulse_60s'));vgap=num(m.get('micro_vwap_gap',m.get('vwap_gap')));one=num(m.get('one_tick_ratio'))
    if rate>12:reasons.append('당일 상승률 과열')
    if imp>ENTRY_MAX_IMPULSE:reasons.append('1분 급등 과열')
    if vgap>ENTRY_MAX_VWAP_GAP:reasons.append('Micro VWAP 추격구간')
    if venue!='NXT' and num(m.get('session_vwap_gap'))>max(2.0,ENTRY_MAX_VWAP_GAP+0.5):reasons.append('Session VWAP 과이격')
    if one>0.45:reasons.append('단일체결 편중')
    if bool(m.get('sector_overheat')):reasons.append('섹터 과열')
    if num(m.get('event_signal'))<=-5.0:reasons.append('중대 악재 공시/뉴스')
    return reasons

def smart_freshness(c:Candidate, venue:str|None=None):
    if venue in ('KRX','NXT'):return venue_smart_freshness(c,venue)
    now=time.time();program_age=(now-c.program_updated_at) if c.program_updated_at else 10**9;program_rt_age=(now-c.program_rt_at) if c.program_rt_at else 10**9;investor_age=(now-c.investor_updated_at) if c.investor_updated_at else 10**9
    return {'program_age':program_age,'program_rt_age':program_rt_age,'program_fresh':min(program_age,program_rt_age)<=PROGRAM_HARD_FRESH_SECONDS,'investor_age':investor_age,'investor_fresh':investor_age<=INVESTOR_FRESH_SECONDS}

def smart_direction_ok(c:Candidate):
    sm=c.smart or {};fresh=smart_freshness(c)
    if not fresh['program_fresh']:return False,'프로그램 수급 freshness 부족'
    pd=num(sm.get('program_delta'));td=num(sm.get('trust_delta'));pnd=num(sm.get('pension_delta'));ind=num(sm.get('institution_delta'))
    positives=sum(1 for x in (pd,td,pnd,ind) if x>0);negatives=sum(1 for x in (pd,td,pnd,ind) if x<0)
    if negatives>=3 and positives==0:return False,'프로그램·기관 수급 동반 둔화'
    if not fresh['investor_fresh']:return True,'프로그램 확인 / 투자자 수급 갱신대기'
    return True,'스마트머니 방향 확인'

def venue_flow_snapshot(c:Candidate, venue:str):
    venue=str(venue or '').upper();sm=_venue_smart(c,venue);fresh=venue_smart_freshness(c,venue);m=c.metrics or {}
    if venue=='NXT':
        return {'smart':sm,'fresh':fresh,'buy_pressure':num(m.get('nxt_buy_pressure'),50),'algo':num(m.get('nxt_algo_persistence'),50),'orderbook':num(m.get('nxt_orderbook_presignal')),'impulse':num(m.get('nxt_impulse_60s')),'breakout':num(m.get('nxt_micro_breakout')),'vwap_gap':num(m.get('nxt_micro_vwap_gap')),'volume_accel':num(m.get('nxt_volume_accel'),1),'volume_accel_ready':bool(m.get('nxt_volume_accel_ready')),'program_delta':num(sm.get('program_delta')),'institution_delta':num(sm.get('institution_delta'))}
    if venue=='KRX':
        return {'smart':sm,'fresh':fresh,'buy_pressure':num(m.get('krx_buy_pressure'),50),'algo':num(m.get('krx_algo_persistence'),50),'orderbook':num(m.get('krx_orderbook_presignal')),'impulse':num(m.get('krx_impulse_60s')),'breakout':num(m.get('krx_micro_breakout')),'vwap_gap':num(m.get('krx_micro_vwap_gap')),'volume_accel':num(m.get('krx_volume_accel'),1),'volume_accel_ready':bool(m.get('krx_volume_accel_ready')),'program_delta':num(sm.get('program_delta')),'institution_delta':num(sm.get('institution_delta'))}
    return {'smart':c.smart or {},'fresh':smart_freshness(c),'buy_pressure':num(m.get('buy_pressure'),50),'algo':num(m.get('algo_persistence'),50),'orderbook':num(m.get('orderbook_presignal')),'impulse':num(m.get('impulse_60s')),'breakout':num(m.get('micro_breakout')),'vwap_gap':num(m.get('micro_vwap_gap',m.get('vwap_gap'))),'volume_accel':num(m.get('volume_accel'),1),'volume_accel_ready':bool(m.get('volume_accel_ready')),'program_delta':num((c.smart or {}).get('program_delta')),'institution_delta':num((c.smart or {}).get('institution_delta'))}

def venue_smart_direction_ok(c:Candidate, venue:str):
    venue=str(venue or '').upper();flow=venue_flow_snapshot(c,venue);sm=flow.get('smart') or {};fresh=flow.get('fresh') or {}
    if not fresh.get('program_fresh'):return False,f'{venue} 프로그램 수급 freshness 부족'
    pd=num(sm.get('program_delta'));td=num(sm.get('trust_delta'));pnd=num(sm.get('pension_delta'));ind=num(sm.get('institution_delta'))
    positives=sum(1 for x in (pd,td,pnd,ind) if x>0);negatives=sum(1 for x in (pd,td,pnd,ind) if x<0)
    if negatives>=3 and positives==0:return False,f'{venue} 프로그램·기관 수급 동반 둔화'
    if not fresh.get('investor_fresh'):return True,f'{venue} 프로그램 확인 / 투자자 수급 갱신대기'
    return True,f'{venue} 스마트머니 방향 확인'

def venue_smart_flow_score(c:Candidate, venue:str):
    """Read-only display score built only from the selected venue's live microflow/smart data."""
    f=venue_flow_snapshot(c,venue);sm=f.get('smart') or {};fresh=f.get('fresh') or {}
    score=(num(f.get('buy_pressure'),50)-50)*0.25+(num(f.get('algo'),50)-50)*0.15+clamp(num(f.get('orderbook')),-3,3)*1.2
    if fresh.get('program_fresh'):
        scale=max(abs(num(sm.get('program_net'))),100000);score+=clamp(num(sm.get('program_delta'))/scale*4,-4,4)
    if fresh.get('investor_fresh'):
        scale=max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000000);score+=clamp(num(sm.get('institution_delta'))/scale*3,-3,3)
    return round(clamp(score,-20,20),2)

def venue_exit_strength(c:Candidate, venue:str):
    """0-100 venue-locked continuation strength used only by automatic EXIT management."""
    f=venue_flow_snapshot(c,venue);sm=f.get('smart') or {};fresh=f.get('fresh') or {}
    score=50+(num(f.get('buy_pressure'),50)-50)*0.35+(num(f.get('algo'),50)-50)*0.20
    score+=clamp(num(f.get('impulse'))*3,-8,8)+clamp(num(f.get('vwap_gap'))*4,-6,6)+clamp(num(f.get('breakout'))*5,0,8)+clamp(num(f.get('orderbook')),-4,4)
    if fresh.get('program_fresh'):
        scale=max(abs(num(sm.get('program_net'))),100000);score+=clamp(num(sm.get('program_delta'))/scale*8,-6,6)
    if fresh.get('investor_fresh'):
        scale=max(abs(num(sm.get('institution_net')))+abs(num(sm.get('foreign_net'))),1000000);score+=clamp(num(sm.get('institution_delta'))/scale*5,-4,4)
    return round(clamp(score,0,100),1)

def direct_support_ok(c:Candidate):
    """Direct ignition has no pullback protection, so both program and investor truth must be current."""
    sm=c.smart or {}; fresh=smart_freshness(c)
    if not fresh.get('program_fresh') or not fresh.get('investor_fresh'):
        return False,'DIRECT 수급 freshness 부족'
    deltas=(num(sm.get('program_delta')),num(sm.get('trust_delta')),num(sm.get('pension_delta')),num(sm.get('institution_delta')))
    positives=sum(1 for x in deltas if x>0); negatives=sum(1 for x in deltas if x<0)
    if negatives>=3:return False,'스마트머니 다중 둔화'
    if positives>=2 or (deltas[0]>0 and positives>=1):return True,'스마트머니 재가속 동조'
    m=c.metrics
    fallback=(bool(m.get('dual_venue')) and num(m.get('sector_score'))>=3 and num(m.get('sector_breadth'))>=3 and num(m.get('buy_pressure'))>=64 and deltas[0]>=0)
    return (fallback, 'KRX·NXT+섹터 확산 보조확인' if fallback else 'DIRECT 수급근거 부족')


def dynamic_reentry_ok(c:Candidate, now:float):
    if not c.last_buy_at or not c.last_signal_price:return False,''
    elapsed=now-c.last_buy_at
    if elapsed<ENTRY_REENTRY_MIN_SEC:return False,''
    m=c.metrics; gain=(c.last_price/c.last_signal_price-1)*100 if c.last_signal_price else 0
    smart_ok,_=smart_direction_ok(c)
    ok=(gain>=ENTRY_REENTRY_GAIN_PCT and c.score>=72 and num(m.get('volume_accel'),1)>=1.5 and num(m.get('buy_pressure'))>=60 and num(m.get('algo_persistence'))>=60 and num(m.get('micro_breakout'))>=0.20 and smart_ok and not entry_hard_reject(c))
    return ok,(f'새 고점 +{gain:.1f}% · 거래량/수급 재가속' if ok else '')


def advance_entry_machine(c:Candidate, sess:dict, age_ms:float):
    """Balanced dual-path entry machine.

    Route A (high trust): DISCOVERY -> PRESSURE_BUILD -> PULLBACK -> REACCEL -> BUY.
    Route B (opportunity rescue): DISCOVERY -> PRESSURE_BUILD -> DIRECT_ARM -> BUY,
    only when momentum, order-flow, VWAP and smart/sector confirmation are all unusually strong.
    No market-wide signal quota is enforced.
    """
    now=time.time(); m=c.metrics; price=c.last_price
    if not price:return
    if not sess.get('active') or age_ms>FRESH_MS:
        if c.entry_state not in ('BUY','COOLDOWN'): set_entry_state(c,'DISCOVERY','세션/실체결 비활성')
        c.metrics.update({'entry_state':c.entry_state,'entry_reason':c.reject_reason,'entry_ready':False,'entry_route':''})
        return

    score=num(c.score); bp=num(m.get('buy_pressure')); accel=num(m.get('volume_accel'),1); algo=num(m.get('algo_persistence')); vgap=num(m.get('micro_vwap_gap',m.get('vwap_gap'))); session_gap=num(m.get('session_vwap_gap')); impulse=num(m.get('impulse_60s')); breakout=num(m.get('micro_breakout'))
    hard=entry_hard_reject(c); smart_ok,smart_note=smart_direction_ok(c); direct_ok,direct_note=direct_support_ok(c)

    # Cooldown is normally 10 minutes, but a truly new price/flow regime can unlock after 7 minutes.
    if c.cooldown_until>now:
        unlock,unlock_note=dynamic_reentry_ok(c,now)
        if unlock:
            c.reentry_unlocked=True;c.cooldown_until=0;set_entry_state(c,'DISCOVERY',unlock_note)
        else:
            if c.entry_state=='BUY' and now-c.entry_state_since<30: pass
            else:c.entry_state='COOLDOWN'
            c.metrics.update({'entry_state':c.entry_state,'entry_reason':'재신호 보호구간','entry_ready':False,'cooldown_sec':round(c.cooldown_until-now),'entry_route':c.last_buy_route})
            return
    if c.entry_state in ('BUY','COOLDOWN') and c.cooldown_until<=now:set_entry_state(c,'DISCOVERY')
    if c.signal_count_today>=ENTRY_MAX_DAILY:
        c.entry_state='COOLDOWN';c.metrics.update({'entry_state':'COOLDOWN','entry_reason':'일일 BUY 상한 도달','entry_ready':False,'entry_route':c.last_buy_route});return
    if c.entry_state=='REJECTED':
        if now-c.entry_state_since<20:
            c.metrics.update({'entry_state':'REJECTED','entry_reason':c.reject_reason,'entry_ready':False,'entry_route':''});return
        set_entry_state(c,'DISCOVERY')

    pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak>0 else 0
    recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low>0 else 0

    if c.entry_state=='DISCOVERY':
        if score>=ENTRY_PRESSURE_SCORE and bp>=53 and algo>=50 and not hard:
            set_entry_state(c,'PRESSURE_BUILD','압력 지속성 확인 중')

    elif c.entry_state=='PRESSURE_BUILD':
        c.pressure_peak=max(c.pressure_peak or price,price)
        pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak else 0
        held=now-c.pressure_started_at if c.pressure_started_at else 0
        # Direct route is checked before the pullback timeout. It requires a clean, not-yet-overextended breakout.
        dna_match=num(c.metrics.get('rally_dna_match'));dna_trap=num(c.metrics.get('rally_dna_trap'));dna_cal=bool(c.metrics.get('rally_dna_calibrated'));dna_relax=(min(DNA_EARLY_TRIGGER_MAX_RELAX,max(0.0,(dna_match-DNA_EARLY_TRIGGER_MIN_MATCH)/4.0)) if dna_cal and dna_match>=DNA_EARLY_TRIGGER_MIN_MATCH and dna_trap<45 else 0.0);direct_threshold=DIRECT_SCORE-dna_relax
        c.metrics['direct_threshold']=round(direct_threshold,1);c.metrics['dna_early_relax']=round(dna_relax,1)
        direct_arm=(bool(m.get('volume_accel_ready')) and held>=DIRECT_HOLD_SEC and score>=direct_threshold and bp>=DIRECT_MIN_BUY_PRESSURE and accel>=DIRECT_MIN_ACCEL and algo>=DIRECT_MIN_ALGO_PERSIST and breakout>=DIRECT_MIN_BREAKOUT and DIRECT_MIN_IMPULSE<=impulse<=DIRECT_MAX_IMPULSE and 0.05<=vgap<=DIRECT_MAX_VWAP_GAP and -0.10<=session_gap<=1.60 and pullback_pct<ENTRY_PULLBACK_MIN and num(c.rate)<=9.5 and direct_ok and not hard)
        if hard:
            set_entry_state(c,'REJECTED',' · '.join(hard[:2]))
        elif direct_arm:
            set_entry_state(c,'DIRECT_ARM',direct_note)
        elif score<52 or bp<48:
            set_entry_state(c,'DISCOVERY','압력 소멸')
        elif held>=ENTRY_HOLD_SEC and ENTRY_PULLBACK_MIN<=pullback_pct<=ENTRY_PULLBACK_MAX and score>=54:
            set_entry_state(c,'PULLBACK','건강한 눌림 확인')
        elif held>120:
            set_entry_state(c,'REJECTED','눌림·직접점화 모두 미확인')

    elif c.entry_state=='PULLBACK':
        c.pullback_low=min(c.pullback_low or price,price)
        pullback_pct=((c.pressure_peak-price)/c.pressure_peak*100) if c.pressure_peak else 0
        recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low else 0
        if hard or pullback_pct>ENTRY_PULLBACK_MAX or score<46:
            set_entry_state(c,'REJECTED','눌림 실패/과열' if not hard else ' · '.join(hard[:2]))
        elif recovery_pct>=0.15 and bp>=ENTRY_MIN_BUY_PRESSURE and accel>=1.15 and algo>=ENTRY_MIN_ALGO_PERSIST and -0.20<=vgap<=1.35 and -0.35<=session_gap<=1.85 and impulse<=2.20 and smart_ok:
            set_entry_state(c,'REACCEL','눌림 후 재가속 확인 중')

    elif c.entry_state=='REACCEL':
        recovery_pct=((price/c.pullback_low-1)*100) if c.pullback_low else 0
        if hard or score<54 or (c.pullback_low and price<c.pullback_low*0.998):
            set_entry_state(c,'PULLBACK','재가속 실패')
        else:
            confirm=(now-c.reaccel_started_at>=ENTRY_REACCEL_SEC and price>=c.reaccel_start_price*1.0004 and score>=PULLBACK_CONFIRM_SCORE and bp>=PULLBACK_CONFIRM_BUY_PRESSURE and accel>=PULLBACK_CONFIRM_ACCEL and algo>=ENTRY_MIN_ALGO_PERSIST and -0.10<=vgap<=1.35 and -0.25<=session_gap<=1.85 and impulse<=2.20 and smart_ok)
            if confirm:
                c.reasons=(['PULLBACK BUY · 눌림 후 재가속',f'공격매수 {bp:.0f}% · 공격매수틱 지속 {algo:.0f}%',smart_note]+list(c.reasons))[:5]
                record_buy_signal(c,'BUY','PULLBACK_REACCEL')

    elif c.entry_state=='DIRECT_ARM':
        elapsed=now-c.direct_started_at if c.direct_started_at else 0
        maintain=(bool(m.get('volume_accel_ready')) and score>=72 and bp>=59 and accel>=1.45 and algo>=58 and breakout>=0.15 and DIRECT_MIN_IMPULSE*0.6<=impulse<=DIRECT_MAX_IMPULSE and -0.02<=vgap<=1.15 and -0.10<=session_gap<=1.70 and direct_ok and not hard and num(c.rate)<=10)
        if not maintain or (c.direct_start_price and price<c.direct_start_price*0.997):
            set_entry_state(c,'PRESSURE_BUILD','DIRECT 점화 확인 실패')
        elif elapsed>=DIRECT_CONFIRM_SEC and price>=c.direct_start_price*1.0008:
            c.reasons=(['DIRECT IGNITION BUY · 눌림 없는 초강세',f'가속 {accel:.1f}x · 공격매수 {bp:.0f}% · 공격매수틱 지속 {algo:.0f}%',direct_note]+list(c.reasons))[:5]
            record_buy_signal(c,'BUY','DIRECT_IGNITION')

    c.metrics.update({
        'entry_state':c.entry_state,'entry_reason':c.reject_reason or c.metrics.get('entry_reason') or '',
        'entry_ready':c.entry_state in ('REACCEL','DIRECT_ARM','BUY'),'entry_route':('DIRECT_IGNITION' if c.entry_state=='DIRECT_ARM' else 'PULLBACK_REACCEL' if c.entry_state in ('PULLBACK','REACCEL') else c.last_buy_route if c.entry_state in ('BUY','COOLDOWN') else ''),
        'pressure_hold_sec':round(now-c.pressure_started_at,1) if c.pressure_started_at else 0,
        'pressure_peak':c.pressure_peak,'pullback_pct':round(pullback_pct,3),'pullback_low':c.pullback_low,
        'recovery_pct':round(recovery_pct,3),'reaccel_sec':round(now-c.reaccel_started_at,1) if c.reaccel_started_at else 0,
        'direct_sec':round(now-c.direct_started_at,1) if c.direct_started_at else 0,'direct_start_price':c.direct_start_price,
        'cooldown_sec':max(0,round(c.cooldown_until-now)) if c.cooldown_until else 0,
        'smart_direction_ok':smart_ok,'smart_direction_note':smart_note,'direct_support_ok':direct_ok,'direct_support_note':direct_note,
        'entry_policy':'PULLBACK_REACCEL_STRICT_CONFIRM | DIRECT_IGNITION','normal_market_signal_target':'8-25/day market-wide (diagnostic only, never quota)'
    })

def calc(c:Candidate):
    ticks=list(c.ticks); now=time.time(); reasons=[]; sess=market_session()
    rest=min(30,num(c.metrics.get('rest_base'))*0.55)
    if len(c.source_hits)>=3: reasons.append(f'독립순위 {len(c.source_hits)}중첩')
    age_ms=(now-c.last_tick_at)*1000 if c.last_tick_at else 10**12
    if len(ticks)<4 or age_ms>DISPLAY_FRESH_MS:
        c.score=round(rest,1); c.confidence=min(35,len(c.source_hits)*8); c.stage='SEED'
        if not sess['active']: reasons.append('시장 종료 · 실시간 신호 비활성')
        elif c.last_tick_at: reasons.append(f'실체결 stale {age_ms/1000:.1f}s')
        else: reasons.append('실시간 체결 축적 중')
        c.reasons=reasons[:4]; c.metrics.update({'fresh':False,'one_tick_ratio':0.0}); update_capture_performance(c); update_buy_signal_performance(c); advance_entry_machine(c,sess,age_ms); update_exit_positions_for_candidate(c); update_manual_positions_for_candidate(c); c.previous_stage=c.stage; return
    recent=[t for t in ticks if now-t.ts<=60]; prev=[t for t in ticks if 60<now-t.ts<=180]; r5=[t for t in ticks if now-t.ts<=300]
    if not recent: recent=ticks[-10:]
    p0=recent[0].price; p1=recent[-1].price; impulse=(p1/p0-1)*100 if p0 else 0
    vol60=sum(abs(t.qty) for t in recent); volume_accel_ready=len(prev)>=3; volprev=(sum(abs(t.qty) for t in prev)/2) if volume_accel_ready else 0.0; accel=(vol60/max(volprev,1)) if volume_accel_ready else 1.0
    signed=sum(t.qty for t in recent); buy_ratio=(signed/vol60*50+50) if vol60 else 50
    pos_ticks=sum(1 for t in recent if t.qty>0); neg_ticks=sum(1 for t in recent if t.qty<0); algo_persistence=(pos_ticks/max(pos_ticks+neg_ticks,1))*100
    prices=[t.price for t in r5 if t.price>0]; breakout=0
    if len(prices)>5:
        old=prices[:-max(2,len(prices)//5)]; oldmax=max(old) if old else max(prices); breakout=max(0,(p1/oldmax-1)*100) if oldmax else 0
    pv=sum(t.price*abs(t.qty) for t in r5); vv=sum(abs(t.qty) for t in r5); micro_vwap=pv/vv if vv else p1; above=(p1/micro_vwap-1)*100 if micro_vwap else 0
    last_tick=recent[-1] if recent else None; session_vwap=(last_tick.turnover/last_tick.cumvol) if last_tick and last_tick.cumvol>0 and last_tick.turnover>0 else ((c.session_pv/c.session_vv) if c.session_vv>0 else 0); session_above=(p1/session_vwap-1)*100 if session_vwap else 0
    range5=((max(prices)-min(prices))/micro_vwap*100) if prices and micro_vwap else 0
    compression=clamp(1-range5/3.0,0,1)
    venues={t.venue for t in ticks if now-t.ts<=120 and t.venue in ('KRX','NXT')}; dual=len(venues)==2
    krx_last=next((t.price for t in reversed(ticks) if t.venue=='KRX' and t.price>0),0.0);nxt_last=next((t.price for t in reversed(ticks) if t.venue=='NXT' and t.price>0),0.0)
    nxt_krx_basis=((nxt_last/krx_last-1)*100) if krx_last>0 and nxt_last>0 else None
    one_tick=max((abs(t.qty) for t in recent),default=0)/max(vol60,1)
    # Venue-isolated microstructure. Automatic EXIT and NXT management must never read the
    # opposite venue's tick pressure/VWAP/breakout merely because that venue printed last.
    def _venue_micro(vname:str):
        vr=[t for t in recent if t.venue==vname];vp=[t for t in prev if t.venue==vname];v5=[t for t in r5 if t.venue==vname]
        vol=sum(abs(t.qty) for t in vr);signed=sum(t.qty for t in vr);bp=(signed/vol*50+50) if vol else 50.0
        pos=sum(1 for t in vr if t.qty>0);neg=sum(1 for t in vr if t.qty<0);algo=pos/max(pos+neg,1)*100
        imp=((vr[-1].price/vr[0].price-1)*100) if len(vr)>=2 and vr[0].price else 0.0
        prices=[t.price for t in v5 if t.price>0];br=0.0
        if len(prices)>5:
            oldp=prices[:-max(2,len(prices)//5)];mx=max(oldp) if oldp else max(prices);br=max(0,(prices[-1]/mx-1)*100) if mx else 0.0
        pv=sum(t.price*abs(t.qty) for t in v5);vv=sum(abs(t.qty) for t in v5);vw=pv/vv if vv else (vr[-1].price if vr else 0.0);vg=((vr[-1].price/vw-1)*100) if vr and vw else 0.0;rg=((max(prices)-min(prices))/vw*100) if prices and vw else 0.0
        prev_ready=len(vp)>=3;prev_vol=(sum(abs(t.qty) for t in vp)/2) if prev_ready else 0.0;acc=(vol/max(prev_vol,1)) if prev_ready else 1.0
        total_notional=sum(t.price*abs(t.qty) for t in vr);one=max([t.price*abs(t.qty) for t in vr] or [0])/max(total_notional,1)
        return {'recent':vr,'bp':bp,'algo':algo,'impulse':imp,'breakout':br,'vwap':vw,'vgap':vg,'range5':rg,'accel':acc,'accel_ready':prev_ready,'one_tick':one}
    nxtm=_venue_micro('NXT');krxm=_venue_micro('KRX')
    nxt_recent=nxtm['recent'];nxt_bp=nxtm['bp'];nxt_algo=nxtm['algo'];nxt_imp=nxtm['impulse'];nxt_break=nxtm['breakout'];nxt_vwap=nxtm['vwap'];nxt_vgap=nxtm['vgap'];nxt_one_tick=nxtm['one_tick']
    big_buys=[t for t in nxt_recent if t.qty>0 and t.price*t.qty>=NXT_BIG_BUY_NOTIONAL];big_buy_notional=sum(t.price*t.qty for t in big_buys)
    c.metrics.update({
      'nxt_buy_pressure':round(nxt_bp,1),'nxt_algo_persistence':round(nxt_algo,1),'nxt_impulse_60s':round(nxt_imp,2),'nxt_micro_breakout':round(nxt_break,2),'nxt_micro_vwap':round(nxt_vwap,3) if nxt_vwap else None,'nxt_micro_vwap_gap':round(nxt_vgap,2),'nxt_tick_count_60s':len(nxt_recent),'nxt_range5_pct':round(nxtm['range5'],2),'nxt_volume_accel':round(nxtm['accel'],2),'nxt_volume_accel_ready':bool(nxtm['accel_ready']),'nxt_big_buy_count_60s':len(big_buys),'nxt_big_buy_notional_60s':round(big_buy_notional,0),'nxt_one_tick_ratio':round(nxt_one_tick,3),
      'krx_buy_pressure':round(krxm['bp'],1),'krx_algo_persistence':round(krxm['algo'],1),'krx_impulse_60s':round(krxm['impulse'],2),'krx_micro_breakout':round(krxm['breakout'],2),'krx_micro_vwap':round(krxm['vwap'],3) if krxm['vwap'] else None,'krx_micro_vwap_gap':round(krxm['vgap'],2),'krx_tick_count_60s':len(krxm['recent']),'krx_range5_pct':round(krxm['range5'],2),'krx_volume_accel':round(krxm['accel'],2),'krx_volume_accel_ready':bool(krxm['accel_ready']),'krx_one_tick_ratio':round(krxm['one_tick'],3)
    })
    sm=c.smart or {}; inst=num(sm.get('institution_net')); trust=num(sm.get('trust_net')); pension=num(sm.get('pension_net')); foreign=num(sm.get('foreign_net')); prog=num(sm.get('program_net')); prog_delta=num(sm.get('program_delta'))
    freshness=smart_freshness(c);inst_scale=max(abs(inst)+abs(foreign),1000000);smart_score=0
    program_ratio=prog/max(abs(num(sm.get('program_buy')))+abs(num(sm.get('program_sell'))),100000)
    trust_delta=num(sm.get('trust_delta'));pension_delta=num(sm.get('pension_delta'));inst_delta=num(sm.get('institution_delta'));foreign_delta=num(sm.get('foreign_delta'))
    # Stale flow is UNKNOWN, not neutral-positive evidence. Aggressive buy-tick persistence remains a separate realtime feature.
    algo_score=clamp((algo_persistence-50)*0.18,0,8)
    if freshness.get('program_fresh'):
        algo_score+=clamp(prog_delta/max(abs(prog),100000)*5,-4,5)
        smart_score+=clamp(program_ratio*10,-9,10)*learner_weight('program')+clamp(prog_delta/max(abs(prog),100000)*4,-4,4)*learner_weight('program')
    if freshness.get('investor_fresh'):
        smart_score+=clamp(trust/inst_scale*9,-6,6)*learner_weight('trust')+clamp(trust_delta/inst_scale*6,-4,4)
        smart_score+=clamp(pension/inst_scale*10,-7,7)*learner_weight('pension')+clamp(pension_delta/inst_scale*7,-5,5)
        smart_score+=clamp(inst/inst_scale*8,-6,6)*learner_weight('institution')+clamp(inst_delta/inst_scale*5,-4,4)
        smart_score+=clamp(foreign/inst_scale*4,-3,3)*learner_weight('foreign')+clamp(foreign_delta/inst_scale*2,-2,2)
    sector_score=num(c.metrics.get('sector_score'))
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_vwap_gap':round(above,2),'session_vwap':round(session_vwap,3) if session_vwap else None,'session_vwap_gap':round(session_above,2),'micro_breakout':round(breakout,2),'compression':round(compression,3),'range5_pct':round(range5,2),'dual_venue':dual,'algo_persistence':round(algo_persistence,1),'volume_accel_ready':volume_accel_ready,'volume_baseline_ticks':len(prev),'nxt_krx_basis_pct':round(nxt_krx_basis,2) if nxt_krx_basis is not None else None})
    update_nxt_second_wave_features(c,now)
    orderbook_bonus=num(c.metrics.get('orderbook_presignal')) if c.orderbook_samples>=2 and now-c.orderbook_at<=ORDERBOOK_FRESH_SECONDS else 0.0
    event_bonus,event_row=market_event_signal(c,now);c.metrics['event_signal']=event_bonus;c.metrics['event_source']=event_row.get('source') if event_row else None;c.metrics['event_title']=event_row.get('title') if event_row else None;c.metrics['event_polarity']=event_row.get('polarity') if event_row else 'NONE';c.metrics['event_polarity_reasons']=event_row.get('polarity_reasons') if event_row else []
    score=rest*learner_weight('rest')+(clamp((accel-1)*12,0,20)*learner_weight('volume_accel') if volume_accel_ready else 0)+clamp((buy_ratio-50)*0.38,0,16)*learner_weight('buy_pressure')+clamp(impulse*3.2,0,15)*learner_weight('impulse')+(clamp(above*3.2,0,5)+clamp(session_above*2.2,0,4))*learner_weight('vwap_gap')+clamp(breakout*6,0,9)*learner_weight('micro_breakout')+(5*learner_weight('dual_venue') if dual else 0)+smart_score+sector_score*learner_weight('sector')+orderbook_bonus+event_bonus
    sw_state=str(c.metrics.get('nxt_second_wave_state') or '');sw_bonus=5.0 if sw_state=='SECOND_WAVE_BUY' else 3.0 if sw_state=='SECOND_WAVE_READY' else 1.5 if sw_state=='SECOND_WAVE_BASE' else 0.0;score+=sw_bonus
    pre_dna_score=score
    dna=rally_live_match(c)
    score+=num(dna.get('bonus'))
    if c.rate>14:score-=12;reasons.append('과열 추격위험')
    if impulse>4.5:score-=7
    if one_tick>0.5:score-=8;reasons.append('단일체결 편중')
    if volume_accel_ready and accel>=1.7:reasons.append(f'1분 체결가속 {accel:.1f}x')
    elif not volume_accel_ready:reasons.append('거래량 기준선 축적 중')
    if orderbook_bonus>=2:reasons.append(f'호가 프리시그널 +{orderbook_bonus:.1f}')
    if int(c.metrics.get('nxt_big_buy_count_60s') or 0)>=2:reasons.append(f"NXT 1억+ 공격체결 {int(c.metrics.get('nxt_big_buy_count_60s') or 0)}회")
    if event_bonus>=1:reasons.append(f"{(event_row or {}).get('source','이벤트')} 선행재료 +{event_bonus:.1f}")
    elif event_bonus<=-2:reasons.append(f"{(event_row or {}).get('source','이벤트')} 악재 {event_bonus:.1f}")
    if buy_ratio>=60:reasons.append(f'공격매수 우위 {buy_ratio:.0f}%')
    if impulse>=0.7:reasons.append(f'가격 선행 +{impulse:.1f}%')
    if above>=0.2:reasons.append(f'Micro VWAP +{above:.2f}%')
    if session_above>=0.15:reasons.append(f'Session VWAP +{session_above:.2f}%')
    if breakout>=0.3:reasons.append(f'5분 미세돌파 +{breakout:.2f}%')
    if dual:reasons.append('KRX·NXT 동시확인')
    if algo_score>=4:reasons.append(f'공격매수 틱 지속 {algo_persistence:.0f}%')
    if sector_score>=3:reasons.append(f"섹터동조 {c.sector} +{sector_score:.1f}")
    if c.metrics.get('sector_follower') and sector_score>0:reasons.append('대표주→후발 확산')
    if c.metrics.get('sector_overheat'):reasons.append('섹터 과열 감점')
    if dna.get('active') and num(dna.get('match'))>=68:reasons.append(f"RALLY DNA {dna.get('type')} {num(dna.get('match')):.0f}%")
    if num(dna.get('bonus'))<0:reasons.append(f"TRAP DNA 감점 {num(dna.get('bonus')):.1f}")
    if freshness.get('program_fresh') and prog>0:reasons.append(f'프로그램 순매수 {prog:,.0f}')
    if freshness.get('investor_fresh') and trust>0:reasons.append(f'투신 순매수 {trust:,.0f}')
    if freshness.get('investor_fresh') and pension>0:reasons.append(f'연기금 순매수 {pension:,.0f}')
    if freshness.get('investor_fresh') and inst>0 and (trust>0 or pension>0):reasons.append('기관 수급 동조')
    score=clamp(score); conf=clamp(20+min(35,len(recent)*1.2)+min(25,len(c.source_hits)*6)+(10 if dual else 0))
    stage='IGNITION' if score>=78 else 'PRESSURE' if score>=64 else 'WATCH' if score>=48 else 'SEED'
    # Never call stale/closed data PRESSURE/IGNITION.
    if not sess['active']:stage='SEED';score=min(score,47)
    elif age_ms>FRESH_MS and STAGE_RANK[stage]>STAGE_RANK['WATCH']:stage='WATCH';score=min(score,63);reasons.insert(0,'실체결 freshness 부족')
    prev_stage=c.stage
    c.score=round(score,1); c.confidence=round(conf,0); c.stage=stage; c.reasons=reasons[:5]
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_vwap_gap':round(above,2),'session_vwap':round(session_vwap,3) if session_vwap else None,'session_vwap_gap':round(session_above,2),'micro_breakout':round(breakout,2),'dual_venue':dual,'tick_count_60s':len(recent),'fresh':age_ms<=FRESH_MS,'one_tick_ratio':round(one_tick,3),'smart_money_score':round(smart_score,2),'program_fresh':bool(freshness.get('program_fresh')),'investor_fresh':bool(freshness.get('investor_fresh')),'algo_score':round(algo_score,2),'algo_persistence':round(algo_persistence,1),'program_net':prog,'program_delta':prog_delta,'trust_net':trust,'trust_delta':trust_delta,'pension_net':pension,'pension_delta':pension_delta,'institution_net':inst,'institution_delta':inst_delta,'foreign_net':foreign,'foreign_delta':foreign_delta,'smart_age_ms':round((now-c.smart_updated_at)*1000) if c.smart_updated_at else None,'program_age_sec':round(smart_freshness(c)['program_age'],1) if smart_freshness(c)['program_age']<10**8 else None,'program_rt_age_sec':round(smart_freshness(c)['program_rt_age'],1) if smart_freshness(c)['program_rt_age']<10**8 else None,'investor_age_sec':round(smart_freshness(c)['investor_age'],1) if smart_freshness(c)['investor_age']<10**8 else None,'aggressive_buy_tick_persistence':round(algo_persistence,1),'learn_active':bool(STATE.learn.get('active')),'sector':c.sector,'sector_score':round(sector_score,1),'sector_breadth':c.metrics.get('sector_breadth'),'sector_members':c.metrics.get('sector_members'),'sector_leader':c.metrics.get('sector_leader'),'sector_avg_rate':c.metrics.get('sector_avg_rate'),'sector_diffusion':c.metrics.get('sector_diffusion'),'sector_follower':bool(c.metrics.get('sector_follower')),'sector_overheat':bool(c.metrics.get('sector_overheat')),'compression':round(compression,3),'range5_pct':round(range5,2),'session_vwap':round(session_vwap,3) if session_vwap else None,'session_vwap_gap':round(session_above,2),'pre_dna_score':round(pre_dna_score,1),'rally_dna_active':bool(dna.get('active')),'rally_dna_match':dna.get('match'),'rally_dna_raw_match':dna.get('raw_match'),'rally_dna_calibrated':bool(dna.get('calibrated')),'rally_dna_trap':dna.get('trap'),'rally_dna_bonus':dna.get('bonus'),'rally_dna_type':dna.get('type'),'rally_dna_samples':dna.get('samples'),'rally_dna_effective_from':dna.get('effective_from_day'),'volume_accel_ready':volume_accel_ready,'volume_baseline_ticks':len(prev),'orderbook_presignal':round(orderbook_bonus,2),'orderbook_age_sec':round(now-c.orderbook_at,2) if c.orderbook_at else None,'orderbook_samples':c.orderbook_samples,'nxt_krx_basis_pct':round(nxt_krx_basis,2) if nxt_krx_basis is not None else None,'event_signal':event_bonus,'event_source':(event_row or {}).get('source'),'event_title':(event_row or {}).get('title')})
    c.previous_stage=prev_stage
    maybe_capture(c,stage)
    advance_entry_machine(c,sess,age_ms)
    advance_nxt_second_wave(c,sess,age_ms)
    advance_nxt_recovery(c,sess,age_ms)
    evaluate_ws_emergency_ignition(c)
    update_buy_signal_performance(c)
    update_exit_positions_for_candidate(c)
    update_manual_positions_for_candidate(c)
    c.previous_stage=stage

def _record_score_runtime(ms:float, full:bool, count:int):
    STATE.score_durations.append(float(ms));vals=sorted(STATE.score_durations);p95=vals[min(len(vals)-1,max(0,int(len(vals)*0.95)-1))] if vals else 0.0
    st=STATE.score_stats;st['runs']=int(st.get('runs') or 0)+1;st['full_runs']=int(st.get('full_runs') or 0)+(1 if full else 0);st['dirty_runs']=int(st.get('dirty_runs') or 0)+(0 if full else 1);st['last_ms']=round(ms,2);st['p95_ms']=round(p95,2);st['last_count']=count;st['dirty_queue']=len(STATE.score_dirty_codes);st['last_at']=time.time()

def replay_journal_file(day:str|None=None):
    return DATA_DIR/f"replay_journal_{day or today_kst()}.jsonl"

def queue_replay_snapshot(c:Candidate):
    """Never writes disk on the scoring/WS path. Important symbols only, throttled to 1-5 seconds."""
    now=time.time();m=c.metrics or {};important=bool(c.code in STATE.core_codes or c.code in STATE.burst_highres_codes or c.code in STATE.nxt_memory_codes or c.signal_count_today>0 or c.entry_state not in ('DISCOVERY','COOLDOWN') or m.get('nxt_recovery_state') or m.get('nxt_second_wave_state') or c.nxt_fast_jump_alert_stage)
    if not important:return False
    venue='NXT' if num(c.last_tick_at_by_venue.get('NXT')) and (c.code in STATE.nxt_memory_codes or m.get('nxt_recovery_state') or m.get('nxt_second_wave_state') or c.nxt_fast_jump_alert_stage or str(c.venue)=='NXT') else (c.venue if c.venue in ('KRX','NXT') else '')
    if not venue:return False
    ts=num(c.last_tick_at_by_venue.get(venue));price=num(c.last_price_by_venue.get(venue));rate=num(c.last_rate_by_venue.get(venue))
    if not ts or now-ts>max(5.0,FRESH_MS/1000) or price<=0:return False
    key=f'{today_kst()}:{c.code}:{venue}';last=num(STATE.replay_last.get(key))
    if now-last<REPLAY_INTERVAL_SECONDS:return False
    STATE.replay_last[key]=now;flow=venue_flow_snapshot(c,venue);before=len(STATE.replay_queue)
    rec={'version':APP_VERSION,'day':today_kst(),'ts':round(now,3),'code':c.code,'name':c.name,'venue':venue,'price':round(price,4),'rate':round(rate,4),'score':round(num(c.score),2),'stage':c.stage,'entry_state':c.entry_state,'route':c.last_buy_route,'buy_pressure':round(num(flow.get('buy_pressure'),50),2),'algo':round(num(flow.get('algo'),50),2),'volume_accel':round(num(flow.get('volume_accel'),1),3),'impulse':round(num(flow.get('impulse')),3),'vwap_gap':round(num(flow.get('vwap_gap')),3),'breakout':round(num(flow.get('breakout')),3),'orderbook':round(num(flow.get('orderbook')),3),'wall_v2':round(num(m.get('nxt_orderbook_wall_v2_score') if venue=='NXT' else m.get('krx_orderbook_wall_v2_score')),3),'wall_cancel_risk':round(num(m.get('nxt_orderbook_wall_cancel_risk') if venue=='NXT' else m.get('krx_orderbook_wall_cancel_risk')),3),'program_delta':round(num(flow.get('program_delta')),2),'institution_delta':round(num(flow.get('institution_delta')),2),'event_signal':round(num(m.get('event_signal')),2),'event_polarity':m.get('event_polarity'),'recovery':m.get('nxt_recovery_state') if venue=='NXT' else None,'second_wave':m.get('nxt_second_wave_state') if venue=='NXT' else None,'fast_jump':c.nxt_fast_jump_alert_stage if venue=='NXT' else None,'catch_score':round(num(m.get('nxt_catch_score')),2),'catch_percentile':round(num(m.get('nxt_catch_percentile')),3),'top1_target':bool(m.get('nxt_top1_target'))}
    if before>=REPLAY_QUEUE_MAX:STATE.replay_status['dropped']=int(STATE.replay_status.get('dropped') or 0)+1
    STATE.replay_queue.append(rec);STATE.replay_status['queued']=len(STATE.replay_queue);return True

async def replay_flush_loop():
    while True:
        await asyncio.sleep(2)
        if not STATE.replay_queue:continue
        batch=[]
        while STATE.replay_queue and len(batch)<1000:batch.append(STATE.replay_queue.popleft())
        STATE.replay_status['queued']=len(STATE.replay_queue)
        def _write(rows):
            by={}
            for x in rows:by.setdefault(str(x.get('day') or today_kst()),[]).append(x)
            for day,grp in by.items():
                with replay_journal_file(day).open('a',encoding='utf-8') as f:
                    for x in grp:f.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n')
        try:
            await asyncio.to_thread(_write,batch);STATE.replay_status['written']=int(STATE.replay_status.get('written') or 0)+len(batch);STATE.replay_status['last_flush_at']=time.time()
        except Exception as e:STATE.replay_status['last_error']=str(e)[:160]

async def evidence_loop():
    await asyncio.sleep(3)
    while True:
        try:
            report=await asyncio.to_thread(write_evidence_report,DATA_DIR,EVIDENCE_REPORT_FILE);STATE.evidence_status.update({'last_at':time.time(),'last_error':'','week_samples':((report.get('periods') or {}).get('week') or {}).get('all',{}).get('samples',0),'month_samples':((report.get('periods') or {}).get('month') or {}).get('all',{}).get('samples',0)})
        except Exception as e:STATE.evidence_status['last_error']=str(e)[:180]
        await asyncio.sleep(EVIDENCE_REFRESH_SECONDS)

async def archive_loop():
    await asyncio.sleep(8)
    while True:
        try:
            today=today_kst();days=await asyncio.to_thread(discover_archive_days,DATA_DIR);targets=[d for d in days if d<today]
            if kst_seconds()>=ARCHIVE_CLOSE_SECONDS and today in days:targets.append(today)
            targets=sorted(set(targets))[-60:];last=''
            for day in targets:
                await asyncio.to_thread(archive_data_day,DATA_DIR,day);last=day
            STATE.archive_status.update({'last_at':time.time(),'last_day':last,'last_error':'','archived_days':len(list((DATA_DIR/'archive').glob('20??????'))) if (DATA_DIR/'archive').exists() else 0})
        except Exception as e:STATE.archive_status['last_error']=str(e)[:180]
        await asyncio.sleep(ARCHIVE_REFRESH_SECONDS)

def mark_score_dirty(code:str):
    if code and code in STATE.candidates:
        STATE.score_dirty_codes.add(code);STATE.score_stats['dirty_queue']=len(STATE.score_dirty_codes);STATE.score_dirty_event.set()

def mark_scores_dirty(codes):
    for code in codes:
        if code and code in STATE.candidates:STATE.score_dirty_codes.add(code)
    STATE.score_stats['dirty_queue']=len(STATE.score_dirty_codes)
    if STATE.score_dirty_codes:STATE.score_dirty_event.set()

def score_codes(codes, *, refresh_sector=False, full=False):
    started=time.perf_counter();todo={str(x) for x in codes if str(x) in STATE.candidates}
    now=time.time()
    if refresh_sector or now-STATE.last_sector_context>=SECTOR_CONTEXT_INTERVAL:
        todo.update(update_sector_context() or set());STATE.last_sector_context=now
    for code in todo:
        c=STATE.candidates.get(code)
        if c is not None:
            calc(c);queue_replay_snapshot(c)
    ms=(time.perf_counter()-started)*1000;_record_score_runtime(ms,full,len(todo));STATE.generated_at=time.time()
    return len(todo)

def score_all():
    # Full-universe scoring is reserved for low-frequency discovery/state rebuilds, never every WS frame.
    STATE.score_dirty_codes.clear();STATE.score_stats['dirty_queue']=0
    return score_codes(list(STATE.candidates),refresh_sector=True,full=True)

async def scoring_loop():
    while True:
        try:
            if not realtime_runtime_awake():
                STATE.performance_guard['overnight_frozen']=True
                await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
            STATE.performance_guard['overnight_frozen']=False
            try:await asyncio.wait_for(STATE.score_dirty_event.wait(),timeout=max(0.25,SECTOR_CONTEXT_INTERVAL))
            except asyncio.TimeoutError:pass
            STATE.score_dirty_event.clear()
            if STATE.score_dirty_codes:await asyncio.sleep(SCORING_COALESCE_MS/1000.0)
            codes=set(STATE.score_dirty_codes);STATE.score_dirty_codes.difference_update(codes)
            now=time.time()
            if now-STATE.last_sector_context>=SECTOR_CONTEXT_INTERVAL:
                codes.update(update_sector_context() or set());STATE.last_sector_context=now
            if codes:
                score_codes(codes,refresh_sector=False,full=False)
                if nxt_radar_session_active():
                    evaluate_nxt_radar_alerts([STATE.candidates[x] for x in codes if x in STATE.candidates])
            STATE.score_stats['dirty_queue']=len(STATE.score_dirty_codes)
            if STATE.score_dirty_codes:STATE.score_dirty_event.set()
        except Exception as e:
            STATE.score_stats['last_error']=str(e)[:160];await asyncio.sleep(0.1)

def ranked():
    protected={str(x.get('code')) for x in STATE.exit_positions.values() if x.get('status') in ('OPEN','EXIT_SIGNALED')}|{str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN'}
    rows=[x for x in STATE.candidates.values() if x.code in protected or not is_fund_like_name(x.name)]
    rows.sort(key=lambda x:(x.score,x.confidence,x.last_tick_at),reverse=True);return rows

def venue_from_fid9081(value:Any)->str:
    v=str(value or '').strip().upper()
    return v if v in ('KRX','NXT') else 'UNKNOWN'

def _tick_signature(venue:str, trade_time:str, price:float, qty:float, cumvol:float, turnover:float):
    return (venue,str(trade_time or ''),round(price,4),round(qty,4),round(cumvol,2),round(turnover,2))

def tick_integrity_check(c:Candidate, *, now:float, price:float, qty:float, rate:float, venue:str, cumvol:float, turnover:float, trade_time:str):
    """Fail-closed only for exact duplicates/reversed cumulative ticks; quarantine suspicious price spikes.

    Gap anomalies are observed, not discarded, because cumulative-volume jumps can represent upstream batching.
    """
    sig=_tick_signature(venue,trade_time,price,qty,cumvol,turnover)
    if sig in c.tick_signatures:
        c.duplicate_ticks+=1;STATE.ws_status['duplicate_drops']=int(STATE.ws_status.get('duplicate_drops') or 0)+1
        return False,'DUPLICATE'
    c.tick_signatures.append(sig)
    prev_cv=num(c.last_cumvol_by_venue.get(venue));prev_to=num(c.last_turnover_by_venue.get(venue));prev_tm=str(c.last_trade_time_by_venue.get(venue) or '')
    if prev_cv>0 and cumvol>0:
        delta=cumvol-prev_cv
        if delta<0 and trade_time and prev_tm and trade_time<=prev_tm:
            c.reorder_ticks+=1;STATE.ws_status['reorder_drops']=int(STATE.ws_status.get('reorder_drops') or 0)+1
            return False,'REORDER_CUMVOL'
        if delta==0 and abs(qty)>0:
            c.duplicate_ticks+=1;STATE.ws_status['duplicate_drops']=int(STATE.ws_status.get('duplicate_drops') or 0)+1
            return False,'CUMVOL_NOT_ADVANCED'
        if delta>max(abs(qty)*25,50000):
            c.gap_anomalies+=1;STATE.ws_status['gap_anomalies']=int(STATE.ws_status.get('gap_anomalies') or 0)+1
    if prev_to>0 and turnover>0 and turnover<prev_to and prev_cv>0 and cumvol>=prev_cv:
        c.reorder_ticks+=1;STATE.ws_status['reorder_drops']=int(STATE.ws_status.get('reorder_drops') or 0)+1
        return False,'TURNOVER_REVERSED'

    # A very large one-tick jump is quarantined when rate/cumulative-volume corroboration is weak.
    suspicious=False
    if c.last_price>0 and c.last_tick_at and now-c.last_tick_at<=2.5:
        jump=abs(price/c.last_price-1)*100
        rate_delta=abs(rate-c.rate)
        price_delta=abs((price/c.last_price-1)*100)
        mismatch=abs(price_delta-rate_delta)>PRICE_RATE_MISMATCH_PCT
        no_volume_progress=bool(prev_cv>0 and cumvol>0 and cumvol<=prev_cv)
        volume_progress=bool(cumvol>0 and (prev_cv<=0 or cumvol>prev_cv))
        nxt_after_confirmed=bool(venue=='NXT' and nxt_after_session_active() and volume_progress and not mismatch)
        suspicious=((jump>=PRICE_HARD_JUMP_PCT and not nxt_after_confirmed) or (jump>=PRICE_JUMP_QUARANTINE_PCT and (mismatch or no_volume_progress) and not nxt_after_confirmed))
    if c.quarantine_price and now-c.quarantine_at>PRICE_QUARANTINE_SECONDS:
        c.quarantine_price=0;c.quarantine_at=0;c.quarantine_cumvol=0
    if c.quarantine_price:
        confirm=abs(price/c.quarantine_price-1)*100<=PRICE_CONFIRM_TOLERANCE_PCT and (not cumvol or cumvol>=c.quarantine_cumvol)
        if confirm:
            c.quarantine_price=0;c.quarantine_at=0;c.quarantine_cumvol=0;STATE.ws_status['price_quarantine_confirmed']=int(STATE.ws_status.get('price_quarantine_confirmed') or 0)+1
        elif suspicious:
            c.price_anomalies+=1;c.quarantined_ticks+=1;STATE.ws_status['price_quarantines']=int(STATE.ws_status.get('price_quarantines') or 0)+1
            return False,'PRICE_QUARANTINE'
        else:
            c.quarantine_price=0;c.quarantine_at=0;c.quarantine_cumvol=0
    elif suspicious:
        c.quarantine_price=price;c.quarantine_at=now;c.quarantine_cumvol=cumvol;c.price_anomalies+=1;c.quarantined_ticks+=1;STATE.ws_status['price_quarantines']=int(STATE.ws_status.get('price_quarantines') or 0)+1
        return False,'PRICE_QUARANTINE'

    if trade_time:c.last_trade_time_by_venue[venue]=trade_time
    if cumvol>0:c.last_cumvol_by_venue[venue]=cumvol
    if turnover>0:c.last_turnover_by_venue[venue]=turnover
    return True,'OK'

def parse_orderbook(c:Candidate, values:dict, now:float, venue:str="UNKNOWN"):
    ask_prices=[abs(num(values.get(str(k)))) for k in range(41,51)]
    bid_prices=[abs(num(values.get(str(k)))) for k in range(51,61)]
    asks=[abs(num(values.get(str(k)))) for k in range(61,71)]
    bids=[abs(num(values.get(str(k)))) for k in range(71,81)]
    if not any(asks) and not any(bids):return False
    vkey=venue if venue in ('KRX','NXT') else 'UNKNOWN'
    ask_total=sum(asks);bid_total=sum(bids);total=max(ask_total+bid_total,1.0)
    imbalance=(bid_total-ask_total)/total
    prev=(c.orderbook_prev_by_venue.get(vkey) or {});prev_ask=num(prev.get('ask_total'));prev_bid=num(prev.get('bid_total'))
    venue_samples=int(c.orderbook_samples_by_venue.get(vkey) or 0)
    ask_depletion=clamp((prev_ask-ask_total)/max(prev_ask,1),-1,1) if prev_ask>0 else 0.0
    bid_build=clamp((bid_total-prev_bid)/max(prev_bid,1),-1,1) if prev_bid>0 else 0.0
    bid_avg=sum(bids)/max(sum(1 for x in bids if x>0),1) if any(bids) else 0.0;ask_avg=sum(asks)/max(sum(1 for x in asks if x>0),1) if any(asks) else 0.0
    bid_i=max(range(len(bids)),key=lambda i:bids[i]) if any(bids) else 0;ask_i=max(range(len(asks)),key=lambda i:asks[i]) if any(asks) else 0
    bid_wall=(bids[bid_i]/max(bid_avg,1)) if any(bids) else 0.0;ask_wall=(asks[ask_i]/max(ask_avg,1)) if any(asks) else 0.0
    bid_wall_price=bid_prices[bid_i] if bid_i<len(bid_prices) else 0.0;ask_wall_price=ask_prices[ask_i] if ask_i<len(ask_prices) else 0.0
    bid_wall_qty=bids[bid_i] if any(bids) else 0.0;ask_wall_qty=asks[ask_i] if any(asks) else 0.0
    score=0.0
    if venue_samples>=1:
        score+=clamp(imbalance*4.0,-2.5,2.5)+clamp(ask_depletion*4.0,-2.0,2.0)+clamp(bid_build*3.0,-1.5,1.5)+clamp((bid_wall-ask_wall)*0.35,-1.0,1.0)
    score=clamp(score,-ORDERBOOK_MAX_BONUS,ORDERBOOK_MAX_BONUS)
    hist=c.orderbook_history_by_venue.get(vkey)
    if not isinstance(hist,deque):hist=deque(maxlen=30);c.orderbook_history_by_venue[vkey]=hist
    recent=[x for x in hist if now-num(x.get('ts'))<=10]
    same=[x for x in recent if bid_wall_price>0 and abs(num(x.get('bid_wall_price'))-bid_wall_price)<=max(1,bid_wall_price*0.0005) and num(x.get('bid_wall'))>=ORDERBOOK_WALL_RATIO]
    wall_persist_sec=(now-min([num(x.get('ts')) for x in same]+[now])) if bid_wall>=ORDERBOOK_WALL_RATIO else 0.0
    bid_wall_persistent=bool(bid_wall>=ORDERBOOK_WALL_RATIO and wall_persist_sec>=ORDERBOOK_WALL_PERSIST_SECONDS)
    prev_wall_price=num(prev.get('bid_wall_price'));prev_wall_qty=num(prev.get('bid_wall_qty'));prev_wall_ratio=num(prev.get('bid_wall'))
    current_at_prev=0.0
    if prev_wall_price>0:
        for px,qty in zip(bid_prices,bids):
            if px>0 and abs(px-prev_wall_price)<=max(1,prev_wall_price*0.0005):current_at_prev=max(current_at_prev,qty)
    cancel_drop=(1-current_at_prev/max(prev_wall_qty,1)) if prev_wall_qty>0 else 0.0
    best_bid=max([x for x in bid_prices if x>0] or [0.0]);price_advanced=bool(prev_wall_price>0 and best_bid>prev_wall_price);wall_cancel_risk=clamp(cancel_drop,0,1) if prev_wall_ratio>=ORDERBOOK_WALL_RATIO and cancel_drop>=ORDERBOOK_WALL_CANCEL_DROP and not price_advanced else 0.0
    bp=num(c.metrics.get('nxt_buy_pressure') if vkey=='NXT' else c.metrics.get('krx_buy_pressure'),50)
    absorption=clamp(max(0,ask_depletion)*2.5+max(0,(bp-55))/25,0,1) if venue_samples>=1 else 0.0
    wall_v2=0.0
    if bid_wall_persistent:wall_v2+=1.15
    wall_v2+=absorption*1.15
    if bid_wall>ask_wall+0.8:wall_v2+=0.45
    wall_v2-=wall_cancel_risk*1.8
    if ask_wall>bid_wall+1.2:wall_v2-=0.5
    wall_v2=clamp(wall_v2,-ORDERBOOK_WALL_V2_MAX_BONUS,ORDERBOOK_WALL_V2_MAX_BONUS)
    snap={'ts':now,'venue':vkey,'ask_total':ask_total,'bid_total':bid_total,'imbalance':imbalance,'ask_depletion':ask_depletion,'bid_build':bid_build,'bid_wall':bid_wall,'ask_wall':ask_wall,'bid_wall_price':bid_wall_price,'ask_wall_price':ask_wall_price,'bid_wall_qty':bid_wall_qty,'ask_wall_qty':ask_wall_qty,'wall_persist_sec':wall_persist_sec,'wall_cancel_risk':wall_cancel_risk,'wall_absorption':absorption,'wall_v2':wall_v2,'score':score}
    c.orderbook_prev_by_venue[vkey]={'ask_total':ask_total,'bid_total':bid_total,'bid_wall':bid_wall,'ask_wall':ask_wall,'bid_wall_price':bid_wall_price,'ask_wall_price':ask_wall_price,'bid_wall_qty':bid_wall_qty,'ask_wall_qty':ask_wall_qty}
    hist.append(snap);c.orderbook_samples_by_venue[vkey]=venue_samples+1
    c.orderbook_prev={'ask_total':ask_total,'bid_total':bid_total};c.orderbook_history.append(snap);c.orderbook_at=now;c.orderbook_samples=sum(c.orderbook_samples_by_venue.values())
    common={'orderbook_presignal':round(score,2),'orderbook_venue':vkey,'orderbook_imbalance':round(imbalance,4),'ask_depletion':round(ask_depletion,4),'bid_build':round(bid_build,4),'bid_wall_ratio':round(bid_wall,2),'ask_wall_ratio':round(ask_wall,2),'orderbook_wall_v2_score':round(wall_v2,2),'orderbook_wall_persist_sec':round(wall_persist_sec,2),'orderbook_wall_cancel_risk':round(wall_cancel_risk,3),'orderbook_wall_absorption':round(absorption,3),'orderbook_samples':c.orderbook_samples}
    c.metrics.update(common)
    if vkey=='NXT':c.metrics.update({'nxt_orderbook_presignal':round(score,2),'nxt_orderbook_at':now,'nxt_orderbook_samples':venue_samples+1,'nxt_orderbook_verified':True,'nxt_orderbook_wall_v2_score':round(wall_v2,2),'nxt_orderbook_wall_persist_sec':round(wall_persist_sec,2),'nxt_orderbook_wall_cancel_risk':round(wall_cancel_risk,3),'nxt_orderbook_wall_absorption':round(absorption,3),'nxt_bid_wall_price':bid_wall_price})
    elif vkey=='KRX':c.metrics.update({'krx_orderbook_presignal':round(score,2),'krx_orderbook_at':now,'krx_orderbook_samples':venue_samples+1,'krx_orderbook_wall_v2_score':round(wall_v2,2),'krx_orderbook_wall_persist_sec':round(wall_persist_sec,2),'krx_orderbook_wall_cancel_risk':round(wall_cancel_risk,3),'krx_orderbook_wall_absorption':round(absorption,3),'krx_bid_wall_price':bid_wall_price})
    STATE.ws_status.update({'orderbook_at':now,'orderbook_code':c.code,'orderbook_venue':vkey,'orderbook_samples':int(STATE.ws_status.get('orderbook_samples') or 0)+1})
    return True

def _probe_shape_score(kind:str, rows:list[dict]):
    keys=set();count=0
    for d in rows:
        count+=1;keys.update(str(k) for k in (d.get('values') or {}).keys())
    if kind=='trade':shape=sum(k in keys for k in ('10','12','13','15','20'));return count*2+shape*4,sorted(keys)[:80]
    if kind=='orderbook':shape=sum(k in keys for k in ('41','51','61','71'));return count*2+shape*5,sorted(keys)[:80]
    shape=sum(k in keys for k in ('212','213'));return count*2+shape*6,sorted(keys)[:80]

async def _probe_ws_pair(code:str, kind:str, types:tuple[str,...]):
    out={}
    token=await TOK.get()
    async with websockets.connect(WS,ping_interval=None,close_timeout=3,max_size=3_000_000) as ws:
        await ws.send(json.dumps({'trnm':'LOGIN','token':token}))
        while True:
            raw=await asyncio.wait_for(ws.recv(),timeout=5);m=json.loads(raw)
            if m.get('trnm')=='PING':await ws.send(raw);continue
            if m.get('trnm')=='LOGIN':
                if int(m.get('return_code',-1))!=0:raise RuntimeError(m.get('return_msg','probe login failed'))
                break
        for idx,typ in enumerate(types):
            grp=f'49{idx}'
            item=code
            packet={'trnm':'REG','grp_no':grp,'refresh':'0','data':[{'item':[item],'type':[typ]}]}
            await ws.send(json.dumps(packet));acked=False;rows=[];deadline=time.time()+WS_CONTRACT_PROBE_SECONDS+4
            collect_until=None
            while time.time()<deadline:
                try:raw=await asyncio.wait_for(ws.recv(),timeout=0.6)
                except asyncio.TimeoutError:
                    if acked and collect_until and time.time()>=collect_until:break
                    continue
                m=json.loads(raw)
                if m.get('trnm')=='PING':await ws.send(raw);continue
                if m.get('trnm')=='REG' and not acked:
                    if int(m.get('return_code',-1))!=0:break
                    acked=True;collect_until=time.time()+WS_CONTRACT_PROBE_SECONDS;continue
                if acked and m.get('trnm')=='REAL':
                    for d in m.get('data') or []:
                        if str(d.get('type'))==typ:rows.append(d)
                if acked and collect_until and time.time()>=collect_until:break
            score,keys=_probe_shape_score(kind,rows);out[typ]={'score':score,'messages':len(rows),'keys':keys,'ack':acked}
    return out

def _choose_probe_type(kind:str, probe:dict, current:str, official:str):
    choices=sorted(probe.items(),key=lambda kv:num((kv[1] or {}).get('score')),reverse=True)
    if not choices:return current,False
    top_t,top=choices[0];top_score=num(top.get('score'));second=num(choices[1][1].get('score')) if len(choices)>1 else 0
    if top_score<8:return current,False
    # Strong evidence: structural fields or materially more actual messages. Ties prefer current/official.
    if top_score>=max(8,second*1.20):return top_t,True
    if current in probe and num(probe[current].get('score'))>0:return current,False
    if official in probe and num(probe[official].get('score'))>0:return official,False
    return top_t,False

async def ws_contract_probe_loop():
    """Health-check only. Official realtime semantics are fixed and probe results can never remap scoring types."""
    official={'trade':'0B','program':'0w','orderbook':'0D'}
    while True:
        try:
            if APP_KEY and SECRET and market_session().get('active') and STATE.core_codes:
                day=today_kst();c=STATE.ws_contract or load_ws_contract()
                if c.get('probe_day')!=day or time.time()-num(c.get('probe_at'))>=WS_CONTRACT_REPROBE_SECONDS:
                    code=STATE.core_codes[0];probe={};health=[]
                    for kind,typ in official.items():
                        try:
                            result=await _probe_ws_pair(code,kind,(typ,));probe[kind]=result;row=result.get(typ) or {};health.append(bool(row.get('ack')) and num(row.get('score'))>0)
                        except Exception as e:probe[kind]={'error':str(e)[:160]};health.append(False)
                    ok=all(health)
                    c={**DEFAULT_WS_CONTRACT,'probe_day':day,'probe_at':time.time(),'updated_at':now_kst(),'confirmed':ok,'health_ok':ok,'probe':probe}
                    STATE.ws_contract=c;persist_ws_contract(c)
                    STATE.ws_status['contract_probe_at']=time.time();STATE.ws_status['contract_probe_code']=code;STATE.ws_status['contract_health_ok']=ok
        except Exception as e:STATE.ws_status['contract_probe_error']=str(e)[:180]
        await asyncio.sleep(15 if not STATE.core_codes else 60)

def _registry_packet(trnm:str, grp_no:str, items:list[str], typ:str):
    packet={'trnm':trnm,'grp_no':grp_no,'data':[{'item':items,'type':[typ]}]}
    if trnm=='REG':packet['refresh']='1'
    return packet

def registry_diff(trade_target, program_target, orderbook_target, krx_registered, nxt_registered, program_registered, orderbook_registered):
    """Order-insensitive differential planner. Group operations are ACK-serialized because REG/REMOVE ACKs may omit grp_no."""
    tt=frozenset(trade_target);pt=frozenset(program_target);ot=frozenset(orderbook_target);kr=frozenset(krx_registered);nx=frozenset(nxt_registered);pr=frozenset(program_registered);ob=frozenset(orderbook_registered)
    plan=[]
    for action,kind,codes in (
        ('REMOVE','ORDERBOOK',ob-ot),('REMOVE','PROGRAM',pr-pt),('REMOVE','TRADE_KRX',kr-tt),('REMOVE','TRADE_NXT',nx-tt),
        ('REG','TRADE_KRX',tt-kr),('REG','TRADE_NXT',tt-nx),('REG','PROGRAM',pt-pr),('REG','ORDERBOOK',ot-ob)):
        if codes:plan.append((action,kind,frozenset(codes)))
    return plan

def build_realtime_targets():
    """Bounded realtime target sets with BURST-HR priority."""
    trade_target=frozenset(STATE.ws_codes[:WS_LIMIT])
    manual=[str(x.get('code')) for x in STATE.manual_positions.values() if x.get('status')=='OPEN' and str(x.get('code')) in trade_target]
    hi=_unique_codes(manual+[x for x in STATE.burst_highres_codes if x in trade_target])
    program_codes=_unique_codes(hi+[x for x in STATE.core_codes if x in trade_target])[:40]
    orderbook_codes=_unique_codes(hi+STATE.core_codes[:ORDERBOOK_CORE_LIMIT]+STATE.challenger_codes[:ORDERBOOK_CHALLENGER_LIMIT])[:40]
    return trade_target,frozenset(program_codes),frozenset(x for x in orderbook_codes if x in trade_target)

async def ws_loop():
    """Realtime truth path: official fixed 0B/0w/0D, ACK-safe diff registry, overnight freeze and 07:55 preopen reconnect."""
    TRADE_KRX_GRP='410';TRADE_NXT_GRP='411';PROGRAM_GRP='420';ORDERBOOK_GRP='430';backoff=WS_RECONNECT_BASE
    while True:
        if not APP_KEY or not SECRET:
            await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
        if not realtime_runtime_awake():
            STATE.ws_status.update({'connected':False,'overnight_frozen':True,'wake_guard_sec':WS_WAKE_GUARD_SECONDS,'runtime_window':'07:30-20:05 KST','reconnect_backoff_sec':0})
            backoff=WS_RECONNECT_BASE;await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
        connected_at=0.0;force_preopen_reconnect=False
        try:
            token=await TOK.get();connected_at=time.time();contract=dict(STATE.ws_contract or load_ws_contract());contract_gen=STATE.ws_contract_generation
            async with websockets.connect(WS,ping_interval=None,close_timeout=3,max_size=6_000_000) as ws:
                STATE.ws_status.update({'connected':True,'overnight_frozen':False,'wake_guard_sec':WS_WAKE_GUARD_SECONDS,'last_error':'','reconnects':int(STATE.ws_status.get('reconnects') or 0)+1,'registered_groups':0,'registered_codes':0,'trade_registered':0,'program_registered':0,'orderbook_registered':0,'reg_pending_groups':0,'reconnect_backoff_sec':0,'registry_mode':'SERIAL_GROUP_BATCH_ACK_NO_GRP_DEPENDENCY','trade_type':contract['trade_type'],'program_type':contract['program_type'],'orderbook_type':contract['orderbook_type'],'contract_source':contract.get('source')})
                krx_registered=frozenset();nxt_registered=frozenset();program_registered=frozenset();orderbook_registered=frozenset();pending={};logged=False;generation=0;blocked_until={}
                await ws.send(json.dumps({'trnm':'LOGIN','token':token}))

                async def send_op(action:str,kind:str,codes:set[str]|frozenset[str],retry:int=0):
                    nonlocal pending,generation
                    if not codes:return False
                    generation+=1;base=sorted(codes)[:40]
                    if kind=='TRADE_KRX':grp,typ,items=TRADE_KRX_GRP,contract['trade_type'],base
                    elif kind=='TRADE_NXT':grp,typ,items=TRADE_NXT_GRP,contract['trade_type'],[x+'_NX' for x in base]
                    elif kind=='PROGRAM':grp,typ=PROGRAM_GRP,contract['program_type'];items=[item for x in base for item in (x,x+'_NX')]
                    else:
                        grp,typ=ORDERBOOK_GRP,contract['orderbook_type'];base=base[:20];items=[item for x in base for item in (x,x+'_NX')]
                    packet=_registry_packet(action,grp,items,typ)
                    await ws.send(json.dumps(packet));pending[grp]={'action':action,'kind':kind,'codes':frozenset(base),'packet':packet,'requested_at':time.time(),'attempts':retry+1,'generation':generation,'grp_no':grp,'type':typ}
                    STATE.ws_status.update({'reg_generation':generation,'reg_pending_groups':1,'reg_pending_action':action,'reg_pending_kind':kind,'reg_pending_codes':len(base),'reg_requested_at':time.time()})
                    return True

                async def schedule_diff():
                    nonlocal krx_registered,nxt_registered,program_registered,orderbook_registered,pending
                    if not logged or pending:return
                    # BURST-HR is prioritized over low-priority CORE tails; each auxiliary realtime group is capped at 40.
                    trade_target,program_target,orderbook_target=build_realtime_targets()
                    plan=registry_diff(trade_target,program_target,orderbook_target,krx_registered,nxt_registered,program_registered,orderbook_registered)
                    now=time.time()
                    for action,kind,codes in plan:
                        if now<num(blocked_until.get(kind,0)):continue
                        await send_op(action,kind,codes);return
                    both=krx_registered & nxt_registered
                    STATE.ws_status.update({'registered_codes':len(both),'trade_registered':len(both),'krx_registered':len(krx_registered),'nxt_registered':len(nxt_registered),'program_registered':len(program_registered),'orderbook_registered':len(orderbook_registered),'registered_at':time.time(),'registry_target_codes':len(trade_target),'registry_target_program':len(program_target),'registry_target_orderbook':len(orderbook_target)})

                while True:
                    if not realtime_runtime_awake():break
                    # One deliberate reconnect at 07:55 re-logins and rebuilds all realtime groups before the 08:00 NXT open.
                    if logged and between(kst_seconds(),WS_PREOPEN_RECONNECT_SECONDS,WS_PREOPEN_RECONNECT_END_SECONDS) and STATE.ws_status.get('preopen_reconnect_day')!=today_kst():
                        STATE.ws_status.update({'preopen_reconnect_day':today_kst(),'preopen_reconnect_at':time.time(),'preopen_reconnect_reason':'07:55_FULL_LIVE_REINIT'});force_preopen_reconnect=True;break
                    if STATE.ws_contract_generation!=contract_gen:raise RuntimeError('WS_CONTRACT_CHANGED_RECONNECT')
                    if logged:await schedule_diff()
                    for grp,op in list(pending.items()):
                        if time.time()-op['requested_at']<=WS_REG_ACK_TIMEOUT:continue
                        if int(op.get('attempts') or 0)>=WS_REG_MAX_RETRY:
                            pending.pop(grp,None);STATE.ws_status['reg_pending_groups']=0;kind=op.get('kind')
                            if kind in ('PROGRAM','ORDERBOOK'):
                                blocked_until[kind]=time.time()+30;STATE.ws_status[f'{kind.lower()}_reg_error']=f"{op.get('type')} ACK timeout";continue
                            raise RuntimeError(f"{kind} {op.get('action')} ACK timeout")
                        STATE.ws_status['reg_retries']=int(STATE.ws_status.get('reg_retries') or 0)+1;op['attempts']+=1;op['requested_at']=time.time();await ws.send(json.dumps(op['packet']))
                    try:raw=await asyncio.wait_for(ws.recv(),timeout=0.6)
                    except asyncio.TimeoutError:continue
                    STATE.ws_status['last_message_at']=time.time();m=json.loads(raw)
                    if m.get('trnm')=='PING':await ws.send(raw);continue
                    if m.get('trnm')=='LOGIN':
                        if int(m.get('return_code',-1))!=0:raise RuntimeError(m.get('return_msg','LOGIN failed'))
                        logged=True;STATE.ws_status.update({'last_login_at':time.time(),'last_login_day':today_kst()});krx_registered=frozenset();nxt_registered=frozenset();program_registered=frozenset();orderbook_registered=frozenset();pending={};continue
                    if m.get('trnm') in ('REG','REMOVE'):
                        if not pending:
                            STATE.ws_status['unexpected_registry_ack']=int(STATE.ws_status.get('unexpected_registry_ack') or 0)+1;continue
                        # Exactly one group operation is in flight, so grp_no is not required for correlation.
                        grp,op=next(iter(pending.items()));pending.pop(grp,None);STATE.ws_status['reg_pending_groups']=0
                        ok=int(m.get('return_code',-1))==0
                        if not ok:
                            STATE.ws_status['reg_failed']=int(STATE.ws_status.get('reg_failed') or 0)+1;kind=op['kind']
                            if kind in ('PROGRAM','ORDERBOOK'):
                                blocked_until[kind]=time.time()+30;STATE.ws_status[f'{kind.lower()}_reg_error']=str(m.get('return_msg') or f'{op.get("type")} registry failed')[:180];continue
                            raise RuntimeError(str(m.get('return_msg') or f"{kind} registry failed")[:180])
                        STATE.ws_status['ack']=int(STATE.ws_status.get('ack') or 0)+1;codes=op['codes'];action=op['action'];kind=op['kind']
                        if kind=='PROGRAM':program_registered=(program_registered|codes) if action=='REG' else (program_registered-codes)
                        elif kind=='ORDERBOOK':orderbook_registered=(orderbook_registered|codes) if action=='REG' else (orderbook_registered-codes)
                        elif kind=='TRADE_KRX':krx_registered=(krx_registered|codes) if action=='REG' else (krx_registered-codes)
                        elif kind=='TRADE_NXT':nxt_registered=(nxt_registered|codes) if action=='REG' else (nxt_registered-codes)
                        both=krx_registered & nxt_registered
                        STATE.ws_status.update({'registered_groups':4,'registered_codes':len(both),'trade_registered':len(both),'krx_registered':len(krx_registered),'nxt_registered':len(nxt_registered),'program_registered':len(program_registered),'orderbook_registered':len(orderbook_registered),'registered_at':time.time()})
                        continue
                    if m.get('trnm')!='REAL':continue
                    for d in m.get('data',[]):
                        typ=str(d.get('type'));v=d.get('values') or {};raw_item=str(d.get('item') or v.get('9001') or '');code=code6(raw_item)
                        if not code:continue
                        cand=STATE.candidates.get(code);now=time.time()
                        if cand is None:
                            STATE.ws_status['orphan_ticks_dropped']=int(STATE.ws_status.get('orphan_ticks_dropped') or 0)+1
                            continue
                        if typ==contract['program_type']:
                            raw_net=str(v.get('212') or '').strip();raw_delta=str(v.get('213') or '').strip();program_venue='NXT' if raw_item.upper().endswith('_NX') or str(v.get('9081') or '').upper()=='NXT' else 'KRX'
                            if raw_net or raw_delta:
                                net=num(v.get('212'));sm=_venue_smart(cand,program_venue);prev=num(sm.get('program_net'));delta=num(v.get('213')) if raw_delta else (net-prev)
                                buy=num(v.get('208'));sell=num(v.get('204'))
                                _apply_program_values(cand,program_venue,buy,sell,net,realtime=True,raw={k:v.get(k) for k in ('212','213','208','204','20') if k in v},source='0w')
                                # 213 is server-side delta; preserve it when provided.
                                if raw_delta:_venue_smart(cand,program_venue)['program_delta']=delta
                                if program_venue=='NXT':cand.metrics['nxt_program_delta']=delta
                                elif str(cand.venue).upper()=='KRX':cand.smart['program_delta']=delta
                                STATE.ws_status.update({'program_rt_at':now,'program_rt_code':code,'program_rt_venue':program_venue,'program_rt_samples':int(STATE.ws_status.get('program_rt_samples') or 0)+1});mark_score_dirty(code)
                            continue
                        if typ==contract['orderbook_type']:
                            ob_venue='NXT' if raw_item.upper().endswith('_NX') or str(v.get('9081') or '').upper()=='NXT' else ('KRX' if code else 'UNKNOWN')
                            parse_orderbook(cand,v,now,ob_venue);mark_score_dirty(code);continue
                        if typ!=contract['trade_type']:continue
                        p=abs(num(v.get('10')));q=num(v.get('15'));rate=num(v.get('12'));fid9081=str(v.get('9081') or '').upper();trade_time=str(v.get('20') or '')
                        venue=venue_from_fid9081(fid9081)
                        if p<=0:continue
                        if venue=='UNKNOWN':
                            # Venue truth is mandatory for scoring/BUY. Audit it, but never let an
                            # unverified trade contaminate ticks, VWAP, acceleration or entry logic.
                            cand.quarantined_ticks+=1;cand.metrics.update({'integrity_last':'UNKNOWN_VENUE_FAIL_CLOSED','venue_confirmed':False});
                            STATE.ws_status['unknown_venue_drops']=int(STATE.ws_status.get('unknown_venue_drops') or 0)+1
                            continue
                        cumvol=abs(num(v.get('13')));turnover=abs(num(v.get('14')))
                        accepted,integrity_reason=tick_integrity_check(cand,now=now,price=p,qty=q,rate=rate,venue=venue,cumvol=cumvol,turnover=turnover,trade_time=trade_time)
                        cand.metrics.update({'integrity_last':integrity_reason,'duplicate_ticks':cand.duplicate_ticks,'reorder_ticks':cand.reorder_ticks,'gap_anomalies':cand.gap_anomalies,'price_anomalies':cand.price_anomalies,'quarantined_ticks':cand.quarantined_ticks,'venue_confirmed':venue!='UNKNOWN'})
                        if not accepted:continue
                        cand.last_price=p;cand.rate=rate;cand.venue=venue;cand.last_fid9081=fid9081 if venue!='UNKNOWN' else '';cand.last_tick_at=now;cand.last_price_source=f"WS_{contract['trade_type']}"
                        if venue in ('KRX','NXT'):
                            cand.last_price_by_venue[venue]=p;cand.last_rate_by_venue[venue]=rate;cand.last_tick_at_by_venue[venue]=now;cand.last_fid9081_by_venue[venue]=fid9081
                        cand.ticks.append(Tick(now,p,q,rate,venue,cumvol,turnover))
                        if venue=='NXT':cand.metrics['nxt_seen']=True;update_nxt_memory_tick(cand,now,p,rate,q,cumvol,turnover)
                        day=today_kst()
                        if cand.session_day!=day:cand.session_day=day;cand.session_pv=0;cand.session_vv=0
                        aq=abs(q)
                        if aq>0:cand.session_pv+=p*aq;cand.session_vv+=aq
                        STATE.ws_status.update({'last_trade_at':now,'last_trade_code':code,'last_trade_venue':venue,'last_fid9081':cand.last_fid9081})
                        update_capture_performance(cand);mark_score_dirty(code)
                    STATE.generated_at=time.time();persist_performance()
            STATE.ws_status.update({'connected':False,'registered_codes':0,'trade_registered':0,'krx_registered':0,'nxt_registered':0,'program_registered':0,'orderbook_registered':0,'reg_pending_groups':0})
            if force_preopen_reconnect:
                backoff=WS_RECONNECT_BASE;await asyncio.sleep(0.25);continue
            if not realtime_runtime_awake():
                STATE.ws_status.update({'overnight_frozen':True,'wake_guard_sec':WS_WAKE_GUARD_SECONDS,'reconnect_backoff_sec':0});backoff=WS_RECONNECT_BASE;await asyncio.sleep(WS_WAKE_GUARD_SECONDS);continue
        except Exception as e:
            if connected_at and time.time()-connected_at>=60:backoff=WS_RECONNECT_BASE
            delay=min(WS_RECONNECT_MAX,backoff)*(1+random.uniform(-WS_RECONNECT_JITTER,WS_RECONNECT_JITTER));delay=max(0.5,delay)
            if ws_wake_guard_active():delay=min(delay,float(WS_WAKE_GUARD_SECONDS))
            STATE.ws_status.update({'connected':False,'last_error':str(e)[:180],'registered_codes':0,'trade_registered':0,'krx_registered':0,'nxt_registered':0,'program_registered':0,'orderbook_registered':0,'reg_pending_groups':0,'reconnect_backoff_sec':round(delay,2)})
            await asyncio.sleep(delay);backoff=min(WS_RECONNECT_MAX,max(WS_RECONNECT_BASE,backoff*2))

def performance_guard_status():
    pg=dict(STATE.performance_guard);pg['scoring']=dict(STATE.score_stats);pg['rest_queue']=REST_PACER.q.qsize();pg['rest_pipeline']=REST_PACER.status();pg['persist_interval_sec']=PERSIST_INTERVAL_SECONDS;pg['last_persist_age_sec']=round(max(0,time.time()-STATE.last_persist),1) if STATE.last_persist else None;pg['memory_dirty']=bool(STATE.nxt_memory_dirty);pg['ledger_dirty']=bool(STATE.nxt_ledger_dirty);pg['op_log_max_mb']=OP_LOG_MAX_MB;pg['op_log_keep_lines']=OP_LOG_KEEP_LINES
    return pg

def feed_truth():
    now=time.time();sess=market_session();last=STATE.ws_status.get('last_trade_at') or 0;age_ms=round((now-last)*1000) if last else None
    if not APP_KEY or not SECRET:state='KEYS_MISSING'
    elif not sess['active']:state='MARKET_CLOSED'
    elif STATE.ws_status.get('connected') and age_ms is not None and age_ms<=FRESH_MS:state='LIVE'
    elif STATE.ws_status.get('connected'):state='CONNECTED_WAITING_TICK'
    else:state='DISCONNECTED'
    cal=_load_krx_calendar()
    return {'state':state,'session':sess,'calendar_stale':bool(cal.get('calendar_stale')),'calendar_years':cal.get('covered_years',[]),'last_trade_at_kst':fmt_kst(last) if last else None,'last_trade_age_ms':age_ms,'last_trade_code':STATE.ws_status.get('last_trade_code'),'last_trade_venue':STATE.ws_status.get('last_trade_venue'),'last_fid9081':STATE.ws_status.get('last_fid9081')}

def build_nxt_signal_management(day:str|None=None):
    """Build one live management row per NXT symbol from persisted stage alerts + current candidate state.

    This is a read-only management view. It does not create BUY signals or alter scoring.
    The first alert price is frozen as the performance reference so early-detection quality remains auditable.
    """
    day=day or today_kst(); now=time.time()
    events=[x for x in list(STATE.nxt_alerts) if str(x.get('day') or '')==day and x.get('code') and str(x.get('code'))!='NXT']
    by_code=defaultdict(list)
    for x in events:by_code[str(x.get('code'))].append(x)
    priority={'RECOVERY_BUY':110,'SECOND_WAVE_BUY':100,'IGNITION':90,'EMERGENCY_IGNITION':88,'PREMARKET_CONFIRM':85,'RECOVERY_READY':83,'SECOND_WAVE_READY':80,'FAST_JUMP_READY':76,'RECOVERY_EARLY':74,'FAST_JUMP_WATCH':72,'PRE_IGNITION':70,'SECOND_WAVE_BASE':60,'EARLY_WATCH':50,'LATE_RALLY':40}
    rows=[]
    for code,evs in by_code.items():
        evs.sort(key=lambda x:num(x.get('at')))
        first,latest=evs[0],evs[-1]; c=STATE.candidates.get(code)
        first_price=num(first.get('price')); first_rate=num(first.get('change_rate'))
        current_price=num(c.last_price_by_venue.get('NXT')) if c else 0;current_price=current_price or num(latest.get('price'))
        current_rate=num(c.last_rate_by_venue.get('NXT')) if c and num(c.last_price_by_venue.get('NXT'))>0 else num(latest.get('change_rate'))
        since_first=round((current_price/first_price-1)*100,2) if first_price>0 and current_price>0 else None
        mx=mn=None
        led=((STATE.nxt_daily_ledger or {}).get('rows') or {}).get(code) or {}
        if first_price>0 and num(led.get('first_alert_at')):
            if num(led.get('max_price_since_alert'))>0:mx=round((num(led.get('max_price_since_alert'))/first_price-1)*100,2)
            if num(led.get('min_price_since_alert'))>0:mn=round((num(led.get('min_price_since_alert'))/first_price-1)*100,2)
        if mx is None and since_first is not None:mx=since_first
        if mn is None and since_first is not None:mn=since_first
        m=(c.metrics if c else {}) or {};nflow=venue_flow_snapshot(c,'NXT') if c else {};nsm=(nflow.get('smart') or {}) if c else {};nfresh=(nflow.get('fresh') or {}) if c else {}
        nxt_radar=num(m.get('nxt_radar_score',latest.get('nxt_radar_score')));nxt_take=num(m.get('nxt_takeover_score',latest.get('nxt_takeover_score')));nxt_score=nxt_radar if nxt_radar else nxt_take
        sw=(latest.get('second_wave') or {}) if isinstance(latest.get('second_wave'),dict) else {}
        recovery=(latest.get('recovery') or {}) if isinstance(latest.get('recovery'),dict) else {}
        stages=[]
        for e in evs:
            st=str(e.get('stage') or '')
            if st and st not in stages:stages.append(st)
        stage=str(latest.get('stage') or (c.nxt_second_wave_alert_stage if c else '') or (c.nxt_fast_jump_alert_stage if c else '') or (c.nxt_alert_stage if c else '') or 'WATCH')
        buy_active=bool(c and c.signal_count_today>0 and c.last_signal_venue=='NXT' and c.last_signal_at>=num(first.get('at')))
        buy_price=num(c.last_signal_price) if buy_active else 0.0
        buy_ret=round((current_price/buy_price-1)*100,2) if buy_price>0 and current_price>0 else None
        nxt_tick_at=num(c.last_tick_at_by_venue.get('NXT')) if c else 0;last_tick_age=round((now-nxt_tick_at)*1000) if nxt_tick_at else None
        row={
            'code':code,'name':(c.name if c and c.name else latest.get('name') or first.get('name') or code),'sector':c.sector if c else None,
            'stage':stage,'stages':stages,'stage_priority':priority.get(stage,0),'alert_count':len(evs),
            'first_stage':first.get('stage'),'first_at_kst':first.get('at_kst'),'first_price':first_price or None,'first_rate':first_rate,
            'last_at_kst':latest.get('at_kst'),'last_event_id':latest.get('id'),'current_price':current_price or None,'current_rate':current_rate,
            'return_since_first':since_first,'max_return_since_first':mx,'min_return_since_first':mn,
            'score':round(nxt_score,1),'confidence':round(max(nxt_radar,nxt_take),1),'ws_tier':c.ws_tier if c else None,
            'venue':'NXT','fid9081':c.last_fid9081_by_venue.get('NXT') if c else None,'last_tick_age_ms':last_tick_age,
            'nxt_radar_score':round(nxt_radar,1),'nxt_takeover_score':round(nxt_take,1),'nxt_catch_score':m.get('nxt_catch_score',latest.get('nxt_catch_score')),'nxt_catch_percentile':m.get('nxt_catch_percentile',latest.get('nxt_catch_percentile')),'nxt_top1_target':bool(m.get('nxt_top1_target',latest.get('nxt_top1_target'))),'buy_prohibited':bool(latest.get('buy_prohibited')), 
            'nxt_volume_accel_30s':m.get('nxt_volume_accel_30s',sw.get('nxt_volume_accel_30s')),'nxt_volume_accel_60s':m.get('nxt_volume_accel_60s',sw.get('nxt_volume_accel_60s')),
            'nxt_dryup_ratio_10m':m.get('nxt_dryup_ratio_10m',sw.get('nxt_dryup_ratio_10m')),'nxt_second_wave_state':m.get('nxt_second_wave_state') or (stage if stage.startswith('SECOND_WAVE_') else None),
            'nxt_second_wave_pullback_pct':m.get('nxt_second_wave_pullback_pct',sw.get('nxt_second_wave_pullback_pct')),'nxt_second_wave_base_minutes':m.get('nxt_second_wave_base_minutes',sw.get('nxt_second_wave_base_minutes')),
            'nxt_recovery_state':m.get('nxt_recovery_state') or (stage if stage.startswith('RECOVERY_') else None),'nxt_recovery_drawdown_pct':m.get('nxt_recovery_drawdown_pct',recovery.get('nxt_recovery_drawdown_pct')),'nxt_recovery_ratio':m.get('nxt_recovery_ratio',recovery.get('nxt_recovery_ratio')),'nxt_recovery_peak_gap_pct':m.get('nxt_recovery_peak_gap_pct',recovery.get('nxt_recovery_peak_gap_pct')),'nxt_recovery_peak_age_min':m.get('nxt_recovery_peak_age_min',recovery.get('nxt_recovery_peak_age_min')),'nxt_recovery_trough_age_min':m.get('nxt_recovery_trough_age_min',recovery.get('nxt_recovery_trough_age_min')),
            'buy_pressure':nflow.get('buy_pressure') if c else None,'orderbook_presignal':nflow.get('orderbook') if c else None,'smart_money_score':venue_smart_flow_score(c,'NXT') if c else None,
            'program_delta':nsm.get('program_delta') if c else None,'institution_delta':nsm.get('institution_delta') if c else None,
            'investor_fresh':bool(nfresh.get('investor_fresh')) if c else False,'program_fresh':bool(nfresh.get('program_fresh')) if c else False,
            'buy_confirmed':buy_active,'buy_route':c.last_buy_route if buy_active else None,'buy_price':buy_price or None,'buy_return':buy_ret,
            'reasons':list(latest.get('reasons') or [])[:8]
        }
        rows.append(row)
    rows.sort(key=lambda r:(r['stage_priority'],num(r.get('nxt_radar_score')),num(r.get('score')),num(r.get('current_rate'))),reverse=True)
    for i,r in enumerate(rows,1):r['rank']=i
    counts=defaultdict(int)
    for r in rows:counts[r['stage']]+=1
    return {'ok':True,'version':APP_VERSION,'day':day,'active':nxt_radar_session_active(),'regular_active':nxt_regular_session_active(),'after_active':nxt_after_session_active(),'premarket_active':nxt_premarket_session_active(),'count':len(rows),'counts':dict(counts),'rows':rows[:120],'generated_at':now_kst(),'note':'NXT 단계 신호의 최초포착가를 고정하며 현재가·등락률·Radar·매수압력·호가·프로그램/기관·BUY 확인은 NXT venue 데이터만 사용합니다. 장기 눌림은 RECOVERY_EARLY(매수금지)→READY→BUY로 표시하며 FAST_JUMP WATCH/READY는 항상 매수금지입니다. Catch 99백분위는 목표진단이며 시장 전체 상위1% 보장은 아닙니다.'}

def ensure_model_migrations():
    """Upgrade persistent models in place without discarding prior samples."""
    try:
        compact_jsonl(RALLY_SAMPLE_FILE,RALLY_SAMPLE_KEEP,RALLY_SAMPLE_COMPACT_TRIGGER)
        if RALLY_SAMPLE_FILE.exists() and (STATE.rally_model or {}).get('version')!='RALLY_DNA_V3_TRUTH_ORDERBOOK_EVENTS':
            review_day=str((STATE.rally_model or {}).get('last_review_day') or (datetime.now(KST)-timedelta(days=1)).strftime('%Y%m%d'))
            rebuild_rally_model(review_day)
    except Exception as e:STATE.rally_status['migration_error']=str(e)[:160]
    try:
        compact_jsonl(EXIT_SAMPLE_FILE,EXIT_SAMPLE_KEEP,EXIT_SAMPLE_COMPACT_TRIGGER)
        if EXIT_SAMPLE_FILE.exists() and (STATE.exit_model or {}).get('version')!='EXIT_DNA_V1_WEIGHTED_CALIBRATED':
            review_day=str((STATE.exit_model or {}).get('last_review_day') or (datetime.now(KST)-timedelta(days=1)).strftime('%Y%m%d'))
            rebuild_exit_model(review_day)
    except Exception as e:STATE.exit_status['migration_error']=str(e)[:160]

app=FastAPI(title='Quant Nova Ignition Radar',version=APP_VERSION)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')

@app.on_event('startup')
async def start():
    _load_krx_calendar();persist_ws_contract(load_ws_contract());load_market_events();load_nxt_alerts();load_nxt_memory_ledger();load_next_day_picks();load_manual_positions();ensure_vapid_keys();load_push_subscriptions();_activate_pending_learning_if_due();ensure_model_migrations()
    asyncio.create_task(daily_rollover_loop(),name='nova-day-rollover');asyncio.create_task(scoring_loop(),name='nova-dirty-scoring');asyncio.create_task(persistence_loop(),name='nova-persistence');asyncio.create_task(performance_guard_loop(),name='nova-performance-guard');asyncio.create_task(discovery_loop(),name='nova-discovery-slow');asyncio.create_task(nxt_fast_radar_loop(),name='nova-nxt-fast-rolling');asyncio.create_task(ws_loop(),name='nova-websocket');asyncio.create_task(ws_contract_probe_loop(),name='nova-ws-contract-probe');asyncio.create_task(smart_money_loop(),name='nova-smart-money');asyncio.create_task(market_event_loop(),name='nova-market-events');asyncio.create_task(rally_trace_loop(),name='nova-rally-trace');asyncio.create_task(rally_review_loop(),name='nova-rally-review');asyncio.create_task(exit_trace_loop(),name='nova-exit-trace');asyncio.create_task(exit_review_loop(),name='nova-exit-review');asyncio.create_task(manual_position_loop(),name='nova-manual-position-manager');asyncio.create_task(close_pick_loop(),name='nova-close-picks');asyncio.create_task(replay_flush_loop(),name='nova-replay-journal');asyncio.create_task(evidence_loop(),name='nova-evidence');asyncio.create_task(archive_loop(),name='nova-archive')

@app.on_event('shutdown')
async def stop():
    global _REST_CLIENT
    try:
        perf,mem,led=_build_persist_snapshot();buy_state=_build_buy_state_payload();await asyncio.to_thread(_write_persist_snapshot,perf,mem,led,buy_state)
    except Exception:pass
    persist_manual_positions()
    if _REST_CLIENT is not None:
        await _REST_CLIENT.aclose();_REST_CLIENT=None

@app.get('/')
async def root():return FileResponse(BASE/'static/index.html')

@app.get('/sw.js')
async def service_worker():return FileResponse(BASE/'static/sw.js',media_type='application/javascript')

@app.get('/manifest.webmanifest')
async def web_manifest():return FileResponse(BASE/'static/manifest.webmanifest',media_type='application/manifest+json')

@app.get('/api/nxt-alerts')
async def nxt_alerts_api():
    return {'ok':True,'version':APP_VERSION,'active':nxt_radar_session_active(),'regular_active':nxt_regular_session_active(),'after_active':nxt_after_session_active(),'premarket_active':nxt_premarket_session_active(),'count':len(STATE.nxt_alerts),'rows':list(STATE.nxt_alerts)[-100:][::-1],'push':STATE.push_status,'generated_at':now_kst()}

@app.get('/api/nxt-signal-table')
async def nxt_signal_table_api():
    return build_nxt_signal_management()

@app.get('/api/close-picks')
async def close_picks_api():
    d=STATE.next_day_picks or {'rows':[]};sec=kst_seconds();visible=bool(str(d.get('effective_day') or '')==today_kst() and sec>=NXT_MORNING_LIST_SECONDS) or bool(str(d.get('source_day') or '')==today_kst() and sec>=NXT_CLOSE_BET_WINDOW_START_SECONDS)
    return {'ok':True,'version':APP_VERSION,'visible':visible,'source_day':d.get('source_day'),'effective_day':d.get('effective_day'),'generated_at':d.get('generated_at'),'final':d.get('final',False),'count':len(d.get('rows') or []),'rows':(d.get('rows') or []) if visible else [],'premarket_active':nxt_premarket_session_active(),'note':'19:30~19:50 NXT-only 강도가 지속되면 CLOSE_READY/CLOSE_BUY를 즉시 표시·Push합니다. 19:50은 최종 요약 시점일 뿐이며, 목록은 익일 07:50 유지 후 08:00 NXT 프리마켓에서 재확인합니다. 주문은 자동실행하지 않습니다.'}

@app.get('/api/push/public-key')
async def push_public_key():
    pub=ensure_vapid_keys();return {'ok':bool(pub),'version':APP_VERSION,'public_key':pub,'subscriptions':len(STATE.push_subscriptions)}

@app.post('/api/push/subscribe')
async def push_subscribe(req:Request):
    body=await req.json();sub=body.get('subscription') if isinstance(body,dict) else None
    if not isinstance(sub,dict) or not sub.get('endpoint'):return {'ok':False,'error':'INVALID_SUBSCRIPTION'}
    ep=str(sub.get('endpoint'));STATE.push_subscriptions=[x for x in STATE.push_subscriptions if str(x.get('endpoint'))!=ep];STATE.push_subscriptions.append(sub);STATE.push_subscriptions=STATE.push_subscriptions[-100:];persist_push_subscriptions()
    return {'ok':True,'subscriptions':len(STATE.push_subscriptions)}

@app.post('/api/push/unsubscribe')
async def push_unsubscribe(req:Request):
    body=await req.json();ep=str((body or {}).get('endpoint') or '');before=len(STATE.push_subscriptions);STATE.push_subscriptions=[x for x in STATE.push_subscriptions if str(x.get('endpoint'))!=ep];persist_push_subscriptions();return {'ok':True,'removed':before-len(STATE.push_subscriptions)}

@app.get('/api/nova')
async def nova():
    rows=[];now=time.time();truth=feed_truth()
    for i,c in enumerate(ranked()[:40],1):
        cap=None
        buy_caps=[x for x in c.captures.values() if x.stage=='BUY']
        if buy_caps: cap=max(buy_caps,key=lambda x:x.at)
        else:
            for st in ('IGNITION','PRESSURE','WATCH'):
                if st in c.captures:cap=c.captures[st];break
        evidence={
            'overlap':int(c.metrics.get('discovery_overlap') or 0),'volume_accel':c.metrics.get('volume_accel'),'buy_pressure':c.metrics.get('buy_pressure'),'vwap_gap':c.metrics.get('vwap_gap'),'micro_breakout':c.metrics.get('micro_breakout'),'dual_venue':bool(c.metrics.get('dual_venue')),'tick_count_60s':int(c.metrics.get('tick_count_60s') or 0),'fresh':bool(c.metrics.get('fresh')),'smart_money_score':c.metrics.get('smart_money_score'),'algo_score':c.metrics.get('algo_score'),'algo_persistence':c.metrics.get('algo_persistence'),'aggressive_buy_tick_persistence':c.metrics.get('algo_persistence'),'micro_vwap_gap':c.metrics.get('micro_vwap_gap'),'session_vwap':c.metrics.get('session_vwap'),'session_vwap_gap':c.metrics.get('session_vwap_gap'),'ws_tier':c.ws_tier,'source_age_sec':c.metrics.get('source_age_sec'),'program_age_sec':round(smart_freshness(c).get('program_age'),1) if c.program_updated_at else None,'program_rt_age_sec':round(smart_freshness(c).get('program_rt_age'),1) if c.program_rt_at else None,'investor_age_sec':round(smart_freshness(c).get('investor_age'),1) if c.investor_updated_at else None,'program_net':c.metrics.get('program_net'),'program_delta':c.metrics.get('program_delta'),'trust_net':c.metrics.get('trust_net'),'trust_delta':c.metrics.get('trust_delta'),'pension_net':c.metrics.get('pension_net'),'pension_delta':c.metrics.get('pension_delta'),'institution_net':c.metrics.get('institution_net'),'institution_delta':c.metrics.get('institution_delta'),'foreign_net':c.metrics.get('foreign_net'),'foreign_delta':c.metrics.get('foreign_delta'),'smart_age_ms':c.metrics.get('smart_age_ms'),'sector':c.sector,'sector_score':c.metrics.get('sector_score'),'sector_breadth':c.metrics.get('sector_breadth'),'sector_members':c.metrics.get('sector_members'),'sector_leader':c.metrics.get('sector_leader'),'sector_avg_rate':c.metrics.get('sector_avg_rate'),'sector_diffusion':c.metrics.get('sector_diffusion'),'sector_follower':bool(c.metrics.get('sector_follower')),'entry_state':c.entry_state,'entry_reason':c.metrics.get('entry_reason'),'entry_ready':bool(c.metrics.get('entry_ready')),'pressure_hold_sec':c.metrics.get('pressure_hold_sec'),'pullback_pct':c.metrics.get('pullback_pct'),'recovery_pct':c.metrics.get('recovery_pct'),'cooldown_sec':c.metrics.get('cooldown_sec'),'entry_route':c.metrics.get('entry_route'),'direct_sec':c.metrics.get('direct_sec'),'direct_support_ok':c.metrics.get('direct_support_ok'),'rally_dna_active':bool(c.metrics.get('rally_dna_active')),'rally_dna_match':c.metrics.get('rally_dna_match'),'rally_dna_trap':c.metrics.get('rally_dna_trap'),'rally_dna_bonus':c.metrics.get('rally_dna_bonus'),'rally_dna_type':c.metrics.get('rally_dna_type'),'rally_dna_samples':c.metrics.get('rally_dna_samples'),'rally_dna_raw_match':c.metrics.get('rally_dna_raw_match'),'rally_dna_calibrated':bool(c.metrics.get('rally_dna_calibrated')),'exit_action':c.metrics.get('exit_action'),'exit_reason':c.metrics.get('exit_reason'),'exit_dna_probability':c.metrics.get('exit_dna_probability'),'exit_dna_type':c.metrics.get('exit_dna_type'),'exit_dna_active':bool(c.metrics.get('exit_dna_active')),'exit_mfe':c.metrics.get('exit_mfe'),'exit_mae':c.metrics.get('exit_mae'),'exit_giveback':c.metrics.get('exit_giveback'),'exit_dynamic_stop':c.metrics.get('exit_dynamic_stop'),'exit_protect_floor':c.metrics.get('exit_protect_floor'),'add_on_count':c.metrics.get('add_on_count'),'compression':c.metrics.get('compression'),'volume_accel_ready':bool(c.metrics.get('volume_accel_ready')),'volume_baseline_ticks':c.metrics.get('volume_baseline_ticks'),'orderbook_presignal':c.metrics.get('orderbook_presignal'),'orderbook_age_sec':c.metrics.get('orderbook_age_sec'),'orderbook_samples':c.metrics.get('orderbook_samples'),'event_signal':c.metrics.get('event_signal'),'event_source':c.metrics.get('event_source'),'event_title':c.metrics.get('event_title'),'integrity_last':c.metrics.get('integrity_last'),'duplicate_ticks':c.duplicate_ticks,'reorder_ticks':c.reorder_ticks,'gap_anomalies':c.gap_anomalies,'price_anomalies':c.price_anomalies,'quarantined_ticks':c.quarantined_ticks,'program_fresh':bool(c.metrics.get('program_fresh')),'investor_fresh':bool(c.metrics.get('investor_fresh')),'nxt_after_mode':bool(c.metrics.get('nxt_after_mode')),'nxt_radar_score':c.metrics.get('nxt_radar_score'),'nxt_takeover_score':c.metrics.get('nxt_takeover_score'),'nxt_radar_count':c.metrics.get('nxt_radar_count'),'nxt_krx_basis_pct':c.metrics.get('nxt_krx_basis_pct'),'nxt_volume_accel_30s':c.metrics.get('nxt_volume_accel_30s'),'nxt_volume_accel_60s':c.metrics.get('nxt_volume_accel_60s'),'nxt_dryup_ratio_10m':c.metrics.get('nxt_dryup_ratio_10m'),'nxt_second_wave_state':c.metrics.get('nxt_second_wave_state'),'nxt_second_wave_pullback_pct':c.metrics.get('nxt_second_wave_pullback_pct'),'nxt_second_wave_base_minutes':c.metrics.get('nxt_second_wave_base_minutes'),'nxt_second_wave_breakout':c.metrics.get('nxt_second_wave_breakout'),'nxt_recovery_state':c.metrics.get('nxt_recovery_state'),'nxt_recovery_drawdown_pct':c.metrics.get('nxt_recovery_drawdown_pct'),'nxt_recovery_ratio':c.metrics.get('nxt_recovery_ratio'),'nxt_recovery_peak_gap_pct':c.metrics.get('nxt_recovery_peak_gap_pct'),'nxt_recovery_peak_age_min':c.metrics.get('nxt_recovery_peak_age_min'),'nxt_catch_score':c.metrics.get('nxt_catch_score'),'nxt_catch_percentile':c.metrics.get('nxt_catch_percentile'),'nxt_top1_target':bool(c.metrics.get('nxt_top1_target')),'nxt_fast_jump_alert_stage':c.nxt_fast_jump_alert_stage,'nxt_alert_stage':c.nxt_alert_stage,'nxt_second_wave_alert_stage':c.nxt_second_wave_alert_stage
        }
        rows.append({'rank':i,'code':c.code,'name':c.name or c.code,'sector':c.sector,'sector_source':c.sector_source,'price':c.last_price,'change_rate':c.rate,'score':c.score,'confidence':c.confidence,'stage':c.stage,'entry_state':c.entry_state,'entry_reason':c.metrics.get('entry_reason') or c.reject_reason,'entry_ready':bool(c.metrics.get('entry_ready')),'reasons':c.reasons,'metrics':c.metrics,'evidence':evidence,'sources':list(c.source_hits),'venue':c.venue,'fid9081':c.last_fid9081,'last_tick_at_kst':fmt_kst(c.last_tick_at,'%H:%M:%S') if c.last_tick_at else None,'price_source':c.last_price_source or (('WS_'+str((STATE.ws_contract or {}).get('trade_type') or '')) if c.last_tick_at else c.last_price_source if c.last_price else ''),'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None,'capture':capture_json(cap) if cap else None,'captures':{k:capture_json(v) for k,v in c.captures.items()}})
    ok_rest=sum(1 for x in STATE.rest_status.values() if x.get('ok'))
    return {'version':APP_VERSION,'generated_at':now_kst(),'threshold':MIN_SCORE,'rows':rows,'feed':truth,'health':{'ws':STATE.ws_status,'ws_contract':ws_contract_status(),'market_events':STATE.market_event_status,'rest_ok':ok_rest,'rest_total':len(STATE.rest_status),'candidate_count':len(STATE.candidates),'performance_guard':performance_guard_status(),'candidate_cap':STATE.candidate_cap_status,'lock_policy':STATE.lock_policy,'evidence':STATE.evidence_status,'replay':STATE.replay_status,'archive':STATE.archive_status,'day_rollover':{'active_day':STATE.active_day,'last_rollover_at':STATE.last_rollover_at},'subscribed':len(STATE.ws_codes),'core_subscribed':len(STATE.core_codes),'challenger_subscribed':len(STATE.challenger_codes),'scan_cycles':STATE.scan_cycles,'event_count':STATE.event_count,'smart_status':STATE.smart_status,'sector_status':STATE.sector_status,'learning':STATE.learn,'rally_dna':rally_model_status(),'exit_dna':exit_model_status(),'nxt_after':{'active':nxt_radar_session_active(),'regular_active':nxt_regular_session_active(),'after_active':nxt_after_session_active(),'premarket_active':nxt_premarket_session_active(),'alerts':len(STATE.nxt_alerts),'burst_watch':len(STATE.burst_codes),'burst_highres':len(STATE.burst_highres_codes),'ws_emergency_alerts':int(STATE.ws_status.get('ws_emergency_alerts') or 0),'second_wave_memory':len(STATE.nxt_memory_codes),'push':STATE.push_status},'next_day_picks':{'effective_day':STATE.next_day_picks.get('effective_day'),'count':len(STATE.next_day_picks.get('rows') or [])}},'policy':{'probability_note':'NOVA Score는 실시간 상대 우선순위입니다. 실제 승률은 누적 성과표본으로 별도 산출해야 합니다.','data_truth':'Kiwoom REST snapshot + official fixed 0B/0w/0D WebSocket contract + FID9081 fail-closed + realtime orderbook + investor/program flow + optional DART/RSS + RALLY DNA prior','universe':'ordinary equities only; ETF/ETN excluded + stale source TTL + 40 CORE + 40 rotating CHALLENGER, event promotion','entry_policy':'점수는 발견용. 이중 BUY + 거리 가중 RALLY DNA + EXIT DNA. adaptive_entry와 DNA 학습은 모두 당일 라벨→익일 적용','time_truth':'Asia/Seoul ZoneInfo 기준'}}

@app.get('/api/buy-signals')
async def buy_signals():
    now=time.time(); day=today_kst(); rows=[]
    for c in STATE.candidates.values():
        if c.signal_count_today<=0 or c.last_signal_at<=0:continue
        entry=c.last_signal_price
        ret=round((c.last_price/entry-1)*100,2) if entry>0 and c.last_price>0 else None
        maxret=round((c.signal_max_price/entry-1)*100,2) if entry>0 and c.signal_max_price>0 else None
        minret=round((c.signal_min_price/entry-1)*100,2) if entry>0 and c.signal_min_price>0 else None
        smart=c.smart or {}; pos=STATE.exit_positions.get(c.last_buy_entry_id) or {}
        rows.append({
            'code':c.code,'name':c.name or c.code,'sector':c.sector,'sector_score':c.metrics.get('sector_score'),'sector_leader':c.metrics.get('sector_leader'),'stage':'BUY','entry_state':c.entry_state,'entry_id':c.last_buy_entry_id,'entry_route':c.last_buy_route,'entry_path':('NXT>FIRST_WAVE>DEEP_SHAKEOUT>RECOVERY>BUY' if c.last_buy_route=='NXT_RECOVERY_RECLAIM' else ('NXT_AFTER>FIRST_WAVE>DRYUP_BASE>REIGNITION>BUY' if c.last_buy_route=='NXT_SECOND_WAVE_BASE' else ('DISCOVERY>PRESSURE_BUILD>DIRECT_ARM>BUY' if c.last_buy_route=='DIRECT_IGNITION' else 'DISCOVERY>PRESSURE_BUILD>PULLBACK>REACCEL>BUY'))),
            'first_signal_at_kst':fmt_kst(c.first_signal_at,'%H:%M:%S') if c.first_signal_at else None,
            'last_signal_at_kst':fmt_kst(c.last_signal_at,'%H:%M:%S') if c.last_signal_at else None,
            'last_signal_age_sec':round(now-c.last_signal_at) if c.last_signal_at else None,
            'price':c.last_price,'change_rate':c.rate,'entry_price':entry,'signal_return':ret,'max_return':maxret,'min_return':minret,
            'signal_count':c.signal_count,'signal_count_today':c.signal_count_today,'score':c.score,'signal_score':c.last_signal_score,'confidence':c.confidence,
            'venue':c.venue,'fid9081':c.last_fid9081,'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None,
            'reasons':c.last_signal_reasons or c.reasons,
            'smart_money_score':c.metrics.get('smart_money_score'),'algo_persistence':c.metrics.get('algo_persistence'),
            'program_net':smart.get('program_net'),'program_delta':smart.get('program_delta'),'trust_net':smart.get('trust_net'),'trust_delta':smart.get('trust_delta'),'pension_net':smart.get('pension_net'),'pension_delta':smart.get('pension_delta'),'institution_net':smart.get('institution_net'),'institution_delta':smart.get('institution_delta'),'foreign_net':smart.get('foreign_net'),'foreign_delta':smart.get('foreign_delta'),'rally_dna_active':bool(c.metrics.get('rally_dna_active')),'rally_dna_match':c.metrics.get('rally_dna_match'),'rally_dna_trap':c.metrics.get('rally_dna_trap'),'rally_dna_bonus':c.metrics.get('rally_dna_bonus'),'rally_dna_type':c.metrics.get('rally_dna_type'),'rally_dna_samples':c.metrics.get('rally_dna_samples'),'rally_dna_raw_match':c.metrics.get('rally_dna_raw_match'),'rally_dna_calibrated':bool(c.metrics.get('rally_dna_calibrated')),
            'exit_action':pos.get('last_action') or c.metrics.get('exit_action') or 'HOLD','exit_reason':pos.get('last_action_reason') or c.metrics.get('exit_reason'),'exit_dna_probability':pos.get('exit_dna_probability') if pos else c.metrics.get('exit_dna_probability'),'exit_dna_type':pos.get('exit_dna_type') if pos else c.metrics.get('exit_dna_type'),'exit_dna_active':bool(pos.get('exit_dna_active') if pos else c.metrics.get('exit_dna_active')),'exit_status':pos.get('status'),'exit_mfe':pos.get('mfe',maxret),'exit_mae':pos.get('mae',minret),'exit_giveback':pos.get('giveback'),'dynamic_stop':pos.get('dynamic_stop'),'protect_floor':pos.get('protect_floor'),'add_on_count':pos.get('add_on_count',0)
        })
    rows.sort(key=lambda x:(STAGE_RANK.get(x['stage'],0),x['score'],x['last_signal_at_kst'] or ''),reverse=True)
    return {'version':APP_VERSION,'day':day,'count':len(rows),'total_events':STATE.buy_signal_events,'generated_at':now_kst(),'rows':rows[:100]}

@app.get('/api/position-manager')
async def position_manager_api():
    return manual_position_payload()

@app.post('/api/position-manager/buy')
async def position_manager_buy(req:Request):
    body=await req.json();code=code6((body or {}).get('code'));style=str((body or {}).get('style') or 'SCALP').upper();entry_venue=str((body or {}).get('entry_venue') or 'AUTO').upper()
    if not code or style not in ('SCALP','SWING','CLOSE_BET') or entry_venue not in ('KRX','NXT','AUTO'):return {'ok':False,'error':'INVALID_CODE_STYLE_OR_VENUE'}
    for pos in STATE.manual_positions.values():
        if pos.get('status')=='OPEN' and str(pos.get('code'))==code:return {'ok':False,'error':'ACTIVE_POSITION_EXISTS','position':_manual_position_row(pos)}
    c=STATE.candidates.get(code)
    if c is None:
        async with STATE.lock:
            c=STATE.candidates.get(code) or STATE.get(code,str((body or {}).get('name') or ''))
            enforce_candidate_cap_locked(time.time())
    fallback_price,_,fallback_venue,_=_manual_market_snapshot(c,{'entry_venue':entry_venue});price=num((body or {}).get('entry_price')) or fallback_price;qty=max(0,num((body or {}).get('qty')))
    if price<=0:return {'ok':False,'error':'NO_VALID_ENTRY_PRICE'}
    if entry_venue=='AUTO':entry_venue=fallback_venue if fallback_venue in ('KRX','NXT') else (c.venue if c.venue in ('KRX','NXT') else 'KRX')
    now=time.time();pid=f'MANUAL:{code}:{int(now)}';source_stage=str((body or {}).get('signal_stage') or c.nxt_second_wave_alert_stage or c.nxt_alert_stage or c.stage);profit_mode=_manual_profit_mode(c,style,source_stage);plan=_manual_plan(style,profit_mode)
    pos={'position_id':pid,'code':code,'name':c.name or str((body or {}).get('name') or code),'style':style,'status':'OPEN','entry_at':now,'entry_at_kst':now_kst(),'entry_price':price,'entry_venue':entry_venue,'profit_mode':profit_mode,'initial_qty':qty,'remaining_pct':100.0,'sold_pct':0.0,'tp1_done':False,'tp2_done':False,'sales':[],'mfe':0.0,'mae':0.0,'giveback':0.0,'current_price':price,'current_return':0.0,'range5_at_entry':num(c.metrics.get('range5_pct')),'signal':'HOLD','signal_reason':f'매수 등록 · {entry_venue} 실체결 추적 · {profit_mode}','suggested_sell_pct':0.0,'notified_signals':[],'source_stage':source_stage,'source_score':c.score,'source_rally_dna':c.metrics.get('rally_dna_match'),'source_nxt_radar':c.metrics.get('nxt_radar_score'),'source_buy_pressure':(c.metrics.get('nxt_buy_pressure') if entry_venue=='NXT' else c.metrics.get('buy_pressure')),'plan':plan}
    STATE.manual_positions[pid]=pos;persist_manual_positions();mark_score_dirty(code);_manual_event(pos,'MANUAL_BUY_START','사용자 매수관리 시작',price,{'qty':qty,'entry_venue':entry_venue,'profit_mode':profit_mode,'plan':plan})
    return {'ok':True,'position':_manual_position_row(pos),'plan':plan}

@app.post('/api/position-manager/edit')
async def position_manager_edit(req:Request):
    body=await req.json();pid=str((body or {}).get('position_id') or '');pos=STATE.manual_positions.get(pid)
    if not pos:return {'ok':False,'error':'POSITION_NOT_FOUND'}
    changed=[]
    if (body or {}).get('entry_venue') is not None:
        v=str((body or {}).get('entry_venue') or '').upper()
        if v not in ('KRX','NXT'):return {'ok':False,'error':'INVALID_ENTRY_VENUE'}
        pos['entry_venue']=v;changed.append('entry_venue')
    if (body or {}).get('entry_price') is not None:
        ep=num((body or {}).get('entry_price'))
        if ep<=0:return {'ok':False,'error':'INVALID_ENTRY_PRICE'}
        pos['entry_price']=ep;changed.append('entry_price')
        c=STATE.candidates.get(str(pos.get('code')));cur,_,_,_=_manual_market_snapshot(c,pos);ret=(cur/ep-1)*100 if cur>0 else 0
        pos['mfe']=round(max(0,ret),2);pos['mae']=round(min(0,ret),2);pos['giveback']=round(max(0,num(pos.get('mfe'))-ret),2);pos['current_return']=round(ret,2);pos['tp1_done']=False;pos['tp2_done']=False;pos['remaining_pct']=max(0,100-num(pos.get('sold_pct')))
    if (body or {}).get('last_sale_price') is not None:
        sp=num((body or {}).get('last_sale_price'));sales=list(pos.get('sales') or [])
        if sp<=0 or not sales:return {'ok':False,'error':'NO_SALE_TO_EDIT'}
        sales[-1]['price']=sp;sales[-1]['edited_at_kst']=now_kst();pos['sales']=sales;changed.append('last_sale_price')
    mode=str((body or {}).get('profit_mode') or pos.get('profit_mode') or 'NORMAL').upper()
    if mode not in ('NORMAL','STRONG','ELITE'):return {'ok':False,'error':'INVALID_PROFIT_MODE'}
    if mode!=pos.get('profit_mode'):pos['profit_mode']=mode;changed.append('profit_mode')
    pos['plan']=_manual_plan(str(pos.get('style') or 'SCALP'),mode);pos['signal']='HOLD';pos['suggested_sell_pct']=0.0;pos['signal_reason']='체결정보 수정 후 재평가';persist_manual_positions();_manual_event(pos,'MANUAL_POSITION_EDIT','체결정보 수정',num(pos.get('entry_price')),{'changed':changed})
    return {'ok':True,'position':_manual_position_row(pos),'changed':changed}

@app.post('/api/position-manager/confirm')
async def position_manager_confirm(req:Request):
    body=await req.json();pid=str((body or {}).get('position_id') or '');action=str((body or {}).get('action') or 'SUGGESTED').upper();pos=STATE.manual_positions.get(pid)
    if not pos:return {'ok':False,'error':'POSITION_NOT_FOUND'}
    if pos.get('status')!='OPEN':return {'ok':False,'error':'POSITION_NOT_OPEN','position':_manual_position_row(pos)}
    c=STATE.candidates.get(str(pos.get('code')));fallback_price,_,_,_=_manual_market_snapshot(c,pos);price=num((body or {}).get('price')) or fallback_price or num(pos.get('current_price'));remaining=max(0,num(pos.get('remaining_pct'),100));signal=str(pos.get('signal') or 'HOLD');plan=_manual_plan(pos.get('style'),pos.get('profit_mode'))
    if action=='CANCEL':
        pos.update({'status':'CANCELLED','closed_at':time.time(),'closed_at_kst':now_kst(),'remaining_pct':0.0,'signal':'CANCELLED','signal_reason':'매수관리 취소'});_manual_event(pos,'MANUAL_POSITION_CANCEL','사용자 취소',price);persist_manual_positions();return {'ok':True,'position':_manual_position_row(pos)}
    if price<=0:return {'ok':False,'error':'INVALID_SELL_PRICE'}
    if action=='FULL':sell_pct=remaining
    elif action=='TP1':sell_pct=min(remaining,plan['tp1_pct']);pos['tp1_done']=True
    elif action=='TP2':sell_pct=min(remaining,plan['tp2_pct']);pos['tp2_done']=True
    else:
        sell_pct=min(remaining,max(0,num(pos.get('suggested_sell_pct'))))
        if sell_pct<=0:return {'ok':False,'error':'NO_ACTIVE_SELL_SIGNAL','position':_manual_position_row(pos)}
        if signal=='SELL_1':pos['tp1_done']=True
        if signal in ('SELL_2','SELL_2_SHORT'):pos['tp2_done']=True
    pos['remaining_pct']=round(max(0,remaining-sell_pct),1);pos['sold_pct']=round(100-num(pos.get('remaining_pct')),1);sales=list(pos.get('sales') or []);sales.append({'at':time.time(),'at_kst':now_kst(),'price':price,'sell_pct':round(sell_pct,1),'signal':signal,'action':action,'venue':pos.get('entry_venue')});pos['sales']=sales[-20:]
    _manual_event(pos,'MANUAL_SELL_CONFIRMED',f'{action} 실제체결 확인',price,{'sell_pct':sell_pct,'source_signal':signal,'entry_venue':pos.get('entry_venue')})
    if pos['remaining_pct']<=0.01:
        pos.update({'status':'CLOSED','closed_at':time.time(),'closed_at_kst':now_kst(),'close_price':price,'signal':'CLOSED','signal_reason':'전량 매도 실제체결 확인','suggested_sell_pct':0.0})
    else:
        pos.update({'signal':'HOLD','signal_reason':'부분매도 실제체결 확인 후 추세 재평가','suggested_sell_pct':0.0,'fade_since':0})
    persist_manual_positions();mark_score_dirty(str(pos.get('code')))
    return {'ok':True,'position':_manual_position_row(pos)}

@app.get('/api/ws-contract')
async def ws_contract_api():
    return {'ok':True,'version':APP_VERSION,'contract':ws_contract_status(),'generated_at':now_kst()}

@app.get('/api/market-events')
async def market_events_api():
    return {'ok':True,'version':APP_VERSION,'status':STATE.market_event_status,'rows':list(STATE.market_events)[-100:][::-1],'generated_at':now_kst()}

@app.get('/api/rally-dna')
async def rally_dna_api():
    st=rally_model_status();m=STATE.rally_model or {}
    return {'ok':True,'version':APP_VERSION,'status':st,'model':{'version':m.get('version'),'samples':m.get('samples',0),'positive':m.get('positive',0),'negative':m.get('negative',0),'types':m.get('types') or {},'distance_weights':m.get('distance_weights') or {},'calibration':m.get('calibration') or {},'validation':m.get('validation'),'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'effective_from_day':m.get('effective_from_day'),'leakage_guard':m.get('leakage_guard')},'review':STATE.rally_review,'generated_at':now_kst()}

@app.get('/api/exit-dna')
async def exit_dna_api():
    st=exit_model_status();m=STATE.exit_model or {}
    open_positions=[x for x in STATE.exit_positions.values() if x.get('status') in ('OPEN','EXIT_SIGNALED')]
    return {'ok':True,'version':APP_VERSION,'status':st,'model':{'version':m.get('version'),'samples':m.get('samples',0),'exit':m.get('positive',0),'hold':m.get('negative',0),'distance_weights':m.get('distance_weights') or {},'calibration':m.get('calibration') or {},'validation':m.get('validation'),'last_review_day':m.get('last_review_day'),'last_review_at':m.get('last_review_at'),'effective_from_day':m.get('effective_from_day'),'leakage_guard':m.get('leakage_guard')},'review':STATE.exit_review,'open_positions':len(open_positions),'generated_at':now_kst()}

@app.get('/api/performance')
async def performance():
    out=[]
    for c in STATE.candidates.values():
        for st,cap in c.captures.items():
            out.append({'code':c.code,'name':c.name,'stage':st,**capture_json(cap)})
    out.sort(key=lambda x:x['at'],reverse=True)
    return {'version':APP_VERSION,'count':len(out),'rows':out[:300]}

@app.get('/api/evidence')
async def evidence_api():
    try:
        if EVIDENCE_REPORT_FILE.exists():report=json.loads(EVIDENCE_REPORT_FILE.read_text(encoding='utf-8'))
        else:report=await asyncio.to_thread(write_evidence_report,DATA_DIR,EVIDENCE_REPORT_FILE)
        return {'ok':True,'version':APP_VERSION,'status':STATE.evidence_status,'report':report}
    except Exception as e:return {'ok':False,'version':APP_VERSION,'error':str(e)[:180],'status':STATE.evidence_status}

@app.get('/api/backtest/status')
async def backtest_status_api():
    rows=[]
    for mode in ('signal','micro','observation'):
        p=DATA_DIR/f'backtest_{mode}_latest.json'
        if p.exists():
            try:
                j=json.loads(p.read_text(encoding='utf-8'));rows.append({'mode':mode,'generated_at':j.get('generated_at'),'rows':j.get('rows'),'top':(j.get('results') or [None])[0],'research_only':True})
            except Exception:pass
    return {'ok':True,'version':APP_VERSION,'rows':rows,'command':'python scripts/replay_backtest.py --data-dir /app/data --mode signal|micro|observation','auto_apply':False}

@app.get('/api/health')
async def health():
    return {'ok':True,'version':APP_VERSION,'feed':feed_truth(),'nxt_after':{'active':nxt_radar_session_active(),'regular_active':nxt_regular_session_active(),'after_active':nxt_after_session_active(),'premarket_active':nxt_premarket_session_active(),'alerts':len(STATE.nxt_alerts),'burst_watch':len(STATE.burst_codes),'burst_highres':len(STATE.burst_highres_codes),'ws_emergency_alerts':int(STATE.ws_status.get('ws_emergency_alerts') or 0),'second_wave_memory':len(STATE.nxt_memory_codes),'fast_jump_watch':sum(1 for c in STATE.candidates.values() if c.nxt_fast_jump_alert_stage),'top1_target_count':sum(1 for c in STATE.candidates.values() if c.metrics.get('nxt_top1_target')),'latest':(STATE.nxt_alerts[-1] if STATE.nxt_alerts else None)},'next_day_picks':{'effective_day':STATE.next_day_picks.get('effective_day'),'count':len(STATE.next_day_picks.get('rows') or []),'generated_at':STATE.next_day_picks.get('generated_at')},'push':STATE.push_status,'calendar':{'trading_day':is_krx_trading_day(),'next_effective_day':_next_effective_day(),'source':_load_krx_calendar().get('source'),'error':_load_krx_calendar().get('error'),'calendar_stale':bool(_load_krx_calendar().get('calendar_stale')),'covered_years':_load_krx_calendar().get('covered_years',[])},'ws':STATE.ws_status,'ws_contract':ws_contract_status(),'market_events':STATE.market_event_status,'rest':STATE.rest_status,'performance_guard':performance_guard_status(),'candidate_cap':STATE.candidate_cap_status,'lock_policy':STATE.lock_policy,'evidence':STATE.evidence_status,'replay':STATE.replay_status,'archive':STATE.archive_status,'day_rollover':{'active_day':STATE.active_day,'last_rollover_at':STATE.last_rollover_at},'generated_at':now_kst(),'smart_money':STATE.smart_status,'sector':STATE.sector_status,'learning':STATE.learn,'rally_dna':rally_model_status(),'exit_dna':exit_model_status(),'data_files':{'events':str(EVENT_FILE),'performance':str(STATE_FILE),'learning':str(LEARN_FILE),'training':str(TRAIN_FILE),'buy_signals':str(BUY_SIGNAL_FILE),'buy_signal_state':str(BUY_SIGNAL_STATE),'rally_model':str(RALLY_MODEL_FILE),'rally_samples':str(RALLY_SAMPLE_FILE),'rally_review':str(RALLY_REVIEW_FILE),'rally_trace_today':str(rally_trace_file()),'rally_teacher_audit':str(RALLY_TEACHER_AUDIT_FILE),'exit_model':str(EXIT_MODEL_FILE),'exit_samples':str(EXIT_SAMPLE_FILE),'exit_review':str(EXIT_REVIEW_FILE),'exit_positions':str(EXIT_POSITION_FILE),'exit_actions':str(EXIT_ACTION_FILE),'exit_trace_today':str(exit_trace_file()),'ws_contract':str(WS_CONTRACT_FILE),'market_events':str(MARKET_EVENT_FILE),'nxt_alerts':str(NXT_ALERT_FILE),'nxt_second_wave':str(NXT_SECOND_WAVE_FILE),'nxt_next_day_picks':str(NXT_NEXT_DAY_PICK_FILE),'nxt_first_wave_memory':str(NXT_FIRST_WAVE_MEMORY_FILE),'nxt_daily_strong_ledger':str(NXT_DAILY_STRONG_LEDGER_FILE),'push_subscriptions':str(PUSH_SUB_FILE),'push_delivery':str(PUSH_DELIVERY_FILE),'manual_positions':str(MANUAL_POSITION_FILE),'manual_position_events':str(MANUAL_POSITION_EVENT_FILE),'evidence_report':str(EVIDENCE_REPORT_FILE),'replay_journal_today':str(replay_journal_file()),'prospective_observations':str(PROSPECTIVE_OBSERVATION_FILE)},'entry_policy':{'version':'ENTRY_V18_TRUTH_GUARD_MAX_PROFIT','routes':['PULLBACK_REACCEL','DIRECT_IGNITION','DNA_EARLY_TRIGGER','NXT_ALLDAY_EARLY_RADAR','NXT_WS_EMERGENCY_IGNITION','NXT_SECOND_WAVE_BASE','NXT_RECOVERY_RECLAIM'],'hold_sec':ENTRY_HOLD_SEC,'pullback_min':ENTRY_PULLBACK_MIN,'pullback_max':ENTRY_PULLBACK_MAX,'reaccel_sec':ENTRY_REACCEL_SEC,'direct_score':DIRECT_SCORE,'direct_hold_sec':DIRECT_HOLD_SEC,'direct_confirm_sec':DIRECT_CONFIRM_SEC,'cooldown_sec':ENTRY_COOLDOWN_SEC,'reentry_min_sec':ENTRY_REENTRY_MIN_SEC,'reentry_gain_pct':ENTRY_REENTRY_GAIN_PCT,'max_daily':ENTRY_MAX_DAILY,'pullback_confirm':{'score':PULLBACK_CONFIRM_SCORE,'buy_pressure':PULLBACK_CONFIRM_BUY_PRESSURE,'volume_accel':PULLBACK_CONFIRM_ACCEL},'normal_market_signal_target':'8-25/day market-wide diagnostic only','quota_enforced':False,'timezone':'Asia/Seoul','rally_dna':'weighted distance + skill/lift calibrated + broad-market teacher audit -> next-day only','adaptive_learning':'mature BUY label -> pending weights -> next-day only','exit_dna':'ENTRY-VENUE LOCKED MFE/giveback + flow fade EOD review -> next-day only; automatic ELITE uses +12/+22/+35 base floors +4/+10/+18 and 9% runner trail after TP2 territory','exit_stop_range':[EXIT_STOP_MIN,EXIT_STOP_MAX],'exit_protect_floors':{'mfe2':EXIT_PROTECT_MFE2,'mfe4':EXIT_PROTECT_MFE4,'mfe7':EXIT_PROTECT_MFE7},'exit_add_return_range':[EXIT_ADD_MIN_RETURN,EXIT_ADD_MAX_RETURN],'manual_position_manager':{'order_execution':'NONE_USER_CONFIRM_ONLY','pricing':'USER_ACTUAL_ENTRY/EXIT + VENUE_LOCKED_KRX_NXT','profit_modes':['NORMAL','STRONG','ELITE'],'SCALP':{m:_manual_plan('SCALP',m) for m in ('NORMAL','STRONG','ELITE')},'SWING':{m:_manual_plan('SWING',m) for m in ('NORMAL','STRONG','ELITE')},'CLOSE_BET':{m:_manual_plan('CLOSE_BET',m) for m in ('NORMAL','STRONG','ELITE')},'signal_logic':'adaptive TP1/TP2 + live short-term flow fade + profit floor + wider elite runner trail','persistent':True},'discovery_seconds':DISCOVERY_SECONDS,'source_ttl_seconds':SOURCE_TTL_SECONDS,'candidate_ttl_seconds':CANDIDATE_TTL_SECONDS,'max_candidates':MAX_CANDIDATES,'ws_core_limit':WS_CORE_LIMIT,'ws_challenger_limit':WS_CHALLENGER_LIMIT,'ws_registry':'STABLE_GROUP_FROZENSET_DIFF_SERIAL_BATCH_ACK_NO_GRP_DEPENDENCY','rest_pipeline':'INDEPENDENT_NXT_FAST_ROLLING_DEADLINE_CANCEL + AS_COMPLETED_STREAMING_APPLY + SLOW_CONTEXT_SCHEDULER + RATE_LIMITED_SHARED_CLIENT','realtime_scoring':'DIRTY_SYMBOL_COALESCED_80MS + SECTOR_DELTA_REFRESH','persistence':'60S_DIRTY_FLUSH_OFF_WS_PATH + OP_LOG_COMPACTION','docker_logging':'JSON_FILE_10MB_X3','tick_integrity':'DEDUP_REORDER_GAP_AUDIT_PRICE_QUARANTINE','trading_calendar':'KRX_WEEKEND_HOLIDAY_OVERRIDE_NEXT_TRADING_DAY','program_realtime':'OFFICIAL FIXED 0w KRX/NXT-qualified + ka90004 market-list REST cache fallback','challenger_smart_money':'TOP10 LOW-FREQUENCY INVESTOR POLL','sector_membership':'KIWOOM ka10001 CACHE -> MAP -> NAME FALLBACK','rally_episode_sampling':'NON_OVERLAP_20MIN_MULTI_EPISODE','dna_early_trigger':{'min_match':DNA_EARLY_TRIGGER_MIN_MATCH,'max_score_relax':DNA_EARLY_TRIGGER_MAX_RELAX},'orderbook_presignal':'ka10020+ka10021+ka10022 discovery + KRX/NXT(_NX) dual realtime orderbook with venue-isolated baselines; Wall V2 persistence/absorption/cancel-risk is a soft confirm for RECOVERY/CLOSE_BET','news_disclosure_feed':'OPTIONAL DART/RSS deterministic POSITIVE/NEGATIVE/NEUTRAL/UNCERTAIN polarity; severe negatives fail-closed for new BUY; never creates BUY alone','nxt_after_radar':'08:00-08:50 PREMARKET + 09:00:30-15:20 NXT-ONLY parallel shadow radar + 15:40-20:00 NXT-ONLY; BURST-HR + WS emergency staged alerts','nxt_allday_discovery_seconds':NXT_ALLDAY_DISCOVERY_SECONDS,'nxt_fast_rest_timeout':NXT_FAST_REST_TIMEOUT,'nxt_slow_context_seconds':NXT_SLOW_CONTEXT_SECONDS,'nxt_after_discovery_seconds':NXT_AFTER_DISCOVERY_SECONDS,'nxt_fastest_discovery_seconds':NXT_FASTEST_DISCOVERY_SECONDS,'nxt_premarket_discovery_seconds':NXT_PREMARKET_DISCOVERY_SECONDS,'nxt_burst_watch_limit':NXT_BURST_WATCH_LIMIT,'nxt_burst_highres_limit':NXT_BURST_HIGHRES_LIMIT,'nxt_ws_emergency':{'accel30':NXT_WS_EMERGENCY_ACCEL30,'accel60':NXT_WS_EMERGENCY_ACCEL60,'buy_pressure':NXT_WS_EMERGENCY_BUY_PRESSURE,'max_rate':NXT_WS_EMERGENCY_MAX_RATE},'nxt_prospective_catch':{'watch_percentile':NXT_FAST_JUMP_WATCH_PERCENTILE,'ready_percentile':NXT_FAST_JUMP_READY_PERCENTILE,'ready_min_population':NXT_FAST_JUMP_READY_MIN_POPULATION,'top1_min_population':NXT_TOP1_MIN_POPULATION,'buy_policy':'FAST_JUMP_WATCH_READY_NEVER_BUY_DIRECT','top1_status':'UNPROVEN_UNTIL_SUFFICIENT_OOS'},'nxt_second_wave':'PERSISTENT 5H FIRST_WAVE MEMORY -> compact SECOND_WAVE + prospective RECOVERY_EARLY(WATCH_ONLY) -> RECOVERY_READY/BUY; point-in-time only','nxt_next_day_close_picks':'19:30-19:50 sustained NXT-only strength -> CLOSE_READY at 45s / CLOSE_BUY at 90s -> immediate per-candidate push -> 19:50 final summary -> overnight persistence -> next trading day 07:50 list -> 08:00-08:50 NXT-only confirmation','nxt_alert_push':'ALL STAGES RECORDED; FAST_JUMP WATCH/READY and RECOVERY_EARLY explicitly BUY-PROHIBITED; point-in-time frozen snapshot; Push delivery accounted','nxt_signal_management':'PERSISTENT FIRST_ALERT + FAST_JUMP WATCH_ONLY + RECOVERY_EARLY WATCH_ONLY + SECOND_WAVE/RECOVERY BUY + prospective anti-hindsight audit','fid9081_policy':'MISSING_OR_UNKNOWN=>UNKNOWN_FAIL_CLOSED','volume_accel_policy':'NO_PRIOR_60_180S_BASELINE=>NEUTRAL_1.0_NO_SCORE','sector_metadata_scheduler':'STALE_ONLY_ROTATING_CURSOR','universe_filter':'ORDINARY_EQUITY; ETF_ETN_EXCLUDED','ws_contract_probe':'OFFICIAL 0B/0w/0D HEALTH CHECK ONLY; probe can never remap scoring semantics','quality_transition_alert':str(CALIB_ALERT_FILE),'program_fresh_seconds':PROGRAM_HARD_FRESH_SECONDS,'investor_fresh_seconds':INVESTOR_FRESH_SECONDS,'rally_min_samples':RALLY_MIN_SAMPLES,'rally_max_bonus':RALLY_MAX_BONUS,'rally_max_penalty':RALLY_MAX_PENALTY}}
