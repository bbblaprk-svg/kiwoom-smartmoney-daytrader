from __future__ import annotations
import gzip, json, math, statistics, time
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

KST=ZoneInfo('Asia/Seoul')
TOP1_AUDIT_MIN_SAMPLES=300
TOP1_AUDIT_STRONG_SAMPLES=1000

def _num(x, d=0.0):
    try:return float(x)
    except:return d

def _jsonl(path:Path):
    if not path.exists():return []
    op=gzip.open if path.suffix=='.gz' else open
    out=[]
    try:
        with op(path,'rt',encoding='utf-8',errors='ignore') as f:
            for line in f:
                try:out.append(json.loads(line))
                except:pass
    except:pass
    return out

def _iter_unique_files(data_dir:Path, names):
    seen=set()
    for n in names:
        p=data_dir/n
        if p.exists() and str(p) not in seen:seen.add(str(p));yield p
    arch=data_dir/'archive'
    if arch.exists():
        for p in arch.glob('20??????/*.jsonl.gz'):
            if p.name in names and str(p) not in seen:seen.add(str(p));yield p

def _wilson(w,n,z=1.959963984540054):
    if n<=0:return [None,None]
    p=w/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den
    half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return [round(max(0,mid-half)*100,2),round(min(1,mid+half)*100,2)]

def _mean_ci(xs,z=1.959963984540054):
    n=len(xs)
    if not n:return [None,None]
    m=statistics.mean(xs)
    if n<2:return [round(m,3),round(m,3)]
    se=statistics.stdev(xs)/math.sqrt(n)
    return [round(m-z*se,3),round(m+z*se,3)]

def _mdd(returns):
    eq=1.0;peak=1.0;worst=0.0
    for r in returns:
        eq*=max(0.0001,1+r/100.0);peak=max(peak,eq);worst=min(worst,(eq/peak-1)*100)
    return round(worst,3)

def _metrics(rows):
    rs=[_num(x.get('ret')) for x in rows if x.get('ret') is not None]
    mfes=[_num(x.get('mfe')) for x in rows if x.get('mfe') is not None]
    maes=[_num(x.get('mae')) for x in rows if x.get('mae') is not None]
    n=len(rs);w=sum(x>0 for x in rs);g=sum(x for x in rs if x>0);loss=-sum(x for x in rs if x<0)
    sharpe=None
    if n>=2:
        sd=statistics.stdev(rs)
        if sd>1e-12:sharpe=statistics.mean(rs)/sd*math.sqrt(n)
    return {
        'samples':n,'wins':w,'win_rate_pct':round(w/n*100,2) if n else None,
        'win_rate_95ci_pct':_wilson(w,n),'expectancy_pct':round(statistics.mean(rs),3) if n else None,
        'expectancy_95ci_pct':_mean_ci(rs),'median_return_pct':round(statistics.median(rs),3) if n else None,
        'avg_mfe_pct':round(statistics.mean(mfes),3) if mfes else None,'avg_mae_pct':round(statistics.mean(maes),3) if maes else None,
        'profit_factor':round(g/loss,3) if loss>0 else (999.0 if g>0 else None),'trade_mdd_pct':_mdd(rs) if n else None,
        'trade_sharpe':round(sharpe,3) if sharpe is not None else None,
        'hit_3_pct':round(sum(x>=3 for x in rs)/n*100,2) if n else None,
        'hit_5_pct':round(sum(x>=5 for x in rs)/n*100,2) if n else None,
        'hit_10_pct':round(sum(x>=10 for x in rs)/n*100,2) if n else None,
        'stop_minus3_pct':round(sum(x<=-3 for x in rs)/n*100,2) if n else None,
        'confidence':'HIGH' if n>=100 else 'MEDIUM' if n>=40 else 'LOW' if n>=10 else 'VERY_LOW'
    }

def _parse_day(x):
    d=str(x.get('day') or '')[:10].replace('-','')
    if len(d)==8:return d
    ts=_num(x.get('ts') or x.get('at_ts') or 0)
    if ts:return datetime.fromtimestamp(ts,KST).strftime('%Y%m%d')
    at=str(x.get('at') or x.get('entry_at') or '')
    try:return datetime.fromisoformat(at.replace('Z','+00:00')).astimezone(KST).strftime('%Y%m%d')
    except:return ''

def _load_buys(data_dir):
    rows=[]
    files=['buy_entry_events_v3.jsonl','buy_signals.jsonl.gz']
    for p in _iter_unique_files(data_dir,files):
        for x in _jsonl(p):
            if str(x.get('kind') or x.get('event') or '').upper() in ('BUY_CONFIRMED','BUY') or x.get('route'):
                rows.append(x)
    # stable de-dupe
    out=[];seen=set()
    for x in rows:
        k=str(x.get('id') or x.get('entry_id') or '') or f"{_parse_day(x)}:{x.get('code')}:{x.get('at')}:{x.get('route')}"
        if k in seen:continue
        seen.add(k);out.append(x)
    return out

def _load_exits(data_dir):
    rows=[]
    for p in data_dir.glob('exit_trace_*.jsonl'):rows+=_jsonl(p)
    arch=data_dir/'archive'
    if arch.exists():
        for p in arch.glob('20??????/exit_trace.jsonl.gz'):rows+=_jsonl(p)
    best={}
    for x in rows:
        k=str(x.get('id') or x.get('entry_id') or '')
        if not k:continue
        ts=_num(x.get('ts'));old=best.get(k)
        if old is None or ts>=_num(old.get('ts')):best[k]=x
    return best

def _load_exit_positions(data_dir):
    p=data_dir/'exit_position_state.json'
    try:
        raw=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
        if isinstance(raw,dict):return raw.get('positions',raw) if isinstance(raw.get('positions',raw),dict) else {}
    except:pass
    return {}


def _manual_outcomes(data_dir):
    rows=[]
    for p in _iter_unique_files(data_dir,['manual_position_events.jsonl','manual_position_events.jsonl.gz']):rows+=_jsonl(p)
    groups=defaultdict(list);seen=set()
    for x in rows:
        pid=str(x.get('position_id') or '')
        if not pid:continue
        key=(pid,str(x.get('event') or ''),str(x.get('at') or ''),str(x.get('price') or ''),str(x.get('sell_pct') or ''))
        if key in seen:continue
        seen.add(key);groups[pid].append(x)
    out=[]
    for pid,xs in groups.items():
        xs.sort(key=lambda x:_num(x.get('at')));buy=next((x for x in xs if x.get('event')=='MANUAL_BUY_START'),None)
        if not buy:continue
        entry=_num(buy.get('price'));sells=[x for x in xs if x.get('event')=='MANUAL_SELL_CONFIRMED' and _num(x.get('price'))>0 and _num(x.get('sell_pct'))>0]
        if entry<=0 or not sells:continue
        sold=sum(_num(x.get('sell_pct')) for x in sells);weighted=sum((_num(x.get('price'))/entry-1)*100*_num(x.get('sell_pct')) for x in sells)/max(sold,1)
        out.append({'id':pid,'day':_parse_day(buy),'route':'MANUAL_'+str(buy.get('style') or 'UNKNOWN'),'ret':weighted,'mfe':None,'mae':None,'manual':True,'sold_pct':round(sold,1),'outcome_status':'CLOSED' if sold>=99.9 else 'PARTIAL'})
    return out

def _joined(data_dir):
    buys=_load_buys(data_dir);ex=_load_exits(data_dir);pos=_load_exit_positions(data_dir);out=[]
    for b in buys:
        eid=str(b.get('id') or b.get('entry_id') or '')
        e=ex.get(eid) or pos.get(eid) or {}
        ret=e.get('ret',e.get('return_pct'))
        if ret is None:continue
        out.append({'id':eid,'day':_parse_day(b),'route':str(b.get('route') or e.get('route') or 'UNKNOWN'),'ret':_num(ret),'mfe':_num(e.get('mfe',e.get('max_return'))),'mae':_num(e.get('mae',e.get('min_return'))),'score':_num(b.get('score')),'rally_dna':bool((b.get('metrics') or {}).get('rally_dna_bonus',0)>0 or 'DNA' in str(b.get('route') or ''))})
    out.extend(_manual_outcomes(data_dir));out.sort(key=lambda x:(x['day'],x['id']))
    return out

def _period(rows,days):
    today=datetime.now(KST).date();cut=(today-timedelta(days=days-1)).strftime('%Y%m%d')
    xs=[x for x in rows if x.get('day','')>=cut]
    by=defaultdict(list)
    for x in xs:by[x['route']].append(x)
    allm=_metrics(xs)
    routes={k:_metrics(v) for k,v in sorted(by.items())}
    dna_on=[x for x in xs if x.get('rally_dna')];dna_off=[x for x in xs if not x.get('rally_dna')]
    return {'window_days':days,'all':allm,'routes':routes,'rally_dna_observed':{'on':_metrics(dna_on),'off':_metrics(dna_off),'note':'관찰 비교이며 인과효과 추정이 아님. 동일 점수/시간대 대조군은 백테스트에서 확인.'}}


def _load_replay(data_dir):
    rows=[]
    for p in list(data_dir.glob('replay_journal_*.jsonl')):
        rows+=_jsonl(p)
    arch=data_dir/'archive'
    if arch.exists():
        for p in arch.glob('20??????/replay_journal.jsonl.gz'):rows+=_jsonl(p)
    rows.sort(key=lambda x:_num(x.get('ts')))
    return rows

def _load_observations(data_dir):
    rows=[]
    for p in _iter_unique_files(data_dir,['prospective_observation_events.jsonl','prospective_observations.jsonl.gz']):rows+=_jsonl(p)
    out=[];seen=set()
    for x in rows:
        k=str(x.get('id') or '')
        if not k or k in seen:continue
        seen.add(k);out.append(x)
    out.sort(key=lambda x:_num(x.get('ts')))
    return out

def _prospective_audit(data_dir):
    obs=_load_observations(data_dir);replay=_load_replay(data_dir);by=defaultdict(list)
    for x in replay:by[(str(x.get('day') or ''),str(x.get('code') or ''),str(x.get('venue') or ''))].append(x)
    outcomes=[]
    for o in obs:
        p0=_num(o.get('price'));t0=_num(o.get('ts'));key=(str(o.get('day') or ''),str(o.get('code') or ''),str(o.get('venue') or 'NXT'))
        if p0<=0 or t0<=0:continue
        fut=[x for x in by.get(key,[]) if 0<_num(x.get('ts'))-t0<=1800 and _num(x.get('price'))>0]
        if not fut:continue
        prices=[_num(x.get('price')) for x in fut];last=fut[-1]
        outcomes.append({'id':o.get('id'),'stage':o.get('stage'),'mode':o.get('mode'),'day':o.get('day'),'code':o.get('code'),'detected_rate':_num(o.get('rate')),'catch_percentile':_num(o.get('nxt_catch_percentile')),'top1_target':bool(o.get('nxt_top1_target')),'mfe30':(max(prices)/p0-1)*100,'mae30':(min(prices)/p0-1)*100,'ret30':(_num(last.get('price'))/p0-1)*100})
    bystage=defaultdict(list)
    for x in outcomes:bystage[str(x.get('stage') or 'UNKNOWN')].append(x)
    stage_metrics={}
    for st,xs in sorted(bystage.items()):
        rets=[x['ret30'] for x in xs];mfes=[x['mfe30'] for x in xs];maes=[x['mae30'] for x in xs]
        stage_metrics[st]={'samples':len(xs),'avg_ret30_pct':round(statistics.mean(rets),3) if rets else None,'avg_mfe30_pct':round(statistics.mean(mfes),3) if mfes else None,'avg_mae30_pct':round(statistics.mean(maes),3) if maes else None,'mfe3_hit_pct':round(sum(x>=3 for x in mfes)/len(mfes)*100,2) if mfes else None,'mfe5_hit_pct':round(sum(x>=5 for x in mfes)/len(mfes)*100,2) if mfes else None,'detected_before_10pct_pct':round(sum(x['detected_rate']<10 for x in xs)/len(xs)*100,2) if xs else None}
    top1={'scope':'PROSPECTIVE_OBSERVATION_COVERED_UNIVERSE_ONLY','samples':len(outcomes),'min_oos_samples':TOP1_AUDIT_MIN_SAMPLES,'strong_oos_samples':TOP1_AUDIT_STRONG_SAMPLES,'status':'INSUFFICIENT_OOS' if len(outcomes)<TOP1_AUDIT_MIN_SAMPLES else 'PRELIMINARY' if len(outcomes)<TOP1_AUDIT_STRONG_SAMPLES else 'EVALUABLE','realized_top1_mfe30_threshold_pct':None,'realized_top1_count':None,'top1_target_alerts':sum(bool(x['top1_target']) for x in outcomes),'top1_target_precision_pct':None,'top1_target_hits':None,'warning':'시장 전체 상위 1% 성과를 증명하는 지표가 아닙니다. NOVA가 사전에 기록한 관찰표본 안에서만 계산하며 최소 300개 OOS 관찰 전에는 TOP1 precision을 공개하지 않습니다.'}
    if len(outcomes)>=TOP1_AUDIT_MIN_SAMPLES:
        vals=sorted(x['mfe30'] for x in outcomes);idx=max(0,min(len(vals)-1,math.ceil(len(vals)*.99)-1));thr=vals[idx];elite=[x for x in outcomes if x['mfe30']>=thr];flag=[x for x in outcomes if x['top1_target']]
        hit=[x for x in flag if x['mfe30']>=thr]
        top1.update({'realized_top1_mfe30_threshold_pct':round(thr,3),'realized_top1_count':len(elite),'top1_target_alerts':len(flag),'top1_target_precision_pct':round(len(hit)/len(flag)*100,2) if flag else None,'top1_target_hits':len(hit)})
    return {'samples':len(outcomes),'stages':stage_metrics,'top1_target_audit':top1,'anti_hindsight':'원본 prospective_observation line은 future_label/return 없이 append-only로 저장되고 결과는 별도 replay JOIN으로 계산'}

def build_report(data_dir:Path):
    data_dir=Path(data_dir);rows=_joined(data_dir)
    return {'version':'EVIDENCE_ENGINE_V2_PROSPECTIVE','generated_at':datetime.now(KST).isoformat(),'total_joined_samples':len(rows),'periods':{'week':_period(rows,7),'month':_period(rows,30)},'prospective':_prospective_audit(data_dir),'method':{'win_ci':'Wilson 95%','expectancy_ci':'normal-approx 95%','mdd':'chronological compounded trade-return drawdown','warning':'표본이 적은 경우 신뢰구간을 우선 해석. 자동 BUY는 최신 EOD/EXIT trace 기준이며 장중에는 중간 mark일 수 있음. MANUAL은 확인된 매도체결의 가중 실현수익. 라이브 파라미터 자동변경 없음.'}}

def write_report(data_dir:Path, output:Path|None=None):
    r=build_report(Path(data_dir));out=Path(output or Path(data_dir)/'evidence_report.json');out.parent.mkdir(parents=True,exist_ok=True)
    tmp=out.with_suffix(out.suffix+'.tmp');tmp.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(out);return r
