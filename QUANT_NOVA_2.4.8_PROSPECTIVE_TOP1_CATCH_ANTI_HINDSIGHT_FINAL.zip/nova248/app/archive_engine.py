from __future__ import annotations
import gzip, hashlib, json, shutil
from pathlib import Path

def _day_of(x):
    d=str(x.get('day') or x.get('date') or '')[:10].replace('-','')
    if len(d)==8:return d
    for k in ('at','generated_at','detected_at_kst','ts_kst'):
        s=str(x.get(k) or '')
        if len(s)>=10 and s[0:4].isdigit():return s[:10].replace('-','')
    return ''

def _gzip_jsonl_filtered(src:Path,dst:Path,day:str):
    if not src.exists():return 0
    dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_suffix(dst.suffix+'.tmp');n=0
    with src.open('r',encoding='utf-8',errors='ignore') as fin,gzip.open(tmp,'wt',encoding='utf-8',compresslevel=6) as fout:
        for line in fin:
            try:x=json.loads(line)
            except:continue
            if _day_of(x)==day:fout.write(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n');n+=1
    tmp.replace(dst);return n

def _gzip_copy(src:Path,dst:Path):
    if not src.exists():return 0
    dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_suffix(dst.suffix+'.tmp')
    with src.open('rb') as fin,gzip.open(tmp,'wb',compresslevel=6) as fout:shutil.copyfileobj(fin,fout)
    tmp.replace(dst);return sum(1 for _ in src.open('rb'))

def discover_days(data_dir:Path):
    data_dir=Path(data_dir);days=set()
    for p in data_dir.glob('*_20??????.jsonl'):
        d=p.stem[-8:]
        if d.isdigit():days.add(d)
    scan=['buy_entry_events_v3.jsonl','rally_dna_samples.jsonl','exit_dna_samples.jsonl','exit_actions.jsonl','manual_position_events.jsonl','market_events.jsonl','push_delivery_events.jsonl','prospective_observation_events.jsonl']
    for name in scan:
        p=data_dir/name
        if not p.exists():continue
        try:
            with p.open('r',encoding='utf-8',errors='ignore') as f:
                for line in f:
                    try:d=_day_of(json.loads(line))
                    except:continue
                    if len(d)==8:days.add(d)
        except:pass
    return sorted(days)

def archive_day(data_dir:Path,day:str):
    data_dir=Path(data_dir);out=data_dir/'archive'/day;manifest_path=out/'manifest.json'
    if manifest_path.exists():
        try:return json.loads(manifest_path.read_text(encoding='utf-8'))
        except:pass
    out.mkdir(parents=True,exist_ok=True)
    mapping={
      'buy_entry_events_v3.jsonl':'buy_signals.jsonl.gz','rally_dna_samples.jsonl':'rally_samples.jsonl.gz','exit_dna_samples.jsonl':'exit_samples.jsonl.gz',
      'exit_actions.jsonl':'exit_actions.jsonl.gz','manual_position_events.jsonl':'manual_position_events.jsonl.gz','market_events.jsonl':'market_events.jsonl.gz','push_delivery_events.jsonl':'push_delivery_events.jsonl.gz','prospective_observation_events.jsonl':'prospective_observations.jsonl.gz'}
    counts={}
    for src,dst in mapping.items():counts[dst]=_gzip_jsonl_filtered(data_dir/src,out/dst,day)
    for prefix,dst in [('rally_trace_','rally_trace.jsonl.gz'),('exit_trace_','exit_trace.jsonl.gz'),('replay_journal_','replay_journal.jsonl.gz')]:
        counts[dst]=_gzip_copy(data_dir/f'{prefix}{day}.jsonl',out/dst)
    manifest={'day':day,'sealed':True,'files':{},'lossless_policy':'archive is immutable daily evidence copy; live hot files may compact independently'}
    for p in out.glob('*.gz'):
        manifest['files'][p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':counts.get(p.name,0)}
    tmp=out/'manifest.json.tmp';tmp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(out/'manifest.json')
    return manifest
