import sys,time,os,tempfile,shutil,atexit
from pathlib import Path
_TEST_DATA=Path(tempfile.mkdtemp(prefix='nova-selfcheck-'))
os.environ['NOVA_DATA_DIR']=str(_TEST_DATA)
atexit.register(lambda: shutil.rmtree(_TEST_DATA,ignore_errors=True))
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from app import main as m

assert m.APP_VERSION == 'NOVA-2.4.8'
assert m.is_krx_trading_day('20260810') is True
assert m.is_krx_trading_day('20260817') is False
assert m._next_effective_day('20260814') == '20260818'
assert '2026' in m._load_krx_calendar().get('covered_years',[])
assert m.venue_from_fid9081('KRX')=='KRX' and m.venue_from_fid9081('NXT')=='NXT'
assert m.venue_from_fid9081('')=='UNKNOWN' and m.venue_from_fid9081('foo')=='UNKNOWN'

# Order-only changes must not create registry churn. Registry now includes realtime orderbook as a separate set.
empty=m.registry_diff({'005930','000660'},{'005930'},{'000660'}, {'005930','000660'}, {'000660','005930'}, {'005930'}, {'000660'})
assert empty == [], empty
plan=m.registry_diff({'005930','000660'},{'000660'},{'000660'}, {'005930','000660'}, {'005930','000660'}, {'005930'}, {'000660'})
assert plan == [('REMOVE','PROGRAM',frozenset({'005930'})),('REG','PROGRAM',frozenset({'000660'}))], plan
reg=m._registry_packet('REG','410',['005930'],'0B');rem=m._registry_packet('REMOVE','410',['005930'],'0B')
assert reg['refresh']=='1' and 'refresh' not in rem

# Duplicate and price-spike quarantine.
c=m.Candidate('005930');now=time.time()
ok,_=m.tick_integrity_check(c,now=now,price=100,qty=10,rate=1,venue='KRX',cumvol=1000,turnover=100000,trade_time='090001');assert ok
c.last_price=100;c.last_tick_at=now;c.rate=1
ok,why=m.tick_integrity_check(c,now=now+.1,price=100,qty=10,rate=1,venue='KRX',cumvol=1000,turnover=100000,trade_time='090001');assert not ok and why=='DUPLICATE'
ok,why=m.tick_integrity_check(c,now=now+.2,price=115,qty=10,rate=16,venue='KRX',cumvol=1010,turnover=101150,trade_time='090002');assert not ok and why=='PRICE_QUARANTINE'
ok,why=m.tick_integrity_check(c,now=now+.3,price=114.9,qty=11,rate=15.9,venue='KRX',cumvol=1021,turnover=102414,trade_time='090003');assert ok

# A corroborated NXT after-market price jump must not be misclassified as a bad tick.
q=m.Candidate('111111');q.last_price=100;q.last_tick_at=now;q.rate=1;q.last_cumvol_by_venue['NXT']=1000;q.last_turnover_by_venue['NXT']=100000;q.last_trade_time_by_venue['NXT']='154400'
old_nxt=m.nxt_after_session_active;m.nxt_after_session_active=lambda:True
ok,why=m.tick_integrity_check(q,now=now+.1,price=115,qty=10,rate=16,venue='NXT',cumvol=1010,turnover=101150,trade_time='154401')
m.nxt_after_session_active=old_nxt
assert ok and why=='OK', (ok,why)

# Realtime orderbook needs two snapshots and stays bounded.
o=m.Candidate('000660')
v1={str(k):100 for k in range(61,81)}
v2={**{str(k):70 for k in range(61,71)},**{str(k):140 for k in range(71,81)}}
assert m.parse_orderbook(o,v1,now)
assert m.parse_orderbook(o,v2,now+.1)
assert o.orderbook_samples==2 and -m.ORDERBOOK_MAX_BONUS <= o.metrics['orderbook_presignal'] <= m.ORDERBOOK_MAX_BONUS
# KRX/NXT orderbook baselines are isolated: first NXT book never compares against a prior KRX book.
ov=m.Candidate('123456')
assert m.parse_orderbook(ov,v1,now,'KRX')
assert m.parse_orderbook(ov,v2,now+.1,'NXT')
assert ov.orderbook_samples_by_venue.get('KRX')==1 and ov.orderbook_samples_by_venue.get('NXT')==1
assert float(ov.metrics.get('nxt_orderbook_presignal'))==0.0
assert ov.orderbook_prev_by_venue['KRX'] != ov.orderbook_prev_by_venue['NXT']

# New WS symbol must NOT fabricate the old ~1.54 volume acceleration bonus.
v=m.Candidate('035420');v.last_tick_at=now;v.last_price=100;v.rate=1
for i in range(6):v.ticks.append(m.Tick(now-10+i,100+i*.1,10,1,'KRX',100+i*10,10000+i*1000))
old_session=m.market_session
m.market_session=lambda:{'active':True,'krx':True,'nxt':False}
m.calc(v)
m.market_session=old_session
assert v.metrics.get('volume_accel_ready') is False and float(v.metrics.get('volume_accel'))==1.0

# ETF/ETN ordinary-equity universe filter.
assert m.is_fund_like_name('KODEX 200') and m.is_fund_like_name('ABC ETN') and not m.is_fund_like_name('삼성전자')

# Stale smart-money fields are UNKNOWN in learning vectors.
s=m.Candidate('000660');s.smart={'program_net':100,'program_buy':200,'program_sell':100,'trust_net':100,'institution_net':100,'foreign_net':0,'program_delta':50,'trust_delta':50}
fv=m.feature_vector(s);rv=m.rally_vector(s)
assert fv['program']==0 and fv['trust']==0 and rv['program_delta']==0 and rv['trust_delta']==0

# Contract probe defaults and event pipeline are fail-safe when no external feed is configured.
ct=m.load_ws_contract();assert ct['trade_type']=='0B' and ct['program_type']=='0w' and ct['orderbook_type']=='0D' and ct['source']=='OFFICIAL_FIXED_CONTRACT'
import inspect
assert 'ka90004' in inspect.getsource(m._refresh_program_rest_cache) and 'ka90003' not in inspect.getsource(m._refresh_program_rest_cache)
assert "c.code+'_NX' if venue=='NXT'" in inspect.getsource(m.poll_investor)

# NXT-after source contract and radar scoring are present without weakening normal-day rules.
assert all(str(t[0]).startswith('nxt_') and t[2].get('stex_tp')=='2' for t in m.NXT_AFTER_RANK_SPECS)
n=m.Candidate('000001','TEST');n.last_price=103;n.rate=3.0;n.score=66;n.last_price_by_venue['NXT']=103;n.last_rate_by_venue['NXT']=3.0;n.last_tick_at_by_venue['NXT']=time.time()
n.source_hits={'nxt_volume_surge:001':25,'nxt_bid_surge:001':20,'nxt_turnover_top:001':15}
n.metrics.update({'nxt_radar_hits':list(n.source_hits),'nxt_radar_count':3,'nxt_radar_score':70,'nxt_takeover_score':65,'buy_pressure':60,'micro_breakout':.2})
old_nxt=m.nxt_after_session_active;m.nxt_after_session_active=lambda:True
old_rad=m.nxt_radar_session_active;m.nxt_radar_session_active=lambda:True
m.evaluate_nxt_radar_alerts([n]);m.nxt_radar_session_active=old_rad;m.nxt_after_session_active=old_nxt
assert n.nxt_alert_stage in ('IGNITION','PRE_IGNITION') and len(m.STATE.nxt_alerts)>=1
# Second-wave feature contract and burst-watch configuration.
assert m.NXT_FASTEST_DISCOVERY_SECONDS <= m.NXT_AFTER_DISCOVERY_SECONDS
assert m.NXT_BURST_WATCH_LIMIT == 20
assert m.NXT_SECOND_WAVE_MIN_PULLBACK < m.NXT_SECOND_WAVE_MAX_PULLBACK
assert m.NXT_SECOND_WAVE_MEMORY_SECONDS>=5*3600 and m.NXT_MEMORY_BAR_KEEP_MINUTES>=300 and m.NXT_RECOVERY_MAX_PEAK_AGE_SECONDS>=5*3600
# Morning close-pick store is a stable dict and API source file is configured.
assert isinstance(m.STATE.next_day_picks,dict) and m.NXT_NEXT_DAY_PICK_FILE.name.endswith('.json')
mg=m.build_nxt_signal_management(); assert mg.get('ok') is True and 'rows' in mg and 'counts' in mg
# CPU/DISK guard contracts.
assert m.SCORING_COALESCE_MS == 80
assert m.PERSIST_INTERVAL_SECONDS == 60
assert m.OP_LOG_MAX_MB >= 8
assert hasattr(m.STATE,'score_dirty_codes') and callable(m.mark_score_dirty) and callable(m.score_codes)
assert callable(m.performance_guard_status) and callable(m._disk_guard_scan)
# Dirty scoring must only consume explicitly dirty symbols; full scoring remains available for discovery refreshes.
a=m.Candidate('700001','A');b=m.Candidate('700002','B');m.STATE.candidates[a.code]=a;m.STATE.candidates[b.code]=b
m.mark_score_dirty(a.code);assert a.code in m.STATE.score_dirty_codes and b.code not in m.STATE.score_dirty_codes
# NXT FAST gets higher REST priority than smart/normal discovery.
assert 'nxt_radar(-10)' in m.REST_PACER.status().get('priority','')
# 2.4.6 keeps all-day NXT + venue-truth flow + long recovery + 19:30~19:50 close window + venue-aware exits.
assert m.NXT_ALLDAY_DISCOVERY_SECONDS <= m.DISCOVERY_SECONDS
assert m.NXT_ALLDAY_INTEGRATED_EVERY >= 2
assert m.NXT_BURST_HIGHRES_LIMIT >= 3
assert 'as_completed' in m.discovery_loop.__code__.co_names
assert 'wait' in m.nxt_fast_radar_loop.__code__.co_names and 'gather' in m.nxt_fast_radar_loop.__code__.co_names
assert m.NXT_FAST_REST_TIMEOUT < m.NXT_ALLDAY_DISCOVERY_SECONDS
# Streamed NXT source should promote a high-value new entrant before the cycle barrier.
import asyncio
async def _stream_test():
    m.STATE.candidates.pop('723456',None);m.STATE.burst_watch.pop('723456',None)
    res=('nxt_volume_surge:001','nxt_volume_surge','001',True,[{'stk_cd':'723456','stk_nm':'STREAM','cur_prc':'10300','flu_rt':'3.0'}],{},None)
    ok,key,codes=await m._apply_streamed_rank_result(res,991)
    assert ok and '723456' in codes and '723456' in m.STATE.burst_watch
    assert '723456' in m.STATE.ws_codes and '723456' in m.STATE.burst_highres_codes
asyncio.run(_stream_test())

# BURST-HR must actually receive program + orderbook targets, with hard 40-code caps.
m.STATE.ws_codes=['810001','810002','810003'];m.STATE.core_codes=['810001'];m.STATE.challenger_codes=['810003'];m.STATE.burst_highres_codes=['810002']
tt,pt,ot=m.build_realtime_targets();assert '810002' in pt and '810002' in ot and len(pt)<=40 and len(ot)<=40
# WS emergency must not require any REST radar hit.
e=m.Candidate('723457','EMERGENCY');e.last_price=104;e.rate=4.0;e.last_tick_at=time.time();e.last_fid9081='NXT';e.last_tick_at_by_venue['NXT']=time.time();e.last_price_by_venue['NXT']=104;e.last_rate_by_venue['NXT']=4.0
e.metrics.update({'nxt_volume_accel_30s':2.5,'nxt_volume_accel_60s':1.9,'nxt_buy_pressure':66,'nxt_algo_persistence':70,'nxt_orderbook_presignal':1.0,'nxt_orderbook_verified':True,'nxt_micro_breakout':0.2,'nxt_impulse_60s':0.5,'nxt_one_tick_ratio':0.2,'nxt_tick_count_60s':20,'nxt_radar_count':0})
old_rad=m.nxt_radar_session_active;m.nxt_radar_session_active=lambda:True
assert m.evaluate_ws_emergency_ignition(e) is True and e.nxt_alert_stage=='EMERGENCY_IGNITION'
m.nxt_radar_session_active=old_rad
assert hasattr(m.STATE,'nxt_first_wave_memory')
assert hasattr(m.STATE,'nxt_daily_ledger')
assert callable(m.nxt_second_wave_memory_codes)
assert callable(m.update_nxt_memory_tick)
# Selective alert/push and daily-stage dedupe: EARLY is recorded without push eligibility, PRE upgrades immediately.
z=m.Candidate('733001','ALERT');z.last_price=101;z.rate=1.0;z.last_price_by_venue['NXT']=101;z.last_rate_by_venue['NXT']=1.0;z.last_tick_at_by_venue['NXT']=time.time()
assert m.emit_nxt_alert(z,'EARLY_WATCH',['early']) is True
assert m.STATE.nxt_alerts[-1].get('push_eligible') is False
# Simulate Candidate recreation; ledger must suppress duplicate EARLY but allow higher PRE immediately.
z2=m.Candidate('733001','ALERT');z2.last_price=102;z2.rate=2.0;z2.last_price_by_venue['NXT']=102;z2.last_rate_by_venue['NXT']=2.0;z2.last_tick_at_by_venue['NXT']=time.time()
assert m.emit_nxt_alert(z2,'EARLY_WATCH',['duplicate']) is False
assert m.emit_nxt_alert(z2,'PRE_IGNITION',['upgrade']) is True
assert m.STATE.nxt_alerts[-1].get('push_eligible') is True
assert m.ENTRY_MAX_DAILY == 2
assert m.PULLBACK_CONFIRM_SCORE == 58 and m.PULLBACK_CONFIRM_BUY_PRESSURE == 58 and abs(m.PULLBACK_CONFIRM_ACCEL-1.20)<1e-9
assert {'FAST_JUMP_WATCH','FAST_JUMP_READY','RECOVERY_EARLY','RECOVERY_READY','RECOVERY_BUY','SECOND_WAVE_READY','SECOND_WAVE_BUY'}.issubset(m.NXT_PUSH_STAGES)
# Complete day rollover: yesterday's count/stages/entry state cannot block the new session.
rr=m.Candidate('744001','ROLLOVER');rr.signal_count_today=2;rr.nxt_alert_stage='IGNITION';rr.nxt_second_wave_alert_stage='SECOND_WAVE_BUY';rr.entry_state='BUY';rr.last_buy_at=time.time();rr.source_hits={'nxt_volume_surge:001':20};rr.ticks.append(m.Tick(time.time(),100,1,1,'NXT'))
m.STATE.candidates[rr.code]=rr;m.STATE.active_day='20260810';old_today=m.today_kst;m.today_kst=lambda:'20260811';assert m.ensure_daily_rollover() is True;m.today_kst=old_today
assert rr.signal_count_today==0 and rr.nxt_alert_stage=='' and rr.nxt_second_wave_alert_stage=='' and rr.nxt_fast_jump_alert_stage=='' and rr.entry_state=='DISCOVERY' and len(rr.ticks)==0 and not rr.source_hits

# Manual position manager: actual price + venue lock + NORMAL/STRONG/ELITE adaptive profit modes.
assert m._manual_plan('SCALP','NORMAL')['tp1']==3.0 and m._manual_plan('SCALP','NORMAL')['runner_pct']==40
assert m._manual_plan('SCALP','STRONG')['runner_pct']==50 and m._manual_plan('SCALP','ELITE')['runner_pct']==60
assert m._manual_plan('SWING','NORMAL')['tp1']==8.0 and m._manual_plan('SWING','NORMAL')['runner_pct']==50
assert m._manual_plan('SWING','ELITE')['runner_pct']==65
assert m._manual_protect_floor('SWING',10)==5.0 and m._manual_protect_floor('SWING',20)==12.0 and m._manual_protect_floor('SWING',35)==20.0
assert m._manual_protect_floor('SWING',12,'ELITE')==4.0 and m._manual_protect_floor('SWING',22,'ELITE')==10.0 and m._manual_protect_floor('SWING',35,'ELITE')==18.0
assert m._manual_protect_floor('CLOSE_BET',22,'ELITE')==10.0
mc=m.Candidate('755001','MANUAL');now2=time.time();mc.last_price=103.2;mc.last_tick_at=now2;mc.venue='KRX';mc.last_price_by_venue={'KRX':103.2,'NXT':104.5};mc.last_rate_by_venue={'KRX':3.2,'NXT':4.5};mc.last_tick_at_by_venue={'KRX':now2,'NXT':now2};mc.last_fid9081_by_venue={'KRX':'KRX','NXT':'NXT'};mc.metrics.update({'range5_pct':1.0,'buy_pressure':60,'algo_persistence':60,'micro_vwap_gap':0.2,'impulse_60s':0.2,'volume_accel':1.2});m.STATE.candidates[mc.code]=mc
pid='MANUAL:755001:1';m.STATE.manual_positions[pid]={'position_id':pid,'code':mc.code,'name':mc.name,'style':'SCALP','status':'OPEN','entry_at':now2-60,'entry_price':100,'entry_venue':'KRX','profit_mode':'NORMAL','initial_qty':100,'remaining_pct':100.0,'sold_pct':0.0,'tp1_done':False,'tp2_done':False,'sales':[],'mfe':0.0,'mae':0.0,'signal':'HOLD','notified_signals':[],'range5_at_entry':1.0}
m.update_manual_positions_for_candidate(mc);mp=m.STATE.manual_positions[pid];assert mp['signal']=='SELL_1' and mp['suggested_sell_pct']==30.0 and abs(mp['current_price']-103.2)<1e-9
# NXT venue lock must ignore newer/different KRX last_price.
mp['signal']='HOLD';mp['tp1_done']=False;mp['entry_venue']='NXT';mc.last_price=99.0;m.update_manual_positions_for_candidate(mc);assert abs(mp['current_price']-104.5)<1e-9
payload=m.manual_position_payload();assert payload['ok'] and payload['open_count']>=1 and payload['plans']['SWING']['NORMAL']['hard_stop']==-6.0
assert m.MANUAL_POSITION_FILE.name=='manual_position_manager.json' and m.MANUAL_POSITION_EVENT_FILE.name.endswith('.jsonl')
# ELITE classification requires exceptional live quality and retains a larger runner.
el=m.Candidate('755002','ELITE');el.score=85;el.nxt_alert_stage='EMERGENCY_IGNITION';el.metrics.update({'buy_pressure':67,'volume_accel':1.8,'nxt_volume_accel_30s':2.3,'rally_dna_match':92,'nxt_radar_score':78,'orderbook_presignal':1.0});assert m._manual_profit_mode(el,'SCALP','EMERGENCY_IGNITION')=='ELITE'
print('SELF_CHECK_CORE=PASS')


# 2.4.6 source-level guards.
assert 'nxt_buy_pressure' in m.update_nxt_second_wave_features.__code__.co_consts and 'nxt_orderbook_presignal' in m.update_nxt_second_wave_features.__code__.co_consts
assert m.WS_WAKE_GUARD_SECONDS>=5 and m.WS_WAKE_START_SECONDS==7*3600+30*60 and m.WS_PREOPEN_RECONNECT_SECONDS==7*3600+55*60

# 2.4.6 data-truth regression: KRX/NXT smart flow never overwrites each other.
flow=m.Candidate('744001','FLOW')
m._apply_program_values(flow,'KRX',100,80,20,realtime=True,source='0w')
m._apply_program_values(flow,'NXT',220,100,120,realtime=True,source='0w')
assert m._venue_smart(flow,'KRX')['program_net']==20 and m._venue_smart(flow,'NXT')['program_net']==120
assert flow.program_rt_at_by_venue.get('KRX') and flow.program_rt_at_by_venue.get('NXT')
# NXT BUY route must freeze NXT price even if the latest generic tick is KRX.
buy=m.Candidate('744002','VENUEBUY');buy.last_price=100;buy.rate=1;buy.venue='KRX';buy.last_fid9081='KRX';buy.last_price_by_venue={'KRX':100,'NXT':103};buy.last_rate_by_venue={'KRX':1,'NXT':3};buy.last_fid9081_by_venue={'KRX':'KRX','NXT':'NXT'};buy.score=82;buy.reasons=['NXT truth']
m.STATE.candidates[buy.code]=buy
assert m.record_buy_signal(buy,'BUY','NXT_SECOND_WAVE_BASE') is True
assert buy.last_signal_price==103 and buy.last_signal_venue=='NXT'
assert m.STATE.exit_positions[buy.last_buy_entry_id]['entry_venue']=='NXT'
buy.last_price=110;buy.last_price_by_venue['KRX']=110;buy.last_price_by_venue['NXT']=104;m.update_buy_signal_performance(buy);assert buy.signal_max_price==104
# Close-bet is a distinct overnight style, not subject to the SCALP 19:50 forced-exit branch.
assert m._manual_plan('CLOSE_BET','NORMAL')['style']=='CLOSE_BET' and 'CLOSE_BET_SIGNAL' in m.NXT_PUSH_STAGES
assert m.NXT_CLOSE_BET_WINDOW_START_SECONDS==19*3600+30*60 and m.NXT_CLOSE_BET_WINDOW_END_SECONDS==19*3600+50*60
assert m.NXT_CLOSE_BET_READY_HOLD_SECONDS==45 and m.NXT_CLOSE_BET_BUY_HOLD_SECONDS==90
# Official REST contract regression: ka90004 is queried once per KOSPI/KOSDAQ market with venue stex_tp, then cached by code.
async def _official_rest_contract_test():
    calls=[]
    old_post=m.kiwoom_post
    async def fake_post(path,api_id,body,**kw):
        calls.append((path,api_id,dict(body)))
        return 200,{'return_code':0,'return_msg':'OK','stk_prm_trde_prst':[{'stk_cd':'A955001','buy_cntr_amt':'500','sel_cntr_amt':'200','netprps_prica':'300'}]}
    m.kiwoom_post=fake_post
    try:
        m.STATE.program_rest_cache['NXT']={};m.STATE.program_rest_cache_at['NXT']=0
        cache=await m._refresh_program_rest_cache('NXT',True)
        assert '955001' in cache
        assert len(calls)==2 and all(x[1]=='ka90004' and x[2].get('stex_tp')=='2' for x in calls)
        assert {x[2].get('mrkt_tp') for x in calls}=={'P00101','P10102'}
    finally:m.kiwoom_post=old_post
asyncio.run(_official_rest_contract_test())

# NXT investor REST must use the exchange-qualified _NX code.
async def _investor_nx_test():
    calls=[];old_post=m.kiwoom_post;old_rad=m.nxt_radar_session_active
    async def fake_post(path,api_id,body,**kw):
        calls.append((api_id,dict(body)))
        return 200,{'return_code':0,'return_msg':'OK','stk_invsr_orgn':[{'orgn':'200','invtrt':'100','penfnd_etc':'50','frgnr_invsr':'80'}]}
    m.kiwoom_post=fake_post;m.nxt_radar_session_active=lambda:True
    try:
        cc=m.Candidate('955002','NXINV');cc.metrics['nxt_seen']=True
        await m.poll_investor(cc)
        assert any(api=='ka10059' and body.get('stk_cd')=='955002_NX' for api,body in calls)
        assert m._venue_smart(cc,'NXT').get('institution_net')==200
    finally:m.kiwoom_post=old_post;m.nxt_radar_session_active=old_rad
asyncio.run(_investor_nx_test())

# 19:30~19:50 engine is persistence-based: no one-shot BUY, READY/BUY upgrades after sustained NXT strength.
close=m.Candidate('955003','CLOSE');now3=time.time();close.last_price_by_venue['NXT']=100;close.last_rate_by_venue['NXT']=5;close.last_tick_at_by_venue['NXT']=now3
close.metrics.update({'nxt_radar_score':80,'nxt_takeover_score':75,'nxt_volume_accel_30s':2.0,'nxt_volume_accel_60s':1.6,'nxt_buy_pressure':68,'nxt_orderbook_presignal':2.0,'nxt_big_buy_count_60s':3,'nxt_big_buy_notional_60s':350000000,'nxt_second_wave_state':'SECOND_WAVE_READY'})
m._apply_program_values(close,'NXT',500,200,300,realtime=True,source='0w');m._apply_investor_row(close,'NXT',{'orgn':'200','invtrt':'100','penfnd_etc':'50','frgnr_invsr':'80'});m.STATE.candidates[close.code]=close
mi=int(now3//60);m.STATE.nxt_first_wave_memory[close.code]={'day':m.today_kst(),'bars':[{'minute':mi-i,'high':100,'low':99,'close':100,'volume':1000} for i in range(10)]+[{'minute':mi-i,'high':98,'low':97,'close':98,'volume':500} for i in range(10,40)]}
m.STATE.nxt_daily_ledger={'day':m.today_kst(),'rows':{close.code:{'name':'CLOSE','sector':'TEST','peak_rate':8,'peak_price':103,'max_radar':80,'max_takeover':75,'last_price':100,'last_rate':5,'last_tick_at':now3,'stages':['IGNITION']}}}
close_rows=m.build_next_day_close_picks(close_signal=True);assert close_rows and close_rows[0]['close_bet_signal']=='WATCH'
m.STATE.next_day_picks['rows'][0]['close_strong_since']=time.time()-m.NXT_CLOSE_BET_BUY_HOLD_SECONDS-2;m.STATE.next_day_picks['rows'][0]['close_strong_samples']=8
close.last_tick_at_by_venue['NXT']=time.time();close_rows=m.build_next_day_close_picks(close_signal=True);assert close_rows and close_rows[0]['close_bet_signal']=='CLOSE_BUY' and close_rows[0]['nxt_program_fresh'] is True and close_rows[0]['close_strong_hold_sec']>=m.NXT_CLOSE_BET_BUY_HOLD_SECONDS
assert m.emit_close_bet_candidate_alert(close_rows[0]) is True and m.STATE.nxt_alerts[-1]['stage']=='CLOSE_BET_BUY'

# Daehwa-like late recovery regression: +first wave -> 4~15% deep shakeout -> >68% reclaim must surface as RECOVERY_BUY with NXT-only flow.
rc=m.Candidate('955004','RECOVERY');nr=time.time();rc.score=86;rc.metrics.update({'nxt_seen':True,'nxt_buy_pressure':64,'nxt_algo_persistence':66,'nxt_micro_vwap_gap':0.25,'nxt_impulse_60s':0.45,'nxt_orderbook_presignal':0.8,'nxt_big_buy_count_60s':2,'nxt_one_tick_ratio':0.18})
rc.last_price_by_venue['NXT']=109.6;rc.last_rate_by_venue['NXT']=15.3;rc.last_tick_at_by_venue['NXT']=nr;rc.last_fid9081_by_venue['NXT']='NXT';rc.last_price=109.6;rc.rate=15.3;rc.venue='NXT'
# Old baseline trades are small; last 30/60s trades accelerate.
for age,qty,pr in [(140,100,106),(120,100,106.2),(100,100,106.5),(80,100,107),(65,100,107.2),(50,100,108),(40,100,108.3),(25,500,108.8),(18,500,109),(12,500,109.2),(6,500,109.4),(1,500,109.6)]:rc.ticks.append(m.Tick(nr-age,pr,qty,15.3,'NXT'))
minr=int(nr//60);peak_at=nr-4*3600;trough_at=nr-55*60
bars=[]
for i in range(250,-1,-1):
    minute=minr-i;price=108.0
    bars.append({'minute':minute,'open':price,'high':price+0.2,'low':price-0.2,'close':price,'volume':500,'ticks':2,'rate':8})
# Force historical peak ~4h ago and trough ~55m ago; current price has reclaimed ~76% of the loss.
for b in bars:
    if abs(b['minute']-int(peak_at//60))<=1:b.update({'high':112.0,'low':111.5,'close':112.0,'rate':17})
    if abs(b['minute']-int(trough_at//60))<=1:b.update({'high':102.5,'low':102.0,'close':102.3,'rate':7})
bars[-1].update({'high':109.7,'low':109.0,'close':109.6,'volume':3000,'rate':15.3})
m.STATE.nxt_first_wave_memory[rc.code]={'day':m.today_kst(),'code':rc.code,'name':rc.name,'first_wave_at':peak_at-60,'peak_at':peak_at,'peak_price':112.0,'peak_rate':17.0,'last_price':109.6,'last_rate':15.3,'last_tick_at':nr,'expires_at':nr+3600,'bars':bars}
m.STATE.candidates[rc.code]=rc
m.update_nxt_second_wave_features(rc,nr)
assert rc.metrics.get('nxt_recovery_state')=='RECOVERY_BUY',rc.metrics
assert 8.0<=float(rc.metrics.get('nxt_recovery_drawdown_pct'))<=10.0 and float(rc.metrics.get('nxt_recovery_ratio'))>=0.68
old_rad2=m.nxt_radar_session_active;m.nxt_radar_session_active=lambda:True
try:
    m.advance_nxt_recovery(rc,{'active':True,'nxt':True},0)
finally:m.nxt_radar_session_active=old_rad2
assert any(x.get('code')==rc.code and x.get('stage')=='RECOVERY_BUY' for x in m.STATE.nxt_alerts)

# CLOSE_BET ELITE 65% runner must actually execute its 9% trailing branch after TP2.
cb=m.Candidate('955005','CLOSE-RUNNER');nc=time.time();cb.last_price=124;cb.last_tick_at=nc;cb.last_price_by_venue['NXT']=124;cb.last_rate_by_venue['NXT']=24;cb.last_tick_at_by_venue['NXT']=nc;cb.last_fid9081_by_venue['NXT']='NXT';cb.metrics.update({'nxt_buy_pressure':60,'nxt_algo_persistence':60,'nxt_micro_vwap_gap':0.1,'nxt_impulse_60s':0.0,'nxt_orderbook_presignal':0.0});m.STATE.candidates[cb.code]=cb
cbid='MANUAL:955005:1';m.STATE.manual_positions[cbid]={'position_id':cbid,'code':cb.code,'name':cb.name,'style':'CLOSE_BET','status':'OPEN','entry_at':nc-3600,'entry_price':100,'entry_venue':'NXT','profit_mode':'ELITE','initial_qty':100,'remaining_pct':65.0,'sold_pct':35.0,'tp1_done':True,'tp2_done':True,'sales':[],'mfe':35.0,'mae':0.0,'signal':'HOLD','notified_signals':[],'range5_at_entry':1.0}
m.update_manual_positions_for_candidate(cb);assert m.STATE.manual_positions[cbid]['signal']=='RUNNER_TRAIL_EXIT' and abs(float(m.STATE.manual_positions[cbid]['trail_floor_pct'])-26.0)<1e-9

# Automatic EXIT-DNA ELITE base curve is distinct from the runner trail.
assert m._auto_exit_protect_floor(12,'ELITE')==4.0 and m._auto_exit_protect_floor(22,'ELITE')==10.0 and m._auto_exit_protect_floor(35,'ELITE')==18.0
assert m._auto_exit_runner_trail_floor(22,'ELITE')==13.0 and m._auto_exit_runner_trail_floor(35,'ELITE')==26.0 and m._auto_exit_runner_trail_floor(35,'NORMAL') is None

# Push lifecycle separates scheduling from successful delivery.
rec={'id':'selfcheck-push','event':'NXT_CLOSE_BET_SIGNAL','stage':'CLOSE_BET_SIGNAL','code':'NXT','day':m.today_kst(),'title':'x','body':'x','at':time.time()}
assert m._persist_nxt_alert_record(rec) is True and rec.get('push_eligible') is True and rec.get('push_sent') is False


# 2.4.6 final venue-lock regressions.
vl=m.Candidate('966001','VLOCK');n=time.time();vl.last_price=120;vl.venue='KRX';vl.last_price_by_venue={'KRX':120,'NXT':101};vl.last_rate_by_venue={'KRX':20,'NXT':1};vl.last_tick_at_by_venue={'KRX':n,'NXT':n};vl.last_fid9081_by_venue={'KRX':'KRX','NXT':'NXT'}
# Populate deliberately opposite KRX/NXT microflow; NXT table/EXIT must read NXT only.
vl.metrics.update({'krx_buy_pressure':90,'krx_algo_persistence':90,'krx_impulse_60s':4,'krx_micro_breakout':2,'krx_micro_vwap_gap':3,'krx_volume_accel':3,'krx_volume_accel_ready':True,'krx_orderbook_presignal':5,'nxt_buy_pressure':55,'nxt_algo_persistence':54,'nxt_impulse_60s':0.1,'nxt_micro_breakout':0.05,'nxt_micro_vwap_gap':0.1,'nxt_volume_accel':1.1,'nxt_volume_accel_ready':True,'nxt_orderbook_presignal':-0.5,'nxt_radar_score':61,'nxt_takeover_score':58})
m._apply_program_values(vl,'KRX',1000,100,900,realtime=True,source='0w');m._apply_program_values(vl,'NXT',100,90,10,realtime=True,source='0w')
assert m.venue_flow_snapshot(vl,'NXT')['buy_pressure']==55 and m.venue_flow_snapshot(vl,'KRX')['buy_pressure']==90
pos={'entry_venue':'NXT','entry_venue_strength':m.venue_exit_strength(vl,'NXT'),'entry_score':80,'mfe':2,'current_return':1}
vec=m.exit_vector(vl,pos);assert vec['buy_pressure_fade']>0 and vec['vwap_break']==0
# NXT management BUY confirmation cannot borrow a KRX BUY.
vl.signal_count_today=1;vl.last_signal_at=n;vl.last_signal_venue='KRX';vl.last_signal_price=120;vl.nxt_alert_stage='PRE_IGNITION';m.STATE.candidates[vl.code]=vl
m.STATE.nxt_alerts.append({'day':m.today_kst(),'code':vl.code,'name':vl.name,'stage':'PRE_IGNITION','at':n-1,'at_kst':m.now_kst(),'price':101,'change_rate':1,'nxt_radar_score':61,'nxt_takeover_score':58,'reasons':['NXT only']})
mg=m.build_nxt_signal_management();row=next(x for x in mg['rows'] if x['code']==vl.code);assert row['current_price']==101 and row['score']==61 and row['buy_confirmed'] is False and row['buy_pressure']==55

# 2.4.7 evidence-first hardening regressions (retained in 2.4.8).
from app.evidence_engine import write_report as _write_evidence
from app.archive_engine import archive_day as _archive_day
assert m.MAX_CANDIDATES==1200 and m.STATE.lock_policy.get('mode')=='STRUCTURAL_ONLY'
assert m.classify_market_event({'source':'DART','title':'단일판매 공급계약체결'})['polarity']=='POSITIVE'
assert m.classify_market_event({'source':'DART','title':'횡령 배임 발생'})['polarity_score']==-6.0
assert m.classify_market_event({'source':'DART','title':'횡령 혐의없음'})['polarity']=='NEUTRAL'
# Severe negative event is a new-BUY fail-closed guard; positive remains only a prior.
eg=m.Candidate('977001','EVENT');eg.last_rate_by_venue['NXT']=2;eg.metrics={'event_signal':-6,'nxt_impulse_60s':0,'nxt_micro_vwap_gap':0,'nxt_one_tick_ratio':0}
assert '중대 악재 공시/뉴스' in m.recovery_entry_hard_reject(eg)
# Wall V2: persistent large NXT bid wall + ask depletion must become a positive soft confirm.
ow=m.Candidate('977002','WALL');t=time.time();ow.metrics['nxt_buy_pressure']=68
for i in range(5):
    vals={}
    for k in range(41,51):vals[str(k)]=101+(k-41)
    for k in range(51,61):vals[str(k)]=100-(k-51)
    for k in range(61,71):vals[str(k)]=max(40,100-i*10)
    for k in range(71,81):vals[str(k)]=100
    vals['71']=500
    assert m.parse_orderbook(ow,vals,t+i,'NXT')
assert float(ow.metrics.get('nxt_orderbook_wall_v2_score'))>0.8 and float(ow.metrics.get('nxt_orderbook_wall_persist_sec'))>=m.ORDERBOOK_WALL_PERSIST_SECONDS
# Candidate hard cap evicts only unprotected low-quality candidates.
_old_candidates=m.STATE.candidates;_old_core=m.STATE.core_codes;_old_ws=m.STATE.ws_codes;_old_max=m.MAX_CANDIDATES
try:
    m.STATE.candidates={};m.STATE.core_codes=['C0'];m.STATE.ws_codes=['C0'];m.MAX_CANDIDATES=5
    for i in range(8):
        q=m.Candidate(f'C{i}',f'C{i}');q.score=i;q.first_seen=time.time()-1000+i;m.STATE.candidates[q.code]=q
    m.enforce_candidate_cap_locked(time.time());assert len(m.STATE.candidates)<=5 and 'C0' in m.STATE.candidates
finally:m.STATE.candidates=_old_candidates;m.STATE.core_codes=_old_core;m.STATE.ws_codes=_old_ws;m.MAX_CANDIDATES=_old_max
# Replay snapshot is memory-queued, not direct disk I/O on the scoring path.
rp=m.Candidate('977003','REPLAY');rp.venue='NXT';rp.last_price_by_venue['NXT']=100;rp.last_rate_by_venue['NXT']=2;rp.last_tick_at_by_venue['NXT']=time.time();rp.metrics.update({'nxt_recovery_state':'RECOVERY_READY','nxt_buy_pressure':60});m.STATE.candidates[rp.code]=rp;m.STATE.nxt_memory_codes.append(rp.code) if rp.code not in m.STATE.nxt_memory_codes else None
before=len(m.STATE.replay_queue);assert m.queue_replay_snapshot(rp) is True and len(m.STATE.replay_queue)>=before+1
# Evidence engine and sealed archive work with empty/test data and never auto-apply parameters.
er=_write_evidence(_TEST_DATA,_TEST_DATA/'evidence_report.json');assert er['version']=='EVIDENCE_ENGINE_V2_PROSPECTIVE' and 'week' in er['periods']
(_TEST_DATA/'buy_entry_events_v3.jsonl').write_text('{"day":"20260808","kind":"BUY_CONFIRMED","id":"E1","code":"977003","route":"TEST","at":"2026-08-08T10:00:00+09:00"}\n',encoding='utf-8')
(_TEST_DATA/'replay_journal_20260808.jsonl').write_text('{"day":"20260808","code":"977003","ts":1,"price":100}\n',encoding='utf-8')
am=_archive_day(_TEST_DATA,'20260808');assert am.get('sealed') is True and (_TEST_DATA/'archive/20260808/replay_journal.jsonl.gz').exists()
assert Path(__file__).resolve().parent.joinpath('replay_backtest.py').exists()

# 2.4.8 prospective anti-hindsight / top-1% target regressions.
import inspect as _inspect
assert 'record_buy_signal' not in _inspect.getsource(m.emit_nxt_fast_jump_alert)
assert 'WATCH_ONLY' in _inspect.getsource(m.emit_nxt_fast_jump_alert) and '매수금지' in _inspect.getsource(m.emit_nxt_fast_jump_alert)
assert 'RECOVERY_EARLY' in m.NXT_RECOVERY_STAGE_RANK and 'RECOVERY_EARLY' in m.NXT_PUSH_STAGES
assert m.NXT_FAST_JUMP_READY_PERCENTILE==99 and m.NXT_FAST_JUMP_WATCH_PERCENTILE<=m.NXT_FAST_JUMP_READY_PERCENTILE
assert m.NXT_TOP1_MIN_POPULATION>=100 and m.NXT_FAST_JUMP_READY_MIN_POPULATION<=m.NXT_TOP1_MIN_POPULATION
assert "'top1_status':'UNPROVEN_UNTIL_SUFFICIENT_OOS'" in _inspect.getsource(m.health)
assert "for mode in ('signal','micro','observation')" in _inspect.getsource(m.backtest_status_api)
# Frozen prospective observation contains no future result at emission time.
po=m.Candidate('988001','PROSPECT');tt=time.time();po.last_price_by_venue['NXT']=110;po.last_rate_by_venue['NXT']=11;po.last_tick_at_by_venue['NXT']=tt;po.metrics.update({'nxt_buy_pressure':66,'nxt_algo_persistence':64,'nxt_catch_score':88,'nxt_catch_percentile':99.2,'nxt_catch_population':100,'nxt_top1_target':True})
rec=m._prospective_observation_snapshot(po,'FAST_JUMP_WATCH','FAST_JUMP',['test'],buy_prohibited=True)
assert rec and rec['frozen_at_emit'] is True and rec['buy_prohibited'] is True and rec['future_label'] is None and rec['future_return'] is None
assert Path(m.PROSPECTIVE_OBSERVATION_FILE).exists()
# Recovery early is observation-only; only RECOVERY_BUY branch may call record_buy_signal.
src=_inspect.getsource(m.advance_nxt_recovery);assert "st=='RECOVERY_EARLY'" in src and "record_buy_signal(c,'BUY','NXT_RECOVERY_RECLAIM')" in src
# Top-1% catch score is a prioritisation feature, not a BUY route.
assert 'record_buy_signal' not in _inspect.getsource(m._nxt_catch_raw_score)

print('NOVA 2.4.8 SELF-CHECK PASS')
