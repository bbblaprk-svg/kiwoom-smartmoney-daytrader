#!/usr/bin/env python3
from __future__ import annotations
import argparse,gzip,json,math,statistics
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import defaultdict
from pathlib import Path

def num(x,d=0.0):
    try:return float(x)
    except:return d

def read_jsonl(p):
    p=Path(p);op=gzip.open if p.suffix=='.gz' else open;out=[]
    if not p.exists():return out
    try:
        with op(p,'rt',encoding='utf-8',errors='ignore') as f:
            for line in f:
                try:out.append(json.loads(line))
                except:pass
    except:pass
    return out

def wilson(w,n,z=1.96):
    if not n:return [None,None]
    p=w/n;den=1+z*z/n;mid=(p+z*z/(2*n))/den;half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return [round(max(0,mid-half)*100,2),round(min(1,mid+half)*100,2)]

def metrics(rs):
    n=len(rs);w=sum(x>0 for x in rs);g=sum(x for x in rs if x>0);l=-sum(x for x in rs if x<0);eq=peak=1.;mdd=0.
    for r in rs:eq*=max(.0001,1+r/100);peak=max(peak,eq);mdd=min(mdd,(eq/peak-1)*100)
    return {'n':n,'win_pct':round(w/n*100,2) if n else None,'win_95ci':wilson(w,n),'expectancy_pct':round(statistics.mean(rs),3) if n else None,'profit_factor':round(g/l,3) if l else (999 if g else None),'mdd_pct':round(mdd,3) if n else None}

def split_days(rows):
    days=sorted({str(x.get('day') or '') for x in rows if x.get('day')});n=len(days)
    if n<3:return set(days),set(),set()
    a=max(1,int(n*.6));b=max(a+1,int(n*.8));return set(days[:a]),set(days[a:b]),set(days[b:])

def load_signal(data):
    buys=[]
    for p in [data/'buy_entry_events_v3.jsonl']+list((data/'archive').glob('20??????/buy_signals.jsonl.gz')) if (data/'archive').exists() else [data/'buy_entry_events_v3.jsonl']:
        buys+=read_jsonl(p)
    exits={}
    for p in list(data.glob('exit_trace_*.jsonl'))+(list((data/'archive').glob('20??????/exit_trace.jsonl.gz')) if (data/'archive').exists() else []):
        for x in read_jsonl(p):
            k=str(x.get('id') or '');
            if k and (k not in exits or num(x.get('ts'))>=num(exits[k].get('ts'))):exits[k]=x
    out=[]
    for b in buys:
        k=str(b.get('id') or b.get('entry_id') or '');e=exits.get(k)
        if not e:continue
        m=b.get('metrics') or {};day=str(b.get('day') or str(b.get('at') or '')[:10]).replace('-','')
        out.append({'day':day,'ret':num(e.get('ret')),'score':num(b.get('score')),'bp':num(m.get('nxt_buy_pressure',m.get('buy_pressure')),50),'accel':num(m.get('nxt_volume_accel_30s',m.get('volume_accel')),1),'event':num(m.get('event_signal'))})
    return out

def load_micro(data):
    rows=[]
    for p in list(data.glob('replay_journal_*.jsonl'))+(list((data/'archive').glob('20??????/replay_journal.jsonl.gz')) if (data/'archive').exists() else []):rows+=read_jsonl(p)
    rows.sort(key=lambda x:num(x.get('ts')));by=defaultdict(list)
    for x in rows:by[(x.get('day'),x.get('code'),x.get('venue'))].append(x)
    out=[]
    for _,xs in by.items():
        for i,x in enumerate(xs):
            target=None
            for y in xs[i+1:]:
                if num(y.get('ts'))-num(x.get('ts'))>=1800:target=y;break
            if not target:continue
            p=num(x.get('price'));q=num(target.get('price'))
            if p<=0 or q<=0:continue
            out.append({**x,'ret':(q/p-1)*100})
    return out


def load_observation(data):
    obs=[]
    p=data/'prospective_observation_events.jsonl'
    if p.exists():obs+=read_jsonl(p)
    arch=data/'archive'
    if arch.exists():
        for q in arch.glob('20??????/prospective_observations.jsonl.gz'):obs+=read_jsonl(q)
    replay=[]
    for q in list(data.glob('replay_journal_*.jsonl'))+(list(arch.glob('20??????/replay_journal.jsonl.gz')) if arch.exists() else []):replay+=read_jsonl(q)
    replay.sort(key=lambda x:num(x.get('ts')));by=defaultdict(list)
    for x in replay:by[(x.get('day'),x.get('code'),x.get('venue'))].append(x)
    out=[];seen=set()
    for o in obs:
        oid=str(o.get('id') or '')
        if not oid or oid in seen:continue
        seen.add(oid);p0=num(o.get('price'));t0=num(o.get('ts'));key=(o.get('day'),o.get('code'),o.get('venue') or 'NXT')
        fut=[x for x in by.get(key,[]) if 0<num(x.get('ts'))-t0<=1800 and num(x.get('price'))>0]
        if p0<=0 or not fut:continue
        prices=[num(x.get('price')) for x in fut];last=fut[-1]
        out.append({'day':o.get('day'),'ret':(num(last.get('price'))/p0-1)*100,'mfe':(max(prices)/p0-1)*100,'mae':(min(prices)/p0-1)*100,'stage':o.get('stage'),'score':num(o.get('nxt_catch_score')),'bp':num(o.get('buy_pressure'),50),'accel':max(num(o.get('volume_accel_30s'),1),num(o.get('volume_accel_60s'),1)),'wall_v2':num(o.get('wall_v2')),'event':num(o.get('event_signal')),'catch_percentile':num(o.get('nxt_catch_percentile')),'top1_target':bool(o.get('nxt_top1_target'))})
    return out

def run(rows,mode):
    train,valid,oos=split_days(rows);results=[]
    score_grid=[65,70,75,80] if mode=='signal' else [55,60,65,70] if mode=='observation' else [60,65,70,75]
    for sc in score_grid:
      for bp in [55,60,65]:
       for acc in [1.05,1.15,1.25]:
        for wall in ([0,.8,1.2] if mode=='micro' else [0]):
         for ev in [-6,-3,0]:
          def filt(ds):return [num(x['ret']) for x in rows if x.get('day') in ds and num(x.get('score'))>=sc and num(x.get('buy_pressure',x.get('bp')),50)>=bp and num(x.get('volume_accel',x.get('accel')),1)>=acc and num(x.get('wall_v2'))>=wall and num(x.get('event_signal',x.get('event')))>=ev]
          results.append({'params':{'score_min':sc,'bp_min':bp,'accel_min':acc,'wall_v2_min':wall,'event_min':ev},'train':metrics(filt(train)),'valid':metrics(filt(valid)),'oos':metrics(filt(oos))})
    results.sort(key=lambda x:((x['valid']['expectancy_pct'] if x['valid']['expectancy_pct'] is not None else -999),(x['oos']['expectancy_pct'] if x['oos']['expectancy_pct'] is not None else -999)),reverse=True)
    return {'version':'OFFLINE_REPLAY_BACKTEST_V1','generated_at':datetime.now(ZoneInfo('Asia/Seoul')).isoformat(),'mode':mode,'auto_apply':False,'research_only':True,'warning':'라이브 파라미터 자동 적용 금지. walk-forward/OOS 표본과 신뢰구간 확인 후 별도 승인 필요.','days':{'train':len(train),'valid':len(valid),'oos':len(oos)},'rows':len(rows),'top':results[:100],'results':results[:100]}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--data-dir',required=True);ap.add_argument('--mode',choices=['signal','micro','observation'],default='signal');ap.add_argument('--output');a=ap.parse_args();d=Path(a.data_dir)
    d.mkdir(parents=True,exist_ok=True);rows=load_signal(d) if a.mode=='signal' else load_observation(d) if a.mode=='observation' else load_micro(d);r=run(rows,a.mode);out=Path(a.output or d/f'backtest_{a.mode}_latest.json');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'ok':True,'mode':a.mode,'rows':len(rows),'output':str(out),'auto_apply':False},ensure_ascii=False))
if __name__=='__main__':main()
