# QUANT NOVA 1.0 · Kiwoom Pre-Ignition Radar

기존 고정/수동/자동/경량/집중/뉴스그룹 개념을 사용하지 않습니다.
키움 REST 순위 API를 독립 발견원으로 사용해 매 주기 동적 유니버스를 만들고,
상위 후보만 Kiwoom WebSocket 주식체결(0B)로 KRX bare + NXT _NX 이중 검증합니다.
실수신 시장은 FID 9081을 우선합니다.

필수 환경변수:
- KIWOOM_APP_KEY
- KIWOOM_SECRET_KEY

선택:
- NOVA_DISCOVERY_SECONDS=20
- NOVA_WS_LIMIT=60
- NOVA_MIN_SCORE=58

주의: NOVA score는 상대 우선순위이며 수익확률을 보장하는 통계적 확률값이 아닙니다.

## NOVA 1.0.1 discovery correction
- Kiwoom official ranking TR only: ka10020/21/22/23/27/30/32
- Removed invalid program ranking call from /api/dostk/rkinfo
- ka10027 request field corrected to trde_qty_cnd
- ka10023 minute window (`tm=5`) added
- Added bid-quantity surge and residual-ratio surge as pre-ignition evidence
