from __future__ import annotations
import asyncio, json, math, os, time, statistics, re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import httpx, websockets
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_VERSION='NOVA-1.0.1'
SEOUL_OFFSET=9*3600
BASE=Path(__file__).resolve().parent.parent
API='https://api.kiwoom.com'
WS='wss://api.kiwoom.com:10000/api/dostk/websocket'
APP_KEY=os.getenv('KIWOOM_APP_KEY','').strip()
SECRET=(os.getenv('KIWOOM_SECRET_KEY') or os.getenv('KIWOOM_APP_SECRET') or '').strip()
DISCOVERY_SECONDS=max(10,int(os.getenv('NOVA_DISCOVERY_SECONDS','20')))
WS_LIMIT=max(20,min(80,int(os.getenv('NOVA_WS_LIMIT','60'))))
MIN_SCORE=float(os.getenv('NOVA_MIN_SCORE','58'))


def num(x, d=0.0):
    try:
        s=str(x).strip().replace(',','')
        if not s:return d
        return float(s)
    except Exception:return d

def code6(x):
    s=str(x or '').strip().upper().replace('_NX','').replace('_AL','')
    m=re.search(r'(\d{6})',s)
    return m.group(1) if m else ''

def clamp(x,a=0,b=100): return max(a,min(b,x))
def sigmoid(x): return 1/(1+math.exp(-max(-30,min(30,x))))
def now_kst(): return time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(time.time()+SEOUL_OFFSET))

@dataclass
class Tick:
    ts: float; price: float; qty: float; rate: float; venue: str; cumvol: float=0; turnover: float=0

@dataclass
class Candidate:
    code: str
    name: str=''
    source_hits: dict[str,float]=field(default_factory=dict)
    ticks: deque=field(default_factory=lambda:deque(maxlen=600))
    last_price: float=0
    rate: float=0
    venue: str=''
    last_tick_at: float=0
    first_seen: float=field(default_factory=time.time)
    score: float=0
    confidence: float=0
    stage: str='SEED'
    reasons: list[str]=field(default_factory=list)
    metrics: dict[str,Any]=field(default_factory=dict)

class TokenManager:
    def __init__(self): self.token=''; self.exp=0; self.lock=asyncio.Lock()
    async def get(self):
        if self.token and time.time()<self.exp-120:return self.token
        async with self.lock:
            if self.token and time.time()<self.exp-120:return self.token
            if not APP_KEY or not SECRET: raise RuntimeError('KIWOOM_APP_KEY / KIWOOM_SECRET_KEY 환경변수 필요')
            async with httpx.AsyncClient(timeout=12) as c:
                r=await c.post(API+'/oauth2/token',json={'grant_type':'client_credentials','appkey':APP_KEY,'secretkey':SECRET})
                r.raise_for_status(); j=r.json()
                if int(j.get('return_code',0))!=0: raise RuntimeError(j.get('return_msg') or 'token error')
                self.token=j['token']; self.exp=time.time()+23*3600
                return self.token
TOK=TokenManager()

class NovaState:
    def __init__(self):
        self.candidates: dict[str,Candidate]={}
        self.rest_status={}; self.ws_status={'connected':False,'ack':0,'last_error':'','last_message_at':0}
        self.generated_at=0; self.lock=asyncio.Lock(); self.ws_codes=[]; self.market_mode='LIVE' if APP_KEY and SECRET else 'WAITING_KEYS'
        self.scan_cycles=0; self.raw_rest_samples={}
    def get(self,code,name=''):
        if code not in self.candidates:self.candidates[code]=Candidate(code,name)
        elif name and not self.candidates[code].name:self.candidates[code].name=name
        return self.candidates[code]
STATE=NovaState()

RANK_SPECS=[
 # Official Kiwoom domestic ranking TRs only. Every source is independent evidence.
 ('orderbook_buy','ka10020',{'mrkt_tp':'{market}','sort_tp':'3','trde_qty_tp':'0000','stk_cnd':'1','crd_cnd':'0','stex_tp':'3'}),
 ('bid_surge','ka10021',{'mrkt_tp':'{market}','trde_tp':'1','sort_tp':'2','tm_tp':'5','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('residual_ratio_surge','ka10022',{'mrkt_tp':'{market}','rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':'3'}),
 ('volume_surge','ka10023',{'mrkt_tp':'{market}','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'1','pric_tp':'0','stex_tp':'3'}),
 ('change_leaders','ka10027',{'mrkt_tp':'{market}','sort_tp':'1','trde_qty_cnd':'0','stk_cnd':'1','crd_cnd':'0','updown_incls':'0','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}),
 ('volume_top','ka10030',{'mrkt_tp':'{market}','sort_tp':'1','mang_stk_incls':'0','crd_tp':'0','trde_qty_tp':'0','pric_tp':'0','trde_prica_tp':'0','mrkt_open_tp':'0','stex_tp':'3'}),
 ('turnover_top','ka10032',{'mrkt_tp':'{market}','mang_stk_incls':'0','stex_tp':'3'}),
]
WEIGHTS={'orderbook_buy':10,'bid_surge':17,'residual_ratio_surge':14,'volume_surge':20,'change_leaders':9,'volume_top':10,'turnover_top':15}

async def kiwoom_post(path, api_id, body):
    token=await TOK.get()
    h={'authorization':f'Bearer {token}','api-id':api_id,'content-type':'application/json;charset=UTF-8'}
    async with httpx.AsyncClient(timeout=8) as c:
        r=await c.post(API+path,headers=h,json=body)
        data=r.json() if r.content else {}
        return r.status_code,data

def extract_rows(obj):
    if isinstance(obj,list):
        if obj and isinstance(obj[0],dict): return obj
        out=[]
        for x in obj: out+=extract_rows(x)
        return out
    if isinstance(obj,dict):
        best=[]
        for k,v in obj.items():
            if isinstance(v,list) and v and isinstance(v[0],dict):
                # ignore tiny diagnostic lists
                if len(v)>len(best): best=v
        return best
    return []

def row_identity(row):
    keys=['stk_cd','stk_code','code','item','종목코드']
    nk=['stk_nm','stk_name','name','종목명']
    c=''; n=''
    for k in keys:
        if row.get(k): c=code6(row.get(k));
        if c:break
    for k in nk:
        if row.get(k): n=str(row.get(k)); break
    return c,n

async def discovery_loop():
    while True:
        started=time.time(); accum=defaultdict(dict)
        if APP_KEY and SECRET:
            for market in ('001','101'):
                for source,api_id,tpl in RANK_SPECS:
                    body={k:(market if v=='{market}' else v) for k,v in tpl.items()}
                    try:
                        status,j=await kiwoom_post('/api/dostk/rkinfo',api_id,body)
                        rows=extract_rows(j); STATE.rest_status[f'{source}:{market}']={'ok':status==200 and int(j.get('return_code',0))==0,'rows':len(rows),'msg':j.get('return_msg','')}
                        for idx,row in enumerate(rows[:80]):
                            c,n=row_identity(row)
                            if not c: continue
                            # rank decay gives early overlap more weight
                            accum[c][source]=max(accum[c].get(source,0), WEIGHTS[source]*(1-0.55*idx/max(1,min(len(rows),80))))
                            cand=STATE.get(c,n)
                    except Exception as e:
                        STATE.rest_status[f'{source}:{market}']={'ok':False,'rows':0,'msg':str(e)[:120]}
            async with STATE.lock:
                now=time.time()
                for c,hits in accum.items():
                    cand=STATE.get(c); cand.source_hits=hits; cand.metrics['discovery_overlap']=len(hits); cand.metrics['rest_base']=sum(hits.values())
                # remove never-ticked stale discovery-only rows after 30m
                for c in list(STATE.candidates):
                    x=STATE.candidates[c]
                    if not x.ticks and now-x.first_seen>1800 and c not in accum: STATE.candidates.pop(c,None)
                score_all()
                STATE.generated_at=now; STATE.scan_cycles+=1
                STATE.ws_codes=[x.code for x in ranked()[:WS_LIMIT]]
        await asyncio.sleep(max(2,DISCOVERY_SECONDS-(time.time()-started)))

def calc(c:Candidate):
    ticks=list(c.ticks); now=time.time(); reasons=[]
    rest=min(30, num(c.metrics.get('rest_base'))*0.55)
    if len(c.source_hits)>=3: reasons.append(f'독립순위 {len(c.source_hits)}중첩')
    if len(ticks)<4:
        c.score=round(rest,1); c.confidence=min(35,len(c.source_hits)*8); c.stage='SEED'; c.reasons=reasons or ['실시간 체결 축적 중']; return
    recent=[t for t in ticks if now-t.ts<=60]; prev=[t for t in ticks if 60<now-t.ts<=180]
    r5=[t for t in ticks if now-t.ts<=300]
    if not recent: recent=ticks[-10:]
    p0=recent[0].price; p1=recent[-1].price
    impulse=(p1/p0-1)*100 if p0 else 0
    vol60=sum(abs(t.qty) for t in recent); volprev=sum(abs(t.qty) for t in prev)/2 if prev else max(vol60*.65,1)
    accel=vol60/max(volprev,1)
    signed=sum(t.qty for t in recent); buy_ratio=(signed/vol60*50+50) if vol60 else 50
    prices=[t.price for t in r5 if t.price>0]; breakout=0
    if len(prices)>5:
        old=prices[:-max(2,len(prices)//5)]
        oldmax=max(old) if old else max(prices)
        breakout=max(0,(p1/oldmax-1)*100) if oldmax else 0
    pv=sum(t.price*abs(t.qty) for t in r5); vv=sum(abs(t.qty) for t in r5); vwap=pv/vv if vv else p1
    above=(p1/vwap-1)*100 if vwap else 0
    # venue corroboration: both markets active for same code in last 120s
    venues={t.venue for t in ticks if now-t.ts<=120 and t.venue in ('KRX','NXT')}
    dual=len(venues)==2
    one_tick=max((abs(t.qty) for t in recent),default=0)/max(vol60,1)
    score=rest
    score+=clamp((accel-1)*12,0,20)
    score+=clamp((buy_ratio-50)*0.38,0,16)
    score+=clamp(impulse*3.2,0,15)
    score+=clamp(above*4.5,0,8)
    score+=clamp(breakout*6,0,9)
    if dual: score+=5
    # anti-chase / fake impulse penalties
    if c.rate>14: score-=12; reasons.append('과열 추격위험')
    if impulse>4.5: score-=7
    if one_tick>0.5: score-=8; reasons.append('단일체결 편중')
    if accel>=1.7: reasons.append(f'1분 체결가속 {accel:.1f}x')
    if buy_ratio>=60: reasons.append(f'공격매수 우위 {buy_ratio:.0f}%')
    if impulse>=0.7: reasons.append(f'가격 선행 +{impulse:.1f}%')
    if above>=0.2: reasons.append('실시간 VWAP 상회')
    if breakout>=0.3: reasons.append('5분 미세돌파')
    if dual: reasons.append('KRX·NXT 동시확인')
    score=clamp(score)
    # confidence is data sufficiency, not win probability
    conf=clamp(20+min(35,len(recent)*1.2)+min(25,len(c.source_hits)*6)+(10 if dual else 0))
    c.score=round(score,1); c.confidence=round(conf,0)
    c.stage='IGNITION' if score>=78 else 'PRESSURE' if score>=64 else 'WATCH' if score>=48 else 'SEED'
    c.reasons=reasons[:4]
    c.metrics.update({'impulse_60s':round(impulse,2),'volume_accel':round(accel,2),'buy_pressure':round(buy_ratio,1),'vwap_gap':round(above,2),'micro_breakout':round(breakout,2),'dual_venue':dual,'tick_count_60s':len(recent)})

def score_all():
    for c in STATE.candidates.values(): calc(c)

def ranked():
    rows=list(STATE.candidates.values()); rows.sort(key=lambda x:(x.score,x.confidence,x.last_tick_at),reverse=True); return rows

async def ws_loop():
    last_reg=(); group=300
    while True:
        if not APP_KEY or not SECRET:
            await asyncio.sleep(5); continue
        try:
            token=await TOK.get()
            async with websockets.connect(WS,ping_interval=None,close_timeout=3,max_size=4_000_000) as ws:
                STATE.ws_status.update({'connected':True,'last_error':''})
                await ws.send(json.dumps({'trnm':'LOGIN','token':token}))
                logged=False
                while True:
                    codes=tuple(STATE.ws_codes[:WS_LIMIT])
                    if logged and codes and codes!=last_reg:
                        group+=1
                        data=[]
                        # validated dual-registration pattern: bare KRX + _NX NXT, trade 0B
                        for c in codes: data.append({'item':[c],'type':['0B']})
                        for c in codes: data.append({'item':[c+'_NX'],'type':['0B']})
                        # chunk to avoid oversized request
                        for i in range(0,len(data),40):
                            await ws.send(json.dumps({'trnm':'REG','grp_no':str(group+i//40),'refresh':'1','data':data[i:i+40]}))
                        last_reg=codes
                    try: raw=await asyncio.wait_for(ws.recv(),timeout=2.0)
                    except asyncio.TimeoutError: continue
                    STATE.ws_status['last_message_at']=time.time()
                    m=json.loads(raw)
                    if m.get('trnm')=='PING': await ws.send(raw); continue
                    if m.get('trnm')=='LOGIN':
                        if int(m.get('return_code',-1))!=0: raise RuntimeError(m.get('return_msg','LOGIN failed'))
                        logged=True; continue
                    if m.get('trnm')=='REG':
                        if int(m.get('return_code',-1))==0: STATE.ws_status['ack']=STATE.ws_status.get('ack',0)+1
                        continue
                    if m.get('trnm')!='REAL': continue
                    for d in m.get('data',[]):
                        if str(d.get('type'))!='0B': continue
                        v=d.get('values') or {}; c=code6(d.get('item') or v.get('9001'))
                        if not c: continue
                        p=abs(num(v.get('10'))); q=num(v.get('15')); rate=num(v.get('12')); venue=str(v.get('9081') or '').upper()
                        if venue not in ('KRX','NXT'): venue='NXT' if str(d.get('item','')).upper().endswith('_NX') else 'KRX'
                        if p<=0: continue
                        cand=STATE.get(c); cand.last_price=p; cand.rate=rate; cand.venue=venue; cand.last_tick_at=time.time()
                        cand.ticks.append(Tick(time.time(),p,q,rate,venue,abs(num(v.get('13'))),abs(num(v.get('14')))))
                    score_all(); STATE.generated_at=time.time()
        except Exception as e:
            STATE.ws_status.update({'connected':False,'last_error':str(e)[:180]}); await asyncio.sleep(2)

app=FastAPI(title='Quant Nova Ignition Radar',version=APP_VERSION)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static')

@app.on_event('startup')
async def start():
    asyncio.create_task(discovery_loop(),name='nova-discovery')
    asyncio.create_task(ws_loop(),name='nova-websocket')

@app.get('/')
async def root(): return FileResponse(BASE/'static/index.html')

@app.get('/api/nova')
async def nova():
    score_all(); rows=[]; now=time.time()
    for i,c in enumerate(ranked()[:40],1):
        rows.append({'rank':i,'code':c.code,'name':c.name or c.code,'price':c.last_price,'change_rate':c.rate,'score':c.score,'confidence':c.confidence,'stage':c.stage,'reasons':c.reasons,'metrics':c.metrics,'sources':list(c.source_hits),'venue':c.venue,'age_ms':round((now-c.last_tick_at)*1000) if c.last_tick_at else None})
    ok_rest=sum(1 for x in STATE.rest_status.values() if x.get('ok'))
    return {'version':APP_VERSION,'generated_at':now_kst(),'mode':STATE.market_mode,'threshold':MIN_SCORE,'rows':rows,'health':{'ws':STATE.ws_status,'rest_ok':ok_rest,'rest_total':len(STATE.rest_status),'candidate_count':len(STATE.candidates),'subscribed':len(STATE.ws_codes),'scan_cycles':STATE.scan_cycles},'policy':{'probability_note':'점수는 실시간 상대 우선순위이며 수익확률을 보장하지 않습니다.','data_truth':'Kiwoom REST ranking + WebSocket 0B, FID9081 venue truth','universe':'고정 목록 없이 순위 API 교집합으로 계속 재구성'}}

@app.get('/api/health')
async def health():
    return {'ok':True,'version':APP_VERSION,'mode':STATE.market_mode,'ws':STATE.ws_status,'rest':STATE.rest_status,'generated_at':now_kst()}
