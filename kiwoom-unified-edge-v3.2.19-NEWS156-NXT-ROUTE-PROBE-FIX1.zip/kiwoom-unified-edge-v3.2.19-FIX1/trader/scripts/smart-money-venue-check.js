const assert = require('assert');
const { evaluateSmartMoneyBehavior } = require('../lib/smartMoneyBehavior');
const { state, processRealtimeEntry, computeMetrics } = require('../lib/realtimeStore');
const fs = require('fs'); const path = require('path');

const t = Date.now();
const stock = { smartMoney: { behaviorState: 'NEUTRAL', behaviorHistory: [], candidateBehavior:'NEUTRAL', candidateSince:0, candidateCount:0 } };
const shakeMetrics = {
  netBuyAmount5s:-10_000_000, netBuyAmount15s:-100_000_000, buyAcceleration:5_000_000,
  programVelocity10s:15_000_000, programNetAmount:30_000_000, orderbookImbalance:1.32,
  bidReplenishRatio:.13, askWithdrawalRatio:.02, momentum1mPct:-.5, drawdownFromHighPct:-1.2,
  tradeStrength:95, vwapDistancePct:-.4, largeNetAmount1m:-20_000_000, largeBuyCount1m:2, largeSellCount1m:2,
  vwapReclaim:false, dualVenueReady:true, venueAgreement:.7,
  tradeAgeMs:0, tradeEventCount:8, orderbookAgeMs:0, orderbookSampleCount:3, orderbookSupportStreak:2, programAgeMs:0, programSampleCount:3,
};
const shakeRaw = evaluateSmartMoneyBehavior(stock, shakeMetrics, t);
assert.strictEqual(shakeRaw.rawBehaviorState, 'SHAKEOUT', JSON.stringify(shakeRaw));
assert.strictEqual(shakeRaw.behaviorState, 'NEUTRAL', '단일 샘플로 SHAKEOUT을 확정하면 안 됩니다.');
const shake = evaluateSmartMoneyBehavior(stock, shakeMetrics, t+350);
assert.strictEqual(shake.behaviorState, 'SHAKEOUT', JSON.stringify(shake));
assert(shake.shakeoutScore >= 65, JSON.stringify(shake));

stock.smartMoney.behaviorState = 'SHAKEOUT'; stock.smartMoney.behaviorHistory=[{at:t+350,state:'SHAKEOUT'}];
const turnMetrics = {
  netBuyAmount5s:45_000_000, netBuyAmount15s:-10_000_000, buyAcceleration:24_000_000,
  programVelocity10s:80_000_000, programNetAmount:120_000_000, orderbookImbalance:1.28,
  bidReplenishRatio:.08, askWithdrawalRatio:.07, momentum1mPct:.25, drawdownFromHighPct:-.3,
  tradeStrength:125, vwapDistancePct:.1, largeNetAmount1m:90_000_000, largeBuyCount1m:4, largeSellCount1m:1,
  vwapReclaim:true, dualVenueReady:true, venueAgreement:.8,
  tradeAgeMs:0, tradeEventCount:12, orderbookAgeMs:0, orderbookSampleCount:5, orderbookSupportStreak:3, programAgeMs:0, programSampleCount:5,
};
const turnRaw = evaluateSmartMoneyBehavior(stock, turnMetrics, t+3000);
assert.strictEqual(turnRaw.rawBehaviorState, 'TURN', JSON.stringify(turnRaw));
const turn = evaluateSmartMoneyBehavior(stock, turnMetrics, t+3300);
assert.strictEqual(turn.behaviorState, 'TURN', JSON.stringify(turn));
assert.strictEqual(turn.legacyState, 'TURN');

const code='999999';
const meta={name:'TEST',market:'SOR',tier:'FOCUS',fixed:true};
function trade(item, venue, qty, price, cumVol, cumAmt) {
  return processRealtimeEntry({type:'0A',item,values:{'9081':venue,'15':String(qty),'10':String(price),'12':'1.0','13':String(cumVol),'14':String(cumAmt),'16':'10000','17':'10200','18':'9900','228':'125','1032':'55'}},meta);
}
trade(code,'KRX',100,10000,1000,10_000_000); trade(code,'KRX',120,10010,1120,11_201_200);
trade(code,'NXT',80,10020,500,5_010_000); trade(code,'NXT',90,10030,590,5_912_700);
const live=state.stocks.get(code);
const m=computeMetrics(live,Date.now());
assert.strictEqual(live.venues.KRX.tradeEventCount,2);
assert.strictEqual(live.venues.NXT.tradeEventCount,2);
assert.strictEqual(live.cumulativeVolume,1710,JSON.stringify({v:live.cumulativeVolume,krx:live.venues.KRX.cumulativeVolume,nxt:live.venues.NXT.cumulativeVolume}));
assert.strictEqual(m.dualVenueReady,true,JSON.stringify(m));
assert(m.venueAgreement >= 0,JSON.stringify(m));

const workerSource = fs.readFileSync(path.join(__dirname,'../worker/kiwoomRealtime.js'),'utf8');
assert(workerSource.includes('return base;'), 'WebSocket bare-code registration missing');
assert(workerSource.includes('SOCKET_WATCHDOG_MS'), 'WebSocket watchdog missing');
assert(workerSource.includes('REST_FALLBACK_INTERVAL_MS'), 'REST continuity fallback missing');
assert(workerSource.includes('9 * 3600 + 30'), 'NXT main-market 09:00:30 boundary missing');
assert(workerSource.includes('15 * 3600 + 40 * 60'), 'NXT after-market 15:40 boundary missing');
assert(workerSource.includes('8 * 3600 + 50 * 60'), 'NXT pre-market 08:50 boundary missing');
console.log('SMART_MONEY_VENUE_CHECK PASS', {shakeout:shake.shakeoutScore,turnConfidence:turn.confidence,dualVenueReady:m.dualVenueReady,venueAgreement:m.venueAgreement});
