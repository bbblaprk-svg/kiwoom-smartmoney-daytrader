const assert = require('assert');
const {
  state, ensureStock, applyMarketSnapshot, applyVenueFallbackQuote, processRealtimeEntry,
  realtimeSessionContext, realtimeTruth, snapshotDisplay, publicStock,
} = require('../lib/realtimeStore');
const { evaluateOpportunity } = require('../lib/unifiedOpportunity');

const activeNow = Date.parse('2026-08-04T23:30:00.000Z'); // 2026-08-05 08:30 KST, NXT active
assert(Number.isFinite(activeNow));
const ctx = realtimeSessionContext(activeNow);
assert.strictEqual(ctx.active, true);
assert.deepStrictEqual(ctx.expected, ['NXT']);

state.stocks.clear();
const stock = ensureStock('005930', { name:'삼성전자', marketMode:'SOR', tier:'FOCUS' });
applyMarketSnapshot('005930', {
  name:'삼성전자', fetchedAt:'2026-08-04T11:36:00.000Z', phase:{code:'CLOSED'},
  krx:{available:true, close:242000, final:true}, nxt:{available:true, close:241500, final:true},
  decision:{ action:'WAIT', score:60 },
});

// NXT 프리마켓에서 REAL payload item이 suffix를 생략해도 세션 단일거래소로 NXT를 판별해야 한다.
const rawNxt = ensureStock('000660', { name:'SK하이닉스', marketMode:'SOR', tier:'FOCUS' });
const originalNowForRoute = Date.now;
Date.now = () => activeNow;
try {
  processRealtimeEntry({ type:'0A', item:'000660', values:{ '10':'1600000','12':'1.1','13':'1000','14':'1600000000','15':'100','228':'120','1032':'58' } }, { name:'SK하이닉스', marketMode:'SOR', tier:'FOCUS' });
  assert.strictEqual(rawNxt.lastTradeVenue, 'NXT');
  assert.strictEqual(rawNxt.lastTradeVenueSource, 'SESSION_SINGLE_VENUE');
  assert.strictEqual(realtimeTruth(rawNxt, activeNow).eligible, true);
} finally { Date.now = originalNowForRoute; }

// 활성장에서는 종가/REST 스냅샷이 현재가로 승격되면 안 된다.
assert.strictEqual(snapshotDisplay(stock, activeNow), null);
let truth = realtimeTruth(stock, activeNow);
assert.strictEqual(truth.eligible, false);

// REST continuity fallback은 진단용이며 stock/venue live price를 변경하면 안 된다.
stock.price = 0;
applyVenueFallbackQuote('005930','NXT',{price:999999, changePct:9.9, volume:123456});
assert.strictEqual(stock.price, 0);
assert.strictEqual(stock.venues.NXT.price, 0);
assert.strictEqual(stock.venues.NXT.fallbackQuote.price, 999999);
const originalNowForMissing = Date.now;
Date.now = () => activeNow;
try {
  const missing = publicStock(stock);
  assert.strictEqual(missing.price, null);
  assert.strictEqual(missing.dataSource, 'REALTIME_MISSING');
  assert.strictEqual(missing.realtimeEligible, false);
} finally { Date.now = originalNowForMissing; }

// 실제 WebSocket 0A 경로가 도착한 경우에만 실시간 판정 가능.
stock.price = 123400;
stock.changePct = 1.25;
stock.updatedAt = activeNow - 1000;
stock.lastTradeVenue = 'NXT';
stock.lastTradeVenueSource = 'SUBSCRIPTION_CODE';
stock.market = 'NXT';
truth = realtimeTruth(stock, activeNow);
assert.strictEqual(truth.routed, true);
assert.strictEqual(truth.eligible, true);
assert.strictEqual(truth.venue, 'NXT');

const realNow = Date.now;
Date.now = () => activeNow;
try {
  const pub = publicStock(stock);
  assert.strictEqual(pub.price, 123400);
  assert.strictEqual(pub.dataSource, 'REALTIME_WEBSOCKET');
  assert.strictEqual(pub.realtimeEligible, true);
  assert.strictEqual(pub.realtimePriceSource, 'KIWOOM_WEBSOCKET_TRADE_AUTO');

  // 같은 날 받은 WebSocket 가격이라도 표시 신선도(기본 10초)를 넘으면 현재가로 남기지 않는다.
  stock.updatedAt = activeNow - 15000;
  const aged = publicStock(stock);
  assert.strictEqual(aged.price, null);
  assert.strictEqual(aged.dataSource, 'REALTIME_MISSING');
  assert.strictEqual(aged.realtimeDisplayFresh, false);
  stock.updatedAt = activeNow - 1000;

  const stale = {
    ...pub,
    realtimeEligible:false,
    realtimePriceSource:null,
    signal:{ action:'BUY', confirmed:true, qualityScore:99, profitPriorityScore:99, dataCompleteness:100, smartMoneyFeedReady:true, independentGroups:4,
      metrics:{tradeStrength:180,turnover1m:999999999,smartMoneyConfidence:95}, plan:{expectedRewardRisk:2,entry:123400,stop:120000,target1:128000} },
  };
  const blocked = evaluateOpportunity(stale, { signal:{ minBuyScore:85,minProfitPriorityScore:78,minTradeStrength:118,minDataCompleteness:95,minOneMinuteTurnover:100000000,minIndependentGroups:4 } });
  assert.strictEqual(blocked.stage, 'NONE');
  assert.strictEqual(blocked.currentPrice, null);
  assert.strictEqual(blocked.entryGuide.blockedBy, 'REALTIME_PRICE_REQUIRED');
} finally {
  Date.now = realNow;
}

// UI의 실시간 후보/관리 테이블도 오래된 signal/ledger 가격을 live처럼 재사용하면 안 된다.
const fs = require('fs');
const path = require('path');
const uiSource = fs.readFileSync(path.join(__dirname, '../pages/index.js'), 'utf8');
assert(uiSource.includes("const fresh = stocks.filter((s) => s.realtimeEligible === true).length;"));
assert(uiSource.includes("if (stock?.realtimeEligible !== true) return false;"));
assert(uiSource.includes("const currentPrice = stock.realtimeEligible === true ? Number(stock.realtimePrice || stock.price || 0) : 0;"));
assert(!uiSource.includes("const currentPrice = Number(live.price || row.currentPrice || 0);"));
assert(!uiSource.includes("const prices = new Map((data.stocks || []).map((stock) => [stock.code, Number(stock.price || 0)]));"));

console.log('REALTIME_TRUTH_CHECK PASS');
console.log(JSON.stringify({activeSession:ctx, restFallbackDiagnosticOnly:true, webSocketPrice:123400, activeSnapshotBlocked:true}, null, 2));
