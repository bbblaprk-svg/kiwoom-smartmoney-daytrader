const assert=require('assert'),fs=require('fs');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8'); const store=fs.readFileSync('lib/realtimeStore.js','utf8');
assert(worker.includes("type:['0A','0B']")); assert(store.includes("case '0A':")&&store.includes("case '0B':"));
assert(worker.includes('bare 6자리')||worker.includes('bare-code')); assert(store.includes('tradeLike'));
console.log('OFFICIAL_REALTIME_ROUTE_CHECK PASS: official 0A mapping + runtime 0A/0B compatibility probe');
