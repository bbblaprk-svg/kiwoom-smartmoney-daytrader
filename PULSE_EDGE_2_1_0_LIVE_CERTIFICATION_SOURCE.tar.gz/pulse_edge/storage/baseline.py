from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from statistics import fmean
from threading import RLock
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")


def minute_bucket(when: datetime) -> int:
    local = when.astimezone(KST)
    return local.hour * 60 + local.minute


class SameTimeBaselineStore:
    """PULSE-owned per-minute baseline for rolling 5-minute traded money.

    Current-day observations are buffered/written for future sessions but are
    explicitly excluded from same-day lookups.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._pending: dict[tuple[str, str, str, int], tuple[float, str]] = {}
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS money_5m_baseline (
                venue TEXT NOT NULL,
                symbol TEXT NOT NULL,
                trade_date TEXT NOT NULL,
                minute_bucket INTEGER NOT NULL,
                money_5m REAL NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (venue, symbol, trade_date, minute_bucket)
            )
            """
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_money_lookup ON money_5m_baseline(venue, symbol, minute_bucket, trade_date DESC)"
        )
        self._conn.commit()

    def close(self) -> None:
        self.flush()
        with self._lock:
            self._conn.close()

    def observe(self, venue: str, symbol: str, when: datetime, money_5m: float) -> None:
        if money_5m < 0:
            return
        local = when.astimezone(KST)
        key = (venue, symbol, local.date().isoformat(), minute_bucket(local))
        with self._lock:
            self._pending[key] = (float(money_5m), local.isoformat())

    def flush(self) -> int:
        with self._lock:
            rows = [(*key, value[0], value[1]) for key, value in self._pending.items()]
            self._pending.clear()
            if not rows:
                return 0
            self._conn.executemany(
                """
                INSERT INTO money_5m_baseline(venue, symbol, trade_date, minute_bucket, money_5m, updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(venue, symbol, trade_date, minute_bucket)
                DO UPDATE SET money_5m=excluded.money_5m, updated_at=excluded.updated_at
                """,
                rows,
            )
            self._conn.commit()
            return len(rows)

    def get_same_time_money(
        self,
        venue: str,
        symbol: str,
        when: datetime,
        lookback_days: int = 20,
    ) -> tuple[float | None, int]:
        local = when.astimezone(KST)
        with self._lock:
            rows = self._conn.execute(
                """
                SELECT money_5m
                FROM money_5m_baseline
                WHERE venue=? AND symbol=? AND minute_bucket=? AND trade_date < ?
                ORDER BY trade_date DESC
                LIMIT ?
                """,
                (venue, symbol, minute_bucket(local), local.date().isoformat(), int(lookback_days)),
            ).fetchall()
        values = [float(r[0]) for r in rows if r and r[0] is not None]
        return (fmean(values), len(values)) if values else (None, 0)

    def count_rows(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) FROM money_5m_baseline").fetchone()
        return int(row[0]) if row else 0

    def distinct_days(self, venue: str, symbol: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(DISTINCT trade_date) FROM money_5m_baseline WHERE venue=? AND symbol=?",
                (venue, symbol),
            ).fetchone()
        return int(row[0]) if row else 0
