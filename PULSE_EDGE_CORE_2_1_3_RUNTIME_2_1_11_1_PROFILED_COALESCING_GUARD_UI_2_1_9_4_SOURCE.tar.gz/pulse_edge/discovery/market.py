from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any, Awaitable, Callable, Protocol

from pulse_edge.core.models import Venue
from pulse_edge.features.benchmark import BenchmarkMapper, MarketClass
from pulse_edge.feed.rest import RestPage
from pulse_edge.session.router import SessionPhase, SessionRouter


class RestLike(Protocol):
    async def post(
        self,
        api_id: str,
        path: str,
        body: dict[str, Any],
        cont_yn: str | None = None,
        next_key: str | None = None,
    ) -> RestPage: ...


SubscribeHook = Callable[[list[str]], Awaitable[None]]


class DiscoverySource(StrEnum):
    BID_SURGE = "BID_SURGE"
    BALANCE_RATIO_SURGE = "BALANCE_RATIO_SURGE"
    VOLUME_SURGE = "VOLUME_SURGE"


@dataclass(frozen=True)
class DiscoveryEvent:
    source: DiscoverySource
    symbol: str
    name: str | None
    market: MarketClass
    venue: Venue
    observed_at: datetime
    source_rank: int
    source_metric: float | None
    raw: dict[str, Any]


def _num(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).replace(",", "").replace("%", "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _symbol(row: dict[str, Any]) -> str:
    value = str(row.get("stk_cd") or row.get("stk_code") or "").strip()
    if value.endswith("_NX"):
        value = value[:-3]
    digits = "".join(ch for ch in value if ch.isdigit())
    return digits[:6] if len(digits) >= 6 else value[:6]


def _metric(row: dict[str, Any]) -> float | None:
    for key in (
        "sdnin_rt",
        "req_rt",
        "trde_qty_rt",
        "flu_rt",
        "rate",
        "rt",
    ):
        val = _num(row.get(key))
        if val is not None:
            return val
    return None


class MarketDiscoveryService:
    """Current-event supply only.

    This service intentionally calls only three acceleration-oriented rank APIs.
    It has no score, selection state, persistence, or previous-session restore path.
    """

    API_IDS = ("ka10021", "ka10022", "ka10023")

    def __init__(
        self,
        rest: RestLike,
        session_router: SessionRouter,
        benchmark_mapper: BenchmarkMapper,
        subscribe_hook: SubscribeHook | None = None,
        max_events: int = 2000,
    ) -> None:
        self.rest = rest
        self.session_router = session_router
        self.benchmark_mapper = benchmark_mapper
        self.subscribe_hook = subscribe_hook
        self.recent_events: deque[DiscoveryEvent] = deque(maxlen=max_events)
        self.last_scan_at: datetime | None = None
        self.last_error: str | None = None
        self.scan_count = 0
        self.api_call_count: dict[str, int] = {x: 0 for x in self.API_IDS}

    async def scan_current(self, when: datetime | None = None) -> list[DiscoveryEvent]:
        now = when or datetime.now(timezone.utc)
        phase = self.session_router.phase_at(now)
        plans = self._plans(phase)
        if not plans:
            self.last_scan_at = now
            return []

        output: list[DiscoveryEvent] = []
        try:
            for venue, exchange in plans:
                for market_code, market_class in (("001", MarketClass.KOSPI), ("101", MarketClass.KOSDAQ)):
                    output.extend(await self._scan_market(venue, exchange, market_code, market_class, now))
            self.last_error = None
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            self.last_scan_at = now
            self.scan_count += 1

        for event in output:
            self.recent_events.append(event)
            self.benchmark_mapper.register(event.symbol, event.market)

        if self.subscribe_hook and output:
            items: set[str] = set()
            for event in output:
                if event.venue == Venue.NXT:
                    items.add(f"{event.symbol}_NX")
                    # KRX alias is needed for 08:50 expected-execution continuity.
                    items.add(event.symbol)
                else:
                    items.add(event.symbol)
            if items:
                await self.subscribe_hook(sorted(items))
        return output

    def _plans(self, phase: SessionPhase) -> list[tuple[Venue, str]]:
        if phase in {SessionPhase.NXT_PRE, SessionPhase.NXT_AFTER, SessionPhase.NXT_LATE_SESSION}:
            return [(Venue.NXT, "2")]
        if phase == SessionPhase.MARKET_MAIN:
            # KRX current-decision discovery is KRX-only during the overlapping main session.
            # NXT is evaluated by the independent NXT-native pipeline and is rediscovered
            # in NXT_AFTER/NXT_LATE_SESSION. This prevents NXT rows from entering the
            # KRX SMART-MONEY -> CONFLUENCE -> PRE-BUY path and halves rank-API pressure.
            return [(Venue.KRX, "1")]
        # Opening auction uses the already-discovered NXT names and KRX expected-execution stream.
        return []

    async def _scan_market(
        self,
        venue: Venue,
        exchange: str,
        market_code: str,
        market_class: MarketClass,
        observed_at: datetime,
    ) -> list[DiscoveryEvent]:
        calls = [
            (
                DiscoverySource.BID_SURGE,
                "ka10021",
                {
                    "mrkt_tp": market_code,
                    "trde_tp": "1",
                    "sort_tp": "2",
                    "tm_tp": "1",
                    "trde_qty_tp": "5",
                    "stk_cnd": "1",
                    "stex_tp": exchange,
                },
                "bid_req_sdnin",
            ),
            (
                DiscoverySource.BALANCE_RATIO_SURGE,
                "ka10022",
                {
                    "mrkt_tp": market_code,
                    "rt_tp": "1",
                    "tm_tp": "1",
                    "trde_qty_tp": "5",
                    "stk_cnd": "1",
                    "stex_tp": exchange,
                },
                "req_rt_sdnin",
            ),
            (
                DiscoverySource.VOLUME_SURGE,
                "ka10023",
                {
                    "mrkt_tp": market_code,
                    "sort_tp": "2",
                    "tm_tp": "1",
                    "trde_qty_tp": "5",
                    "tm": "1",
                    "stk_cnd": "20",
                    "pric_tp": "0",
                    "stex_tp": exchange,
                },
                "trde_qty_sdnin",
            ),
        ]
        out: list[DiscoveryEvent] = []
        for source, api_id, body, response_key in calls:
            page = await self.rest.post(api_id, "/api/dostk/rkinfo", body)
            self.api_call_count[api_id] += 1
            rows = page.body.get(response_key, []) or []
            if not isinstance(rows, list):
                continue
            for idx, row in enumerate(rows, start=1):
                if not isinstance(row, dict):
                    continue
                symbol = _symbol(row)
                if not symbol:
                    continue
                out.append(
                    DiscoveryEvent(
                        source=source,
                        symbol=symbol,
                        name=str(row.get("stk_nm")) if row.get("stk_nm") is not None else None,
                        market=market_class,
                        venue=venue,
                        observed_at=observed_at,
                        source_rank=idx,
                        source_metric=_metric(row),
                        raw={k: row.get(k) for k in ("stk_cd", "stk_nm", "sdnin_rt", "req_rt", "trde_qty_rt") if k in row},
                    )
                )
        return out

    def recent(self, limit: int = 100) -> list[DiscoveryEvent]:
        limit = max(1, min(int(limit), self.recent_events.maxlen or 2000))
        return list(self.recent_events)[-limit:]
