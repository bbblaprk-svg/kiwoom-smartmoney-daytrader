from types import SimpleNamespace
from pulse_edge.presentation import hidden_gem_display_key, eligible_now

def c(**kw):
    d=dict(name='X',sensor_only=False,data_status='LIVE',stage='WATCH',precursor_stage='NONE',energy_stage='OBSERVE',
           energy_stored=60,remaining_energy=45,flow_pressure_score=60,sell_response_failure=55,supply_decay_score=50,
           flow_dislocation=10,total_score=60,too_late=False,pre_release_ready=False,discovery_phase='TRACE',
           pre_release_score=60,release_imminence=55,release_convergence_score=55,purity_score=70)
    d.update(kw); return SimpleNamespace(**d)

def test_release_coil_orders_above_trace():
    assert hidden_gem_display_key(c(precursor_stage='RELEASE COIL',discovery_phase='BUILDING')) > hidden_gem_display_key(c())

def test_trace_is_visible_but_too_late_is_not():
    assert eligible_now(c())
    assert not eligible_now(c(too_late=True,discovery_phase='TOO LATE'))
