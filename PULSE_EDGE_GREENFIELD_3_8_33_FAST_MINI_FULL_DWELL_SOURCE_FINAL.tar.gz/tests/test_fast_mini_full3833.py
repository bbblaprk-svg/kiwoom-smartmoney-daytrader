from pulse_edge.config import Settings
from pulse_edge.models import Candidate

def test_three_stage_dwell_is_bounded_and_cpu_safe():
    s=Settings()
    assert s.ws_background_reserve_items == 14
    assert s.ws_dynamic_max_items == 34
    assert s.ws_quote_focus_items == 4
    assert 2.0 <= s.background_rotate_sec <= 4.0
    assert 10.0 <= s.probe_mini_dwell_sec <= 20.0
    assert s.probe_mid_dwell_sec == 45.0
    assert s.probe_high_dwell_sec == 90.0

def test_probe_acceleration_and_hidden_purity_are_exposed():
    f=Candidate.__dataclass_fields__
    assert "probe_acceleration" in f
    assert "hidden_gem_purity_score" in f

def test_acceleration_can_help_early_promotion():
    s=Settings()
    assert s.probe_acceleration_min_score > 0
    assert s.probe_mini_score < s.probe_trace_min_score < s.probe_min_score
