
from pathlib import Path
from pulse_edge.config import Settings

def test_reconnect_quiet_is_signal_only_guard():
    s=Settings(); assert s.reconnect_signal_quiet_sec>=10
    r=Path('pulse_edge/runtime.py').read_text()
    assert "now-self.ws.connected_since < self.s.reconnect_signal_quiet_sec" in r
    assert r.index("raw=self.scorer.rank") < r.index("signal_quiet=")

def test_ws_records_connect_epoch():
    s=Path('pulse_edge/feed/kiwoom.py').read_text()
    assert 'connected_since=time.time()' in s
