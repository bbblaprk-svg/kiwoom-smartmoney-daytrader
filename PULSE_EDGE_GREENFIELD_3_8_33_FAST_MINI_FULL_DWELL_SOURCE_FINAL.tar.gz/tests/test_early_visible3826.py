from types import SimpleNamespace as NS
from pulse_edge.presentation import eligible_now


def c(**kw):
    d=dict(name='테스트',sensor_only=False,data_status='LIVE',stage='WATCH',precursor_stage='OBSERVE',
           energy_stage='OBSERVE',energy_stored=48.0,remaining_energy=32.0,flow_pressure_score=53.0,
           sell_response_failure=20.0,supply_decay_score=20.0,flow_dislocation=0.0,total_score=61.0,too_late=False)
    d.update(kw); return NS(**d)

def test_early_latent_observe_is_visible_without_relaxing_action_stage():
    x=c()
    assert eligible_now(x)
    assert x.stage=='WATCH' and x.energy_stage=='OBSERVE'

def test_early_latent_observe_requires_two_energy_axes_and_remaining_energy():
    assert not eligible_now(c(flow_pressure_score=49, energy_stored=44))
    assert not eligible_now(c(remaining_energy=24.9))
    assert not eligible_now(c(total_score=57.9))

def test_early_latent_observe_never_shows_stale_sensor_or_too_late():
    assert not eligible_now(c(data_status='STALE'))
    assert not eligible_now(c(sensor_only=True))
    assert not eligible_now(c(too_late=True))
