from pulse_edge.config import Settings
from pulse_edge.models import Candidate

def test_coil_persistence_settings_are_cpu_bounded():
    s=Settings()
    assert s.latent_persist_energy_gain_min >= 0
    assert s.latent_persist_supply_gain_min >= 0
    assert s.coil_velocity_min >= 0
    assert s.ws_quote_focus_items == 4
    assert s.ws_dynamic_max_items == 34

def test_candidate_exposes_coil_truth_fields():
    names=Candidate.__dataclass_fields__
    for x in ("energy_persistence","supply_persistence","coil_velocity","upper_supply_veto"):
        assert x in names
