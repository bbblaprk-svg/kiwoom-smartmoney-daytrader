from pulse_edge.config import Settings

def test_discovery_dwell_and_seed_width_are_bounded_but_earlier():
    s=Settings()
    assert 2.0 <= s.background_rotate_sec <= 4.0
    assert s.probe_min_score <= 45
    assert s.probe_rest_confirm_min_score >= 60
    assert s.early_absorption_min_observed_sec == 60
    assert s.ranking_bucket_limit >= 20
    assert s.ws_quote_focus_items == 4
    assert s.discovery_fresh_slots >= 8
