
from pulse_edge.models import Candidate

def test_candidate_has_zero_io_pre_release_fields():
    fields=Candidate.__dataclass_fields__
    for name in ("energy_acceleration","supply_decay_acceleration","release_suppression_score","release_convergence_score","pre_release_score","pre_release_ready"):
        assert name in fields

def test_pre_release_config_is_bounded():
    from pulse_edge.config import Settings
    s=Settings()
    assert 60 <= s.pre_release_score_min <= 80
    assert s.pre_release_remaining_min >= 40
    assert s.pre_release_max_released <= 60
    assert s.ws_quote_focus_items == 4
