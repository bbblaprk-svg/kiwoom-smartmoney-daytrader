from pathlib import Path
from pulse_edge.config import Settings

def test_adaptive_floor_is_downward_only_from_legacy():
    f=Path('pulse_edge/engine/features.py').read_text()
    assert 'adaptive_floor=min(float(bid_legacy_cap_krw)' in f
    assert 'max(float(bid_abs_floor_krw), total_value*float(bid_sell_ratio_min))' in f
    assert 'sell_value>=20_000_000' not in f

def test_early_state_is_informational_only():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert "'EARLY PRESSURE ABSORBED'" in r
    assert 'release_ready=bool(pressure_absorbed and' in r
    assert 'pressure_absorbed=bool(hold and sell_pressure_evidence' in r

def test_core_thresholds_unchanged():
    s=Settings()
    assert s.supply_tight_min_conditions==8
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.pressure_sell_value_floor==20_000_000.0
    assert s.bid_absorption_abs_floor_krw==5_000_000.0
    assert s.bid_absorption_sell_ratio_min==0.20
    assert s.early_absorption_min_observed_sec==60.0
