from pulse_edge.config import Settings

def test_fast_scan_dwell_keeps_capacity_and_shortens_cold_scan():
    s=Settings()
    assert s.ws_background_reserve_items == 14
    assert 2.0 <= s.background_rotate_sec <= 4.0
    assert s.probe_mid_dwell_sec == 45.0
    assert s.probe_high_dwell_sec == 90.0
    assert s.probe_retained_background_max <= 4
    assert s.fast_scan_min_fresh_slots >= 10
    assert s.fast_scan_min_fresh_slots + s.probe_retained_background_max <= s.ws_background_reserve_items

def test_fast_scan_does_not_expand_heavy_feeds():
    s=Settings()
    assert s.ws_dynamic_max_items == 34
    assert s.ws_quote_focus_items == 4
