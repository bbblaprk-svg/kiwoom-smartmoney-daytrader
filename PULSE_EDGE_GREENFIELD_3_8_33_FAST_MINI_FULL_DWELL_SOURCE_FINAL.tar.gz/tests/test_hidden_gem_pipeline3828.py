
from pulse_edge.config import Settings
from pulse_edge.engine.features import quick_probe_metrics
from pulse_edge.models import SymbolState,Trade
from pulse_edge.presentation import eligible_now
from types import SimpleNamespace
import time

def test_pipeline_resource_bounds_and_early_observation():
    s=Settings()
    assert s.ws_dynamic_max_items==34
    assert s.ws_quote_focus_items==4
    assert s.probe_retained_background_max <= s.ws_background_reserve_items-4
    assert s.early_absorption_min_observed_sec==60
    assert s.quote_min_focus_sec>=30
    assert s.probe_trace_min_score < s.probe_min_score < s.probe_rest_confirm_min_score

def test_probe_requires_multiple_axes_for_meaningful_trace():
    n=time.time(); st=SymbolState('123456',price=100,change_rate=0.5)
    st.trades.extend([Trade(n-3,100,10,buy_exec=10,sell_exec=0,strength=120),Trade(n-2,100.1,10,buy_exec=10,sell_exec=0,strength=120)])
    m=quick_probe_metrics(st,20,n)
    assert m['trade_count']==2 and m['score']<45

def test_trace_visibility_never_bypasses_data_truth_or_too_late():
    base=dict(name='ABC',sensor_only=False,data_status='LIVE',stage='WATCH',precursor_stage='OBSERVE',energy_stage='OBSERVE',energy_stored=45,remaining_energy=35,flow_pressure_score=48,sell_response_failure=42,supply_decay_score=38,flow_dislocation=5,total_score=56,too_late=False,discovery_phase='TRACE')
    assert eligible_now(SimpleNamespace(**base))
    assert not eligible_now(SimpleNamespace(**{**base,'data_status':'STALE'}))
    assert not eligible_now(SimpleNamespace(**{**base,'too_late':True,'discovery_phase':'TOO LATE'}))
