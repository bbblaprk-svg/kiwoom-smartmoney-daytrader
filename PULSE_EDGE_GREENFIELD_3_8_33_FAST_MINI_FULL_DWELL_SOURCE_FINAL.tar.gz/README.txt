PULSE EDGE 3.8.26_EARLY_VISIBLE_PIPELINE
3.8.19 대비 변경: 점수 계산에서 None으로 빠지는 네 가지 사유를 기록하고 기존 진단 줄에 표시.
점수, 진입/탈락 조건, 신선도, 구독, 저장소 처리, 배포 안전 기준은 변경하지 않음.
API: no_score_reasons, evaluated_at, subscription_details[].evaluation 추가.
NO_SCORE를 사유 있는 NOT_QUALIFIED와 평가 대기 AWAITING_EVALUATION으로 구분.
평가 시점의 스냅샷이므로 현재 수신 상태와 시각이 다를 수 있음.
이번 수정은 진단 누락 수정이며 후보 수 증가나 탐지 성과를 보장하지 않음.
서버 재배포 전 Dockerfile/소스/배포 스크립트 세 파일을 같은 디렉터리에 배치.
Dockerfile 이름에 확장자를 붙이지 말 것. 스크립트는 sudo bash로 실행.
실제 Docker 빌드와 Kiwoom/NXT 실시간 검증은 배포 스크립트가 수행.


3.8.23 LATENT ENERGY CORE
- Reuses existing live trade/quote/investor data only; no extra WS/REST subscriptions.
- Adds FLOW PRESSURE, PRICE REACTION, FLOW DISLOCATION, SELL RESPONSE FAILURE and SUPPLY DECAY.
- Separates ENERGY STORED / ENERGY RELEASED / REMAINING ENERGY.
- Adds RELEASE IMMINENCE and dynamic TOO LATE based on actual release/exhaustion, not a simple rise threshold.
- Same-venue cross-sectional percentiles are computed in a bounded second pass over the existing evaluated pool.
- +3% remains the ordinary PRE ceiling; up to +7% can remain eligible only when remaining energy is high, released energy is limited, and TOO LATE is false.
- Existing DATA TRUTH / PRICE HOLD / spread / cross-source / market-red / PRE sequence hard gates remain in force.
- ENERGY LOADED and RELEASE WINDOW are observational precursor states; they do not independently grant A/B suitability.

3.8.24 NXT 08:00 bootstrap fix:
- Official NXT ranking responses prove current NXT eligibility even when universe nxtEnable is stale/missing.
- Venue transitions clear previous-market websocket slots before repopulation.
- Existing NOW TOP10 is fed by NXT 08:00~08:50, KRX 09:00~15:30, NXT 15:40~20:00. No new table.
- Latent-energy scoring and hard gates unchanged.


3.8.25 COMMON NOW PIPELINE
- Fixes common KRX/NXT empty-board path without loosening PRE/action gates.
- Active venue only consumes TOP20 rank slots; inactive venue states remain for history/context.
- sensor_only market leaders are retained in last_evaluated diagnostics but excluded from hidden-gem TOP20.
- strong latent ENERGY BUILDING candidates are visible as WATCH observations.
- existing four quote slots are reused with slow newcomer rotation; no capacity increase.
- diagnostics expose live_ranked/display_eligible/sensor_only counts.

3.8.27 DISCOVERY_DWELL_FIX: widened ranking seeds, 12s background dwell, 45-point trace promotion, 60s early observation, 8 fresh priority slots; PRE/DATA TRUTH/PRICE HOLD hard gates unchanged.
\n3.8.28 HIDDEN_GEM_PIPELINE_REBUILD: adaptive whole-market dwell, multi-axis probe promotion, velocity traces, information-value quote focus with minimum residency, 60s early absorption observation, TRACE visibility separated from ENTRY, 10/20/30m+MFE/MAE/+2/+3/+5 performance ledger. PRE/PRICE HOLD/DATA TRUTH and KRX/NXT session authority are unchanged.\n
3.8.29 PRE_RELEASE_TENSION: zero-I/O temporal latent-energy acceleration, release suppression, balanced-axis convergence and RELEASE COIL stage. No new REST/WS/DB load; PRE/DATA TRUTH/PRICE HOLD gates unchanged.

3.8.30 COIL_PERSISTENCE_VETO: three-sample O(1) persistence, coil velocity, upper-supply/replenishment veto; no extra API/WS/DB polling; PRE/DATA TRUTH hard gates unchanged.\n
3.8.31 HIDDEN_GEM_VISIBLE_RANK: RELEASE COIL promoted in scorer rank; NOW table fills from already-evaluated LIVE eligible candidates without new scoring/I/O; UI sequence explicitly TRACE→BUILDING→LOADED→COIL→WINDOW→PRE. PRE/DATA TRUTH gates unchanged.

3.8.32 FAST_SCAN_DWELL: 14 background slots unchanged; normal symbols rotate every 3s, suspicious TRACE symbols dwell 45-90s, held background capped at 4 so >=10 fresh scan slots remain. No new REST/DB/quote feeds; PRE/DATA TRUTH hard gates unchanged.\n
3.8.33 FAST_MINI_FULL_DWELL: 3s FAST -> 15s MINI -> 45/90s FULL dwell, probe acceleration-weighted promotion, cross-section COIL/WINDOW re-evaluation, separate hidden-gem purity vs release-imminence display. WS34/background14/quote4 unchanged; no new REST/DB feed; PRE/DATA TRUTH gates unchanged.
