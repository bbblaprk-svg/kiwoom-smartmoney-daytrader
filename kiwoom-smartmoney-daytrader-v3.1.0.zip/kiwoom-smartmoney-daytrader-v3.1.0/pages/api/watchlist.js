const { getItem, setItem } = require('../../lib/store');
const {
  CORE_STOCKS, MAX_FOCUS_USER_STOCKS, MAX_LIGHT_USER_STOCKS,
  mergeWatchlist, normalizeStock, sanitizeUserStocks, countUserTiers, toKiwoomCode,
} = require('../../lib/stocks');
const { getStockInfo } = require('../../lib/kiwoomClient');
const { requireAuth } = require('../../lib/auth');

const KEY = 'watchlist:user';
async function loadUser() { return sanitizeUserStocks((await getItem(KEY)) || []); }

module.exports = async function handler(req, res) {
  if (!requireAuth(req, res)) return;
  try {
    if (req.method === 'GET') {
      const user = await loadUser();
      return res.status(200).json({
        core: CORE_STOCKS, user, watchlist: mergeWatchlist(user), counts: countUserTiers(user),
        maxFocusUserStocks: MAX_FOCUS_USER_STOCKS, maxLightUserStocks: MAX_LIGHT_USER_STOCKS,
      });
    }
    if (req.method === 'POST') {
      const user = await loadUser();
      let stock = normalizeStock(req.body || {}, false);
      if (CORE_STOCKS.some((item) => item.code === stock.code)) return res.status(409).json({ error: '고정 종목은 이미 집중감시 중입니다.' });
      const existingIndex = user.findIndex((item) => item.code === stock.code);
      const countsWithoutExisting = countUserTiers(existingIndex >= 0 ? user.filter((_, i) => i !== existingIndex) : user);
      if (stock.tier === 'FOCUS' && countsWithoutExisting.focus >= MAX_FOCUS_USER_STOCKS) {
        return res.status(400).json({ error: `집중입력 종목은 최대 ${MAX_FOCUS_USER_STOCKS}개입니다.` });
      }
      if (stock.tier === 'LIGHT' && countsWithoutExisting.light >= MAX_LIGHT_USER_STOCKS) {
        return res.status(400).json({ error: `경량입력 종목은 최대 ${MAX_LIGHT_USER_STOCKS}개입니다.` });
      }
      const info = await getStockInfo(toKiwoomCode(stock));
      const officialName = String(info.stk_nm || info.stk_name || '').trim();
      if (officialName) stock = { ...stock, name: officialName.slice(0, 30) };
      if (existingIndex >= 0) user[existingIndex] = stock; else user.push(stock);
      const saved = sanitizeUserStocks(user);
      await setItem(KEY, saved);
      return res.status(201).json({ stock, watchlist: mergeWatchlist(saved), counts: countUserTiers(saved) });
    }
    if (req.method === 'DELETE') {
      const code = String(req.query.code || '').replace(/\D/g, '').slice(0, 6);
      if (CORE_STOCKS.some((item) => item.code === code)) return res.status(400).json({ error: '고정 4종목은 삭제할 수 없습니다.' });
      const user = (await loadUser()).filter((item) => item.code !== code);
      await setItem(KEY, user);
      return res.status(200).json({ deleted: code, watchlist: mergeWatchlist(user), counts: countUserTiers(user) });
    }
    res.setHeader('Allow', ['GET', 'POST', 'DELETE']);
    return res.status(405).json({ error: '지원하지 않는 요청입니다.' });
  } catch (error) {
    return res.status(500).json({ error: String(error.message || error) });
  }
};
