const { state } = require('../../lib/realtimeStore');

module.exports = function handler(req, res) {
  const connected = state.connection.status === 'connected';
  const stocks = [...state.stocks.values()];
  const focus = stocks.filter((stock) => stock.activeTier === 'FOCUS').length;
  const light = stocks.filter((stock) => stock.activeTier === 'LIGHT').length;
  const promoted = stocks.filter((stock) => Number(stock.promotedUntil || 0) > Date.now()).length;
  const closeSnapshots = stocks.filter((stock) => Number(stock.marketSnapshot && stock.marketSnapshot.krx && stock.marketSnapshot.krx.close || 0) > 0).length;

  res.status(200).json({
    ok: connected,
    status: state.connection.status,
    lastMessageAt: state.connection.lastMessageAt,
    subscribed: state.connection.subscribed.length,
    focus,
    light,
    promoted,
    closeSnapshots,
    lastSnapshotAt: state.connection.lastSnapshotAt || null,
    snapshotStatus: state.connection.snapshotStatus || null,
    sseClients: state.sseClients || 0,
    serverTime: new Date().toISOString(),
  });
};
