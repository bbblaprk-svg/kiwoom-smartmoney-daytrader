# Lightsail v3.1.0 업데이트

GitHub 저장소 최상위에 다음 세 파일을 올립니다.

- `kiwoom-smartmoney-daytrader-v3.1.0.zip`
- `Dockerfile`
- `update-lightsail-v3.1.0.sh`

저장소가 Private이면 업데이트 동안만 Public으로 전환한 뒤, Lightsail SSH에서 다음 한 줄을 실행합니다.

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/bbblaprk-svg/kiwoom-smartmoney-daytrader/main/update-lightsail-v3.1.0.sh)
```

스크립트는 기존 `.env`를 재사용하므로 APP KEY와 Secret을 다시 입력하지 않습니다. 새 컨테이너의 `/api/health`가 정상일 때만 기존 컨테이너를 제거하며, 실패하면 자동으로 기존 버전으로 되돌립니다.

완료 후 앱에서 `종가 동기화`를 누르고 `종가 확보 4/4`와 각 종목의 KRX 종가·NXT 최종가·종가판단을 확인합니다. 확인 후 GitHub 저장소를 다시 Private으로 바꿉니다.
