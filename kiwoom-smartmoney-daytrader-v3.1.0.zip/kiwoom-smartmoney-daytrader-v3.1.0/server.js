const http = require('http');
const next = require('next');
const { startKiwoomRealtime } = require('./worker/kiwoomRealtime');

const dev = process.env.NODE_ENV !== 'production';
const hostname = process.env.HOST || '0.0.0.0';
const port = Number(process.env.PORT || 3000);
const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  if (String(process.env.KIWOOM_REALTIME_ENABLED || 'true').toLowerCase() !== 'false') {
    startKiwoomRealtime();
  }
  http.createServer((req, res) => handle(req, res)).listen(port, hostname, () => {
    console.log(`Kiwoom day-trader listening on http://${hostname}:${port}`);
  });
}).catch((error) => {
  console.error(error);
  process.exit(1);
});
