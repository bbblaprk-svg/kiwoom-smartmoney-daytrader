const assert = require('assert');
const {
  CORE_STOCKS, mergeWatchlist, splitWatchlist, toKiwoomCode,
  MAX_FOCUS_USER_STOCKS, MAX_LIGHT_USER_STOCKS,
} = require('../lib/stocks');
const { evaluateSignal } = require('../lib/signalEngine');
const { accountRisk, calculateNetPnl } = require('../lib/risk');
const realtime = require('../lib/realtimeStore');
const { mergeSettings } = require('../lib/settings');
const { dailyRowsFrom, calculateIndicators, evaluateCloseDecision, closingFlowFromLive, marketPhase } = require('../lib/marketSnapshot');

assert.strictEqual(CORE_STOCKS.length, 4);
assert.strictEqual(MAX_FOCUS_USER_STOCKS, 4);
assert.strictEqual(MAX_LIGHT_USER_STOCKS, 4);
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'SOR' }), '005930_AL');
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'NXT' }), '005930_NX');

const list = mergeWatchlist([
  ...Array.from({ length: 5 }, (_, i) => ({ code: `1${String(i).padStart(5, '0')}`, name: `집중${i}`, tier: 'FOCUS', market: 'SOR' })),
  ...Array.from({ length: 5 }, (_, i) => ({ code: `2${String(i).padStart(5, '0')}`, name: `경량${i}`, tier: 'LIGHT', market: 'SOR' })),
]);
const split = splitWatchlist(list);
assert.strictEqual(split.focus.length, 8, '고정4+사용자집중4');
assert.strictEqual(split.light.length, 4, '사용자경량4');

const activeTime = new Date('2026-07-31T05:10:00.000Z'); // KST 14:10
const strong = evaluateSignal({
  price: 100800, vwap: 100000, vwapDistancePct: 0.8,
  turnover1m: 500_000_000, turnover15s: 120_000_000,
  tradeStrength: 145, buyRatio: 66, rvol1m: 2.2,
  netBuyAmount5s: 90_000_000, netBuyAmount15s: 210_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 350_000_000, largeBuyCount1m: 4, largeSellCount1m: 0,
  spreadBps: 8, orderbookImbalance: 1.7, bidReplenishRatio: 0.18, askWithdrawalRatio: 0.12,
  programNetAmount: 500_000_000, programVelocity10s: 160_000_000, programTurnedPositive: 1,
  foreignNetDelta: 5000, breakout: true, vwapReclaim: true,
  momentum1mPct: 0.7, drawdownFromHighPct: -0.1,
  recentHigh: 100800, recentLow: 99500,
  smartMoneyState: 'EXPANSION', dataCompleteness: 100, activeTier: 'FOCUS',
  relativeStrengthPct: 1.2, marketBreadthPct: 58, marketAboveVwap: 1,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(strong.action, 'BUY', JSON.stringify(strong));
assert(strong.qualityScore >= 85);
assert.strictEqual(strong.qualityIsProbability, false);

const light = evaluateSignal({ ...strong, activeTier: 'LIGHT' }, {}, activeTime);
assert.notStrictEqual(light.action, 'BUY', '경량 종목은 자동승격 전 확정매수 불가');

const vi = evaluateSignal({ price: 100000, vwap: 100000, spreadBps: 10, viActive: true, dataCompleteness: 100, activeTier: 'FOCUS', updatedAt: activeTime.getTime() }, {}, activeTime);
assert.strictEqual(vi.action, 'SELL');
assert.strictEqual(vi.urgency, 'critical');

const today = new Date();
const risk = accountRisk([
  { status: 'closed', realizedPnl: -600000, exitTime: new Date(today.getTime() - 60_000).toISOString() },
  { status: 'closed', realizedPnl: -500000, exitTime: new Date(today.getTime() - 120_000).toISOString() },
], { dayStartingEquity: 100000000, dailyMaxLossPct: -1, maxConsecutiveLosses: 3 });
assert.strictEqual(Number(risk.dailyPnlPct.toFixed(2)), -1.1);
assert.strictEqual(risk.halted, true);

const net = calculateNetPnl({ avgPrice: 100000, quantity: 10 }, 101000, { buyFeePct: 0.01, sellFeePct: 0.02, sellTaxPct: 0.15 });
assert.strictEqual(net.grossPnl, 10000);
assert(Math.abs(net.realizedPnl - 8183) < 1e-9);

const settings = mergeSettings({ signal: { minBuyScore: 40, confirmTicks: 9, confirmHoldMs: -1 } });
assert.strictEqual(settings.signal.minBuyScore, 65);
assert.strictEqual(settings.signal.confirmTicks, 6);
assert.strictEqual(settings.signal.confirmHoldMs, 0);

const dailyRows = dailyRowsFrom({ stk_dt_pole_chart_qry: [
  { cur_prc: '70100', trde_qty: '9263135', trde_prica: '648525', dt: '20260731', open_pric: '69800', high_pric: '70500', low_pric: '69600' },
  { cur_prc: '69500', trde_qty: '11526724', trde_prica: '804642', dt: '20260730', open_pric: '70300', high_pric: '70400', low_pric: '69500' },
  ...Array.from({ length: 20 }, (_, index) => ({ cur_prc: String(69000 - index * 100), trde_qty: '7000000', trde_prica: '500000', dt: String(20260729 - index), open_pric: '69000', high_pric: '70000', low_pric: '68000' })),
] });
assert.strictEqual(dailyRows[0].close, 70100);
assert.strictEqual(dailyRows[0].tradeAmount, 648525000000);
const indicators = calculateIndicators(dailyRows);
assert(indicators.ma5 > 0 && indicators.ma20 > 0);
const closeSnapshot = {
  krx: { close: 70100, open: 69800, high: 70500, low: 69600, volume: 9263135, changePct: 0.86 },
  nxt: { available: true, close: 70400 }, nxtGapPct: 0.43, indicators,
};
const closeDecision = evaluateCloseDecision(closeSnapshot, { smartMoney: { state: 'TURN' }, program: { netAmount: 100000000 }, broker: { foreignNetDelta: 1 } }, settings.perStock['005930']);
assert(['CLOSE_BUY', 'HOLD'].includes(closeDecision.action), JSON.stringify(closeDecision));
assert.strictEqual(closeDecision.qualityIsProbability, false);
const closeFlow = closingFlowFromLive({
  updatedAt: activeTime.getTime(), smartMoney: { state: 'TURN', score: 82 },
  program: { netAmount: 100000000, netQty: 1000 }, broker: { foreignNet: 5000, foreignNetDelta: 500 },
});
assert.strictEqual(closeFlow.source, 'REALTIME_ACCUMULATED');
assert.strictEqual(closeFlow.smartMoneyState, 'TURN');
assert.strictEqual(closeFlow.programNetAmount, 100000000);
assert.strictEqual(marketPhase(new Date('2026-07-31T13:30:00.000Z')).code, 'ALL_CLOSED'); // KST 22:30

realtime.state.stocks.clear();
realtime.processRealtimeEntry({ type: '0B', item: '005930_AL', values: { '10': '100000', '15': '1000', '27': '100100', '28': '100000', '228': '130', '620': '99500', '9081': 'NXT' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
realtime.processRealtimeEntry({ type: '1h', item: '', values: { '9001': '005930_AL', '302': '삼성전자', '9068': '1', '1224': '' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
const stock = realtime.getSnapshot([{ code: '005930', name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true }]).stocks[0];
assert.strictEqual(stock.market, 'NXT');
assert.strictEqual(stock.signal.action, 'SELL');
assert.strictEqual(stock.signal.confirmed, true);

console.log('CHECK OK: 4+4+4 구독, 실시간 신호, 종가 스냅샷·종가판단, 위험관리');
