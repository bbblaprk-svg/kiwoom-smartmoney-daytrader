# v3.2.8 — PIPELINE GUARD V2 / COALESCED CLOSE SYNC

- 20:01 이후 KRX/NXT 미완료 동기화를 단일 pass로 합침
- KRX 종가시 NXT REST 호출 제거
- KRX 기본정보는 일봉 실패시만 fallback
- NXT 최종값은 WebSocket final 우선, REST 1회 fallback
- ka10059 기관/외인 우선, ka10008 외인상세 fallback-only
- close-sync state v5 및 reconnect cleanup map 초기화
- 실시간 WebSocket 처리와 종가 REST 복구를 계속 분리

# v3.2.7 — PIPELINE GUARD

- BUY 독립증거 게이트에서 execution+largeTrades를 동일 tape축으로 통합해 상관신호 이중가산 제거
- Smart Money TURN/MARKUP도 대형체결을 execution과 별도 독립축으로 세지 않고 프로그램/호가/가격/KRX·NXT 교차확인을 요구
- 새 설치 AUTO 시장선정 bootstrap 지원, 이후 AUTO LIGHT만 최대 2개/5분 보수적 교체
- LIGHT→FOCUS 승격에 전일 동시간 거래량비 보조축 추가(정밀피드 승격일 뿐 BUY 하드게이트는 불변)
- 모든 실시간 체결은 저장하고 고비용 신호평가만 체결 80ms/보조 180ms 기본 throttle
- quick promotion 경량경로로 burst 구간 이벤트루프 병목 완화
- 장중 추천 프로필 cache-only로 REST 직렬 폭주 차단
- 거래원(0F)은 스마트머니 보조증거로 유지하되 BUY 핵심피드 하드게이트에서 제외
- Smart Money 상태전환에 fresh trade/orderbook/program, EWMA 호가지지, 독립증거 수, persistence 요구
- 종가 공식수급 REST 우선, 신선 realtime fallback만 허용, 오래된 보존값은 display-only
- 학습 최소표본 60/12, 기본 보정 ±6, hard gate 불변
- BUY_ACTIVE를 BUY_MANAGE로 UI에 고정하고 데이터완전성/RR 표시
- health에 realtime type map/부하 telemetry와 BUY 엔진 정의와 일치한 smartMoneyReady 제공
- pipeline audit + 30종목 30,000 합성 이벤트 부하검사 추가

# v3.2.7 — CLOSE SYNC RESILIENCE

- KRX 15:32 실패 종목만 15:34/15:37/15:42/16:00 재시도
- NXT 20:01 실패 종목만 20:03/20:06/20:12/20:20 재시도
- 예약시각 서버 중단 시 재기동 즉시 catch-up
- 최종 예약 이후 제한적 5분 catch-up, 기본 총 7회
- 이전 유효 종가/일봉 보존과 오늘 공식 종가 확인 상태 분리
- 오늘 KRX 공식 종가 미확정 시 CLOSE_BUY 하드 차단
- 공식 수급 미확정 종목도 재시도 대상 유지
- watchlist 변경 시 장중 전체 REST 호출 제거
- `/api/health`에 closeSync/retry 상태 노출

# v3.2.7 — LOW TRAFFIC + MANAGED SIGNAL TABLE

- 장중 15분 전체 REST 스냅샷 제거
- KRX 15:32 / NXT 20:01 KST 자동 전체 종가동기화만 유지
- KRX/NXT WebSocket 실시간 수신 우선, stale일 때만 제한 REST 보조
- 정상장 관리신호 목표 4~6개: BUY 게이트는 유지하고 PRE-BUY/EARLY/안전 예비신호로 관리
- 약세장 상한 4, 강한장 상한 6
- 실시간 신호 관리 테이블 추가: 점수/현재가/진입기준가/수익률/등락률/KRX/NXT/스마트머니/신호시각
- 뉴스 1.5.1, Smart Money Behavior, KRX/NXT Dual Feed, Dual Close 및 승률학습 유지

## 3.2.9 — PHASED SMART MONEY
- Added SMART_NEG → SMART_NEUTRAL → SMART_BUILD → SMART_TURN → SMART_POS → SMART_CONFIRMED interpretation layer.
- 75+ candidates can remain PRE-BUY when core safety gates pass and Smart Money is merely unconfirmed, while negative Smart Money still vetoes entry.
- BUY remains hard-gated and requires confirmed Smart Money plus independent flow evidence.
- Added stage/remaining-condition metadata and PRE-BUY stage outcome recording at KRX official close.
