# Lightsail v3.1.16 FINAL 업데이트

GitHub 저장소 최상위에 다음 3개 파일을 올립니다.

```text
Dockerfile
kiwoom-smartmoney-daytrader-v3.1.16-FINAL.zip
update-lightsail-v3.1.16-FINAL.sh
```

업데이트 스크립트는 기존 `.env`와 `kiwoom-data` 볼륨을 유지하고, ZIP SHA256과 내부 SOURCE_MANIFEST를 검사합니다. AWS 빌드에서 `npm install`, 전체 회귀검사, 20종목 부하검사, Next.js build가 모두 성공한 경우에만 v3.1.16 컨테이너로 교체합니다. 실패하면 기존 앱을 자동 복구합니다.

v3.1.16은 데이터수집 경로가 아니라 판정 후 표시/기록/알림을 수익추구 중심으로 단순화한 버전입니다.
