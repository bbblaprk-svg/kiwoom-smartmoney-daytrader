const fs = require('fs');
const path = require('path');
const assert = require('assert');
const { spawnSync } = require('child_process');
const {
  CORE_STOCKS, mergeWatchlist, splitWatchlist, toKiwoomCode,
  MAX_FOCUS_USER_STOCKS, MAX_LIGHT_USER_STOCKS,
} = require('../lib/stocks');
const { evaluateSignal } = require('../lib/signalEngine');
const { accountRisk, calculateNetPnl } = require('../lib/risk');
const realtime = require('../lib/realtimeStore');
const { mergeSettings } = require('../lib/settings');
const { dailyRowsFrom, calculateIndicators, computeSnapshotCompleteness, evaluateCloseDecision, closingFlowFromLive, marketPhase } = require('../lib/marketSnapshot');

assert.strictEqual(CORE_STOCKS.length, 4);
assert.strictEqual(MAX_FOCUS_USER_STOCKS, 8);
assert.strictEqual(MAX_LIGHT_USER_STOCKS, 8);
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'SOR' }), '005930_AL');
assert.strictEqual(toKiwoomCode({ code: '005930', market: 'NXT' }), '005930_NX');


// Production must fail closed when app credentials are missing.
{
  const authPath = path.join(__dirname, '..', 'lib', 'auth.js');
  const missing = spawnSync(process.execPath, ['-e', `process.env.NODE_ENV='production'; delete process.env.APP_ACCESS_TOKEN; delete process.env.APP_SESSION_SECRET; require(${JSON.stringify(authPath)}).assertCredentials();`], { encoding: 'utf8' });
  assert.notStrictEqual(missing.status, 0, 'production boot must fail without app credentials');
  const valid = spawnSync(process.execPath, ['-e', `process.env.NODE_ENV='production'; process.env.APP_ACCESS_TOKEN='sample-access-token-123'; process.env.APP_SESSION_SECRET='0123456789abcdef0123456789abcdef0123456789abcdef'; require(${JSON.stringify(authPath)}).assertCredentials();`], { encoding: 'utf8' });
  assert.strictEqual(valid.status, 0, valid.stderr || 'valid production credentials rejected');
}

const list = mergeWatchlist([
  ...Array.from({ length: 10 }, (_, i) => ({ code: `1${String(i).padStart(5, '0')}`, name: `집중${i}`, tier: 'FOCUS', market: 'SOR' })),
  ...Array.from({ length: 10 }, (_, i) => ({ code: `2${String(i).padStart(5, '0')}`, name: `경량${i}`, tier: 'LIGHT', market: 'SOR' })),
]);
const split = splitWatchlist(list);
assert.strictEqual(split.focus.length, 12, '고정4+사용자집중8');
assert.strictEqual(split.light.length, 8, '사용자경량8');
assert.strictEqual(list.length, 20, '총 20종목 감시');

const activeTime = new Date('2026-07-31T05:10:00.000Z'); // KST 14:10
const strong = evaluateSignal({
  price: 100800, vwap: 100000, vwapDistancePct: 0.8,
  turnover1m: 500_000_000, turnover15s: 120_000_000,
  tradeStrength: 145, buyRatio: 66, rvol1m: 2.2,
  netBuyAmount5s: 90_000_000, netBuyAmount15s: 210_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 350_000_000, largeBuyCount1m: 4, largeSellCount1m: 0,
  spreadBps: 8, orderbookImbalance: 1.7, bidReplenishRatio: 0.18, askWithdrawalRatio: 0.12,
  programNetAmount: 500_000_000, programVelocity10s: 160_000_000, programTurnedPositive: 1,
  foreignNetDelta: 5000, breakout: true, vwapReclaim: true,
  momentum1mPct: 0.7, drawdownFromHighPct: -0.1,
  recentHigh: 100800, recentLow: 99500,
  smartMoneyState: 'EXPANSION', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 2,
  relativeStrengthPct: 1.2, marketBreadthPct: 58, marketAboveVwap: 1,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(strong.action, 'BUY', JSON.stringify(strong));
assert(strong.qualityScore >= 85);
assert.strictEqual(strong.qualityIsProbability, false);
const profitBlocked = evaluateSignal({
  price: 100800, vwap: 100000, vwapDistancePct: 0.8,
  turnover1m: 500_000_000, turnover15s: 120_000_000,
  tradeStrength: 145, buyRatio: 66, rvol1m: 2.2,
  netBuyAmount5s: 90_000_000, netBuyAmount15s: 210_000_000, buyAcceleration: 18_000_000,
  largeNetAmount1m: 350_000_000, largeBuyCount1m: 4, largeSellCount1m: 0,
  spreadBps: 8, orderbookImbalance: 1.7, bidReplenishRatio: 0.18, askWithdrawalRatio: 0.12,
  programNetAmount: 500_000_000, programVelocity10s: 160_000_000, programTurnedPositive: 1,
  foreignNetDelta: 5000, breakout: true, vwapReclaim: true,
  recentHigh: 100800, recentLow: 99500, smartMoneyState: 'EXPANSION',
  dataCompleteness: 100, activeTier: 'FOCUS', relativeStrengthPct: 1.2,
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 2,
  marketBreadthPct: 58, marketAboveVwap: 1, viActive: false, updatedAt: activeTime.getTime(),
}, { minProfitPriorityScore: 99 }, activeTime);
assert.strictEqual(profitBlocked.blockedByProfitPriority, true, JSON.stringify(profitBlocked));
assert(profitBlocked.profitPriorityScore < 99);

const light = evaluateSignal({ ...strong, activeTier: 'LIGHT' }, {}, activeTime);
assert.notStrictEqual(light.action, 'BUY', '경량 종목은 자동승격 전 확정매수 불가');

const vi = evaluateSignal({ price: 100000, vwap: 100000, spreadBps: 10, viActive: true, dataCompleteness: 100, activeTier: 'FOCUS', updatedAt: activeTime.getTime() }, {}, activeTime);
assert.strictEqual(vi.action, 'BLOCKED');
assert.strictEqual(vi.urgency, 'normal');

const earlySell = evaluateSignal({
  price: 99500, vwap: 100000, vwapDistancePct: -0.5,
  turnover1m: 450_000_000, tradeStrength: 82, buyRatio: 39, rvol1m: 2.1,
  netBuyAmount5s: -45_000_000, netBuyAmount15s: -120_000_000, buyAcceleration: -20_000_000,
  largeNetAmount1m: -150_000_000, largeBuyCount1m: 0, largeSellCount1m: 3,
  spreadBps: 10, orderbookImbalance: 0.68, bidReplenishRatio: -0.08, askWithdrawalRatio: -0.05,
  programNetAmount: -300_000_000, programVelocity10s: -90_000_000,
  foreignNetDelta: -4000, breakdown: false, vwapReclaim: false,
  momentum1mPct: -0.55, drawdownFromHighPct: -0.8,
  recentHigh: 100300, recentLow: 99300,
  smartMoneyState: 'DISTRIBUTION', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 8, programSampleCount: 3,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(earlySell.action, 'WAIT', JSON.stringify(earlySell));
assert(earlySell.sellPressureGroups >= 3, JSON.stringify(earlySell));
assert.strictEqual(earlySell.earlySellEligible, true);
assert.strictEqual(earlySell.negativePressureBlock, true);

const preDropEarlySell = evaluateSignal({
  price: 100000, vwap: 100100, vwapDistancePct: -0.1,
  turnover1m: 500_000_000, tradeStrength: 91, buyRatio: 42, rvol1m: 1.9,
  netBuyAmount5s: -35_000_000, netBuyAmount15s: -80_000_000, buyAcceleration: -18_000_000,
  largeNetAmount1m: -100_000_000, largeBuyCount1m: 0, largeSellCount1m: 2,
  spreadBps: 10, orderbookImbalance: 0.82,
  programNetAmount: -200_000_000, programVelocity10s: -70_000_000,
  foreignNetDelta: -2500, breakdown: false, momentum1mPct: -0.1, drawdownFromHighPct: -0.2,
  recentHigh: 100200, recentLow: 99800, smartMoneyState: 'DISTRIBUTION',
  dataCompleteness: 100, activeTier: 'FOCUS', orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0,
  tradeEventCount: 7, programSampleCount: 3, viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(preDropEarlySell.action, 'WAIT', `분배→매도 가속은 신규진입 안전필터로만 남아야 합니다: ${JSON.stringify(preDropEarlySell)}`);
assert.strictEqual(preDropEarlySell.sellPressure.price, false, '가격 하락확정 없이도 스마트머니·체결·프로그램·호가 압력으로 EARLY_SELL 가능해야 합니다.');
assert.strictEqual(preDropEarlySell.negativePressureBlock, true);

const riskWatch = evaluateSignal({
  price: 99800, vwap: 100000, vwapDistancePct: -0.2,
  turnover1m: 250_000_000, tradeStrength: 92, buyRatio: 45, rvol1m: 1.5,
  netBuyAmount5s: -30_000_000, netBuyAmount15s: -55_000_000, buyAcceleration: -8_000_000,
  largeNetAmount1m: -20_000_000, largeBuyCount1m: 0, largeSellCount1m: 1,
  spreadBps: 10, orderbookImbalance: 0.84,
  programNetAmount: 100_000_000, programVelocity10s: -20_000_000,
  foreignNetDelta: -1000, breakdown: false,
  momentum1mPct: -0.25, drawdownFromHighPct: -0.3,
  recentHigh: 100100, recentLow: 99600,
  smartMoneyState: 'NEUTRAL', dataCompleteness: 100, activeTier: 'FOCUS',
  orderbookAgeMs: 0, programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 6, programSampleCount: 2,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert.strictEqual(riskWatch.action, 'WAIT', JSON.stringify(riskWatch));

const today = new Date();
const risk = accountRisk([
  { status: 'closed', realizedPnl: -600000, exitTime: new Date(today.getTime() - 60_000).toISOString() },
  { status: 'closed', realizedPnl: -500000, exitTime: new Date(today.getTime() - 120_000).toISOString() },
], { dayStartingEquity: 100000000, dailyMaxLossPct: -1, maxConsecutiveLosses: 3 });
assert.strictEqual(Number(risk.dailyPnlPct.toFixed(2)), -1.1);
assert.strictEqual(risk.halted, true);

const net = calculateNetPnl({ avgPrice: 100000, quantity: 10 }, 101000, { buyFeePct: 0.01, sellFeePct: 0.02, sellTaxPct: 0.15 });
assert.strictEqual(net.grossPnl, 10000);
assert(Math.abs(net.realizedPnl - 8183) < 1e-9);

const settings = mergeSettings({ signal: { minBuyScore: 40, confirmTicks: 9, confirmHoldMs: -1 } });
assert.strictEqual(settings.signal.minBuyScore, 65);
assert.strictEqual(settings.signal.confirmTicks, 6);
assert.strictEqual(settings.signal.confirmHoldMs, 0);
assert.strictEqual(settings.signal.maxSmartOrderbookAgeSeconds, 3.5);
assert.strictEqual(settings.signal.maxSmartProgramAgeSeconds, 20);
assert.strictEqual(settings.signal.maxSmartBrokerAgeSeconds, 120);
assert.strictEqual(settings.signal.minSmartTradeEvents, 5);
assert.strictEqual(settings.signal.minSmartProgramSamples, 2);
assert.strictEqual(settings.signal.preSurgeEarlyScore, 68);
assert.strictEqual(settings.signal.preSurgeMinGroups, 3);
assert.strictEqual(settings.signal.riskWatchScore, 45);
assert.strictEqual(settings.signal.earlySellScore, 58);
assert.strictEqual(settings.signal.earlySellMinGroups, 3);

const dailyRows = dailyRowsFrom({ stk_dt_pole_chart_qry: [
  { cur_prc: '70100', trde_qty: '9263135', trde_prica: '648525', dt: '20260731', open_pric: '69800', high_pric: '70500', low_pric: '69600' },
  { cur_prc: '69500', trde_qty: '11526724', trde_prica: '804642', dt: '20260730', open_pric: '70300', high_pric: '70400', low_pric: '69500' },
  ...Array.from({ length: 20 }, (_, index) => ({ cur_prc: String(69000 - index * 100), trde_qty: '7000000', trde_prica: '500000', dt: String(20260729 - index), open_pric: '69000', high_pric: '70000', low_pric: '68000' })),
] });
assert.strictEqual(dailyRows[0].close, 70100);
assert.strictEqual(dailyRows[0].tradeAmount, 648525000000);
const indicators = calculateIndicators(dailyRows);
assert(indicators.ma5 > 0 && indicators.ma20 > 0);
const closeLive = {
  updatedAt: activeTime.getTime(), tradeEventCount: 20, smartMoney: { state: 'TURN', score: 82 },
  program: { netAmount: 100000000, netQty: 1000, updatedAt: activeTime.getTime() },
  broker: { foreignNet: 5000, foreignNetDelta: 500, updatedAt: activeTime.getTime() },
};
const closeFlow = closingFlowFromLive(closeLive);
const closeSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: true },
  krx: { close: 70100, open: 69800, high: 70500, low: 69600, volume: 9263135, tradeAmount: 648525000000, date: '20260731', changePct: 0.86 },
  nxt: { available: true, close: 70400, final: true, changePct: 1.2, changePctAvailable: true }, nxtGapPct: 0.43, indicators, closingFlow: closeFlow,
};
const closeDecision = evaluateCloseDecision(closeSnapshot, closeLive, settings.perStock['005930']);
assert(['CLOSE_BUY', 'HOLD'].includes(closeDecision.action), JSON.stringify(closeDecision));
assert.strictEqual(closeDecision.qualityIsProbability, false);
assert.strictEqual(closeDecision.basis.decisionPrice, 'KRX_OFFICIAL_CLOSE');
assert(closeDecision.breakdown.length >= 9, '종가점수 세부 산출근거');
assert.strictEqual(closeFlow.source, 'REALTIME_PLUS_OFFICIAL_REST');
assert.deepStrictEqual(closeFlow.availability, { smartMoney: true, program: true, foreign: true, institution: false });
assert.strictEqual(closeFlow.smartMoneyState, 'TURN');
assert.strictEqual(closeFlow.programNetAmount, 100000000);
const fullCompleteness = computeSnapshotCompleteness(closeSnapshot);
assert.strictEqual(fullCompleteness.score, 95);
const missingFlowCompleteness = computeSnapshotCompleteness({ ...closeSnapshot, closingFlow: closingFlowFromLive(null) });
assert.strictEqual(missingFlowCompleteness.score, 70, JSON.stringify(missingFlowCompleteness));
assert(missingFlowCompleteness.missing.includes('마감 스마트머니'));
assert.strictEqual(marketPhase(new Date('2026-07-31T13:30:00.000Z')).code, 'ALL_CLOSED'); // KST 22:30


// v3.1.12 inherits v3.1.11: 조기 급등/품절형 강세가 단순 미정배열·저거래량 때문에 과도하게 감점되지 않아야 한다.
const eventRows = [
  { cur_prc: '129800', trde_qty: '3000000', trde_prica: '500000', dt: '20260731', open_pric: '101000', high_pric: '130000', low_pric: '100500' },
  { cur_prc: '100000', trde_qty: '9000000', trde_prica: '900000', dt: '20260730', open_pric: '102000', high_pric: '103000', low_pric: '99000' },
  ...Array.from({ length: 24 }, (_, index) => ({ cur_prc: String(105000 - index * 300), trde_qty: '8000000', trde_prica: '700000', dt: String(20260729 - index), open_pric: '104000', high_pric: '106000', low_pric: '100000' })),
];
const eventDaily = dailyRowsFrom({ stk_dt_pole_chart_qry: eventRows });
const eventIndicators = calculateIndicators(eventDaily);
const eventSnapshot = {
  phase: { code: 'ALL_CLOSED', krxFinal: true, nxtFinal: true },
  krx: { close: 129800, open: 101000, high: 130000, low: 100500, volume: 3000000, tradeAmount: 500000000000, date: '20260731', changePct: 29.8 },
  nxt: { available: true, close: 129900, final: true }, nxtGapPct: 0.08,
  indicators: { ...eventIndicators, ma5: 112000, ma20: 114000, prevMa5: 108000, ma5SlopePct: 3.704, volumeRatio20: 0.38, closeFromHighPct: -0.15 },
  closingFlow: { availability: { smartMoney: true, program: true, foreign: true, institution: true }, smartMoneyState: 'TURN', programNetAmount: 300000000, foreignNetDelta: 5000, institutionNet: 100000000, source: 'TEST' },
  completeness: 100,
};
const eventDecision = evaluateCloseDecision(eventSnapshot, null, settings.perStock['005930']);
assert(eventDecision.score > eventDecision.legacyScore, JSON.stringify(eventDecision));
assert(eventDecision.breakdown.find((x) => x.key === 'volume').points >= 0, JSON.stringify(eventDecision.breakdown));
assert(eventDecision.breakdown.find((x) => x.key === 'alignment').points >= 0, JSON.stringify(eventDecision.breakdown));
assert(eventDecision.eventContext.strongPriceLockProxy, JSON.stringify(eventDecision.eventContext));

const preSurgeEarly = evaluateSignal({
  price: 100200, vwap: 100000, vwapDistancePct: 0.2, turnover1m: 180_000_000,
  tradeStrength: 122, buyRatio: 57, rvol1m: 1.55, netBuyAmount5s: 35_000_000,
  netBuyAmount15s: 65_000_000, buyAcceleration: 18_000_000, largeNetAmount1m: 20_000_000,
  largeBuyCount1m: 1, largeSellCount1m: 0, spreadBps: 9, orderbookImbalance: 1.35,
  bidReplenishRatio: 0.13, askWithdrawalRatio: 0.08, programNetAmount: 100_000_000,
  programVelocity10s: 70_000_000, foreignNetDelta: 1500, breakout: false, vwapReclaim: true,
  momentum1mPct: 0.2, drawdownFromHighPct: -0.1, recentHigh: 100300, recentLow: 99700,
  smartMoneyState: 'TURN', dataCompleteness: 100, activeTier: 'FOCUS', orderbookAgeMs: 0,
  programAgeMs: 0, brokerAgeMs: 0, tradeEventCount: 6, programSampleCount: 2,
  viActive: false, updatedAt: activeTime.getTime(),
}, {}, activeTime);
assert(preSurgeEarly.preSurgeScore >= 68, JSON.stringify(preSurgeEarly));
assert(preSurgeEarly.preSurgeGroups >= 3, JSON.stringify(preSurgeEarly));
assert(['EARLY', 'BUY'].includes(preSurgeEarly.action), JSON.stringify(preSurgeEarly));

realtime.state.stocks.clear();
realtime.processRealtimeEntry({ type: '0B', item: '005930_AL', values: { '10': '100000', '15': '1000', '27': '100100', '28': '100000', '228': '130', '620': '99500', '9081': 'NXT' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
realtime.processRealtimeEntry({ type: '1h', item: '', values: { '9001': '005930_AL', '302': '삼성전자', '9068': '1', '1224': '' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
const stock = realtime.getSnapshot([{ code: '005930', name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true }]).stocks[0];
assert.strictEqual(stock.market, 'NXT');
assert.strictEqual(stock.lastTradeVenue, 'NXT');
assert.strictEqual(stock.lastTradeVenueSource, 'REALTIME_FID');
assert.strictEqual(stock.signal.action, 'BLOCKED');
assert.strictEqual(stock.signal.confirmed, false);


realtime.state.stocks.clear();
realtime.processRealtimeEntry({ type: '0B', item: '005930_AL', values: { '10': '100000', '15': '1000', '27': '100100', '28': '100000', '228': '130', '620': '99500' } }, { name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true });
const sorUnknown = realtime.getSnapshot([{ code: '005930', name: '삼성전자', market: 'SOR', tier: 'FOCUS', fixed: true }]).stocks[0];
assert.strictEqual(sorUnknown.market, 'SOR');
assert.strictEqual(sorUnknown.lastTradeVenue, 'UNKNOWN');
assert.strictEqual(sorUnknown.lastTradeVenueSource, 'SOR_ROUTE_ONLY');

console.log('CHECK OK: 고정4+집중8+경량8=20종목, 급등초입/BUY 중심, 매도잡신호 제거, 종가 합리화, 단순 손절관리');

// v3.1.0-HF1 regression: the live-list comparator must not reference an undefined `s`.
{
  const pageSource = fs.readFileSync(path.join(__dirname, '..', 'pages', 'index.js'), 'utf8');
  assert(!pageSource.includes('const useClose = s.dataSource'), 'undefined comparator variable regression');
  assert(pageSource.includes('const rankA = usesCloseSnapshot(a)'), 'close/live rankA comparator missing');
  assert(pageSource.includes('const rankB = usesCloseSnapshot(b)'), 'close/live rankB comparator missing');
  assert(pageSource.includes('휴장·미측정'), 'closed market zero-to-NA display missing');
  assert(pageSource.includes('계산기준 분리:'), 'KRX/NXT calculation basis label missing');
  assert(pageSource.includes('점수 산출근거 보기'), 'close score breakdown UI missing');
  assert(pageSource.includes('데이터 완전성 구성'), 'snapshot completeness breakdown UI missing');
  assert(pageSource.includes('급등 사전포착 · 매수후보'), 'profit-focus board missing');
  assert(pageSource.includes('아이폰 푸시 켜기·테스트'), 'iPhone push test UI missing');
  assert(pageSource.includes('실제체결'), 'actual venue display missing');
  assert(pageSource.includes('장전 사전점검'), 'preflight panel missing');
  assert(pageSource.includes('장전 사전점검'), 'preflight UI missing');
  assert(pageSource.includes('아이폰 푸시 켜기·테스트'), 'push test UI missing');
  assert(pageSource.includes('실제체결'), 'actual execution venue UI missing');
}
