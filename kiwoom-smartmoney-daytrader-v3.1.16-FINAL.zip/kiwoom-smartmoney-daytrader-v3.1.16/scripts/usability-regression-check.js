process.env.STORE_DISABLE_LOCAL_FILE = 'true';
const fs = require('fs');
const assert = require('assert');

function text(file) { return fs.readFileSync(file, 'utf8'); }

(async () => {
  const index = text('pages/index.js');
  const events = text('pages/api/events.js');
  const worker = text('worker/kiwoomRealtime.js');
  const subscribe = text('pages/api/push/subscribe.js');
  const sw = text('public/sw.js');

  assert(index.includes('const UI_FLUSH_MS = 1500'), 'UI 1.5초 묶음갱신 누락');
  assert(events.includes('1000 - (now - previous)'), 'SSE 1초 표시 스로틀 누락');
  assert(!index.includes('new Notification('), 'SSE/대시보드 중복 브라우저 알림이 남아있음');
  assert(index.includes('푸시 알림 완전 해제'), '푸시 해제 UI 누락');
  assert(index.includes("JSON.stringify({ endpoint, all: true })"), '클라이언트 전체 구독 해제 누락');
  assert(subscribe.includes('const all = Boolean'), '서버 전체 구독 해제 누락');
  assert(worker.includes("if (notificationAction === 'EARLY' || stock.entryRestricted) return;"), 'EARLY/진입제한 BUY 푸시 억제 누락');
  assert(worker.includes('this.notificationHistory = new Map()'), '액션별 반복알림 억제 누락');
  assert(sw.includes('renotify: false'), '서비스워커 재알림 억제 누락');
  assert(index.includes('장중 강한종목 갱신'), '장중 강한종목 갱신 UI 누락');
  assert(index.includes('장중 자동적용'), '장중 자동적용 ON/OFF UI 누락');
  assert(index.includes('60초 재조회 제한'), '장중 추천 화면 안정화 안내 누락');

  const { setItem } = require('../lib/store');
  const { PUSH_ENABLED_KEY, getPushStatus } = require('../lib/pushConfig');
  const { sendWebPush } = require('../lib/notifications');
  await setItem(PUSH_ENABLED_KEY, false);
  const status = await getPushStatus({ generate: false });
  assert.strictEqual(status.enabled, false, '푸시 OFF 상태 저장 실패');
  const result = await sendWebPush({ type: 'buy', action: 'BUY', code: '005930', name: '삼성전자', message: 'test' });
  assert.strictEqual(result.disabled, true, '서버 푸시 차단 실패');
  assert.strictEqual(result.reason, '사용자 푸시 해제', '서버 푸시 OFF 이유 불일치');

  assert(index.includes('급등 사전포착 · 매수후보'), '급등초입 중심 보드 누락');
  assert(index.includes('확정 BUY와 실제 보유종목의 설정 손절가 도달만 전송'), '간소화 알림정책 누락');
  console.log('USABILITY CHECK OK: 화면/알림 안정화 + 장중 강한종목 + BUY/손절만 알림');
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
