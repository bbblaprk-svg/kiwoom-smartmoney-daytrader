# v3.1.16 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.16

## 변경 목적
v3.1.15에서 일반 감시종목의 하락전조/RISK/EARLY_SELL이 화면을 지배해 앱의 목적이 흐려지는 문제를 수정했습니다. v3.1.16은 **상승초입·급등후보 발견과 확정 BUY 선별**을 주기능으로 두고, 실제 보유종목 청산 알림은 사용자가 정한 손절가로 단순화합니다.

## 핵심 변경
1. 일반 감시종목의 RISK/EARLY_SELL/SELL 런타임 기록·푸시 제거.
2. 하락압력 점수는 신규진입 차단용 `negativePressureBlock`으로만 사용.
3. 프로그램/거래원 피드가 완전히 준비되기 전에도 독립적인 체결·가격/거래량·호가 축이 강하면 `earlyDiscoveryEligible`로 EARLY 표시.
4. 확정 BUY 게이트는 품질 85+, 수익우선 78+, 체결강도 118+, 데이터완전성 95+, 스마트머니 TURN/EXPANSION, R/R 1.5+를 그대로 유지.
5. 실제 보유종목 알림은 설정 손절가 도달 1회만 허용. T1/T2/T3/트레일링 푸시 제거.
6. 계좌 위험/최대보유 한도가 차도 좋은 EARLY/BUY를 숨기지 않고 `신규진입 제한`으로 표시.
7. 종합기록부/알림탭 기본화면을 EARLY/BUY 중심으로 단순화.

## 데이터수집 경로 보존 확인
v3.1.15 원본과 SHA256 비교 결과 다음 파일은 완전히 동일합니다.
- `lib/kiwoomClient.js`: `9a02d2cb0d4d95f978fd20cb42afdb0fe6744969a2f87742fe79f8e2f34a57b6`
- `lib/flowCollector.js`: `7a236c42f33950431b3f0f0acff3c7a5d88249e2437f9eb30e6d71e3718e6f1a`
- `lib/marketSnapshot.js`: `dd62e9a7434b0e8e4c5b03d93b4a7acbbb302c40c4752a5273cb9c15112edb8b`
- `lib/stocks.js`: `083f6089ae9424685677a0d1fe3da682693082b28c7ecb64efb0450416b6cef8`
- `lib/recommendationEngine.js`: `f13804c2ccb3e467aebf55ae1203a2cf40db8c2aafdbc3bfac4ae748fed646f7`

`lib/realtimeStore.js`는 BUY-only confirmation/표시 필드만 변경했습니다. worker는 판정 후 알림·기록 및 실제 보유종목 손절 처리만 변경했습니다. WebSocket 구독 종류와 TR/FID 수신/해석 경로는 변경하지 않았습니다.

## 회귀검사
실행/통과 대상:
- `node --check` 수정 주요 JS
- `npm run check:unit`
- `npm run check:integration`
- `npm run check:storage`
- `npm run check:flow`
- `npm run check:rest`
- `npm run check:recommendations`
- `npm run check:usability`
- `npm run check:profit-focus`

`check:profit-focus`는 특히 다음을 검증합니다.
- 프로그램/거래원 완전준비 전 급등 조짐 EARLY 가능
- 강한 하락압력 일반종목은 SELL/RISK가 아닌 WAIT
- 실제 보유종목 설정 손절가 알림 존재
- EARLY 및 신규진입 제한 BUY 푸시 억제
- 최대보유 한도가 좋은 BUY 기록 자체를 숨기지 않음
- 실시간 confirmation이 BUY-only
- 종합기록부/핵심보드가 수익추구 중심

## 20종목 합성부하
최종 실제 실행값 (`LOAD_TEST_TICKS=100000 LOAD_TEST_SYMBOLS=20`):
- totalTicks: 100,000
- symbols: 20
- 처리율: **63,052 ticks/s**
- event-loop p95: **24.13 ms**
- event-loop max: **26.85 ms**
- coalesced / processed: 98,380 / 1,620
- errors: **0**
- RSS: **120.1 MB**
- final pending / active: **0 / 0**

배포 스크립트에서도 별도로 20,000틱 부하검사를 재실행합니다.

## Next.js 빌드
현재 제작 런타임에는 `node_modules`가 없어 로컬 `npm run build`는 `next: not found`로 실행할 수 없었습니다. 이를 성공으로 간주하지 않습니다. Lightsail 업데이트 스크립트가 public npm registry에서 `npm install → npm run check → 20종목 부하검사 → npm run build`를 모두 성공한 경우에만 기존 컨테이너를 교체하며, 실패 시 기존 앱으로 롤백합니다.
