"""Validate one live deployment sample; distinguish market closure from Feed failure."""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


def check(root, cap, sample):
    p=Path(root)
    h=json.loads((p/'health.json').read_text())
    session=json.loads((p/'session.json').read_text())
    truth=json.loads((p/'truth.json').read_text())
    runtime=json.loads((p/'runtime.json').read_text())
    errors=[]
    if h.get('runtime_safety_release')!='2.1.11.9_SCOUT_FUNNEL_CPU_SAFE' or h.get('feed_enabled') is not True:
        errors.append('wrong_release_or_feed_mode')
    phase=session.get('phase')
    active=phase in ('NXT_PRE','MARKET_MAIN','NXT_AFTER','NXT_LATE_SESSION')
    if phase not in ('CLOSED','NXT_PRE','OPENING_AUCTION','MARKET_MAIN','KRX_CLOSE_AUCTION','POST_GAP','NXT_AFTER','NXT_LATE_SESSION'):
        errors.append('unknown_session')
    if not h.get('runtime_load_stage') or h['runtime_load_stage']=='CRITICAL': errors.append('runtime_load')
    if active and sample>=4 and (not h.get('ws_connected') or h.get('runtime_feed_health')=='OFFLINE'):
        errors.append('active_feed_offline')
    stats=h.get('runtime_feature_recalc') or {}
    for key,limit in [('pending',24),('oldest_pending_ms',2500)]:
        value=stats.get(key)
        if not isinstance(value,(float,int)) or value>=limit: errors.append('recalc_'+key)
    dynamic=(runtime.get('metrics') or {}).get('dynamic_subscription_count')
    if not isinstance(dynamic,int) or dynamic>cap: errors.append('dynamic_capacity')
    age=None
    if active and sample>=4:
        stamp=truth.get('last_trusted_market_event_at')
        try:
            dt=datetime.fromisoformat(stamp.replace('Z','+00:00'))
            if dt.tzinfo is None: raise ValueError('naive timestamp')
            age=(datetime.now(timezone.utc)-dt.astimezone(timezone.utc)).total_seconds()
            if not -2<=age<=10: errors.append('trusted_market_tick_not_fresh')
        except (TypeError,ValueError,AttributeError): errors.append('missing_trusted_tick')
        if not isinstance(dynamic,int) or dynamic<1: errors.append('no_dynamic_subscriptions')
        if not isinstance(truth.get('feature_frame_count'),int) or truth['feature_frame_count']<1: errors.append('no_feature_frames')
    try:
        cpu=float((p/'stats.txt').read_text().split()[0].rstrip('%'))
        if cpu>=85: errors.append('cpu_high')
    except (ValueError,IndexError): cpu=None; errors.append('cpu_missing')
    mem={l.split(':')[0]:int(l.split()[1]) for l in open('/proc/meminfo') if ':' in l}
    if mem.get('MemAvailable',0)<131072: errors.append('memory_low')
    if mem.get('MemAvailable',0)+mem.get('SwapFree',0)<262144: errors.append('memory_swap_low')
    docker_health=(p/'docker-health.txt').read_text().strip()
    if docker_health!='healthy': errors.append('docker_health_'+docker_health)
    if not active: market='NOT_TESTED_OUTSIDE_CONTINUOUS_SESSION'
    elif sample<4: market='WARMING'
    else: market='PASS' if not errors else 'FAIL'
    print(f'LIVE_METRICS phase={phase} market_feed={market} cpu={cpu} dyn={dynamic}/{cap} age_sec={age} recalc={stats} docker={docker_health} errors={errors}')
    return errors


if __name__=='__main__':
    try: failures=check(sys.argv[1],int(sys.argv[2]),int(sys.argv[3]))
    except Exception as exc:
        print('LIVE_METRICS_INVALID '+type(exc).__name__)
        raise SystemExit(1)
    raise SystemExit(bool(failures))
