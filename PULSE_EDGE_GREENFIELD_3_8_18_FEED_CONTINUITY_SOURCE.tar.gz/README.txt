PULSE EDGE 3.8.18_FEED_CONTINUITY
기준: 3.8.17_NOW_REPAIR

수정:
1. 최종 우선 구독 20자리 중 최대 6자리를 실제 PRE/RELEASE/EARLY 보호 대상으로 배정.
   PRE/RELEASE 180초, EARLY 90초 구독 유지. 유효한 새 평가로만 연장.
   TTL은 구독 유지에만 사용되며 오래된 시세를 LIVE/매수 신호로 사용하지 않음.
   나머지 신규·probe·일반 탐색 자리 유지. 총 34개 및 호가4개 상한 유지.
2. 일봉은 마지막 시도 순서로 조회. 실패도 시도로 기록해 앞 종목의 반복 실패가 뒤 종목을 막지 않음.
   회당 20개 한도 유지, 씨앗30개 고정 시 두 회차 내 전부 조회.
3. REST 가격은 수신시점 기준 2초 이내의 체결과 비교하며 최대30초의 비교자료만 인정.
   과거 REST와 움직이는 현재가를 직접 비교하지 않음.
   REST의 원천 거래시각을 확보한 것은 아니므로 수신시각 근접 비교라는 한계는 남음.
   근접 체결이 없거나 자료가 오래되면 교차확인 미완료. PRE 승격 불가.
   실제 근접 가격 충돌은 기존 임계값으로 차단. 일봉 현재가격을 실시간 REST 확인값으로 덮어쓰지 않음.
4. DATA CHECK와 센서전용 종목을 호가 strongest 선택에서 제외.
5. 후보 진단에 실제 구독별 freshness/stage/blockers, 전체 평가단계 및 일봉/수급 확보 수 추가.
   추가 진단을 위해 재점수계산이나 REST 호출을 하지 않음.

검증:
pytest 112개 통과 (추가4개: 구독 보호/만료/상한, 실패시 일봉순환, 시점 차이 오판방지, 실제 충돌/시장분리).
기존 offline_tests PRE 도달/스프레드/시세충돌/지연/과열/채널/readiness 검증 통과.
Node DOM 표·가격·DETAIL 동작 검사 통과. Python/JS/Bash/내장Python 구문 및 산출물 SHA 검증.
로컬 Feed-OFF HTTP 기동/종료 계약 검증.

한계:
실운영 OAuth/WS/개별종목 전체수신/공개HTTPS/실서버CPU/10~20분 장중 지속성을 직접 확인하지 못함.
이 환경에는 Docker가 없어 실제 Docker build는 실행하지 못함.
실제 브라우저 렌더링은 미검증. DOM 동작 검증과 CSS검토만 수행.
112개 테스트는 실제 장중 탐지 성과나 모든 종목 표시를 보장하지 않음.
기존3.8.17 운영서버 배포통과 결과를 이번3.8.18의 배포성공으로 간주하지 않음.

배포:
Dockerfile + PULSE_EDGE_GREENFIELD_3_8_18_FEED_CONTINUITY_SOURCE.tar.gz를 같은 폴더에 둡니다.
Lightsail Bash는 PULSE_EDGE_GREENFIELD_3_8_18_FEED_CONTINUITY_ONE_SHOT_DEPLOY.sh입니다.
환경·네트워크·기존컨테이너·canary·singleton·인증서·10분 부하검증·실패시 복구 절차 유지.
Render에서 Bash는 사용하지 않습니다. Docker 빌드 컨텍스트에는 소스 tar가 함께 있어야 합니다.
