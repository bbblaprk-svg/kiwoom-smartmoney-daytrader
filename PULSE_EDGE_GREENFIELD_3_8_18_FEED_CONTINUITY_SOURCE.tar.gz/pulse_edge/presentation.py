"""Bounded presentation enrichment; never modifies stored signal snapshots."""
import time
from collections import Counter
from pulse_edge.feed.kiwoom import excluded_security

NOW_STAGES={'EARLY HIDDEN GEM','SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}
PRECURSORS={'EARLY PRESSURE ABSORBED','PRESSURE ABSORBED','RELEASE READY'}

def eligible_now(c):
    return (not excluded_security(c.name) and not c.sensor_only
            and c.data_status in {'LIVE','CONFIRMED'}
            and (c.stage in NOW_STAGES or c.precursor_stage in PRECURSORS))

def enrich(runtime, rows, history=False, horizon='NOW'):
    n=time.time(); venue=runtime.active_venue(); out=[]
    signals={} if history else {(r.get('symbol'),r.get('venue','KRX')):r for r in reversed(runtime.signal_store.recent(200,horizon))}
    for row in rows:
        d=dict(row); sym=d.get('symbol'); source=d.get('venue','KRX')
        sig=d if history else signals.get((sym,source),{})
        d['signal_price']=sig.get('signal_price',sig.get('current_price'))
        d['signal_ts']=sig.get('history_ts')
        st=runtime.states.get(f'{sym}:{venue}') if venue else None
        fresh=bool(st and st.price and runtime.scorer.data_status(st,n) in {'LIVE','CONFIRMED'})
        d['live_price']=st.price if fresh else None
        d['live_change_rate']=st.change_rate if fresh else None
        d['price_status']='LIVE' if fresh else ('WAIT' if venue else 'CLOSED')
        d['price_venue']=venue
        d['price_timestamp']=st.last_trade_event_ts if fresh else None
        d['signal_return_pct']=round((st.price/d['signal_price']-1)*100,2) if fresh and d.get('signal_price') else None
        out.append(d)
    return out

def diagnostics(runtime):
    stages=Counter(c.stage for c in runtime.raw_results)
    gates=Counter()
    for c in runtime.raw_results:
        for reason in c.reasons:
            if reason in {'TRADE_DATA_NOT_FRESH','PRICE_OR_CHANGE_RECHECK_REQUIRED'} or reason in {
                'COMMON_HARD=False','CROSS_SOURCE=False','MODEL_A_READY=False','MODEL_B_READY=False',
                'SPREAD_OK=False','EARLY_ENERGY_EVIDENCE=False','EARLY_ABSORPTION_EVIDENCE=False','MARKET_INDEX_FRESH=False'}:
                gates[reason]+=1
    return {'states':len(runtime.states),'ranked':len(runtime.raw_results),'stages':dict(stages),'blockers':dict(gates),
            'scope':'ranked_top20','note':'EARLY는 관찰 · PRE만 엄격한 실시간·흡수·방출 검증'}

_original_diagnostics=diagnostics
def diagnostics(runtime):
    d=_original_diagnostics(runtime); now=time.time(); venue=runtime.active_venue()
    wires=runtime.ws.items(); details=[]
    evaluated={(c.symbol,c.venue):c for c in getattr(runtime.scorer,'last_evaluated',[])}
    for wire in wires:
        st=runtime._wire_state(wire)
        if st is None:
            details.append({'symbol':wire,'status':'NO_STATE','stage':'NOT_EVALUATED'});continue
        c=evaluated.get((st.symbol,st.venue))
        details.append({'symbol':st.symbol,'venue':st.venue,'status':runtime.scorer.data_status(st,now),
            'trade_age_sec':round(now-st.last_trade_event_ts,2) if st.last_trade_event_ts else None,
            'stage':c.stage if c else 'NO_SCORE',
            'blockers':[x for x in c.reasons if x.endswith('=False') or 'REQUIRED' in x or 'NOT_FRESH' in x] if c else [],
            'protected':wire in runtime.priority_leases})
    d['subscribed']=len(wires);d['subscription_status']=dict(Counter(x['status'] for x in details))
    d['subscription_stages']=dict(Counter(x['stage'] for x in details));d['subscription_details']=details
    d['all_evaluated_stages']=dict(Counter(c.stage for c in evaluated.values() if c.venue==venue))
    seeds=[runtime.states.get(f'{sym}:KRX') for sym in runtime.coiled_seed_symbols]
    d['daily_pipeline']={'seeds':len(seeds),'state_ready':sum(st is not None for st in seeds),
       'bars_ready':sum(bool(st and len(st.daily_bars)>=8) for st in seeds),
       'flows_ready':sum(bool(st and len(st.daily_flows)>=3) for st in seeds),'qualified_top':len(runtime.coiled_results)}
    return d
