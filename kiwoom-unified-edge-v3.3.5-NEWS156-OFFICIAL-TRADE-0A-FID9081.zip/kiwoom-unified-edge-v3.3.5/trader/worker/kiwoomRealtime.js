const WebSocket = require('ws');
const { getAccessToken, getStockInfo } = require('../lib/kiwoomClient');
const { getItem, setItem } = require('../lib/store');
const { mergeWatchlist, splitWatchlist } = require('../lib/stocks');
const { state, processRealtimeEntry, setConnection, setSignalSettings, resetSubscriptions, setPromotion, applyMarketSnapshot, applyVenueFallbackQuote, realtimeTruth } = require('../lib/realtimeStore');
const { notify } = require('../lib/notifications');
const { mergeSettings } = require('../lib/settings');
const { accountRisk } = require('../lib/risk');
const { ensureLoaded: loadPerformance, registerBuySignal, registerDiscoverySignal, updatePrice: updatePerformancePrice, sweepExpired } = require('../lib/signalPerformance');
const { ensureLoaded: loadSignalLedger, recordSignal, recordShadowSignal, updateObservationTrajectory, updatePrice: updateLedgerPrice, persistNow: persistSignalLedger } = require('../lib/signalLedger');
const runtimeMetrics = require('../lib/runtimeMetrics');
const realtimeDebug = require('../lib/realtimeDebug');
const { refreshAll: refreshMarketSnapshots, loadLatestSnapshots } = require('../lib/marketSnapshot');
const { getRecommendationLearningContext } = require('../lib/recommendationEngine');

const WS_URL = process.env.KIWOOM_WS_URL || 'wss://api.kiwoom.com:10000/api/dostk/websocket';
// v3.3.5 OFFICIAL TRADE TYPE FIX: bare-code REG 구조는 유지하고 주식체결 type을 0A로 교정한다.
// 국내 WebSocket item은 bare 종목코드 문자열 배열이며, REST 전용 거래소별 종목코드(_NX/_AL)나 미국주식용 item-map(stex_tp)을 REG에 혼용하지 않는다.
// 실제 체결의 거래소 진실값은 0A payload FID 9081이며 요청 라벨/시간대로 추정하지 않는다.
const TRADE_TYPE = '0A';
const SCOUT_TYPES = ['0A', '0D', '0u'];
const FOCUS_TYPES = ['0A', '0D', '0F', '0u'];
const LIGHT_TYPES = SCOUT_TYPES;
const GLOBAL_TYPES = ['0m'];
const SNAPSHOT_POLICY = 'CLOSE_ONLY';
const SOCKET_WATCHDOG_MS = Math.max(10_000, Number(process.env.KIWOOM_SOCKET_WATCHDOG_MS || 20_000));
const WATCHDOG_INTERVAL_MS = Math.max(500, Number(process.env.KIWOOM_WATCHDOG_INTERVAL_MS || 1000));
const VENUE_STALE_MS = Math.max(2_000, Number(process.env.KIWOOM_VENUE_STALE_MS || 5_000));
// 활성장 동적판정은 REST fallback 금지. 필요시 운영진단용 quote만 별도 허용하며 기본 OFF.
const REST_FALLBACK_INTERVAL_MS = Math.max(3_000, Number(process.env.KIWOOM_REST_FALLBACK_INTERVAL_MS || 5_000));
const INTRADAY_REST_DIAGNOSTIC = String(process.env.KIWOOM_INTRADAY_REST_DIAGNOSTIC || 'false').toLowerCase() === 'true';
const VENUE_NO_TRADE_RECOVERY_MS = Math.max(5_000, Number(process.env.KIWOOM_VENUE_NO_TRADE_RECOVERY_MS || 8_000));
const VENUE_RECOVERY_COOLDOWN_MS = Math.max(8_000, Number(process.env.KIWOOM_VENUE_RECOVERY_COOLDOWN_MS || 12_000));
const VENUE_HARD_RECOVERY_MS = Math.max(VENUE_NO_TRADE_RECOVERY_MS + 5_000, Number(process.env.KIWOOM_VENUE_HARD_RECOVERY_MS || 18_000));
const CLOSE_SYNC_STATE_PREFIX = 'market:close-sync:v5:';
const CLOSE_SYNC_MAX_ATTEMPTS = Math.max(5, Number(process.env.CLOSE_SYNC_MAX_ATTEMPTS || 7));
const SMART_MONEY_CHECKPOINT_PREFIX = 'market:smart-money-checkpoint:v1:';
const CLOSE_SYNC_POST_FINAL_RETRY_MS = Math.max(120_000, Number(process.env.CLOSE_SYNC_POST_FINAL_RETRY_MS || 300_000));
const CLOSE_SYNC_PLANS = {
  KRX_CLOSE: { start: 15 * 60 + 32, schedule: [15 * 60 + 32, 15 * 60 + 34, 15 * 60 + 37, 15 * 60 + 42, 16 * 60] },
  NXT_CLOSE: { start: 20 * 60 + 1, schedule: [20 * 60 + 1, 20 * 60 + 3, 20 * 60 + 6, 20 * 60 + 12, 20 * 60 + 20] },
};
let singleton = globalThis.__KIWOOM_WORKER__ || null;

async function loadWatchlist() { return mergeWatchlist((await getItem('watchlist:user')) || []); }
function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function kstClockParts(now = new Date()) {
  const shifted = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const isoDate = shifted.toISOString().slice(0, 10);
  return {
    isoDate, compactDate: isoDate.replace(/-/g, ''), weekday: shifted.getUTCDay(),
    minute: shifted.getUTCHours() * 60 + shifted.getUTCMinutes(), nowMs: now.getTime(),
  };
}
function kstMinuteToUtcIso(isoDate, minute) {
  const hh = String(Math.floor(minute / 60)).padStart(2, '0');
  const mm = String(minute % 60).padStart(2, '0');
  return new Date(`${isoDate}T${hh}:${mm}:00+09:00`).toISOString();
}

class KiwoomRealtimeWorker {
  constructor() {
    this.stopped = false;
    this.ws = null;
    this.reconnectAttempt = 0;
    this.watchHash = '';
    this.watchlist = [];
    this.watchPoll = null;
    this.marketClockPoll = null;
    this.closeSyncCache = new Map();
    this.snapshotBusy = false;
    this.notificationBusy = new Set();
    this.notificationHistory = new Map(); // 액션이 흔들려도 같은 종목·같은 중요신호 반복 알림 억제
    this.positionCache = { loadedAt: 0, positions: [], settings: mergeSettings(null) };
    this.positionAlertAt = new Map();
    this.resubscribeBusy = false;
    this.postPending = new Map();
    this.postRunning = new Set();
    this.postActive = 0;
    this.postMaxConcurrency = Math.max(1, Number(process.env.POST_PROCESS_CONCURRENCY || 4));
    this.positionPersistTimer = null;
    this.positionPersistDirty = false;
    this.watchdogPoll = null;
    this.lastSocketFrameAt = 0;
    this.pendingRegGroups = [];
    this.tradeDedupe = new Map();
    this.restFallbackBusy = false;
    this.restFallbackCursor = 0;
    this.lastRestFallbackAt = 0;
    this.marketStatusRefreshTimers = new Map();
    this.venueZeroFreshSince = { KRX: 0, NXT: 0 };
    this.lastVenueRecoveryAt = { KRX: 0, NXT: 0 };
    this.lastMarketStartOperation = null;
    // v3.2.17: 등록 성공(ACK)과 실제 체결 수신을 분리 추적한다.
    this.regRequests = new Map();
    this.regSeq = 0;
    this.acceptedTradeCodes = { KRX: new Set(), NXT: new Set(), SOR: new Set() };
    this.firstTradeAt = { KRX: new Map(), NXT: new Map() };
    this.failedTradeCodes = { KRX: new Map(), NXT: new Map(), SOR: new Map() };
    this.startupCloseCatchupDate = null;
  }

  start() {
    this.stopped = false;
    Promise.all([loadPerformance(), loadSignalLedger()]).catch((error) => console.error(`[startup] 성과/기록부 로드 실패: ${error.message}`));
    this.connectLoop().catch((error) => setConnection({ status: 'error', lastError: String(error.message || error) }));
    return this;
  }

  async stop() {
    this.stopped = true;
    if (this.watchPoll) clearInterval(this.watchPoll);
    if (this.marketClockPoll) clearInterval(this.marketClockPoll);
    if (this.watchdogPoll) clearInterval(this.watchdogPoll);
    if (this.positionPersistTimer) clearTimeout(this.positionPersistTimer);
    await this.flushPositions().catch((error) => console.error(`[positions] 종료 저장 실패: ${error.message}`));
    await persistSignalLedger().catch((error) => console.error(`[ledger] 종료 저장 실패: ${error.message}`));
    if (this.ws) this.ws.close();
  }

  async connectLoop() {
    while (!this.stopped) {
      try { await this.connectOnce(); this.reconnectAttempt = 0; }
      catch (error) {
        this.reconnectAttempt += 1;
        setConnection({ status: 'reconnecting', lastError: String(error.message || error), reconnects: state.connection.reconnects + 1 });
      }
      if (!this.stopped) await wait(Math.min(30_000, 1000 * (2 ** Math.min(this.reconnectAttempt, 5))));
    }
  }

  async connectOnce() {
    setConnection({ status: 'connecting', lastError: null });
    const token = await getAccessToken();
    const [watchlist, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    this.watchlist = watchlist;
    setSignalSettings(mergeSettings(savedSettings).signal);
    const ws = new WebSocket(WS_URL, { handshakeTimeout: 20_000, perMessageDeflate: false });
    this.ws = ws;
    try {
      await new Promise((resolve, reject) => {
        const cleanup = () => { clearTimeout(timer); ws.off('open', onOpen); ws.off('error', onError); };
        const onOpen = () => { cleanup(); resolve(); };
        const onError = (error) => { cleanup(); reject(error); };
        const timer = setTimeout(() => { cleanup(); reject(new Error('키움 WebSocket 연결 시간초과')); }, 20_000);
        ws.once('open', onOpen); ws.once('error', onError);
      });
      ws.send(JSON.stringify({ trnm: 'LOGIN', token }));
      await this.waitForLogin(ws);
      this.lastSocketFrameAt = Date.now();
      setConnection({ status: 'connected', connectedAt: new Date().toISOString(), lastError: null, venueRegistration: {}, websocketEndpoint: WS_URL });
      ws.on('message', (data) => this.onMessage(data));
      await this.subscribe(this.watchlist, true);
      await this.hydrateSmartMoneyCheckpoints().catch(() => null);
      await this.hydrateSnapshots(this.watchlist);
      setConnection({ snapshotPolicy: SNAPSHOT_POLICY, snapshotStatus: state.connection.snapshotCount > 0 ? 'cached' : 'waiting_close_sync' });
      // v3.3.1: 장 종료 후 재시작했다면 과거 latest snapshot을 그대로 노출하지 않고
      // 현재 영업일 KRX/NXT 종가 동기화를 1회 즉시 시도한다. 실패해도 WS 연결은 유지하고
      // freshness gate가 오래된 종가를 메인 랭킹/현재가에서 차단한다.
      await this.runStartupCloseCatchup(new Date()).catch((error) => {
        setConnection({ startupCloseCatchup: { status: 'error', at: new Date().toISOString(), error: String(error.message || error) } });
      });
      this.watchPoll = setInterval(() => this.refreshWatchlist().catch(() => null), 30_000);
      this.marketClockPoll = setInterval(() => this.maybeScheduledCloseRefresh().catch(() => null), 30_000);
      this.watchdogPoll = setInterval(() => this.watchdog().catch(() => null), WATCHDOG_INTERVAL_MS);
      if (this.watchdogPoll.unref) this.watchdogPoll.unref();
      this.maybeScheduledCloseRefresh().catch(() => null);
      await new Promise((resolve, reject) => {
        ws.once('close', resolve); ws.once('error', reject);
      });
    } finally {
      if (this.watchPoll) clearInterval(this.watchPoll);
        if (this.marketClockPoll) clearInterval(this.marketClockPoll);
      if (this.watchdogPoll) clearInterval(this.watchdogPoll);
      this.watchPoll = null;
        this.marketClockPoll = null;
      this.watchdogPoll = null;
      for (const timer of this.marketStatusRefreshTimers.values()) clearTimeout(timer);
      this.marketStatusRefreshTimers.clear();
      if (this.ws === ws) this.ws = null;
      try { if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.terminate(); } catch (_) {}
      if (!this.stopped) setConnection({ status: 'disconnected' });
    }
  }

  waitForLogin(ws) {
    return new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); ws.off('message', handler); ws.off('close', onClose); ws.off('error', onError); };
      const finish = (error) => { cleanup(); if (error) reject(error); else resolve(); };
      const onClose = () => finish(new Error('키움 WebSocket이 LOGIN 전에 종료됐습니다.'));
      const onError = (error) => finish(error);
      const handler = (buffer) => {
        let message; try { message = JSON.parse(buffer.toString()); } catch (_) { runtimeMetrics.markRealtimeParseError(); return; }
        if (message.trnm === 'PING') { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message)); return; }
        if (String(message.trnm || '').toUpperCase() !== 'LOGIN') return;
        if (Number(message.return_code || 0) !== 0) finish(new Error(`키움 LOGIN 실패: ${message.return_msg || message.return_code}`));
        else finish();
      };
      const timer = setTimeout(() => finish(new Error('키움 WebSocket LOGIN 응답 시간초과')), 15_000);
      ws.on('message', handler); ws.once('close', onClose); ws.once('error', onError);
    });
  }


  async hydrateSnapshots(watchlist) {
    const saved = await loadLatestSnapshots(watchlist).catch(() => []);
    for (const item of saved) applyMarketSnapshot(item.meta.code, item.snapshot, {
      name: item.meta.name, marketMode: item.meta.market, tier: item.meta.tier, fixed: item.meta.fixed,
    });
    if (saved.length) setConnection({ snapshotCount: saved.length });
  }

  async refreshSnapshots(reason = 'manual', targetWatchlist = null, syncContext = {}) {
    await this.persistSmartMoneyCheckpoints(syncContext.now instanceof Date ? syncContext.now : new Date()).catch(() => null);
    const targets = Array.isArray(targetWatchlist) && targetWatchlist.length ? targetWatchlist : this.watchlist;
    if (this.snapshotBusy || !targets.length) return null;
    this.snapshotBusy = true;
    setConnection({ snapshotStatus: 'refreshing', snapshotReason: reason, snapshotRetryRequested: targets.length });
    try {
      const savedSettings = await getItem('settings');
      const result = await refreshMarketSnapshots(targets, {
        settings: savedSettings,
        getLiveStock: (code) => state.stocks.get(code) || null,
        syncStage: syncContext.stage || null,
        syncDate: syncContext.targetDate || null,
        now: syncContext.now instanceof Date ? syncContext.now : new Date(),
      });
      for (const snapshot of result.snapshots) {
        const meta = this.watchlist.find((item) => item.code === snapshot.code) || targets.find((item) => item.code === snapshot.code) || {};
        applyMarketSnapshot(snapshot.code, snapshot, {
          name: meta.name || snapshot.name, marketMode: meta.market || 'SOR', tier: meta.tier || 'FOCUS', fixed: meta.fixed,
        });
      }
      const invalidSnapshots = result.snapshots
        .filter((snapshot) => !(snapshot && snapshot.krx && Number(snapshot.krx.close || 0) > 0))
        .map((snapshot) => ({ code: snapshot && snapshot.code || '?', error: 'KRX 종가 미수집' }));
      const validSnapshots = result.snapshots.length - invalidSnapshots.length;
      const allErrors = [...result.errors, ...invalidSnapshots];
      const totalSnapshotCount = [...state.stocks.values()].filter((stock) => Number(stock.marketSnapshot && stock.marketSnapshot.krx && stock.marketSnapshot.krx.close || 0) > 0).length;
      const snapshotStatus = validSnapshots === result.requested && allErrors.length === 0
        ? 'ready'
        : validSnapshots > 0 ? 'partial' : 'error';
      setConnection({
        snapshotStatus,
        snapshotCount: totalSnapshotCount,
        snapshotRequested: this.watchlist.length,
        snapshotRetryRequested: result.requested,
        snapshotErrors: allErrors,
        lastSnapshotAt: new Date().toISOString(),
        snapshotPolicy: SNAPSHOT_POLICY,
      });
      return result;
    } catch (error) {
      setConnection({ snapshotStatus: 'error', snapshotErrors: [{ error: String(error.message || error) }] });
      throw error;
    } finally {
      this.snapshotBusy = false;
    }
  }

  closeSyncStateKey(date) { return `${CLOSE_SYNC_STATE_PREFIX}${date}`; }

  smartMoneyCheckpointKey(date) { return `${SMART_MONEY_CHECKPOINT_PREFIX}${date}`; }

  async persistSmartMoneyCheckpoints(now = new Date()) {
    const date = kstClockParts(now).compactDate;
    const rows = {};
    for (const [code, stock] of state.stocks.entries()) {
      const cp = stock && stock.smartMoneyCheckpoint;
      if (cp && cp.sessionDate === date && Number(cp.at || 0) > 0) rows[code] = cp;
    }
    if (Object.keys(rows).length) await setItem(this.smartMoneyCheckpointKey(date), { date, updatedAt: now.toISOString(), rows });
    return rows;
  }

  async hydrateSmartMoneyCheckpoints(now = new Date()) {
    const date = kstClockParts(now).compactDate;
    const saved = await getItem(this.smartMoneyCheckpointKey(date)).catch(() => null);
    const rows = saved && saved.rows || {};
    for (const [code, cp] of Object.entries(rows)) {
      const stock = state.stocks.get(code);
      if (stock && cp && cp.sessionDate === date) stock.smartMoneyCheckpoint = cp;
    }
  }


  async loadCloseSyncState(clock) {
    const key = this.closeSyncStateKey(clock.isoDate);
    if (this.closeSyncCache.has(key)) return this.closeSyncCache.get(key);
    const saved = await getItem(key).catch(() => null);
    const value = saved && typeof saved === 'object' ? saved : { version: 5, date: clock.isoDate, stages: {} };
    value.version = 5; value.date = clock.isoDate; value.stages = value.stages && typeof value.stages === 'object' ? value.stages : {};
    this.closeSyncCache.set(key, value);
    return value;
  }

  async saveCloseSyncState(clock, syncState) {
    const key = this.closeSyncStateKey(clock.isoDate);
    syncState.updatedAt = new Date().toISOString();
    this.closeSyncCache.set(key, syncState);
    await setItem(key, syncState);
    this.publishCloseSyncState(syncState);
  }

  publishCloseSyncState(syncState) {
    const summarize = (stage) => {
      const row = syncState && syncState.stages && syncState.stages[stage] || {};
      return {
        status: row.status || 'waiting', attempts: Number(row.attempts || 0),
        pending: Array.isArray(row.pendingCodes) ? row.pendingCodes.length : 0,
        success: Array.isArray(row.successCodes) ? row.successCodes.length : 0,
        lastAttemptAt: row.lastAttemptAt || null, nextRetryAt: row.nextRetryAt || null,
        completedAt: row.completedAt || null, trigger: row.lastTrigger || null,
      };
    };
    setConnection({ closeSync: { version: 5, date: syncState && syncState.date || null, KRX_CLOSE: summarize('KRX_CLOSE'), NXT_CLOSE: summarize('NXT_CLOSE') } });
  }

  reconcileStageState(syncState, stage) {
    const codes = [...new Set(this.watchlist.map((x) => String(x.code)))];
    const prior = syncState.stages[stage] && typeof syncState.stages[stage] === 'object' ? syncState.stages[stage] : {};
    const success = new Set((prior.successCodes || []).filter((code) => codes.includes(code)));
    const pending = codes.filter((code) => !success.has(code));
    const next = {
      status: pending.length ? (prior.status === 'ready' ? 'pending_retry' : (prior.status || 'waiting')) : 'ready',
      attempts: Number(prior.attempts || 0), successCodes: [...success], pendingCodes: pending,
      lastAttemptAt: prior.lastAttemptAt || null, lastAttemptMinute: Number.isFinite(Number(prior.lastAttemptMinute)) ? Number(prior.lastAttemptMinute) : null,
      nextRetryAt: prior.nextRetryAt || null, completedAt: pending.length ? null : (prior.completedAt || new Date().toISOString()),
      errors: Array.isArray(prior.errors) ? prior.errors.slice(-20) : [], lastTrigger: prior.lastTrigger || null,
    };
    syncState.stages[stage] = next;
    return next;
  }

  nextCloseRetryAt(stage, clock, attempts) {
    const plan = CLOSE_SYNC_PLANS[stage];
    const nextMinute = plan.schedule.find((minute) => minute > clock.minute);
    if (nextMinute != null) return kstMinuteToUtcIso(clock.isoDate, nextMinute);
    if (attempts < CLOSE_SYNC_MAX_ATTEMPTS) return new Date(clock.nowMs + CLOSE_SYNC_POST_FINAL_RETRY_MS).toISOString();
    return null;
  }

  snapshotPassesCloseStage(snapshot, stage, targetDate) {
    const cs = snapshot && snapshot.closeSync || {};
    const targetMatches = String(cs.targetDate || '') === targetDate;
    return stage === 'KRX_CLOSE'
      ? Boolean(targetMatches && cs.krxOfficialConfirmed && cs.officialFlowConfirmed)
      : Boolean(targetMatches && cs.krxOfficialConfirmed && cs.nxtFinalConfirmed && cs.officialFlowConfirmed);
  }

  closeStageFailureReason(snapshot, stage) {
    const cs = snapshot && snapshot.closeSync || {};
    if (!cs.krxOfficialConfirmed) return `KRX 공식종가 미확정(${cs.krxStatus || 'PENDING'})`;
    if (!cs.officialFlowConfirmed) return `공식 수급 미확정(${cs.flowStatus || 'PENDING'})`;
    if (stage === 'NXT_CLOSE' && !cs.nxtFinalConfirmed) return `NXT 최종가 미확정(${cs.nxtStatus || 'PENDING'})`;
    return '종가 동기화 조건 미충족';
  }

  applyCloseStageResult(stageState, stage, result, clock, trigger) {
    const successNow = new Set();
    const syncErrors = [];
    for (const snapshot of result && result.snapshots || []) {
      if (this.snapshotPassesCloseStage(snapshot, stage, clock.compactDate)) successNow.add(String(snapshot.code));
      else syncErrors.push({ code: String(snapshot && snapshot.code || '?'), error: this.closeStageFailureReason(snapshot, stage) });
    }
    for (const error of result && result.errors || []) syncErrors.push({ code: String(error.code || '?'), error: String(error.error || error.message || error) });
    const success = new Set([...(stageState.successCodes || []), ...successNow]);
    const currentCodes = this.watchlist.map((x) => String(x.code));
    const pending = currentCodes.filter((code) => !success.has(code));
    stageState.attempts = Number(stageState.attempts || 0) + 1;
    stageState.successCodes = [...success].filter((code) => currentCodes.includes(code));
    stageState.pendingCodes = pending;
    stageState.lastAttemptAt = new Date(clock.nowMs).toISOString();
    stageState.lastAttemptMinute = clock.minute;
    stageState.lastTrigger = trigger;
    stageState.errors = [...(stageState.errors || []), ...syncErrors].slice(-20);
    if (!pending.length) {
      stageState.status = 'ready'; stageState.nextRetryAt = null; stageState.completedAt = new Date(clock.nowMs).toISOString();
    } else {
      stageState.nextRetryAt = this.nextCloseRetryAt(stage, clock, stageState.attempts);
      stageState.status = stageState.nextRetryAt ? 'pending_retry' : 'degraded';
      stageState.completedAt = null;
    }
    return pending;
  }

  async runCloseSyncStage(stage, clock, trigger = 'schedule') {
    const syncState = await this.loadCloseSyncState(clock);
    const stageState = this.reconcileStageState(syncState, stage);
    if (!stageState.pendingCodes.length) { stageState.status = 'ready'; await this.saveCloseSyncState(clock, syncState); return null; }
    const pendingSet = new Set(stageState.pendingCodes);
    const targets = this.watchlist.filter((item) => pendingSet.has(String(item.code)));
    if (!targets.length) { stageState.status = 'ready'; stageState.pendingCodes = []; stageState.completedAt = new Date().toISOString(); await this.saveCloseSyncState(clock, syncState); return null; }

    const result = await this.refreshSnapshots(stage.toLowerCase(), targets, { stage, targetDate: clock.compactDate, now: new Date(clock.nowMs) });
    if (!result) return null;
    const pending = this.applyCloseStageResult(stageState, stage, result, clock, trigger);
    await this.saveCloseSyncState(clock, syncState);
    setConnection({
      snapshotStatus: pending.length ? 'partial' : 'ready',
      snapshotErrors: stageState.errors,
      snapshotRetryPending: pending.length,
      snapshotRetryCodes: pending,
      snapshotReason: stage.toLowerCase(),
    });
    return { ...result, stage, pendingCodes: pending, successCodes: stageState.successCodes, closeSyncStatus: stageState.status };
  }

  async runCombinedCloseSync(clock, trigger = 'restart_catchup_combined') {
    const syncState = await this.loadCloseSyncState(clock);
    const krxState = this.reconcileStageState(syncState, 'KRX_CLOSE');
    const nxtState = this.reconcileStageState(syncState, 'NXT_CLOSE');
    const union = new Set([...(krxState.pendingCodes || []), ...(nxtState.pendingCodes || [])]);
    const targets = this.watchlist.filter((item) => union.has(String(item.code)));
    if (!targets.length) { await this.saveCloseSyncState(clock, syncState); return null; }

    // 20:01 이후 KRX와 NXT가 모두 미완료라면 동일 종목을 두 번 REST 순회하지 않는다.
    // NXT_CLOSE 한 번의 스냅샷으로 KRX 공식종가/수급/NXT 최종값을 동시에 검증한다.
    const result = await this.refreshSnapshots('combined_close_sync', targets, {
      stage: 'NXT_CLOSE', targetDate: clock.compactDate, now: new Date(clock.nowMs), combinedCloseSync: true,
    });
    if (!result) return null;
    const krxPending = this.applyCloseStageResult(krxState, 'KRX_CLOSE', result, clock, trigger);
    const nxtPending = this.applyCloseStageResult(nxtState, 'NXT_CLOSE', result, clock, trigger);
    await this.saveCloseSyncState(clock, syncState);
    const pending = [...new Set([...krxPending, ...nxtPending])];
    const errors = [...(krxState.errors || []), ...(nxtState.errors || [])].slice(-20);
    setConnection({
      snapshotStatus: pending.length ? 'partial' : 'ready', snapshotErrors: errors,
      snapshotRetryPending: pending.length, snapshotRetryCodes: pending,
      snapshotReason: 'combined_close_sync', closeSyncCoalescedAt: new Date(clock.nowMs).toISOString(),
    });
    return { ...result, stage: 'COMBINED_CLOSE', pendingCodes: pending, closeSyncStatus: pending.length ? 'pending_retry' : 'ready' };
  }

  async runStartupCloseCatchup(now = new Date()) {
    const clock = kstClockParts(now);
    if (clock.weekday === 0 || clock.weekday === 6 || clock.minute < CLOSE_SYNC_PLANS.KRX_CLOSE.start) return null;
    if (this.startupCloseCatchupDate === clock.compactDate) return null;
    this.startupCloseCatchupDate = clock.compactDate;
    const stages = clock.minute >= CLOSE_SYNC_PLANS.NXT_CLOSE.start ? ['KRX_CLOSE', 'NXT_CLOSE'] : ['KRX_CLOSE'];
    const syncState = await this.loadCloseSyncState(clock);
    let staleCount = 0;
    for (const stage of stages) {
      const row = this.reconcileStageState(syncState, stage);
      const validSuccess = [];
      for (const code of row.successCodes || []) {
        const stock = state.stocks.get(String(code));
        if (this.snapshotPassesCloseStage(stock && stock.marketSnapshot, stage, clock.compactDate)) validSuccess.push(String(code));
      }
      row.successCodes = validSuccess;
      row.pendingCodes = this.watchlist.map((x) => String(x.code)).filter((code) => !validSuccess.includes(code));
      if (row.pendingCodes.length) { row.status = 'waiting'; row.nextRetryAt = null; row.completedAt = null; staleCount += row.pendingCodes.length; }
    }
    await this.saveCloseSyncState(clock, syncState);
    if (!staleCount) {
      setConnection({ startupCloseCatchup: { status: 'ready', at: new Date().toISOString(), targetDate: clock.compactDate, pending: 0 } });
      return null;
    }
    setConnection({ startupCloseCatchup: { status: 'running', at: new Date().toISOString(), targetDate: clock.compactDate, pending: staleCount } });
    const result = clock.minute >= CLOSE_SYNC_PLANS.NXT_CLOSE.start
      ? await this.runCombinedCloseSync(clock, 'startup_freshness_catchup')
      : await this.runCloseSyncStage('KRX_CLOSE', clock, 'startup_freshness_catchup');
    const pending = Array.isArray(result && result.pendingCodes) ? result.pendingCodes.length : 0;
    setConnection({ startupCloseCatchup: { status: pending ? 'partial' : 'ready', at: new Date().toISOString(), targetDate: clock.compactDate, pending } });
    return result;
  }

  async maybeScheduledCloseRefresh(now = new Date()) {
    const clock = kstClockParts(now);
    if (clock.weekday === 0 || clock.weekday === 6) return null;
    const syncState = await this.loadCloseSyncState(clock);
    let changed = false;
    for (const stage of ['KRX_CLOSE', 'NXT_CLOSE']) {
      const before = JSON.stringify(syncState.stages[stage] || null);
      this.reconcileStageState(syncState, stage);
      if (before !== JSON.stringify(syncState.stages[stage])) changed = true;
    }
    if (changed) await this.saveCloseSyncState(clock, syncState);

    const krxPlan = CLOSE_SYNC_PLANS.KRX_CLOSE;
    const nxtPlan = CLOSE_SYNC_PLANS.NXT_CLOSE;
    const krx = syncState.stages.KRX_CLOSE;
    const nxt = syncState.stages.NXT_CLOSE;
    const due = (stageState) => !stageState.lastAttemptAt || Boolean(stageState.nextRetryAt && clock.nowMs >= Date.parse(stageState.nextRetryAt));

    // NXT 종료 이후에는 NXT가 due이고 KRX도 미완료이면 한 번의 결합 동기화로 처리한다.
    if (clock.minute >= nxtPlan.start && nxt.pendingCodes.length && nxt.status !== 'ready' && due(nxt)) {
      if (krx.pendingCodes.length && krx.status !== 'ready') {
        return this.runCombinedCloseSync(clock, !nxt.lastAttemptAt ? 'restart_catchup_combined' : 'combined_retry');
      }
      return this.runCloseSyncStage('NXT_CLOSE', clock, !nxt.lastAttemptAt && clock.minute > nxtPlan.start ? 'restart_catchup' : 'scheduled_retry');
    }

    if (clock.minute >= krxPlan.start && krx.pendingCodes.length && krx.status !== 'ready' && due(krx)) {
      return this.runCloseSyncStage('KRX_CLOSE', clock, !krx.lastAttemptAt && clock.minute > krxPlan.start ? 'restart_catchup' : 'scheduled_retry');
    }

    this.publishCloseSyncState(syncState);
    return null;
  }

  isKrxCloseAuditWindow(now = new Date()) {
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const day = kst.getUTCDay();
    if (day === 0 || day === 6) return false;
    const minute = kst.getUTCHours() * 60 + kst.getUTCMinutes();
    // 종가 스마트머니 표본 누락 방지: 14:40~15:35 KST에만 30종목 모두 정밀피드로 승격.
    // REST를 늘리지 않고 기존 단일 WebSocket 세션 안에서 체결/호가/프로그램을 확보한다.
    return minute >= 14 * 60 + 40 && minute <= 15 * 60 + 35;
  }

  subscriptionGroups(watchlist) {
    const now = Date.now();
    const { focus, light } = splitWatchlist(watchlist);
    const promoted = light.filter((item) => {
      const stock = state.stocks.get(item.code);
      return stock && stock.promotedUntil > now;
    });
    const promotedCodes = new Set(promoted.map((x) => x.code));
    const closeAudit = this.isKrxCloseAuditWindow(new Date(now));
    const full = closeAudit ? [...watchlist] : [...focus, ...promoted];
    const lightOnly = closeAudit ? [] : light.filter((x) => !promotedCodes.has(x.code));
    return { full, lightOnly, promoted, closeAudit };
  }

  sendReg(groupNo, label, data, refresh = '1', meta = {}) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !Array.isArray(data) || !data.length) return false;
    const request = { groupNo:String(groupNo), label, at:Date.now(), data,
      venue:meta.venue || null, kind:meta.kind || 'AUX', required:Boolean(meta.required),
      codes:Array.isArray(meta.codes)?meta.codes.map(String):[], types:Array.isArray(meta.types)?meta.types.map(String):[] };
    this.pendingRegGroups.push(request); this.regRequests.set(String(groupNo), request);
    this.ws.send(JSON.stringify({ trnm:'REG', grp_no:String(groupNo), refresh:String(refresh), data }));
    setConnection({ venueRegistration:{ ...(state.connection.venueRegistration||{}), [label]:'pending' } });
    return true;
  }

  chunks(items, size = 8) { const out=[]; for(let i=0;i<items.length;i+=size) out.push(items.slice(i,i+size)); return out; }

  resetRealtimeAckState() {
    this.acceptedTradeCodes = { KRX:new Set(), NXT:new Set(), SOR:new Set() };
    this.firstTradeAt = { KRX:new Map(), NXT:new Map(), SOR:new Map() };
    this.failedTradeCodes = { KRX:new Map(), NXT:new Map(), SOR:new Map() };
    this.regRequests.clear(); this.pendingRegGroups=[];
  }

  registrationStats(now = Date.now()) {
    const requested = new Set((state.connection.subscribed || []).map((x) => String(x).replace(/_(AL|NX)$/i, '')));
    const summarizeVenue = (venue) => {
      let fresh = 0, newest = 0, first = 0;
      for (const code of requested) {
        const stock = state.stocks.get(code); const v = stock && stock.venues && stock.venues[venue]; const at = Number(v && v.updatedAt || 0);
        newest = Math.max(newest, at); if (at && now - at <= VENUE_STALE_MS) fresh += 1;
        if (this.firstTradeAt[venue] && this.firstTradeAt[venue].has(code)) first += 1;
      }
      return { requested: requested.size, firstTick: first, fresh, venueConfirmed: first > 0,
        lastTradeAt: newest ? new Date(newest).toISOString() : null, dataReady: fresh > 0 };
    };
    return {
      DOMESTIC: { requested: requested.size, regAccepted: Number(state.connection.domesticCoreRegAccepted || 0), regFailed: Number(state.connection.domesticCoreRegFailed || 0) },
      KRX: summarizeVenue('KRX'), NXT: summarizeVenue('NXT'),
      detectedTradeType: state.connection.detectedTradeType || null,
      truthPolicy: 'REAL_0A_FID9081_ONLY',
    };
  }

  async subscribe(watchlist, replace = false) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const { full, lightOnly, promoted, closeAudit } = this.subscriptionGroups(watchlist);
    const baseCodes = [...new Set(watchlist.map((x) => String(x.code || '').replace(/[^0-9]/g, '').slice(0, 6)).filter(Boolean))];
    const baseFull = full.map((x) => x.code), baseLight = lightOnly.map((x) => x.code);
    this.watchlist = watchlist;
    this.metaByCode = new Map(watchlist.map((item) => [String(item.code).replace(/[^0-9]/g, '').slice(0, 6), item]));
    this.watchHash = JSON.stringify({ baseCodes, baseFull, baseLight, closeAudit });
    if (replace) this.resetRealtimeAckState(); else this.pendingRegGroups = [];

    // v3.3.5 OFFICIAL DOMESTIC WEBSOCKET REG + OFFICIAL TRADE TYPE
    // 국내 WebSocket bare-code REG 구조를 유지하고 주식체결 실시간 type은 0A를 사용한다.
    // 공식 문서에서 _NX/_AL은 REST 거래소별 stk_cd로 명시되어 있으며, 국내 WebSocket REG의 별도 NXT item 규격으로 명시되지 않았다.
    // 따라서 하나의 국내 WebSocket에 bare 종목코드만 등록하고, KRX/NXT 판별은 수신 REAL payload의 기존 truth route에서만 수행한다.
    this.sendReg('1', 'DOMESTIC_TRADE_0A', [{ item: baseCodes, type: ['0A'] }], replace ? '0' : '1', {
      venue: 'DOMESTIC', kind: 'CORE_TRADE_DOMESTIC', required: true, codes: baseCodes, types: ['0A'],
    });
    for (const [i, batch] of this.chunks(baseCodes, 8).entries()) {
      this.sendReg(String(2 + i), `DOMESTIC_AUX_${i + 1}`, [{ item: batch, type: ['0D', '0u'] }], '1', {
        venue: 'DOMESTIC', kind: 'AUX', codes: batch, types: ['0D', '0u'],
      });
    }
    if (baseFull.length) this.sendReg('10', 'DOMESTIC_FOCUS_BROKER', [{ item: baseFull, type: ['0F'] }], '1', {
      venue: 'DOMESTIC', kind: 'AUX', codes: baseFull, types: ['0F'],
    });
    this.sendReg('90', 'MARKET_STATUS', [{ item: [''], type: ['0m'] }], '1', { kind: 'GLOBAL', codes: [], types: ['0m'] });

    resetSubscriptions({ all: baseCodes, focus: baseFull, light: baseLight, wire: baseCodes, krx: baseCodes, nxt: baseCodes });
    setConnection({
      promoted: promoted.map((x) => x.code), wireSubscribed: baseCodes, krxSubscribed: baseCodes, nxtSubscribed: baseCodes,
      closeAuditMode: Boolean(closeAudit), closeAuditFullCount: closeAudit ? full.length : 0,
      realtimeRegistrationMode: 'KIWOOM_OFFICIAL_DOMESTIC_BARE_REG_V4', requestedSubscriptions: { DOMESTIC: baseCodes.length },
      venueCoreRegAccepted: { KRX: 0, NXT: 0 }, venueCoreRegFailed: { KRX: 0, NXT: 0 },
      coreRegAccepted: 0, coreRegFailed: 0, detectedTradeType: '0A',
      registrationTruthPolicy: 'DOMESTIC_REG_ACK_THEN_REAL_ROUTE_FIRST_TICK_THEN_FRESH',
    });
  }

  expectedVenues(now = new Date()) {
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const day = kst.getUTCDay(); if (day === 0 || day === 6) return [];
    const sec = kst.getUTCHours() * 3600 + kst.getUTCMinutes() * 60 + kst.getUTCSeconds();
    const venues = [];
    if (sec >= 9 * 3600 && sec <= 15 * 3600 + 30 * 60) venues.push('KRX');
    // NXT 실제 체결시간: 프리 08:00~08:50, 메인 09:00:30~15:20, 애프터 15:40~20:00.
    const nxtActive = (sec >= 8 * 3600 && sec <= 8 * 3600 + 50 * 60)
      || (sec >= 9 * 3600 + 30 && sec <= 15 * 3600 + 20 * 60)
      || (sec >= 15 * 3600 + 40 * 60 && sec <= 20 * 3600);
    if (nxtActive) venues.push('NXT');
    return venues;
  }

  venueHealth(now = Date.now()) {
    const result = {
      KRX: { fresh: 0, stale: 0, subscribed: 0, lastTradeAt: null, lastTradeAgeMs: null },
      NXT: { fresh: 0, stale: 0, subscribed: 0, lastTradeAt: null, lastTradeAgeMs: null },
    };
    for (const venue of ['KRX','NXT']) {
      const wire = venue === 'KRX' ? (state.connection.krxSubscribed || []) : (state.connection.nxtSubscribed || []);
      const bases = [...new Set(wire.map((x)=>String(x).replace(/_(AL|NX)$/i,'')))];
      result[venue].subscribed = bases.length;
      let newest = 0;
      for (const code of bases) {
        const stock = state.stocks.get(code);
        const v = stock && stock.venues && stock.venues[venue];
        const at = Number(v && v.updatedAt || 0);
        newest = Math.max(newest, at);
        const fresh = Boolean(at && now - at <= VENUE_STALE_MS);
        if (fresh) result[venue].fresh += 1; else result[venue].stale += 1;
      }
      result[venue].lastTradeAt = newest ? new Date(newest).toISOString() : null;
      result[venue].lastTradeAgeMs = newest ? Math.max(0, now - newest) : null;
    }
    return result;
  }

  async watchdog() {
    const now = Date.now();
    const frameAge = this.lastSocketFrameAt ? now - this.lastSocketFrameAt : Number.POSITIVE_INFINITY;
    const venueHealth = this.venueHealth(now);
    const expected = this.expectedVenues(new Date(now));
    const registrationStats = this.registrationStats(now);
    const activeReady = expected.length ? expected.every((v)=>Number(registrationStats[v]?.fresh || 0) > 0) : true;
    const anyReady = expected.some((v)=>Number(registrationStats[v]?.fresh || 0) > 0);
    const dataStatus = !expected.length ? 'OFF_SESSION' : activeReady ? 'DATA_LIVE' : anyReady ? 'DATA_PARTIAL' : 'DATA_OFFLINE';
    setConnection({
      socketFrameAgeMs: Number.isFinite(frameAge) ? frameAge : null,
      venueHealth, registrationStats, dataStatus,
      expectedVenues: expected,
      realtimeJudgmentRoute: 'KIWOOM_WEBSOCKET_ONLY',
      restFallbackDiagnosticOnly: true,
      intradayRestDiagnosticEnabled: INTRADAY_REST_DIAGNOSTIC,
      scoutRealtimeTypes: SCOUT_TYPES,
      lastWatchdogAt: new Date(now).toISOString(),
    });
    if (this.ws && this.ws.readyState === WebSocket.OPEN && frameAge > SOCKET_WATCHDOG_MS) {
      setConnection({ lastError: `WebSocket 무수신 ${Math.round(frameAge/1000)}초 · 자동 재연결` });
      try { this.ws.terminate(); } catch (_) {}
      return;
    }

    // v3.3.3: 특정 거래소(NXT 포함) firstTick/fresh 부재만으로 정상 WebSocket을 끊거나
    // 다른 등록 형식으로 변칙 재등록하지 않는다. socketFrameAge watchdog만 transport 장애를 재연결한다.
    // 활성 NXT가 미수신이면 NXT_DATA_MISSING으로 fail-closed하고, 장전환 0m 이벤트의 동일 suffix REG 재등록만 허용한다.
    const missingExpected = expected.filter((venue) => Number((venueHealth[venue] && venueHealth[venue].fresh) || 0) <= 0);
    if (missingExpected.length) {
      setConnection({ venueRecovery: { venue: missingExpected.join(','), at: new Date(now).toISOString(), reason:'VENUE_DATA_MISSING_FAIL_CLOSED_NO_SOCKET_RESTART', socketFrameAgeMs:Number.isFinite(frameAge)?frameAge:null } });
    } else {
      setConnection({ venueRecovery: null });
    }

    if (INTRADAY_REST_DIAGNOSTIC && now - this.lastRestFallbackAt >= REST_FALLBACK_INTERVAL_MS) {
      this.lastRestFallbackAt = now;
      await this.restContinuityFallback(now).catch((error) => setConnection({ fallbackLastError: String(error.message || error) }));
    }
  }

  async restContinuityFallback(now = Date.now()) {
    if (this.restFallbackBusy) return;
    const expected = this.expectedVenues(new Date(now)); if (!expected.length) return;
    const focus = (state.connection.focusSubscribed || []).map((x)=>String(x).replace(/_(AL|NX)$/i,''));
    if (!focus.length) return;
    const candidates = [];
    for (const code of focus) {
      const stock = state.stocks.get(code);
      for (const venue of expected) {
        const v = stock && stock.venues && stock.venues[venue];
        if (!v || !v.updatedAt || now - v.updatedAt > VENUE_STALE_MS) candidates.push({ code, venue, age: v && v.updatedAt ? now-v.updatedAt : Number.POSITIVE_INFINITY });
      }
    }
    if (!candidates.length) return;
    candidates.sort((a,b)=>b.age-a.age);
    const pick = candidates[this.restFallbackCursor++ % candidates.length];
    this.restFallbackBusy = true;
    try {
      const queryCode = pick.venue === 'NXT' ? `${pick.code}_NX` : pick.code;
      const info = await getStockInfo(queryCode);
      applyVenueFallbackQuote(pick.code, pick.venue, {
        price: info.cur_prc || info.cur_price || info.stk_prc,
        changePct: info.flu_rt || info.change_rate,
        volume: info.acc_trde_qty || info.acc_volume,
        amount: info.acc_trde_prica || info.acc_trde_amt,
      }, this.metaByCode && this.metaByCode.get(pick.code) || {});
      setConnection({ fallbackLastAt: new Date().toISOString(), fallbackLastVenue: pick.venue, fallbackLastCode: pick.code, fallbackLastError: null, fallbackDiagnosticOnly: true });
    } finally { this.restFallbackBusy = false; }
  }

  async refreshWatchlist() {
    const [list, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    setSignalSettings(mergeSettings(savedSettings).signal);
    const now = Date.now();
    let promotionExpired = false;
    for (const item of list) {
      const stock = state.stocks.get(item.code);
      if (stock && stock.tier === 'LIGHT' && stock.promotedUntil > 0 && stock.promotedUntil <= now) {
        setPromotion(item.code, 0); promotionExpired = true;
      }
    }
    const groups = this.subscriptionGroups(list);
    const hash = JSON.stringify({ closeAudit: Boolean(groups.closeAudit),
      full: groups.full.map((x)=>String(x.code||'').replace(/[^0-9]/g,'').slice(0,6)),
      light: groups.lightOnly.map((x)=>String(x.code||'').replace(/[^0-9]/g,'').slice(0,6)),
    });
    const changed = hash !== this.watchHash;
    if (changed || promotionExpired) await this.subscribe(list, true);
    this.watchlist = list;
    if (changed) {
      // LOW TRAFFIC: 종목 변경 시 저장된 종가만 hydrate하고 장중 전체 REST 재조회는 하지 않는다.
      // 새 종목은 WebSocket 즉시 감시 후 다음 KRX/NXT 종가 동기화 대상에 자동 포함된다.
      await this.hydrateSnapshots(list);
    }
    const prices = {};
    for (const [code, stock] of state.stocks.entries()) prices[code] = stock.price;
    await sweepExpired(prices).catch(() => null);
    await this.persistSmartMoneyCheckpoints(new Date(now)).catch(() => null);
  }

  onMessage(buffer) {
    let message; try { message = JSON.parse(buffer.toString()); } catch (_) { runtimeMetrics.markRealtimeParseError(); return; }
    this.lastSocketFrameAt = Date.now();
    if (message.trnm === 'PING') {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(message));
      setConnection({ lastSocketPingAt: new Date().toISOString() });
      return;
    }
    if (message.trnm === 'REG') {
      const grpNo = String(message.grp_no || '');
      let pendingIndex = grpNo ? this.pendingRegGroups.findIndex((x)=>x.groupNo===grpNo) : 0;
      if (pendingIndex < 0) pendingIndex = 0;
      const pending = this.pendingRegGroups.splice(pendingIndex, 1)[0] || this.regRequests.get(grpNo) || { label: grpNo ? `GROUP_${grpNo}` : 'REG', codes:[], types:[] };
      const ok = Number(message.return_code || 0) === 0;
      const registration = { ...(state.connection.venueRegistration || {}), [pending.label]: ok ? 'ack' : `rejected:${message.return_msg || message.return_code}` };
      if (pending.kind === 'CORE_TRADE_DOMESTIC') {
        setConnection({ domesticCoreRegAccepted: ok ? (pending.codes || []).length : 0, domesticCoreRegFailed: ok ? 0 : (pending.codes || []).length,
          coreRegAccepted: ok ? (pending.codes || []).length : 0, coreRegFailed: ok ? 0 : (pending.codes || []).length });
      }
      setConnection({ venueRegistration: registration, registrationStats: this.registrationStats(), lastRegistrationAt: new Date().toISOString() });
      if (!ok) {
        const fatal = Boolean(pending.required);
        setConnection({ lastError: `실시간 등록 ${pending.label} 실패: ${message.return_msg || message.return_code}${fatal ? ' · 핵심 체결루트 재연결' : ' · 격리/보조루트 유지'}` });
        if (fatal && this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.close(1011, 'required realtime registration failed');
      }
      return;
    }
    if (message.trnm !== 'REAL' || !Array.isArray(message.data)) return;
    runtimeMetrics.markRealtimeFrame(message.data.length);
    setConnection({ lastMessageAt: new Date().toISOString() });
    for (const entry of message.data) {
      runtimeMetrics.markRealtimeType(entry.type);
      const payloadCode = entry.type === '0w' ? entry.values && entry.values['9001'] : entry.item;
      const baseCode = String(payloadCode || '').replace(/_(AL|NX)$/i, '');
      if (entry.type === '0w' && (!this.metaByCode || !this.metaByCode.has(baseCode))) continue;
      const metadata = this.metaByCode ? this.metaByCode.get(baseCode) : null;
      const values = entry.values || {};
      const tradeLike = entry.type === '0A' && values['10'] != null && (values['15'] != null || values['13'] != null || values['228'] != null);
      let routeVenue = null; let routeSource = null;
      const expectedNow = this.expectedVenues(new Date());
      if (tradeLike && baseCode) {
        const rawItem=String(entry.item||'').toUpperCase();
        const explicit=String(values['9081']||'').trim().toUpperCase();
        routeVenue = explicit.includes('NXT') || explicit === '2' ? 'NXT' : explicit.includes('KRX') || explicit === '1' ? 'KRX' : 'UNKNOWN';
        routeSource = routeVenue === 'UNKNOWN' ? 'FID9081_MISSING_OR_UNKNOWN' : 'FID9081_VENUE_TRUTH';
        if(routeVenue !== 'UNKNOWN' && this.firstTradeAt[routeVenue]) { if(!this.firstTradeAt[routeVenue].has(baseCode)) this.firstTradeAt[routeVenue].set(baseCode,Date.now()); }
        setConnection({ detectedTradeType:entry.type, lastTradeTickAt:new Date().toISOString() });
      }
      if (tradeLike && routeVenue && routeVenue !== 'UNKNOWN') {
        const dedupeKey = [baseCode, routeVenue, String(values['20']||''), String(values['10']||''), String(values['15']||''), String(values['13']||'')].join('|');
        const previousAt = Number(this.tradeDedupe.get(dedupeKey) || 0);
        const nowMs = Date.now();
        this.tradeDedupe.set(dedupeKey, nowMs);
        if (previousAt && nowMs - previousAt < 1500) {
          realtimeDebug.record(entry, { venue: routeVenue, source: `${routeSource}:DUPLICATE_SKIPPED`, expectedVenues: expectedNow, tradeLike });
          continue;
        }
        if (this.tradeDedupe.size > 5000) {
          for (const [key, at] of this.tradeDedupe) if (nowMs - Number(at || 0) > 5000) this.tradeDedupe.delete(key);
        }
      }
      realtimeDebug.record(entry, { venue: routeVenue, source: routeSource, expectedVenues: expectedNow, tradeLike });
      processRealtimeEntry(entry, metadata || {});
      // LOW TRAFFIC PIPELINE: 장운영 이벤트는 상태표시에만 사용한다.
      // 전체 REST 스냅샷은 절대 여기서 호출하지 않고 KRX/NXT 예약 종가 동기화만 사용한다.
      if (entry.type === '0m') {
        this.maybeScheduledCloseRefresh().catch(() => null);
        this.handleMarketStatusRealtime(entry.values || {});
      }
      if (!baseCode) continue;
      this.schedulePostProcess(baseCode, { trade: tradeLike });
    }
  }

  handleMarketStatusRealtime(values = {}) {
    const operation = String(values['215'] || '').trim();
    if (!['3','P','R','U'].includes(operation) || operation === this.lastMarketStartOperation) return;
    this.lastMarketStartOperation = operation;
    // 장 전환 직후 REG 유실/지연을 기다리지 않고 즉시 재등록한다. refresh=1로 기존 구독을 지우지 않는다.
    for (const [idx, delay] of [100, 1500, 4000].entries()) {
      const key = `open-${operation}-${idx}`;
      const old = this.marketStatusRefreshTimers.get(key); if (old) clearTimeout(old);
      const timer = setTimeout(async () => {
        this.marketStatusRefreshTimers.delete(key);
        if (this.resubscribeBusy || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        this.resubscribeBusy = true;
        try {
          await this.subscribe(this.watchlist, false);
          setConnection({ marketOpenRecovery: { operation, at: new Date().toISOString(), delayMs: delay } });
        } catch (error) {
          setConnection({ lastError: `장전환 REG 재등록 실패: ${error.message}` });
        } finally { this.resubscribeBusy = false; }
      }, delay);
      if (timer.unref) timer.unref();
      this.marketStatusRefreshTimers.set(key, timer);
    }
  }

  schedulePostProcess(code, flags = {}) {
    const existing = this.postPending.get(code);
    if (existing) {
      existing.trade = existing.trade || Boolean(flags.trade);
      runtimeMetrics.incrementPostProcess('coalesced');
    } else {
      this.postPending.set(code, { trade: Boolean(flags.trade) });
    }
    runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
    this.drainPostProcess();
  }

  drainPostProcess() {
    while (this.postActive < this.postMaxConcurrency) {
      const next = [...this.postPending.entries()].find(([code]) => !this.postRunning.has(code));
      if (!next) break;
      const [code, flags] = next;
      this.postPending.delete(code);
      this.postRunning.add(code);
      this.postActive += 1;
      runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
      setImmediate(async () => {
        try {
          const stock = state.stocks.get(code);
          if (flags.trade) {
            await this.maybePromote(code);
            if (stock && stock.price > 0) {
              await Promise.all([
                updatePerformancePrice(code, stock.price),
                updateLedgerPrice(code, stock.price),
              ]);
            }
            await this.maybeRiskNotify(code);
          }
          await this.maybeNotify(code);
          runtimeMetrics.incrementPostProcess('processed');
        } catch (error) {
          runtimeMetrics.incrementPostProcess('errors');
          console.error(`[post-process] ${code} 처리 실패: ${error.message}`);
        } finally {
          this.postRunning.delete(code);
          this.postActive = Math.max(0, this.postActive - 1);
          runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
          this.drainPostProcess();
        }
      });
    }
  }

  schedulePositionsPersist() {
    this.positionPersistDirty = true;
    if (this.positionPersistTimer) return;
    this.positionPersistTimer = setTimeout(() => {
      this.positionPersistTimer = null;
      this.flushPositions().catch((error) => console.error(`[positions] 배치 저장 실패: ${error.message}`));
    }, Math.max(200, Number(process.env.POSITION_BATCH_MS || 750)));
    if (this.positionPersistTimer.unref) this.positionPersistTimer.unref();
  }

  async flushPositions() {
    if (!this.positionPersistDirty || !this.positionCache || !Array.isArray(this.positionCache.positions)) return;
    this.positionPersistDirty = false;
    await setItem('positions', this.positionCache.positions);
    this.positionCache.loadedAt = Date.now();
  }

  async maybePromote(code) {
    const stock = state.stocks.get(code);
    if (!stock || stock.tier !== 'LIGHT' || stock.promotedUntil > Date.now() || stock.promotionScore < Number(state.settings.promotionMinScore || 60)) return;
    const max = Number(state.settings.maxPromotedLight || 4);
    const current = [...state.stocks.values()].filter((s) => s.tier === 'LIGHT' && s.promotedUntil > Date.now());
    if (current.length >= max) return;
    const seconds = Number(state.settings.promotionSeconds || 600);
    setPromotion(code, Date.now() + seconds * 1000);
    if (this.resubscribeBusy) return;
    this.resubscribeBusy = true;
    try { await this.subscribe(this.watchlist, false); }
    finally { this.resubscribeBusy = false; }
  }

  async loadPositionCache() {
    if (Date.now() - this.positionCache.loadedAt < 30_000) return this.positionCache;
    const [positions, savedSettings] = await Promise.all([getItem('positions'), getItem('settings')]);
    this.positionCache = { loadedAt: Date.now(), positions: Array.isArray(positions) ? positions : [], settings: mergeSettings(savedSettings) };
    return this.positionCache;
  }

  async maybeRiskNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !(stock.price > 0)) return;
    const cache = await this.loadPositionCache();
    const openPositions = cache.positions.filter((position) => position.status !== 'closed' && String(position.code) === code);
    if (!openPositions.length) return;
    let changed = false;
    for (const position of openPositions) {
      const cfg = cache.settings.perStock[code] || { stopPct: -1.5 };
      const avg = Number(position.avgPrice || 0); if (!(avg > 0)) continue;
      const initialStop = Number(position.initialStopPrice || avg * (1 + Number(cfg.stopPct || -1.5) / 100));
      const highest = Math.max(Number(position.highestPrice || avg), stock.price);
      if (highest !== Number(position.highestPrice || avg) || Number(position.currentStopPrice || 0) !== Math.round(initialStop)) {
        position.highestPrice = highest;
        // v3.1.16: 보유종목 대응은 단순화. 자동 트레일링/목표가 매도 알림 대신 매수가 기준 설정 손절가만 사용한다.
        position.currentStopPrice = Math.round(initialStop);
        position.trailActive = false;
        position.updatedAt = new Date().toISOString();
        changed = true;
      }
      if (stock.price > initialStop) continue;
      const notified = Array.isArray(position.notifiedLevels) ? position.notifiedLevels : [];
      if (notified.includes('STOP')) continue; // 한 포지션당 손절가 도달 알림 1회
      position.notifiedLevels = [...new Set([...notified, 'STOP'])];
      changed = true;
      await notify({
        type: 'critical', action: 'SELL', code, name: stock.name, price: stock.price,
        message: `보유종목 손절가 도달 · 현재 ${stock.price.toLocaleString()}원 · 손절 ${Math.round(initialStop).toLocaleString()}원`,
        reasons: [`매수가 ${Math.round(avg).toLocaleString()}원 대비 설정 손절가 도달 · 일반 매도잡신호와 무관`],
      });
    }
    if (changed) this.schedulePositionsPersist();
  }

  async maybeNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !stock.signal) return;
    // EARLY/BUY 기록·알림은 현재 활성 세션의 Kiwoom WebSocket 체결(0A)이 신선할 때만 허용한다.
    if (!realtimeTruth(stock, Date.now()).eligible) return;
    const signal = stock.signal;
    const earlyEligible = signal.action === 'EARLY'
      && stock.activeTier === 'FOCUS'
      && Boolean(signal.preSurgeEligible || signal.earlyDiscoveryEligible)
      && Number(signal.preSurgeScore || 0) >= Math.max(62, Number(state.settings.preSurgeEarlyScore || 68) - 6);
    const buyEligible = signal.action === 'BUY' && Boolean(signal.confirmed);
    const observation = {
      preSurgeScore: Number(signal.preSurgeScore || 0),
      activeGroups: Number(signal.preSurgeGroups || 0),
      executionScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.execution || 0),
      flowScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.flow || 0),
      orderbookScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.orderbook || 0),
      priceVolumeScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.priceVolume || 0),
      tradeStrength: Number(signal.metrics && signal.metrics.tradeStrength || 0),
      netBuyAmount5s: Number(signal.metrics && signal.metrics.netBuyAmount5s || 0),
      rvol1m: Number(signal.metrics && signal.metrics.rvol1m || 0),
      smartMoneyState: signal.smartMoneyState || 'NEUTRAL',
    };
    // 같은 EARLY가 유지되는 동안에도 15초/의미변화 단위로 강화 궤적만 갱신한다.
    // 푸시/타임라인 이벤트는 늘리지 않으므로 화면·알림 잡음은 증가하지 않는다.
    if (earlyEligible) {
      await updateObservationTrajectory({ code, name: stock.name, price: stock.price, observation, at: Date.now() });
    }

    // v3.1.18: 일반 감시종목은 상승초입/BUY만 기록한다.
    // 하락압력 점수는 신규진입 안전필터일 뿐 RISK/EARLY_SELL/SELL 기록·푸시로 확장하지 않는다.
    if (!buyEligible && !earlyEligible) {
      stock.activeNotificationStage = null;
      stock.entryRestricted = false;
      stock.entryRestrictionReason = null;
      if (signal.blockedByProfitPriority) {
        await recordShadowSignal({
          code,
          name: stock.name,
          price: stock.price,
          qualityScore: signal.qualityScore,
          profitPriorityScore: signal.profitPriorityScore,
          minProfitPriorityScore: Number(state.settings.minProfitPriorityScore || 78),
          vwapDistancePct: Number(signal.metrics && signal.metrics.vwapDistancePct || 0),
          spreadBps: Number(signal.metrics && signal.metrics.spreadBps || 0),
          reasons: [...signal.reasons, ...signal.warnings],
          at: Date.now(),
        });
      }
      return;
    }

    const cache = await this.loadPositionCache();
    const risk = accountRisk(cache.positions, cache.settings);
    const limitReached = risk.openCount >= Number(cache.settings.maxConcurrentPositions || 2);
    stock.entryRestricted = Boolean(risk.halted || limitReached);
    stock.entryRestrictionReason = risk.halted
      ? `신규진입 제한: ${risk.reasons.join(' · ')}`
      : limitReached ? `신규진입 제한: 최대 동시보유 ${cache.settings.maxConcurrentPositions || 2}종목` : null;

    const now = Date.now();
    const notificationAction = buyEligible ? 'BUY' : 'EARLY';
    if (stock.activeNotificationStage === notificationAction) return;
    const configuredCooldownMs = Number(state.settings.signalCooldownSeconds || 300) * 1000;
    const historyKey = `${code}:${notificationAction}`;
    const lastActionAt = this.notificationHistory.get(historyKey) || 0;
    if (now - lastActionAt < configuredCooldownMs) return;
    if (this.notificationBusy.has(historyKey)) return;
    this.notificationBusy.add(historyKey);
    try {
      stock.lastNotifiedAction = notificationAction;
      stock.lastNotifiedAt = now;
      stock.activeNotificationStage = notificationAction;
      this.notificationHistory.set(historyKey, now);
      const performanceSummary = globalThis.__SIGNAL_PERFORMANCE__;
      const verified = Boolean(performanceSummary && performanceSummary.outcomes && performanceSummary.outcomes.filter((x) => x.result === 'WIN' || x.result === 'LOSS').length >= 200);
      const recommendationContext = await getRecommendationLearningContext(code).catch(() => null);
      const learningContext = {
        ...(recommendationContext || {}),
        qualityScore: Number(signal.qualityScore || 0),
        profitPriorityScore: Number(signal.profitPriorityScore || 0),
        preSurgeScore: Number(signal.preSurgeScore || 0),
        preSurgeGroups: Number(signal.preSurgeGroups || 0),
        tradeStrength: Number(signal.metrics && signal.metrics.tradeStrength || 0),
        rvol1m: Number(signal.metrics && signal.metrics.rvol1m || 0),
        smartMoneyState: String(signal.smartMoneyState || 'NEUTRAL'),
        smartMoneyBehaviorState: String(signal.smartMoneyBehaviorState || signal.metrics && signal.metrics.smartMoneyBehaviorState || 'NEUTRAL'),
        smartMoneyConfidence: Number(signal.smartMoneyConfidence || signal.metrics && signal.metrics.smartMoneyConfidence || 0),
        shakeoutScore: Number(signal.shakeoutScore || signal.metrics && signal.metrics.shakeoutScore || 0),
        venueAgreement: signal.venueAgreement == null ? null : Number(signal.venueAgreement),
        dataCompleteness: Number(signal.dataCompleteness || 0),
        signalAction: notificationAction,
      };
      if (notificationAction === 'BUY' && signal.plan) {
        await registerBuySignal({ code, name: stock.name, price: stock.price, qualityScore: signal.qualityScore, stop: signal.plan.stop, target: signal.plan.target1, at: now, learningContext });
      } else if (notificationAction === 'EARLY' && signal.plan) {
        await registerDiscoverySignal({ code, name: stock.name, price: stock.price, qualityScore: signal.qualityScore, stop: signal.plan.stop, target: signal.plan.target1, at: now, learningContext });
      }
      await recordSignal({
        code, name: stock.name, action: notificationAction, price: stock.price,
        qualityScore: signal.qualityScore, profitPriorityScore: signal.profitPriorityScore, sellScore: 0,
        reasons: [...signal.reasons, ...signal.warnings], plan: signal.plan, at: now, verified,
        entryRestricted: stock.entryRestricted, entryRestrictionReason: stock.entryRestrictionReason,
        observation: notificationAction === 'EARLY' ? observation : null,
      });
      // EARLY는 기록부/화면 전용. 알림은 확정 BUY와 실제 보유종목 손절가 도달만 허용한다.
      if (notificationAction === 'EARLY' || stock.entryRestricted) return;
      const firstReasons = [...signal.reasons, ...signal.warnings].slice(0, 3).join(' · ');
      await notify({
        type: 'buy', action: 'BUY', code, name: stock.name, score: signal.qualityScore, price: stock.price, reasons: signal.reasons,
        message: `${signal.label} · 품질 ${signal.qualityScore}점 · 수익우선 ${signal.profitPriorityScore || 0}점 · 사전포착 ${signal.preSurgeScore || 0}점 · 스마트머니 ${signal.smartMoneyState} · ${stock.price.toLocaleString()}원${verified ? '' : ' · 미검증 신호'}${firstReasons ? ` · ${firstReasons}` : ''}`,
      });
    } finally { this.notificationBusy.delete(historyKey); }
  }

}

function startKiwoomRealtime() {
  if (singleton) return singleton;
  singleton = new KiwoomRealtimeWorker().start();
  globalThis.__KIWOOM_WORKER__ = singleton;
  return singleton;
}

module.exports = { KiwoomRealtimeWorker, startKiwoomRealtime };
