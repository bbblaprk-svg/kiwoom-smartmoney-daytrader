# v3.3.5 OFFICIAL TRADE 0A

- v3.3.4의 WebSocket bare-code registration layer는 유지합니다.
- 주식체결 실시간 type을 0B에서 0A로 교정합니다.
- 실제 체결의 거래소 판정은 FID 9081만 사용합니다.
- REST NXT 조회의 `${code}_NX`는 그대로 유지합니다.
- `_NX`를 WebSocket REG item에 넣지 않습니다.
- NXT 성공 판정은 REG ACK가 아니라 0A firstTick/fresh + FID9081=NXT로 판단합니다.
