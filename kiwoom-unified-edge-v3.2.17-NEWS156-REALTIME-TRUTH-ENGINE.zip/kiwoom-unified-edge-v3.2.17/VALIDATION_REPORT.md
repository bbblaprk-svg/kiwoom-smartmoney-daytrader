# v3.2.17 Validation Report

## Purpose
급등 후 추격이 아니라 **급등 전 PRE-IGNITION** 포착. 활성장 동적 판단은 Kiwoom WebSocket 실시간 데이터만 사용.

## Rebuilt realtime truth engine
1. REG 요청수와 실시간 정상 상태를 분리.
2. 정상 단계: `REQUESTED -> REG ACK -> FIRST 0A TICK -> FRESH 0A`.
3. KRX 핵심 0A와 0C/0u 보조 등록 분리.
4. NXT 핵심 0A를 종목별 등록해 한 종목 오류가 전체 NXT를 죽이지 않음.
5. NXT 0C/0u는 별도 소배치. 보조 등록 실패가 가격 0A에 영향 없음.
6. GLOBAL 0m/0w 혼합 등록 제거. 전역 0m만 별도 등록.
7. 활성장 fresh 0A가 없으면 `DATA_OFFLINE`/`DATA_PARTIAL`; 전일종가·REST를 현재가로 사용하지 않음.
8. PRE-IGNITION은 tape/orderbook/program/VWAP 독립증거 기반이며 과열 추격 차단 유지.

## Executed checks
- `npm run check`: PASS
- `npm run check:load`: PASS
- load: 30 symbols / 12,000 events / errors 0 / finalPending 0 / finalActive 0 / ~72,727 ticks/s / event-loop p95 22.36 ms
- `REALTIME_ENGINE_V3217_CHECK`: PASS

## Important production gate
실제 Kiwoom 네트워크에서만 검증 가능한 항목은 AWS 배포 스크립트가 활성장에 직접 확인한다:
- KRX/NXT REG ACK
- 실제 first 0A tick
- fresh 0A 증가
- dashboard의 realtime-only price lineage
실패 시 기존 컨테이너로 자동 롤백한다.
