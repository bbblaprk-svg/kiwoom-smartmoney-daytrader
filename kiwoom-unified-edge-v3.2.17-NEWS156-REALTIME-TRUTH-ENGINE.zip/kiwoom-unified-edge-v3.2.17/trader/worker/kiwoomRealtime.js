const WebSocket = require('ws');
const { getAccessToken, getStockInfo } = require('../lib/kiwoomClient');
const { getItem, setItem } = require('../lib/store');
const { mergeWatchlist, splitWatchlist } = require('../lib/stocks');
const { state, processRealtimeEntry, setConnection, setSignalSettings, resetSubscriptions, setPromotion, applyMarketSnapshot, applyVenueFallbackQuote, realtimeTruth } = require('../lib/realtimeStore');
const { notify } = require('../lib/notifications');
const { mergeSettings } = require('../lib/settings');
const { accountRisk } = require('../lib/risk');
const { ensureLoaded: loadPerformance, registerBuySignal, registerDiscoverySignal, updatePrice: updatePerformancePrice, sweepExpired } = require('../lib/signalPerformance');
const { ensureLoaded: loadSignalLedger, recordSignal, recordShadowSignal, updateObservationTrajectory, updatePrice: updateLedgerPrice, persistNow: persistSignalLedger } = require('../lib/signalLedger');
const runtimeMetrics = require('../lib/runtimeMetrics');
const { refreshAll: refreshMarketSnapshots, loadLatestSnapshots } = require('../lib/marketSnapshot');
const { getRecommendationLearningContext } = require('../lib/recommendationEngine');

const WS_URL = process.env.KIWOOM_WS_URL || 'wss://api.kiwoom.com:10000/api/dostk/websocket';
// 키움 공식 현재 실시간 타입(2026-08 가이드): 주식체결 0A, 주식우선호가 0B, 주식호가잔량 0C, 주식당일거래원 0E, 종목프로그램매매 0u, 장시작시간 0m, VI발동/해제 0w.
const FOCUS_TYPES = ['0A', '0C', '0E', '0u'];
// 전 30종목 사전포착용 기본 루트: 체결+호가+프로그램을 모두 WebSocket으로 받는다.
// 거래원(0E)만 FOCUS/승격 종목에 추가해 트래픽을 제어한다.
const SCOUT_TYPES = ['0A', '0C', '0u'];
const LIGHT_TYPES = SCOUT_TYPES;
const GLOBAL_TYPES = ['0m', '0w'];
const SNAPSHOT_POLICY = 'CLOSE_ONLY';
const SOCKET_WATCHDOG_MS = Math.max(10_000, Number(process.env.KIWOOM_SOCKET_WATCHDOG_MS || 20_000));
const WATCHDOG_INTERVAL_MS = Math.max(500, Number(process.env.KIWOOM_WATCHDOG_INTERVAL_MS || 1000));
const VENUE_STALE_MS = Math.max(2_000, Number(process.env.KIWOOM_VENUE_STALE_MS || 5_000));
// 활성장 동적판정은 REST fallback 금지. 필요시 운영진단용 quote만 별도 허용하며 기본 OFF.
const REST_FALLBACK_INTERVAL_MS = Math.max(3_000, Number(process.env.KIWOOM_REST_FALLBACK_INTERVAL_MS || 5_000));
const INTRADAY_REST_DIAGNOSTIC = String(process.env.KIWOOM_INTRADAY_REST_DIAGNOSTIC || 'false').toLowerCase() === 'true';
const VENUE_NO_TRADE_RECOVERY_MS = Math.max(5_000, Number(process.env.KIWOOM_VENUE_NO_TRADE_RECOVERY_MS || 8_000));
const VENUE_RECOVERY_COOLDOWN_MS = Math.max(8_000, Number(process.env.KIWOOM_VENUE_RECOVERY_COOLDOWN_MS || 12_000));
const VENUE_HARD_RECOVERY_MS = Math.max(VENUE_NO_TRADE_RECOVERY_MS + 5_000, Number(process.env.KIWOOM_VENUE_HARD_RECOVERY_MS || 18_000));
const CLOSE_SYNC_STATE_PREFIX = 'market:close-sync:v5:';
const CLOSE_SYNC_MAX_ATTEMPTS = Math.max(5, Number(process.env.CLOSE_SYNC_MAX_ATTEMPTS || 7));
const SMART_MONEY_CHECKPOINT_PREFIX = 'market:smart-money-checkpoint:v1:';
const CLOSE_SYNC_POST_FINAL_RETRY_MS = Math.max(120_000, Number(process.env.CLOSE_SYNC_POST_FINAL_RETRY_MS || 300_000));
const CLOSE_SYNC_PLANS = {
  KRX_CLOSE: { start: 15 * 60 + 32, schedule: [15 * 60 + 32, 15 * 60 + 34, 15 * 60 + 37, 15 * 60 + 42, 16 * 60] },
  NXT_CLOSE: { start: 20 * 60 + 1, schedule: [20 * 60 + 1, 20 * 60 + 3, 20 * 60 + 6, 20 * 60 + 12, 20 * 60 + 20] },
};
let singleton = globalThis.__KIWOOM_WORKER__ || null;

async function loadWatchlist() { return mergeWatchlist((await getItem('watchlist:user')) || []); }
function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function kstClockParts(now = new Date()) {
  const shifted = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const isoDate = shifted.toISOString().slice(0, 10);
  return {
    isoDate, compactDate: isoDate.replace(/-/g, ''), weekday: shifted.getUTCDay(),
    minute: shifted.getUTCHours() * 60 + shifted.getUTCMinutes(), nowMs: now.getTime(),
  };
}
function kstMinuteToUtcIso(isoDate, minute) {
  const hh = String(Math.floor(minute / 60)).padStart(2, '0');
  const mm = String(minute % 60).padStart(2, '0');
  return new Date(`${isoDate}T${hh}:${mm}:00+09:00`).toISOString();
}

class KiwoomRealtimeWorker {
  constructor() {
    this.stopped = false;
    this.ws = null;
    this.reconnectAttempt = 0;
    this.watchHash = '';
    this.watchlist = [];
    this.watchPoll = null;
    this.marketClockPoll = null;
    this.closeSyncCache = new Map();
    this.snapshotBusy = false;
    this.notificationBusy = new Set();
    this.notificationHistory = new Map(); // 액션이 흔들려도 같은 종목·같은 중요신호 반복 알림 억제
    this.positionCache = { loadedAt: 0, positions: [], settings: mergeSettings(null) };
    this.positionAlertAt = new Map();
    this.resubscribeBusy = false;
    this.postPending = new Map();
    this.postRunning = new Set();
    this.postActive = 0;
    this.postMaxConcurrency = Math.max(1, Number(process.env.POST_PROCESS_CONCURRENCY || 4));
    this.positionPersistTimer = null;
    this.positionPersistDirty = false;
    this.watchdogPoll = null;
    this.lastSocketFrameAt = 0;
    this.pendingRegGroups = [];
    this.restFallbackBusy = false;
    this.restFallbackCursor = 0;
    this.lastRestFallbackAt = 0;
    this.marketStatusRefreshTimers = new Map();
    this.venueZeroFreshSince = { KRX: 0, NXT: 0 };
    this.lastVenueRecoveryAt = { KRX: 0, NXT: 0 };
    this.lastMarketStartOperation = null;
    // v3.2.17: 등록 성공(ACK)과 실제 체결 수신을 분리 추적한다.
    this.regRequests = new Map();
    this.regSeq = 0;
    this.acceptedTradeCodes = { KRX: new Set(), NXT: new Set() };
    this.firstTradeAt = { KRX: new Map(), NXT: new Map() };
    this.failedTradeCodes = { KRX: new Map(), NXT: new Map() };
  }

  start() {
    this.stopped = false;
    Promise.all([loadPerformance(), loadSignalLedger()]).catch((error) => console.error(`[startup] 성과/기록부 로드 실패: ${error.message}`));
    this.connectLoop().catch((error) => setConnection({ status: 'error', lastError: String(error.message || error) }));
    return this;
  }

  async stop() {
    this.stopped = true;
    if (this.watchPoll) clearInterval(this.watchPoll);
    if (this.marketClockPoll) clearInterval(this.marketClockPoll);
    if (this.watchdogPoll) clearInterval(this.watchdogPoll);
    if (this.positionPersistTimer) clearTimeout(this.positionPersistTimer);
    await this.flushPositions().catch((error) => console.error(`[positions] 종료 저장 실패: ${error.message}`));
    await persistSignalLedger().catch((error) => console.error(`[ledger] 종료 저장 실패: ${error.message}`));
    if (this.ws) this.ws.close();
  }

  async connectLoop() {
    while (!this.stopped) {
      try { await this.connectOnce(); this.reconnectAttempt = 0; }
      catch (error) {
        this.reconnectAttempt += 1;
        setConnection({ status: 'reconnecting', lastError: String(error.message || error), reconnects: state.connection.reconnects + 1 });
      }
      if (!this.stopped) await wait(Math.min(30_000, 1000 * (2 ** Math.min(this.reconnectAttempt, 5))));
    }
  }

  async connectOnce() {
    setConnection({ status: 'connecting', lastError: null });
    const token = await getAccessToken();
    const [watchlist, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    this.watchlist = watchlist;
    setSignalSettings(mergeSettings(savedSettings).signal);
    const ws = new WebSocket(WS_URL, { handshakeTimeout: 20_000, perMessageDeflate: false });
    this.ws = ws;
    try {
      await new Promise((resolve, reject) => {
        const cleanup = () => { clearTimeout(timer); ws.off('open', onOpen); ws.off('error', onError); };
        const onOpen = () => { cleanup(); resolve(); };
        const onError = (error) => { cleanup(); reject(error); };
        const timer = setTimeout(() => { cleanup(); reject(new Error('키움 WebSocket 연결 시간초과')); }, 20_000);
        ws.once('open', onOpen); ws.once('error', onError);
      });
      ws.send(JSON.stringify({ trnm: 'LOGIN', token }));
      await this.waitForLogin(ws);
      this.lastSocketFrameAt = Date.now();
      setConnection({ status: 'connected', connectedAt: new Date().toISOString(), lastError: null, venueRegistration: {}, websocketEndpoint: WS_URL });
      ws.on('message', (data) => this.onMessage(data));
      await this.subscribe(this.watchlist, true);
      await this.hydrateSmartMoneyCheckpoints().catch(() => null);
      await this.hydrateSnapshots(this.watchlist);
      setConnection({ snapshotPolicy: SNAPSHOT_POLICY, snapshotStatus: state.connection.snapshotCount > 0 ? 'cached' : 'waiting_close_sync' });
      this.watchPoll = setInterval(() => this.refreshWatchlist().catch(() => null), 30_000);
      this.marketClockPoll = setInterval(() => this.maybeScheduledCloseRefresh().catch(() => null), 30_000);
      this.watchdogPoll = setInterval(() => this.watchdog().catch(() => null), WATCHDOG_INTERVAL_MS);
      if (this.watchdogPoll.unref) this.watchdogPoll.unref();
      this.maybeScheduledCloseRefresh().catch(() => null);
      await new Promise((resolve, reject) => {
        ws.once('close', resolve); ws.once('error', reject);
      });
    } finally {
      if (this.watchPoll) clearInterval(this.watchPoll);
        if (this.marketClockPoll) clearInterval(this.marketClockPoll);
      if (this.watchdogPoll) clearInterval(this.watchdogPoll);
      this.watchPoll = null;
        this.marketClockPoll = null;
      this.watchdogPoll = null;
      for (const timer of this.marketStatusRefreshTimers.values()) clearTimeout(timer);
      this.marketStatusRefreshTimers.clear();
      if (this.ws === ws) this.ws = null;
      try { if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.terminate(); } catch (_) {}
      if (!this.stopped) setConnection({ status: 'disconnected' });
    }
  }

  waitForLogin(ws) {
    return new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); ws.off('message', handler); ws.off('close', onClose); ws.off('error', onError); };
      const finish = (error) => { cleanup(); if (error) reject(error); else resolve(); };
      const onClose = () => finish(new Error('키움 WebSocket이 LOGIN 전에 종료됐습니다.'));
      const onError = (error) => finish(error);
      const handler = (buffer) => {
        let message; try { message = JSON.parse(buffer.toString()); } catch (_) { runtimeMetrics.markRealtimeParseError(); return; }
        if (message.trnm === 'PING') { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message)); return; }
        if (String(message.trnm || '').toUpperCase() !== 'LOGIN') return;
        if (Number(message.return_code || 0) !== 0) finish(new Error(`키움 LOGIN 실패: ${message.return_msg || message.return_code}`));
        else finish();
      };
      const timer = setTimeout(() => finish(new Error('키움 WebSocket LOGIN 응답 시간초과')), 15_000);
      ws.on('message', handler); ws.once('close', onClose); ws.once('error', onError);
    });
  }


  async hydrateSnapshots(watchlist) {
    const saved = await loadLatestSnapshots(watchlist).catch(() => []);
    for (const item of saved) applyMarketSnapshot(item.meta.code, item.snapshot, {
      name: item.meta.name, marketMode: item.meta.market, tier: item.meta.tier, fixed: item.meta.fixed,
    });
    if (saved.length) setConnection({ snapshotCount: saved.length });
  }

  async refreshSnapshots(reason = 'manual', targetWatchlist = null, syncContext = {}) {
    await this.persistSmartMoneyCheckpoints(syncContext.now instanceof Date ? syncContext.now : new Date()).catch(() => null);
    const targets = Array.isArray(targetWatchlist) && targetWatchlist.length ? targetWatchlist : this.watchlist;
    if (this.snapshotBusy || !targets.length) return null;
    this.snapshotBusy = true;
    setConnection({ snapshotStatus: 'refreshing', snapshotReason: reason, snapshotRetryRequested: targets.length });
    try {
      const savedSettings = await getItem('settings');
      const result = await refreshMarketSnapshots(targets, {
        settings: savedSettings,
        getLiveStock: (code) => state.stocks.get(code) || null,
        syncStage: syncContext.stage || null,
        syncDate: syncContext.targetDate || null,
        now: syncContext.now instanceof Date ? syncContext.now : new Date(),
      });
      for (const snapshot of result.snapshots) {
        const meta = this.watchlist.find((item) => item.code === snapshot.code) || targets.find((item) => item.code === snapshot.code) || {};
        applyMarketSnapshot(snapshot.code, snapshot, {
          name: meta.name || snapshot.name, marketMode: meta.market || 'SOR', tier: meta.tier || 'FOCUS', fixed: meta.fixed,
        });
      }
      const invalidSnapshots = result.snapshots
        .filter((snapshot) => !(snapshot && snapshot.krx && Number(snapshot.krx.close || 0) > 0))
        .map((snapshot) => ({ code: snapshot && snapshot.code || '?', error: 'KRX 종가 미수집' }));
      const validSnapshots = result.snapshots.length - invalidSnapshots.length;
      const allErrors = [...result.errors, ...invalidSnapshots];
      const totalSnapshotCount = [...state.stocks.values()].filter((stock) => Number(stock.marketSnapshot && stock.marketSnapshot.krx && stock.marketSnapshot.krx.close || 0) > 0).length;
      const snapshotStatus = validSnapshots === result.requested && allErrors.length === 0
        ? 'ready'
        : validSnapshots > 0 ? 'partial' : 'error';
      setConnection({
        snapshotStatus,
        snapshotCount: totalSnapshotCount,
        snapshotRequested: this.watchlist.length,
        snapshotRetryRequested: result.requested,
        snapshotErrors: allErrors,
        lastSnapshotAt: new Date().toISOString(),
        snapshotPolicy: SNAPSHOT_POLICY,
      });
      return result;
    } catch (error) {
      setConnection({ snapshotStatus: 'error', snapshotErrors: [{ error: String(error.message || error) }] });
      throw error;
    } finally {
      this.snapshotBusy = false;
    }
  }

  closeSyncStateKey(date) { return `${CLOSE_SYNC_STATE_PREFIX}${date}`; }

  smartMoneyCheckpointKey(date) { return `${SMART_MONEY_CHECKPOINT_PREFIX}${date}`; }

  async persistSmartMoneyCheckpoints(now = new Date()) {
    const date = kstClockParts(now).compactDate;
    const rows = {};
    for (const [code, stock] of state.stocks.entries()) {
      const cp = stock && stock.smartMoneyCheckpoint;
      if (cp && cp.sessionDate === date && Number(cp.at || 0) > 0) rows[code] = cp;
    }
    if (Object.keys(rows).length) await setItem(this.smartMoneyCheckpointKey(date), { date, updatedAt: now.toISOString(), rows });
    return rows;
  }

  async hydrateSmartMoneyCheckpoints(now = new Date()) {
    const date = kstClockParts(now).compactDate;
    const saved = await getItem(this.smartMoneyCheckpointKey(date)).catch(() => null);
    const rows = saved && saved.rows || {};
    for (const [code, cp] of Object.entries(rows)) {
      const stock = state.stocks.get(code);
      if (stock && cp && cp.sessionDate === date) stock.smartMoneyCheckpoint = cp;
    }
  }


  async loadCloseSyncState(clock) {
    const key = this.closeSyncStateKey(clock.isoDate);
    if (this.closeSyncCache.has(key)) return this.closeSyncCache.get(key);
    const saved = await getItem(key).catch(() => null);
    const value = saved && typeof saved === 'object' ? saved : { version: 5, date: clock.isoDate, stages: {} };
    value.version = 5; value.date = clock.isoDate; value.stages = value.stages && typeof value.stages === 'object' ? value.stages : {};
    this.closeSyncCache.set(key, value);
    return value;
  }

  async saveCloseSyncState(clock, syncState) {
    const key = this.closeSyncStateKey(clock.isoDate);
    syncState.updatedAt = new Date().toISOString();
    this.closeSyncCache.set(key, syncState);
    await setItem(key, syncState);
    this.publishCloseSyncState(syncState);
  }

  publishCloseSyncState(syncState) {
    const summarize = (stage) => {
      const row = syncState && syncState.stages && syncState.stages[stage] || {};
      return {
        status: row.status || 'waiting', attempts: Number(row.attempts || 0),
        pending: Array.isArray(row.pendingCodes) ? row.pendingCodes.length : 0,
        success: Array.isArray(row.successCodes) ? row.successCodes.length : 0,
        lastAttemptAt: row.lastAttemptAt || null, nextRetryAt: row.nextRetryAt || null,
        completedAt: row.completedAt || null, trigger: row.lastTrigger || null,
      };
    };
    setConnection({ closeSync: { version: 5, date: syncState && syncState.date || null, KRX_CLOSE: summarize('KRX_CLOSE'), NXT_CLOSE: summarize('NXT_CLOSE') } });
  }

  reconcileStageState(syncState, stage) {
    const codes = [...new Set(this.watchlist.map((x) => String(x.code)))];
    const prior = syncState.stages[stage] && typeof syncState.stages[stage] === 'object' ? syncState.stages[stage] : {};
    const success = new Set((prior.successCodes || []).filter((code) => codes.includes(code)));
    const pending = codes.filter((code) => !success.has(code));
    const next = {
      status: pending.length ? (prior.status === 'ready' ? 'pending_retry' : (prior.status || 'waiting')) : 'ready',
      attempts: Number(prior.attempts || 0), successCodes: [...success], pendingCodes: pending,
      lastAttemptAt: prior.lastAttemptAt || null, lastAttemptMinute: Number.isFinite(Number(prior.lastAttemptMinute)) ? Number(prior.lastAttemptMinute) : null,
      nextRetryAt: prior.nextRetryAt || null, completedAt: pending.length ? null : (prior.completedAt || new Date().toISOString()),
      errors: Array.isArray(prior.errors) ? prior.errors.slice(-20) : [], lastTrigger: prior.lastTrigger || null,
    };
    syncState.stages[stage] = next;
    return next;
  }

  nextCloseRetryAt(stage, clock, attempts) {
    const plan = CLOSE_SYNC_PLANS[stage];
    const nextMinute = plan.schedule.find((minute) => minute > clock.minute);
    if (nextMinute != null) return kstMinuteToUtcIso(clock.isoDate, nextMinute);
    if (attempts < CLOSE_SYNC_MAX_ATTEMPTS) return new Date(clock.nowMs + CLOSE_SYNC_POST_FINAL_RETRY_MS).toISOString();
    return null;
  }

  snapshotPassesCloseStage(snapshot, stage, targetDate) {
    const cs = snapshot && snapshot.closeSync || {};
    const targetMatches = String(cs.targetDate || '') === targetDate;
    return stage === 'KRX_CLOSE'
      ? Boolean(targetMatches && cs.krxOfficialConfirmed && cs.officialFlowConfirmed)
      : Boolean(targetMatches && cs.krxOfficialConfirmed && cs.nxtFinalConfirmed && cs.officialFlowConfirmed);
  }

  closeStageFailureReason(snapshot, stage) {
    const cs = snapshot && snapshot.closeSync || {};
    if (!cs.krxOfficialConfirmed) return `KRX 공식종가 미확정(${cs.krxStatus || 'PENDING'})`;
    if (!cs.officialFlowConfirmed) return `공식 수급 미확정(${cs.flowStatus || 'PENDING'})`;
    if (stage === 'NXT_CLOSE' && !cs.nxtFinalConfirmed) return `NXT 최종가 미확정(${cs.nxtStatus || 'PENDING'})`;
    return '종가 동기화 조건 미충족';
  }

  applyCloseStageResult(stageState, stage, result, clock, trigger) {
    const successNow = new Set();
    const syncErrors = [];
    for (const snapshot of result && result.snapshots || []) {
      if (this.snapshotPassesCloseStage(snapshot, stage, clock.compactDate)) successNow.add(String(snapshot.code));
      else syncErrors.push({ code: String(snapshot && snapshot.code || '?'), error: this.closeStageFailureReason(snapshot, stage) });
    }
    for (const error of result && result.errors || []) syncErrors.push({ code: String(error.code || '?'), error: String(error.error || error.message || error) });
    const success = new Set([...(stageState.successCodes || []), ...successNow]);
    const currentCodes = this.watchlist.map((x) => String(x.code));
    const pending = currentCodes.filter((code) => !success.has(code));
    stageState.attempts = Number(stageState.attempts || 0) + 1;
    stageState.successCodes = [...success].filter((code) => currentCodes.includes(code));
    stageState.pendingCodes = pending;
    stageState.lastAttemptAt = new Date(clock.nowMs).toISOString();
    stageState.lastAttemptMinute = clock.minute;
    stageState.lastTrigger = trigger;
    stageState.errors = [...(stageState.errors || []), ...syncErrors].slice(-20);
    if (!pending.length) {
      stageState.status = 'ready'; stageState.nextRetryAt = null; stageState.completedAt = new Date(clock.nowMs).toISOString();
    } else {
      stageState.nextRetryAt = this.nextCloseRetryAt(stage, clock, stageState.attempts);
      stageState.status = stageState.nextRetryAt ? 'pending_retry' : 'degraded';
      stageState.completedAt = null;
    }
    return pending;
  }

  async runCloseSyncStage(stage, clock, trigger = 'schedule') {
    const syncState = await this.loadCloseSyncState(clock);
    const stageState = this.reconcileStageState(syncState, stage);
    if (!stageState.pendingCodes.length) { stageState.status = 'ready'; await this.saveCloseSyncState(clock, syncState); return null; }
    const pendingSet = new Set(stageState.pendingCodes);
    const targets = this.watchlist.filter((item) => pendingSet.has(String(item.code)));
    if (!targets.length) { stageState.status = 'ready'; stageState.pendingCodes = []; stageState.completedAt = new Date().toISOString(); await this.saveCloseSyncState(clock, syncState); return null; }

    const result = await this.refreshSnapshots(stage.toLowerCase(), targets, { stage, targetDate: clock.compactDate, now: new Date(clock.nowMs) });
    if (!result) return null;
    const pending = this.applyCloseStageResult(stageState, stage, result, clock, trigger);
    await this.saveCloseSyncState(clock, syncState);
    setConnection({
      snapshotStatus: pending.length ? 'partial' : 'ready',
      snapshotErrors: stageState.errors,
      snapshotRetryPending: pending.length,
      snapshotRetryCodes: pending,
      snapshotReason: stage.toLowerCase(),
    });
    return { ...result, stage, pendingCodes: pending, successCodes: stageState.successCodes, closeSyncStatus: stageState.status };
  }

  async runCombinedCloseSync(clock, trigger = 'restart_catchup_combined') {
    const syncState = await this.loadCloseSyncState(clock);
    const krxState = this.reconcileStageState(syncState, 'KRX_CLOSE');
    const nxtState = this.reconcileStageState(syncState, 'NXT_CLOSE');
    const union = new Set([...(krxState.pendingCodes || []), ...(nxtState.pendingCodes || [])]);
    const targets = this.watchlist.filter((item) => union.has(String(item.code)));
    if (!targets.length) { await this.saveCloseSyncState(clock, syncState); return null; }

    // 20:01 이후 KRX와 NXT가 모두 미완료라면 동일 종목을 두 번 REST 순회하지 않는다.
    // NXT_CLOSE 한 번의 스냅샷으로 KRX 공식종가/수급/NXT 최종값을 동시에 검증한다.
    const result = await this.refreshSnapshots('combined_close_sync', targets, {
      stage: 'NXT_CLOSE', targetDate: clock.compactDate, now: new Date(clock.nowMs), combinedCloseSync: true,
    });
    if (!result) return null;
    const krxPending = this.applyCloseStageResult(krxState, 'KRX_CLOSE', result, clock, trigger);
    const nxtPending = this.applyCloseStageResult(nxtState, 'NXT_CLOSE', result, clock, trigger);
    await this.saveCloseSyncState(clock, syncState);
    const pending = [...new Set([...krxPending, ...nxtPending])];
    const errors = [...(krxState.errors || []), ...(nxtState.errors || [])].slice(-20);
    setConnection({
      snapshotStatus: pending.length ? 'partial' : 'ready', snapshotErrors: errors,
      snapshotRetryPending: pending.length, snapshotRetryCodes: pending,
      snapshotReason: 'combined_close_sync', closeSyncCoalescedAt: new Date(clock.nowMs).toISOString(),
    });
    return { ...result, stage: 'COMBINED_CLOSE', pendingCodes: pending, closeSyncStatus: pending.length ? 'pending_retry' : 'ready' };
  }

  async maybeScheduledCloseRefresh(now = new Date()) {
    const clock = kstClockParts(now);
    if (clock.weekday === 0 || clock.weekday === 6) return null;
    const syncState = await this.loadCloseSyncState(clock);
    let changed = false;
    for (const stage of ['KRX_CLOSE', 'NXT_CLOSE']) {
      const before = JSON.stringify(syncState.stages[stage] || null);
      this.reconcileStageState(syncState, stage);
      if (before !== JSON.stringify(syncState.stages[stage])) changed = true;
    }
    if (changed) await this.saveCloseSyncState(clock, syncState);

    const krxPlan = CLOSE_SYNC_PLANS.KRX_CLOSE;
    const nxtPlan = CLOSE_SYNC_PLANS.NXT_CLOSE;
    const krx = syncState.stages.KRX_CLOSE;
    const nxt = syncState.stages.NXT_CLOSE;
    const due = (stageState) => !stageState.lastAttemptAt || Boolean(stageState.nextRetryAt && clock.nowMs >= Date.parse(stageState.nextRetryAt));

    // NXT 종료 이후에는 NXT가 due이고 KRX도 미완료이면 한 번의 결합 동기화로 처리한다.
    if (clock.minute >= nxtPlan.start && nxt.pendingCodes.length && nxt.status !== 'ready' && due(nxt)) {
      if (krx.pendingCodes.length && krx.status !== 'ready') {
        return this.runCombinedCloseSync(clock, !nxt.lastAttemptAt ? 'restart_catchup_combined' : 'combined_retry');
      }
      return this.runCloseSyncStage('NXT_CLOSE', clock, !nxt.lastAttemptAt && clock.minute > nxtPlan.start ? 'restart_catchup' : 'scheduled_retry');
    }

    if (clock.minute >= krxPlan.start && krx.pendingCodes.length && krx.status !== 'ready' && due(krx)) {
      return this.runCloseSyncStage('KRX_CLOSE', clock, !krx.lastAttemptAt && clock.minute > krxPlan.start ? 'restart_catchup' : 'scheduled_retry');
    }

    this.publishCloseSyncState(syncState);
    return null;
  }

  isKrxCloseAuditWindow(now = new Date()) {
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const day = kst.getUTCDay();
    if (day === 0 || day === 6) return false;
    const minute = kst.getUTCHours() * 60 + kst.getUTCMinutes();
    // 종가 스마트머니 표본 누락 방지: 14:40~15:35 KST에만 30종목 모두 정밀피드로 승격.
    // REST를 늘리지 않고 기존 단일 WebSocket 세션 안에서 체결/호가/프로그램을 확보한다.
    return minute >= 14 * 60 + 40 && minute <= 15 * 60 + 35;
  }

  subscriptionGroups(watchlist) {
    const now = Date.now();
    const { focus, light } = splitWatchlist(watchlist);
    const promoted = light.filter((item) => {
      const stock = state.stocks.get(item.code);
      return stock && stock.promotedUntil > now;
    });
    const promotedCodes = new Set(promoted.map((x) => x.code));
    const closeAudit = this.isKrxCloseAuditWindow(new Date(now));
    const full = closeAudit ? [...watchlist] : [...focus, ...promoted];
    const lightOnly = closeAudit ? [] : light.filter((x) => !promotedCodes.has(x.code));
    return { full, lightOnly, promoted, closeAudit };
  }

  explicitVenueCode(item, venue) {
    const base = String(item && item.code || item || '').replace(/[^0-9]/g, '').slice(0, 6);
    return venue === 'NXT' ? `${base}_NX` : base;
  }

  sendReg(groupNo, label, data, refresh = '1', meta = {}) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !Array.isArray(data) || !data.length) return false;
    const request = {
      groupNo: String(groupNo), label, at: Date.now(), data,
      venue: meta.venue || null, kind: meta.kind || 'AUX', required: Boolean(meta.required),
      codes: Array.isArray(meta.codes) ? meta.codes.map(String) : [],
      types: Array.isArray(meta.types) ? meta.types.map(String) : [],
    };
    this.pendingRegGroups.push(request);
    this.regRequests.set(String(groupNo), request);
    this.ws.send(JSON.stringify({ trnm: 'REG', grp_no: String(groupNo), refresh: String(refresh), data }));
    const vr = { ...(state.connection.venueRegistration || {}), [label]: 'pending' };
    setConnection({ venueRegistration: vr });
    return true;
  }

  chunks(items, size = 8) {
    const out = []; for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size)); return out;
  }

  resetRealtimeAckState() {
    this.acceptedTradeCodes = { KRX: new Set(), NXT: new Set() };
    this.firstTradeAt = { KRX: new Map(), NXT: new Map() };
    this.failedTradeCodes = { KRX: new Map(), NXT: new Map() };
    this.regRequests.clear();
    this.pendingRegGroups = [];
  }

  registrationStats(now = Date.now()) {
    const summarize = (venue) => {
      const requestedWire = venue === 'KRX' ? (state.connection.krxSubscribed || []) : (state.connection.nxtSubscribed || []);
      const requested = new Set(requestedWire.map((x)=>String(x).replace(/_(AL|NX)$/i,'')));
      const accepted = this.acceptedTradeCodes[venue] || new Set();
      const first = this.firstTradeAt[venue] || new Map();
      let fresh = 0, newest = 0;
      for (const code of requested) {
        const stock = state.stocks.get(code); const v = stock && stock.venues && stock.venues[venue];
        const at = Number(v && v.updatedAt || 0); newest = Math.max(newest, at);
        if (at && now-at <= VENUE_STALE_MS) fresh += 1;
      }
      return {
        requested: requested.size,
        regAccepted: [...requested].filter((c)=>accepted.has(c)).length,
        firstTick: [...requested].filter((c)=>first.has(c)).length,
        fresh,
        regFailed: [...requested].filter((c)=>(this.failedTradeCodes[venue]||new Map()).has(c)).length,
        lastTradeAt: newest ? new Date(newest).toISOString() : null,
        dataReady: fresh > 0,
      };
    };
    return { KRX: summarize('KRX'), NXT: summarize('NXT') };
  }

  async subscribe(watchlist, replace = false) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const { full, lightOnly, promoted, closeAudit } = this.subscriptionGroups(watchlist);
    const baseFull = full.map((x) => x.code);
    const baseLight = lightOnly.map((x) => x.code);
    const krxWire = watchlist.map((x) => this.explicitVenueCode(x, 'KRX'));
    const nxtWire = watchlist.map((x) => this.explicitVenueCode(x, 'NXT'));
    const allWire = [...new Set([...krxWire, ...nxtWire])];
    const hash = JSON.stringify({ baseFull, baseLight, closeAudit, krxWire, nxtWire });
    this.watchHash = hash;
    this.watchlist = watchlist;
    this.metaByCode = new Map(watchlist.map((item) => [item.code, item]));
    if (replace) this.resetRealtimeAckState(); else this.pendingRegGroups = [];

    // 핵심 가격 루트(0A)는 보조 타입과 분리한다. 보조 타입 오류가 체결 등록을 함께 죽이지 않게 한다.
    // KRX는 30개를 한 번에 등록하고, NXT는 종목별 0A 등록으로 미지원 종목 하나가 전체 NXT를 막지 않게 격리한다.
    this.sendReg('1', 'KRX_CORE_TRADE', [{ item: krxWire, type: ['0A'] }], replace ? '0' : '1', {
      venue:'KRX', kind:'CORE_TRADE', required:true, codes:watchlist.map(x=>x.code), types:['0A']
    });
    this.sendReg('2', 'KRX_SCOUT_AUX', [{ item: krxWire, type: ['0C','0u'] }], '1', {
      venue:'KRX', kind:'AUX', required:false, codes:watchlist.map(x=>x.code), types:['0C','0u']
    });
    if (baseFull.length) this.sendReg('3', 'KRX_FOCUS_BROKER', [{ item: baseFull, type: ['0E'] }], '1', {
      venue:'KRX', kind:'AUX', required:false, codes:baseFull, types:['0E']
    });

    let grp = 20;
    for (const item of watchlist) {
      const wire = this.explicitVenueCode(item,'NXT');
      this.sendReg(String(grp), `NXT_CORE_${item.code}`, [{ item:[wire], type:['0A'] }], '1', {
        venue:'NXT', kind:'CORE_TRADE', required:false, codes:[item.code], types:['0A']
      });
      grp += 1;
    }
    // NXT 보조피드는 작은 배치로. 실패해도 0A 가격 루트는 유지된다.
    let auxGrp = 60;
    for (const batch of this.chunks(watchlist, 5)) {
      const wires = batch.map((x)=>this.explicitVenueCode(x,'NXT'));
      this.sendReg(String(auxGrp), `NXT_AUX_${auxGrp}`, [{ item:wires, type:['0C','0u'] }], '1', {
        venue:'NXT', kind:'AUX', required:false, codes:batch.map(x=>x.code), types:['0C','0u']
      });
      auxGrp += 1;
    }
    if (baseFull.length) this.sendReg('80', 'NXT_FOCUS_BROKER', [{ item:baseFull.map(c=>`${c}_NX`), type:['0E'] }], '1', {
      venue:'NXT', kind:'AUX', required:false, codes:baseFull, types:['0E']
    });
    // 전역 장상태(0m)와 종목형 VI(0w)를 한 REG에 섞지 않는다. 0m만 전역으로 등록.
    this.sendReg('90', 'MARKET_STATUS', [{ item:[''], type:['0m'] }], '1', { kind:'GLOBAL', required:false, codes:[], types:['0m'] });

    resetSubscriptions({ all: [...new Set([...baseFull, ...baseLight])], focus: baseFull, light: baseLight, wire: allWire, krx: krxWire, nxt: nxtWire });
    setConnection({
      promoted: promoted.map((x) => x.code), wireSubscribed: allWire, krxSubscribed: krxWire, nxtSubscribed: nxtWire,
      closeAuditMode: Boolean(closeAudit), closeAuditFullCount: closeAudit ? full.length : 0,
      realtimeRegistrationMode: 'CORE_TRADE_ISOLATED_ACK_FIRST_TICK_V1',
      requestedSubscriptions: { KRX: krxWire.length, NXT: nxtWire.length },
    });
  }

  expectedVenues(now = new Date()) {
    const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
    const day = kst.getUTCDay(); if (day === 0 || day === 6) return [];
    const sec = kst.getUTCHours() * 3600 + kst.getUTCMinutes() * 60 + kst.getUTCSeconds();
    const venues = [];
    if (sec >= 9 * 3600 && sec <= 15 * 3600 + 30 * 60) venues.push('KRX');
    // NXT 실제 체결시간: 프리 08:00~08:50, 메인 09:00:30~15:20, 애프터 15:40~20:00.
    const nxtActive = (sec >= 8 * 3600 && sec <= 8 * 3600 + 50 * 60)
      || (sec >= 9 * 3600 + 30 && sec <= 15 * 3600 + 20 * 60)
      || (sec >= 15 * 3600 + 40 * 60 && sec <= 20 * 3600);
    if (nxtActive) venues.push('NXT');
    return venues;
  }

  venueHealth(now = Date.now()) {
    const result = {
      KRX: { fresh: 0, stale: 0, subscribed: 0, lastTradeAt: null, lastTradeAgeMs: null },
      NXT: { fresh: 0, stale: 0, subscribed: 0, lastTradeAt: null, lastTradeAgeMs: null },
    };
    for (const venue of ['KRX','NXT']) {
      const wire = venue === 'KRX' ? (state.connection.krxSubscribed || []) : (state.connection.nxtSubscribed || []);
      const bases = [...new Set(wire.map((x)=>String(x).replace(/_(AL|NX)$/i,'')))];
      result[venue].subscribed = bases.length;
      let newest = 0;
      for (const code of bases) {
        const stock = state.stocks.get(code);
        const v = stock && stock.venues && stock.venues[venue];
        const at = Number(v && v.updatedAt || 0);
        newest = Math.max(newest, at);
        const fresh = Boolean(at && now - at <= VENUE_STALE_MS);
        if (fresh) result[venue].fresh += 1; else result[venue].stale += 1;
      }
      result[venue].lastTradeAt = newest ? new Date(newest).toISOString() : null;
      result[venue].lastTradeAgeMs = newest ? Math.max(0, now - newest) : null;
    }
    return result;
  }

  async watchdog() {
    const now = Date.now();
    const frameAge = this.lastSocketFrameAt ? now - this.lastSocketFrameAt : Number.POSITIVE_INFINITY;
    const venueHealth = this.venueHealth(now);
    const expected = this.expectedVenues(new Date(now));
    const registrationStats = this.registrationStats(now);
    const activeReady = expected.length ? expected.every((v)=>Number(registrationStats[v]?.fresh || 0) > 0) : true;
    const anyReady = expected.some((v)=>Number(registrationStats[v]?.fresh || 0) > 0);
    const dataStatus = !expected.length ? 'OFF_SESSION' : activeReady ? 'DATA_LIVE' : anyReady ? 'DATA_PARTIAL' : 'DATA_OFFLINE';
    setConnection({
      socketFrameAgeMs: Number.isFinite(frameAge) ? frameAge : null,
      venueHealth, registrationStats, dataStatus,
      expectedVenues: expected,
      realtimeJudgmentRoute: 'KIWOOM_WEBSOCKET_ONLY',
      restFallbackDiagnosticOnly: true,
      intradayRestDiagnosticEnabled: INTRADAY_REST_DIAGNOSTIC,
      scoutRealtimeTypes: SCOUT_TYPES,
      lastWatchdogAt: new Date(now).toISOString(),
    });
    if (this.ws && this.ws.readyState === WebSocket.OPEN && frameAge > SOCKET_WATCHDOG_MS) {
      setConnection({ lastError: `WebSocket 무수신 ${Math.round(frameAge/1000)}초 · 자동 재연결` });
      try { this.ws.terminate(); } catch (_) {}
      return;
    }

    // 소켓 자체는 살아 있어도 활성 거래소의 체결(0A)이 짧은 기한 동안 전 종목에서 0이면
    // REG 유실/거래소별 라우팅 장애 가능성이 있으므로 해당 세션을 재등록한다.
    for (const venue of ['KRX','NXT']) {
      if (!expected.includes(venue)) { this.venueZeroFreshSince[venue] = 0; continue; }
      const vh = venueHealth[venue] || {};
      if (Number(vh.subscribed || 0) <= 0 || Number(vh.fresh || 0) > 0) { this.venueZeroFreshSince[venue] = 0; continue; }
      if (!this.venueZeroFreshSince[venue]) this.venueZeroFreshSince[venue] = now;
      const zeroFor = now - this.venueZeroFreshSince[venue];
      const cooldown = now - Number(this.lastVenueRecoveryAt[venue] || 0);
      // 1차는 기존 구독을 지우지 않는 REG 보강으로 즉시 복구를 시도한다.
      // 그래도 전 30종목 체결이 장시간 0이면 소켓 자체의 거래소 라우팅이 꼬인 것으로 보고 완전 재연결한다.
      if (zeroFor >= VENUE_HARD_RECOVERY_MS && this.ws && this.ws.readyState === WebSocket.OPEN) {
        setConnection({ lastError: `${venue} 실시간 체결 0건 ${Math.round(zeroFor/1000)}초 · WebSocket 강제 재연결`, venueRecovery: { venue, at: new Date(now).toISOString(), reason: 'ZERO_FRESH_HARD_RECONNECT', zeroForMs: zeroFor } });
        try { this.ws.terminate(); } catch (_) {}
        return;
      }
      if (zeroFor >= VENUE_NO_TRADE_RECOVERY_MS && cooldown >= VENUE_RECOVERY_COOLDOWN_MS && !this.resubscribeBusy) {
        this.lastVenueRecoveryAt[venue] = now;
        this.resubscribeBusy = true;
        try {
          setConnection({ lastError: `${venue} 실시간 체결 0건 ${Math.round(zeroFor/1000)}초 · REG 무중단 보강`, venueRecovery: { venue, at: new Date(now).toISOString(), reason: 'ZERO_FRESH_SOFT_REREG', zeroForMs: zeroFor } });
          await this.subscribe(this.watchlist, false);
        } finally { this.resubscribeBusy = false; }
      }
    }

    if (INTRADAY_REST_DIAGNOSTIC && now - this.lastRestFallbackAt >= REST_FALLBACK_INTERVAL_MS) {
      this.lastRestFallbackAt = now;
      await this.restContinuityFallback(now).catch((error) => setConnection({ fallbackLastError: String(error.message || error) }));
    }
  }

  async restContinuityFallback(now = Date.now()) {
    if (this.restFallbackBusy) return;
    const expected = this.expectedVenues(new Date(now)); if (!expected.length) return;
    const focus = (state.connection.focusSubscribed || []).map((x)=>String(x).replace(/_(AL|NX)$/i,''));
    if (!focus.length) return;
    const candidates = [];
    for (const code of focus) {
      const stock = state.stocks.get(code);
      for (const venue of expected) {
        const v = stock && stock.venues && stock.venues[venue];
        if (!v || !v.updatedAt || now - v.updatedAt > VENUE_STALE_MS) candidates.push({ code, venue, age: v && v.updatedAt ? now-v.updatedAt : Number.POSITIVE_INFINITY });
      }
    }
    if (!candidates.length) return;
    candidates.sort((a,b)=>b.age-a.age);
    const pick = candidates[this.restFallbackCursor++ % candidates.length];
    this.restFallbackBusy = true;
    try {
      const queryCode = pick.venue === 'NXT' ? `${pick.code}_NX` : pick.code;
      const info = await getStockInfo(queryCode);
      applyVenueFallbackQuote(pick.code, pick.venue, {
        price: info.cur_prc || info.cur_price || info.stk_prc,
        changePct: info.flu_rt || info.change_rate,
        volume: info.acc_trde_qty || info.acc_volume,
        amount: info.acc_trde_prica || info.acc_trde_amt,
      }, this.metaByCode && this.metaByCode.get(pick.code) || {});
      setConnection({ fallbackLastAt: new Date().toISOString(), fallbackLastVenue: pick.venue, fallbackLastCode: pick.code, fallbackLastError: null, fallbackDiagnosticOnly: true });
    } finally { this.restFallbackBusy = false; }
  }

  async refreshWatchlist() {
    const [list, savedSettings] = await Promise.all([loadWatchlist(), getItem('settings')]);
    setSignalSettings(mergeSettings(savedSettings).signal);
    const now = Date.now();
    let promotionExpired = false;
    for (const item of list) {
      const stock = state.stocks.get(item.code);
      if (stock && stock.tier === 'LIGHT' && stock.promotedUntil > 0 && stock.promotedUntil <= now) {
        setPromotion(item.code, 0); promotionExpired = true;
      }
    }
    const groups = this.subscriptionGroups(list);
    const hash = JSON.stringify({ closeAudit: Boolean(groups.closeAudit),
      krxFull: groups.full.map((x)=>this.explicitVenueCode(x,'KRX')),
      nxtFull: groups.full.map((x)=>this.explicitVenueCode(x,'NXT')),
      krxLight: groups.lightOnly.map((x)=>this.explicitVenueCode(x,'KRX')),
      nxtLight: groups.lightOnly.map((x)=>this.explicitVenueCode(x,'NXT')),
    });
    const changed = hash !== this.watchHash;
    if (changed || promotionExpired) await this.subscribe(list, true);
    this.watchlist = list;
    if (changed) {
      // LOW TRAFFIC: 종목 변경 시 저장된 종가만 hydrate하고 장중 전체 REST 재조회는 하지 않는다.
      // 새 종목은 WebSocket 즉시 감시 후 다음 KRX/NXT 종가 동기화 대상에 자동 포함된다.
      await this.hydrateSnapshots(list);
    }
    const prices = {};
    for (const [code, stock] of state.stocks.entries()) prices[code] = stock.price;
    await sweepExpired(prices).catch(() => null);
    await this.persistSmartMoneyCheckpoints(new Date(now)).catch(() => null);
  }

  onMessage(buffer) {
    let message; try { message = JSON.parse(buffer.toString()); } catch (_) { runtimeMetrics.markRealtimeParseError(); return; }
    this.lastSocketFrameAt = Date.now();
    if (message.trnm === 'PING') {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(message));
      setConnection({ lastSocketPingAt: new Date().toISOString() });
      return;
    }
    if (message.trnm === 'REG') {
      const grpNo = String(message.grp_no || '');
      let pendingIndex = grpNo ? this.pendingRegGroups.findIndex((x)=>x.groupNo===grpNo) : 0;
      if (pendingIndex < 0) pendingIndex = 0;
      const pending = this.pendingRegGroups.splice(pendingIndex, 1)[0] || this.regRequests.get(grpNo) || { label: grpNo ? `GROUP_${grpNo}` : 'REG', codes:[], types:[] };
      const ok = Number(message.return_code || 0) === 0;
      const registration = { ...(state.connection.venueRegistration || {}), [pending.label]: ok ? 'ack' : `rejected:${message.return_msg || message.return_code}` };
      if (pending.kind === 'CORE_TRADE' && pending.venue) {
        const accepted = this.acceptedTradeCodes[pending.venue] || new Set();
        const failed = this.failedTradeCodes[pending.venue] || new Map();
        for (const code of pending.codes || []) {
          if (ok) { accepted.add(String(code)); failed.delete(String(code)); }
          else failed.set(String(code), String(message.return_msg || message.return_code || 'REG_REJECTED'));
        }
        this.acceptedTradeCodes[pending.venue] = accepted;
        this.failedTradeCodes[pending.venue] = failed;
      }
      setConnection({ venueRegistration: registration, registrationStats: this.registrationStats(), lastRegistrationAt: new Date().toISOString() });
      if (!ok) {
        const fatal = Boolean(pending.required);
        setConnection({ lastError: `실시간 등록 ${pending.label} 실패: ${message.return_msg || message.return_code}${fatal ? ' · 핵심 체결루트 재연결' : ' · 격리/보조루트 유지'}` });
        if (fatal && this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.close(1011, 'required realtime registration failed');
      }
      return;
    }
    if (message.trnm !== 'REAL' || !Array.isArray(message.data)) return;
    runtimeMetrics.markRealtimeFrame(message.data.length);
    setConnection({ lastMessageAt: new Date().toISOString() });
    for (const entry of message.data) {
      runtimeMetrics.markRealtimeType(entry.type);
      const payloadCode = entry.type === '0w' ? entry.values && entry.values['9001'] : entry.item;
      const baseCode = String(payloadCode || '').replace(/_(AL|NX)$/i, '');
      if (entry.type === '0w' && (!this.metaByCode || !this.metaByCode.has(baseCode))) continue;
      const metadata = this.metaByCode ? this.metaByCode.get(baseCode) : null;
      if (entry.type === '0A' && baseCode) {
        const rawItem = String(entry.item || '').toUpperCase();
        let venue = rawItem.endsWith('_NX') ? 'NXT' : rawItem.endsWith('_AL') ? null : 'KRX';
        const explicitVenue = String(entry.values && (entry.values['9081'] || entry.values['337']) || '').toUpperCase();
        if (explicitVenue.includes('NXT') || explicitVenue === '2') venue = 'NXT';
        else if (explicitVenue.includes('KRX') || explicitVenue === '1') venue = 'KRX';
        if (!venue) { const exp=this.expectedVenues(new Date()); if (exp.length===1) venue=exp[0]; }
        if (venue && this.firstTradeAt[venue]) {
          if (!this.firstTradeAt[venue].has(baseCode)) this.firstTradeAt[venue].set(baseCode, Date.now());
          const reg = { ...(state.connection.venueRegistration || {}) };
          const coreLabel = venue === 'KRX' ? 'KRX_CORE_TRADE' : `NXT_CORE_${baseCode}`;
          if (reg[coreLabel] === 'ack') reg[coreLabel] = 'live';
          setConnection({ venueRegistration: reg, registrationStats: this.registrationStats(), lastTradeTickAt: new Date().toISOString() });
        }
      }
      processRealtimeEntry(entry, metadata || {});
      // LOW TRAFFIC PIPELINE: 장운영 이벤트는 상태표시에만 사용한다.
      // 전체 REST 스냅샷은 절대 여기서 호출하지 않고 KRX/NXT 예약 종가 동기화만 사용한다.
      if (entry.type === '0m') {
        this.maybeScheduledCloseRefresh().catch(() => null);
        this.handleMarketStatusRealtime(entry.values || {});
      }
      if (!baseCode) continue;
      this.schedulePostProcess(baseCode, { trade: entry.type === '0A' });
    }
  }

  handleMarketStatusRealtime(values = {}) {
    const operation = String(values['215'] || '').trim();
    if (!['3','P','R','U'].includes(operation) || operation === this.lastMarketStartOperation) return;
    this.lastMarketStartOperation = operation;
    // 장 전환 직후 REG 유실/지연을 기다리지 않고 즉시 재등록한다. refresh=1로 기존 구독을 지우지 않는다.
    for (const [idx, delay] of [100, 1500, 4000].entries()) {
      const key = `open-${operation}-${idx}`;
      const old = this.marketStatusRefreshTimers.get(key); if (old) clearTimeout(old);
      const timer = setTimeout(async () => {
        this.marketStatusRefreshTimers.delete(key);
        if (this.resubscribeBusy || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        this.resubscribeBusy = true;
        try {
          await this.subscribe(this.watchlist, false);
          setConnection({ marketOpenRecovery: { operation, at: new Date().toISOString(), delayMs: delay } });
        } catch (error) {
          setConnection({ lastError: `장전환 REG 재등록 실패: ${error.message}` });
        } finally { this.resubscribeBusy = false; }
      }, delay);
      if (timer.unref) timer.unref();
      this.marketStatusRefreshTimers.set(key, timer);
    }
  }

  schedulePostProcess(code, flags = {}) {
    const existing = this.postPending.get(code);
    if (existing) {
      existing.trade = existing.trade || Boolean(flags.trade);
      runtimeMetrics.incrementPostProcess('coalesced');
    } else {
      this.postPending.set(code, { trade: Boolean(flags.trade) });
    }
    runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
    this.drainPostProcess();
  }

  drainPostProcess() {
    while (this.postActive < this.postMaxConcurrency) {
      const next = [...this.postPending.entries()].find(([code]) => !this.postRunning.has(code));
      if (!next) break;
      const [code, flags] = next;
      this.postPending.delete(code);
      this.postRunning.add(code);
      this.postActive += 1;
      runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
      setImmediate(async () => {
        try {
          const stock = state.stocks.get(code);
          if (flags.trade) {
            await this.maybePromote(code);
            if (stock && stock.price > 0) {
              await Promise.all([
                updatePerformancePrice(code, stock.price),
                updateLedgerPrice(code, stock.price),
              ]);
            }
            await this.maybeRiskNotify(code);
          }
          await this.maybeNotify(code);
          runtimeMetrics.incrementPostProcess('processed');
        } catch (error) {
          runtimeMetrics.incrementPostProcess('errors');
          console.error(`[post-process] ${code} 처리 실패: ${error.message}`);
        } finally {
          this.postRunning.delete(code);
          this.postActive = Math.max(0, this.postActive - 1);
          runtimeMetrics.updatePostProcess({ pendingCodes: this.postPending.size, active: this.postActive });
          this.drainPostProcess();
        }
      });
    }
  }

  schedulePositionsPersist() {
    this.positionPersistDirty = true;
    if (this.positionPersistTimer) return;
    this.positionPersistTimer = setTimeout(() => {
      this.positionPersistTimer = null;
      this.flushPositions().catch((error) => console.error(`[positions] 배치 저장 실패: ${error.message}`));
    }, Math.max(200, Number(process.env.POSITION_BATCH_MS || 750)));
    if (this.positionPersistTimer.unref) this.positionPersistTimer.unref();
  }

  async flushPositions() {
    if (!this.positionPersistDirty || !this.positionCache || !Array.isArray(this.positionCache.positions)) return;
    this.positionPersistDirty = false;
    await setItem('positions', this.positionCache.positions);
    this.positionCache.loadedAt = Date.now();
  }

  async maybePromote(code) {
    const stock = state.stocks.get(code);
    if (!stock || stock.tier !== 'LIGHT' || stock.promotedUntil > Date.now() || stock.promotionScore < Number(state.settings.promotionMinScore || 60)) return;
    const max = Number(state.settings.maxPromotedLight || 4);
    const current = [...state.stocks.values()].filter((s) => s.tier === 'LIGHT' && s.promotedUntil > Date.now());
    if (current.length >= max) return;
    const seconds = Number(state.settings.promotionSeconds || 600);
    setPromotion(code, Date.now() + seconds * 1000);
    if (this.resubscribeBusy) return;
    this.resubscribeBusy = true;
    try { await this.subscribe(this.watchlist, false); }
    finally { this.resubscribeBusy = false; }
  }

  async loadPositionCache() {
    if (Date.now() - this.positionCache.loadedAt < 30_000) return this.positionCache;
    const [positions, savedSettings] = await Promise.all([getItem('positions'), getItem('settings')]);
    this.positionCache = { loadedAt: Date.now(), positions: Array.isArray(positions) ? positions : [], settings: mergeSettings(savedSettings) };
    return this.positionCache;
  }

  async maybeRiskNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !(stock.price > 0)) return;
    const cache = await this.loadPositionCache();
    const openPositions = cache.positions.filter((position) => position.status !== 'closed' && String(position.code) === code);
    if (!openPositions.length) return;
    let changed = false;
    for (const position of openPositions) {
      const cfg = cache.settings.perStock[code] || { stopPct: -1.5 };
      const avg = Number(position.avgPrice || 0); if (!(avg > 0)) continue;
      const initialStop = Number(position.initialStopPrice || avg * (1 + Number(cfg.stopPct || -1.5) / 100));
      const highest = Math.max(Number(position.highestPrice || avg), stock.price);
      if (highest !== Number(position.highestPrice || avg) || Number(position.currentStopPrice || 0) !== Math.round(initialStop)) {
        position.highestPrice = highest;
        // v3.1.16: 보유종목 대응은 단순화. 자동 트레일링/목표가 매도 알림 대신 매수가 기준 설정 손절가만 사용한다.
        position.currentStopPrice = Math.round(initialStop);
        position.trailActive = false;
        position.updatedAt = new Date().toISOString();
        changed = true;
      }
      if (stock.price > initialStop) continue;
      const notified = Array.isArray(position.notifiedLevels) ? position.notifiedLevels : [];
      if (notified.includes('STOP')) continue; // 한 포지션당 손절가 도달 알림 1회
      position.notifiedLevels = [...new Set([...notified, 'STOP'])];
      changed = true;
      await notify({
        type: 'critical', action: 'SELL', code, name: stock.name, price: stock.price,
        message: `보유종목 손절가 도달 · 현재 ${stock.price.toLocaleString()}원 · 손절 ${Math.round(initialStop).toLocaleString()}원`,
        reasons: [`매수가 ${Math.round(avg).toLocaleString()}원 대비 설정 손절가 도달 · 일반 매도잡신호와 무관`],
      });
    }
    if (changed) this.schedulePositionsPersist();
  }

  async maybeNotify(code) {
    const stock = state.stocks.get(code);
    if (!stock || !stock.signal) return;
    // EARLY/BUY 기록·알림은 현재 활성 세션의 Kiwoom WebSocket 체결(0A)이 신선할 때만 허용한다.
    if (!realtimeTruth(stock, Date.now()).eligible) return;
    const signal = stock.signal;
    const earlyEligible = signal.action === 'EARLY'
      && stock.activeTier === 'FOCUS'
      && Boolean(signal.preSurgeEligible || signal.earlyDiscoveryEligible)
      && Number(signal.preSurgeScore || 0) >= Math.max(62, Number(state.settings.preSurgeEarlyScore || 68) - 6);
    const buyEligible = signal.action === 'BUY' && Boolean(signal.confirmed);
    const observation = {
      preSurgeScore: Number(signal.preSurgeScore || 0),
      activeGroups: Number(signal.preSurgeGroups || 0),
      executionScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.execution || 0),
      flowScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.flow || 0),
      orderbookScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.orderbook || 0),
      priceVolumeScore: Number(signal.preSurgeBreakdown && signal.preSurgeBreakdown.priceVolume || 0),
      tradeStrength: Number(signal.metrics && signal.metrics.tradeStrength || 0),
      netBuyAmount5s: Number(signal.metrics && signal.metrics.netBuyAmount5s || 0),
      rvol1m: Number(signal.metrics && signal.metrics.rvol1m || 0),
      smartMoneyState: signal.smartMoneyState || 'NEUTRAL',
    };
    // 같은 EARLY가 유지되는 동안에도 15초/의미변화 단위로 강화 궤적만 갱신한다.
    // 푸시/타임라인 이벤트는 늘리지 않으므로 화면·알림 잡음은 증가하지 않는다.
    if (earlyEligible) {
      await updateObservationTrajectory({ code, name: stock.name, price: stock.price, observation, at: Date.now() });
    }

    // v3.1.18: 일반 감시종목은 상승초입/BUY만 기록한다.
    // 하락압력 점수는 신규진입 안전필터일 뿐 RISK/EARLY_SELL/SELL 기록·푸시로 확장하지 않는다.
    if (!buyEligible && !earlyEligible) {
      stock.activeNotificationStage = null;
      stock.entryRestricted = false;
      stock.entryRestrictionReason = null;
      if (signal.blockedByProfitPriority) {
        await recordShadowSignal({
          code,
          name: stock.name,
          price: stock.price,
          qualityScore: signal.qualityScore,
          profitPriorityScore: signal.profitPriorityScore,
          minProfitPriorityScore: Number(state.settings.minProfitPriorityScore || 78),
          vwapDistancePct: Number(signal.metrics && signal.metrics.vwapDistancePct || 0),
          spreadBps: Number(signal.metrics && signal.metrics.spreadBps || 0),
          reasons: [...signal.reasons, ...signal.warnings],
          at: Date.now(),
        });
      }
      return;
    }

    const cache = await this.loadPositionCache();
    const risk = accountRisk(cache.positions, cache.settings);
    const limitReached = risk.openCount >= Number(cache.settings.maxConcurrentPositions || 2);
    stock.entryRestricted = Boolean(risk.halted || limitReached);
    stock.entryRestrictionReason = risk.halted
      ? `신규진입 제한: ${risk.reasons.join(' · ')}`
      : limitReached ? `신규진입 제한: 최대 동시보유 ${cache.settings.maxConcurrentPositions || 2}종목` : null;

    const now = Date.now();
    const notificationAction = buyEligible ? 'BUY' : 'EARLY';
    if (stock.activeNotificationStage === notificationAction) return;
    const configuredCooldownMs = Number(state.settings.signalCooldownSeconds || 300) * 1000;
    const historyKey = `${code}:${notificationAction}`;
    const lastActionAt = this.notificationHistory.get(historyKey) || 0;
    if (now - lastActionAt < configuredCooldownMs) return;
    if (this.notificationBusy.has(historyKey)) return;
    this.notificationBusy.add(historyKey);
    try {
      stock.lastNotifiedAction = notificationAction;
      stock.lastNotifiedAt = now;
      stock.activeNotificationStage = notificationAction;
      this.notificationHistory.set(historyKey, now);
      const performanceSummary = globalThis.__SIGNAL_PERFORMANCE__;
      const verified = Boolean(performanceSummary && performanceSummary.outcomes && performanceSummary.outcomes.filter((x) => x.result === 'WIN' || x.result === 'LOSS').length >= 200);
      const recommendationContext = await getRecommendationLearningContext(code).catch(() => null);
      const learningContext = {
        ...(recommendationContext || {}),
        qualityScore: Number(signal.qualityScore || 0),
        profitPriorityScore: Number(signal.profitPriorityScore || 0),
        preSurgeScore: Number(signal.preSurgeScore || 0),
        preSurgeGroups: Number(signal.preSurgeGroups || 0),
        tradeStrength: Number(signal.metrics && signal.metrics.tradeStrength || 0),
        rvol1m: Number(signal.metrics && signal.metrics.rvol1m || 0),
        smartMoneyState: String(signal.smartMoneyState || 'NEUTRAL'),
        smartMoneyBehaviorState: String(signal.smartMoneyBehaviorState || signal.metrics && signal.metrics.smartMoneyBehaviorState || 'NEUTRAL'),
        smartMoneyConfidence: Number(signal.smartMoneyConfidence || signal.metrics && signal.metrics.smartMoneyConfidence || 0),
        shakeoutScore: Number(signal.shakeoutScore || signal.metrics && signal.metrics.shakeoutScore || 0),
        venueAgreement: signal.venueAgreement == null ? null : Number(signal.venueAgreement),
        dataCompleteness: Number(signal.dataCompleteness || 0),
        signalAction: notificationAction,
      };
      if (notificationAction === 'BUY' && signal.plan) {
        await registerBuySignal({ code, name: stock.name, price: stock.price, qualityScore: signal.qualityScore, stop: signal.plan.stop, target: signal.plan.target1, at: now, learningContext });
      } else if (notificationAction === 'EARLY' && signal.plan) {
        await registerDiscoverySignal({ code, name: stock.name, price: stock.price, qualityScore: signal.qualityScore, stop: signal.plan.stop, target: signal.plan.target1, at: now, learningContext });
      }
      await recordSignal({
        code, name: stock.name, action: notificationAction, price: stock.price,
        qualityScore: signal.qualityScore, profitPriorityScore: signal.profitPriorityScore, sellScore: 0,
        reasons: [...signal.reasons, ...signal.warnings], plan: signal.plan, at: now, verified,
        entryRestricted: stock.entryRestricted, entryRestrictionReason: stock.entryRestrictionReason,
        observation: notificationAction === 'EARLY' ? observation : null,
      });
      // EARLY는 기록부/화면 전용. 알림은 확정 BUY와 실제 보유종목 손절가 도달만 허용한다.
      if (notificationAction === 'EARLY' || stock.entryRestricted) return;
      const firstReasons = [...signal.reasons, ...signal.warnings].slice(0, 3).join(' · ');
      await notify({
        type: 'buy', action: 'BUY', code, name: stock.name, score: signal.qualityScore, price: stock.price, reasons: signal.reasons,
        message: `${signal.label} · 품질 ${signal.qualityScore}점 · 수익우선 ${signal.profitPriorityScore || 0}점 · 사전포착 ${signal.preSurgeScore || 0}점 · 스마트머니 ${signal.smartMoneyState} · ${stock.price.toLocaleString()}원${verified ? '' : ' · 미검증 신호'}${firstReasons ? ` · ${firstReasons}` : ''}`,
      });
    } finally { this.notificationBusy.delete(historyKey); }
  }

}

function startKiwoomRealtime() {
  if (singleton) return singleton;
  singleton = new KiwoomRealtimeWorker().start();
  globalThis.__KIWOOM_WORKER__ = singleton;
  return singleton;
}

module.exports = { KiwoomRealtimeWorker, startKiwoomRealtime };
