from __future__ import annotations

from datetime import datetime

from pulse_edge.bridge.models import BridgeFrame, BridgeStage
from pulse_edge.confluence.models import ConfluenceFrame, DecisionStage
from pulse_edge.decision.models import DecisionPrimaryRoute, PreBuyAction, PreBuyDecisionFrame, PreBuyStage
from pulse_edge.features.models import FeatureFrame
from pulse_edge.absorption.models import AbsorptionFrame, AbsorptionModel, AbsorptionStage
from pulse_edge.ignition.models import IgnitionFrame, IgnitionStage
from pulse_edge.patterns.models import (
    OrbFrame,
    OrbStage,
    SqueezeFrame,
    SqueezeStage,
    VwapReclaimFrame,
    VwapReclaimStage,
)
from pulse_edge.pullback.models import PullbackFrame, PullbackStage
from pulse_edge.smart_money.models import SmartMoneyFrame, SmartMoneyStage
from pulse_edge.spillover.models import SpilloverFrame, SpilloverStage


class PreBuyDecisionEngine:
    """Maps already-computed PULSE EDGE evidence into a shadow promotion board.

    This layer never edits upstream scores, never turns shadow eligibility into an
    official signal, and never emits an order action. Its job is to explain the
    current promotion state and the structural references behind it.
    """

    def evaluate(
        self,
        confluence: ConfluenceFrame,
        feature: FeatureFrame | None,
        smart: SmartMoneyFrame | None,
        ignition: IgnitionFrame | None,
        spillover: SpilloverFrame | None,
        pullback: PullbackFrame | None,
        orb: OrbFrame | None,
        squeeze: SqueezeFrame | None,
        reclaim: VwapReclaimFrame | None,
        bridge: BridgeFrame | None,
        absorption: AbsorptionFrame | None = None,
        *,
        asof: datetime,
        upstream_age_sec: float,
    ) -> PreBuyDecisionFrame:
        route, route_score, supporting = self._route(
            confluence, smart, ignition, spillover, pullback, orb, squeeze, reclaim, bridge
        )
        risks = self._risks(ignition, spillover, pullback, orb, squeeze, reclaim, bridge)
        stage = self._stage(confluence, route, risks)
        action = self._action(absorption, confluence, risks)
        entry_low, entry_high, entry_basis, invalidation, invalidation_basis = self._references(
            route, feature, pullback, orb, squeeze, reclaim
        )
        reasons = self._reasons(confluence, route, supporting)
        missing = self._missing(confluence, route, risks)
        if entry_basis is None:
            missing.append("STRUCTURAL_ENTRY_REFERENCE_UNAVAILABLE")

        return PreBuyDecisionFrame(
            venue=confluence.venue,
            symbol=confluence.symbol,
            asof=asof,
            price=feature.price if feature is not None else confluence.price,
            change_rate=feature.change_rate if feature is not None else confluence.change_rate,
            stage=stage,
            action=action,
            action_signal_price=(feature.price if action in {PreBuyAction.EARLY_BUY, PreBuyAction.STRONG_EARLY_BUY, PreBuyAction.BUY} and feature is not None else None),
            absorption_model=(absorption.model.value if absorption is not None else None),
            absorption_stage=(absorption.stage.value if absorption is not None else None),
            absorption_score_100=(absorption.score_100 if absorption is not None else None),
            absorption_price_hold_pass=bool(absorption.price_hold_pass) if absorption is not None else False,
            selling_deceleration_confirmed=bool(absorption.seller_sell_deceleration_confirmed) if absorption is not None else False,
            primary_route=route,
            supporting_routes=supporting,
            confluence_grade=confluence.confluence_grade,
            confluence_score_100=confluence.confluence_score_100,
            evidence_count=confluence.evidence_count,
            regime_state=confluence.regime_state,
            regime_score_100=confluence.regime_score_100,
            sector_name=smart.sector_name if smart is not None else None,
            sector_code=spillover.sector_code if spillover is not None else None,
            smart_flow_state=feature.smart_flow_state if feature is not None else "DATA_WAIT",
            smart_flow_score_100=feature.smart_flow_realtime_score_100 if feature is not None else None,
            smart_flow_confirmed_windows=feature.smart_flow_confirmed_windows if feature is not None else 0,
            microprice_bias_pct=feature.microprice_bias_pct if feature is not None else None,
            spread_pct=confluence.spread_pct,
            money_5m=confluence.money_5m,
            tick_age_sec=confluence.tick_age_sec,
            quote_age_sec=feature.quote_age_sec if feature is not None else None,
            discovery_source_count=confluence.discovery_source_count,
            universe_eligible=confluence.universe_eligible,
            universe_eligibility_reasons=list(confluence.universe_eligibility_reasons),
            gate_results=dict(confluence.gate_results),
            base_hard_gate_pass=confluence.base_hard_gate_pass,
            hard_gate_pass=confluence.hard_gate_pass,
            persistence_count=confluence.persistence_count,
            persistence_required=confluence.persistence_required,
            gate_failures=list(confluence.gate_failures),
            route_score_100=route_score,
            entry_reference_low=entry_low,
            entry_reference_high=entry_high,
            entry_reference_basis=entry_basis,
            invalidation_price=invalidation,
            invalidation_basis=invalidation_basis,
            reasons=reasons,
            missing_requirements=list(dict.fromkeys(missing)),
            risk_flags=list(dict.fromkeys(risks)),
            upstream_asof_age_sec=round(max(0.0, upstream_age_sec), 3),
            official_signal_enabled=False,
            order_action_enabled=False,
        )

    @staticmethod
    def _route(confluence, smart, ignition, spillover, pullback, orb, squeeze, reclaim, bridge):
        hits: list[tuple[DecisionPrimaryRoute, float | None]] = []
        if confluence.venue.value == "NXT" and bridge is not None and bridge.stage == BridgeStage.NXT_CONFIRM_SHADOW:
            hits.append((DecisionPrimaryRoute.NXT_BRIDGE, bridge.bridge_score_100))
        if pullback is not None and pullback.stage == PullbackStage.SECOND_WAVE_SHADOW:
            hits.append((DecisionPrimaryRoute.SECOND_WAVE, pullback.second_wave_score_100))
        if reclaim is not None and reclaim.stage == VwapReclaimStage.VWAP_RECLAIM_SHADOW:
            hits.append((DecisionPrimaryRoute.VWAP_RECLAIM, reclaim.reclaim_score_100))
        if orb is not None and orb.stage == OrbStage.ORB_RETEST_CONFIRMED_SHADOW:
            hits.append((DecisionPrimaryRoute.ORB_RETEST, orb.orb_score_100))
        if squeeze is not None and squeeze.stage == SqueezeStage.SQUEEZE_RELEASE_SHADOW:
            hits.append((DecisionPrimaryRoute.SQUEEZE_RELEASE, squeeze.squeeze_score_100))
        if spillover is not None and spillover.stage == SpilloverStage.EARLY_FOLLOWER_SHADOW:
            hits.append((DecisionPrimaryRoute.EARLY_FOLLOWER, spillover.spillover_score_100))
        if ignition is not None and ignition.stage in {
            IgnitionStage.FLOW_IGNITION_SHADOW,
            IgnitionStage.VERIFIED_CATALYST_IGNITION_SHADOW,
        } and not ignition.veto:
            hits.append((DecisionPrimaryRoute.IGNITION, ignition.ignition_score_100))
        if smart is not None and smart.stage == SmartMoneyStage.PRE_SHADOW:
            hits.append((DecisionPrimaryRoute.SMART_PRE, smart.raw_score_100))

        if not hits:
            return DecisionPrimaryRoute.OBSERVE, None, []
        primary, score = hits[0]
        supporting = [route.value for route, _ in hits[1:]]
        return primary, score, supporting

    @staticmethod
    def _risks(ignition, spillover, pullback, orb, squeeze, reclaim, bridge) -> list[str]:
        out: list[str] = []
        if ignition is not None and (ignition.veto or ignition.stage == IgnitionStage.FALSE_BREAKOUT_VETO):
            out.append("FALSE_BREAKOUT_VETO")
        if spillover is not None and spillover.stage == SpilloverStage.OVERHEAT_RISK_SHADOW:
            out.append("SECTOR_OVERHEAT_RISK")
        if pullback is not None and pullback.stage == PullbackStage.OVEREXTENDED_RISK_SHADOW:
            out.append("PULLBACK_OVEREXTENDED_RISK")
        if orb is not None and orb.stage in {OrbStage.ORB_FAIL_SHADOW, OrbStage.OVERHEAT_RISK_SHADOW}:
            out.append(orb.stage.value)
        if squeeze is not None and squeeze.stage == SqueezeStage.OVEREXTENDED_RISK_SHADOW:
            out.append("SQUEEZE_OVEREXTENDED_RISK")
        if reclaim is not None and reclaim.stage == VwapReclaimStage.RECLAIM_FAIL_SHADOW:
            out.append("VWAP_RECLAIM_FAIL")
        if bridge is not None and bridge.stage in {BridgeStage.PREMIUM_RISK_SHADOW, BridgeStage.LOW_LIQUIDITY_SHADOW}:
            out.append(bridge.stage.value)
        return out

    @staticmethod
    def _stage(confluence: ConfluenceFrame, route: DecisionPrimaryRoute, risks: list[str]) -> PreBuyStage:
        if confluence.decision_stage == DecisionStage.DATA_WAIT:
            return PreBuyStage.DATA_WAIT
        if confluence.decision_stage == DecisionStage.BLOCKED_SHADOW or risks:
            return PreBuyStage.BLOCKED_SHADOW
        if route == DecisionPrimaryRoute.OBSERVE:
            return PreBuyStage.PREBUY_WATCH_SHADOW
        if confluence.decision_stage == DecisionStage.A_PLUS_ELIGIBLE_SHADOW:
            return PreBuyStage.A_PLUS_ELIGIBLE_SHADOW
        if confluence.decision_stage == DecisionStage.ENTRY_ELIGIBLE_SHADOW:
            return PreBuyStage.ENTRY_ELIGIBLE_SHADOW
        if confluence.decision_stage == DecisionStage.READY_SHADOW and confluence.base_hard_gate_pass:
            return PreBuyStage.READY_SHADOW
        if confluence.evidence_count >= 3:
            return PreBuyStage.PREBUY_SHADOW
        return PreBuyStage.PREBUY_WATCH_SHADOW


    @staticmethod
    def _action(absorption: AbsorptionFrame | None, confluence: ConfluenceFrame, risks: list[str]) -> PreBuyAction:
        """2.2.2 pre-emptive action mapping.

        PRICE HOLD remains mandatory. DUAL_CONFIRMED is a confidence booster, not
        an absolute EARLY_BUY requirement. A/B1/B2/B3 may qualify independently
        when price hold and selling deceleration are both confirmed. Final BUY
        remains reserved for PRE_IGNITION. This does not alter absorption scores.
        """
        if risks or confluence.decision_stage in {DecisionStage.DATA_WAIT, DecisionStage.BLOCKED_SHADOW}:
            return PreBuyAction.WATCH
        if absorption is None:
            return PreBuyAction.WATCH
        valid_models = {
            AbsorptionModel.A_FOREIGN_ABSORB,
            AbsorptionModel.B1_FUND_ABSORB,
            AbsorptionModel.B2_PENSION_ABSORB,
            AbsorptionModel.B3_FUND_PENSION_ABSORB,
            AbsorptionModel.DUAL_CONFIRMED,
        }
        if absorption.model not in valid_models or not absorption.price_hold_pass:
            return PreBuyAction.WATCH
        if absorption.stage == AbsorptionStage.PRE_IGNITION and absorption.seller_sell_deceleration_confirmed:
            return PreBuyAction.BUY
        if absorption.stage in {AbsorptionStage.SUPPLY_TIGHT, AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED} and absorption.seller_sell_deceleration_confirmed:
            return PreBuyAction.STRONG_EARLY_BUY
        if absorption.stage in {AbsorptionStage.PRICE_HOLD, AbsorptionStage.SUPPLY_TIGHT, AbsorptionStage.SUPPLY_EXHAUSTION_ESTIMATED} and absorption.seller_sell_deceleration_confirmed:
            return PreBuyAction.EARLY_BUY
        return PreBuyAction.READY

    @staticmethod
    def _references(route, feature, pullback, orb, squeeze, reclaim):
        price = feature.price if feature is not None else None
        vwap = feature.session_vwap if feature is not None else None
        low = high = invalidation = None
        basis = invalidation_basis = None

        if route == DecisionPrimaryRoute.SECOND_WAVE and pullback is not None and price is not None:
            anchors = [x for x in (pullback.trough_price, vwap) if x is not None and x > 0 and x <= price]
            low = max(anchors) if anchors else None
            high = price if low is not None else None
            basis = "SECOND_WAVE_SUPPORT_TO_CURRENT" if low is not None else None
            invalidation = pullback.trough_price
            invalidation_basis = "PULLBACK_TROUGH_BREAK" if invalidation is not None else None
        elif route == DecisionPrimaryRoute.VWAP_RECLAIM and reclaim is not None and price is not None:
            if reclaim.session_vwap is not None and reclaim.session_vwap <= price:
                low, high = reclaim.session_vwap, price
                basis = "RECLAIMED_VWAP_TO_CURRENT"
                if reclaim.min_below_vwap_pct is not None:
                    invalidation = reclaim.session_vwap * (1.0 + reclaim.min_below_vwap_pct / 100.0)
                    invalidation_basis = "PRIOR_RECLAIM_BREAKDOWN_LOW"
        elif route == DecisionPrimaryRoute.ORB_RETEST and orb is not None and price is not None:
            if orb.opening_high is not None and orb.opening_high <= price:
                low, high = orb.opening_high, price
                basis = "OPENING_RANGE_HIGH_TO_CURRENT"
                invalidation = orb.opening_high
                invalidation_basis = "OPENING_RANGE_HIGH_LOSS"
        elif route == DecisionPrimaryRoute.SQUEEZE_RELEASE and squeeze is not None and price is not None:
            if squeeze.compression_high is not None and squeeze.compression_high <= price:
                low, high = squeeze.compression_high, price
                basis = "COMPRESSION_HIGH_TO_CURRENT"
                invalidation = squeeze.compression_low
                invalidation_basis = "COMPRESSION_LOW_BREAK" if invalidation is not None else None
        elif price is not None and vwap is not None and vwap > 0:
            low, high = sorted((price, vwap))
            basis = "CURRENT_TO_SESSION_VWAP"
            invalidation = vwap
            invalidation_basis = "SESSION_VWAP_REFERENCE"

        def r(x):
            return round(x, 6) if x is not None else None
        return r(low), r(high), basis, r(invalidation), invalidation_basis

    @staticmethod
    def _reasons(confluence: ConfluenceFrame, route: DecisionPrimaryRoute, supporting: list[str]) -> list[str]:
        out = [f"PRIMARY_ROUTE={route.value}"]
        out.append(f"EVIDENCE={confluence.evidence_count}/5")
        out.append(f"REGIME={confluence.regime_state.value}")
        if confluence.base_hard_gate_pass:
            out.append("BASE_HARD_GATE_PASS")
        if confluence.hard_gate_pass:
            out.append("PERSISTENT_HARD_GATE_PASS")
        if supporting:
            out.append("SUPPORTING_ROUTES=" + ",".join(supporting))
        return out

    @staticmethod
    def _missing(confluence: ConfluenceFrame, route: DecisionPrimaryRoute, risks: list[str]) -> list[str]:
        out: list[str] = []
        out.extend(f"GATE:{name}" for name in confluence.gate_failures)
        if route == DecisionPrimaryRoute.OBSERVE:
            out.append("PRIMARY_ROUTE_NOT_CONFIRMED")
        if confluence.evidence_count < 3:
            out.append(f"EVIDENCE_NEEDS_{3 - confluence.evidence_count}_FOR_PREBUY")
        if confluence.evidence_count < 4:
            out.append(f"EVIDENCE_NEEDS_{4 - confluence.evidence_count}_FOR_ENTRY_ELIGIBLE")
        if confluence.evidence_count < 5:
            out.append(f"EVIDENCE_NEEDS_{5 - confluence.evidence_count}_FOR_A_PLUS_ELIGIBLE")
        if confluence.base_hard_gate_pass and not confluence.hard_gate_pass:
            out.append(f"PERSISTENCE={confluence.persistence_count}/{confluence.persistence_required}")
        out.extend(f"RISK:{x}" for x in risks)
        return out
