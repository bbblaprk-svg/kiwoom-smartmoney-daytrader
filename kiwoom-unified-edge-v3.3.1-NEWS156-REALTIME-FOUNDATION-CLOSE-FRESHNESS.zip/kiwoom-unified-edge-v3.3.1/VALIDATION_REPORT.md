# v3.3.0 REALTIME FOUNDATION validation

검증 완료 항목:
- trader `npm run check`: PASS
- news-radar v1.5.6 `npm run check`: PASS
- realtime-foundation-check: PASS
- realtime-truth-check: PASS
- realtime-latency-check: PASS
- pre-ignition-check: PASS
- smart-money-venue-check: PASS (v3.3.0 bare 0B + FID9081 정책으로 갱신)
- 30종목 12,000 이벤트 load-check: errors 0, finalPending 0, finalActive 0, 약 80,537 events/sec, event-loop p95 22.12 ms
- 모든 JS `node --check`: PASS
- ZIP 무결성 / Trader / News / Bundle SHA256 manifest: PASS

주의:
- 실제 Kiwoom 운영서버의 KRX/NXT firstTick/fresh는 로컬 합성검사로 보장할 수 없다.
- AWS 배포 스크립트는 활성 거래소에서 `REG ACK + FID9081-confirmed firstTick + fresh`를 실제로 확인하지 못하면 신규판을 성공 처리하지 않고 기존 컨테이너로 롤백한다.
