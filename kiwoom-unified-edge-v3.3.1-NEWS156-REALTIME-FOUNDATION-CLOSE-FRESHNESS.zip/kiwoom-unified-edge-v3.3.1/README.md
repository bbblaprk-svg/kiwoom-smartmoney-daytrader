# v3.3.1 REALTIME FOUNDATION + CLOSE FRESHNESS

실제 수신된 국내 WebSocket 데이터만 판단에 사용합니다. KRX/NXT를 등록 단계에서 억지로 분리하지 않고, bare 6자리 코드로 0B/0D/0u/0F를 등록한 뒤 REAL payload의 FID 9081이 KRX/NXT를 명시한 경우에만 해당 거래소 데이터로 저장합니다. FID 9081이 없으면 UNKNOWN으로 폐기하며 시각·suffix·watch mode로 추정하지 않습니다.

# Kiwoom Unified Edge v3.2.17 + News Radar v1.5.6

## 핵심 목표
**급등 후 추격이 아니라 급등 전 PRE-IGNITION 포착.** 장중 현재가와 동적 매수판단은 Kiwoom 공식 WebSocket 실시간 데이터만 사용합니다.

## 중요 수정
Kiwoom 공식 국내주식 realtime 타입을 다시 대조해 다음과 같이 교정했습니다.

- 0A: 주식체결 — 실시간 현재가/체결 판단
- 0B: 주식우선호가 — 보조
- 0C: 주식호가잔량 — orderbook
- 0E: 주식당일거래원
- 0u: 종목프로그램매매
- 0m: 장시작시간
- 0w: VI발동/해제

따라서 이전처럼 0B를 체결, 0D를 정규 호가잔량으로 오인하는 경로는 제거했습니다.

## 실시간 정책
- 30종목 모두 0A + 0C + 0w 실시간 구독
- FOCUS는 0F 추가
- 활성장 current price = fresh 0A only
- fresh 0A 없으면 전일종가/REST로 대체하지 않고 현재가 미수신 + 신규진입 차단
- NXT `_NX` 등록 및 NXT-only bare-code route 보정
- KRX/NXT 동시장에서 출처 불명 데이터는 UNKNOWN fail-closed
- 8초 무수신 REG 복구, 18초 지속 시 hard reconnect

## 앱 내부 지연 정책
- trade eval 40ms
- aux eval 80ms
- SSE 100ms
- UI flush 100ms

네트워크/거래소 물리 지연을 0으로 보장하는 의미가 아니라, 앱 내부에서 발생하던 불필요한 polling/1초 batching/stale substitution을 제거하는 정책입니다.

## PRE-IGNITION
Tape + Book + Program Flow + Structure 중 독립 3축 이상이 동시 강화될 때만 사전포착합니다. +4.5% 이상은 PRE-IGNITION에서 제외하고 +6% 이상은 신규진입을 hard block합니다.

## News v1.5.6
ROTATION PICKS와 3/5일 섹터 회전은 후보 발굴용입니다. 뉴스 자체는 BUY 점수에 들어가지 않습니다.

자세한 내용은 `PRE_IGNITION_REALTIME_CORE_V3216.md`와 `VALIDATION_REPORT.md`를 확인하세요.

## v3.3.1 maintenance

REALTIME FOUNDATION remains unchanged. This maintenance release adds stale-close freshness gating, startup close catch-up, and fixes live entry guidance to use the v3.3.0 realtime source.
