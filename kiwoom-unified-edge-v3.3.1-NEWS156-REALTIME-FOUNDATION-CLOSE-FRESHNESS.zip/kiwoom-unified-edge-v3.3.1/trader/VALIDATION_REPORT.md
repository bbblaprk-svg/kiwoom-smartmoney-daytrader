# Trader v3.3.1 REALTIME FOUNDATION + CLOSE FRESHNESS validation

- v3.3.0 realtime foundation data path is unchanged: one official domestic WebSocket, bare 6-digit REG, 0B trade + FID9081 venue truth.
- closeSnapshot freshness gate: PASS. Stale close dates cannot drive current price, close ranking, public closeDecision, or preflight readiness.
- startup close catch-up after 15:32/20:01 KST: PASS static/runtime checks.
- legacy entry-guidance source mismatch (`KIWOOM_WEBSOCKET_0A`) removed; current source is `KIWOOM_WEBSOCKET_TRADE_AUTO`: PASS.
- live signal table: outside session intentionally empty; active-session EARLY/PRE-BUY/BUY rows require fresh WebSocket data.
- EARLY/PRE-BUY show waiting range; confirmed BUY shows fixed entry/stop/targets.
- `npm run check`: PASS.
- 30 symbols / 30,000 events load check: errors 0, finalPending 0, finalActive 0, ~105,634 events/sec, event-loop p95 22.66 ms.
- Docker build still re-runs manifest check, npm checks, 30k load check, and Next production build before container replacement.
