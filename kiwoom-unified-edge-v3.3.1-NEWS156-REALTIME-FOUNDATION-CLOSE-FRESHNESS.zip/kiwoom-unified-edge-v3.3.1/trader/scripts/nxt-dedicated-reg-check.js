const fs=require('fs'); const assert=require('assert');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8'); const health=fs.readFileSync('pages/api/health.js','utf8');
assert(worker.includes('KRX_CORE_BARE_0B')); assert(worker.includes('startNxtProbeSocket')); assert(worker.includes('onNxtProbeMessage'));
assert(worker.includes("stex_tp:'NXT'")); assert(worker.includes("stex_tp:'2'")); assert(worker.includes("venue!=='NXT'"));
assert(worker.includes("values['9081']")); assert(!worker.includes("values['9081']||values['337']"));
assert(health.includes('KRX_BARE_LOCK_NXT_ISOLATED_PROBE_V11')); assert(health.includes('isolated NXT')||health.includes('nxtProbe'));
console.log('NXT_ISOLATED_REG_CHECK PASS');
