const fs=require('fs'); const assert=require('assert');
const worker=fs.readFileSync('worker/kiwoomRealtime.js','utf8');
assert(worker.includes('NXT_CORE_0B')); assert(worker.includes('KRX_CORE_0B'));
assert(worker.includes('websocketVenueItem')); assert(worker.includes('stex_tp: stex'));
console.log('REALTIME_ENGINE_V3217_COMPAT_CHECK PASS -> dedicated venue registration');
