# Kiwoom Unified Edge v3.2.7 PIPELINE GUARD 검증보고서

검증일: 2026-08-04

## 전체 자동검사 PASS
- unit / integration / storage / flow / REST
- market-discovery / recommendations / usability / profit-focus
- observation-strength / adaptive-learning / entry-guidance / unified
- close-learning / smart-money-venue / low-traffic-portfolio / close-sync-resilience
- 신규 pipeline-audit

## 신규 파이프라인 감사 결과
- Kiwoom realtime mapping guard: trade 0B / orderbook 0D / broker 0F / program 0w / market 0s / VI 1h
- 500틱 burst: 체결 저장 500, 전체 signal evaluation 1, evaluation skip 499, drop 0
- 장중 periodic full REST 없음
- market-status 이벤트에서 full snapshot 호출 없음
- intraday recommendation market-profile enrichment cache-only
- smart-money: 신선도 + 상태 persistence + tape 중복축 제거 + 서로 다른 원천 확인 검증
- official close flow: REST 우선 + 신선 realtime fallback + 보존값 display-only
- learning: 기본 min total 60 / bucket 12 / max adjustment ±6
- BUY_ACTIVE 관리행 고정 + 데이터완전성/RR 열 확인
- 실제 포지션 학습: 앱 BUY/CLOSE_BUY 문맥 캡처 + 실제 진입/청산가 R 계산 + 60표본 이후 우선학습 검사 PASS
- 새 설치 AUTO 시장선정 bootstrap + 이후 AUTO LIGHT 최대2 교체 구조 점검
- LIGHT 승격은 절대거래대금 외 전일 동시간 거래량급증 보조축을 허용하되 BUY 하드게이트와 분리

## 30종목 / 30,000 합성 이벤트 부하검사 PASS
- 총 30,000 이벤트
- 30종목
- injection 278ms
- total 499ms
- 합성 처리량 약 107,914 ticks/sec
- event-loop p95 21.02ms / max 22.25ms
- coalesced 29,490 / processed 510
- errors 0
- RSS 약 98MB
- final pending/active 0/0

합성 처리량은 실제 Kiwoom 회선/장중 수신속도 또는 미래 승률을 의미하지 않는다.

## Production build 제한
현재 작업환경에는 기존 node_modules/Next 실행파일이 없고 내부 npm 미러가 일부 패키지에 404를 반환하여 로컬 `next build`까지 완료하지 못했다. 배포 Dockerfile은 공식 npm registry를 설정한 뒤 `npm install → npm run check → 30,000 tick 부하검사 → next build`를 모두 통과해야 이미지를 생성한다. 배포 스크립트는 build/health/실시간 freshness/뉴스 bridge 검증 실패 시 기존 컨테이너 롤백을 시도한다.

## 해석 주의
- 관리점수, shakeoutScore, 증거신뢰도는 통계적 승률이 아니다.
- 정상장 4~6개는 관리 범위 목표이며 신호가 약하면 숫자를 강제하지 않는다.
- 자체학습은 하드 BUY 조건을 완화하지 않는다.
- 실전 우수성은 AWS 장중 forward/shadow 성과를 쌓아 승률·평균R·MFE/MAE·최대낙폭으로 검증해야 한다.
