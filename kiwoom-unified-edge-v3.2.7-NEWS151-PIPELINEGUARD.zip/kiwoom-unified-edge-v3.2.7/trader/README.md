# Kiwoom Unified Edge Trader v3.2.7 PIPELINE GUARD

## Realtime pipeline
- KRX/NXT WebSocket 실시간 체결을 최우선으로 받습니다.
- 모든 체결 틱은 상태에 반영하되, 전체 신호엔진은 체결 기본 80ms/보조 이벤트 180ms 간격으로 평가하여 burst 병목을 줄입니다.
- quick promotion 경로로 LIGHT→FOCUS 승격에 필요한 최소 지표만 빠르게 계산합니다. 절대거래대금이 아직 작아도 전일 동시간 거래량비 150% 이상 + 강한 체결/순매수/VWAP이 겹치면 정밀피드 후보가 될 수 있습니다.
- FOCUS 핵심 스마트머니 준비도는 실체결 + 호가 + 프로그램입니다. 거래원(0F)은 저빈도 보조증거이며 BUY 하드게이트가 아닙니다.
- 런타임 평가횟수/스킵/평가시간/이벤트를 `/api/health` 인증 상세정보에 노출합니다.

## LOW TRAFFIC WebSocket-first
- 장중 자동 15분 전체 REST 스냅샷은 없습니다.
- 추천 프로필 보강도 장중에는 cache-only로 동작하여 직렬 REST 폭주를 막습니다.
- FOCUS 거래소가 stale일 때만 제한적인 REST 현재가 보조를 사용하며 보조값은 스마트머니/BUY 체결근거로 사용하지 않습니다.
- 전체 REST 종가·일봉·공식수급 동기화는 KRX 15:32, NXT 20:01 KST 이후에 실행합니다.
- 실패 종목만 단계적 재시도하고 서버 재기동 시 미완료 단계를 catch-up 합니다.
- 이전 스냅샷은 표시용으로 보존해도 오늘 공식 KRX 종가/수급이 확인되지 않으면 CLOSE_BUY는 차단됩니다.

## Smart Money Behavior
`ACCUMULATION → SHAKEOUT → TURN → MARKUP → DISTRIBUTION / EXHAUSTION`
- 신선한 체결/호가/프로그램만 사용합니다.
- 호가는 EWMA와 support streak로 반복 확인합니다.
- SHAKEOUT은 바로 BUY하지 않습니다.
- execution/대형체결/흡수/매도→매수 전환은 같은 tape 원천으로 묶어 독립증거를 중복 계산하지 않습니다.
- TURN은 실제 매도→공격매수 전환(tape) + VWAP/프로그램/호가/KRX·NXT 중 최소 2개 다른 원천을 요구합니다.
- MARKUP은 강한 tape + 프로그램/호가/가격/KRX·NXT 중 최소 3개 다른 원천을 요구합니다.
- KRX/NXT 방향 충돌 시 확정 BUY를 보류합니다.
- 스마트머니 confidence는 승률이 아니라 증거신뢰도입니다.

## Automatic market selection
- 배포 기본값은 `INTRADAY_AUTO_APPLY_DEFAULT=true`입니다. 사용자가 UI에서 OFF하면 그 선택을 보존합니다.
- AUTO 목록이 비어 있는 새 설치는 시장순위 3개 원천으로 FOCUS/LIGHT를 한 번 채웁니다.
- 이후 5분마다 수동·고정·AUTO FOCUS는 보호하고 AUTO LIGHT만 최대 2종목 교체합니다.
- 30종목 전체는 체결을 받고, FOCUS만 호가/프로그램/거래원을 추가 구독하여 네트워크와 CPU를 절약합니다.

## Managed Signals 4~6
일반 정상장에서는 BUY 임계값을 낮추지 않고 BUY/PRE-BUY/EARLY를 우선한 뒤 안전 예비관찰로만 약 4~6개를 관리합니다. 강한 장 최대 6, 약세장 최대 4입니다.

BUY_ACTIVE는 `BUY_MANAGE`로 테이블에 고정됩니다. 테이블은 단계, 종목, 관리점수, 증거신뢰, 데이터완전성, 현재가, 진입/기준가, 수익률, 등락률, R/R, KRX/NXT, 신호시각을 표시합니다.

## Dual Close + Learning
- TREND / FLOOR_REVERSAL 종가 엔진을 유지합니다.
- 투신·연기금은 독립 보조가점이며 단독 BUY 근거가 아닙니다.
- adaptive/close 학습은 기본 전체 60표본, 동일 버킷 12표본부터 적용합니다.
- 기본 보정폭은 ±6점이며 하드 BUY 게이트는 학습이 완화하지 못합니다.
- CLOSE_BUY 결과에 MFE/MAE, R, 관찰 trading bars를 저장합니다.
- 사용자가 실제 매수/매도 체결을 기록하면, 진입 시 앱 BUY/CLOSE_BUY 문맥이 있었던 포지션만 실제 체결 학습표본으로 저장하며 60건 이후 ACTUAL_POSITION을 우선 사용합니다.

## News
News Radar 1.5.1-unified 브리지를 유지합니다.

## 검사
- `npm run check`: 전체 회귀 + pipeline audit
- `LOAD_TEST_SYMBOLS=30 LOAD_TEST_TICKS=30000 npm run check:load`: 30종목 합성 실시간 부하검사

실제 장중 성능/승률은 Kiwoom 회선과 AWS 환경에서 forward/shadow 표본으로 별도 검증해야 합니다.
