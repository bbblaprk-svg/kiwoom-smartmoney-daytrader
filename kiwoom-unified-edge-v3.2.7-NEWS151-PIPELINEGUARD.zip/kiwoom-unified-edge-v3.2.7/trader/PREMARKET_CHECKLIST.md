# v3.2.7 장전/장중 체크리스트

1. 화면/컨테이너 버전 `3.2.7` 확인.
2. `/api/health`: `status=connected`, `subscribed<=30`, `krxSubscribed>0`, `nxtSubscribed>0` 확인.
3. 장중에는 `venueFeeds.KRX.fresh`, NXT 운영시간에는 `venueFeeds.NXT.fresh`가 실제로 증가하는지 확인.
4. `socketFrameAgeMs`가 watchdog 기준보다 짧게 유지되는지 확인.
5. `venueRegistration`에 KRX fatal/degraded가 없는지 확인.
6. 스마트머니 행동은 SHAKEOUT만으로 BUY하지 않고 TURN/MARKUP 확인 후 승격되는지 확인.
7. REST fallback 발생 시 `fallbackLastAt`은 보조 확인일 뿐 실시간 체결로 오인하지 않는지 확인.
8. News Radar `/api/discovery-feed`가 5초 이내 200 응답인지 확인.
