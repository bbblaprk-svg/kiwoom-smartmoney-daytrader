# Lightsail v3.2.7 SMARTMONEY DUALFEED 업데이트

배포 ZIP과 전용 update script를 GitHub 저장소 최상위에 올린 뒤 update script를 실행합니다.

배포 스크립트는 기존 `.env` 및 영속 볼륨을 보존하고, News Radar 1.5.1과 Trader 3.2.7를 새 이미지로 빌드합니다. 빌드/헬스체크/뉴스브리지 검증이 실패하면 기존 컨테이너 롤백을 시도합니다.

새 기본값:
- `KIWOOM_SOCKET_WATCHDOG_MS=45000`
- `KIWOOM_VENUE_STALE_MS=12000`
- `KIWOOM_REST_FALLBACK_INTERVAL_MS=5000`

실제 장중 검증은 `/api/health`의 `krxSubscribed`, `nxtSubscribed`, `venueFeeds`, `venueRegistration`, `socketFrameAgeMs`를 확인합니다.
