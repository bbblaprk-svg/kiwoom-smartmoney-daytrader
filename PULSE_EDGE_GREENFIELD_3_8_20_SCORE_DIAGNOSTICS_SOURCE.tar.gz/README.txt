PULSE EDGE 3.8.20_SCORE_DIAGNOSTICS
3.8.19 대비 변경: 점수 계산에서 None으로 빠지는 네 가지 사유를 기록하고 기존 진단 줄에 표시.
점수, 진입/탈락 조건, 신선도, 구독, 저장소 처리, 배포 안전 기준은 변경하지 않음.
API: no_score_reasons, evaluated_at, subscription_details[].evaluation 추가.
NO_SCORE를 사유 있는 NOT_QUALIFIED와 평가 대기 AWAITING_EVALUATION으로 구분.
평가 시점의 스냅샷이므로 현재 수신 상태와 시각이 다를 수 있음.
이번 수정은 진단 누락 수정이며 후보 수 증가나 탐지 성과를 보장하지 않음.
서버 재배포 전 Dockerfile/소스/배포 스크립트 세 파일을 같은 디렉터리에 배치.
Dockerfile 이름에 확장자를 붙이지 말 것. 스크립트는 sudo bash로 실행.
실제 Docker 빌드와 Kiwoom/NXT 실시간 검증은 배포 스크립트가 수행.
