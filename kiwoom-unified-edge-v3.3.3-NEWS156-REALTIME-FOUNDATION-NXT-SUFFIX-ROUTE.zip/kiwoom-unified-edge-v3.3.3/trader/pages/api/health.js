const { state } = require('../../lib/realtimeStore');
const { getStoreMetrics } = require('../../lib/store');
const runtimeMetrics = require('../../lib/runtimeMetrics');
const { isAuthenticated } = require('../../lib/auth');
const { getRestMetrics } = require('../../lib/kiwoomClient');
const { closeSnapshotFreshness } = require('../../lib/marketSnapshot');

module.exports = function handler(req, res) {
  const connected = state.connection.status === 'connected';
  const stocks = [...state.stocks.values()];
  const focus = stocks.filter((stock) => stock.activeTier === 'FOCUS').length;
  const light = stocks.filter((stock) => stock.activeTier === 'LIGHT').length;
  const promoted = stocks.filter((stock) => Number(stock.promotedUntil || 0) > Date.now()).length;
  const closeFreshnessRows = stocks.map((stock) => closeSnapshotFreshness(stock.marketSnapshot, new Date()));
  const closeSnapshots = closeFreshnessRows.filter((row) => row.rankEligible).length;
  const staleCloseSnapshots = closeFreshnessRows.filter((row) => row.status === 'STALE_CLOSE_SNAPSHOT').length;
  const now = Date.now();
  const kstDate = new Date(now + 9*60*60*1000).toISOString().slice(0,10).replace(/-/g,'');
  const focusStocks = stocks.filter((stock) => stock.activeTier === 'FOCUS');
  const allFeedReady = {
    trade: stocks.filter((stock) => stock.updatedAt && now - stock.updatedAt <= 5000 && Number(stock.tradeEventCount || 0) >= 1).length,
    orderbook: stocks.filter((stock) => stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 5000).length,
    program: stocks.filter((stock) => stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 25000 && Number(stock.program.sampleCount || 0) >= 1).length,
    broker: stocks.filter((stock) => stock.broker && stock.broker.updatedAt && now - stock.broker.updatedAt <= 120000).length,
  };
  const feedReady = {
    trade: focusStocks.filter((stock) => stock.updatedAt && now - stock.updatedAt <= 1500 && Number(stock.tradeEventCount || 0) >= 5).length,
    orderbook: focusStocks.filter((stock) => stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 3500).length,
    program: focusStocks.filter((stock) => stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 20000 && Number(stock.program.sampleCount || 0) >= 2).length,
    broker: focusStocks.filter((stock) => stock.broker && stock.broker.updatedAt && now - stock.broker.updatedAt <= 120000).length,
  };
  const checkpointStocks = stocks.filter((stock) => stock.smartMoneyCheckpoint && stock.smartMoneyCheckpoint.sessionDate === kstDate);
  const smartMoneyCheckpoints = checkpointStocks.length;
  const smartMoneyCheckpointFull = checkpointStocks.filter((stock) => String(stock.smartMoneyCheckpoint.quality || 'FULL').toUpperCase() === 'FULL').length;
  const smartMoneyCheckpointPartial = checkpointStocks.filter((stock) => String(stock.smartMoneyCheckpoint.quality || '').toUpperCase() === 'PARTIAL').length;
  const smartMoneyReady = focusStocks.filter((stock) => stock.updatedAt && now - stock.updatedAt <= 1500 && Number(stock.tradeEventCount || 0) >= 5
    && stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 3500
    && stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 20000 && Number(stock.program.sampleCount || 0) >= 2).length;

  const venueFeeds = state.connection.venueHealth || { KRX: { fresh: 0, stale: 0, subscribed: 0 }, NXT: { fresh: 0, stale: 0, subscribed: 0 } };
  const dualFresh = stocks.filter((stock) => {
    const k = Number(stock.venues?.KRX?.updatedAt || 0), n = Number(stock.venues?.NXT?.updatedAt || 0);
    return k > 0 && n > 0 && now-k <= 5000 && now-n <= 5000;
  }).length;
  venueFeeds.dualFresh = dualFresh;
  const behaviorStates = {};
  for (const stock of focusStocks) {
    const behavior = String(stock.smartMoney && stock.smartMoney.behaviorState || 'NEUTRAL');
    behaviorStates[behavior] = Number(behaviorStates[behavior] || 0) + 1;
  }
  const load = runtimeMetrics.snapshot();
  const store = getStoreMetrics();
  const rest = getRestMetrics();
  const expectedVenues = Array.isArray(state.connection.expectedVenues) ? state.connection.expectedVenues : [];
  const venueRouteStats = stocks.reduce((acc, stock) => {
    acc.KRX += Number(stock.venueStats?.KRX || 0);
    acc.NXT += Number(stock.venueStats?.NXT || 0);
    acc.UNKNOWN += Number(stock.venueStats?.UNKNOWN || 0);
    const source = String(stock.lastTradeVenueSource || 'NONE');
    acc.sources[source] = Number(acc.sources[source] || 0) + 1;
    return acc;
  }, { KRX:0, NXT:0, UNKNOWN:0, sources:{} });

  const payload = {
    ok: connected,
    version: '3.3.3-realtime-foundation-nxt-suffix-route-news156',
    status: state.connection.status,
    lastMessageAt: state.connection.lastMessageAt,
    subscribed: state.connection.subscribed.length,
    dataStatus: state.connection.dataStatus || 'UNKNOWN',
    registrationStats: state.connection.registrationStats || {},
    wireSubscribed: (state.connection.wireSubscribed || []).length,
    krxSubscribed: (state.connection.krxSubscribed || []).length,
    nxtSubscribed: (state.connection.nxtSubscribed || []).length,
    focus, light, promoted, closeSnapshots, staleCloseSnapshots, smartMoneyReady, smartMoneyCheckpoints, smartMoneyCheckpointFull, smartMoneyCheckpointPartial,
    feedReady, allFeedReady, venueFeeds, behaviorStates,
    expectedVenues, venueRouteStats,
    realtimeTruth: {
      activeSession: expectedVenues.length > 0,
      expectedVenues,
      judgmentRoute: 'KIWOOM_WEBSOCKET_ONLY',
      priceRoute: 'KIWOOM_WEBSOCKET_TRADE_AUTO_ONLY_WHEN_ACTIVE',
      restAffectsJudgment: false,
      closeSnapshotAffectsActiveCurrentPrice: false,
      missingRealtimeAction: 'BLOCK_NEW_ENTRY_AND_SHOW_MISSING',
    },
    closeAuditMode: Boolean(state.connection.closeAuditMode), closeAuditFullCount: Number(state.connection.closeAuditFullCount || 0),
    socketFrameAgeMs: state.connection.socketFrameAgeMs ?? null, venueRegistration: state.connection.venueRegistration || {}, venueRecovery: state.connection.venueRecovery || null,
    fallbackLastAt: state.connection.fallbackLastAt || null, fallbackLastVenue: state.connection.fallbackLastVenue || null, fallbackLastCode: state.connection.fallbackLastCode || null,
    fallbackDiagnosticOnly: true,
    lastSnapshotAt: state.connection.lastSnapshotAt || null,
    snapshotStatus: state.connection.snapshotStatus || null,
    snapshotPolicy: state.connection.snapshotPolicy || 'CLOSE_ONLY',
    closeSync: state.connection.closeSync || null,
    startupCloseCatchup: state.connection.startupCloseCatchup || null,
    snapshotRetryPending: Number(state.connection.snapshotRetryPending || 0),
    snapshotRetryCodes: state.connection.snapshotRetryCodes || [],
    trafficMode: 'ONE_DOMESTIC_WEBSOCKET_BARE_REG_V1',
    realtimeTruthMode: 'REAL_PAYLOAD_FID9081_ONLY_V1',
    realtimeTypeMap: { trade:'0B', orderbook:'0D', broker:'0F', program:'0u', marketStatus:'0m', vi:'0w' },
    realtimeTypeLabels: { trade:'주식체결(0B)', orderbook:'주식호가잔량(0D)', broker:'주식당일거래원(0F)', program:'종목프로그램매매(0u)', marketStatus:'장시작시간(0m)', vi:'VI발동/해제(0w)' },
    scoutRealtimeTypes: state.connection.scoutRealtimeTypes || ['0B','0D','0F','0u'],
    latencyPolicy: { backendTradeEvalMs: Number(process.env.REALTIME_TRADE_EVAL_MIN_MS || 40), backendAuxEvalMs: Number(process.env.REALTIME_AUX_EVAL_MIN_MS || 80), ssePerStockMs: 100, uiFlushMs: 100, watchdogMs: Number(process.env.KIWOOM_WATCHDOG_INTERVAL_MS || 1000), noTradeRecoveryMs: Number(process.env.KIWOOM_VENUE_NO_TRADE_RECOVERY_MS || 8000), hardReconnectMs: Number(process.env.KIWOOM_VENUE_HARD_RECOVERY_MS || 18000) },
    preIgnitionPolicy: { purpose:'BEFORE_SURGE_NOT_AFTER_SURGE', liveMarketDataOnly:true, lateChaseBlocked:true, newsRole:'DISCOVERY_ONLY' },
    restPolicy: {
      periodicFullSnapshot: false, staleFallbackOnly: false, fallbackDiagnosticOnly: true, intradayRestDiagnosticEnabled: Boolean(state.connection.intradayRestDiagnosticEnabled), activeSessionJudgment: 'WEBSOCKET_ONLY',
      krxCloseSync: '15:32 KST', krxRetries: ['15:34','15:37','15:42','16:00'],
      nxtCloseSync: '20:01 KST', nxtRetries: ['20:03','20:06','20:12','20:20'],
      retryScope: 'FAILED_SYMBOLS_ONLY', restartCatchup: true, closeBuyRequiresOfficialKrxClose: true,
      closeSyncCoalescing: true, startupCloseCatchup: true, closeSnapshotFreshnessGate: 'EXPECTED_OFFICIAL_CLOSE_DATE_ONLY', nxtFinalFastPath: 'WEBSOCKET_THEN_REST', nxtFinalRestScope: 'CLOSE_ONLY', foreignDetailFallbackOnly: true,
    },
    restMetrics: { total: rest.total, startedAt: rest.startedAt, lastAt: rest.lastAt, minGapMs: rest.minGapMs, byApi: rest.byApi },
    sseClients: state.sseClients || 0,
    serverTime: new Date().toISOString(),
  };
  if (isAuthenticated(req)) {
    payload.load = {
      eventLoop: load.eventLoop,
      store: { ...load.store, backend: store.usingRedis ? 'redis' : store.usingLocalFile ? 'local-sharded' : 'memory', keyCount: store.keyCount, queueLength: store.queueLength, pendingKeys: store.pendingKeys },
      alerts: load.alerts,
      postProcess: load.postProcess,
      realtime: load.realtime,
      memory: load.memory,
    };
  }
  res.status(200).json(payload);
};
