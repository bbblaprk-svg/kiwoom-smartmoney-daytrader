import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, AlertTriangle, Bell, BookOpen, CheckCircle2, ChevronDown, CircleDollarSign,
  Gauge, LockKeyhole, Plus, RefreshCw, Settings, ShieldAlert, Trash2, TrendingDown,
  TrendingUp, Wifi, WifiOff, X,
} from 'lucide-react';

const EMPTY = {
  connection: { status: 'idle' }, stocks: [], positions: [], alerts: [], risk: {}, settings: {}, watchlist: [], performance: {},
};

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `요청 실패 ${response.status}`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
function fmt(value, digits = 0) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? number.toLocaleString('ko-KR', { maximumFractionDigits: digits }) : '-';
}
function fmtWon(value) {
  const number = Number(value || 0);
  const absolute = Math.abs(number);
  if (absolute >= 100_000_000) return `${(number / 100_000_000).toFixed(1)}억`;
  if (absolute >= 10_000) return `${(number / 10_000).toFixed(0)}만`;
  return fmt(number);
}
function timeAgo(timestamp) {
  if (!timestamp) return '-';
  const seconds = Math.max(0, (Date.now() - Number(timestamp)) / 1000);
  if (seconds < 1) return '방금';
  if (seconds < 60) return `${seconds.toFixed(0)}초 전`;
  return `${(seconds / 60).toFixed(0)}분 전`;
}
function tone(value) { return Number(value) > 0 ? 'text-[#ff6b6b]' : Number(value) < 0 ? 'text-[#4ea1ff]' : 'text-[#d5dde5]'; }
function signalTone(action) {
  if (action === 'BUY') return 'border-[#1c6b46] bg-[#10271d] text-[#55e39a]';
  if (action === 'SELL') return 'border-[#7a2732] bg-[#311219] text-[#ff7b87]';
  if (action === 'EARLY') return 'border-[#6a571b] bg-[#2a240f] text-[#f1cf62]';
  if (action === 'BLOCKED') return 'border-[#665218] bg-[#2d2610] text-[#f6d365]';
  return 'border-[#29323d] bg-[#111820] text-[#93a4b5]';
}
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  return Uint8Array.from([...rawData].map((char) => char.charCodeAt(0)));
}
function beep(action = 'BUY') {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = action === 'SELL' ? 420 : 820;
    gain.gain.value = 0.06;
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.22);
  } catch (_) {}
}

export default function Home() {
  const [data, setData] = useState(EMPTY);
  const [tab, setTab] = useState('live');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [auth, setAuth] = useState({ checked: false, required: false, authenticated: false });
  const [token, setToken] = useState('');
  const [pushStatus, setPushStatus] = useState('');
  const lastAlertId = useRef(null);
  const liveSignalRef = useRef(new Map());

  const refresh = async (quiet = false) => {
    try {
      const next = await api('/api/dashboard');
      setData(next);
      setError('');
      if (!quiet) setLoading(false);
      const newest = next.alerts && next.alerts[0];
      if (newest && lastAlertId.current && newest.id !== lastAlertId.current) {
        beep(newest.action);
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          new Notification(`${newest.name || newest.code || '종목'} ${newest.action || '알림'}`, { body: newest.message });
        }
      }
      if (newest) lastAlertId.current = newest.id;
    } catch (err) {
      if (err.status === 401) setAuth((prev) => ({ ...prev, required: true, authenticated: false, checked: true }));
      else setError(err.message);
      if (!quiet) setLoading(false);
    }
  };

  useEffect(() => {
    api('/api/auth/check').then((result) => {
      setAuth({ checked: true, required: result.authRequired, authenticated: result.authenticated });
      if (result.authenticated) refresh(); else setLoading(false);
    }).catch((err) => { setError(err.message); setLoading(false); });
  }, []);

  useEffect(() => {
    if (!auth.authenticated) return undefined;
    const timer = setInterval(() => refresh(true), 30_000);
    const source = new EventSource('/api/events');
    source.onmessage = (event) => {
      let payload;
      try { payload = JSON.parse(event.data); } catch (_) { return; }
      if (payload.type === 'stock' && payload.stock) {
        const nextStock = payload.stock;
        const isEarly = nextStock.signal?.action === 'EARLY' && nextStock.signal?.smartMoneyState === 'TURN';
        const signalKey = nextStock.signal?.confirmed ? `${nextStock.signal.action}:${nextStock.signal.smartMoneyState}` : isEarly ? `EARLY:${nextStock.signal.smartMoneyState}` : 'NONE';
        const previousKey = liveSignalRef.current.get(nextStock.code) || 'NONE';
        if (signalKey !== 'NONE' && signalKey !== previousKey) {
          beep(nextStock.signal.action === 'SELL' ? 'SELL' : 'BUY');
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(`${nextStock.name} ${nextStock.signal.label}`, { body: `품질 ${nextStock.signal.qualityScore || 0}점 · ${fmt(nextStock.price)}원` });
          }
        }
        liveSignalRef.current.set(nextStock.code, signalKey);
        setData((prev) => ({
          ...prev,
          stocks: [...(prev.stocks || []).filter((stock) => stock.code !== nextStock.code), nextStock],
          connection: payload.connection || prev.connection,
        }));
      } else if (payload.type === 'connection' && payload.connection) {
        setData((prev) => ({ ...prev, connection: payload.connection }));
      }
    };
    source.onerror = () => setError('실시간 화면 연결 재시도 중');
    source.onopen = () => setError('');
    return () => { clearInterval(timer); source.close(); };
  }, [auth.authenticated]);

  const login = async (event) => {
    event.preventDefault();
    try {
      await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ token }) });
      setAuth({ checked: true, required: true, authenticated: true });
      setToken('');
      setLoading(true);
      await refresh();
    } catch (err) { setError(err.message); }
  };

  const enableNotifications = async () => {
    try {
      if (typeof Notification === 'undefined') throw new Error('이 브라우저는 알림 API를 지원하지 않습니다.');
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') throw new Error('아이폰 알림 권한이 허용되지 않았습니다.');
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.register('/sw.js');
        const keyInfo = await api('/api/push/public-key');
        if (keyInfo.enabled && keyInfo.publicKey) {
          const subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(keyInfo.publicKey) });
          await api('/api/push/subscribe', { method: 'POST', body: JSON.stringify(subscription) });
          setPushStatus('앱을 닫아도 푸시 알림 수신');
        } else {
          setPushStatus('앱이 열린 동안 브라우저 알림 수신 · VAPID 설정 시 종료 후 푸시 가능');
        }
      }
    } catch (err) { setPushStatus(err.message); }
  };

  if (!auth.checked || loading) return <Center><RefreshCw className="animate-spin" size={22} /> 데이터 준비 중</Center>;
  if (auth.required && !auth.authenticated) {
    return (
      <Center>
        <form onSubmit={login} className="w-full max-w-sm border border-[#26303b] bg-[#0d131a] rounded-2xl p-6 space-y-4">
          <LockKeyhole className="text-[#f5a623]" />
          <div><h1 className="font-bold text-lg">단타 앱 로그인</h1><p className="text-xs text-[#8190a0] mt-1">서버 환경변수 APP_ACCESS_TOKEN 값을 입력하세요.</p></div>
          <input className="input" type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="접근 암호" autoFocus />
          {error && <div className="text-xs text-[#ff7b87]">{error}</div>}
          <button className="primary-btn w-full" type="submit">로그인</button>
        </form>
      </Center>
    );
  }

  const connected = data.connection && data.connection.status === 'connected';
  const tabs = [
    ['live', Activity, '실시간'], ['watch', Plus, '종목관리'], ['journal', BookOpen, '매매일지'], ['alerts', Bell, '알림'], ['settings', Settings, '설정'],
  ];

  return (
    <div className="min-h-screen bg-[#080b0f] text-[#e6edf3]">
      <header className="sticky top-0 z-30 bg-[#0b1016]/95 backdrop-blur border-b border-[#202832]">
        <div className="max-w-6xl mx-auto px-3 py-3 flex items-start justify-between gap-3">
          <div>
            <div className="text-[10px] tracking-[0.22em] text-[#738191]">KIWOOM REALTIME DAY TRADER · READ ONLY</div>
            <h1 className="font-bold text-base mt-0.5">KRX·NXT 실시간 단타 신호</h1>
            <div className="text-[11px] text-[#7e8c99] mt-1">고정 4 + 집중입력 4 + 경량입력 4 · SSE 즉시전달 · 스마트머니 상태추적</div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[11px] ${connected ? 'border-[#1d563b] bg-[#102319] text-[#55e39a]' : 'border-[#67303a] bg-[#2b1218] text-[#ff7b87]'}`}>
              {connected ? <Wifi size={12} /> : <WifiOff size={12} />}{data.connection?.status || 'idle'}
            </div>
            <div className="text-[10px] text-[#697786]">수신 {data.connection?.lastMessageAt ? new Date(data.connection.lastMessageAt).toLocaleTimeString('ko-KR') : '-'}</div>{data.connection?.marketStatus?.label && <div className="text-[10px] text-[#8b98a5]">{data.connection.marketStatus.label}</div>}
          </div>
        </div>
        {data.risk?.halted && <div className="bg-[#351119] text-[#ff8995] border-t border-[#6b2632] px-3 py-2 text-xs"><ShieldAlert size={13} className="inline mr-1" />신규매수 차단: {data.risk.reasons.join(' · ')} · 매도/청산은 항상 허용</div>}
        {error && <div className="bg-[#30270f] text-[#f2d36b] border-t border-[#5c4c1e] px-3 py-2 text-xs">{error}</div>}
      </header>

      <nav className="sticky top-[88px] z-20 bg-[#0b1016] border-b border-[#202832] overflow-x-auto">
        <div className="max-w-6xl mx-auto px-2 flex">
          {tabs.map(([id, Icon, label]) => <button key={id} onClick={() => setTab(id)} className={`nav-btn ${tab === id ? 'active' : ''}`}><Icon size={14} />{label}</button>)}
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-3 py-4 pb-24">
        {tab === 'live' && <LiveTab data={data} onNotify={enableNotifications} pushStatus={pushStatus} refresh={() => refresh()} />}
        {tab === 'watch' && <WatchlistTab data={data} onChanged={() => refresh()} />}
        {tab === 'journal' && <JournalTab data={data} onChanged={() => refresh()} />}
        {tab === 'alerts' && <AlertsTab alerts={data.alerts || []} />}
        {tab === 'settings' && <SettingsTab settings={data.settings || {}} onSaved={() => refresh()} />}
      </main>
    </div>
  );
}

function Center({ children }) { return <div className="min-h-screen bg-[#080b0f] text-[#dce5ed] flex items-center justify-center gap-2 p-5">{children}</div>; }

function LiveTab({ data, onNotify, pushStatus, refresh }) {
  const stocks = data.stocks || [];
  const ordered = useMemo(() => [...stocks].sort((a, b) => {
    const rank = (s) => s.signal?.confirmed ? (s.signal.action === 'BUY' ? 0 : 1) : s.signal?.action === 'EARLY' ? 2 : 3;
    return rank(a) - rank(b) || Number(b.signal?.qualityScore || 0) - Number(a.signal?.qualityScore || 0);
  }), [stocks]);
  const buys = stocks.filter((s) => s.signal?.confirmed && s.signal.action === 'BUY').length;
  const sells = stocks.filter((s) => s.signal?.confirmed && s.signal.action === 'SELL').length;
  const fresh = stocks.filter((s) => Date.now() - Number(s.updatedAt || 0) < 2500).length;
  const promoted = stocks.filter((s) => s.tier === 'LIGHT' && s.activeTier === 'FOCUS').length;
  const perf = data.performance?.quality85Plus || {};
  const winRate = perf.winRate == null ? '-' : `${Number(perf.winRate).toFixed(1)}%`;

  return <div className="space-y-4">
    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
      <Summary label="실시간 수신" value={`${fresh}/${stocks.length}`} icon={Wifi} />
      <Summary label="확정 매수" value={buys} icon={TrendingUp} positive />
      <Summary label="매도·청산" value={sells} icon={TrendingDown} negative />
      <Summary label="자동승격" value={promoted} icon={Activity} />
      <Summary label="85점+ 실증승률" value={`${winRate} · n=${perf.sampleSize || 0}`} icon={Gauge} />
    </div>
    <div className="flex flex-wrap gap-2 items-center">
      <button className="secondary-btn" onClick={onNotify}><Bell size={14} />알림 켜기</button>
      <button className="secondary-btn" onClick={refresh}><RefreshCw size={14} />전체 동기화</button>
      <span className="text-[11px] text-[#7e8c99]">{pushStatus || '앱 열린 상태는 SSE 즉시알림 · 종료 후 Web Push 보조'}</span>
    </div>
    <Notice icon={AlertTriangle}>품질점수 85는 적중확률 85%가 아닙니다. 실증승률은 15분 내 +1R/-1R 선도달 결과를 200건 이상 축적한 뒤 판정합니다.</Notice>
    {!data.connection?.lastMessageAt && <Notice icon={AlertTriangle}>키움 실시간 수신 전입니다. 환경변수 등록 후 장중 데이터가 들어오면 지표가 채워집니다.</Notice>}
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
      {ordered.map((stock) => <StockCard key={stock.code} stock={stock} settings={data.settings || {}} risk={data.risk || {}} />)}
    </div>
  </div>;
}
function Summary({ label, value, icon: Icon, positive, negative, valueClass = '' }) {
  return <div className="panel p-3"><div className="flex items-center gap-1.5 text-[11px] text-[#7e8c99]"><Icon size={13} />{label}</div><div className={`text-xl font-bold mt-1 ${positive ? 'text-[#55e39a]' : negative ? 'text-[#ff7b87]' : valueClass}`}>{value}</div></div>;
}
function Notice({ icon: Icon, children }) { return <div className="border border-[#5a4818] bg-[#29220f] text-[#efd36c] rounded-xl px-3 py-2 text-xs"><Icon size={13} className="inline mr-1" />{children}</div>; }

function StockCard({ stock, settings, risk }) {
  const signal = stock.signal || {};
  const metrics = signal.metrics || {};
  const age = timeAgo(stock.updatedAt);
  const priceFresh = Date.now() - Number(stock.updatedAt || 0) < 2500;
  const action = signal.confirmed ? signal.action : signal.action === 'EARLY' ? 'EARLY' : signal.action === 'BUY' || signal.action === 'SELL' ? 'WAIT' : signal.action;
  const plan = signal.plan;
  const riskBudget = Math.max(0, Number(settings.accountEquity || 0) * Number(settings.maxRiskPerTradePct || 0) / 100);
  const riskPerShare = plan ? Math.max(1, Number(plan.entry || 0) - Number(plan.stop || 0)) : 0;
  const riskQty = riskPerShare > 0 ? Math.floor(riskBudget / riskPerShare) : 0;
  const capitalQty = plan && Number(plan.entry) > 0 ? Math.floor(Number(settings.accountEquity || 0) * Number(settings.maxPositionPct || 33) / 100 / Number(plan.entry)) : 0;
  const suggestedQty = Math.max(0, Math.min(riskQty || 0, capitalQty || riskQty || 0));
  const feedAges = stock.feeds || {};
  const tierLabel = stock.activeTier === 'FOCUS' ? (stock.tier === 'LIGHT' ? '자동승격' : '집중') : '경량';
  const confirmText = signal.confirmed ? '확정 신호' : signal.action === 'EARLY' ? '조기관찰' : `체결확인 ${signal.confirmCount || 0}/${signal.requiredConfirmations || 3}`;
  return <section className={`panel overflow-hidden ${signal.confirmed && signal.action === 'BUY' ? 'ring-1 ring-[#2e8b5e]' : signal.confirmed && signal.action === 'SELL' ? 'ring-1 ring-[#98404b]' : ''}`}>
    <div className="p-3 border-b border-[#202832] flex items-start justify-between gap-2">
      <div>
        <div className="flex items-center gap-2"><span className="font-bold">{stock.name}</span><span className="text-[10px] text-[#728091]">{stock.code} · {stock.marketMode}</span><span className="badge">{tierLabel}</span>{stock.vi?.active && <span className="badge-danger">VI</span>}</div>
        <div className="flex items-baseline gap-2 mt-1"><span className="text-2xl font-black">{stock.price ? fmt(stock.price) : '-'}</span><span className={`text-sm font-bold ${tone(stock.changePct)}`}>{Number(stock.changePct || 0) > 0 ? '+' : ''}{Number(stock.changePct || 0).toFixed(2)}%</span><span className={`text-[10px] ${priceFresh ? 'text-[#55e39a]' : 'text-[#ff7b87]'}`}>{age}</span></div>
      </div>
      <div className={`border rounded-lg px-2.5 py-1.5 text-center min-w-[108px] ${signalTone(action)}`}>
        <div className="text-[10px]">{confirmText}</div><div className="font-bold text-sm">{signal.label || '수신대기'}</div>
      </div>
    </div>
    <div className="p-3">
      <div className="grid grid-cols-3 gap-2">
        <Metric label="품질점수" value={`${signal.qualityScore || 0}`} accent="up" />
        <Metric label="데이터 완전성" value={`${Number(signal.dataCompleteness || 0).toFixed(0)}%`} />
        <Metric label="스마트머니" value={signal.smartMoneyState || stock.smartMoney?.state || '-'} />
        <Metric label="체결강도" value={metrics.tradeStrength ? `${fmt(metrics.tradeStrength)}%` : '-'} />
        <Metric label="5초 순공격대금" value={fmtWon(metrics.netBuyAmount5s)} valueClass={tone(metrics.netBuyAmount5s)} />
        <Metric label="매수 가속도" value={fmtWon(metrics.buyAcceleration)} valueClass={tone(metrics.buyAcceleration)} />
        <Metric label="1분 거래대금" value={fmtWon(metrics.turnover1m)} />
        <Metric label="1분 RVOL" value={metrics.rvol1m ? `${Number(metrics.rvol1m).toFixed(2)}x` : '-'} />
        <Metric label="공격매수" value={metrics.buyRatio ? `${Number(metrics.buyRatio).toFixed(1)}%` : '-'} />
        <Metric label="VWAP" value={metrics.vwap ? fmt(metrics.vwap) : '-'} />
        <Metric label="호가 불균형" value={metrics.orderbookImbalance ? Number(metrics.orderbookImbalance).toFixed(2) : '-'} />
        <Metric label="프로그램 10초" value={fmtWon(metrics.programVelocity10s)} valueClass={tone(metrics.programVelocity10s)} />
        <Metric label="대형체결 순매수" value={fmtWon(metrics.largeNetAmount1m)} valueClass={tone(metrics.largeNetAmount1m)} />
        <Metric label="외국계 변화" value={fmt(stock.broker?.foreignNetDelta)} valueClass={tone(stock.broker?.foreignNetDelta)} />
        <Metric label="스프레드" value={metrics.spreadBps && metrics.spreadBps < 9000 ? `${Number(metrics.spreadBps).toFixed(1)}bp` : '-'} />
      </div>
      <div className="mt-3 space-y-1">
        {(signal.reasons || []).slice(0, 4).map((reason, index) => <div key={`r${index}`} className="text-[11px] text-[#72d9a5]"><CheckCircle2 size={11} className="inline mr-1" />{reason}</div>)}
        {(signal.warnings || []).slice(0, 3).map((reason, index) => <div key={`w${index}`} className="text-[11px] text-[#e5c45c]"><AlertTriangle size={11} className="inline mr-1" />{reason}</div>)}
        {(signal.vetoes || []).slice(0, 3).map((reason, index) => <div key={`v${index}`} className="text-[11px] text-[#ff7b87]"><X size={11} className="inline mr-1" />{reason}</div>)}
      </div>
      <div className="mt-3 pt-2 border-t border-[#18212a] text-[10px] text-[#718091] flex flex-wrap gap-x-3 gap-y-1"><span>체결 {timeAgo(feedAges.tradeAt)}</span><span>호가 {timeAgo(feedAges.orderbookAt)}</span><span>프로그램 {timeAgo(feedAges.programAt)}</span><span>거래원 {timeAgo(feedAges.brokerAt)}</span><span>실제시장 {stock.market || '-'}</span>{stock.tier === 'LIGHT' && <span>승격점수 {stock.promotionScore || 0}</span>}</div>
      {plan && <details className="mt-3 text-xs"><summary className="cursor-pointer text-[#8ea0b2] flex items-center gap-1"><ChevronDown size={13} />신호 발생 시 위험계획</summary><div className="grid grid-cols-4 gap-1 mt-2"><Plan label="손절" value={fmt(plan.stop)} /><Plan label="1R" value={fmt(plan.target1)} /><Plan label="1.7R" value={fmt(plan.target2)} /><Plan label="2.5R" value={fmt(plan.target3)} /></div><div className={`mt-2 rounded-lg border px-2.5 py-2 ${risk.halted ? 'border-[#6f2934] bg-[#2a1218] text-[#ff8d97]' : 'border-[#274535] bg-[#102019] text-[#75d9a8]'}`}>{risk.halted ? '계좌 손실 제한으로 신규매수 차단' : `권장 최대 ${fmt(suggestedQty)}주 · 1회 위험예산 ${fmt(riskBudget)}원`}</div></details>}
    </div>
  </section>;
}
function Metric({ label, value, accent, valueClass = '' }) { return <div className="metric"><div>{label}</div><strong className={`${accent === 'up' ? 'text-[#55e39a]' : accent === 'down' ? 'text-[#ff7b87]' : ''} ${valueClass}`}>{value}</strong></div>; }
function Plan({ label, value }) { return <div className="bg-[#0b1117] rounded-md p-1.5 text-center"><div className="text-[9px] text-[#718091]">{label}</div><div className="font-mono mt-0.5">{value}</div></div>; }

function WatchlistTab({ data, onChanged }) {
  const [form, setForm] = useState({ code: '', name: '', market: 'SOR', tier: 'FOCUS' });
  const [message, setMessage] = useState('');
  const submit = async (event) => {
    event.preventDefault();
    try {
      await api('/api/watchlist', { method: 'POST', body: JSON.stringify(form) });
      setForm({ code: '', name: '', market: 'SOR', tier: 'FOCUS' });
      setMessage('등록했습니다. 집중/경량 구독은 30초 이내 갱신됩니다.');
      onChanged();
    } catch (err) { setMessage(err.message); }
  };
  const remove = async (code) => {
    try { await api(`/api/watchlist?code=${code}`, { method: 'DELETE' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const counts = data.watchCounts || { focus: 0, light: 0 };
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><Plus size={16} />종목 추가</h2>
      <p className="help">집중입력 4개는 체결·10호가·거래원·프로그램을 모두 수신합니다. 경량입력 4개는 체결만 감시하다 급증 조건 충족 시 자동승격됩니다.</p>
      <div className="text-xs text-[#8b98a5] mt-2">집중 {counts.focus || 0}/4 · 경량 {counts.light || 0}/4</div>
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-5 gap-2 mt-3">
        <input className="input" inputMode="numeric" maxLength={6} placeholder="6자리 종목코드" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.replace(/\D/g, '').slice(0, 6) })} />
        <input className="input" placeholder="종목명" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <select className="input" value={form.market} onChange={(e) => setForm({ ...form, market: e.target.value })}><option value="SOR">SOR 통합</option><option value="KRX">KRX만</option><option value="NXT">NXT만</option></select>
        <select className="input" value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })}><option value="FOCUS">집중입력</option><option value="LIGHT">경량입력</option></select>
        <button className="primary-btn" type="submit"><Plus size={14} />등록</button>
      </form>{message && <div className="text-xs text-[#d6bd65] mt-2">{message}</div>}
    </section>
    <section className="panel overflow-hidden"><div className="p-3 border-b border-[#202832] text-xs text-[#8190a0]">현재 감시 {data.watchlist?.length || 0}종목</div>{(data.watchlist || []).map((stock) => <div key={stock.code} className="px-3 py-3 border-b border-[#18212a] last:border-0 flex justify-between items-center"><div><strong>{stock.name}</strong><span className="ml-2 text-xs text-[#708091]">{stock.code} · {stock.market}</span><span className="ml-2 badge">{stock.fixed ? '고정집중' : stock.tier === 'LIGHT' ? '경량' : '집중'}</span></div>{!stock.fixed && <button className="icon-btn" onClick={() => remove(stock.code)} aria-label="삭제"><Trash2 size={15} /></button>}</div>)}</section>
  </div>;
}
function JournalTab({ data, onChanged }) {
  const [form, setForm] = useState({ code: data.watchlist?.[0]?.code || '', avgPrice: '', quantity: '', initialStopPrice: '', memo: '' });
  const [message, setMessage] = useState('');
  const open = async (event) => {
    event.preventDefault();
    try { const result = await api('/api/positions', { method: 'POST', body: JSON.stringify(form) }); setMessage(result.riskWarning || '포지션을 기록했습니다.'); setForm({ ...form, avgPrice: '', quantity: '', initialStopPrice: '', memo: '' }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const close = async (position) => {
    const current = data.stocks?.find((s) => s.code === position.code)?.price || position.avgPrice;
    const exitText = window.prompt('매도 체결가를 입력하세요.', String(current || ''));
    if (!exitText) return;
    const exitPrice = Number(exitText);
    try { await api('/api/positions', { method: 'PUT', body: JSON.stringify({ id: position.id, status: 'closed', exitPrice, exitTime: new Date().toISOString() }) }); onChanged(); } catch (err) { setMessage(err.message); }
  };
  const positions = data.positions || [];
  return <div className="space-y-4">
    <section className="panel p-4"><h2 className="section-title"><BookOpen size={16} />수동 체결 기록</h2><p className="help">실제 주문을 전송하지 않습니다. 키움 주문 연동 전까지 체결 후 기록용이며, 서버가 손절·목표가를 실시간 감시합니다.</p>
      <form onSubmit={open} className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-3"><select className="input" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })}>{(data.watchlist || []).map((s) => <option key={s.code} value={s.code}>{s.name}</option>)}</select><input className="input" inputMode="decimal" placeholder="매수가" value={form.avgPrice} onChange={(e) => setForm({ ...form, avgPrice: e.target.value })} /><input className="input" inputMode="numeric" placeholder="수량" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /><input className="input" inputMode="decimal" placeholder="최초 손절가(선택)" value={form.initialStopPrice} onChange={(e) => setForm({ ...form, initialStopPrice: e.target.value })} /><button className="primary-btn" type="submit">매수 기록</button></form>{message && <div className="text-xs text-[#e0c563] mt-2">{message}</div>}
    </section>
    <section className="space-y-2">{positions.length === 0 && <div className="empty">매매 기록이 없습니다.</div>}{positions.map((p) => { const live = data.stocks?.find((s) => s.code === p.code); const pnl = p.status === 'closed' ? p.realizedPnl : live?.price ? (live.price - p.avgPrice) * p.quantity : 0; return <div className="panel p-3 flex items-center justify-between gap-3" key={p.id}><div><div className="font-bold">{live?.name || p.code} <span className="text-[10px] text-[#718091]">{p.status === 'closed' ? '청산' : '보유'}</span></div><div className="text-xs text-[#8493a2] mt-1">매수 {fmt(p.avgPrice)}원 × {fmt(p.quantity)}주 · 수정손절 {p.currentStopPrice ? fmt(p.currentStopPrice) : '-'}</div><div className={`text-sm font-bold mt-1 ${tone(pnl)}`}>{pnl >= 0 ? '+' : ''}{fmt(pnl)}원</div></div>{p.status !== 'closed' && <button className="danger-btn" onClick={() => close(p)}>매도 완료 기록</button>}</div>; })}</section>
  </div>;
}

function AlertsTab({ alerts }) { return <div className="space-y-2">{alerts.length === 0 && <div className="empty">아직 알림이 없습니다.</div>}{alerts.map((a) => <div key={a.id} className="panel p-3"><div className="flex justify-between gap-2"><div className={`font-bold text-sm ${a.action === 'BUY' ? 'text-[#55e39a]' : a.action === 'SELL' ? 'text-[#ff7b87]' : ''}`}>{a.name || a.code} {a.action || ''}</div><div className="text-[10px] text-[#6f7d8b]">{new Date(a.time).toLocaleString('ko-KR')}</div></div><div className="text-xs mt-1 text-[#d0d9e1]">{a.message}</div></div>)}</div>; }

function SettingsTab({ settings, onSaved }) {
  const [form, setForm] = useState(settings);
  const [message, setMessage] = useState('');
  useEffect(() => setForm(settings), [settings]);
  const set = (key, value) => setForm({ ...form, [key]: Number(value) });
  const setSignal = (key, value) => setForm({ ...form, signal: { ...(form.signal || {}), [key]: Number(value) } });
  const save = async () => { try { await api('/api/settings', { method: 'PUT', body: JSON.stringify(form) }); setMessage('저장했습니다.'); onSaved(); } catch (err) { setMessage(err.message); } };
  return <div className="space-y-4"><section className="panel p-4"><h2 className="section-title"><ShieldAlert size={16} />계좌 위험 제한</h2><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="당일 시작자산" value={form.dayStartingEquity} onChange={(v) => set('dayStartingEquity', v)} /><Field label="일일 최대손실 %" value={form.dailyMaxLossPct} onChange={(v) => set('dailyMaxLossPct', v)} /><Field label="연속손실 제한" value={form.maxConsecutiveLosses} onChange={(v) => set('maxConsecutiveLosses', v)} /><Field label="최대 동시보유" value={form.maxConcurrentPositions} onChange={(v) => set('maxConcurrentPositions', v)} /><Field label="1회 위험예산 %" value={form.maxRiskPerTradePct} onChange={(v) => set('maxRiskPerTradePct', v)} /><Field label="종목당 자금상한 %" value={form.maxPositionPct} onChange={(v) => set('maxPositionPct', v)} /><Field label="매수 수수료 %" value={form.buyFeePct} onChange={(v) => set('buyFeePct', v)} /><Field label="매도 수수료 %" value={form.sellFeePct} onChange={(v) => set('sellFeePct', v)} /><Field label="매도 세금 %" value={form.sellTaxPct} onChange={(v) => set('sellTaxPct', v)} /></div></section>
    <section className="panel p-4"><h2 className="section-title"><Gauge size={16} />실시간 신호 임계값</h2><div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3"><Field label="조기관찰 점수" value={form.signal?.earlyWatchScore} onChange={(v) => setSignal('earlyWatchScore', v)} /><Field label="확정 품질점수" value={form.signal?.minBuyScore} onChange={(v) => setSignal('minBuyScore', v)} /><Field label="강한매수 점수" value={form.signal?.strongBuyScore} onChange={(v) => setSignal('strongBuyScore', v)} /><Field label="데이터 완전성 %" value={form.signal?.minDataCompleteness} onChange={(v) => setSignal('minDataCompleteness', v)} /><Field label="체결 확인 횟수" value={form.signal?.confirmTicks} onChange={(v) => setSignal('confirmTicks', v)} /><Field label="조건 유지 ms" value={form.signal?.confirmHoldMs} onChange={(v) => setSignal('confirmHoldMs', v)} /><Field label="최대 스프레드 bp" value={form.signal?.maxSpreadBps} onChange={(v) => setSignal('maxSpreadBps', v)} /><Field label="최소 체결강도" value={form.signal?.minTradeStrength} onChange={(v) => setSignal('minTradeStrength', v)} /><Field label="최소 1분 거래대금" value={form.signal?.minOneMinuteTurnover} onChange={(v) => setSignal('minOneMinuteTurnover', v)} /><Field label="최소 RVOL" value={form.signal?.minRvol} onChange={(v) => setSignal('minRvol', v)} /><Field label="VWAP 최대이격 %" value={form.signal?.maxVwapExtensionPct} onChange={(v) => setSignal('maxVwapExtensionPct', v)} /><Field label="알림 재발생 초" value={form.signal?.signalCooldownSeconds} onChange={(v) => setSignal('signalCooldownSeconds', v)} /><Field label="승격 15초 거래대금" value={form.signal?.promotionTurnover15s} onChange={(v) => setSignal('promotionTurnover15s', v)} /><Field label="승격 5초 순매수" value={form.signal?.promotionNetBuy5s} onChange={(v) => setSignal('promotionNetBuy5s', v)} /><Field label="승격 유지 초" value={form.signal?.promotionSeconds} onChange={(v) => setSignal('promotionSeconds', v)} /><Field label="동시 자동승격" value={form.signal?.maxPromotedLight} onChange={(v) => setSignal('maxPromotedLight', v)} /></div></section>
    <button className="primary-btn" onClick={save}>설정 저장</button>{message && <span className="text-xs text-[#d8c15f] ml-2">{message}</span>}
  </div>;
}
function Field({ label, value, onChange }) { return <label className="text-xs text-[#8998a7]"><span>{label}</span><input className="input mt-1" type="number" step="any" value={value ?? ''} onChange={(e) => onChange(e.target.value)} /></label>; }
