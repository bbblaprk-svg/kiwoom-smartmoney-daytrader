const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const worker = fs.readFileSync(path.join(root, 'worker/kiwoomRealtime.js'), 'utf8');
const store = fs.readFileSync(path.join(root, 'lib/realtimeStore.js'), 'utf8');
const health = fs.readFileSync(path.join(root, 'pages/api/health.js'), 'utf8');
// Kiwoom official current domestic-stock realtime mapping (verified 2026-08-05):
// 0A executions, 0B best quote, 0C depth, 0D after-hours quote, 0E brokers,
// 0F ETF NAV, 0m market status, 0s ELW indicator, 0u program, 0w VI.
assert(worker.includes("const FOCUS_TYPES = ['0A', '0C', '0E', '0u'];"));
assert(worker.includes("const SCOUT_TYPES = ['0A', '0C', '0u'];"));
assert(worker.includes("const GLOBAL_TYPES = ['0m', '0w'];"));
assert(store.includes("case '0A': return processTrade"));
assert(store.includes("case '0B': {"));
assert(store.includes("case '0C': processOrderbook"));
assert(store.includes("case '0E': processBroker"));
assert(store.includes("case '0u': processProgram"));
assert(store.includes("case '0m':"));
assert(store.includes("case '0w': processVi"));
assert(!store.includes("case '0B': return processTrade"));
assert(!store.includes("case '0D': processOrderbook"));
assert(!store.includes("case '0F': processBroker"));
assert(!store.includes("case '0w': processProgram"));
assert(!store.includes("case '0s':\n      state.connection.marketStatus"));
assert(!store.includes("case '1h': processVi"));
for (const marker of ["trade:'0A'","bestQuote:'0B'","orderbook:'0C'","broker:'0E'","program:'0u'","marketStatus:'0m'","vi:'0w'"]) assert(health.includes(marker), marker);
assert(worker.includes("`${base}_NX`"));
assert(store.includes("code.endsWith('_NX')"));
assert(store.includes('SESSION_SINGLE_VENUE'));
assert(store.includes('AMBIGUOUS_REALTIME_ROUTE'));
console.log('OFFICIAL_REALTIME_ROUTE_CHECK PASS: current official mapping + NXT fail-closed');
