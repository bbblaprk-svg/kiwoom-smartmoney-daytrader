# Kiwoom Unified Edge Trader v3.2.16 — PRE-IGNITION VERIFIED REALTIME CORE

## 목적
이 앱의 장중 목적은 **이미 급등한 종목을 따라가는 것이 아니라, 급등 전에 체결·호가·프로그램 수급이 동시에 강화되는 종목을 사전 포착**하는 것입니다. 뉴스는 후보 발굴과 섹터 맥락에만 쓰고, EARLY/PRE-BUY/BUY의 동적 판단은 Kiwoom WebSocket 실시간 데이터만 사용합니다.

## 1. Kiwoom 공식 실시간 라우트 — 가장 중요한 수정
공식 국내주식 WebSocket 실시간 타입에 맞춰 다음처럼 고정했습니다.

- `0A` = 주식체결 → **실시간 현재가와 tape 판단의 유일한 원천**
- `0B` = 주식우선호가 → 보조 최우선호가
- `0C` = 주식호가잔량 → orderbook imbalance/replenishment/withdrawal
- `0E` = 주식당일거래원 → FOCUS 보조증거
- `0u` = 종목프로그램매매 → 프로그램 방향·가속·전환
- `0m` = 장시작시간 → 장 전환 즉시 REG 복구
- `0w` = VI발동/해제

이전 버전에서 0B를 체결, 0D를 호가잔량처럼 취급할 수 있던 위험을 제거했습니다. `0D`는 주식시간외호가이므로 정규 실시간 orderbook 판단에 사용하지 않습니다.

## 2. 장중 current price = WebSocket 0A ONLY
활성 KRX/NXT 세션에서는 `currentPrice`를 다음 조건을 모두 만족할 때만 제공합니다.

1. 오늘 수신된 Kiwoom `0A` 체결
2. 현재 활성 거래소와 라우팅 일치
3. 표시 freshness 10초 이내
4. 신규진입 판단 freshness 2초 이내

조건이 깨지면 전일종가, 종가 스냅샷, REST 현재가, ledger 마지막 가격을 현재가처럼 대체하지 않습니다. 화면은 `실시간 시세 미수신`으로 표시하고 신규 EARLY/PRE-BUY/BUY를 차단합니다.

## 3. NXT 라우팅
- 등록 코드: NXT는 `_NX`, KRX는 기본 6자리 코드로 분리 등록합니다.
- 실시간 payload에 거래소 FID가 있으면 이를 최우선 사용합니다.
- `_NX` suffix가 있으면 NXT로 확정합니다.
- 08:00~08:50처럼 NXT만 열려 있고 payload가 bare code로 오는 경우 `SESSION_SINGLE_VENUE=NXT`로 안전하게 복원합니다.
- KRX/NXT 동시 거래시간인데 출처가 없는 bare code는 임의 추측하지 않고 `UNKNOWN`으로 두어 신규판정을 차단합니다.

## 4. 전 30종목 WebSocket Scout
후보 30종목 모두 다음 실시간을 구독합니다.

- 0A 체결
- 0C 호가잔량
- 0u 프로그램매매

FOCUS/승격 종목에는 0E 거래원까지 추가합니다. 따라서 급등 이후 FOCUS로 바뀐 뒤에야 호가를 받는 구조가 아니라, **30종목 전체에서 점화 전 미세변화를 선행 감지**할 수 있습니다.

## 5. PRE-IGNITION 엔진
독립적인 4개 축을 사용합니다.

- Tape: 5초 공격매수 가속, 순매수 증가, 체결강도, 매수비율
- Book: 호가 imbalance 변화, bid replenishment, ask withdrawal, 지지 지속
- Flow: 프로그램 순매수 속도, 음→양 전환, 순매수 확대
- Structure: VWAP 인접, 최근고점 근접이나 과열 전, 15초 momentum, turnover acceleration, 적정 RVOL

기본 PRE-IGNITION 요건은 score 62+, 독립축 3개+, fresh 0A/0C, fresh 0w 또는 매우 강한 tape입니다. 스마트머니 상태는 파생 보너스이지 같은 원천을 독립증거로 중복 계산하지 않습니다.

### 추격 방지
- 당일 등락률 `+4.5%` 이상: PRE-IGNITION 자격 차단
- 당일 등락률 `+6.0%` 이상: 신규진입 hard chase block
- VWAP 과도 이격/1분 momentum 과열도 별도 차단

즉 이미 +10% 급등한 종목을 높은 점수로 BUY시키는 것이 목적이 아닙니다.

## 6. 앱 내부 지연 최소화
기본 정책:

- trade 평가: 40ms
- aux(orderbook/program) 평가: 80ms
- SSE 종목별 coalescing: 100ms
- UI flush: 100ms
- watchdog: 1초

WebSocket 모든 틱은 상태에 반영하고, 고비용 신호 계산만 종목별 최신상태 병합으로 CPU burst를 막습니다. 네트워크·거래소 자체 지연을 0으로 만들 수는 없지만 앱 내부의 불필요한 REST polling과 1초 UI 지연은 제거했습니다.

## 7. 소켓 복구
- 활성 거래소에서 8초간 fresh 0A가 전 종목 0이면 기존 등록을 지우지 않고 REG 재등록
- 그래도 18초까지 0A가 없으면 socket hard reconnect
- 장 시작 이벤트(`0s`) 수신 후 0.1s / 1.5s / 4s에 non-destructive REG 재확인
- REST 현재가는 장애 시에도 장중 매수판정 대체값으로 사용하지 않습니다.

## 8. News Radar v1.5.6
ROTATION PICKS, 3일/5일 섹터 회전, 글로벌 선행뉴스, 반도체 편중제어를 유지합니다. 단 뉴스는 `DISCOVERY_ONLY`입니다.

- 뉴스 점수는 어떤 종목을 30종목 실시간 감시군에 넣을지 결정하는 데 사용
- 뉴스만으로 EARLY/PRE-BUY/BUY 생성 금지
- sector forecast의 국내 동적값도 trader의 fresh 0A 기반 실시간 데이터만 사용
- 실시간 표본 부족 시 종가/REST로 채우지 않고 판단 보류

## 9. 종가·학습
일봉/공식 종가/기관·외인 REST는 과거기준, 종가판정, 성과학습에만 사용합니다. KRX 15:32, NXT 20:01 이후 종가 동기화와 실패종목 재시도를 유지합니다. 종가 스마트머니 감사 구간에는 30종목의 WebSocket 정밀피드를 보존합니다.

## 10. 검사
- `npm run check`: 전체 회귀 + 공식 실시간 route + realtime truth + latency + pre-ignition
- `npm run check:load`: 30종목 / 12,000 합성 실시간 이벤트 부하검사
- Dockerfile은 SOURCE_MANIFEST → npm install → 전체 check → 30,000 load → next build를 모두 통과해야 배포 이미지가 생성됩니다.

합성 검사는 소프트웨어 로직/병목 회귀검사이며 실제 Kiwoom 회선 지연이나 투자 승률을 보장하지 않습니다. 실제 배포 스크립트는 활성 장이면 fresh 0A가 확인되지 않을 경우 새 버전을 성공 처리하지 않고 롤백하도록 설계합니다.
