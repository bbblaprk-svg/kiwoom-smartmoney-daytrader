# v3.2.16 Validation Report

## 목적
- 활성 KRX/NXT 판단은 Kiwoom WebSocket 실시간 데이터만 사용
- 급등 후 추격보다 급등 전 PRE-IGNITION 탐지 우선
- REST/종가/뉴스는 장중 currentPrice와 신규진입 판단을 대체하지 않음

## 재검증에서 발견·수정한 핵심
이전 후보판의 실시간 타입 매핑 일부가 2026-08-05 현재 Kiwoom 공식 가이드와 불일치했다. 이를 다음으로 고정했다.
- 0A 주식체결
- 0B 주식우선호가
- 0C 주식호가잔량
- 0D 주식시간외호가 (장중 판단 미사용)
- 0E 주식당일거래원
- 0F ETF NAV (일반주식 판단 미사용)
- 0m 장시작시간
- 0s ELW 지표 (일반주식 판단 미사용)
- 0u 종목프로그램매매
- 0w VI발동/해제

## 실시간 hot path
- 30종목 SCOUT: 0A + 0C + 0u
- FOCUS: 0E 추가
- 0A 수신 즉시 롤링윈도우/VWAP/체결가속/PRE-IGNITION 평가
- REST, 뉴스 HTTP, 저장을 hot path에서 기다리지 않음
- SSE/UI coalescing 50ms
- 활성세션 fresh 0A가 없으면 currentPrice=null 및 신규 EARLY/PRE-BUY/BUY fail-closed

## PRE-IGNITION
독립 축: tape / orderbook / program / structure-context. 최소 3축 동시강화를 요구하고, +4.5% 이상은 PRE-IGNITION 제외, +6% 이상 신규진입 차단.

## 실행 검증
- trader `npm run check`: PASS
- trader `npm run check:load`: PASS
  - 30종목, 12,000 이벤트
  - errors 0 / finalPending 0 / finalActive 0
  - throughput 약 63,158 ticks/sec
  - event-loop p95 23.43ms
- news-radar v1.5.6 `npm run check`: PASS
- 로컬 `next build`: 미실행 (`next` binary 미설치). Dockerfile은 배포 시 manifest -> npm install -> check -> 30,000-event load -> next build를 모두 통과해야 이미지 생성.

## 보장하지 않는 것
거래소/키움/인터넷의 물리적 지연을 0으로 만들 수 없으며 투자 승률을 보장하지 않는다. 소프트웨어 내부에서는 polling/REST를 실시간 판정 hot path에서 배제하고 event-driven으로 처리한다.
