## v3.1.7 FINAL — 수급 누락 복구·동일 종가 보존

- 종목별 프로그램매매 REST TR을 ka90004로 교정했습니다.
- 휴장/과거 종가에서 ka90013 일별 프로그램 추이 보강 경로를 추가했습니다.
- 같은 KRX 종가 날짜를 다시 동기화할 때 이미 저장된 마감 스마트머니/프로그램/외국계/기관 수급을 지우지 않고 보존합니다.
- 과거 실시간 스마트머니가 한 번도 저장되지 않은 날짜는 임의 추정값으로 채우지 않습니다.


## v3.1.6 FINAL — profit-priority shadow validation

- Added `blockedByProfitPriority` without changing the 78-point threshold or VWAP extension penalty.
- Signals rejected only by the profit-priority gate are written to a hidden shadow ledger.
- Shadow rows track live price, maximum/minimum return, and the first available return at or after 15 minutes.
- Shadow rows are excluded from alerts, SSE/UI ledgers, and the existing 200-signal quality validation sample.
- AWS Lightsail build uses the public npm registry explicitly and still requires unit, integration, storage, load, and Next.js build success before replacing the old container.
# 변경내역

## v3.1.6

- 종합 발생기록부 추가
  - SIGNAL/실제 POSITION 구분
  - 진입시점·매도시점·현재가·진입가·매도가·실시간/확정 수익률 표시
  - 매수/매도 확인중·확정·조기관찰·목표도달·손절·시간청산 상태 표시
- 실시간 화면에 매수·매도 신호 한눈에 보드 추가
- 수익우선점수 추가
  - 품질·유동성·기대손익비 가점, 스프레드·VWAP 추격 감점
  - BUY에 최소 수익우선점수 게이트 적용
- 단일 로컬 JSON 전체 재기록을 키별 원자 파일 저장으로 변경
- 알림 저장과 포지션 최고가·기록부 현재가 저장 배치화
- Redis 알림을 `LPUSH/LTRIM` 리스트 구조로 저장해 전체 배열 재기록 제거
- 종목별 비동기 후처리 최신상태 병합·동시성 제한·오류계측
- `/api/health`에 이벤트 루프·저장 큐·알림·후처리·메모리 지표 추가
- 저장검사와 12종목/12,000틱 합성 부하검사 추가

## v3.1.2

- 종가 데이터 완전성을 단순 OHLCV 개수로 계산하던 방식을 수정
  - KRX 핵심 35점, 기술지표 20점, NXT 15점, 마감 수급 30점으로 분리
  - 스마트머니·프로그램·외국계 자료가 없으면 더 이상 100%로 표시하지 않음
  - 누락 항목과 영역별 점수를 화면에서 확인 가능
- KRX와 NXT 계산 기준을 명시적으로 분리
  - 종가 판단가격과 이동평균·거래량 지표는 KRX 공식 종가·일봉 사용
  - NXT 가격은 KRX 종가 대비 괴리 확인 및 제한적 점수 보정에만 사용
  - NXT 표시가격에 KRX 등락률이나 NXT 괴리율을 등락률로 혼합하지 않음
- 휴장·장 종료 시 실시간 지표의 0 표시를 `휴장·미측정`으로 변경
- 종가점수의 항목별 가감점과 계산 근거를 화면에 표시
- 저장된 구형 종가 스냅샷을 불러올 때 완전성을 새 기준으로 다시 계산
- 운영 보안 강화
  - production 환경에서 `APP_ACCESS_TOKEN`, `APP_SESSION_SECRET`이 없거나 짧으면 서버 부팅 중단
  - 두 비밀값이 동일한 경우도 부팅 차단
- Safari 실시간/종가 혼합 정렬 회귀검사 유지

## v3.1.0–v3.1.1

- 키움 REST `ka10081` 일봉 OHLCV 스냅샷 추가
- KRX 종가와 NXT 현재/최종가 분리 표시
- 5일·20일 이동평균, 20일 거래량비, 고가 대비 마감 위치 계산
- 종가매수·보유·관망·절반축소·청산 판단 엔진 추가
- 마감 직전 스마트머니·프로그램·외국계 추정값 보존
- 앱 시작·15분 주기·KRX/NXT 종료 시 종가 자동 동기화
- 로컬 JSON 영속 저장과 Docker named volume 지원
- 실시간/종가 혼합 정렬 Safari client-side exception 수정

## v3.0.0

- 고정 집중 4 + 사용자 집중 4 + 사용자 경량 4 구조
- 경량 체결 전용 구독과 자동승격
- 증분 롤링 계산, 스마트머니 상태기계, 다중 확인 조건
- 품질점수와 실증승률 분리
- SSE 즉시전달과 단위·통합검사 추가

## v3.1.6
- 종목관리 입력을 종목명 단일 입력 방식으로 단순화했습니다.
- 등록 시 키움 공식 종목정보 리스트(ka10099)를 조회해 종목명을 정확히 6자리 종목코드로 변환합니다.
- 종목 마스터는 6시간 메모리 캐시하며, 이름을 찾지 못하면 1회 강제 새로고침 후 재검색합니다.
- 등록 후 ka10001로 공식 종목명을 다시 검증합니다.
