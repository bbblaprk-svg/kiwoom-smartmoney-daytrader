const assert = require('assert');
const { parseProgram } = require('../lib/flowCollector');
const { closingFlowFromLive } = require('../lib/marketSnapshot');

const p = parseProgram({ rows: [{ prm_netprps_amt: '+123456', prm_netprps_qty: '+789' }] });
assert.equal(p.netAmount, 123456);
assert.equal(p.netQty, 789);
assert.equal(p.rawAvailable, true);

const previous = {
  smartMoneyState: 'EXPANSION', smartMoneyScore: 81,
  programNetAmount: 500000000, programNetQty: 10000,
  foreignNet: 1000, foreignNetDelta: 200, institutionNet: 300,
  availability: { smartMoney: true, program: true, foreign: true, institution: true },
  feedTimes: { tradeAt: 1, programAt: 2, brokerAt: 3, officialAt: 4 }, lastLiveAt: 1,
};
const merged = closingFlowFromLive(null, null, previous);
assert.equal(merged.smartMoneyState, 'EXPANSION');
assert.equal(merged.programNetAmount, 500000000);
assert.equal(merged.availability.smartMoney, true);
assert.equal(merged.availability.program, true);
assert.equal(merged.source, 'PRESERVED_SAME_CLOSE');
console.log('flow-regression-check: OK');
