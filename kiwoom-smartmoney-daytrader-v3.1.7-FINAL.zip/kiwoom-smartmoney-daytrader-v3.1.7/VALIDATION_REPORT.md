# v3.1.7 FINAL VALIDATION REPORT

검증 대상: 키움 스마트머니 실시간·종가 단타 앱 v3.1.7

## 이번 수정 핵심

- 종목별 프로그램매매 REST TR을 `ka90004`로 교정.
- 휴장/과거 종가 재구성 시 `ka90013` 종목일별 프로그램매매추이 보강.
- 같은 KRX 종가일을 다시 동기화해도 이미 저장된 마감 스마트머니/프로그램/외국계/기관 수급을 소거하지 않도록 보존.
- 과거 장중 체결 이력이 없던 날짜의 스마트머니는 임의 추정으로 채우지 않음.

## 실행 검증

- `node --check lib/flowCollector.js`: 통과
- `node --check lib/marketSnapshot.js`: 통과
- `node scripts/check.js`: 통과
- `node scripts/integration-check.js`: 통과
- `node scripts/storage-check.js`: 통과
- `node scripts/flow-regression-check.js`: 통과
- `node scripts/load-check.js`: 통과
- 12종목/12,000틱, 처리 오류 0, 최종 pending 0

## 실전 확인이 필요한 부분

키움 실서버의 프로그램/투자자 필드 값과 영웅문 표시값은 다음 거래일 장중 및 장마감 후 실제 대조가 필요합니다. 특히 `smartMoney`는 앱이 체결·호가·프로그램·거래원으로 계산하는 파생지표이므로 과거 날짜를 REST 자료만으로 동일하게 복원하지 않습니다.
