PULSE EDGE 3.9.0 HIDDEN GEM PURE

PURPOSE
- Find Korean stocks where internal buy energy is accumulating faster than price response and supply is drying up immediately before a first meaningful 10-30 minute release.
- This is not a top-gainer, news-chaser, sector-leader, or 1-2 day COILED strategy.

LIVE DATA PATH
- Kiwoom REST: low-cost universe/ranking/context discovery.
- Kiwoom WebSocket: live trade/order-book/program flow for precision tracking.
- KRX and NXT are separate venue/session states. Price, VWAP, executions, order book, volume and turnover are never cross-venue aggregated for buy decisions.
- DATA TRUTH and PRICE HOLD remain hard gates. Delayed/stale/conflicted data cannot confirm PRE-IGNITION or ENTRY NOW.

PURE HIDDEN GEM SEQUENCE
FRESH DISCOVERY
 -> ENERGY BUILD
 -> MICRO8
 -> FOCUS4
 -> FLOW DISLOCATION
 -> SELL RESPONSE FAILURE
 -> PRICE HOLD
 -> SUPPLY DECAY
 -> SUPPLY EXHAUSTION
 -> PRE-IGNITION
 -> ENTRY NOW

CORE METRICS
- ENERGY STORED: latent buy pressure that has not yet translated into proportional price expansion.
- ENERGY RELEASED: remembers the venue-local full intraday release path, including day peak extension, maximum VWAP extension, turnover acceleration, repeated release cycles and peak giveback.
- REMAINING ENERGY: stored/flow/supply energy net of already-released energy.
- RELEASE IMMINENCE: proximity to actual release, emphasizing supply exhaustion and accelerating flow.

IMPORTANT RELEASE POLICY
- +3% to +7% is not automatically TOO LATE. It can remain eligible when remaining energy is strong and released energy is limited.
- Example policy: current +5% / intraday high +12% may remain a re-accumulation candidate; current +5% / intraday high +20% with large giveback is treated as already released/TOO LATE.
- Market RED does not stop discovery or PRE observation, but blocks a new ENTRY ignition event.

REMOVED FROM FINAL DECISION
- Legacy MODEL A / A1 / A2 / B gating.
- Sector-first candidate priority.
- News/sector bonus in the final Hidden Gem Score.
- Large-cap/leader sensor exclusion from hidden-gem visibility.
- 1-2D COILED strategy runtime. Compatibility endpoints return DISABLED_IN_HIDDEN_GEM_PURE and no rows.

HIDDEN GEM SCORE (100)
- FLOW DISLOCATION 22
- SELL RESPONSE FAILURE 18
- PRICE HOLD 12
- SUPPLY DECAY 16
- SUPPLY EXHAUSTION 14
- REMAINING ENERGY 10
- RELEASE IMMINENCE 8

DEFAULT PRE-IGNITION GATES
- ENERGY STORED >= 80
- REMAINING ENERGY >= 75
- RELEASE IMMINENCE >= 82
- ENERGY RELEASED <= 45
- FLOW DISLOCATION >= 60
- SELL RESPONSE FAILURE >= 55
- SUPPLY DECAY >= 55
- SUPPLY EXHAUSTION score >= 60
- DATA TRUTH PASS and PRICE HOLD PASS are mandatory.

ENTRY / ALERTS
- PRE-IGNITION: immediate push after strict gate confirmation.
- ENTRY NOW: PRE + actual supply exhaustion + high imminence + real ignition micro triggers; blocked when market RED.
- INVALIDATION: immediate push when a prior PRE/ENTRY loses PRICE HOLD, becomes TOO LATE, or falls back materially.
- Early precursor states are retained for UI/history but do not generate noisy push alerts.
- Repeat alerts require a real state change, REMAINING/IMMINENCE +8, supply-decay-to-exhaustion transition, or re-accumulation after invalidation.

RESOURCE POLICY
- Existing CPU-safe pipeline retained: bounded REST discovery, dynamic WebSocket slots up to 34, and quote-depth focus on 4 candidates.
- No additional broad order-book subscriptions are added.

DEPLOYMENT
- Put exactly the matching Dockerfile, SOURCE tar.gz and ONE_SHOT_DEPLOY script in the same directory.
- Do not upload .env or Kiwoom credentials. The deploy script reads the existing protected credential env on the server.
- Run: sudo bash PULSE_EDGE_GREENFIELD_3_9_0_HIDDEN_GEM_PURE_ONE_SHOT_DEPLOY.sh --preflight
- Then run the same command without --preflight for cutover.
- Live Kiwoom/OAuth/REST/WebSocket, Caddy route and sustained host resource checks are authoritative on the target server.
