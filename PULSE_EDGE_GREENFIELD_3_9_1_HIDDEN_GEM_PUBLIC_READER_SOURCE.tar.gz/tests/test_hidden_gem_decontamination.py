from pathlib import Path
from pulse_edge.config import Settings

def test_pure_settings_and_no_familiar_blacklist():
    s=Settings()
    assert s.release=='3.9.0_HIDDEN_GEM_PURE'
    assert s.hidden_gem_pre_stored_min==80.0
    assert s.hidden_gem_pre_remaining_min==75.0
    assert s.hidden_gem_pre_imminence_min==82.0
    assert s.hidden_gem_pre_released_max==45.0
    assert not hasattr(s,'familiar_symbols')

def test_model_a_b_removed_from_decision_engine():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'model_a_ready' not in r and 'model_b_ready' not in r
    assert "detection_model='HIDDEN_GEM_PURE'" in r

def test_sector_and_news_are_not_hidden_gem_score_inputs():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('hidden_gem_score='):r.index('total=hidden_gem_score')]
    assert 'sector' not in block.lower() and 'news' not in block.lower()

def test_full_day_release_memory_is_present():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    for token in ['day_peak_change','intraday_max_vwap_extension_atr','intraday_max_turnover_accel','intraday_release_cycle_count','giveback_ratio']:
        assert token in r

def test_core_gates_remain():
    s=Settings()
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.bid_absorption_min_score==60.0
    assert s.impact_decay_min_score==60.0
