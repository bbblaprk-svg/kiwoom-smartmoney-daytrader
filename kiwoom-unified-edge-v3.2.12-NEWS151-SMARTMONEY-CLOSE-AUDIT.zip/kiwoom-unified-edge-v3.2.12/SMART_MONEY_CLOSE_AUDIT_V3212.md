# v3.2.12 SMART MONEY CLOSE AUDIT

목표: 종가 판정에서 스마트머니 `미수집`을 사전에 줄이되 REST 트래픽을 늘리지 않는다.

- 14:40~15:35 KST: 30종목 전체를 단일 Kiwoom WebSocket 세션의 정밀피드로 임시 승격.
- 15:36 이후: 기존 FOCUS/LIGHT 구조로 자동 복귀.
- FULL checkpoint: trade + orderbook + program 모두 신선. BUY/PRE-BUY 판단에 사용 가능.
- PARTIAL checkpoint: trade + orderbook/program 중 하나. 진단/보존은 하지만 BUY/PRE-BUY 하드게이트는 통과시키지 않음.
- health checkpoint 카운트는 전체 감시종목 기준으로 유지되어 장마감 후 LIGHT 복귀 때문에 숫자가 사라지는 착시를 제거.
