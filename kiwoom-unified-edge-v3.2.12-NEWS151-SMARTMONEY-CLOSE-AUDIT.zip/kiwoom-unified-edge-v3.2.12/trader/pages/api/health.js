const { state } = require('../../lib/realtimeStore');
const { getStoreMetrics } = require('../../lib/store');
const runtimeMetrics = require('../../lib/runtimeMetrics');
const { isAuthenticated } = require('../../lib/auth');
const { getRestMetrics } = require('../../lib/kiwoomClient');

module.exports = function handler(req, res) {
  const connected = state.connection.status === 'connected';
  const stocks = [...state.stocks.values()];
  const focus = stocks.filter((stock) => stock.activeTier === 'FOCUS').length;
  const light = stocks.filter((stock) => stock.activeTier === 'LIGHT').length;
  const promoted = stocks.filter((stock) => Number(stock.promotedUntil || 0) > Date.now()).length;
  const closeSnapshots = stocks.filter((stock) => Number(stock.marketSnapshot && stock.marketSnapshot.krx && stock.marketSnapshot.krx.close || 0) > 0).length;
  const now = Date.now();
  const kstDate = new Date(now + 9*60*60*1000).toISOString().slice(0,10).replace(/-/g,'');
  const focusStocks = stocks.filter((stock) => stock.activeTier === 'FOCUS');
  const feedReady = {
    trade: focusStocks.filter((stock) => stock.updatedAt && now - stock.updatedAt <= 1500 && Number(stock.tradeEventCount || 0) >= 5).length,
    orderbook: focusStocks.filter((stock) => stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 3500).length,
    program: focusStocks.filter((stock) => stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 20000 && Number(stock.program.sampleCount || 0) >= 2).length,
    broker: focusStocks.filter((stock) => stock.broker && stock.broker.updatedAt && now - stock.broker.updatedAt <= 120000).length,
  };
  // BUY 엔진과 동일하게 핵심 준비도는 체결+호가+프로그램으로 계산한다.
  // 거래원(0F)은 갱신 빈도가 낮을 수 있어 보조 확인용이며 smartMoneyReady의 하드 요건이 아니다.
  const checkpointStocks = stocks.filter((stock) => stock.smartMoneyCheckpoint && stock.smartMoneyCheckpoint.sessionDate === kstDate);
  const smartMoneyCheckpoints = checkpointStocks.length;
  const smartMoneyCheckpointFull = checkpointStocks.filter((stock) => String(stock.smartMoneyCheckpoint.quality || 'FULL').toUpperCase() === 'FULL').length;
  const smartMoneyCheckpointPartial = checkpointStocks.filter((stock) => String(stock.smartMoneyCheckpoint.quality || '').toUpperCase() === 'PARTIAL').length;
  const smartMoneyReady = focusStocks.filter((stock) => stock.updatedAt && now - stock.updatedAt <= 1500 && Number(stock.tradeEventCount || 0) >= 5
    && stock.orderbook && stock.orderbook.updatedAt && now - stock.orderbook.updatedAt <= 3500
    && stock.program && stock.program.updatedAt && now - stock.program.updatedAt <= 20000 && Number(stock.program.sampleCount || 0) >= 2).length;
  const venueFeeds = { KRX: { fresh: 0, stale: 0 }, NXT: { fresh: 0, stale: 0 }, dualFresh: 0 };
  const behaviorStates = {};
  for (const stock of focusStocks) {
    const krxAt = Number(stock.venues && stock.venues.KRX && stock.venues.KRX.updatedAt || 0);
    const nxtAt = Number(stock.venues && stock.venues.NXT && stock.venues.NXT.updatedAt || 0);
    const kFresh = krxAt > 0 && now - krxAt <= 5000; const nFresh = nxtAt > 0 && now - nxtAt <= 5000;
    venueFeeds.KRX[kFresh ? 'fresh' : 'stale'] += 1; venueFeeds.NXT[nFresh ? 'fresh' : 'stale'] += 1;
    if (kFresh && nFresh) venueFeeds.dualFresh += 1;
    const behavior = String(stock.smartMoney && stock.smartMoney.behaviorState || 'NEUTRAL');
    behaviorStates[behavior] = Number(behaviorStates[behavior] || 0) + 1;
  }
  const load = runtimeMetrics.snapshot();
  const store = getStoreMetrics();
  const rest = getRestMetrics();

  const payload = {
    ok: connected,
    version: '3.2.12-smartmoney-close-audit',
    status: state.connection.status,
    lastMessageAt: state.connection.lastMessageAt,
    subscribed: state.connection.subscribed.length,
    wireSubscribed: (state.connection.wireSubscribed || []).length, krxSubscribed: (state.connection.krxSubscribed || []).length, nxtSubscribed: (state.connection.nxtSubscribed || []).length,
    focus, light, promoted, closeSnapshots, smartMoneyReady, smartMoneyCheckpoints, smartMoneyCheckpointFull, smartMoneyCheckpointPartial, feedReady, venueFeeds, behaviorStates,
    closeAuditMode: Boolean(state.connection.closeAuditMode), closeAuditFullCount: Number(state.connection.closeAuditFullCount || 0),
    socketFrameAgeMs: state.connection.socketFrameAgeMs ?? null, venueRegistration: state.connection.venueRegistration || {},
    fallbackLastAt: state.connection.fallbackLastAt || null, fallbackLastVenue: state.connection.fallbackLastVenue || null, fallbackLastCode: state.connection.fallbackLastCode || null,
    lastSnapshotAt: state.connection.lastSnapshotAt || null,
    snapshotStatus: state.connection.snapshotStatus || null,
    snapshotPolicy: state.connection.snapshotPolicy || 'CLOSE_ONLY',
    closeSync: state.connection.closeSync || null,
    snapshotRetryPending: Number(state.connection.snapshotRetryPending || 0),
    snapshotRetryCodes: state.connection.snapshotRetryCodes || [],
    trafficMode: 'LOW_TRAFFIC_WEBSOCKET_FIRST_PIPELINE_GUARD_V2',
    realtimeTypeMap: { trade:'0B', orderbook:'0D', broker:'0F', program:'0w', vi:'1h', marketStatus:'0s' },
    restPolicy: {
      periodicFullSnapshot: false, staleFallbackOnly: true,
      krxCloseSync: '15:32 KST', krxRetries: ['15:34','15:37','15:42','16:00'],
      nxtCloseSync: '20:01 KST', nxtRetries: ['20:03','20:06','20:12','20:20'],
      retryScope: 'FAILED_SYMBOLS_ONLY', restartCatchup: true, closeBuyRequiresOfficialKrxClose: true,
      closeSyncCoalescing: true, nxtFinalFastPath: 'WEBSOCKET_THEN_REST', foreignDetailFallbackOnly: true,
    },
    restMetrics: { total: rest.total, startedAt: rest.startedAt, lastAt: rest.lastAt, minGapMs: rest.minGapMs, byApi: rest.byApi },
    sseClients: state.sseClients || 0,
    serverTime: new Date().toISOString(),
  };
  // 외부 헬스체크에는 연결상태만 노출하고, 부하·메모리 상세는 로그인 세션/토큰에만 제공합니다.
  if (isAuthenticated(req)) {
    payload.load = {
      eventLoop: load.eventLoop,
      store: { ...load.store, backend: store.usingRedis ? 'redis' : store.usingLocalFile ? 'local-sharded' : 'memory', keyCount: store.keyCount, queueLength: store.queueLength, pendingKeys: store.pendingKeys },
      alerts: load.alerts,
      postProcess: load.postProcess,
      realtime: load.realtime,
      memory: load.memory,
    };
  }
  res.status(200).json(payload);
};
