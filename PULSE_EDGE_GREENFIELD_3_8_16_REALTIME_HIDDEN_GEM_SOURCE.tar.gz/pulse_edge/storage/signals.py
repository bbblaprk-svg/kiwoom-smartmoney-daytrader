from __future__ import annotations
import sqlite3, json, time, threading
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.parse import urlparse

class SignalStore:
    def __init__(self,path,limit=100,now_limit=None,coiled_limit=None):
        self.path=path; self.limit=limit; self.now_limit=now_limit; self.coiled_limit=coiled_limit; self.lock=threading.RLock()
        self.db=sqlite3.connect(path,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA busy_timeout=3000')
        self.db.execute('CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, symbol TEXT NOT NULL, venue TEXT NOT NULL, horizon TEXT NOT NULL DEFAULT "NOW", stage TEXT NOT NULL, score REAL, payload TEXT NOT NULL)')
        cols={r[1] for r in self.db.execute('PRAGMA table_info(signals)').fetchall()}
        if 'horizon' not in cols:
            self.db.execute('ALTER TABLE signals ADD COLUMN horizon TEXT NOT NULL DEFAULT "NOW"')
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts DESC)')
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_signals_horizon_ts ON signals(horizon,ts DESC)')
        self.db.execute('CREATE TABLE IF NOT EXISTS subscriptions(endpoint TEXT PRIMARY KEY, payload TEXT NOT NULL, updated REAL NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS signal_outcomes(signal_id INTEGER PRIMARY KEY, symbol TEXT NOT NULL, venue TEXT NOT NULL, signal_ts REAL NOT NULL, signal_price REAL NOT NULL, mfe_pct REAL NOT NULL DEFAULT 0, mae_pct REAL NOT NULL DEFAULT 0, ret_10m REAL, ret_30m REAL, ret_close REAL, last_price REAL, updated REAL NOT NULL)')
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_signal_outcomes_ts ON signal_outcomes(signal_ts DESC)')
        self.db.commit()
    def add_payload(self,symbol,venue,stage,score,data):
        horizon=str((data or {}).get('horizon') or ('1-2D' if str(stage).startswith(('COILED','BUILDING')) else 'NOW'))
        if horizon not in {'NOW','NOW-PRECURSOR','1-2D','TRANSITION'}:
            horizon='NOW'
        payload_data=dict(data or {}); payload_data['horizon']=horizon
        payload=json.dumps(payload_data,ensure_ascii=False,separators=(',',':'))
        with self.lock:
            signal_ts=time.time()
            cur=self.db.execute('INSERT INTO signals(ts,symbol,venue,horizon,stage,score,payload) VALUES(?,?,?,?,?,?,?)',(signal_ts,symbol,venue,horizon,stage,score,payload))
            signal_id=int(cur.lastrowid)
            px=payload_data.get('current_price')
            if horizon in {'NOW','NOW-PRECURSOR','TRANSITION'} and isinstance(px,(int,float)) and float(px)>0:
                self.db.execute('INSERT OR IGNORE INTO signal_outcomes(signal_id,symbol,venue,signal_ts,signal_price,last_price,updated) VALUES(?,?,?,?,?,?,?)',(signal_id,symbol,venue,signal_ts,float(px),float(px),signal_ts))
            if self.now_limit is not None and self.coiled_limit is not None:
                self.db.execute('DELETE FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") AND id NOT IN (SELECT id FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") ORDER BY id DESC LIMIT ?)',(int(self.now_limit),))
                self.db.execute('DELETE FROM signals WHERE horizon="1-2D" AND id NOT IN (SELECT id FROM signals WHERE horizon="1-2D" ORDER BY id DESC LIMIT ?)',(int(self.coiled_limit),))
            else:
                self.db.execute('DELETE FROM signals WHERE id NOT IN (SELECT id FROM signals ORDER BY id DESC LIMIT ?)',(self.limit,))
            self.db.commit()
    def prune_horizons(self,now_limit=200,coiled_limit=200):
        with self.lock:
            self.db.execute('DELETE FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") AND id NOT IN (SELECT id FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") ORDER BY id DESC LIMIT ?)',(int(now_limit),))
            self.db.execute('DELETE FROM signals WHERE horizon="1-2D" AND id NOT IN (SELECT id FROM signals WHERE horizon="1-2D" ORDER BY id DESC LIMIT ?)',(int(coiled_limit),))
            self.db.commit()
    def add(self,c):
        self.add_payload(c.symbol,c.venue,c.stage,c.total_score,c.to_dict())
    def recent(self,limit=100,horizon=None):
        n=max(1,min(int(limit),self.limit))
        with self.lock:
            if horizon=='NOW':
                rows=self.db.execute('SELECT id,ts,symbol,venue,horizon,payload FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") ORDER BY id DESC LIMIT ?',(n,)).fetchall()
                counts={(s,v):c for s,v,c in self.db.execute('SELECT symbol,venue,COUNT(*) FROM signals WHERE horizon IN ("NOW","NOW-PRECURSOR","TRANSITION") GROUP BY symbol,venue').fetchall()}
            elif horizon=='1-2D':
                rows=self.db.execute('SELECT id,ts,symbol,venue,horizon,payload FROM signals WHERE horizon="1-2D" ORDER BY id DESC LIMIT ?',(n,)).fetchall()
                counts={(s,v):c for s,v,c in self.db.execute('SELECT symbol,venue,COUNT(*) FROM signals WHERE horizon="1-2D" GROUP BY symbol,venue').fetchall()}
            else:
                rows=self.db.execute('SELECT id,ts,symbol,venue,horizon,payload FROM signals ORDER BY id DESC LIMIT ?',(n,)).fetchall()
                counts={(s,v):c for s,v,c in self.db.execute('SELECT symbol,venue,COUNT(*) FROM signals GROUP BY symbol,venue').fetchall()}
        out=[]
        for i,ts,symbol,venue,h,payload in rows:
            d=json.loads(payload); d['history_id']=i; d['history_ts']=ts; d['horizon']=h; d['occurrence_count']=counts.get((symbol,venue),1); out.append(d)
        return out
    def update_performance(self,prices,now=None):
        """Low-overhead NOW signal scoring. prices maps (symbol,venue)->current price.
        Updates MFE/MAE and fixed 10m/30m/EOD marks without touching UI/history payloads.
        """
        n=time.time() if now is None else float(now); kst=ZoneInfo('Asia/Seoul')
        with self.lock:
            rows=self.db.execute('SELECT signal_id,symbol,venue,signal_ts,signal_price,mfe_pct,mae_pct,ret_10m,ret_30m,ret_close FROM signal_outcomes WHERE signal_ts>=? ORDER BY signal_id DESC LIMIT 1000',(n-7*86400,)).fetchall()
            for sid,symbol,venue,sts,sp,mfe,mae,r10,r30,rclose in rows:
                px=prices.get((symbol,venue))
                if px is None or px<=0 or sp<=0: continue
                ret=(float(px)/float(sp)-1.0)*100.0; mfe=max(float(mfe or 0.0),ret); mae=min(float(mae or 0.0),ret); age=n-float(sts)
                if r10 is None and age>=600: r10=ret
                if r30 is None and age>=1800: r30=ret
                sig_dt=datetime.fromtimestamp(float(sts),kst); now_dt=datetime.fromtimestamp(n,kst)
                if rclose is None and sig_dt.date()==now_dt.date() and (now_dt.hour>15 or (now_dt.hour==15 and now_dt.minute>=29)): rclose=ret
                self.db.execute('UPDATE signal_outcomes SET mfe_pct=?,mae_pct=?,ret_10m=?,ret_30m=?,ret_close=?,last_price=?,updated=? WHERE signal_id=?',(round(mfe,4),round(mae,4),None if r10 is None else round(float(r10),4),None if r30 is None else round(float(r30),4),None if rclose is None else round(float(rclose),4),float(px),n,int(sid)))
            self.db.execute('DELETE FROM signal_outcomes WHERE signal_ts<?',(n-30*86400,))
            self.db.commit()
    def performance_count(self):
        with self.lock: return int(self.db.execute('SELECT COUNT(*) FROM signal_outcomes').fetchone()[0])

    def subscribe(self,sub):
        ep=str(sub.get('endpoint') or '').strip()
        keys=sub.get('keys') or {}
        try: parsed=urlparse(ep)
        except Exception: parsed=None
        if not ep or parsed is None or parsed.scheme!='https' or not parsed.netloc:
            raise ValueError('invalid push endpoint')
        if not str(keys.get('p256dh') or '').strip() or not str(keys.get('auth') or '').strip():
            raise ValueError('missing push keys')
        # Keep the local subscription table bounded; old clients are evicted by least-recent update.
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO subscriptions(endpoint,payload,updated) VALUES(?,?,?)',(ep,json.dumps(sub,separators=(',',':')),time.time()))
            self.db.execute('DELETE FROM subscriptions WHERE endpoint NOT IN (SELECT endpoint FROM subscriptions ORDER BY updated DESC LIMIT 64)')
            self.db.commit()
    def unsubscribe(self,endpoint):
        with self.lock:
            self.db.execute('DELETE FROM subscriptions WHERE endpoint=?',(endpoint,)); self.db.commit()
    def subscriptions(self):
        with self.lock: rows=self.db.execute('SELECT payload FROM subscriptions').fetchall()
        return [json.loads(x[0]) for x in rows]
    def count(self):
        with self.lock: return int(self.db.execute('SELECT COUNT(*) FROM signals').fetchone()[0])
    def subscription_count(self):
        with self.lock: return int(self.db.execute('SELECT COUNT(*) FROM subscriptions').fetchone()[0])
    def drop_subscription(self,endpoint): self.unsubscribe(endpoint)

    def close(self):
        with self.lock:
            self.db.commit(); self.db.close()
