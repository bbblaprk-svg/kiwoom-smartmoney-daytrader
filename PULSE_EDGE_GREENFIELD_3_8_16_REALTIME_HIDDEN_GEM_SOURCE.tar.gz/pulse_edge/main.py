from __future__ import annotations
from contextlib import asynccontextmanager
from fastapi import FastAPI,Query,Request,HTTPException
from fastapi.responses import FileResponse,JSONResponse
from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime

S=Settings(); R=Runtime(S); WEB=Path(__file__).with_name('web')
@asynccontextmanager
async def lifespan(app):
    await R.start(); yield; await R.stop()
app=FastAPI(title='PULSE EDGE REALTIME HIDDEN GEM 3.8.16',lifespan=lifespan)
@app.get('/health')
def health(): return R.health()
@app.get('/api/readiness')
def readiness():
    r=R.readiness(); return JSONResponse(r,status_code=200 if r['ready'] else 503)
@app.get('/api/hidden-gem/top')
def top(limit:int=Query(20,ge=1,le=20)):
    rows=R.results[:limit]
    actionable=[x for x in rows if x.suitability in {'A','B'}][:7]
    a=[x.to_dict() for x in actionable if x.suitability=='A']
    b=[x.to_dict() for x in actionable if x.suitability=='B']
    watch=[x.to_dict() for x in rows if x.suitability=='WATCH'][:3]
    return {'release':S.release,'message':None if a else '현재 신규 숨은 진주 A급 없음','a':a,'b':b,'watch':watch,'all':[x.to_dict() for x in rows]}
@app.get('/api/coiled-spring/top')
def coiled_top(limit:int=Query(5,ge=1,le=5)):
    rows=R.coiled_results[:limit]
    if rows:
        return {'release':S.release,'message':None,'source':'RECALCULATED','rows':[x.to_dict() for x in rows]}
    # Closed-session startup can precede the first daily-context refresh. Preserve the
    # latest unique 1-2D candidates from the bounded history instead of flashing an empty table.
    if R.active_venue() is None:
        hist=R.signal_store.recent(S.coiled_history_limit,'1-2D'); out=[]; seen=set()
        for r in hist:
            sym=str(r.get('symbol') or '')
            if not sym or sym in seen: continue
            seen.add(sym); out.append(r)
            if len(out)>=limit: break
        if out:
            return {'release':S.release,'message':'휴장 · 최근 1~2D 후보 보존','source':'HISTORY_SNAPSHOT','rows':out}
    return {'release':S.release,'message':'현재 신규 1~2D 응축 후보 없음','source':'EMPTY','rows':[]}
@app.get('/api/signal-history')
def signal_history(limit:int=Query(100,ge=1,le=400),horizon:str|None=None):
    h='NOW' if horizon=='NOW' else ('1-2D' if horizon=='1-2D' else None)
    return {'limit':S.history_limit,'horizon':h,'rows':R.signal_store.recent(limit,h)}

@app.get('/api/history/now')
def history_now(limit:int=Query(200,ge=1,le=200)):
    return {'limit':S.now_history_limit,'rows':R.signal_store.recent(limit,'NOW')}

@app.get('/api/history/coiled')
def history_coiled(limit:int=Query(200,ge=1,le=200)):
    return {'limit':S.coiled_history_limit,'rows':R.signal_store.recent(limit,'1-2D')}

@app.get('/api/symbol-current')
def symbol_current(symbol:str,horizon:str='NOW'):
    symbol=''.join(c for c in str(symbol or '') if c.isdigit())[:6]
    if not symbol: raise HTTPException(400,'symbol required')
    if horizon=='1-2D':
        from pulse_edge.engine.coiled import score_coiled
        st=next((x for x in R.states.values() if x.symbol==symbol and x.venue=='KRX'),None)
        if not st: return {'found':False,'symbol':symbol,'horizon':'1-2D'}
        c=score_coiled(st,{x.symbol for x in R.raw_results if x.stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}})
        return {'found':bool(c),'symbol':symbol,'horizon':'1-2D','row':c.to_dict() if c else None}
    c=next((x for x in R.raw_results if x.symbol==symbol),None) or next((x for x in R.results if x.symbol==symbol),None)
    return {'found':bool(c),'symbol':symbol,'horizon':'NOW','row':c.to_dict() if c else None}
@app.get('/api/push/public-key')
def push_key(): return {'enabled':bool(S.push_enabled and S.vapid_public_key and S.vapid_private_key),'public_key':S.vapid_public_key}
@app.post('/api/push/subscribe')
async def push_subscribe(req:Request):
    body=await req.json()
    try: R.signal_store.subscribe(body)
    except ValueError as e: raise HTTPException(400,str(e))
    return {'ok':True}
@app.post('/api/push/unsubscribe')
async def push_unsubscribe(req:Request):
    body=await req.json(); R.signal_store.unsubscribe(str(body.get('endpoint') or '')); return {'ok':True}
@app.post('/api/news-signal')
async def news_signal(req:Request):
    body=await req.json()
    if not S.news_webhook_secret:
        raise HTTPException(503,'news adapter not configured')
    if str(body.get('secret') or '')!=S.news_webhook_secret:
        raise HTTPException(403,'invalid news signal secret')
    symbol=''.join(c for c in str(body.get('symbol') or '') if c.isdigit())[:6]
    if not symbol: raise HTTPException(400,'symbol required')
    touched=R.ingest_news_signal(symbol,bool(body.get('hot')),bool(body.get('catalyst')),body.get('risk'))
    return {'ok':True,'symbol':symbol,'states_updated':touched}

@app.get('/api/runtime-truth')
def truth(): return R.health()
@app.get('/api/feed-truth')
def feed_truth():
    h=R.health()
    return {'ws_connected':R.ws.connected,'last_message':R.ws.last_message,'active_venue':R.active_venue(),'quote_focus':list(R.quote_focus_key),
            'market_index_age_sec':h.get('market_index_age_sec'),'nxt_market_proxy':h.get('nxt_market_proxy'),'channel_age_sec':h.get('channel_age_sec'),
            'probe_promoted':h.get('probe_promoted'),'data_truth_policy':'NO_DELAYED_OR_CROSS_VENUE_DATA_FOR_BUY_DECISION'}
@app.get('/api/session')
def session(): return {'release':S.release,'mode':'GREENFIELD','active_venue':R.active_venue(),'automatic_orders':False}
@app.get('/')
def root(): return FileResponse(WEB/'index.html',headers={'Cache-Control':'no-store'})
@app.get('/pulse.js')
def js(): return FileResponse(WEB/'pulse.js',media_type='application/javascript',headers={'Cache-Control':'no-store'})
@app.get('/pulse.css')
def css(): return FileResponse(WEB/'pulse.css',media_type='text/css',headers={'Cache-Control':'no-store'})
@app.get('/sw.js')
def sw(): return FileResponse(WEB/'sw.js',media_type='application/javascript',headers={'Service-Worker-Allowed':'/','Cache-Control':'no-cache'})
