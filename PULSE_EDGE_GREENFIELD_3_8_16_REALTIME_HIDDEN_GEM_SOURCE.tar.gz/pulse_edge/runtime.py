from __future__ import annotations
import asyncio, time, os, json
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from collections import deque
from pulse_edge.config import Settings
from pulse_edge.models import SymbolState,Trade,Quote,InvestorSnapshot
from pulse_edge.feed.kiwoom import Auth,Rest,WS,load_universe,intraday_investor_snapshots,minute_baseline_rows,daily_investor_rows,investor_rank_symbols,after_close_investor_seed_symbols,num,money_krw
from pulse_edge.storage.baseline import BaselineStore
from pulse_edge.storage.signals import SignalStore
from pulse_edge.engine.scorer import Scorer
from pulse_edge.engine.features import quick_probe_score
from pulse_edge.engine.coiled import rank_coiled
KST=ZoneInfo('Asia/Seoul')


def parse_hhmmss(raw):
    s=''.join(c for c in str(raw or '') if c.isdigit())[-6:]
    if len(s)!=6: return time.time()
    now=datetime.now(KST)
    try:
        d=now.replace(hour=int(s[:2]),minute=int(s[2:4]),second=int(s[4:]),microsecond=0)
        # Protect against malformed/future timestamps without silently making them fresh.
        if (d-now).total_seconds()>300: d-=timedelta(days=1)
        return d.timestamp()
    except Exception: return time.time()


# 2026 Korean public/exchange closures that fall on weekdays, plus KRX-specific
# Workers' Day and year-end closure. Weekend filtering is generic for every year.
_KRX_CLOSED_2026={
    '2026-01-01',
    '2026-02-16','2026-02-17','2026-02-18',
    '2026-03-02',
    '2026-05-01','2026-05-05','2026-05-25',
    '2026-06-03',
    '2026-07-17',
    '2026-08-17',
    '2026-09-24','2026-09-25',
    '2026-10-05','2026-10-09',
    '2026-12-25','2026-12-31',
}

def venue_for_kst(dt,closed_dates=None):
    # Saturday/Sunday are never treated as live KRX/NXT sessions.
    if dt.weekday()>=5: return None
    closed=set(_KRX_CLOSED_2026)
    if closed_dates: closed.update(closed_dates)
    if dt.date().isoformat() in closed: return None
    sec=dt.hour*3600+dt.minute*60+dt.second
    # User policy: KRX only for the entire 09:00~15:30 regular session.
    # NXT official non-overlap windows: pre 08:00~08:50, after 15:40~20:00.
    if 9*3600 <= sec <= 15*3600+30*60: return 'KRX'
    if 8*3600 <= sec <= 8*3600+50*60: return 'NXT'
    if 15*3600+40*60 <= sec <= 20*3600: return 'NXT'
    return None


def interleave_unique(buckets,limit):
    out=[]; seen=set(); depth=max((len(x) for x in buckets),default=0)
    for i in range(depth):
        for bucket in buckets:
            if i>=len(bucket): continue
            x=bucket[i]
            if x in seen: continue
            seen.add(x); out.append(x)
            if len(out)>=limit: return out
    return out


class Runtime:
    def __init__(self,s:Settings):
        self.s=s; os.makedirs(s.data_dir,exist_ok=True)
        self.baseline=BaselineStore(s.baseline_db); self.scorer=Scorer(s,self.baseline); self.signal_store=SignalStore(s.history_db,s.history_limit,s.now_history_limit,s.coiled_history_limit)
        self.signal_last={}; self.states={}; self.universe={}; self.results=[]; self.raw_results=[]; self.tasks=[]; self.errors=deque(maxlen=60)
        self.started=time.time(); self.rotate_cursor=0; self.last_rank_commit=0.; self.last_quote_focus=0.; self.quote_focus_key=()
        self.auth=Auth(s.kiwoom_rest_base,s.kiwoom_appkey,s.kiwoom_secretkey); self.rest=Rest(s.kiwoom_rest_base,self.auth)
        self.ws=WS(s.kiwoom_ws_url,self.auth,self.on_event,s.ws_dynamic_max_items,s.ws_background_reserve_items,s.ws_group_base,s.ws_quote_focus_items)
        self.last_eval=0.; self.last_universe=0.; self.last_investor=0.; self.last_daily=0.; self.rank_priority=[]; self.coiled_results=[]; self.coiled_seed_symbols=[]; self.coiled_last={}; self.precursor_last={}
        self.probe_until={}; self.probe_scores={}; self.job_health={}; self.baseline_bootstrapped=set(); self.push_tasks=set(); self._stopping=False
        # Discovery metadata is transport/slot state only; it never changes candidate scores.
        self.discovery_meta={}; self.discovery_pool=[]; self.priority_demotions=0; self.discovery_sector_scores={}
        self.probe_rest_confirm_ts={}; self.urgent_baseline_queue=deque(); self.urgent_baseline_queued=set(); self.last_urgent_baseline=0.
        self.krx_closed_dates={x.strip() for x in str(self.s.krx_closed_dates or '').split(',') if x.strip()}
        self.eval_seq=0; self.last_candidate_fingerprint=''; self.last_trade_event_seen=0.; self.last_performance_update=0.
        self.event_loop_lag_ms=deque(maxlen=max(30,int(self.s.latency_sample_size)))
        self.event_handler_ms=deque(maxlen=max(30,int(self.s.latency_sample_size)))
        self.feed_event_age_ms=deque(maxlen=max(30,int(self.s.latency_sample_size)))
        self.eval_ms=deque(maxlen=max(30,int(self.s.latency_sample_size)))

    def state(self,symbol,venue='KRX'):
        key=f'{symbol}:{venue}'
        if key not in self.states:
            meta=self.universe.get(symbol,{})
            self.states[key]=SymbolState(symbol=symbol,name=meta.get('name',''),market=meta.get('market','UNKNOWN'),sector=meta.get('sector','UNKNOWN'),nxt_enabled=bool(meta.get('nxt_enabled')),listed_shares=meta.get('listed_shares'),venue=venue,first_seen_ts=time.time())
        return self.states[key]

    async def on_event(self,e):
        handler_start=time.perf_counter()
        s=e.get('symbol'); typ=e.get('type'); d=e.get('data') or {}; venue=e.get('venue','KRX'); recv=float(e.get('receive_ts') or time.time())
        if typ=='1h':
            sym=s or ''.join(c for c in str(d.get('stock_code') or '') if c.isdigit())[:6]
            if not sym or sym not in self.universe: return
            st=self.state(sym,venue if venue in {'KRX','NXT'} else (self.active_venue() or 'KRX'))
            st.vi_last_ts=recv
            st.vi_count=int(abs(num(d.get('vi_count')) or st.vi_count or 0))
            st.vi_trigger_rate=num(d.get('vi_trigger_rate'))
            evcode=str(d.get('vi_event') or '').strip()
            # Official 1h uses VI event code to distinguish trigger/release; the announced
            # release time may already be present on a trigger message, so it must not clear it.
            st.vi_active=evcode in {'1','발동','TRIGGER'}
            return
        if typ=='0J':
            cr=num(d.get('change_rate'))
            if s in {'001','000001'} and cr is not None:
                self.scorer.market_change['KOSPI']=cr; self.scorer.market_ts['KOSPI']=parse_hhmmss(d.get('trade_time'))
            elif s in {'101','000101'} and cr is not None:
                self.scorer.market_change['KOSDAQ']=cr; self.scorer.market_ts['KOSDAQ']=parse_hhmmss(d.get('trade_time'))
            return
        if not s or len(s)!=6: return
        st=self.state(s,venue); st.name=st.name or str(e.get('name') or '')
        ev=parse_hhmmss(d.get('trade_time') or d.get('quote_time')); st.last_receive_ts=recv; st.last_event_ts=ev
        age_ms=max(0.0,(recv-ev)*1000.0)
        if age_ms < 3600000:
            self.feed_event_age_ms.append(age_ms)
        if typ=='0B':
            st.last_trade_receive_ts=recv; st.last_trade_event_ts=ev; self.last_trade_event_seen=max(self.last_trade_event_seen,ev)
            p=num(d.get('price')); signed_vol=num(d.get('trade_volume')); cr=num(d.get('change_rate')); vol=abs(signed_vol or 0)
            if p is not None: st.price=abs(p)
            if cr is not None: st.change_rate=cr
            op=num(d.get('open')); hi=num(d.get('high')); lo=num(d.get('low'))
            if op is not None: st.open=abs(op)
            if hi is not None: st.high=abs(hi)
            if lo is not None: st.low=abs(lo)
            st.cumulative_volume=abs(num(d.get('cumulative_volume')) or st.cumulative_volume or 0)
            cum_amt=money_krw(d.get('cumulative_amount')); st.cumulative_amount=abs(cum_amt) if cum_amt is not None else st.cumulative_amount
            if st.price and vol>0:
                # Primary truth: official FID15 sign. FID1030/1031 are only a fallback if FID15 has no direction.
                if signed_vol is not None and signed_vol!=0:
                    buy_exec=max(signed_vol,0.0); sell_exec=max(-signed_vol,0.0)
                else:
                    buy_exec=abs(num(d.get('buy_exec_volume')) or 0); sell_exec=abs(num(d.get('sell_exec_volume')) or 0)
                strength=num(d.get('trade_strength'))  # official FID228 only
                st.trades.append(Trade(ev,st.price,vol,st.cumulative_volume,st.cumulative_amount,buy_exec,sell_exec,strength))
                minute=int(datetime.fromtimestamp(ev,KST).strftime('%H%M')); st.minute_amount[minute]=st.minute_amount.get(minute,0)+st.price*vol
                if len(st.minute_amount)>120:
                    for k in sorted(st.minute_amount)[:-90]: st.minute_amount.pop(k,None)
        elif typ=='0D':
            st.last_quote_receive_ts=recv; st.last_quote_event_ts=ev
            aq=sum(abs(num(d.get(k)) or 0) for k in ('ask1_qty','ask2_qty','ask3_qty')); bq=sum(abs(num(d.get(k)) or 0) for k in ('bid1_qty','bid2_qty','bid3_qty'))
            st.quotes.append(Quote(ev,abs(num(d.get('ask1')) or 0) or None,abs(num(d.get('bid1')) or 0) or None,aq or None,bq or None,abs(num(d.get('total_ask_qty')) or 0) or None,abs(num(d.get('total_bid_qty')) or 0) or None))
        elif typ=='0w':
            st.last_program_receive_ts=recv; st.last_program_event_ts=ev
            pn=money_krw(d.get('program_net_buy_amount')); st.program_net=pn if pn is not None else st.program_net
            if pn is not None: st.program_hist.append((ev,pn))
        self.event_handler_ms.append((time.perf_counter()-handler_start)*1000.0)

    async def refresh_universe(self):
        try:
            self.universe=await load_universe(self.rest)
            for st in list(self.states.values()):
                m=self.universe.get(st.symbol)
                if m:
                    st.name=m['name']; st.market=m['market']; st.sector=m['sector']; st.nxt_enabled=m['nxt_enabled']; st.listed_shares=m.get('listed_shares')
            self.last_universe=time.time()
        except Exception as e:
            self.errors.append(f'universe:{type(e).__name__}:{e}')

    def active_venue(self): return venue_for_kst(datetime.now(KST),self.krx_closed_dates)

    def _wire_state(self,wire):
        venue='NXT' if wire.endswith('_NX') else 'KRX'; sym=wire[:-3] if venue=='NXT' else wire
        return self.states.get(f'{sym}:{venue}')

    def _queue_urgent_baseline(self,wire):
        st=self._wire_state(wire)
        if st is None: return
        key=(st.symbol,st.venue)
        if key in self.baseline_bootstrapped or wire in self.urgent_baseline_queued: return
        self.urgent_baseline_queue.append(wire); self.urgent_baseline_queued.add(wire)

    async def _rest_confirm_probe(self,wire):
        """Bounded official single-stock cross-confirm for a newly promoted probe.
        ka10001 is a direct stock lookup, so a hidden gem does not need to be present
        in a ranking TOP12 in order to complete DATA TRUTH.
        """
        now=time.time()
        if now-self.probe_rest_confirm_ts.get(wire,0)<self.s.probe_rest_confirm_cooldown_sec: return
        self.probe_rest_confirm_ts[wire]=now
        st=self._wire_state(wire)
        if st is None: return
        api_symbol=st.symbol if st.venue=='KRX' else st.symbol+'_NX'
        try:
            row,_=await self.rest.post('ka10001','/api/dostk/stkinfo',{'stk_cd':api_symbol})
            self._rest_observe(st.symbol,st.venue,row)
        except Exception as e:
            self.errors.append(f'probe-confirm:{st.symbol}:ka10001:{type(e).__name__}:{e}')

    def _harvest_probes(self):
        now=time.time(); changed=False
        for wire in list(self.ws.background):
            st=self._wire_state(wire)
            if not st: continue
            score=quick_probe_score(st,self.s.probe_window_sec,now)
            if score>=self.s.probe_min_score:
                old=self.probe_scores.get(wire,0); newly_promoted=(wire not in self.probe_until)
                self.probe_scores[wire]=max(score,old); self.probe_until[wire]=now+self.s.probe_ttl_sec; changed=True
                if score>=self.s.urgent_baseline_min_score: self._queue_urgent_baseline(wire)
                if newly_promoted and score>=self.s.probe_rest_confirm_min_score:
                    task=asyncio.create_task(self._rest_confirm_probe(wire)); self.push_tasks.add(task); task.add_done_callback(self.push_tasks.discard)
        expired=[w for w,t in self.probe_until.items() if t<=now]
        for w in expired: self.probe_until.pop(w,None); self.probe_scores.pop(w,None); changed=True
        return changed

    def _probe_wires(self):
        now=time.time(); active=[w for w,t in self.probe_until.items() if t>now]
        active.sort(key=lambda w:self.probe_scores.get(w,0),reverse=True)
        return active[:self.s.probe_promote_items]

    def _actionable_wires(self):
        out=set()
        for c in self.raw_results:
            if c.stage in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'} or c.precursor_stage=='RELEASE READY':
                out.add(c.symbol+'_NX' if c.venue=='NXT' else c.symbol)
        return out

    def _fresh_discovery_wires(self, now=None):
        now=time.time() if now is None else now
        fresh=[]
        for wire in self.discovery_pool:
            m=self.discovery_meta.get(wire) or {}
            if now-m.get('first_seen',now) <= self.s.discovery_new_sec or now-m.get('last_change',0) <= self.s.discovery_new_sec:
                fresh.append(wire)
        return fresh

    def _eligible_rank_priority(self, now=None):
        now=time.time() if now is None else now
        actionable=self._actionable_wires()
        fresh=set(self._fresh_discovery_wires(now))
        out=[]
        for wire in self.discovery_pool:
            m=self.discovery_meta.get(wire) or {}
            idle=now-m.get('last_change',m.get('first_seen',now))
            # A confirmed pressure-release/PRE name is protected. Otherwise a symbol
            # that has shown no REST price/change signature movement for 10 minutes
            # yields its precision slot so new hidden-gem candidates can enter.
            if wire not in actionable and wire not in fresh and idle > self.s.priority_idle_sec:
                self.priority_demotions += 1
                continue
            out.append(wire)
        return out

    async def _apply_priority(self):
        limit=max(1,self.s.ws_dynamic_max_items-self.s.ws_background_reserve_items); probes=self._probe_wires()
        ranks=self._eligible_rank_priority()
        fresh=self._fresh_discovery_wires()
        fresh_slots=min(max(0,int(self.s.discovery_fresh_slots)),limit,len(fresh))
        probe_slots=min(len(probes),self.s.probe_promote_items,max(0,limit-fresh_slots))
        steady_slots=max(0,limit-fresh_slots-probe_slots)
        fresh_lane=fresh[:fresh_slots]
        probe_lane=[x for x in probes if x not in fresh_lane][:probe_slots]
        steady_lane=[x for x in ranks if x not in fresh_lane and x not in probe_lane][:steady_slots]
        combined=interleave_unique([fresh_lane,probe_lane,steady_lane],limit)
        if len(combined)<limit:
            for x in ranks+probes:
                if x not in combined: combined.append(x)
                if len(combined)>=limit: break
        self.rank_priority=combined
        await self.ws.set_priority(combined)

    async def rotate_background(self):
        if not self.universe: return
        venue=self.active_venue()
        if venue is None: return
        changed=self._harvest_probes()
        eligible=[m for m in self.universe.values() if venue=='KRX' or m.get('nxt_enabled')]
        n=self.s.ws_background_reserve_items
        if not eligible or n<=0: return
        priority_base={x.replace('_NX','') for x in self.ws.priority}; promoted={x.replace('_NX','') for x in self._probe_wires()}
        batch=[]; checked=0; idx=self.rotate_cursor
        while len(batch)<n and checked<len(eligible)*2:
            m=eligible[idx%len(eligible)]; idx+=1; checked+=1
            if m['symbol'] in priority_base or m['symbol'] in promoted: continue
            wire=m['symbol'] if venue=='KRX' else m['symbol']+'_NX'
            if wire not in batch: batch.append(wire)
        self.rotate_cursor=idx%len(eligible); await self.ws.set_background(batch)
        if changed: await self._apply_priority()

    def _rest_observe(self,symbol,venue,row):
        st=self.state(symbol,venue); p=abs(num(row.get('cur_prc')) or 0) or None
        if p: st.rest_price=p; st.rest_price_ts=time.time(); st.rest_venue=venue
        cr=num(row.get('flu_rt'))
        if cr is not None: st.rest_change_rate=cr; st.rest_change_ts=time.time()

    async def _ranking_bucket(self,api,body,key,venue,suffix):
        bucket=[]
        try:
            b,_=await self.rest.post(api,'/api/dostk/rkinfo',body)
            for r in (b.get(key,[]) or [])[:12]:
                sym=''.join(c for c in str(r.get('stk_cd') or '') if c.isdigit())[:6]
                if not sym or sym not in self.universe: continue
                if venue=='NXT' and not self.universe[sym].get('nxt_enabled'): continue
                self._rest_observe(sym,venue,r); bucket.append(sym+suffix)
        except Exception as e:
            self.errors.append(f'discovery:{api}:{type(e).__name__}')
        return bucket

    def _sector_first_discovery(self,buckets,limit):
        """Order ranking-discovered symbols as market -> sector -> laggard stock.

        All ranking buckets are gathered first. Sector strength is then estimated from
        breadth, source diversity and the share of still-unextended (-1.5~+2.5%) names.
        This changes transport priority only; final PRE hard gates remain in Scorer.
        """
        hits={}
        for bi,b in enumerate(buckets):
            for wire in b:
                hits.setdefault(wire,set()).add(bi)
        sector_rows={}
        for wire,sources in hits.items():
            st=self._wire_state(wire)
            if st is None: continue
            cr=st.rest_change_rate
            sec=(st.market,st.sector)
            sector_rows.setdefault(sec,[]).append((wire,cr,len(sources)))
        scored=[]
        for sec,rows in sector_rows.items():
            n=len(rows)
            if n < self.s.sector_discovery_min_sample: continue
            known=[float(cr) for _,cr,_ in rows if cr is not None]
            positive=sum(1 for x in known if x>0)/max(len(known),1)
            lag=sum(1 for x in known if self.s.early_hidden_gem_change_min<=x<=self.s.sector_discovery_laggard_max_change)/max(len(known),1)
            src=sum(src for _,_,src in rows)/max(n,1)
            # Breadth + low-extension participation are more important than raw leader return.
            score=min(100.0,n*6.0+positive*22.0+lag*42.0+min(src,3.0)/3.0*18.0)
            scored.append((score,sec,rows))
        scored.sort(reverse=True,key=lambda x:x[0])
        self.discovery_sector_scores={f'{m}:{sec}':round(sc,1) for sc,(m,sec),_ in scored}
        out=[]
        for _,_,rows in scored:
            rows=sorted(rows,key=lambda x:(
                1 if x[1] is not None and self.s.early_hidden_gem_change_min<=x[1]<=self.s.sector_discovery_laggard_max_change else 0,
                x[2],
                -(abs(float(x[1])) if x[1] is not None else 99.0)
            ),reverse=True)
            for wire,_,_ in rows:
                if wire not in out: out.append(wire)
                if len(out)>=limit: return out
        # Keep discovery robust if sector samples are sparse.
        for wire in interleave_unique(buckets,limit):
            if wire not in out: out.append(wire)
            if len(out)>=limit: break
        return out

    async def discovery_accelerator(self):
        venue=self.active_venue()
        if venue=='KRX': stex='1'
        elif venue=='NXT': stex='2'
        else: return
        suffix='' if venue=='KRX' else '_NX'; jobs=[]
        for mrkt in ('001','101'):
            calls=[
                ('ka10021',{'mrkt_tp':mrkt,'trde_tp':'1','sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':stex},'bid_req_sdnin'),
                ('ka10022',{'mrkt_tp':mrkt,'rt_tp':'1','tm_tp':'1','trde_qty_tp':'5','stk_cnd':'1','stex_tp':stex},'req_rt_sdnin'),
                ('ka10023',{'mrkt_tp':mrkt,'sort_tp':'2','tm_tp':'1','trde_qty_tp':'5','tm':'5','stk_cnd':'20','pric_tp':'0','stex_tp':stex},'trde_qty_sdnin'),
            ]
            for api,body,key in calls:
                jobs.append(self._ranking_bucket(api,body,key,venue,suffix))
        buckets=[x for x in await asyncio.gather(*jobs) if x]
        now=time.time()
        discovered=self._sector_first_discovery(buckets,max(self.s.ws_dynamic_max_items*3,60))
        self.discovery_pool=discovered
        for wire in discovered:
            st=self._wire_state(wire)
            sig=(round(float(st.rest_price or 0),4),round(float(st.rest_change_rate or 0),4)) if st else (0.0,0.0)
            m=self.discovery_meta.get(wire)
            if m is None:
                self.discovery_meta[wire]={'first_seen':now,'last_seen':now,'last_change':now,'sig':sig}
            else:
                m['last_seen']=now
                if sig!=m.get('sig'):
                    m['last_change']=now; m['sig']=sig
        # Garbage-collect symbols not rediscovered for one hour.
        for wire,m in list(self.discovery_meta.items()):
            if now-m.get('last_seen',now)>3600:
                self.discovery_meta.pop(wire,None)
        await self._apply_priority()

    async def refresh_coiled_seeds(self):
        if not self.s.feed_enabled: return
        buckets=[]; venue=self.active_venue()
        if venue is None:
            # Closed session: use the official after-close investor TR first. Avoid burning
            # three intraday-ranking calls every minute when the market is closed.
            try:
                closed=await after_close_investor_seed_symbols(self.rest,self.s.coiled_seed_limit)
                if closed: buckets.append(closed)
            except Exception as e:
                self.errors.append(f'coiled-seed:after-close:{type(e).__name__}')
            # Defensive fallback only if ka10066 yields no usable symbols.
            if not buckets:
                for org in ('9000','3000','6000'):
                    try: buckets.append(await investor_rank_symbols(self.rest,org,self.s.coiled_seed_limit))
                    except Exception as e: self.errors.append(f'coiled-seed:fallback:{org}:{type(e).__name__}')
        else:
            for org in ('9000','3000','6000'):
                try: buckets.append(await investor_rank_symbols(self.rest,org,self.s.coiled_seed_limit))
                except Exception as e: self.errors.append(f'coiled-seed:{org}:{type(e).__name__}')
        self.coiled_seed_symbols=interleave_unique(buckets,self.s.coiled_seed_limit)

    async def refresh_investors(self):
        now=time.time(); venue=self.active_venue()
        # Keep the same REST budget, but reserve slots for early/new candidates.
        actionable=[]; ranked=[]
        for c in self.raw_results:
            if venue is not None and c.venue!=venue: continue
            st=self.states.get(f'{c.symbol}:{c.venue}')
            if st is None: continue
            ranked.append(st)
            if c.stage in {'PRE-IGNITION','IGNITION IMMINENT'} or c.precursor_stage=='RELEASE READY':
                actionable.append(st)
        newcomer=[]
        for wire in interleave_unique([self._probe_wires(),self._fresh_discovery_wires(now)],8):
            st=self._wire_state(wire)
            if st is not None and (venue is None or st.venue==venue): newcomer.append(st)
        target=[]; seen=set()
        def add_many(xs,limit):
            added=0
            for st in xs:
                key=(st.symbol,st.venue)
                if key in seen: continue
                seen.add(key); target.append(st); added+=1
                if added>=limit or len(target)>=self.s.max_investor_symbols: break
        add_many(actionable,4)
        add_many(newcomer,4)
        add_many(ranked,max(0,self.s.max_investor_symbols-len(target)))
        for st in target[:self.s.max_investor_symbols]:
            try:
                xs=await intraday_investor_snapshots(self.rest,st.symbol,st.market,st.venue)
                existing={x.ts for x in st.investor_hist}
                for x in xs:
                    if x['ts'] not in existing:
                        st.investor_hist.append(InvestorSnapshot(ts=x['ts'],foreign=x['foreign'],institution=x['institution'],program=None,investment_trust=x.get('investment_trust'),pension=x.get('pension'),source_status=x['status']))
            except Exception as e: self.errors.append(f'investor:{st.symbol}:{type(e).__name__}')
        self.last_investor=time.time()

    async def refresh_daily_context(self):
        now=time.time(); scored=[]
        # Reuse the latest engine ranking rather than recomputing all scorer features.
        for c in self.raw_results:
            st=self.states.get(f'{c.symbol}:{c.venue}')
            if st is not None: scored.append((c.total_score,st))
        day=datetime.now(KST).strftime('%Y%m%d'); ordered=[]
        for sym in self.coiled_seed_symbols:
            st=self.states.get(f'{sym}:KRX')
            if st is None and sym in self.universe: st=self.state(sym,'KRX')
            if st is not None: ordered.append(st)
        ordered += [st for _,st in scored]
        for wire in self.ws.priority:
            st=self._wire_state(wire)
            if st is not None: ordered.append(st)
        seen=set()
        for st in ordered:
            if (st.symbol,st.venue) in seen: continue
            seen.add((st.symbol,st.venue))
            if len(seen)>self.s.daily_context_symbols: break
            try:
                b,_=await self.rest.post('ka10081','/api/dostk/chart',{'stk_cd':st.symbol,'base_dt':day,'upd_stkpc_tp':'1'})
                rows=b.get('stk_dt_pole_chart_qry',[]) or []; vals=[]; bars=[]
                for r in rows[:20]:
                    px=abs(num(r.get('cur_prc')) or 0); dt=str(r.get('dt') or '')
                    if px>0:
                        vals.append((dt,px))
                        bars.append({'date':dt,'close':px,'open':abs(num(r.get('open_pric')) or px),'high':abs(num(r.get('high_pric')) or px),'low':abs(num(r.get('low_pric')) or px),'volume':abs(num(r.get('trde_qty')) or 0),'turnover':abs(num(r.get('trde_prica')) or 0)})
                if not vals: continue
                st.daily_bars=bars
                # Weekend/holiday: use latest actual completed KRX bar date.
                latest_session=next((str(b.get('date') or '') for b in bars if str(b.get('date') or '').isdigit() and len(str(b.get('date') or ''))==8), day)
                try: st.daily_flows=await daily_investor_rows(self.rest,st.symbol,latest_session,'KRX')
                except Exception as e: self.errors.append(f'dailyflow:{st.symbol}:{type(e).__name__}')
                todays=[px for dt,px in vals if dt==day]; prior=[px for dt,px in vals if dt!=day]
                canonical_prev=prior[0] if prior else (vals[0][1] if vals[0][0]!=day else None)
                if canonical_prev: st.prev_close=canonical_prev
                current=st.price or (todays[0] if todays else vals[0][1])
                c1=(current/prior[0]-1)*100 if len(prior)>=1 else None; c3=(current/prior[2]-1)*100 if len(prior)>=3 else None; c5=(current/prior[4]-1)*100 if len(prior)>=5 else None; c15=(current/prior[14]-1)*100 if len(prior)>=15 else None
                self.scorer.daily_changes[st.symbol]=(c1,c3,c5,c15)
                # Daily chart is KRX canonical context; never call it an NXT live cross-source price.
                if st.venue=='KRX' and todays:
                    st.rest_price=todays[0]; st.rest_price_ts=time.time(); st.rest_venue='KRX'
            except Exception as e: self.errors.append(f'daily:{st.symbol}:{type(e).__name__}')
        self.last_daily=time.time()

    async def urgent_baseline_bootstrap(self):
        venue=self.active_venue()
        if venue is None or not self.urgent_baseline_queue: return
        now=time.time()
        if now-self.last_urgent_baseline < self.s.urgent_baseline_cooldown_sec: return
        wire=self.urgent_baseline_queue.popleft(); self.urgent_baseline_queued.discard(wire)
        st=self._wire_state(wire)
        if st is None or st.venue!=venue: return
        key=(st.symbol,st.venue); today=datetime.now(KST).date().isoformat()
        if key in self.baseline_bootstrapped: return
        self.last_urgent_baseline=now
        try:
            if self.baseline.history_days(st.symbol,st.venue,today)>=self.s.tod_min_baseline_days:
                self.baseline_bootstrapped.add(key); return
            rows=await minute_baseline_rows(self.rest,st.symbol,st.venue,self.s.baseline_bootstrap_max_pages,self.s.baseline_bootstrap_target_days)
            prior=[]
            for ts,amount in rows:
                if datetime.fromtimestamp(ts,KST).date().isoformat()!=today:
                    prior.append((st.symbol,st.venue,ts,amount))
            self.baseline.record_many(prior)
            if self.baseline.history_days(st.symbol,st.venue,today)>=self.s.tod_min_baseline_days:
                self.baseline_bootstrapped.add(key)
        except Exception as e:
            self.errors.append(f'urgent-baseline:{st.symbol}:{type(e).__name__}:{e}')

    async def bootstrap_baselines(self):
        """Cold-start ToD baseline for a tiny, bounded set of active candidates."""
        venue=self.active_venue()
        if venue is None: return
        wires=interleave_unique([self._probe_wires(),self._fresh_discovery_wires(),self.rank_priority],max(6,self.s.baseline_bootstrap_symbols_per_cycle*5))
        todo=[]
        for wire in wires:
            st=self._wire_state(wire)
            if st is None or st.venue!=venue: continue
            key=(st.symbol,st.venue)
            if key in self.baseline_bootstrapped: continue
            todo.append(st)
            if len(todo)>=self.s.baseline_bootstrap_symbols_per_cycle: break
        today=datetime.now(KST).date().isoformat()
        for st in todo:
            try:
                if self.baseline.history_days(st.symbol,st.venue,today)>=self.s.tod_min_baseline_days:
                    self.baseline_bootstrapped.add((st.symbol,st.venue)); continue
                rows=await minute_baseline_rows(self.rest,st.symbol,st.venue,self.s.baseline_bootstrap_max_pages,self.s.baseline_bootstrap_target_days)
                prior=[]; days=set()
                for ts,amount in rows:
                    day=datetime.fromtimestamp(ts,KST).date().isoformat()
                    if day==today: continue
                    prior.append((st.symbol,st.venue,ts,amount)); days.add(day)
                self.baseline.record_many(prior)
                total_days=self.baseline.history_days(st.symbol,st.venue,today)
                if total_days>=self.s.tod_min_baseline_days:
                    self.baseline_bootstrapped.add((st.symbol,st.venue))
                else:
                    self.errors.append(f'baseline_bootstrap:{st.symbol}:{st.venue}:days={total_days}')
            except Exception as e:
                self.errors.append(f'baseline_bootstrap:{st.symbol}:{type(e).__name__}')

    async def baseline_flush(self):
        now=time.time(); d=datetime.fromtimestamp(now,KST).replace(second=0,microsecond=0)
        wanted={(d-timedelta(minutes=i)).hour*100+(d-timedelta(minutes=i)).minute for i in (0,1,2)}
        batch=[]
        for st in list(self.states.values()):
            for minute in wanted:
                amt=st.minute_amount.get(minute)
                if not amt: continue
                hh,mm=divmod(minute,100); ts=d.replace(hour=hh,minute=mm).timestamp()
                batch.append((st.symbol,st.venue,ts,amt))
        try: self.baseline.record_many(batch)
        except Exception as e: self.errors.append(f'baseline:{type(e).__name__}')

    def evict_states(self):
        now=time.time(); protected=set(self.ws.items())
        def wire(st): return st.symbol+'_NX' if st.venue=='NXT' else st.symbol
        stale=[k for k,st in self.states.items() if wire(st) not in protected and now-max(st.last_receive_ts,st.first_seen_ts)>self.s.state_ttl_sec]
        for k in stale: self.states.pop(k,None)
        if len(self.states)>self.s.max_state_symbols:
            candidates=sorted((max(st.last_receive_ts,st.first_seen_ts),k) for k,st in self.states.items() if wire(st) not in protected)
            for _,k in candidates[:max(0,len(self.states)-self.s.max_state_symbols)]: self.states.pop(k,None)

    def _signal_changed(self,c):
        if c.stage not in {'EARLY HIDDEN GEM','SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT','IGNITION'}: return False
        k=(c.symbol,c.venue); now=time.time(); prev=self.signal_last.get(k)
        absorb_surge=bool(prev and c.foreign_absorb_ratio is not None and prev.get('absorb') is not None and c.foreign_absorb_ratio>=prev['absorb']+0.25)
        accel_surge=bool(c.absorb_acceleration is not None and c.absorb_acceleration>=0.15)
        sell_decel=bool(prev and c.institution_sell_velocity is not None and prev.get('inst_decel') is not None and c.institution_sell_velocity>=prev['inst_decel']+self.s.minimum_inst_sell_value*0.5)
        vwap_rebreak=bool(prev and c.vwap_state=='ABOVE' and prev.get('vwap')!='ABOVE')
        breadth_surge=bool(prev and c.sector_breadth is not None and prev.get('breadth') is not None and c.sector_breadth>=prev['breadth']+10)
        allow=(prev is None or now-prev['ts']>=self.s.repeat_ttl_sec or c.stage!=prev['stage'] or c.detection_model!=prev.get('model') or c.total_score>=prev['score']+8 or (c.price_hold=='PASS' and prev.get('hold')!='PASS') or absorb_surge or accel_surge or sell_decel or vwap_rebreak or breadth_surge)
        if allow:
            self.signal_last[k]={'ts':now,'stage':c.stage,'model':c.detection_model,'score':c.total_score,'hold':c.price_hold,'absorb':c.foreign_absorb_ratio,'inst_decel':c.institution_sell_velocity,'vwap':c.vwap_state,'breadth':c.sector_breadth}
        return allow

    def _coiled_changed(self,c):
        prev=self.coiled_last.get(c.symbol); now=time.time()
        order={'WATCH':0,'BUILDING':1,'COILED':2,'PRESSURE ABSORBED':3,'RELEASE READY':4}
        promoted=bool(c.promoted_to_now and not (prev or {}).get('promoted'))
        stage_up=bool(prev is None or order.get(c.stage,0)>order.get(prev.get('stage'),0))
        stronger=bool(prev and c.score>=prev.get('score',0)+8)
        allow=promoted or stage_up or stronger
        self.coiled_last[c.symbol]={'ts':now,'stage':c.stage,'score':c.score,'promoted':c.promoted_to_now}
        return allow, promoted

    def _precursor_changed(self,c):
        if c.precursor_stage not in {'PRESSURE ABSORBED','RELEASE READY'}:
            return False
        prev=self.precursor_last.get((c.symbol,c.venue)); now=time.time()
        order={'OBSERVE':0,'COILED':1,'PRESSURE ABSORBED':2,'RELEASE READY':3}
        allow=bool(prev is None or order.get(c.precursor_stage,0)>order.get(prev.get('stage'),0) or
                   (c.pressure_release_score is not None and c.pressure_release_score>=prev.get('score',0)+8))
        self.precursor_last[(c.symbol,c.venue)]={'ts':now,'stage':c.precursor_stage,'score':c.pressure_release_score or 0}
        return allow

    async def _push_coiled(self,c,promoted=False):
        if not self.s.push_enabled or not self.s.vapid_private_key or not self.s.vapid_public_key: return
        try: from pywebpush import webpush
        except Exception: return
        title=('COILED → PRE · ' if promoted else f'{c.stage} 1–2D · ')+(c.name or c.symbol)
        body=f'{c.change_rate or 0:+.2f}% · {c.core_actor} · 응축 {c.score:.0f} · PR {c.pressure_release_score or 0:.0f} · 돌파거리 {c.breakout_distance or 0:.1f}%'
        payload=json.dumps({'title':title,'body':body,'url':f'/?symbol={c.symbol}&horizon=1-2d','tag':f'pulse-coiled-{c.symbol}'},ensure_ascii=False)
        for sub in self.signal_store.subscriptions():
            try: await asyncio.to_thread(webpush,subscription_info=sub,data=payload,vapid_private_key=self.s.vapid_private_key,vapid_claims={'sub':self.s.vapid_subject})
            except Exception: pass

    async def _push_precursor(self,c):
        # Keep alerts sparse: PRESSURE ABSORBED is history-only; RELEASE READY is push-worthy.
        if c.precursor_stage!='RELEASE READY' or not self.s.push_enabled or not self.s.vapid_private_key or not self.s.vapid_public_key:
            return
        try: from pywebpush import webpush
        except Exception: return
        payload=json.dumps({'title':f'RELEASE READY · {c.name or c.symbol}',
                            'body':f'{c.change_rate:+.2f}% · 충격감쇠 {c.price_impact_decay or 0:.0f} · 수급지연 {c.flow_price_lag or 0:.0f} · 방출거리 {c.release_distance_score or 0:.0f}',
                            'url':f'/?symbol={c.symbol}&venue={c.venue}',
                            'tag':f'pulse-release-{c.symbol}-{c.venue}'},ensure_ascii=False)
        for sub in self.signal_store.subscriptions():
            try:
                await asyncio.to_thread(webpush,subscription_info=sub,data=payload,vapid_private_key=self.s.vapid_private_key,vapid_claims={'sub':self.s.vapid_subject})
            except Exception:
                pass

    async def _push(self,c):
        if not self.s.push_enabled or not self.s.vapid_private_key or not self.s.vapid_public_key: return
        try: from pywebpush import webpush
        except Exception: self.errors.append('push:dependency'); return
        payload=json.dumps({'title':f'{c.stage} · {c.name or c.symbol}','body':f'{c.current_price:,.0f}원 {c.change_rate:+.2f}% · {c.detection_model} · PRE {c.ignition_probability:.0f} · SCORE {c.total_score:.0f}','url':f'/?symbol={c.symbol}&venue={c.venue}','tag':f'pulse-edge-{c.symbol}-{c.venue}'},ensure_ascii=False)
        for sub in self.signal_store.subscriptions():
            try:
                await asyncio.to_thread(webpush,subscription_info=sub,data=payload,vapid_private_key=self.s.vapid_private_key,vapid_claims={'sub':self.s.vapid_subject})
            except Exception as e:
                status=getattr(getattr(e,'response',None),'status_code',None)
                if status in (404,410): self.signal_store.drop_subscription(sub.get('endpoint',''))
                else: self.errors.append(f'push:{type(e).__name__}')

    def _update_signal_performance(self,now=None):
        n=time.time() if now is None else float(now)
        if n-self.last_performance_update<30.0: return
        self.last_performance_update=n
        prices={(st.symbol,st.venue):float(st.price) for st in self.states.values() if st.price is not None and st.price>0}
        if prices:
            self.signal_store.update_performance(prices,n)

    async def evaluate(self):
        eval_start=time.perf_counter(); now=time.time()
        # Coverage is counted only while the websocket is connected and globally recent.
        # Thus no-trade can be accepted without converting a feed gap into a fake zero.
        if self.s.feed_enabled and self.ws.connected and self.ws.last_message and now-self.ws.last_message<=5.0:
            d=datetime.fromtimestamp(now,KST); minute=d.hour*100+d.minute
            for wire in self.ws.items():
                st_cov=self._wire_state(wire)
                if st_cov is not None:
                    st_cov.minute_feed_coverage[minute]=min(120,int(st_cov.minute_feed_coverage.get(minute,0) or 0)+1)
                    if len(st_cov.minute_feed_coverage)>120:
                        for k in sorted(st_cov.minute_feed_coverage)[:-90]:
                            st_cov.minute_feed_coverage.pop(k,None)
        raw=self.scorer.rank(self.states); self.raw_results=raw; self.last_eval=now; self.eval_seq+=1
        self.last_candidate_fingerprint='|'.join(
            f'{c.symbol}:{c.venue}:{c.stage}:{round(float(c.total_score or 0),2)}'
            for c in raw[:10]
        )
        self.coiled_results=rank_coiled(self.states,{c.symbol for c in raw if c.stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT'}},self.s.coiled_top_limit)
        for cc in self.coiled_results:
            changed,promoted=self._coiled_changed(cc)
            if changed:
                payload=cc.to_dict(); payload.update({'venue':'KRX','horizon':'1-2D','stage':('COILED → PRE' if promoted else cc.stage),'total_score':cc.score,'ignition_probability':None})
                self.signal_store.add_payload(cc.symbol,'KRX',payload['stage'],cc.score,payload)
                if promoted:
                    now_payload=dict(payload); now_payload['horizon']='TRANSITION'; now_payload['transition_from']='1-2D'; now_payload['transition_to']='NOW'
                    self.signal_store.add_payload(cc.symbol,'KRX','COILED → NOW',cc.score,now_payload)
                # Push only strong 1–2D states or an actual promotion; BUILDING/COILED/ABSORBED remain history-only.
                if promoted:
                    task=asyncio.create_task(self._push_coiled(cc,True)); self.push_tasks.add(task); task.add_done_callback(self.push_tasks.discard)
        if self.s.feed_enabled:
            probes=self._probe_wires(); fresh=self._fresh_discovery_wires(now); focus=[]
            actionable=self._actionable_wires()
            protected=[c.symbol+'_NX' if c.venue=='NXT' else c.symbol for c in raw
                       if (c.symbol+'_NX' if c.venue=='NXT' else c.symbol) in actionable]
            strongest=[c.symbol+'_NX' if c.venue=='NXT' else c.symbol for c in raw]
            newcomer_slots=min(max(1,int(self.s.quote_newcomer_slots)),max(1,self.s.ws_quote_focus_items-2))
            # Quote capacity stays fixed at 4: 1 actionable + 1 strongest + 2 newcomer/probe.
            lanes=[protected[:1],strongest[:1],interleave_unique([probes,fresh],newcomer_slots)]
            for lane in lanes:
                for x in lane:
                    if x not in focus: focus.append(x)
            for x in strongest+probes+fresh:
                if x not in focus: focus.append(x)
                if len(focus)>=self.s.ws_quote_focus_items: break
            focus=tuple(focus[:self.s.ws_quote_focus_items])
            if focus!=self.quote_focus_key and now-self.last_quote_focus>=3:
                self.quote_focus_key=focus; self.last_quote_focus=now; await self.ws.set_quote_focus(list(focus))
        for c in raw:
            if self._precursor_changed(c):
                payload=c.to_dict(); payload.update({'horizon':'NOW-PRECURSOR','stage':c.precursor_stage,'total_score':c.pressure_release_score,'ignition_probability':c.ignition_probability})
                self.signal_store.add_payload(c.symbol,c.venue,c.precursor_stage,c.pressure_release_score or 0,payload)
                # Sparse early alert: PRESSURE ABSORBED stays history-only; RELEASE READY pushes once on progression.
                if c.precursor_stage=='RELEASE READY':
                    task=asyncio.create_task(self._push_precursor(c)); self.push_tasks.add(task); task.add_done_callback(self.push_tasks.discard)
            if self._signal_changed(c):
                payload=c.to_dict(); payload['horizon']='NOW'
                self.signal_store.add_payload(c.symbol,c.venue,c.stage,c.total_score,payload)
                if c.stage in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'}:
                    task=asyncio.create_task(self._push(c)); self.push_tasks.add(task); task.add_done_callback(self.push_tasks.discard)
        if not self.results or now-self.last_rank_commit>=self.s.rank_commit_sec:
            self.results=raw; self.last_rank_commit=now
        self._update_signal_performance(now)
        self.eval_ms.append((time.perf_counter()-eval_start)*1000.0)

    async def _periodic(self,name,interval,fn,initial=0.0):
        if initial>0: await asyncio.sleep(initial)
        while not self._stopping:
            start=time.time(); self.job_health.setdefault(name,{})['last_start']=start
            try:
                await fn(); self.job_health[name]['last_ok']=time.time(); self.job_health[name]['last_error']=None
            except asyncio.CancelledError: raise
            except Exception as e:
                self.job_health[name]['last_error']=f'{type(e).__name__}:{e}'; self.errors.append(f'job:{name}:{type(e).__name__}:{e}')
            self.job_health[name]['last_duration']=round(time.time()-start,3)
            await asyncio.sleep(max(0.2,interval-(time.time()-start)))

    @staticmethod
    def _pct(xs,p):
        if not xs: return None
        ys=sorted(float(x) for x in xs); i=min(len(ys)-1,max(0,int(round((len(ys)-1)*p))))
        return round(ys[i],3)

    async def _event_loop_monitor(self):
        interval=max(0.1,float(self.s.event_loop_probe_sec))
        target=time.perf_counter()+interval
        while not self._stopping:
            await asyncio.sleep(interval)
            now=time.perf_counter()
            self.event_loop_lag_ms.append(max(0.0,(now-target)*1000.0))
            target=now+interval

    async def _evaluate_loop(self):
        while not self._stopping:
            start=time.time()
            try: await self.evaluate()
            except asyncio.CancelledError: raise
            except Exception as e: self.errors.append(f'evaluate:{type(e).__name__}:{e}')
            await asyncio.sleep(max(0.05,self.s.evaluate_interval_sec-(time.time()-start)))

    async def start(self):
        if self.s.feed_enabled:
            await self.refresh_universe(); self.tasks.append(asyncio.create_task(self.ws.run(),name='kiwoom-ws'))
            self.tasks += [
                asyncio.create_task(self._periodic('background',self.s.background_rotate_sec,self.rotate_background,1.0),name='background-rotation'),
                asyncio.create_task(self._periodic('discovery',self.s.scan_interval_sec,self.discovery_accelerator,2.0),name='discovery'),
                asyncio.create_task(self._periodic('investor',self.s.investor_refresh_sec,self.refresh_investors,5.0),name='investor'),
                asyncio.create_task(self._periodic('coiled-seeds',self.s.coiled_refresh_sec,self.refresh_coiled_seeds,3.0),name='coiled-seeds'),
                asyncio.create_task(self._periodic('daily',self.s.daily_context_refresh_sec,self.refresh_daily_context,8.0),name='daily-context'),
                asyncio.create_task(self._periodic('baseline',self.s.baseline_flush_sec,self.baseline_flush,10.0),name='baseline'),
                asyncio.create_task(self._periodic('baseline-bootstrap',self.s.baseline_bootstrap_interval_sec,self.bootstrap_baselines,15.0),name='baseline-bootstrap'),
                asyncio.create_task(self._periodic('urgent-baseline',5.0,self.urgent_baseline_bootstrap,6.0),name='urgent-baseline'),
                asyncio.create_task(self._periodic('evict',60.0,self._evict_async,60.0),name='evict'),
                asyncio.create_task(self._periodic('universe',self.s.universe_refresh_sec,self.refresh_universe,self.s.universe_refresh_sec),name='universe-refresh'),
            ]
        self.tasks.append(asyncio.create_task(self._evaluate_loop(),name='engine-evaluate'))
        self.tasks.append(asyncio.create_task(self._event_loop_monitor(),name='event-loop-monitor'))

    async def _evict_async(self): self.evict_states()

    async def stop(self):
        self._stopping=True; self.ws.stop_evt.set()
        for t in self.tasks: t.cancel()
        await asyncio.gather(*self.tasks,return_exceptions=True)
        if self.push_tasks:
            try: await asyncio.wait(self.push_tasks,timeout=3.0)
            except Exception: pass
        try: await self.rest.close()
        except Exception: pass
        try: await self.auth.close()
        except Exception: pass
        try: self.signal_store.close()
        except Exception: pass
        try: self.baseline.close()
        except Exception: pass

    def readiness(self):
        h=self.health(); venue=h.get('active_venue'); checks={}
        checks['universe']=h.get('universe_count',0)>=500 if self.s.feed_enabled else True
        checks['ws_connected']=bool(h.get('ws_connected')) if self.s.feed_enabled else True
        ws_age=h.get('ws_last_message_age_sec')
        checks['ws_recent']=(ws_age is not None and ws_age<=30) if self.s.feed_enabled and venue else True
        trade_age=(h.get('channel_age_sec') or {}).get('trade')
        checks['trade_recent']=(trade_age is not None and trade_age<=15) if self.s.feed_enabled and venue else True
        if not self.s.feed_enabled:
            checks['market_context']=True
        elif venue=='KRX':
            ages=h.get('market_index_age_sec') or {}
            checks['market_context']=any(v is not None and v<=60 for v in ages.values())
        elif venue=='NXT':
            prox=h.get('nxt_market_proxy') or {}
            checks['market_context']=any((x or {}).get('sample',0)>=self.s.nxt_market_proxy_min_sample and (x or {}).get('age_sec') is not None and (x or {}).get('age_sec')<=self.s.nxt_market_proxy_stale_sec for x in prox.values())
        else:
            # Closed/gap sessions cannot prove market ticks; do not fabricate a live PASS.
            checks['market_context']=True
        ready=all(checks.values())
        return {'ready':ready,'release':self.s.release,'feed_enabled':self.s.feed_enabled,'active_venue':venue,'checks':checks,'live_market_verified':bool(venue and ready),'note':None if venue else 'MARKET_CLOSED_OR_SESSION_GAP_LIVE_TICK_NOT_VERIFIABLE'}

    def ingest_news_signal(self,symbol:str,hot:bool=False,catalyst:bool=False,risk:str|None=None):
        # Adapter only: without a real external news collector the state remains UNAVAILABLE.
        now=time.time(); touched=0
        for st in self.states.values():
            if st.symbol!=symbol: continue
            st.news_ts=now; st.news_hot=bool(hot); st.news_catalyst=bool(catalyst)
            st.news_risk=str(risk or ('HIGH' if hot else 'LOW')); touched+=1
        return touched

    def health(self):
        now=time.time(); a=sum(1 for x in self.results if x.suitability=='A'); b=sum(1 for x in self.results if x.suitability=='B')
        market_age={k:(round(now-v,2) if v else None) for k,v in self.scorer.market_ts.items()}
        channel={'trade':None,'quote':None,'program':None}
        items=[self._wire_state(x) for x in self.ws.items()]; items=[x for x in items if x]
        if items:
            vals=[now-x.last_trade_receive_ts for x in items if x.last_trade_receive_ts]; channel['trade']=round(min(vals),3) if vals else None
            vals=[now-x.last_quote_receive_ts for x in items if x.last_quote_receive_ts]; channel['quote']=round(min(vals),3) if vals else None
            vals=[now-x.last_program_receive_ts for x in items if x.last_program_receive_ts]; channel['program']=round(min(vals),3) if vals else None
        latency={'event_loop_lag_ms_p95':self._pct(self.event_loop_lag_ms,0.95),
                 'event_handler_ms_p95':self._pct(self.event_handler_ms,0.95),
                 'feed_event_age_ms_p95':self._pct(self.feed_event_age_ms,0.95),
                 'evaluate_ms_p95':self._pct(self.eval_ms,0.95)}
        return {'ok':True,'runtime_safety_release':self.s.release,'feed_enabled':self.s.feed_enabled,'active_venue':self.active_venue(),'ws_connected':self.ws.connected,
                'ws_last_message_age_sec':round(now-self.ws.last_message,3) if self.ws.last_message else None,'ws_last_error':self.ws.last_error or None,'universe_count':len(self.universe),
                'observed_states':len(self.states),'candidate_count':len(self.results),'raw_candidate_count':len(self.raw_results),'a_count':a,'b_count':b,'quote_focus':list(self.quote_focus_key),
                'probe_promoted':len(self._probe_wires()),'coiled_count':len(self.coiled_results),'rank_age_sec':round(now-self.last_rank_commit,2) if self.last_rank_commit else None,
                'eval_seq':self.eval_seq,'last_eval_ts':round(self.last_eval,3) if self.last_eval else None,'candidate_fingerprint':self.last_candidate_fingerprint,
                'latest_trade_event_ts':round(self.last_trade_event_seen,3) if self.last_trade_event_seen else None,'session_date_kst':datetime.now(KST).date().isoformat(),'market_index_age_sec':market_age,
                'nxt_market_proxy':{m:{'change':self.scorer.nxt_market_change.get(m),'sample':self.scorer.nxt_market_sample.get(m,0),'age_sec':round(now-self.scorer.nxt_market_ts.get(m,0),2) if self.scorer.nxt_market_ts.get(m) else None} for m in ('KOSPI','KOSDAQ')},
                'channel_age_sec':channel,'latency':latency,'discovery_pool_count':len(self.discovery_pool),'fresh_discovery_count':len(self._fresh_discovery_wires(now)),
                'priority_demotions':self.priority_demotions,'discovery_sector_scores':self.discovery_sector_scores,'urgent_baseline_queue':len(self.urgent_baseline_queue),'probe_rest_confirmed_recent':sum(1 for t in self.probe_rest_confirm_ts.values() if now-t<=60),'feed_coverage_symbols':sum(1 for st in self.states.values() if st.minute_feed_coverage),'coiled_seed_count':len(self.coiled_seed_symbols),'jobs':self.job_health,'history_count':self.signal_store.count(),'history_now_count':len(self.signal_store.recent(self.s.now_history_limit,'NOW')),'history_coiled_count':len(self.signal_store.recent(self.s.coiled_history_limit,'1-2D')),'performance_count':self.signal_store.performance_count(),'push_subscriptions':self.signal_store.subscription_count(),'errors':list(self.errors)[-10:]}
