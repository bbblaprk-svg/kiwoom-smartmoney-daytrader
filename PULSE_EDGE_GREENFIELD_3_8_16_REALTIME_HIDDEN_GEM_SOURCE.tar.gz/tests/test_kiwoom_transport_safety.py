from pathlib import Path


def test_dynamic_ws_groups_replace_membership_not_accumulate():
    src=Path('pulse_edge/feed/kiwoom.py').read_text()
    block=src[src.index('    async def refresh(self):'):src.index('    async def run(self):')]
    assert "'refresh':'0'" in block
    assert "'refresh':'1'" not in block
    assert "['0B','0w']" in block
    assert "['0D']" in block


def test_rest_only_zero_is_success():
    src=Path('pulse_edge/feed/kiwoom.py').read_text()
    block=src[src.index('class Rest:'):src.index('async def load_universe')]
    assert "not in (0,20)" not in block
    assert "!= 0" in block
