import os, tempfile
from datetime import datetime
from types import SimpleNamespace
from zoneinfo import ZoneInfo

from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime

KST=ZoneInfo('Asia/Seoul')


def _runtime(tmp):
    return Runtime(Settings(
        feed_enabled=False,
        push_enabled=False,
        data_dir=tmp,
        baseline_db=os.path.join(tmp,'base.sqlite3'),
        history_db=os.path.join(tmp,'hist.sqlite3'),
    ))


def _candidate(symbol='123456', stage='WATCH', score=61, price=8190, promoted=False):
    return SimpleNamespace(symbol=symbol, stage=stage, score=score,
                           current_price=price, promoted_to_now=promoted)


def _legacy_history(rt, symbol='123456', stage='WATCH', score=61, price=8190,
                    ts=None):
    rt.signal_store.add_payload(symbol,'KRX',stage,score,{
        'symbol':symbol,'name':'TEST','venue':'KRX','horizon':'1-2D',
        'stage':stage,'total_score':score,'current_price':price,
    })
    if ts is not None:
        with rt.signal_store.lock:
            rt.signal_store.db.execute('UPDATE signals SET ts=? WHERE id=(SELECT MAX(id) FROM signals)',(float(ts),))
            rt.signal_store.db.commit()


def test_restart_does_not_duplicate_same_closed_session_coiled_history():
    with tempfile.TemporaryDirectory() as tmp:
        rt=_runtime(tmp)
        # Legacy record written on Saturday from Friday's completed KRX daily context.
        sat=datetime(2026,9,12,21,21,tzinfo=KST).timestamp()
        _legacy_history(rt,ts=sat)
        rt.coiled_last={}
        changed,promoted=rt._coiled_changed(_candidate(),'20260911')
        assert changed is False
        assert promoted is False
        rt.signal_store.close(); rt.baseline.close()


def test_new_completed_trade_session_is_allowed_once():
    with tempfile.TemporaryDirectory() as tmp:
        rt=_runtime(tmp)
        sat=datetime(2026,9,12,21,21,tzinfo=KST).timestamp()
        _legacy_history(rt,ts=sat)
        rt.coiled_last={}
        changed,_=rt._coiled_changed(_candidate(),'20260914')
        assert changed is True
        rt.signal_store.close(); rt.baseline.close()


def test_stage_upgrade_or_score_plus_eight_still_records():
    with tempfile.TemporaryDirectory() as tmp:
        rt=_runtime(tmp)
        sat=datetime(2026,9,12,21,21,tzinfo=KST).timestamp()
        _legacy_history(rt,ts=sat)
        rt.coiled_last={}
        changed,_=rt._coiled_changed(_candidate(stage='BUILDING',score=61),'20260911')
        assert changed is True
        rt.coiled_last={}
        changed,_=rt._coiled_changed(_candidate(stage='WATCH',score=69),'20260911')
        assert changed is True
        rt.signal_store.close(); rt.baseline.close()
