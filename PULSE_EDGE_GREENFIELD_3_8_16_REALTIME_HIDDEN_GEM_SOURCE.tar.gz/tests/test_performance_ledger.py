import time, tempfile
from pathlib import Path
from pulse_edge.storage.signals import SignalStore

def test_now_performance_ledger_without_ui_change():
    with tempfile.TemporaryDirectory() as td:
        st=SignalStore(str(Path(td)/"h.sqlite3"),400,200,200)
        now=time.time()
        st.add_payload("123456","KRX","PRE-IGNITION",90,{"horizon":"NOW","current_price":10000})
        # Shift signal time backward to make 10m/30m marks deterministic.
        st.db.execute("UPDATE signal_outcomes SET signal_ts=?",(now-1900,)); st.db.commit()
        st.update_performance({("123456","KRX"):10500},now)
        row=st.db.execute("SELECT mfe_pct,mae_pct,ret_10m,ret_30m FROM signal_outcomes").fetchone()
        assert row[0]>=5 and row[1]<=0 and row[2]>=5 and row[3]>=5
        assert st.performance_count()==1
        st.close()
