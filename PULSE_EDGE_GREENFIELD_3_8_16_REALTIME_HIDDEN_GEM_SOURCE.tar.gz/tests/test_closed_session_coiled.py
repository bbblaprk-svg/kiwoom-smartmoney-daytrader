import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo
from pulse_edge.feed.kiwoom import after_close_investor_seed_symbols
from pulse_edge.runtime import venue_for_kst

class FakeRest:
    async def post(self, api, path, body, cont=None, next_key=None):
        assert api=='ka10066'
        assert path=='/api/dostk/mrkcond'
        assert body=={'mrkt_tp':'000','amt_qty_tp':'1','trde_tp':'0','stex_tp':'1'}
        return {'any_record_name':[{'stk_cd':'005930'},{'stk_cd':'000660'},{'stk_cd':'005930'}]},{}

def test_saturday_is_closed_but_after_close_seed_works():
    kst=ZoneInfo('Asia/Seoul')
    assert venue_for_kst(datetime(2026,9,12,12,0,tzinfo=kst)) is None
    got=asyncio.run(after_close_investor_seed_symbols(FakeRest(),30))
    assert got==['005930','000660']

def test_closed_session_coiled_paths_present():
    from pathlib import Path
    r=Path('pulse_edge/runtime.py').read_text()
    m=Path('pulse_edge/main.py').read_text()
    assert "if venue is None:" in r
    assert 'after_close_investor_seed_symbols' in r
    assert "source':'HISTORY_SNAPSHOT'" in m

def test_daily_only_coiled_candidate_scores_on_closed_session_inputs():
    from pulse_edge.models import SymbolState
    from pulse_edge.engine.coiled import score_coiled
    st=SymbolState(symbol='123456',name='TEST',market='KOSDAQ',venue='KRX')
    bars=[]
    for i in range(12):
        close=100.0-(0.2*i)
        if i<3:
            hi=close*1.005; lo=close*0.995; turn=180_000_000
        else:
            hi=close*1.02; lo=close*0.98; turn=100_000_000
        bars.append({'date':f'202609{11-i:02d}','close':close,'open':close*1.002,'high':hi,'low':lo,'volume':100000,'turnover':turn})
    st.daily_bars=bars
    st.daily_flows=[
      {'date':'20260911','foreign':200_000_000,'investment_trust':300_000_000,'pension':200_000_000},
      {'date':'20260910','foreign':150_000_000,'investment_trust':200_000_000,'pension':150_000_000},
      {'date':'20260909','foreign':100_000_000,'investment_trust':100_000_000,'pension':100_000_000},
    ]
    c=score_coiled(st,set())
    assert c is not None
    assert c.score>=60
    assert c.stage in {'BUILDING','COILED','PRESSURE ABSORBED','RELEASE READY'}


def test_runtime_uses_string_state_key_for_closed_session_daily_context():
    from pathlib import Path
    r=Path('pulse_edge/runtime.py').read_text()
    assert "self.states.get(f'{sym}:KRX')" in r
    assert "self.states.get((sym,'KRX'))" not in r

def test_closed_session_prefers_after_close_seed_before_intraday_fallback():
    from pathlib import Path
    r=Path('pulse_edge/runtime.py').read_text()
    block=r[r.index('    async def refresh_coiled_seeds'):r.index('    async def refresh_investors')]
    assert block.index('after_close_investor_seed_symbols') < block.index('investor_rank_symbols')
    assert "if venue is None:" in block

def test_health_exposes_coiled_seed_count_for_deploy_truth():
    from pathlib import Path
    r=Path('pulse_edge/runtime.py').read_text()
    assert "'coiled_seed_count':len(self.coiled_seed_symbols)" in r
