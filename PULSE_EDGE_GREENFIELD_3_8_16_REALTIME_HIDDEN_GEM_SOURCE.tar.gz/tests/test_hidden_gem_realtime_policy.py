from pathlib import Path
from pulse_edge.config import Settings

def test_market_red_is_fresh_entry_gate_only():
    s=Settings()
    assert s.market_red_threshold_pct==-1.5
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'market_red=bool(' in src
    assert 'not market_red and not sensor_only' in src
    assert "if market_red or sensor_only: suitability='WATCH'" in src

def test_leader_and_mega_cap_are_sensor_only_for_fresh_entry():
    s=Settings()
    assert s.hidden_gem_sensor_market_cap_krw==5_000_000_000_000.0
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'effective_leader_sensor=bool(' in src
    assert 'large_cap_sensor=bool(' in src
    assert 'sensor_only=bool(' in src

def test_sector_first_transport_precedes_candidate_priority():
    src=Path('pulse_edge/runtime.py').read_text()
    assert 'def _sector_first_discovery' in src
    assert 'discovered=self._sector_first_discovery(buckets' in src
    assert 'sector_discovery_laggard_max_change' in Path('pulse_edge/config.py').read_text()

def test_fast_hold_is_watch_only_and_never_pre_bypass():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'def early_price_hold' in src
    block=src[src.index('pre_common='):src.index('ignition_event=')]
    assert 'early_hold' not in block
    assert 'pressure_absorbed and release_ready' in block

def test_program_direction_acceleration_is_measured():
    src=Path('pulse_edge/engine/scorer.py').read_text()
    run=Path('pulse_edge/runtime.py').read_text()
    assert 'def program_metrics' in src
    assert 'program_delta_5m' in src and 'program_accel' in src
    assert 'st.program_hist.append((ev,pn))' in run
