from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import uuid4
from zoneinfo import ZoneInfo

from pulse_edge.core.models import Venue
from pulse_edge.decision.models import PreBuyDecisionFrame, PreBuyStage
from pulse_edge.decision.service import PreBuyDecisionService
from pulse_edge.features.engine import FeatureEngine
from pulse_edge.ledger.models import EpisodeStatus, OutcomeHorizon, SignalEpisode, SignalEvent, SignalOutcome
from pulse_edge.ledger.store import SignalLedgerStore

KST = ZoneInfo("Asia/Seoul")


@dataclass
class _ObservationTrack:
    first_seen_at: datetime
    first_seen_price: float | None
    first_route: str
    qualifying_since: datetime | None = None
    last_seen_at: datetime | None = None
    active_episode_id: str | None = None
    last_stage: str | None = None
    last_route: str | None = None
    last_sample_at: datetime | None = None


class SignalLedgerService:
    """One-way historical verifier fed by current PULSE decision rows.

    Stored history never enters discovery, confluence, hard-gate, or PRE-BUY current-row supply.
    Process restart begins with an empty observation tracker. A same-day open historical episode may
    only be reused for de-duplication after the symbol reappears in *current* PRE-BUY input.
    """

    TRACK_STAGES = {
        PreBuyStage.PREBUY_WATCH_SHADOW,
        PreBuyStage.PREBUY_SHADOW,
        PreBuyStage.READY_SHADOW,
        PreBuyStage.ENTRY_ELIGIBLE_SHADOW,
        PreBuyStage.A_PLUS_ELIGIBLE_SHADOW,
    }
    QUALIFY_STAGES = {
        # 2.2.0 candidate history begins at WATCH; remains strictly one-way history.
        PreBuyStage.PREBUY_WATCH_SHADOW,
        PreBuyStage.PREBUY_SHADOW,
        PreBuyStage.READY_SHADOW,
        PreBuyStage.ENTRY_ELIGIBLE_SHADOW,
        PreBuyStage.A_PLUS_ELIGIBLE_SHADOW,
    }

    def __init__(
        self,
        *,
        store: SignalLedgerStore,
        decisions: PreBuyDecisionService,
        features: FeatureEngine,
        min_stage_dwell_sec: float = 30.0,
        sample_interval_sec: float = 10.0,
        episode_end_absence_sec: float = 120.0,
    ) -> None:
        self.store = store
        self.decisions = decisions
        self.features = features
        self.min_stage_dwell_sec = max(0.0, float(min_stage_dwell_sec))
        self.sample_interval_sec = max(1.0, float(sample_interval_sec))
        self.episode_end_absence_sec = max(30.0, float(episode_end_absence_sec))
        self._tracks: dict[tuple[Venue, str], _ObservationTrack] = {}
        self.last_refresh_at: datetime | None = None
        self.last_error: str | None = None

    def refresh(self, limit: int = 100, asof: datetime | None = None) -> dict:
        now = asof or datetime.now(timezone.utc)
        current = self.decisions.top(max(20, min(int(limit), 200)))
        seen: set[tuple[Venue, str]] = set()
        created = events = samples = outcomes = 0

        for row in current:
            key = (row.venue, row.symbol)
            seen.add(key)
            if row.stage == PreBuyStage.DATA_WAIT:
                continue
            track = self._tracks.get(key)
            if track is None:
                track = _ObservationTrack(
                    first_seen_at=now,
                    first_seen_price=row.price,
                    first_route=row.primary_route.value,
                    last_seen_at=now,
                    last_stage=row.stage.value,
                    last_route=row.primary_route.value,
                )
                self._tracks[key] = track
            track.last_seen_at = now

            if row.stage == PreBuyStage.BLOCKED_SHADOW:
                if track.active_episode_id:
                    self._event(track.active_episode_id, row, now, "RISK_BLOCK")
                    self.store.end_episode(track.active_episode_id, now=now, price=row.price, reason="RISK_BLOCK")
                    events += 1
                    track.active_episode_id = None
                track.qualifying_since = None
                track.last_stage = row.stage.value
                track.last_route = row.primary_route.value
                continue

            if row.stage in self.QUALIFY_STAGES:
                if track.qualifying_since is None:
                    track.qualifying_since = now
                if track.active_episode_id is None and (now - track.qualifying_since).total_seconds() >= self.min_stage_dwell_sec:
                    episode = self._create_or_reuse(row, track, now)
                    track.active_episode_id = episode.episode_id
                    track.last_stage = episode.current_stage
                    track.last_route = episode.primary_route
                    created += 1
            else:
                track.qualifying_since = None

            if track.active_episode_id:
                stage_changed = row.stage.value != track.last_stage
                route_changed = row.primary_route.value != track.last_route
                if stage_changed or route_changed:
                    self._event(
                        track.active_episode_id,
                        row,
                        now,
                        "STAGE_CHANGE" if stage_changed else "PRIMARY_ROUTE_CHANGE",
                        details={"previous_stage": track.last_stage, "previous_route": track.last_route},
                    )
                    self.store.update_stage_time(track.active_episode_id, now)
                    track.last_stage = row.stage.value
                    track.last_route = row.primary_route.value
                    events += 1
                if track.last_sample_at is None or (now - track.last_sample_at).total_seconds() >= self.sample_interval_sec:
                    self._sample(track.active_episode_id, row, now)
                    track.last_sample_at = now
                    samples += 1

        # Absence ends a historical episode; it never restores a current row.
        for key, track in list(self._tracks.items()):
            if key in seen:
                continue
            if track.last_seen_at is None:
                self._tracks.pop(key, None)
                continue
            absent = (now - track.last_seen_at).total_seconds()
            if track.active_episode_id and absent >= self.episode_end_absence_sec:
                feature = self.features.frames.get(key)
                price = feature.price if feature is not None else None
                self.store.end_episode(track.active_episode_id, now=now, price=price, reason="CURRENT_DECISION_ABSENT")
                track.active_episode_id = None
            if absent >= self.episode_end_absence_sec:
                self._tracks.pop(key, None)

        # Capture only trustworthy intraday horizons from a currently available feature price.
        for pending in self.store.due_intraday_outcomes(now):
            ep = self.store.get_episode(pending.episode_id)
            if ep is None:
                continue
            feature = self.features.frames.get((ep.venue, ep.symbol))
            if feature is None or feature.price is None or feature.price <= 0 or pending.due_at is None:
                continue
            if max(0.0, (now - feature.asof).total_seconds()) > 7.0:
                continue
            self.store.capture_outcome(
                ep.episode_id, pending.horizon, due_at=pending.due_at, captured_at=now,
                price=feature.price, signal_price=ep.signal_price,
            )
            outcomes += 1

        self.last_refresh_at = now
        self.last_error = None
        return {"created": created, "events": events, "samples": samples, "outcomes": outcomes}

    def _create_or_reuse(self, row: PreBuyDecisionFrame, track: _ObservationTrack, now: datetime) -> SignalEpisode:
        day = now.astimezone(KST).date().isoformat()
        existing = self.store.find_open_episode(day, row.venue, row.symbol)
        if existing is not None:
            gap = max(0.0, (now - existing.last_update_at).total_seconds())
            if gap <= self.episode_end_absence_sec:
                return existing
            self.store.end_episode(existing.episode_id, now=now, price=row.price, reason="STALE_OPEN_EPISODE_AFTER_RESTART")
        price = float(row.price or 0.0)
        if price <= 0:
            raise ValueError("cannot create signal episode without trusted positive price")
        episode_id = uuid4().hex
        feature = self.features.frames.get((row.venue, row.symbol))
        flow_state = feature.smart_flow_state if feature is not None else None
        episode = SignalEpisode(
            episode_id=episode_id,
            trading_day=day,
            venue=row.venue,
            symbol=row.symbol,
            first_seen_at=track.first_seen_at,
            first_seen_price=track.first_seen_price,
            first_route=track.first_route,
            signal_at=now,
            signal_price=price,
            primary_route=row.primary_route.value,
            current_stage=row.stage.value,
            last_stage_at=now,
            last_price=price,
            highest_price=price,
            lowest_price=price,
            mfe_pct=0.0,
            mae_pct=0.0,
            evidence_count=row.evidence_count,
            confluence_grade=row.confluence_grade.value,
            confluence_score_100=row.confluence_score_100,
            regime_state=row.regime_state.value,
            smart_flow_state=flow_state,
            data_age_sec=row.upstream_asof_age_sec,
            invalidation_price=row.invalidation_price,
            status=EpisodeStatus.ACTIVE,
            last_update_at=now,
        )
        outcomes = [
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.M10, due_at=now + timedelta(minutes=10)),
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.M30, due_at=now + timedelta(minutes=30)),
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.CLOSE, status="WAITING_TRUSTED_CLOSE_SOURCE"),
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.D1, status="WAITING_DAILY_SOURCE"),
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.D3, status="WAITING_DAILY_SOURCE"),
            SignalOutcome(episode_id=episode_id, horizon=OutcomeHorizon.D5, status="WAITING_DAILY_SOURCE"),
        ]
        self.store.insert_episode(episode, outcomes)
        self._event(episode_id, row, now, "SIGNAL_EPISODE_START", details={"dwell_sec": self.min_stage_dwell_sec})
        return episode

    def _sample(self, episode_id: str, row: PreBuyDecisionFrame, now: datetime) -> None:
        feature = self.features.frames.get((row.venue, row.symbol))
        self.store.update_episode_sample(
            episode_id,
            now=now,
            price=row.price,
            stage=row.stage.value,
            route=row.primary_route.value,
            evidence_count=row.evidence_count,
            confluence_grade=row.confluence_grade.value,
            confluence_score_100=row.confluence_score_100,
            regime_state=row.regime_state.value,
            smart_flow_state=feature.smart_flow_state if feature is not None else None,
            data_age_sec=row.upstream_asof_age_sec,
            invalidation_price=row.invalidation_price,
        )

    def _event(self, episode_id: str, row: PreBuyDecisionFrame, now: datetime, event_type: str, details: dict | None = None) -> None:
        feature = self.features.frames.get((row.venue, row.symbol))
        event = SignalEvent(
            event_id=0,
            episode_id=episode_id,
            event_at=now,
            event_type=event_type,
            stage=row.stage.value,
            price=row.price,
            primary_route=row.primary_route.value,
            evidence_count=row.evidence_count,
            confluence_grade=row.confluence_grade.value,
            confluence_score_100=row.confluence_score_100,
            regime_state=row.regime_state.value,
            smart_flow_state=feature.smart_flow_state if feature is not None else None,
            risk_flags=list(row.risk_flags),
            gate_failures=list(row.gate_failures),
            details=details or {},
        )
        self.store.append_event(event)

    def recent(self, limit: int = 100) -> list[SignalEpisode]:
        return self.store.recent_episodes(limit)

    def detail(self, episode_id: str) -> dict | None:
        ep = self.store.get_episode(episode_id)
        if ep is None:
            return None
        return {
            "episode": ep.model_dump(mode="json"),
            "events": [x.model_dump(mode="json") for x in self.store.events(episode_id)],
            "outcomes": [x.model_dump(mode="json") for x in self.store.outcomes(episode_id)],
        }

    def performance(self, limit: int = 500) -> dict:
        return self.store.performance_summary(limit)
