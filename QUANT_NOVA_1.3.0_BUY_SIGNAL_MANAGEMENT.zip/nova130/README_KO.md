# QUANT NOVA 1.3.0 · BUY SIGNAL MANAGEMENT

NOVA 1.2.0 Adaptive Smart Money를 기반으로 매수신호 관리 Ledger를 추가한 버전입니다.

## 매수신호 관리 테이블
PRESSURE/IGNITION 진입을 BUY_SIGNAL 이벤트로 기록합니다.
- PRESSURE 최초 진입: 1회
- PRESSURE → IGNITION 승격: 추가 1회
- WATCH/SEED로 내려갔다가 PRESSURE/IGNITION 재진입: 추가 1회
- 같은 상태가 지속되는 동안에는 중복 카운트하지 않음

표시 컬럼:
- 상태
- 종목명/코드/거래소/FID9081
- 최근 신호시간 및 경과시간
- 현재가 / 당일 등락률
- 신호 발생 시점 진입 기준가
- 신호 후 현재 수익률 / 최대 수익률
- 오늘 신호횟수 / 누적 신호횟수
- 현재 NOVA 점수 / 신호 발생점수
- 프로그램 / 투신 / 연기금 / 알고리즘 지속률
- 매수신호 발생 이유
- 실체결 데이터 지연(ms)

## 영구 저장
- /app/data/buy_signal_events.jsonl : 모든 BUY_SIGNAL 이벤트
- /app/data/buy_signal_state.json : 종목별 최근 신호 및 횟수 상태
- 기존 performance_state.json / adaptive_model.json / training_events.jsonl 유지

※ '진입 기준가'는 실제 주문 체결가격이 아니라 신호 발생 시점의 실시간 가격입니다.
