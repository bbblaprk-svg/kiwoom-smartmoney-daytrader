PULSE EDGE 3.8.19_STORAGE_ISOLATION
기준: 3.8.18 구독유지/가격시점비교/일봉순환 수정본.
3.8.18 운영배포는 이벤트 루프 p95 약6~7초 지연으로 실패했고 이전3.8.17로 복귀했습니다.
해당 지연의 실제 원인이 DB였다고 확정한 것은 아닙니다. 코드의 동기DB 차단경로를 제거하고 작업별 계측을 추가했습니다.

수정
- 기준DB 읽기/저장, 신호저장, 성과갱신, 푸시구독 조회를 전용 스레드1개로 분리.
- 생산자는 DB 작업 완료를 await하므로 주기작업이 동일 작업을 계속 발행하지 않음.
- 점수계산은 메모리 기준값 사용. 기존 RVOL 계산값과 동일한 선형 환산이며 DB직접조회 없음.
- 기준값 생성 후 분이 바뀌면 재사용하지 않고 미확인으로 처리.
- 완료 전 취소된 DB 작업은 끝날 때까지 기다린 뒤 DB 연결 종료.
- 신호 저장 실패 시 중복억제 상태를 해제해 다음 유효 신호에서 재시도 가능.
- DB 트랜잭션 실패는 rollback. 이미 저장된 과거 신호를 재작성하지 않음.
- 기준DB 날짜 인덱스 및 하루1회 오래된 데이터 정리. 매 저장마다 전체 삭제검색 방지.
- /health storage_waiting 및 storage_timing(last_ms,max_ms) 추가.
- 기존 진입조건과 지연 차단 및 배포 p95 기준 유지. 기준완화로 배포를 통과시키지 않음.

검증
- pytest117개: 기존112개 + SQLite잠금/직렬처리및취소/기준값만료/실제평가의worker사용/저장실패재시도5개.
- 외부 SQLite 쓰기잠금2.4초 동안 이벤트루프20ms 간격 반복실행, 최대 간격200ms미만 확인.
- offline_tests 및 Python/JS/Bash/내장Python/소스해시 검증.
- Feed-OFF 로컬 Uvicorn 실제 기동 및 health/후보/기록부/API/정적파일 계약검증.

한계
- 이 환경에는 Docker가 없어 실제 Docker build 및 배포/cutover/rollback은 미검증.
- 실제 키움 NXT/정규장 부하/운영DB/공개HTTPS/장중10~20분 지속성은 운영서버 재검증 필요.
- 단일스레드 DB 대기가 길면 평가·저장은 지연될 수 있으나 수신루프를 동기잠금으로 막지 않음.
- 프로세스 강제종료/영구디스크오류/전원장애에서 기록무손실을 보장하는 설계는 아님.
- 실제 브라우저 픽셀렌더는 미검증. 이번 버전 UI 코드는 버전문구 외 변경 없음.

파일
Dockerfile
PULSE_EDGE_GREENFIELD_3_8_19_STORAGE_ISOLATION_SOURCE.tar.gz
PULSE_EDGE_GREENFIELD_3_8_19_STORAGE_ISOLATION_ONE_SHOT_DEPLOY.sh
세파일은 동일 빌드폴더에 두고 소스압축은 임의로 재압축하지 마세요.
Bash는 기존 Lightsail용 네트워크/환경을 사용하며 SHA검증/canary/싱글턴/HTTPS/10분부하/실패시복구 절차 유지.
