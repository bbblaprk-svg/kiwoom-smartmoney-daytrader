PULSE EDGE 3.5.0 GREENFIELD PRE-IGNITION HARDGATE2

Core design:
- GREENFIELD only. No legacy NOVA runtime/state/history is imported.
- KRX-only discovery during 09:00-15:30 KST. NXT is used only in the official non-overlap windows 08:00-08:50 and 15:40-20:00.
- Trade, quote and program freshness are tracked independently. A fresh quote/program update cannot make stale executions look LIVE.
- Official Kiwoom FID15 signed execution direction + FID228 trade strength; 1030/1031 are fallback only when FID15 has no direction.
- KOSPI/KOSDAQ 0J is the KRX market context. NXT uses a fresh NXT-native observed-market proxy and never borrows KRX 0J.
- Venue-native ka10064 intraday investor snapshots construct current/prior 5-minute flow windows; NXT uses the official _NX code form instead of KRX investor facts.
- Strict PRICE HOLD: non-overlapping rising lows + VWAP/ATR hold + sell-pulse recovery or verified quiet structure + <=0.5 ATR additional damage + relative damage resistance.
- Model A = absorption/flow confirmation. Model B = quiet compression/microstructure path; missing flow never gets relabeled as confirmed flow.
- 100-point PRE score: 30 microstructure / 25 hold+compression / 20 turnover / 15 sector+RS / 10 ignition proximity.
- Cross-source truth: <=0.10% confirmed, 0.10~0.30% ESTIMATED, >0.30% CONFLICT. Delayed/estimated/conflicting facts cannot produce A/B buy suitability.
- +3~5% heat penalty is applied before stage calculation; >=5% is excluded.
- Time-of-Day RVOL uses ten completed minute buckets and venue-separated history. Candidate-only ka10080 bootstrap avoids a five-day cold-start while limiting REST load.
- Quote depth is focused on four candidates; up to 34 symbols retain broad trade/program streams.
- Broad background probes rotate every 4 seconds and can promote quiet symbols before ranking APIs fully expose them; ranking sources/markets are interleaved to prevent slot monopoly. Sector breadth is explicitly a fresh observed-sample metric, not falsely labeled as full-market breadth.
- Real-time scoring/push loop is separated from REST maintenance jobs so slow REST calls cannot block 1-second evaluation.
- UI ranking commits every 30 seconds to prevent row shaking; the internal engine still evaluates every second.
- Signal history keeps the latest 100 events, shows roughly 10 rows with scroll, and includes occurrence count.
- Web Push uses bounded validated HTTPS subscriptions, VAPID and per-symbol notification tags.
- Health/readiness expose channel ages, job state, index/NXT market context, probe count, history and push counts for deployment gates.
- SQLite baseline/history use WAL + busy timeout and bounded retention.

No automatic order execution.
