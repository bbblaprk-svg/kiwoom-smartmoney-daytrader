from pathlib import Path

def test_scorer_calls_quote_microstructure_once_per_score_path():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    score_block=r[r.index('    def score('):r.index('    def rank(')]
    assert score_block.count('quote_microstructure(')==1
    assert score_block.count('ignition_trigger_metrics(')==1

def test_ignition_metrics_accepts_reused_qm_without_changing_fallback():
    r=Path('pulse_edge/engine/features.py').read_text()
    assert 'def ignition_trigger_metrics(state:SymbolState,vw:float|None,sector_expansion:float|None,now=None,qm:dict|None=None):' in r
    assert "qm=qm if qm is not None else quote_microstructure(state,n)" in r

def test_original_pre_sequence_lock_still_exact():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'pre=bool(pre_common and (model_a_ready or model_b_ready) and pressure_absorbed and release_ready)' in r

def test_ui_and_history_contract_unchanged():
    js=Path('pulse_edge/web/pulse.js').read_text()
    html=Path('pulse_edge/web/index.html').read_text()
    runtime=Path('pulse_edge/runtime.py').read_text()
    assert "mk('now',10,8)" in js
    assert '① HIDDEN GEM · NOW TOP10' in html
    assert html.index('DETAIL · 선택 종목') < html.index('② COILED SPRING')
    assert "if c.precursor_stage=='RELEASE READY':" in runtime
    assert "'EARLY HIDDEN GEM'" in runtime
