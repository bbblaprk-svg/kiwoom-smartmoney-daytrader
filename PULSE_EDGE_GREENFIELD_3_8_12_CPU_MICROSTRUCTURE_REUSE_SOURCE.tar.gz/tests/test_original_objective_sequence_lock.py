from pathlib import Path

def test_pre_requires_pressure_absorbed_and_release_ready():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('pre_common='):r.index('ignition_event=')]
    assert 'pre=bool(pre_common' in block
    assert 'pressure_absorbed' in block
    assert 'release_ready' in block

def test_release_ready_itself_requires_pressure_absorbed():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'release_ready=bool(pressure_absorbed and' in r

def test_model_b_is_not_direct_pre_bypass():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('pre_common='):r.index('ignition_event=')]
    assert '(model_a_ready or model_b_ready)' in block
    assert 'and pressure_absorbed and release_ready' in block
