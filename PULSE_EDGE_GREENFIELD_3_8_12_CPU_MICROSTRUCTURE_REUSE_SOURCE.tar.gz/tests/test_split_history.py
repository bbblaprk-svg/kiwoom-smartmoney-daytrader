
import os,tempfile
from pulse_edge.storage.signals import SignalStore

def row(sym,h,stage='PRE-IGNITION',score=90):
    return {'symbol':sym,'name':sym,'venue':'KRX','horizon':h,'stage':stage,'total_score':score,'current_price':10000,'ignition_probability':88}

def test_split_history_prunes_200_each_and_keeps_snapshot():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        st=SignalStore(path,400,200,200)
        for i in range(205):
            d=row(f'{i%99:06d}','NOW'); st.add_payload(d['symbol'],'KRX',d['stage'],90,d)
        for i in range(207):
            d=row(f'{(i+300)%999999:06d}','1-2D','COILED',82); st.add_payload(d['symbol'],'KRX',d['stage'],82,d)
        st.prune_horizons(200,200)
        assert len(st.recent(400,'NOW'))==200
        assert len(st.recent(400,'1-2D'))==200
        assert st.count()==400
        x=st.recent(1,'NOW')[0]
        assert x['current_price']==10000 and x['horizon']=='NOW' and 'history_ts' in x
    finally:
        try: st.close()
        except Exception: pass
        os.unlink(path)

def test_transition_belongs_to_now_history_not_coiled():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        st=SignalStore(path,400,200,200)
        d=row('123456','TRANSITION','COILED → NOW',91)
        st.add_payload('123456','KRX','COILED → NOW',91,d)
        assert st.recent(10,'NOW')[0]['stage']=='COILED → NOW'
        assert st.recent(10,'1-2D')==[]
    finally:
        st.close(); os.unlink(path)
