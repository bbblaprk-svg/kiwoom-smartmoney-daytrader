from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
from pulse_edge.runtime import venue_for_kst, _KRX_CLOSED_2026
from pulse_edge.config import Settings

KST=ZoneInfo('Asia/Seoul')

def test_weekend_never_live():
    assert venue_for_kst(datetime(2026,9,12,12,0,tzinfo=KST)) is None
    assert venue_for_kst(datetime(2026,9,13,12,0,tzinfo=KST)) is None

def test_known_2026_exchange_closures():
    for ds in ('2026-05-01','2026-06-03','2026-07-17','2026-09-24','2026-12-31'):
        y,m,d=map(int,ds.split('-'))
        assert venue_for_kst(datetime(y,m,d,12,0,tzinfo=KST)) is None

def test_regular_weekday_krx_and_override():
    dt=datetime(2026,9,14,12,0,tzinfo=KST)
    assert venue_for_kst(dt)=='KRX'
    assert venue_for_kst(dt,{'2026-09-14'}) is None

def test_probe_uses_single_stock_ka10001():
    r=Path('pulse_edge/runtime.py').read_text()
    block=r[r.index('async def _rest_confirm_probe'):r.index('def _harvest_probes')]
    assert "'ka10001','/api/dostk/stkinfo'" in block
    assert "{'stk_cd':api_symbol}" in block
    assert 'rkinfo' not in block

def test_progression_metrics_exposed():
    r=Path('pulse_edge/runtime.py').read_text()
    for token in ("'eval_seq':self.eval_seq","'candidate_fingerprint':self.last_candidate_fingerprint","'latest_trade_event_ts':"):
        assert token in r
