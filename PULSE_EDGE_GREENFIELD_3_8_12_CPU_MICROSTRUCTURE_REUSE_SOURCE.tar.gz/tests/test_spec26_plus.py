
import asyncio, time
from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime
from pulse_edge.models import SymbolState, Trade, Quote

def test_vi_trigger_and_release_state():
    r=Runtime(Settings(feed_enabled=False))
    r.universe={'005930':{'name':'X','market':'KOSPI','sector':'반도체','nxt_enabled':True,'listed_shares':1_000_000}}
    asyncio.run(r.on_event({'type':'1h','symbol':'005930','venue':'KRX','receive_ts':time.time(),
                            'data':{'vi_event':'1','vi_release_time':'111703','vi_count':'1','vi_trigger_rate':'+10.00'}}))
    st=r.state('005930','KRX')
    assert st.vi_active is True and st.vi_count==1
    asyncio.run(r.on_event({'type':'1h','symbol':'005930','venue':'KRX','receive_ts':time.time(),
                            'data':{'vi_event':'2','vi_count':'1'}}))
    assert st.vi_active is False

def test_news_adapter_updates_only_real_injected_state():
    r=Runtime(Settings(feed_enabled=False))
    r.universe={'123456':{'name':'Y','market':'KOSDAQ','sector':'로봇','nxt_enabled':False,'listed_shares':1_000_000}}
    st=r.state('123456','KRX')
    assert st.news_risk.startswith('UNAVAILABLE')
    assert r.ingest_news_signal('123456',hot=True,catalyst=True,risk='HIGH')==1
    assert st.news_hot and st.news_catalyst and st.news_risk=='HIGH'

def test_sector_chain_and_confidence_are_emitted():
    s=Settings(feed_enabled=False,sector_min_sample=3,sector_full_confidence_sample=5)
    r=Runtime(s); now=time.time()
    states={}
    for i,cr in enumerate([7.0,4.5,3.8,1.2,0.8,0.5]):
        st=SymbolState(str(i).zfill(6),market='KOSDAQ',sector='로봇',venue='KRX',price=100+cr,change_rate=cr,
                       last_trade_event_ts=now,last_trade_receive_ts=now,first_seen_ts=now-700)
        for k in range(12):
            st.trades.append(Trade(now-k*30,100+cr,1000, strength=120))
        st.quotes.append(Quote(now,101,100,1000,1200,3000,3600))
        states[f'{st.symbol}:KRX']=st
    sec=r.scorer.sector_stats(states,now)
    x=sec[('KRX','KOSDAQ','로봇')]
    assert x['confidence']=='HIGH'
    assert x['chain_score'] is not None and x['mid_ratio']>0 and x['laggard_ratio']>0
