from pathlib import Path

def test_guard_patch():
 r=Path('pulse_edge/runtime.py').read_text(); k=Path('pulse_edge/feed/kiwoom.py').read_text()
 assert 'latest_session=next' in r
 assert "if c.stage in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'}:" in r
 assert 'self.signal_store.prune_horizons' not in r
 assert 'its!=self._sent_items' in k and 'qits!=self._sent_quotes' in k
