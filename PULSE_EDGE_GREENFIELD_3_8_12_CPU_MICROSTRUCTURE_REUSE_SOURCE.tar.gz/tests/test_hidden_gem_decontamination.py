from pathlib import Path
from pulse_edge.config import Settings

def test_foreign_hard_filter_settings_are_gone():
    s=Settings()
    for name in (
        'min_market_cap_krw','popular_market_cap_cutoff_krw',
        'recent_3d_exclusion_pct','recent_5d_exclusion_pct',
        'familiar_symbols','market_red_new_block','market_red_threshold_pct',
        'model_b_breadth_min','leader_sensor_min_change','leader_sensor_chain_min',
    ):
        assert not hasattr(s,name), name

def test_no_cap_market_or_leader_in_absolute_gate():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    block=r[r.index('absolute_gate='):r.index('pre=bool(pre_common')]
    assert "absolute_gate=common_hard and not distortion and data in {'LIVE','CONFIRMED'}" in block
    assert 'cap_ok' not in block
    assert 'market_red' not in block
    assert 'leader_sensor' not in block

def test_familiar_and_recent_return_none_are_removed():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'familiar_symbols' not in r
    assert 'recent_3d_exclusion_pct' not in r
    assert 'recent_5d_exclusion_pct' not in r

def test_sector_breadth_is_context_not_model_or_pre_gate():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    mb=r[r.index('model_b_ready=bool('):r.index('absorption_model_detail=')]
    pc=r[r.index('pre_common='):r.index('pre=bool(pre_common')]
    assert 'breadth' not in mb
    assert 'breadth' not in pc

def test_fixed_turnover_no_longer_kills_candidate():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'turn10<self.s.minimum_turnover_10m: return None' not in r
    # score-only liquidity context remains, so removing the hard filter does not rewrite the score model.
    assert 'if turn10>=self.s.minimum_turnover_10m: C+=2' in r

def test_hidden_gem_core_gates_remain():
    s=Settings()
    assert s.supply_tight_min_conditions==8
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.allowed_change_max==3.0
    assert s.bid_absorption_min_score==60.0
    assert s.impact_decay_min_score==60.0
