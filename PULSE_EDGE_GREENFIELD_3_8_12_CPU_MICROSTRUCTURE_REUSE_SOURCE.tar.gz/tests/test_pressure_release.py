
import time
from pulse_edge.models import SymbolState, Trade
from pulse_edge.engine.features import price_impact_decay, flow_price_lag_score, release_distance_score
from pulse_edge.engine.coiled import _daily_impact_decay, _daily_flow_lag, _daily_release_distance

def _tr(now, age, price, sell=0, buy=0, strength=120):
    return Trade(now-age, price, abs(sell)+abs(buy) or 1, buy_exec=buy, sell_exec=sell, strength=strength)

def test_price_impact_decay_detects_same_sell_pressure_less_damage():
    n=time.time(); st=SymbolState('123456',price=10000)
    # oldest 5m window: ~2% damage
    st.trades.extend([_tr(n,850,10000,3000),_tr(n,780,9900,3000),_tr(n,700,9800,3000)])
    # middle: ~1%
    st.trades.extend([_tr(n,550,10000,3000),_tr(n,480,9950,3000),_tr(n,400,9900,3000)])
    # newest: ~0.3%
    st.trades.extend([_tr(n,250,10000,3000),_tr(n,180,9990,3000),_tr(n,100,9970,3000)])
    score, impacts, sells=price_impact_decay(st,n,20_000_000)
    assert score is not None and score>=80
    assert all(x is not None for x in impacts)
    assert impacts[0] > impacts[1] > impacts[2]
    assert min(sells)>=20_000_000

def test_flow_price_lag_rewards_accelerating_flow_with_muted_price():
    n=time.time(); st=SymbolState('123456',price=10050)
    st.trades.extend([_tr(n,920,10000,buy=100),_tr(n,601,10010,buy=100),
                      _tr(n,599,10010,buy=100),_tr(n,301,10020,buy=100),
                      _tr(n,299,10020,buy=100),_tr(n,1,10050,buy=100)])
    score=flow_price_lag_score(st,[100_000_000,200_000_000,400_000_000],n)
    assert score is not None and score>=85

def test_release_distance_combines_geometry_and_microstructure():
    n=time.time(); st=SymbolState('123456',price=9980)
    st.trades.extend([_tr(n,1000,10000,buy=100),_tr(n,900,9990,buy=100),_tr(n,30,9980,buy=100)])
    qm={'ask_depletion':80.0,'spread_trend':10.0}
    score,gap=release_distance_score(st,0.25,qm,30.0,n)
    assert score is not None and score>=70
    assert gap is not None and gap<1

def test_daily_precursors_use_real_daily_inputs_not_private_fund():
    bars=[
        {'date':'20260911','open':100,'close':99.8,'high':101,'low':99,'turnover':300_000_000},
        {'date':'20260910','open':100,'close':99.5,'high':101,'low':99,'turnover':280_000_000},
        {'date':'20260909','open':100,'close':99.0,'high':101,'low':98,'turnover':260_000_000},
    ]
    flows=[
        {'date':'20260911','foreign':10,'investment_trust':200,'pension':150},
        {'date':'20260910','foreign':10,'investment_trust':120,'pension':100},
        {'date':'20260909','foreign':10,'investment_trust':60,'pension':50},
    ]
    impact,_=_daily_impact_decay(bars)
    lag,arr=_daily_flow_lag(flows,'투신+연기금',bars)
    release=_daily_release_distance(1.2,80,80,1.4)
    assert impact is not None and impact>=60
    assert lag is not None and lag>=80
    assert arr==[350,220,110]
    assert release is not None and release>=65
