import asyncio,time
from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.runtime import Runtime

def S(tmp_path):
    return Settings(feed_enabled=False,
                    data_dir=str(tmp_path),
                    baseline_db=str(tmp_path/'b.sqlite3'),
                    history_db=str(tmp_path/'h.sqlite3'))

def test_no_duplicate_full_score_refresh_sources():
    s=Path('pulse_edge/runtime.py').read_text()
    inv=s[s.index('async def refresh_investors'):s.index('async def refresh_daily_context')]
    daily=s[s.index('async def refresh_daily_context'):s.index('async def bootstrap_baselines')]
    assert 'self.scorer.score(' not in inv
    assert 'self.scorer.score(' not in daily
    assert 'self.raw_results' in inv and 'self.raw_results' in daily

def test_fresh_lane_and_idle_release_present():
    s=Path('pulse_edge/runtime.py').read_text()
    assert 'priority_idle_sec' in Path('pulse_edge/config.py').read_text()
    assert '_fresh_discovery_wires' in s
    assert '_eligible_rank_priority' in s
    assert 'idle > self.s.priority_idle_sec' in s
    assert 'discovery_fresh_slots' in s

def test_latency_metrics_exposed(tmp_path):
    r=Runtime(S(tmp_path))
    r.event_loop_lag_ms.extend([1,2,3])
    r.event_handler_ms.extend([2,3,4])
    r.feed_event_age_ms.extend([5,6,7])
    r.eval_ms.extend([8,9,10])
    h=r.health()
    assert 'latency' in h
    assert h['latency']['event_loop_lag_ms_p95'] is not None
    r.signal_store.close(); r.baseline.close()

def test_actionable_is_protected_from_idle_demotion(tmp_path):
    r=Runtime(S(tmp_path))
    # Source-level invariant is enough to ensure actionables bypass idle release.
    src=Path('pulse_edge/runtime.py').read_text()
    assert "wire not in actionable" in src
    r.signal_store.close(); r.baseline.close()
