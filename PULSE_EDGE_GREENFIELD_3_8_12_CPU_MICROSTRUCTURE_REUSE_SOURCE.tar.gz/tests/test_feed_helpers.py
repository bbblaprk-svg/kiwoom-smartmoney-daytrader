import asyncio
from pulse_edge.feed.kiwoom import minute_baseline_rows,intraday_investor_snapshots

class FakeRest:
    def __init__(self): self.calls=[]
    async def post(self,api,path,body,cont=None,next_key=None):
        self.calls.append((api,body,cont,next_key))
        if api=='ka10080':
            return {'stk_min_pole_chart_qry':[
                {'cur_prc':'10000','trde_qty':'100','cntr_tm':'20260911100000'},
                {'cur_prc':'10010','trde_qty':'200','cntr_tm':'20260910100000'},
                {'cur_prc':'10020','trde_qty':'150','cntr_tm':'20260909100000'},
                {'cur_prc':'10030','trde_qty':'120','cntr_tm':'20260908100000'},
                {'cur_prc':'10040','trde_qty':'110','cntr_tm':'20260907100000'},
                {'cur_prc':'10050','trde_qty':'90','cntr_tm':'20260904100000'},
            ]},{'cont-yn':'N'}
        if api=='ka10064':
            return {'opmr_invsr_trde_chart':[]},{}
        raise AssertionError(api)

def test_minute_baseline_uses_nxt_wire_code_and_price_volume_amount():
    r=FakeRest(); rows=asyncio.run(minute_baseline_rows(r,'039490','NXT',2,5))
    assert r.calls[0][1]['stk_cd']=='039490_NX'
    assert len(rows)==6 and rows[-1][1]==1_000_000
