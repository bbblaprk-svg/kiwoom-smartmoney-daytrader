import tempfile, os
from pulse_edge.storage.signals import SignalStore
from pulse_edge.models import Candidate

def c(i,symbol=None):
    sym=symbol or str(i)
    return Candidate(sym,f'S{i}','KOSDAQ','KRX',10000,1.0,'2026-09-12T09:10:00+09:00','LIVE','PRE-IGNITION',90,80,85,90,70,None,None,None,1,-1,1,-1,1,1,1e8,1.5,50,50,True,'PASS','ABOVE',1,1,70,1,5,130,.2,40,20,'-','10%','-','-','-','-','-','A',[])

def test_history_caps_100_and_occurrence_count():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        st=SignalStore(path,100)
        for i in range(103): st.add(c(i))
        st.add(c(103,'777777')); st.add(c(104,'777777'))
        rows=st.recent(100); assert len(rows)==100; assert rows[0]['symbol']=='777777'; assert rows[0]['occurrence_count']==2
        assert st.count()==100
    finally:
        try: os.unlink(path)
        except FileNotFoundError: pass


def test_push_subscription_requires_https_and_webpush_keys():
    fd,path=tempfile.mkstemp(); os.close(fd)
    try:
        st=SignalStore(path,100)
        import pytest
        with pytest.raises(ValueError): st.subscribe({'endpoint':'http://bad.example/x','keys':{'p256dh':'a','auth':'b'}})
        with pytest.raises(ValueError): st.subscribe({'endpoint':'https://ok.example/x','keys':{}})
        st.subscribe({'endpoint':'https://ok.example/x','keys':{'p256dh':'abc','auth':'def'}})
        assert st.subscription_count()==1
    finally:
        try: os.unlink(path)
        except FileNotFoundError: pass
