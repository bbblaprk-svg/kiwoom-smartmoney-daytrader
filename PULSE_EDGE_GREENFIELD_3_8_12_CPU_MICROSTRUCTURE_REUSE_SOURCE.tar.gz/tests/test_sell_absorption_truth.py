from pathlib import Path
from pulse_edge.config import Settings
from pulse_edge.models import SymbolState,Trade
from pulse_edge.engine.features import tape_sell_pressure_metrics

def test_pressure_absorbed_requires_actual_sell_pressure():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'sell_pressure_evidence=bool(' in r
    assert 'pressure_absorbed=bool(hold and sell_pressure_evidence' in r
    assert 'release_ready=bool(pressure_absorbed' in r

def test_a1_and_a2_are_both_present():
    r=Path('pulse_edge/engine/scorer.py').read_text()
    assert 'model_a1_ready=bool(' in r and 'model_a2_ready=bool(' in r
    assert "'A1_FOREIGN_ABSORB'" in r and "'A2_CORE_INST_ABSORB'" in r and "detection_model='A_ABSORPTION'" in r

def test_bid_absorption_is_separate_from_ask_depletion():
    r=Path('pulse_edge/engine/features.py').read_text()
    assert "'bid_absorption':bid_absorption" in r
    assert "'ask_depletion':dep_quality" in r

def test_tape_sell_decel_is_not_seller_disappearance():
    st=SymbolState(symbol='000001'); now=1_800_000_000.0
    for age in (850,800,550,500): st.trades.append(Trade(now-age,10000,3000,sell_exec=3000))
    m=tape_sell_pressure_metrics(st,now,20_000_000)
    assert m['decelerating'] is False and m['persistent'] is False

def test_core_thresholds_preserved():
    s=Settings()
    assert s.supply_tight_min_conditions==8
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.bid_absorption_min_score==60.0
