from pulse_edge.models import SymbolState
from pulse_edge.engine.coiled import score_coiled

def test_coiled_uses_trust_plus_pension_and_excludes_private_fund_by_construction():
    st=SymbolState('123456',name='TEST',market='KOSDAQ',venue='KRX',price=101,change_rate=1.0)
    st.daily_bars=[
        {'date':f'202609{10-i:02d}','close':100+i*.15,'open':100,'high':101.0+i*.05,'low':99.4+i*.05,'turnover':150+i*3,'volume':1000} for i in range(10)
    ]
    st.daily_flows=[
        {'date':'20260910','foreign':10,'investment_trust':80,'pension':70},
        {'date':'20260909','foreign':5,'investment_trust':50,'pension':40},
        {'date':'20260908','foreign':2,'investment_trust':20,'pension':15},
    ]
    c=score_coiled(st,set())
    assert c is not None
    assert c.core_actor=='투신+연기금'
    assert c.core_inst_3d==275
    assert c.trust_3d==150 and c.pension_3d==125

def test_coiled_to_now_flag():
    st=SymbolState('123456',name='TEST',market='KOSDAQ',venue='KRX',price=101,change_rate=1.0)
    st.daily_bars=[{'date':f'202609{10-i:02d}','close':100,'open':100,'high':101,'low':99.5,'turnover':150,'volume':1000} for i in range(10)]
    st.daily_flows=[{'date':'3','foreign':30,'investment_trust':10,'pension':10},{'date':'2','foreign':20,'investment_trust':8,'pension':8},{'date':'1','foreign':10,'investment_trust':5,'pension':5}]
    c=score_coiled(st,{'123456'})
    assert c and c.promoted_to_now is True
