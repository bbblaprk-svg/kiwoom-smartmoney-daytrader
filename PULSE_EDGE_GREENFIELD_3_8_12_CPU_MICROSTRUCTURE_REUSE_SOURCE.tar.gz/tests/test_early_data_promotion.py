from pathlib import Path
from pulse_edge.config import Settings

def test_discovery_capacity_and_quote_newcomers():
    s=Settings()
    assert s.ws_dynamic_max_items==34
    assert s.ws_background_reserve_items==14
    assert s.quote_newcomer_slots==2

def test_probe_cross_confirm_is_bounded():
    r=Path('pulse_edge/runtime.py').read_text()
    assert 'async def _rest_confirm_probe' in r
    assert 'probe_rest_confirm_cooldown_sec' in r
    assert 'newly_promoted' in r
    assert "task=asyncio.create_task(self._rest_confirm_probe(wire))" in r

def test_quote_focus_reserves_newcomers():
    r=Path('pulse_edge/runtime.py').read_text()
    assert 'newcomer_slots=' in r
    assert 'interleave_unique([probes,fresh],newcomer_slots)' in r

def test_urgent_baseline_is_bounded_and_prioritized():
    r=Path('pulse_edge/runtime.py').read_text()
    assert 'async def urgent_baseline_bootstrap' in r
    assert 'urgent_baseline_cooldown_sec' in r
    assert 'interleave_unique([self._probe_wires(),self._fresh_discovery_wires(),self.rank_priority]' in r

def test_core_thresholds_unchanged():
    s=Settings()
    assert s.supply_tight_min_conditions==8
    assert s.supply_exhaustion_min_signals==7
    assert s.ignition_trigger_min_count==2
    assert s.cross_confirm_accept_pct==0.001
