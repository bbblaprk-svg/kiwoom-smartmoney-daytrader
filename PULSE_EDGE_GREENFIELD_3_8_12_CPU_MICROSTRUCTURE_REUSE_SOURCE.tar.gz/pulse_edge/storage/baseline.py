from __future__ import annotations
import sqlite3, threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
KST=ZoneInfo('Asia/Seoul')

class BaselineStore:
    def __init__(self,path):
        self.path=path; self.lock=threading.RLock(); self.db=sqlite3.connect(path,check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=NORMAL'); self.db.execute('PRAGMA busy_timeout=3000')
        # Venue-separated baseline: KRX and NXT facts never mix.
        self.db.execute('CREATE TABLE IF NOT EXISTS tod_v2(symbol TEXT, venue TEXT NOT NULL, day TEXT, minute INTEGER, amount REAL, PRIMARY KEY(symbol,venue,day,minute))')
        self.db.execute('CREATE INDEX IF NOT EXISTS idx_tod_v2_lookup ON tod_v2(symbol,venue,minute,day DESC)')
        old=self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='tod'").fetchone()
        if old:
            self.db.execute("INSERT OR IGNORE INTO tod_v2(symbol,venue,day,minute,amount) SELECT symbol,'KRX',day,minute,amount FROM tod")
        self.db.commit()

    def _tuple(self,symbol,venue,ts,amount):
        d=datetime.fromtimestamp(ts,KST); return (symbol,venue,d.date().isoformat(),d.hour*60+d.minute,float(amount)),d

    def record(self,symbol,venue,ts,amount):
        self.record_many([(symbol,venue,ts,amount)])

    def record_many(self,rows):
        cooked=[]; newest=None
        for symbol,venue,ts,amount in rows:
            if amount is None or float(amount)<=0: continue
            row,d=self._tuple(symbol,venue,ts,amount); cooked.append(row)
            newest=d if newest is None or d>newest else newest
        if not cooked: return 0
        with self.lock:
            self.db.executemany('INSERT INTO tod_v2(symbol,venue,day,minute,amount) VALUES(?,?,?,?,?) ON CONFLICT(symbol,venue,day,minute) DO UPDATE SET amount=excluded.amount',cooked)
            cutoff=((newest or datetime.now(KST)).date()-timedelta(days=45)).isoformat()
            self.db.execute('DELETE FROM tod_v2 WHERE day<?',(cutoff,))
            self.db.commit()
        return len(cooked)

    def history_days(self,symbol,venue,exclude_day=None):
        with self.lock:
            if exclude_day:
                r=self.db.execute('SELECT COUNT(DISTINCT day) FROM tod_v2 WHERE symbol=? AND venue=? AND day<>?',(symbol,venue,exclude_day)).fetchone()
            else:
                r=self.db.execute('SELECT COUNT(DISTINCT day) FROM tod_v2 WHERE symbol=? AND venue=?',(symbol,venue)).fetchone()
        return int((r or [0])[0] or 0)


    def close(self):
        with self.lock:
            self.db.commit(); self.db.close()

    def rvol(self,symbol,venue,ts,current_completed_10m):
        if current_completed_10m is None: return None,0
        d=datetime.fromtimestamp(ts,KST); m=d.hour*60+d.minute
        # Compare ten completed minutes (m-10..m-1) with the same completed interval historically.
        with self.lock:
            rows=self.db.execute('SELECT day,SUM(amount) FROM tod_v2 WHERE symbol=? AND venue=? AND day<>? AND minute BETWEEN ? AND ? GROUP BY day ORDER BY day DESC LIMIT 20',(symbol,venue,d.date().isoformat(),m-10,m-1)).fetchall()
        if len(rows)<5: return None,len(rows)
        vals=sorted(float(x[1] or 0) for x in rows if x[1] is not None and float(x[1] or 0)>0)
        if len(vals)<5: return None,len(vals)
        med=vals[len(vals)//2]
        return (current_completed_10m/med if med>0 else None),len(vals)
