from __future__ import annotations
import statistics, time
from pulse_edge.models import SymbolState


def clamp(x,a=0.,b=100.): return max(a,min(b,x))
def safe_div(a,b): return None if a is None or b in (None,0) else a/b
def _now(v=None): return time.time() if v is None else float(v)

def vwap(trades):
    vals=[(t.price,abs(t.volume)) for t in trades if t.price and t.price>0 and t.volume]
    den=sum(v for _,v in vals)
    return sum(p*v for p,v in vals)/den if den else None

def window(state:SymbolState,sec:float,now=None):
    n=_now(now); out=[]
    for t in reversed(state.trades):
        age=n-t.ts
        if age<0: continue
        if age>sec: break
        out.append(t)
    out.reverse(); return out

def qwindow(state:SymbolState,sec:float,now=None):
    n=_now(now); out=[]
    for q in reversed(state.quotes):
        age=n-q.ts
        if age<0: continue
        if age>sec: break
        out.append(q)
    out.reverse(); return out

def turnover(trades): return sum(t.price*abs(t.volume) for t in trades if t.price and t.volume)

def price_range(trades):
    ps=[t.price for t in trades if t.price and t.price>0]
    if not ps: return None
    lo=min(ps); hi=max(ps); return (hi-lo)/lo*100 if lo>0 else None

def _segments(state:SymbolState,width:int,count:int,now=None):
    """Oldest->newest non-overlapping segments."""
    n=_now(now); buckets=[[] for _ in range(count)]; limit=width*count
    for t in reversed(state.trades):
        age=n-t.ts
        if age<0: continue
        if age>limit: break
        idx=min(count-1,max(0,int(max(age-1e-9,0)//width)))
        buckets[count-1-idx].append(t)
    for b in buckets: b.reverse()
    return buckets

def segment_structure(state:SymbolState,now=None):
    segs=_segments(state,300,6,now); out=[]
    for seg in segs:
        ps=[t.price for t in seg if t.price and t.price>0]
        if len(ps)<3: continue
        buy=sum(float(t.buy_exec or 0) for t in seg); sell=sum(float(t.sell_exec or 0) for t in seg)
        out.append({'low':min(ps),'high':max(ps),'open':ps[0],'close':ps[-1],'buy':buy,'sell':sell,'turnover':turnover(seg),'n':len(seg)})
    return out

def rising_lows(state:SymbolState,now=None):
    s=segment_structure(state,now)
    lows=[x['low'] for x in s[-4:]]
    return len(lows)>=3 and all(b >= a*0.9995 for a,b in zip(lows,lows[1:]))

def high_hold(state:SymbolState,now=None):
    s=segment_structure(state,now); highs=[x['high'] for x in s[-4:]]
    if len(highs)<3: return False
    # Highs need not rise, but a cascading lower-high structure is rejected.
    return all(b >= a*0.995 for a,b in zip(highs,highs[1:]))

def sell_pressure_damage_resistance(state:SymbolState,now=None):
    """True when higher sell pressure is not translating into proportionally larger price damage."""
    s=segment_structure(state,now)
    if len(s)<3: return None
    vals=[]
    for x in s[-3:]:
        damage=max(0.0,(x['open']-x['low'])/max(x['open'],1e-9))
        vals.append((x['sell'],damage))
    # Quiet compression has no meaningful sell pulse and is acceptable for Model B.
    if max(v[0] for v in vals)<=0: return True
    a,b=vals[-2],vals[-1]
    if b[0] >= a[0]*1.05:
        return b[1] <= a[1]*1.05
    return b[1] <= max(a[1]*1.15,0.0005)

def compression(state:SymbolState,now=None):
    segs=_segments(state,300,4,now); ranges=[]; bodies=[]
    for seg in segs:
        ps=[t.price for t in seg if t.price and t.price>0]
        if len(ps)<3: continue
        lo=min(ps); hi=max(ps)
        ranges.append((hi-lo)/lo*100 if lo>0 else 0)
        bodies.append(abs(ps[-1]-ps[0])/ps[0]*100 if ps[0]>0 else 0)
    if len(ranges)<3: return None,ranges
    old_r=statistics.mean(ranges[:-1]); new_r=ranges[-1]
    old_b=statistics.mean(bodies[:-1]); new_b=bodies[-1]
    return clamp(clamp((1-new_r/max(old_r,1e-6))*100)*0.70 + clamp((1-new_b/max(old_b,1e-6))*100)*0.30),ranges

def recent_atr_abs(state:SymbolState,now=None):
    vals=[]
    for seg in _segments(state,300,6,now):
        ps=[t.price for t in seg if t.price and t.price>0]
        if len(ps)>=3: vals.append(max(ps)-min(ps))
    vals=[x for x in vals if x>0]
    return statistics.median(vals) if len(vals)>=3 else None

def short_atr(state:SymbolState,now=None):
    vals=[]
    for seg in _segments(state,300,6,now):
        ps=[t.price for t in seg if t.price and t.price>0]
        if len(ps)>=3 and min(ps)>0: vals.append((max(ps)-min(ps))/min(ps))
    if len(vals)<3: return None
    recent=statistics.mean(vals[-2:]); older=statistics.mean(vals[:-2]) if len(vals)>2 else recent
    return clamp((1-recent/max(older,1e-9))*100)

def order_flow(state:SymbolState,now=None):
    ts=window(state,300,now)
    if not ts: return None,None,None
    buy=sum(float(t.buy_exec or 0) for t in ts); sell=sum(float(t.sell_exec or 0) for t in ts)
    if buy+sell<=0: return None,None,None
    ofi=(buy-sell)/(buy+sell)
    official=[float(t.strength) for t in ts if t.strength is not None and float(t.strength)>0]
    strength=statistics.median(official[-30:]) if official else None
    return ofi,strength,buy-sell

def has_official_trade_strength(state:SymbolState,sec:float=300,now=None):
    return any(t.strength is not None and t.strength>0 for t in window(state,sec,now))

def trade_flow_acceleration(state:SymbolState,now=None):
    """Current 60s vs prior 60s: aggressive-buy and tick-speed acceleration."""
    n=_now(now)
    cur=[t for t in state.trades if 0<=n-t.ts<=60]; prev=[t for t in state.trades if 60<n-t.ts<=120]
    if len(cur)<2 or len(prev)<2: return None,None
    cb=sum(t.buy_exec or 0 for t in cur); cs=sum(t.sell_exec or 0 for t in cur)
    pb=sum(t.buy_exec or 0 for t in prev); ps=sum(t.sell_exec or 0 for t in prev)
    cur_ratio=cb/max(cb+cs,1); prev_ratio=pb/max(pb+ps,1)
    buy_accel=(cur_ratio-prev_ratio)*100
    speed_accel=(len(cur)/max(len(prev),1)-1)*100
    return buy_accel,speed_accel

def quote_microstructure(state:SymbolState,now=None,bid_window_sec:float=90.0,bid_abs_floor_krw:float=5_000_000.0,bid_sell_ratio_min:float=0.20,bid_legacy_cap_krw:float=20_000_000.0):
    qs=qwindow(state,300,now)
    empty={'absorption':None,'spread_trend':None,'ask_depletion':None,'replenishment_decline':None,'bid_support':None,'bid_absorption':None,'bid_replenishment_events':0,'bid_sell_value':None,'bid_total_value':None,'bid_adaptive_floor':None}
    if len(qs)<4: return empty
    asks=[q.ask_qty for q in qs if q.ask_qty is not None and q.ask_qty>0]; bids=[q.bid_qty for q in qs if q.bid_qty is not None and q.bid_qty>0]
    if len(asks)<4 or len(bids)<4: return empty
    dep=[max(asks[i-1]-asks[i],0) for i in range(1,len(asks))]; rep=[max(asks[i]-asks[i-1],0) for i in range(1,len(asks))]
    depletion=sum(dep); replenish=sum(rep); dep_quality=100*depletion/max(depletion+replenish,1.0)
    bid_support=clamp((bids[-1]/max(bids[0],1)-1)*100+50)
    last=qs[-1]; depth_bias=50.0
    if last.total_bid is not None and last.total_ask is not None and (last.total_bid+last.total_ask)>0:
        depth_bias=clamp((last.total_bid-last.total_ask)/(last.total_bid+last.total_ask)*50+50)
    spreads=[(q.ask-q.bid)/q.bid for q in qs if q.ask and q.bid and q.bid>0]
    spread_trend=None
    if len(spreads)>=4:
        half=max(2,len(spreads)//2); old=statistics.median(spreads[:half]); new=statistics.median(spreads[-half:])
        spread_trend=(old-new)/max(old,1e-9)*100
    replenishment_decline=None
    if len(rep)>=4:
        half=max(2,len(rep)//2); old=sum(rep[:half]); new=sum(rep[-half:]); replenishment_decline=(old-new)/max(old,1.0)*100
    n=_now(now); win=max(30.0,float(bid_window_sec))
    recent_q=[q for q in qs if 0<=n-q.ts<=win and q.bid and q.bid_qty is not None]
    all_recent_t=[t for t in state.trades if 0<=n-t.ts<=win and t.price>0]
    recent_t=[t for t in all_recent_t if (t.sell_exec or 0)>0]
    sell_value=sum(t.price*float(t.sell_exec or 0) for t in recent_t)
    total_value=sum(t.price*abs(float(t.volume or 0)) for t in all_recent_t)
    # Downward-only adaptation: helps small/illiquid names without making the
    # existing 3.8.6 filter stricter for liquid names.
    adaptive_floor=min(float(bid_legacy_cap_krw), max(float(bid_abs_floor_krw), total_value*float(bid_sell_ratio_min)))
    bid_absorption=None; bid_replenishment_events=0
    if len(recent_q)>=4 and sell_value>=adaptive_floor:
        support_events=0; observed=0; rebuild_ratios=[]
        for i in range(1,len(recent_q)):
            q0,q1=recent_q[i-1],recent_q[i]
            sells_between=sum(t.price*float(t.sell_exec or 0) for t in recent_t if q0.ts<=t.ts<=q1.ts)
            if sells_between<=0: continue
            observed+=1
            bid_hold=bool(q1.bid is not None and q0.bid is not None and q1.bid>=q0.bid*0.999)
            rebuild=max(float(q1.bid_qty or 0)-float(q0.bid_qty or 0),0.0)/max(float(q0.bid_qty or 0),1.0)
            if bid_hold: support_events+=1
            if rebuild>0:
                bid_replenishment_events+=1; rebuild_ratios.append(rebuild)
        if observed>=2:
            hold_ratio=support_events/observed
            rebuild_med=statistics.median(rebuild_ratios) if rebuild_ratios else 0.0
            sell_component=clamp(sell_value/100_000_000*25,0,25)
            bid_absorption=clamp(hold_ratio*55 + min(rebuild_med,1.0)*20 + sell_component)
    return {'absorption':clamp(dep_quality*0.55+bid_support*0.25+depth_bias*0.20),'spread_trend':spread_trend,'ask_depletion':dep_quality,'replenishment_decline':replenishment_decline,'bid_support':bid_support,'bid_absorption':bid_absorption,'bid_replenishment_events':bid_replenishment_events,'bid_sell_value':sell_value,'bid_total_value':total_value,'bid_adaptive_floor':adaptive_floor}

def quote_absorption(state:SymbolState,now=None): return quote_microstructure(state,now).get('absorption')

def spread_pct(state:SymbolState):
    if not state.quotes: return None
    q=state.quotes[-1]
    if not q.ask or not q.bid or q.bid<=0: return None
    return (q.ask-q.bid)/q.bid

def large_buy_trade_score(state:SymbolState,now=None):
    ts=window(state,600,now)
    vals=[(t.price*abs(t.volume),t) for t in ts if t.price and t.volume]
    if len(vals)<5: return None
    med=statistics.median(x for x,_ in vals); threshold=max(100_000_000,med*5)
    # Only aggressive BUY prints count. Large sells are not rewarded.
    hits=sum(1 for x,t in vals if x>=threshold and (t.buy_exec or 0)>(t.sell_exec or 0))
    return clamp(hits*20)

def large_trade_score(state:SymbolState,now=None): return large_buy_trade_score(state,now)

def sell_pulse_recovery(state:SymbolState,now=None):
    n=_now(now); ts=sorted(window(state,900,n),key=lambda t:t.ts); atr=recent_atr_abs(state,n)
    if len(ts)<10 or not atr or atr<=0: return None,None,atr
    buckets=[]; cur_key=None; cur=[]
    for t in ts:
        k=int(t.ts//60)
        if cur_key is None or k==cur_key: cur_key=k; cur.append(t)
        else: buckets.append(cur); cur=[t]; cur_key=k
    if cur: buckets.append(cur)
    buckets=[b for b in buckets if b]
    if len(buckets)<3: return None,None,atr
    best=None
    for i in range(1,len(buckets)):
        pre=[x.price for b in buckets[max(0,i-2):i] for x in b if x.price>0]; pulse=[x for x in buckets[i] if x.price>0]
        if not pre or not pulse: continue
        peak=max(pre); low_trade=min(pulse,key=lambda x:x.price); low=low_trade.price; damage=peak-low
        if damage>0 and (best is None or damage>best[0]): best=(damage,peak,low,low_trade.ts)
    if best is None or best[0] < atr*0.20: return 1.0,0.0,atr
    damage,peak,pulse_low,low_ts=best; post=[t.price for t in ts if t.ts>low_ts and t.price>0]; cur=ts[-1].price
    recovery=clamp((cur-pulse_low)/max(damage,1e-9),0,1.5); later_low=min(post) if post else cur; extra=max(0.0,pulse_low-later_low)/atr
    return recovery,extra,atr

def completed_10m_amount(state:SymbolState,now=None,zero_trade_coverage_samples=45):
    """Ten completed KST minutes with feed-truth separation.

    Missing trade amount is a real zero only when this symbol had sustained live
    subscription coverage for that minute. Otherwise it stays UNKNOWN.
    The second return value preserves the historical diagnostic meaning: actual
    amount-bearing minutes on failure, 10 when all ten minutes are truth-confirmed.
    """
    n=_now(now)
    from datetime import datetime, timedelta
    from zoneinfo import ZoneInfo
    KST=ZoneInfo('Asia/Seoul'); d=datetime.fromtimestamp(n,KST).replace(second=0,microsecond=0)
    keys=[]
    for i in range(1,11):
        x=d-timedelta(minutes=i); keys.append(x.hour*100+x.minute)
    actual_present=sum(1 for k in keys if k in state.minute_amount)
    coverage=getattr(state,'minute_feed_coverage',{}) or {}
    total=0.0
    for k in keys:
        if k in state.minute_amount:
            total+=float(state.minute_amount.get(k,0) or 0)
        elif int(coverage.get(k,0) or 0) >= int(zero_trade_coverage_samples):
            total+=0.0
        else:
            return None,actual_present
    return total,10

def ignition_trigger_metrics(state:SymbolState,vw:float|None,sector_expansion:float|None,now=None,qm:dict|None=None):
    n=_now(now); cur=state.price or 0; t20=window(state,1200,n); recent=[t for t in t20 if n-t.ts<=600]; prior=[t for t in t20 if 600<n-t.ts<=1200]
    box_hi=max((t.price for t in prior if t.price>0),default=None)
    box_break=bool(box_hi and cur>box_hi*1.0005)
    high_break=box_break
    vwap_expand=False
    if vw and vw>0:
        r1=[t.price for t in state.trades if 0<=n-t.ts<=60 and t.price>0]; p3=[t.price for t in state.trades if 60<n-t.ts<=240 and t.price>0]
        if r1 and p3: vwap_expand=(statistics.mean(r1)/vw-1) > (statistics.mean(p3)/vw-1)+0.001
    buy_acc,speed_acc=trade_flow_acceleration(state,n)
    ofi5,_,_=order_flow(state,n); prior5=[t for t in state.trades if 300<n-t.ts<=600]
    pb=sum(t.buy_exec or 0 for t in prior5); ps=sum(t.sell_exec or 0 for t in prior5); prior_ofi=(pb-ps)/max(pb+ps,1) if pb+ps>0 else None
    ofi_surge=bool(ofi5 is not None and prior_ofi is not None and ofi5-prior_ofi>=0.15)
    turn5=turnover(window(state,300,n)); prev5=turnover(prior5); turnover_surge=bool(prev5>0 and turn5/prev5>=1.30)
    qm=qm if qm is not None else quote_microstructure(state,n); ask_fast=bool(qm['ask_depletion'] is not None and qm['ask_depletion']>=65 and (qm['replenishment_decline'] or 0)>=10)
    spread_hold=bool(qm['spread_trend'] is not None and qm['spread_trend']>=-5)
    sector_sync=bool(sector_expansion is not None and sector_expansion>=5)
    flags={'BOX_BREAK':box_break,'HIGH_10_20_BREAK':high_break,'VWAP_EXPAND':vwap_expand,'AGGR_BUY_SURGE':bool(buy_acc is not None and buy_acc>=10),'OFI_SURGE':ofi_surge,'TURNOVER_SURGE':turnover_surge,'ASK_1_3_DEPLETION':ask_fast,'SPREAD_HOLD_OR_TIGHTEN':spread_hold,'SECTOR_LAGGARD_SYNC':sector_sync,'TRADE_SPEED_ACCEL':bool(speed_acc is not None and speed_acc>=20)}
    return flags,qm,buy_acc,speed_acc

def quick_probe_score(state:SymbolState,sec:float=20.0,now=None):
    n=_now(now); ts=window(state,sec,n)
    if len(ts)<2 or state.price is None or state.change_rate is None: return 0.0
    buy=sum(t.buy_exec or 0 for t in ts); sell=sum(t.sell_exec or 0 for t in ts); ofi=(buy-sell)/max(buy+sell,1)
    official=[t.strength for t in ts if t.strength is not None and t.strength>0]; strength=statistics.median(official) if official else 0; money=turnover(ts); score=0.0
    if -1.0 <= state.change_rate <= 2.5: score+=15
    elif -2.0 <= state.change_rate < 4.0: score+=7
    score+=clamp((len(ts)-2)/10*20,0,20)+clamp((ofi+0.1)/0.7*25,0,25)+clamp((strength-90)/60*25,0,25)+clamp(money/50_000_000*15,0,15)
    return clamp(score)


def price_impact_decay(state:SymbolState, now=None, sell_value_floor:float=20_000_000.0):
    """Measure whether comparable aggressive sell pressure causes progressively less damage.
    Returns (score, impacts, sell_values). No score is emitted unless >=2 windows have real sell value.
    Impact unit = percentage drawdown per KRW 100m aggressive sell value.
    """
    n=_now(now)
    windows=[(900,600),(600,300),(300,0)]
    impacts=[]; sell_values=[]
    for old,new in windows:
        ts=[t for t in state.trades if new <= n-t.ts < old and t.price>0]
        sell_value=sum(t.price*max(0.0,float(t.sell_exec or 0)) for t in ts)
        sell_values.append(sell_value)
        if len(ts)<2 or sell_value<sell_value_floor:
            impacts.append(None); continue
        ts=sorted(ts,key=lambda x:x.ts)
        ref=ts[0].price
        low=min(t.price for t in ts)
        damage=max(0.0,(ref-low)/max(ref,1e-9)*100.0)
        impacts.append(damage/max(sell_value/100_000_000.0,0.01))
    valid=[x for x in impacts if x is not None]
    if len(valid)<2:
        return None,impacts,sell_values
    score=40.0
    # Strongest evidence: all three windows show falling price impact while sell pressure persists.
    if all(x is not None for x in impacts):
        a,b,c=impacts
        if a>=b>=c:
            score=75.0
            if a>0 and c<=a*0.50: score=95.0
            elif a>0 and c<=a*0.70: score=85.0
        elif c < a:
            score=65.0
        else:
            score=25.0
        # Do not reward "impact decay" that is caused merely by sell pressure disappearing.
        if sell_values[0]>0 and sell_values[2] < sell_values[0]*0.35:
            score=min(score,55.0)
    else:
        first,last=valid[0],valid[-1]
        score=70.0 if last<first else 30.0
    return round(clamp(score),1),impacts,sell_values


def tape_sell_pressure_metrics(state:SymbolState, now=None, sell_value_floor:float=20_000_000.0):
    """Three 5m aggressive-sell windows, keeping persistence and deceleration separate."""
    n=_now(now); windows=[(900,600),(600,300),(300,0)]; vals=[]
    for old,new in windows:
        ts=[t for t in state.trades if new <= n-t.ts < old and t.price>0]
        vals.append(sum(t.price*max(0.0,float(t.sell_exec or 0)) for t in ts))
    active=[v>=sell_value_floor for v in vals]
    persistent=bool(sum(active)>=2 and active[-1])
    decel=bool(all(active) and vals[0]>=vals[1]>=vals[2] and vals[0]>vals[2])
    if vals[-1] < sell_value_floor: decel=False
    return {'sell_values':vals,'persistent':persistent,'decelerating':decel,'latest_sell_value':vals[-1]}


def flow_price_lag_score(state:SymbolState, actor_flows, now=None):
    """Score money-flow acceleration that has not yet been released into price.
    actor_flows must be three real 5-minute incremental flow values, oldest -> newest.
    """
    if not actor_flows or len(actor_flows)!=3 or any(x is None for x in actor_flows):
        return None
    flows=[float(x) for x in actor_flows]
    if flows[-1] <= 0:
        return 0.0
    n=_now(now)
    px=[]
    for age in (900,600,300,0):
        cand=[t for t in state.trades if t.price>0 and t.ts<=n-age]
        px.append(cand[-1].price if cand else None)
    if px[0] is None or state.price is None or px[0]<=0:
        return None
    price_reaction=abs((state.price/px[0]-1)*100.0)
    trend=0.0
    if flows[0] <= flows[1] <= flows[2] and flows[2]>flows[0]:
        trend=70.0
    elif flows[2] >= flows[1] and flows[2]>0:
        trend=50.0
    else:
        trend=25.0
    # Highest score when flow accelerates while 15m price reaction remains muted.
    lag_bonus=clamp((2.0-price_reaction)/2.0*30.0,0,30)
    return round(clamp(trend+lag_bonus),1)


def release_distance_score(state:SymbolState, ofi:float|None, qm:dict, speed_accel:float|None, now=None):
    """How close the coil is to release, using price geometry + top-of-book/tape conditions."""
    n=_now(now); cur=state.price
    if cur is None or cur<=0:
        return None,None
    prior=[t.price for t in state.trades if 600 < n-t.ts <= 1200 and t.price>0]
    if not prior:
        prior=[t.price for t in state.trades if 300 < n-t.ts <= 900 and t.price>0]
    ceiling=max(prior) if prior else None
    gap=max(0.0,(ceiling/cur-1)*100.0) if ceiling else None
    score=0.0; weight=0.0
    if gap is not None:
        # 0~1.5% below the actual compression ceiling is the preferred release zone.
        score += clamp((2.5-gap)/2.5*35.0,0,35); weight+=35
    dep=qm.get('ask_depletion')
    if dep is not None: score+=clamp(dep/100*25,0,25); weight+=25
    spr=qm.get('spread_trend')
    if spr is not None: score+=clamp((spr+5)/30*15,0,15); weight+=15
    if ofi is not None: score+=clamp((ofi+0.05)/0.45*15,0,15); weight+=15
    if speed_accel is not None: score+=clamp((speed_accel+5)/35*10,0,10); weight+=10
    if weight<50:
        return None,gap
    return round(clamp(score*100.0/weight),1),gap
