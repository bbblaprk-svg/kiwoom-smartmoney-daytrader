from __future__ import annotations
import statistics, time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from collections import defaultdict
from pulse_edge.models import Candidate
from pulse_edge.engine.features import *
KST=ZoneInfo('Asia/Seoul')

class Scorer:
    def __init__(self,settings,baseline):
        self.s=settings; self.baseline=baseline
        self.market_change={'KOSPI':0.0,'KOSDAQ':0.0}; self.market_ts={'KOSPI':0.0,'KOSDAQ':0.0}
        self.nxt_market_change={'KOSPI':None,'KOSDAQ':None}; self.nxt_market_ts={'KOSPI':0.0,'KOSDAQ':0.0}; self.nxt_market_sample={'KOSPI':0,'KOSDAQ':0}
        self.daily_changes={}; self.breadth_history=defaultdict(list); self._last_breadth_record=0.0

    def _trade_times(self,st):
        rr=st.last_trade_receive_ts or (st.last_receive_ts if st.trades else 0.0); ee=st.last_trade_event_ts or (st.last_event_ts if st.trades else 0.0)
        return rr,ee

    def data_status(self,st,now=None):
        n=time.time() if now is None else now; rr,ee=self._trade_times(st)
        if not rr or not ee: return 'UNAVAILABLE'
        ra=n-rr; ea=n-ee
        if ra < -2 or ea < -2: return 'CONFLICT'
        if ra<=self.s.stale_receive_sec and ea<=self.s.stale_event_sec: return 'LIVE'
        if ra<=15 and ea<=30: return 'CONFIRMED'
        if ra<=120: return 'DELAYED'
        return 'STALE'

    def update_venue_market_proxies(self,states,now=None):
        n=time.time() if now is None else now
        for market in ('KOSPI','KOSDAQ'):
            vals=[]
            for st in states.values():
                if st.venue!='NXT' or st.market!=market or st.change_rate is None: continue
                if self.data_status(st,n) not in {'LIVE','CONFIRMED'}: continue
                vals.append(float(st.change_rate))
            self.nxt_market_sample[market]=len(vals)
            if len(vals)>=self.s.nxt_market_proxy_min_sample:
                self.nxt_market_change[market]=statistics.median(vals); self.nxt_market_ts[market]=n

    def market_snapshot(self,market,venue='KRX',now=None):
        n=time.time() if now is None else now
        if venue=='KRX':
            ts=self.market_ts.get(market,0.0); age=n-ts if ts else 999999
            return self.market_change.get(market),age<=self.s.market_index_stale_sec,1 if ts else 0
        ts=self.nxt_market_ts.get(market,0.0); age=n-ts if ts else 999999; sample=self.nxt_market_sample.get(market,0)
        fresh=age<=self.s.nxt_market_proxy_stale_sec and sample>=self.s.nxt_market_proxy_min_sample
        return self.nxt_market_change.get(market),fresh,sample

    @staticmethod
    def _snap_at(hist,target,max_gap=100):
        before=[x for x in hist if x.ts<=target]
        if before:
            x=before[-1]; return x if target-x.ts<=max_gap else None
        after=[x for x in hist if x.ts>target]
        if after and after[0].ts-target<=max_gap: return after[0]
        return None

    def investor_metrics(self,st):
        """Three non-overlapping 5m windows: 15-10m, 10-5m, 5-0m."""
        hist=sorted(list(st.investor_hist),key=lambda x:x.ts)
        if not hist: return (None,)*11
        cur=hist[-1]; foreign=cur.foreign; inst=cur.institution; program=st.program_net if st.program_net is not None else cur.program
        p5=self._snap_at(hist,cur.ts-300); p10=self._snap_at(hist,cur.ts-600); p15=self._snap_at(hist,cur.ts-900)
        ratios=[]; sells=[]; foreign_buys=[]; core_buys=[]; foreign_sells=[]; core_absorb_ratios=[]
        points=[(p15,p10),(p10,p5),(p5,cur)]
        for a,b in points:
            if not a or not b or a.foreign is None or b.foreign is None or a.institution is None or b.institution is None:
                ratios.append(None); sells.append(None); foreign_buys.append(None); core_buys.append(None); foreign_sells.append(None); core_absorb_ratios.append(None); continue
            f=b.foreign-a.foreign; i=b.institution-a.institution; sell=max(0.0,-i); denom=sell if sell>=self.s.minimum_inst_sell_value else None
            ratios.append(max(0.0,f)/denom if denom else None); sells.append(sell); foreign_buys.append(max(0.0,f))
            f_sell=max(0.0,-f); foreign_sells.append(f_sell)
            if a.investment_trust is None and a.pension is None and b.investment_trust is None and b.pension is None:
                core_buys.append(None); core_absorb_ratios.append(None)
            else:
                ac=(a.investment_trust or 0.0)+(a.pension or 0.0); bc=(b.investment_trust or 0.0)+(b.pension or 0.0)
                core_buy=bc-ac; core_buys.append(core_buy)
                fden=f_sell if f_sell>=self.s.minimum_inst_sell_value else None
                core_absorb_ratios.append(max(0.0,core_buy)/fden if fden else None)
        ratio=ratios[-1]; accel=None
        valid=[x for x in ratios if x is not None]
        if len(valid)>=2: accel=valid[-1]-valid[-2]
        absorb_3=bool(len(ratios)==3 and all(x is not None for x in ratios) and ratios[0] <= ratios[1] <= ratios[2] and ratios[2]>ratios[0])
        decel=None
        if sells[-1] is not None and sells[-2] is not None: decel=sells[-2]-sells[-1]
        sell_decel_3=bool(len(sells)==3 and all(x is not None for x in sells) and sells[0]>=sells[1]>=sells[2])
        foreign_accel_3=bool(len(foreign_buys)==3 and all(x is not None for x in foreign_buys) and foreign_buys[0]<=foreign_buys[1]<=foreign_buys[2])
        trust=cur.investment_trust; pension=cur.pension
        core_inst=None if trust is None and pension is None else (trust or 0.0)+(pension or 0.0)
        recent_core=core_buys[-1] if core_buys and core_buys[-1] is not None else None
        recent_foreign=foreign_buys[-1] if foreign_buys and foreign_buys[-1] is not None else None
        actor='투신+연기금' if (recent_core or 0)>max(0.0,recent_foreign or 0.0) else ('외국인' if (recent_foreign or 0)>0 else '압축형')
        actor_windows=core_buys if actor=='투신+연기금' else (foreign_buys if actor=='외국인' else [None,None,None])
        core_ratio=core_absorb_ratios[-1] if core_absorb_ratios else None
        core_absorb_3=bool(len(core_absorb_ratios)==3 and all(x is not None for x in core_absorb_ratios) and core_absorb_ratios[0]<=core_absorb_ratios[1]<=core_absorb_ratios[2] and core_absorb_ratios[2]>core_absorb_ratios[0])
        core_accel_3=bool(len(core_buys)==3 and all(x is not None for x in core_buys) and core_buys[0]<=core_buys[1]<=core_buys[2] and core_buys[-1]>0)
        foreign_sell_decel_3=bool(len(foreign_sells)==3 and all(x is not None for x in foreign_sells) and foreign_sells[0]>=foreign_sells[1]>=foreign_sells[2] and foreign_sells[0]>foreign_sells[2])
        return foreign,inst,program,decel,ratio,cur.source_status,accel,absorb_3,sell_decel_3,foreign_accel_3,{'ratios':ratios,'sells':sells,'foreign_buys':foreign_buys,'core_buys':core_buys,'foreign_sells':foreign_sells,'core_absorb_ratios':core_absorb_ratios,'core_absorb_ratio':core_ratio,'core_absorb_3':core_absorb_3,'core_accel_3':core_accel_3,'foreign_sell_decel_3':foreign_sell_decel_3,'actor_windows':actor_windows,'investment_trust':trust,'pension':pension,'core_inst':core_inst,'core_actor':actor}

    def price_hold(self,st,vw,rising,market_rs,now=None):
        if st.price is None or vw is None: return False,[]
        recovery,extra_damage_atr,atr_abs=sell_pulse_recovery(st,now)
        if atr_abs is None or atr_abs<=0: return False,['ATR_UNAVAILABLE']
        high_ok=high_hold(st,now); damage_ok=sell_pressure_damage_resistance(st,now); reasons=[]
        if rising: reasons.append('LOW_RISING')
        if high_ok: reasons.append('HIGH_HOLD')
        vwap_gap=max(vw-st.price,0.0)/atr_abs
        if st.price>=vw or vwap_gap<=self.s.price_hold_vwap_gap_atr: reasons.append('VWAP_ATR_HOLD')
        if recovery is not None and recovery>=self.s.price_hold_recovery_min: reasons.append('SELL_PULSE_RECOVERY_OR_QUIET')
        if extra_damage_atr is not None and extra_damage_atr<=self.s.price_hold_extra_damage_atr: reasons.append('LIMITED_EXTRA_DAMAGE_ATR')
        if market_rs is not None and market_rs>=self.s.price_hold_market_rs_floor: reasons.append('RELATIVE_DAMAGE_RESISTANCE')
        if damage_ok is True: reasons.append('SELL_PRESSURE_DAMAGE_RESISTANCE')
        return len(reasons)==7,reasons

    def sector_stats(self,states,now=None):
        n=time.time() if now is None else now; by=defaultdict(list)
        for st in states.values():
            if st.change_rate is None or self.data_status(st,n) not in {'LIVE','CONFIRMED'}: continue
            by[(st.venue,st.market,st.sector)].append(st)
        out={}; record=n-self._last_breadth_record>=10
        for key,rows in by.items():
            if len(rows)<self.s.sector_min_sample: continue
            leader_state=max(rows,key=lambda x:(x.change_rate if x.change_rate is not None else -999)); leader=leader_state.change_rate or 0.0
            ups=vwup=turnup=laggard=0; usable_turn=0
            for x in rows:
                if (x.change_rate or 0)>0: ups+=1
                vw=vwap(window(x,1800,n))
                if vw and x.price and x.price>=vw: vwup+=1
                cur5=turnover(window(x,300,n)); prev5=turnover([t for t in x.trades if 300<n-t.ts<=600])
                if prev5>0:
                    usable_turn+=1
                    if cur5>=prev5: turnup+=1
                if 0 <= (x.change_rate or 0) <= min(3.0,max(0.0,leader-1.0)) and vw and x.price and x.price>=vw: laggard+=1
            up_ratio=ups/len(rows)*100; vwap_ratio=vwup/len(rows)*100; turnover_ratio=(turnup/usable_turn*100) if usable_turn else None; laggard_ratio=laggard/len(rows)*100
            mid=sum(1 for x in rows if 3.0 < (x.change_rate or 0) < max(3.01,leader-0.5))
            mid_ratio=mid/len(rows)*100
            axes=[up_ratio,vwap_ratio,turnover_ratio,laggard_ratio]; present=[x for x in axes if x is not None]
            breadth=sum(present)/len(present) if present else None
            avg=sum(x.change_rate or 0 for x in rows)/len(rows); hist=self.breadth_history[key]
            old=[x for x in hist if 55<=n-x[0]<=180]
            expansion=(breadth-old[-1][1]) if old and breadth is not None else None
            sector_rs_slope=(avg-old[-1][2]) if old else None
            old_mid=old[-1][3] if old and len(old[-1])>3 else None
            old_lag=old[-1][4] if old and len(old[-1])>4 else None
            leader_strength=max(0.0,min(100.0,leader/8.0*100.0))
            mid_component=max(0.0,min(100.0,mid_ratio*3.0))
            lag_expand=laggard_ratio-(old_lag if old_lag is not None else laggard_ratio)
            lag_component=max(0.0,min(100.0,50.0+lag_expand*5.0))
            chain_score=0.35*leader_strength+0.30*mid_component+0.35*lag_component
            if old_mid is not None and mid_ratio+5 < old_mid: chain_score=max(0.0,chain_score-15.0)
            if record:
                hist.append((n,breadth,avg,mid_ratio,laggard_ratio)); del hist[:-180]
            confidence='HIGH' if len(rows)>=self.s.sector_full_confidence_sample else ('MEDIUM' if len(rows)>=max(5,self.s.sector_min_sample) else 'LOW')
            out[key]={'breadth':breadth,'breadth_expansion':expansion,'sector_rs_slope':sector_rs_slope,'leader':leader,'leader_symbol':leader_state.symbol,'avg':avg,'sample':len(rows),'up_ratio':up_ratio,'vwap_ratio':vwap_ratio,'turnover_ratio':turnover_ratio,'laggard_ratio':laggard_ratio,'mid_ratio':mid_ratio,'chain_score':chain_score,'confidence':confidence}
        if record: self._last_breadth_record=n
        return out

    def _data_check_candidate(self,st,data,reason,now,cr,d1,d3,d5,d15=None):
        event_ts=st.last_trade_event_ts or st.last_trade_receive_ts or now; dt=datetime.fromtimestamp(event_ts,timezone.utc).astimezone(KST).isoformat(timespec='seconds')
        return 0.0,Candidate(symbol=st.symbol,name=st.name,market=st.market,venue=st.venue,current_price=st.price,change_rate=cr,data_timestamp=dt,data_status=data,stage='DATA CHECK',total_score=0.0,purity_score=0.0,energy_compression=0.0,ignition_probability=0.0,persistence_score=0.0,change_1d=d1,change_3d=d3,change_5d=d5,change_15d=d15,persistence_15d_score=None,foreign_flow=None,institution_flow=None,program_flow=None,institution_sell_velocity=None,foreign_absorb_ratio=None,absorb_acceleration=None,turnover_10m=None,tod_rvol=None,atr_compression=None,range_compression=None,rising_lows=False,price_hold='UNCONFIRMED',vwap_state='UNAVAILABLE',market_rs=None,sector_rs=None,sector_breadth=None,flow_price_divergence=None,leader_laggard_gap=None,trade_strength=None,ofi=None,quote_absorption=None,large_trade_score=None,entry_zone='-',recommended_weight='0% 관찰',add_condition='DATA TRUTH 정상화 후 재평가',trigger_10_30m='DATA CHECK',invalidation='데이터 충돌/지연 지속',stop_condition='신규 진입 금지',sell_news_risk='UNAVAILABLE(NO_LIVE_NEWS_FEED)',suitability='WATCH',reasons=[reason,'DATA_TRUTH_FAIL_STOPPED'],detection_model='OBSERVE')

    def score(self,st,states,sector_stats,now=None):
        n=time.time() if now is None else now; data=self.data_status(st,n)
        if st.price is None or st.change_rate is None: return None
        cr=float(st.change_rate); dc=self.daily_changes.get(st.symbol,(None,None,None,None)); dc=tuple(dc)+(None,)*(4-len(tuple(dc))); d1,d3,d5,d15=dc[:4]
        if data in {'STALE','UNAVAILABLE'}: return self._data_check_candidate(st,data,'TRADE_DATA_NOT_FRESH',n,cr,d1,d3,d5,d15)
        if cr>=self.s.hidden_gem_max_change or cr<-5: return None
        base_fresh=data in {'LIVE','CONFIRMED'}; rest_px=st.rest_price if st.rest_venue==st.venue else None; rest_age=n-st.rest_price_ts if rest_px and st.rest_price_ts else 9999
        cross_div=abs(st.price/rest_px-1) if rest_px and st.price and rest_age<=90 else None; cross_confirmed=cross_div is not None and cross_div<=self.s.cross_confirm_accept_pct
        if cross_div is not None:
            if cross_div>self.s.cross_conflict_pct: data='CONFLICT'
            elif cross_div>self.s.cross_confirm_accept_pct: data='ESTIMATED'
        if st.prev_close and st.prev_close>0:
            internal=(st.price/st.prev_close-1)*100; diff=abs(internal-cr)
            if diff>self.s.change_conflict_pp: data='CONFLICT'
            elif diff>self.s.change_recheck_pp and data!='CONFLICT': data='ESTIMATED'
        if data in {'CONFLICT','ESTIMATED','DELAYED'}:
            return self._data_check_candidate(st,data,'PRICE_OR_CHANGE_RECHECK_REQUIRED',n,cr,d1,d3,d5,d15)

        t30=window(st,1800,n); t10=window(st,600,n); t5=window(st,300,n)
        if len(t10)<4: return None
        vw=vwap(t30 or t10); ofi,strength,_=order_flow(st,n); official_strength=has_official_trade_strength(st,300,n)
        large=large_buy_trade_score(st,n); rng_comp,_=compression(st,n); atr_comp=short_atr(st,n); rise=rising_lows(st,n)
        turn10=turnover(t10); turn5=turnover(t5); observed_for=max(0.0,n-st.first_seen_ts)
        tick_values=[t.price*abs(t.volume) for t in t10 if t.price and t.volume]; distortion=bool(tick_values and max(tick_values)>=1_000_000_000 and max(tick_values)>=0.5*max(turn10,1))
        prior5=turnover([t for t in st.trades if 300<n-t.ts<=600]); turn_acc=(turn5/max(prior5,1))*100 if prior5>0 else None
        completed10,completed_minutes=completed_10m_amount(st,n,self.s.zero_trade_minute_coverage_samples); tod,baseline_days=self.baseline.rvol(st.symbol,st.venue,n,completed10) if completed10 is not None else (None,0)
        market_move,market_fresh,market_sample=self.market_snapshot(st.market,st.venue,n); market_rs=(cr-market_move) if market_fresh and market_move is not None else None
        hold,hold_reasons=self.price_hold(st,vw,rise,market_rs,n)
        f,inst,prog,inst_decel,absorb,flow_status,abs_acc,absorb_3,sell_decel_3,foreign_accel_3,flow_windows=self.investor_metrics(st)
        flow_windows=flow_windows or {}
        core_ratio=flow_windows.get('core_absorb_ratio')
        core_absorb_3=bool(flow_windows.get('core_absorb_3'))
        core_accel_3=bool(flow_windows.get('core_accel_3'))
        foreign_sell_decel_3=bool(flow_windows.get('foreign_sell_decel_3'))
        spread=spread_pct(st); spread_limit=self.s.spread_limit_nxt if st.venue=='NXT' else self.s.spread_limit_krx
        quote_recv=st.last_quote_receive_ts or (st.quotes[-1].ts if st.quotes else 0.0); quote_ev=st.last_quote_event_ts or (st.quotes[-1].ts if st.quotes else 0.0); quote_age=max(n-quote_recv,n-quote_ev) if quote_recv and quote_ev else None
        prog_recv=st.last_program_receive_ts; prog_ev=st.last_program_event_ts; program_age=max(n-prog_recv,n-prog_ev) if prog_recv and prog_ev else None
        trade_rr,trade_ev=self._trade_times(st); trade_age=max(n-trade_rr,n-trade_ev) if trade_rr and trade_ev else None
        quote_fresh=quote_age is not None and quote_age<=self.s.stale_event_sec; micro_fresh=ofi is not None and strength is not None and official_strength; program_fresh=program_age is not None and program_age<=self.s.program_stale_sec
        flow_confirmed=(flow_status in {'LIVE','CONFIRMED'} and prog is not None and program_fresh); spread_ok=spread is not None and spread<=spread_limit
        common_hard=base_fresh and quote_fresh and micro_fresh and cross_confirmed and spread_ok and market_fresh

        sec=sector_stats.get((st.venue,st.market,st.sector),{}); breadth=sec.get('breadth'); breadth_exp=sec.get('breadth_expansion'); sector_rs_slope=sec.get('sector_rs_slope'); leader=sec.get('leader'); leader_symbol=sec.get('leader_symbol'); sec_avg=sec.get('avg'); sector_sample=sec.get('sample'); chain_score=sec.get('chain_score'); breadth_confidence=sec.get('confidence','LOW')
        sector_rs=(cr-sec_avg) if sec_avg is not None else None; gap=(leader-cr) if leader is not None else None
        # Diagnostic only: sector leadership is context, never an exclusion gate.
        leader_sensor=bool(leader_symbol==st.symbol)
        # CPU guard: compute quote microstructure once per symbol/evaluation and reuse it.
        # The same adaptive parameters/thresholds are preserved; only duplicate scans are removed.
        qm=quote_microstructure(st,n,self.s.bid_absorption_window_sec,self.s.bid_absorption_abs_floor_krw,self.s.bid_absorption_sell_ratio_min,self.s.pressure_sell_value_floor)
        ignition_flags,qm,buy_accel,speed_accel=ignition_trigger_metrics(st,vw,breadth_exp,n,qm)
        qabs=qm['absorption']
        impact_decay,impact_windows,impact_sell_values=price_impact_decay(st,n,self.s.pressure_sell_value_floor)
        tape_sell=tape_sell_pressure_metrics(st,n,self.s.pressure_sell_value_floor)
        tape_sell_decel=bool(tape_sell.get('decelerating')); tape_sell_persistent=bool(tape_sell.get('persistent'))
        bid_absorption=qm.get('bid_absorption')
        flow_lag=flow_price_lag_score(st,flow_windows.get('actor_windows'),n)
        release_dist,release_gap=release_distance_score(st,ofi,qm,speed_accel,n)
        precursor_values=[x for x in (impact_decay,flow_lag,release_dist,bid_absorption) if x is not None]
        pressure_release=round(sum(precursor_values)/len(precursor_values),1) if precursor_values else None
        precursor_axes=sum(1 for x,thr in ((impact_decay,self.s.impact_decay_min_score),(flow_lag,self.s.flow_price_lag_min_score),(release_dist,self.s.release_distance_min_score),(bid_absorption,self.s.bid_absorption_min_score)) if x is not None and x>=thr)
        sell_pressure_evidence=bool(tape_sell_persistent and ((impact_decay or 0)>=self.s.impact_decay_min_score or (bid_absorption or 0)>=self.s.bid_absorption_min_score))
        pressure_absorbed=bool(hold and sell_pressure_evidence and precursor_axes>=self.s.pressure_absorbed_min_axes)
        # Informational early flag only. It cannot satisfy strict PRESSURE ABSORBED,
        # RELEASE READY, SUPPLY TIGHT or PRE hard gates.
        early_absorbed=bool(
            self.s.early_absorption_min_observed_sec<=observed_for<600 and
            hold and
            float(qm.get('bid_sell_value') or 0)>=float(qm.get('bid_adaptive_floor') or 1e99) and
            (bid_absorption or 0)>=self.s.bid_absorption_min_score
        )
        release_ready=bool(pressure_absorbed and release_dist is not None and release_dist>=self.s.release_distance_min_score and precursor_axes>=self.s.release_ready_min_axes)
        precursor_stage='RELEASE READY' if release_ready else ('PRESSURE ABSORBED' if pressure_absorbed else ('EARLY PRESSURE ABSORBED' if early_absorbed else ('COILED' if ((rng_comp or 0)>=30 and (atr_comp or 0)>=20) else 'OBSERVE')))
        mcap=(st.price*st.listed_shares) if st.price and st.listed_shares else None
        market_red=False  # broad-market direction is context, not a hidden-gem hard gate
        flow_div=clamp(absorb*40-max(cr,0)*5) if absorb is not None else None
        vi_recent=bool(st.vi_active or (st.vi_last_ts and n-st.vi_last_ts<=self.s.vi_block_sec))
        news_fresh=bool(st.news_ts and n-st.news_ts<=self.s.news_stale_sec)
        news_hot=bool(news_fresh and st.news_hot); news_catalyst=bool(news_fresh and st.news_catalyst)
        news_risk=st.news_risk if news_fresh else 'UNAVAILABLE(NO_LIVE_NEWS_FEED)'

        A=0.0
        if ofi is not None: A+=clamp((ofi+0.2)/0.8*7,0,7)
        if strength is not None: A+=clamp((strength-80)/80*4,0,4)
        if qabs is not None: A+=clamp(qabs/100*3,0,3)
        if bid_absorption is not None: A+=clamp(bid_absorption/100*4,0,4)
        if absorb is not None: A+=clamp(absorb/1.2*5,0,5)
        if core_ratio is not None: A+=clamp(core_ratio/1.2*5,0,5)
        if absorb_3: A+=3
        if sell_decel_3: A+=2
        if tape_sell_decel: A+=2
        if qm['replenishment_decline'] is not None: A+=clamp(qm['replenishment_decline']/100*2,0,2)
        # Model B must be able to earn the full microstructure bucket from observed tape/depth alone;
        # unavailable investor flow is never guessed, it is simply not required for the quiet-compression path.
        if qm['bid_support'] is not None: A+=clamp((qm['bid_support']-45)/35*3,0,3)
        if qm['spread_trend'] is not None: A+=clamp((qm['spread_trend']+5)/25*2,0,2)
        if buy_accel is not None: A+=clamp((buy_accel+5)/25*2,0,2)
        if speed_accel is not None: A+=clamp((speed_accel+10)/40*1,0,1)
        if large is not None: A+=clamp(large/100*2,0,2)
        if ofi is not None and ofi>=self.s.model_b_ofi_min and qabs is not None and qabs>=self.s.model_b_quote_absorb_min and strength is not None and strength>=self.s.model_b_strength_min and sell_pressure_damage_resistance(st,n): A+=5
        A=clamp(A,0,30)
        B=0.0; atr_abs=recent_atr_abs(st,n)
        if rise: B+=4
        if high_hold(st,n): B+=3
        if vw and atr_abs and (st.price>=vw or (vw-st.price)/atr_abs<=self.s.price_hold_vwap_gap_atr): B+=4
        if rng_comp is not None: B+=clamp(rng_comp/80*5,0,5)
        if atr_comp is not None: B+=clamp(atr_comp/70*4,0,4)
        rec,_,_=sell_pulse_recovery(st,n)
        if rec is not None: B+=clamp(rec*3,0,3)
        if sell_pressure_damage_resistance(st,n): B+=2
        C=0.0
        if tod is not None: C+=clamp((tod-0.8)/0.9*8,0,8)
        if turn_acc is not None: C+=clamp((turn_acc-80)/120*5,0,5)
        if large is not None: C+=clamp(large/100*3,0,3)
        if turn10>=self.s.minimum_turnover_10m: C+=2
        if cr<=2 and turn_acc and turn_acc>110: C+=2
        D=0.0
        if market_rs is not None: D+=clamp((market_rs+1)/3*4,0,4)
        if sector_rs is not None: D+=clamp((sector_rs+1)/3*3,0,3)
        if breadth is not None: D+=clamp((breadth-40)/50*3,0,3)
        if breadth_exp is not None: D+=clamp((breadth_exp+2)/12*2,0,2)
        if gap is not None and gap>=2: D+=2
        if (sec.get('laggard_ratio') or 0)>=20: D+=1
        E=0.0; recent_prices=[t.price for t in t10 if t.price]; box_hi=max(recent_prices) if recent_prices else st.price; proximity=1-(max(box_hi-st.price,0)/max(st.price,1)); E+=clamp((proximity-0.98)/0.02*3,0,3)
        if vw and st.price>=vw: E+=2
        if qabs is not None and qabs>=30: E+=2
        if strength is not None and strength>=120: E+=1
        if turn_acc is not None and turn_acc>=130: E+=1
        if sum(1 for v in ignition_flags.values() if v)>=2: E+=1

        raw_total=clamp(A+B+C+D+E); heat_penalty=20.0 if cr>self.s.allowed_change_max else 0.0; total=round(max(0.0,raw_total-heat_penalty),1)
        purity=85.0
        if cr>self.s.preferred_change_max: purity-=25+(cr-self.s.preferred_change_max)*12
        if cr<0: purity-=min(10,abs(cr)*4)
        if gap is not None and gap<1: purity-=15
        if turn_acc is not None and turn_acc>300: purity-=15
        if vi_recent: purity=0
        if news_hot: purity=max(0,purity-35)
        purity=round(clamp(purity),1); energy=round(clamp((B/25*35)+(C/20*30)+(A/30*35)),1)

        model_a1_ready=bool(common_hard and flow_confirmed and absorb is not None and absorb>=self.s.model_a_absorb_ratio_min and absorb_3 and sell_decel_3 and foreign_accel_3 and inst_decel is not None and inst_decel>=self.s.model_a_min_sell_decel)
        model_a2_ready=bool(common_hard and flow_confirmed and core_ratio is not None and core_ratio>=self.s.model_a2_absorb_ratio_min and core_absorb_3 and core_accel_3 and foreign_sell_decel_3)
        model_a_ready=bool(model_a1_ready or model_a2_ready)
        model_b_ready=bool(common_hard and ofi is not None and ofi>=self.s.model_b_ofi_min and strength is not None and strength>=self.s.model_b_strength_min and qabs is not None and qabs>=self.s.model_b_quote_absorb_min and rng_comp is not None and rng_comp>=self.s.model_b_range_compression_min and atr_comp is not None and atr_comp>=self.s.model_b_atr_compression_min and turn_acc is not None and turn_acc>=self.s.model_b_turn_accel_min)
        absorption_model_detail='A1_FOREIGN_ABSORB' if model_a1_ready else ('A2_CORE_INST_ABSORB' if model_a2_ready else ('B_COMPRESSION' if model_b_ready else 'NONE'))
        detection_model='A_ABSORPTION' if model_a_ready else ('B_COMPRESSION' if model_b_ready else 'OBSERVE'); hard_data=common_hard and (model_a_ready or model_b_ready)
        ignition=round(clamp(total*0.72+energy*0.18+(E/10*100)*0.10) if hard_data else min(clamp(total*0.72+energy*0.18+(E/10*100)*0.10),79),1)
        rvol_ready=tod is not None and completed_minutes==10 and baseline_days>=self.s.tod_min_baseline_days
        breadth_ready=breadth is not None and (sector_sample or 0)>=self.s.sector_min_sample
        sector_not_worsening=True
        supply_tight_conditions=[hold,total>=80,rvol_ready and tod>=1.2,qabs is not None and qabs>=20,rise,high_hold(st,n),(rng_comp or 0)>=20,(vw is not None and st.price>=vw*(1-0.001))]
        if model_a_ready:
            supply_tight_conditions += [sell_decel_3 if model_a1_ready else foreign_sell_decel_3, absorb_3 if model_a1_ready else core_absorb_3, tape_sell_persistent]
        else: supply_tight_conditions += [ofi is not None and ofi>=0.05,strength is not None and strength>=105]
        supply_tight=hold and total>=80 and rvol_ready and tod is not None and tod>=1.2 and sum(bool(x) for x in supply_tight_conditions)>=self.s.supply_tight_min_conditions
        exhaustion_signals=[qabs is not None and qabs>=35, qm['ask_depletion'] is not None and qm['ask_depletion']>=60, qm['replenishment_decline'] is not None and qm['replenishment_decline']>=10, ofi is not None and ofi>=0.10, strength is not None and strength>=110, buy_accel is not None and buy_accel>=5, qm['spread_trend'] is not None and qm['spread_trend']>=0, rise, turn_acc is not None and turn_acc>=110, vw is not None and st.price>=vw]
        exhaustion_count=sum(bool(x) for x in exhaustion_signals); exhaustion=supply_tight and exhaustion_count>=self.s.supply_exhaustion_min_signals
        # Independent hidden-gem truth: market cap, familiarity, sector leadership
        # and broad-market direction do not suppress discovery.
        discovery_gate=common_hard and not distortion and data in {'LIVE','CONFIRMED'}
        early_absorption_evidence=bool(
            pressure_absorbed or early_absorbed or
            (bid_absorption or 0)>=self.s.bid_absorption_min_score or
            (impact_decay or 0)>=self.s.impact_decay_min_score
        )
        early_hidden_gem=bool(
            discovery_gate and hold and early_absorption_evidence and
            self.s.early_hidden_gem_change_min<=cr<=self.s.early_hidden_gem_change_max and
            total>=self.s.early_hidden_gem_min_score
        )
        absolute_gate=common_hard and not distortion and data in {'LIVE','CONFIRMED'}
        pre_common=absolute_gate and hold and supply_tight and rvol_ready and tod is not None and tod>=1.3 and total>=88 and cr<=self.s.allowed_change_max and (rng_comp or 0)>=30 and (turn_acc or 0)>=110
        # ORIGINAL OBJECTIVE SEQUENCE LOCK:
        # PRE-IGNITION requires confirmed sell-pressure absorption and release readiness.
        # B_COMPRESSION remains an early discovery path; it cannot bypass this sequence.
        pre=bool(pre_common and (model_a_ready or model_b_ready) and pressure_absorbed and release_ready)
        trigger_count=sum(1 for k,v in ignition_flags.items() if v and k!='TRADE_SPEED_ACCEL')
        imminent=pre and total>=94 and exhaustion
        ignition_event=imminent and trigger_count>=self.s.ignition_trigger_min_count
        if ignition_event: stage='IGNITION'
        elif imminent: stage='IGNITION IMMINENT'
        elif pre: stage='PRE-IGNITION'
        elif absolute_gate and exhaustion and (model_a_ready or model_b_ready): stage='SUPPLY EXHAUSTION'
        elif absolute_gate and supply_tight and (model_a_ready or model_b_ready): stage='SUPPLY TIGHT'
        elif early_hidden_gem: stage='EARLY HIDDEN GEM'
        elif total>=70: stage='ABSORB'
        elif total>=60: stage='WATCH'
        else: stage='EXCLUDE'
        if stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION','PRE-IGNITION','IGNITION IMMINENT','IGNITION'} and not absolute_gate: stage='WATCH' if total>=60 else 'EXCLUDE'

        if stage in {'PRE-IGNITION','IGNITION IMMINENT'} and purity>=70 and detection_model in {'A_ABSORPTION','B_COMPRESSION'} and release_ready: suitability='A'
        elif stage in {'PRE-IGNITION','IGNITION IMMINENT'} and purity>=70 and detection_model in {'A_ABSORPTION','B_COMPRESSION'}: suitability='B'
        elif stage=='IGNITION': suitability='B'  # detected but no longer preferred for fresh pre-buy
        elif stage in {'SUPPLY TIGHT','SUPPLY EXHAUSTION'} and total>=80: suitability='B'
        elif stage=='EARLY HIDDEN GEM': suitability='WATCH'
        else: suitability='WATCH' if total>=60 else '제외'
        hold_label='PASS' if hold and discovery_gate else ('UNCONFIRMED' if hold else 'FAIL')
        if suitability in {'A','B'} and (hold_label!='PASS' or not absolute_gate): suitability='WATCH'

        persistence=0.0
        if hold: persistence+=20
        if breadth is not None: persistence+=clamp((breadth-35)/65*20,0,20)
        if market_rs is not None: persistence+=clamp((market_rs+1)/4*15,0,15)
        if d1 is not None: persistence+=15 if -1<=d1<=3 else (8 if -3<=d1<=5 else 0)
        if d3 is not None: persistence+=15 if -2<=d3<=8 else (8 if -5<=d3<=12 else 0)
        if d5 is not None: persistence+=15 if -3<=d5<=12 else (8 if -7<=d5<=18 else 0)
        persistence=round(clamp(persistence),1)
        persistence15 = None if d15 is None else round(clamp(100 - max(0,abs(d15)-15)*3),1)
        final=round(ignition*.45+purity*.30+persistence*.25,1)
        event_ts=st.last_trade_event_ts or st.last_event_ts or st.last_trade_receive_ts or n; dt=datetime.fromtimestamp(event_ts,timezone.utc).astimezone(KST).isoformat(timespec='seconds')
        if vw and atr_abs: vstate='ABOVE' if st.price>=vw else ('NEAR' if (vw-st.price)/atr_abs<=self.s.price_hold_vwap_gap_atr else 'BELOW')
        else: vstate='UNAVAILABLE'
        entry=f"{st.price*0.997:.0f}~{st.price*1.002:.0f}" if st.price else '-'; recw='10~15%' if suitability=='A' else ('5~10%' if suitability=='B' else '0~5% 관찰')
        active_triggers=[k for k,v in ignition_flags.items() if v]; trigger_text=('실제 트리거: '+', '.join(active_triggers)) if active_triggers else '아직 실제 IGNITION 트리거 2개 미만'
        inv='PRICE HOLD 이탈/VWAP 재이탈/기관 매도속도 재가속/업종 Breadth 악화'; stop='진입가 -6% 또는 PRICE HOLD 구조 파괴 중 먼저 발생'
        reasons=hold_reasons+[f'MODEL={detection_model}',f'SCORE_A_MICRO={A}',f'SCORE_B_HOLD={B}',f'SCORE_C_TURN={C}',f'SCORE_D_SECTOR={D}',f'SCORE_E_TRIGGER={E}',f'BASELINE_DAYS={baseline_days}',f'COMPLETED_MINUTES={completed_minutes}',f'CHANGE_3D_CONTEXT={d3}',f'CHANGE_5D_CONTEXT={d5}',f'FINAL_RANK={final}',f'CROSS_SOURCE={cross_confirmed}',f'CROSS_DIV={cross_div}',f'FLOW_CONFIRMED={flow_confirmed}',f'ABSORB_3WINDOW={absorb_3}',f'SELL_DECEL_3WINDOW={sell_decel_3}',f'FOREIGN_ACCEL_3WINDOW={foreign_accel_3}',f'FLOW_WINDOWS={flow_windows}',f'PROGRAM_FRESH={program_fresh}',f'MARKET_INDEX_FRESH={market_fresh}',f'MARKET_SAMPLE={market_sample}',f'SECTOR_SAMPLE={sector_sample}',f'MARKET_RED={market_red}',f'SPREAD_OK={spread_ok}',f'SPREAD_TREND={qm["spread_trend"]}',f'REPLENISHMENT_DECLINE={qm["replenishment_decline"]}',f'BUY_ACCEL={buy_accel}',f'TRADE_SPEED_ACCEL={speed_accel}',f'OFFICIAL_STRENGTH={official_strength}',f'BLOCK_DISTORTION={distortion}',f'DISCOVERY_GATE={discovery_gate}',f'EARLY_HIDDEN_GEM={early_hidden_gem}',f'EARLY_ABSORPTION_EVIDENCE={early_absorption_evidence}',f'MARKET_CAP_CONTEXT={mcap}',f'LEADER_SENSOR={leader_sensor}',f'BREADTH_EXP={breadth_exp}',f'SECTOR_RS_SLOPE={sector_rs_slope}',f'BREADTH_UP={sec.get("up_ratio")}',f'BREADTH_VWAP={sec.get("vwap_ratio")}',f'BREADTH_TURNOVER={sec.get("turnover_ratio")}',f'BREADTH_LAGGARD={sec.get("laggard_ratio")}',f'LEADER_CHAIN={chain_score}',f'BREADTH_CONFIDENCE={breadth_confidence}',f'VI_RECENT={vi_recent}',f'NEWS_HOT={news_hot}',f'NEWS_CATALYST={news_catalyst}',f'RVOL_READY={rvol_ready}',f'COMMON_HARD={common_hard}',f'MODEL_A_READY={model_a_ready}',f'MODEL_B_READY={model_b_ready}',f'SUPPLY_EXHAUSTION_SIGNALS={exhaustion_count}',f'IGNITION_TRIGGER_COUNT={trigger_count}',f'IGNITION_TRIGGERS={active_triggers}',f'BID_ADAPTIVE_FLOOR={qm.get("bid_adaptive_floor")}',f'BID_SELL_VALUE={qm.get("bid_sell_value")}',f'BID_TOTAL_VALUE={qm.get("bid_total_value")}',f'EARLY_ABSORBED={early_absorbed}',f'BID_ABSORPTION={bid_absorption}',f'BID_REPLENISH_EVENTS={qm.get("bid_replenishment_events")}',f'TAPE_SELL_PERSISTENT={tape_sell_persistent}',f'TAPE_SELL_DECEL={tape_sell_decel}',f'TAPE_SELL_VALUES={tape_sell.get("sell_values")}',f'SELL_PRESSURE_EVIDENCE={sell_pressure_evidence}',f'MODEL_A1_READY={model_a1_ready}',f'MODEL_A2_READY={model_a2_ready}',f'CORE_ABSORB_RATIO={core_ratio}',f'PRICE_IMPACT_DECAY={impact_decay}',f'IMPACT_WINDOWS={impact_windows}',f'IMPACT_SELL_VALUES={impact_sell_values}',f'FLOW_PRICE_LAG={flow_lag}',f'RELEASE_DISTANCE={release_dist}',f'RELEASE_GAP={release_gap}',f'PRESSURE_RELEASE_SCORE={pressure_release}',f'PRE_SEQUENCE_LOCK={pressure_absorbed and release_ready}',f'PRECURSOR_STAGE={precursor_stage}',f'PRECURSOR_AXES={precursor_axes}']
        c=Candidate(symbol=st.symbol,name=st.name,market=st.market,venue=st.venue,current_price=st.price,change_rate=cr,data_timestamp=dt,data_status=data,stage=stage,total_score=total,purity_score=purity,energy_compression=energy,ignition_probability=ignition,persistence_score=persistence,change_1d=d1,change_3d=d3,change_5d=d5,change_15d=d15,persistence_15d_score=persistence15,foreign_flow=f,institution_flow=inst,program_flow=prog,institution_sell_velocity=inst_decel,foreign_absorb_ratio=absorb,absorb_acceleration=abs_acc,turnover_10m=turn10,tod_rvol=tod,atr_compression=atr_comp,range_compression=rng_comp,rising_lows=rise,price_hold=hold_label,vwap_state=vstate,market_rs=market_rs,sector_rs=sector_rs,sector_breadth=breadth,flow_price_divergence=flow_div,leader_laggard_gap=gap,trade_strength=strength,ofi=ofi,quote_absorption=qabs,large_trade_score=large,entry_zone=entry,recommended_weight=recw,add_condition='VWAP 지지 + 공급감소 + 5분 거래대금 재가속',trigger_10_30m=trigger_text,invalidation=inv,stop_condition=stop,sell_news_risk=news_risk,suitability=suitability,reasons=reasons,detection_model=detection_model,sector_sample=sector_sample,market_sample=market_sample,trade_age_sec=round(trade_age,3) if trade_age is not None else None,quote_age_sec=round(quote_age,3) if quote_age is not None else None,program_age_sec=round(program_age,3) if program_age is not None else None,ignition_trigger_count=trigger_count,leader_sensor=leader_sensor,sector_breadth_expansion=breadth_exp,sector_rs_slope=sector_rs_slope,breadth_up_ratio=sec.get('up_ratio'),breadth_vwap_ratio=sec.get('vwap_ratio'),breadth_turnover_ratio=sec.get('turnover_ratio'),breadth_laggard_ratio=sec.get('laggard_ratio'),spread_trend=qm.get('spread_trend'),trade_speed_accel=speed_accel,buy_aggression_accel=buy_accel,supply_exhaustion_signals=exhaustion_count,leader_laggard_chain_score=chain_score,sector_breadth_confidence=breadth_confidence,vi_risk=('BLOCK' if vi_recent else 'CLEAR'),news_catalyst=news_catalyst,investment_trust_flow=flow_windows.get('investment_trust'),pension_flow=flow_windows.get('pension'),core_inst_flow=flow_windows.get('core_inst'),core_actor=flow_windows.get('core_actor','압축형'),price_impact_decay=impact_decay,flow_price_lag=flow_lag,release_distance_score=release_dist,release_gap_pct=release_gap,pressure_release_score=pressure_release,precursor_stage=precursor_stage,precursor_axes=precursor_axes,bid_absorption_score=bid_absorption,tape_sell_deceleration=tape_sell_decel,tape_sell_persistent=tape_sell_persistent,sell_pressure_evidence=sell_pressure_evidence,absorption_model=absorption_model_detail,core_inst_absorb_ratio=core_ratio)
        # Tie-break order encoded separately and consumed by rank(): HOLD, exhaustion proximity, turnover accel, laggard gap, breadth expansion.
        tie=(1 if hold_label=='PASS' else 0,exhaustion_count,pressure_release or -1,turn_acc or -1,gap or -999,breadth_exp or -999)
        return final,c,tie

    def rank(self,states):
        now=time.time(); self.update_venue_market_proxies(states,now); sectors=self.sector_stats(states,now); rows=[]
        stage_priority={
            'PRE-IGNITION':70,
            'IGNITION IMMINENT':68,
            'SUPPLY EXHAUSTION':55,
            'SUPPLY TIGHT':45,
            'EARLY HIDDEN GEM':40,
            'ABSORB':30,
            'WATCH':20,
            'IGNITION':10,
            'DATA CHECK':0,
        }
        for st in list(states.values()):
            r=self.score(st,states,sectors,now)
            if r:
                final,c,*rest=r
                if c.stage not in {'EXCLUDE','SENSOR'}:
                    prox=stage_priority.get(c.stage,0)
                    if c.precursor_stage=='RELEASE READY' and c.stage not in {'PRE-IGNITION','IGNITION IMMINENT','IGNITION'}:
                        prox=max(prox,60)
                    elif c.precursor_stage=='PRESSURE ABSORBED' and prox<50:
                        prox=50
                    elif c.precursor_stage=='EARLY PRESSURE ABSORBED' and prox<42:
                        prox=42
                    rows.append((prox,final,c,rest[0] if rest else ()))
        rows.sort(key=lambda x:(x[0],x[2].ignition_probability,x[2].purity_score,x[2].persistence_score,x[1],x[2].total_score,*x[3]),reverse=True)
        return [c for _,_,c,_ in rows[:20]]
