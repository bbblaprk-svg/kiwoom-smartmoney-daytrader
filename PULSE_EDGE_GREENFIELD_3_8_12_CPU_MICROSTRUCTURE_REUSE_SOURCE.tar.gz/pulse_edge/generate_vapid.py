import base64, os
from cryptography.hazmat.primitives.asymmetric import ec

def b64(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()

def generate():
    k=ec.generate_private_key(ec.SECP256R1())
    n=k.private_numbers().private_value.to_bytes(32,'big')
    p=k.public_key().public_numbers(); pub=b'\x04'+p.x.to_bytes(32,'big')+p.y.to_bytes(32,'big')
    subject=os.getenv('PULSE_VAPID_SUBJECT') or os.getenv('PULSE_PUBLIC_URL') or 'https://localhost'
    return b64(n),b64(pub),subject

if __name__=='__main__':
    private,public,subject=generate()
    print('PULSE_VAPID_PRIVATE_KEY='+private)
    print('PULSE_VAPID_PUBLIC_KEY='+public)
    print('PULSE_VAPID_SUBJECT='+subject)
