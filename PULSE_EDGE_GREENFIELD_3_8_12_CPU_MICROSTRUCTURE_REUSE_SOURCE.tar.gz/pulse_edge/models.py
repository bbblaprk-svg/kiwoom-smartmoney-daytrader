from __future__ import annotations
from dataclasses import dataclass, field, asdict
from collections import deque
from typing import Any

@dataclass
class Quote:
    ts: float
    ask: float|None=None
    bid: float|None=None
    ask_qty: float|None=None
    bid_qty: float|None=None
    total_ask: float|None=None
    total_bid: float|None=None

@dataclass
class Trade:
    ts: float
    price: float
    volume: float
    cum_volume: float|None=None
    cum_amount: float|None=None
    buy_exec: float|None=None
    sell_exec: float|None=None
    strength: float|None=None

@dataclass
class InvestorSnapshot:
    ts: float = 0.0
    foreign: float|None = None
    institution: float|None = None
    program: float|None = None
    source_status: str = 'UNAVAILABLE'
    investment_trust: float|None = None
    pension: float|None = None

@dataclass
class SymbolState:
    symbol: str
    name: str = ''
    market: str = 'UNKNOWN'
    sector: str = 'UNKNOWN'
    nxt_enabled: bool = False
    listed_shares: float|None = None
    venue: str = 'KRX'
    open: float|None = None
    high: float|None = None
    low: float|None = None
    prev_close: float|None = None
    price: float|None = None
    change_rate: float|None = None
    # Compatibility timestamps. They are kept as the latest stock event/receive time,
    # but DATA TRUTH uses the channel-specific timestamps below so quotes/program events
    # can never make a stale trade stream look LIVE.
    last_event_ts: float = 0.0
    last_receive_ts: float = 0.0
    last_trade_event_ts: float = 0.0
    last_trade_receive_ts: float = 0.0
    last_quote_event_ts: float = 0.0
    last_quote_receive_ts: float = 0.0
    last_program_event_ts: float = 0.0
    last_program_receive_ts: float = 0.0
    cumulative_amount: float|None = None
    cumulative_volume: float|None = None
    program_net: float|None = None
    rest_price: float|None = None
    rest_price_ts: float = 0.0
    rest_change_rate: float|None = None
    rest_change_ts: float = 0.0
    rest_venue: str|None = None
    trades: deque = field(default_factory=lambda: deque(maxlen=1800))
    quotes: deque = field(default_factory=lambda: deque(maxlen=600))
    investor_hist: deque = field(default_factory=lambda: deque(maxlen=80))
    minute_amount: dict = field(default_factory=dict)
    minute_feed_coverage: dict = field(default_factory=dict)
    first_seen_ts: float = 0.0
    vi_active: bool = False
    vi_last_ts: float = 0.0
    vi_count: int = 0
    vi_trigger_rate: float|None = None
    news_ts: float = 0.0
    news_hot: bool = False
    news_catalyst: bool = False
    news_risk: str = 'UNAVAILABLE(NO_LIVE_NEWS_FEED)'
    daily_bars: list = field(default_factory=list)
    daily_flows: list = field(default_factory=list)

@dataclass
class Candidate:
    symbol: str
    name: str
    market: str
    venue: str
    current_price: float|None
    change_rate: float|None
    data_timestamp: str
    data_status: str
    stage: str
    total_score: float
    purity_score: float
    energy_compression: float
    ignition_probability: float
    persistence_score: float|None
    change_1d: float|None
    change_3d: float|None
    change_5d: float|None
    foreign_flow: float|None
    institution_flow: float|None
    program_flow: float|None
    institution_sell_velocity: float|None
    foreign_absorb_ratio: float|None
    absorb_acceleration: float|None
    turnover_10m: float|None
    tod_rvol: float|None
    atr_compression: float|None
    range_compression: float|None
    rising_lows: bool
    price_hold: str
    vwap_state: str
    market_rs: float|None
    sector_rs: float|None
    sector_breadth: float|None
    flow_price_divergence: float|None
    leader_laggard_gap: float|None
    trade_strength: float|None
    ofi: float|None
    quote_absorption: float|None
    large_trade_score: float|None
    entry_zone: str
    recommended_weight: str
    add_condition: str
    trigger_10_30m: str
    invalidation: str
    stop_condition: str
    sell_news_risk: str
    suitability: str
    reasons: list[str] = field(default_factory=list)
    # 3.3 diagnostic fields are appended with defaults for backwards-compatible
    # history payloads and positional test fixtures.
    detection_model: str = 'OBSERVE'
    sector_sample: int|None = None
    market_sample: int|None = None
    trade_age_sec: float|None = None
    quote_age_sec: float|None = None
    program_age_sec: float|None = None
    ignition_trigger_count: int = 0
    leader_sensor: bool = False
    sector_breadth_expansion: float|None = None
    sector_rs_slope: float|None = None
    breadth_up_ratio: float|None = None
    breadth_vwap_ratio: float|None = None
    breadth_turnover_ratio: float|None = None
    breadth_laggard_ratio: float|None = None
    spread_trend: float|None = None
    trade_speed_accel: float|None = None
    buy_aggression_accel: float|None = None
    supply_exhaustion_signals: int = 0
    change_15d: float|None = None
    persistence_15d_score: float|None = None
    leader_laggard_chain_score: float|None = None
    sector_breadth_confidence: str = 'LOW'
    vi_risk: str = 'CLEAR'
    news_catalyst: bool = False
    investment_trust_flow: float|None = None
    pension_flow: float|None = None
    core_inst_flow: float|None = None
    core_actor: str = '압축형'
    price_impact_decay: float|None = None
    flow_price_lag: float|None = None
    release_distance_score: float|None = None
    release_gap_pct: float|None = None
    pressure_release_score: float|None = None
    precursor_stage: str = 'OBSERVE'
    precursor_axes: int = 0
    bid_absorption_score: float|None = None
    tape_sell_deceleration: bool = False
    tape_sell_persistent: bool = False
    sell_pressure_evidence: bool = False
    absorption_model: str = 'NONE'
    core_inst_absorb_ratio: float|None = None

    def to_dict(self) -> dict[str,Any]:
        return asdict(self)


@dataclass
class CoiledCandidate:
    symbol: str
    name: str
    market: str
    current_price: float|None
    change_rate: float|None
    score: float
    core_actor: str
    foreign_3d: float|None
    trust_3d: float|None
    pension_3d: float|None
    core_inst_3d: float|None
    energy_latency: float
    compression_score: float
    supply_decay: float
    turnover_build: float
    breakout_distance: float|None
    expected_window: str
    stage: str
    promoted_to_now: bool=False
    price_impact_decay: float|None=None
    flow_price_lag: float|None=None
    release_distance_score: float|None=None
    pressure_release_score: float|None=None
    precursor_axes: int=0
    reasons: list[str]=field(default_factory=list)
    def to_dict(self): return asdict(self)
