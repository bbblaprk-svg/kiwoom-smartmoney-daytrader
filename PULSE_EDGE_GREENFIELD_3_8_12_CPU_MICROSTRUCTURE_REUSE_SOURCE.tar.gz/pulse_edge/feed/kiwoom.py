from __future__ import annotations
import asyncio, json, time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Any, Awaitable, Callable
import httpx, websockets

KST=ZoneInfo('Asia/Seoul')
# Kiwoom monetary flow fields are published in million-won display units.
# Normalize them to KRW before scoring so denominator floors and UI values share one unit.
AMOUNT_UNIT_KRW=1_000_000.0

def num(v):
    if v is None: return None
    s=str(v).replace(',','').replace('%','').strip()
    if not s: return None
    try: return float(s.replace('+',''))
    except: return None

def money_krw(v):
    x=num(v)
    return None if x is None else x*AMOUNT_UNIT_KRW

def symbol_of(v):
    s=str(v or '').strip().replace('_NX','')
    d=''.join(c for c in s if c.isdigit())
    return d[:6] if len(d)>=6 else ''

FID={
 '0B':{'20':'trade_time','10':'price','11':'change','12':'change_rate','16':'open','17':'high','18':'low','15':'trade_volume','13':'cumulative_volume','14':'cumulative_amount','228':'trade_strength','1030':'sell_exec_volume','1031':'buy_exec_volume','1032':'buy_exec_ratio','1313':'instant_amount','9081':'exchange_code'},
 '0D':{'21':'quote_time','41':'ask1','42':'ask2','43':'ask3','51':'bid1','52':'bid2','53':'bid3','61':'ask1_qty','62':'ask2_qty','63':'ask3_qty','71':'bid1_qty','72':'bid2_qty','73':'bid3_qty','121':'total_ask_qty','125':'total_bid_qty'},
 '0w':{'20':'trade_time','10':'price','12':'change_rate','212':'program_net_buy_amount','213':'program_net_buy_amount_delta','9081':'exchange_code'},
 '0J':{'20':'trade_time','10':'price','12':'change_rate'},
 '1h':{'9001':'stock_code','302':'stock_name','9068':'vi_event','1221':'vi_price','1223':'vi_event_time','1224':'vi_release_time','1225':'vi_type','1489':'vi_trigger_rate','1490':'vi_count','9069':'vi_direction'},
}

class Auth:
    def __init__(self,base,key,secret):
        self.base=base.rstrip('/'); self.key=key; self.secret=secret; self._tok=None; self._exp=0.; self.lock=asyncio.Lock()
        self.client=httpx.AsyncClient(timeout=httpx.Timeout(15.0,connect=8.0),limits=httpx.Limits(max_connections=4,max_keepalive_connections=2))
    async def token(self):
        async with self.lock:
            if self._tok and time.time()<self._exp-120: return self._tok
            if not self.key or not self.secret: raise RuntimeError('Kiwoom credentials missing')
            r=await self.client.post(self.base+'/oauth2/token',json={'grant_type':'client_credentials','appkey':self.key,'secretkey':self.secret},headers={'Content-Type':'application/json;charset=UTF-8'})
            r.raise_for_status(); b=r.json()
            if int(b.get('return_code',0) or 0)!=0 or not b.get('token'): raise RuntimeError('Kiwoom token rejected')
            self._tok=str(b['token']); self._exp=time.time()+11*3600; return self._tok
    async def close(self):
        await self.client.aclose()

class Rest:
    def __init__(self,base,auth):
        self.base=base.rstrip('/'); self.auth=auth
        self.client=httpx.AsyncClient(timeout=httpx.Timeout(15.0,connect=8.0),limits=httpx.Limits(max_connections=12,max_keepalive_connections=6),http2=False)
        self.sem=asyncio.Semaphore(3)
    async def post(self,api_id,path,body,cont=None,next_key=None):
        h={'authorization':'Bearer '+await self.auth.token(),'api-id':api_id,'Content-Type':'application/json;charset=UTF-8'}
        if cont: h['cont-yn']=cont
        if next_key: h['next-key']=next_key
        async with self.sem:
            r=await self.client.post(self.base+path,headers=h,json=body)
        r.raise_for_status(); b=r.json()
        if int(b.get('return_code',0) or 0) not in (0,20): raise RuntimeError(f'{api_id}: {b.get("return_msg","error")}')
        return b,r.headers
    async def close(self):
        await self.client.aclose()

async def load_universe(rest:Rest,max_pages=30):
    out={}
    for market_code,market in [('0','KOSPI'),('10','KOSDAQ')]:
        cont=next_key=None
        for _ in range(max_pages):
            b,h=await rest.post('ka10099','/api/dostk/stkinfo',{'mrkt_tp':market_code},cont,next_key)
            for r in b.get('list',[]) or []:
                s=symbol_of(r.get('code'))
                if not s: continue
                name=str(r.get('name') or '')
                cls=(str(r.get('companyClassName') or '')+' '+name).upper()
                state=str(r.get('state') or '')
                warn=str(r.get('orderWarning') or '')
                blocked=any(x in cls for x in ['ETF','ETN','REIT','리츠','SPAC','스팩']) or name.endswith(('우','우B','우C')) or any(x in state for x in ['관리','정지','정리매매','상장폐지','투자위험']) or warn.upper() in {'1','Y','TRUE'}
                if blocked: continue
                out[s]={'symbol':s,'name':name,'market':market,'sector':str(r.get('upName') or 'UNKNOWN'),'listed_shares':num(r.get('listCount')),'nxt_enabled':str(r.get('nxtEnable') or '').upper() in {'1','Y','TRUE','T'}}
            cont=h.get('cont-yn'); next_key=h.get('next-key')
            if cont!='Y' or not next_key: break
    return out

async def minute_baseline_rows(rest:Rest,symbol:str,venue:str,max_pages:int=8,target_days:int=6):
    """Fetch bounded official 1-minute chart history for ToD-RVOL bootstrap.

    The same venue-specific code form is used for KRX/NXT; only timestamp, price and
    volume are retained. Amount is approximated consistently as minute price*volume.
    """
    wire=symbol if venue=='KRX' else symbol+'_NX'
    cont=next_key=None; out=[]; days=set()
    for _ in range(max(1,int(max_pages))):
        b,h=await rest.post('ka10080','/api/dostk/chart',{'stk_cd':wire,'tic_scope':'1','upd_stkpc_tp':'1'},cont,next_key)
        for r in b.get('stk_min_pole_chart_qry',[]) or []:
            raw=''.join(c for c in str(r.get('cntr_tm') or '') if c.isdigit())
            if len(raw)<12: continue
            raw=raw[-14:] if len(raw)>=14 else raw
            try:
                if len(raw)==14: dt=datetime.strptime(raw,'%Y%m%d%H%M%S').replace(tzinfo=KST)
                elif len(raw)==12: dt=datetime.strptime(raw,'%Y%m%d%H%M').replace(tzinfo=KST)
                else: continue
            except Exception:
                continue
            px=abs(num(r.get('cur_prc')) or 0); qty=abs(num(r.get('trde_qty')) or 0)
            if px<=0 or qty<=0: continue
            out.append((dt.timestamp(),px*qty)); days.add(dt.date().isoformat())
        if len(days)>=max(1,int(target_days)): break
        cont=h.get('cont-yn'); next_key=h.get('next-key')
        if cont!='Y' or not next_key: break
    out.sort(key=lambda x:x[0])
    return out


async def intraday_investor_snapshots(rest:Rest,symbol:str,market:str,venue:str):
    """Venue-native intraday investor chart (ka10064).

    Amount mode is used and values are normalized to KRW. NXT uses the official
    `<code>_NX` form instead of borrowing KRX investor data.
    """
    wire=symbol if venue=='KRX' else symbol+'_NX'
    mrkt='001' if market=='KOSPI' else ('101' if market=='KOSDAQ' else '000')
    b,_=await rest.post('ka10064','/api/dostk/chart',{'mrkt_tp':mrkt,'amt_qty_tp':'1','trde_tp':'0','stk_cd':wire})
    rows=b.get('opmr_invsr_trde_chart',[]) or []; now=datetime.now(KST); out=[]
    for r in rows:
        raw=''.join(c for c in str(r.get('tm') or '') if c.isdigit())[-6:]
        if len(raw)!=6: continue
        try:
            dt=now.replace(hour=int(raw[:2]),minute=int(raw[2:4]),second=int(raw[4:]),microsecond=0)
            ts=dt.timestamp()
        except Exception:
            continue
        age=time.time()-ts
        if age < -300 or age > 24*3600: continue
        status='CONFIRMED' if age<=120 else ('DELAYED' if age<=900 else 'STALE')
        out.append({'foreign':money_krw(r.get('frgnr_invsr')),'institution':money_krw(r.get('orgn')),'investment_trust':money_krw(r.get('invtrt')),'pension':money_krw(r.get('penfnd_etc')),'ts':ts,'status':status})
    out.sort(key=lambda x:x['ts'])
    return out[-40:]

class WS:
    def __init__(self,url,auth,on_event,max_items=34,reserve=10,group_base=3000,quote_focus_items=4):
        self.url=url; self.auth=auth; self.on_event=on_event; self.max_items=max_items; self.reserve=reserve; self.group_base=group_base
        self.quote_focus_items=max(1,int(quote_focus_items)); self.priority=[]; self.background=[]; self.quote_focus=[]
        self.ws=None; self.connected=False; self.last_message=0.; self.last_error=''; self.stop_evt=asyncio.Event(); self.lock=asyncio.Lock(); self._sent_items=(); self._sent_quotes=()
    def items(self):
        seen=set(); out=[]
        for x in self.priority[:max(0,self.max_items-self.reserve)]+self.background:
            if x not in seen: seen.add(x); out.append(x)
            if len(out)>=self.max_items: break
        return out
    def quote_items(self):
        allowed=set(self.items()); out=[]
        for x in self.quote_focus+self.priority+self.background:
            if x in allowed and x not in out: out.append(x)
            if len(out)>=self.quote_focus_items: break
        return out
    async def set_priority(self,items): self.priority=list(dict.fromkeys(items)); await self.refresh()
    async def set_background(self,items): self.background=list(dict.fromkeys(items))[:self.reserve]; await self.refresh()
    async def set_quote_focus(self,items): self.quote_focus=list(dict.fromkeys(items))[:self.quote_focus_items]; await self.refresh()
    async def refresh(self):
        if not self.connected or not self.ws: return
        its=tuple(self.items()); qits=tuple(self.quote_items())
        packets=[]
        # No duplicate REG traffic. Changed membership replaces the group so rotating
        # background symbols cannot accumulate stale subscriptions and feed load.
        if its and its!=self._sent_items:
            packets.append({'trnm':'REG','grp_no':str(self.group_base),'refresh':'1','data':[{'item':list(its),'type':['0B','0w']}]})
        if qits and qits!=self._sent_quotes:
            packets.append({'trnm':'REG','grp_no':str(self.group_base+1),'refresh':'1','data':[{'item':list(qits),'type':['0D']}]})
        if not packets: return
        async with self.lock:
            for packet in packets: await self.ws.send(json.dumps(packet,ensure_ascii=False))
        self._sent_items=its; self._sent_quotes=qits
    async def run(self):
        backoff=1
        while not self.stop_evt.is_set():
            try:
                tok=await self.auth.token()
                async with websockets.connect(self.url,ping_interval=20,ping_timeout=20,close_timeout=5) as ws:
                    self.ws=ws; self.connected=True; self.last_error=''; self._sent_items=(); self._sent_quotes=(); backoff=1
                    await ws.send(json.dumps({'trnm':'LOGIN','token':tok},ensure_ascii=False)); ack=json.loads(await ws.recv())
                    if str(ack.get('return_code','0'))!='0': raise RuntimeError('WS login rejected')
                    for packet in [
                        {'trnm':'REG','grp_no':str(self.group_base+90),'refresh':'1','data':[{'item':[],'type':['0s']}]},
                        {'trnm':'REG','grp_no':str(self.group_base+91),'refresh':'1','data':[{'item':['001','101'],'type':['0J']}]},
                        {'trnm':'REG','grp_no':str(self.group_base+92),'refresh':'1','data':[{'item':[],'type':['1h']}]},
                    ]: await ws.send(json.dumps(packet,ensure_ascii=False))
                    await self.refresh()
                    async for msg in ws:
                        self.last_message=time.time(); p=json.loads(msg)
                        if p.get('trnm')=='PING':
                            async with self.lock: await ws.send(msg)
                            continue
                        if str(p.get('trnm') or '').upper()!='REAL': continue
                        for row in p.get('data',[]) or []:
                            typ=str(row.get('type') or ''); vals=row.get('values') or {}
                            dec={FID.get(typ,{}).get(str(k),f'fid_{k}'):v for k,v in vals.items()}
                            item=str(row.get('item') or '')
                            if typ in {'0J','0U'}:
                                s=''.join(c for c in item if c.isdigit())
                            else:
                                s=symbol_of(item)
                            venue='NXT' if item.endswith('_NX') or str(dec.get('exchange_code') or '').upper() in {'N','NXT','2'} else 'KRX'
                            await self.on_event({'type':typ,'symbol':s,'raw_item':item,'venue':venue,'name':row.get('name'),'data':dec,'receive_ts':time.time()})
            except asyncio.CancelledError: raise
            except Exception as e:
                self.connected=False; self.ws=None; self.last_error=f'{type(e).__name__}:{e}'
                await asyncio.sleep(backoff); backoff=min(30,backoff*2)


async def daily_investor_rows(rest:Rest,symbol:str,day:str,venue:str='KRX'):
    """Official ka10060. Private-fund field is deliberately ignored by design."""
    wire=symbol if venue=='KRX' else symbol+'_NX'
    b,_=await rest.post('ka10060','/api/dostk/chart',{'dt':day,'stk_cd':wire,'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1000'})
    out=[]
    for r in (b.get('stk_invsr_orgn_chart',[]) or [])[:20]:
        dt=str(r.get('dt') or '')
        if len(dt)!=8: continue
        out.append({'date':dt,'foreign':money_krw(r.get('frgnr_invsr')),'institution':money_krw(r.get('orgn')),'investment_trust':money_krw(r.get('invtrt')),'pension':money_krw(r.get('penfnd_etc'))})
    return out

async def investor_rank_symbols(rest:Rest,orgn_tp:str,limit:int=20):
    """Official ka10065 all-market net-buy ranking; used only as a coarse seed accelerator."""
    b,_=await rest.post('ka10065','/api/dostk/rkinfo',{'trde_tp':'1','mrkt_tp':'000','orgn_tp':orgn_tp,'amt_qty_tp':'1'})
    out=[]
    for r in b.get('opmr_invsr_trde_upper',[]) or []:
        sym=symbol_of(r.get('stk_cd'))
        if sym and sym not in out: out.append(sym)
        if len(out)>=limit: break
    return out
